"""基础数学运算与任务处理模块。

提供数字奇偶性判断及简易任务日志记录功能。
"""
import logging
from typing import Optional


class NumberProcessor:
    """数字处理器类，封装奇偶判断与任务标识生成逻辑。"""

    def __init__(self) -> None:
        """初始化日志器。"""
        self.logger: logging.Logger = logging.getLogger(__name__)

    def is_odd_or_even(self, number: int) -> str:
        """判断给定数字是奇数还是偶数。

        Args:
            number: 待判断的整数。

        Returns:
            'even' 如果数字是偶数，否则为 'odd'。
        """
        return 'even' if number % 2 == 0 else 'odd'

    def add_task(self, task: str) -> str:
        """记录任务并生成唯一任务标识。

        Args:
            task: 任务描述字符串。

        Returns:
            形如 'Task_<id>' 的唯一任务标识。
        """
        self.logger.info("添加任务: %s", task)
        return f"Task_{id(task)}"
