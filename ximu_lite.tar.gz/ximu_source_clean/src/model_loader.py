from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

_DEFAULTS: Dict[str, Any] = {
    "model": {
        "name": "GPT-4o",
        "type": "llm",
        "provider": "openai",
        "version": "4o",
        "max_tokens": 4096,
        "temperature": 0.7,
        "top_p": 0.9,
        "call_trigger": "user_input",
        "size_mb": 1200,
        "dependencies": ["python>=3.9", "openai>=1.0.0"],
        "cloud_free_models": []
    },
    "fallback": {
        "enabled": True,
        "model_name": "GPT-3.5-turbo",
        "type": "llm",
        "provider": "openai",
        "size_mb": 500,
        "call_trigger": "model_error",
        "cloud_free_models": []
    },
    "cache": {
        "enabled": True,
        "type": "redis",
        "ttl_seconds": 3600,
        "max_size_mb": 1024,
        "dependencies": ["redis>=4.0.0"],
        "cloud_free_models": []
    }
}

VALID_TYPES: frozenset = frozenset({"llm", "redis"})
VALID_CALL_TRIGGERS: frozenset = frozenset({"user_input", "model_error"})

_DEFAULT_TTL: int = 3600


@dataclass
class ModelConfig:
    """模型核心配置数据类。"""

    name: str = "GPT-4o"
    type: str = "llm"
    provider: str = "openai"
    version: str = "4o"
    max_tokens: int = 4096
    temperature: float = 0.7
    top_p: float = 0.9
    call_trigger: str = "user_input"
    size_mb: int = 1200
    dependencies: List[str] = field(default_factory=lambda: ["python>=3.9", "openai>=1.0.0"])
    cloud_free_models: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """将 ModelConfig 转换为字典。"""
        return asdict(self)


@dataclass
class FallbackConfig:
    """故障回退配置数据类。"""

    enabled: bool = True
    model_name: str = "GPT-3.5-turbo"
    type: str = "llm"
    provider: str = "openai"
    size_mb: int = 500
    call_trigger: str = "model_error"
    cloud_free_models: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """将 FallbackConfig 转换为字典。"""
        return asdict(self)


@dataclass
class CacheConfig:
    """缓存配置数据类。"""

    enabled: bool = True
    type: str = "redis"
    ttl_seconds: int = 3600
    max_size_mb: int = 1024
    dependencies: List[str] = field(default_factory=lambda: ["redis>=4.0.0"])
    cloud_free_models: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """将 CacheConfig 转换为字典。"""
        return asdict(self)


@dataclass
class ModelLoaderConfig:
    """模型加载器总配置数据类，包含 model/fallback/cache 三个子配置。"""

    model: ModelConfig = field(default_factory=ModelConfig)
    fallback: FallbackConfig = field(default_factory=FallbackConfig)
    cache: CacheConfig = field(default_factory=CacheConfig)

    def to_dict(self) -> Dict[str, Any]:
        """将 ModelLoaderConfig 转换为嵌套字典。"""
        return {
            "model": self.model.to_dict(),
            "fallback": self.fallback.to_dict(),
            "cache": self.cache.to_dict(),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ModelLoaderConfig:
        """从字典构建 ModelLoaderConfig 实例，缺失字段使用默认值兜底。"""
        model_data: Dict[str, Any] = {**_DEFAULTS["model"], **(data.get("model") or {})}
        fallback_data: Dict[str, Any] = {**_DEFAULTS["fallback"], **(data.get("fallback") or {})}
        cache_data: Dict[str, Any] = {**_DEFAULTS["cache"], **(data.get("cache") or {})}

        model = ModelConfig(**{k: v for k, v in model_data.items() if k in ModelConfig.__dataclass_fields__})
        fallback = FallbackConfig(**{k: v for k, v in fallback_data.items() if k in FallbackConfig.__dataclass_fields__})
        cache = CacheConfig(**{k: v for k, v in cache_data.items() if k in CacheConfig.__dataclass_fields__})

        return cls(model=model, fallback=fallback, cache=cache)


def validate_config(config: ModelLoaderConfig) -> List[str]:
    """校验配置，返回错误信息列表（空列表表示通过）。"""
    errors: List[str] = []
    sections: List[tuple[str, Any]] = [
        ("model", config.model),
        ("fallback", config.fallback),
        ("cache", config.cache),
    ]

    for section_name, section in sections:
        section_type: Optional[str] = getattr(section, "type", None)
        if section_type not in VALID_TYPES:
            errors.append(f"{section_name}.type 非法值: {section_type!r}，合法取值: {sorted(VALID_TYPES)}")

    trigger_sections: List[tuple[str, Any]] = [
        ("model", config.model),
        ("fallback", config.fallback),
    ]
    for section_name, section in trigger_sections:
        call_trigger: Optional[str] = getattr(section, "call_trigger", None)
        if call_trigger not in VALID_CALL_TRIGGERS:
            errors.append(f"{section_name}.call_trigger 非法值: {call_trigger!r}，合法取值: {sorted(VALID_CALL_TRIGGERS)}")

    return errors


class _ConfigLoader:
    """内部加载器：单例、懒加载、TTL 缓存、默认值兜底。"""

    def __init__(self) -> None:
        """初始化加载器。"""
        self._lock: threading.Lock = threading.Lock()
        self._instance: Optional[ModelLoaderConfig] = None
        self._loaded_at: float = 0.0
        self._ttl: float = float(_DEFAULT_TTL)
        self._yaml_path: str = ""
        self._custom_validators: List[Callable[[ModelLoaderConfig], List[str]]] = []
        self._post_hooks: List[Callable[[ModelLoaderConfig], None]] = []

    def register_validator(self, validator: Callable[[ModelLoaderConfig], List[str]]) -> None:
        """注册自定义校验器；validator(cfg) 返回错误信息列表。"""
        self._custom_validators.append(validator)

    def register_post_hook(self, hook: Callable[[ModelLoaderConfig], None]) -> None:
        """注册后置钩子；在配置构建后、校验前调用。"""
        self._post_hooks.append(hook)

    def _load_yaml(self, path: str) -> Dict[str, Any]:
        """读取 YAML 文件；失败返回空 dict（由默认值兜底）。"""
        p: Path = Path(path)
        if not p.exists():
            return {}
        try:
            import yaml
            with open(p, "r", encoding="utf-8") as f:
                data: Union[Dict[str, Any], Any] = yaml.safe_load(f)
            if isinstance(data, dict):
                return data
            return {}
        except Exception:
            return {}

    def _is_cache_valid(self) -> bool:
        """判断 TTL 缓存是否仍然有效。"""
        return (time.monotonic() - self._loaded_at) < self._ttl and self._instance is not None

    def get(self, yaml_path: str = "", force_reload: bool = False) -> ModelLoaderConfig:
        """获取 ModelLoaderConfig 单例。"""
        if not force_reload and self._is_cache_valid():
            return self._instance
        with self._lock:
            if not force_reload and self._is_cache_valid():
                return self._instance
            path: str = yaml_path or self._yaml_path
            self._yaml_path = path
            raw: Dict[str, Any] = self._load_yaml(path) if path else {}
            config: ModelLoaderConfig = ModelLoaderConfig.from_dict(raw)
            self._ttl = float(config.cache.ttl_seconds)
            for hook in self._post_hooks:
                hook(config)
            self._instance = config
            self._loaded_at = time.monotonic()
            return config


_loader_instance: Optional[_ConfigLoader] = None


def get_model_loader() -> _ConfigLoader:
    """获取模型配置加载器单例。"""
    global _loader_instance
    if _loader_instance is None:
        _loader_instance = _ConfigLoader()
    return _loader_instance
