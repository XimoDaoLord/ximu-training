# -*- coding: utf-8 -*-
"""汐沫AI - 认证路由模块。

提供基于Flask的用户认证路由实现，支持登录与注册功能。
"""
from __future__ import annotations

import logging
from typing import Any

from flask import Flask, jsonify, make_response, request
from src.ximu.auth_utils import auth_utils, decode_jwt_token
from src.ximu.common.config_manager import ConfigManager

logger: logging.Logger = logging.getLogger("src.auth")
app: Flask = Flask(__name__)
config: ConfigManager = ConfigManager.get_instance()


def _extract_credentials() -> tuple[str | None, str | None]:
    """从请求体中提取并验证用户名和密码。

    Returns:
        包含用户名和密码的元组，若缺失则为None。
    """
    json_data: dict[str, Any] = request.get_json(silent=True) or {}
    username: str | None = json_data.get("username")
    password: str | None = json_data.get("password")
    return username, password


def login() -> Any:
    """处理用户登录请求。

    验证凭据并生成JWT Token。

    Returns:
        包含token的JSON响应，若验证失败则返回相应错误状态码。
    """
    username, password = _extract_credentials()

    if not username or not password:
        return make_response(jsonify({"message": "Username and password are required"}), 400)

    user: dict[str, Any] | None = auth_utils.fetch_user_by_username(username)
    if not user:
        return make_response(jsonify({"message": "Invalid username or password"}), 401)

    if not auth_utils.verify_password(password, user["password"]):
        return make_response(jsonify({"message": "Invalid username or password"}), 401)

    token: str = auth_utils.generate_jwt_token(user["id"], user["username"])
    return make_response(jsonify({"token": token}), 200)


def register() -> Any:
    """处理用户注册请求。

    验证输入并执行注册逻辑（简化版）。

    Returns:
        包含注册结果或错误的JSON响应。
    """
    username, password = _extract_credentials()

    if not username or not password:
        return make_response(jsonify({"message": "Username and password are required"}), 400)

    # 执行注册逻辑，防止重复注册
    if auth_utils.fetch_user_by_username(username):
        return make_response(jsonify({"message": "Username already exists"}), 409)

    auth_utils.create_user(username, password)
    return make_response(jsonify({"message": "用户注册成功"}), 201)


app.add_url_rule('/login', view_func=login, methods=['POST'])
app.add_url_rule('/register', view_func=register, methods=['POST'])
