from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from src.auth import app

db = SQLAlchemy(app)

class User(db.Model):
    """用户模型，存储用户信息"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))

    def set_password(self, password: str) -> None:
        """设置用户密码，并存储哈希值"""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        """检查用户密码是否正确"""
        return check_password_hash(self.password_hash, password)
