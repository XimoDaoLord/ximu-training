"""Fibonacci sequence calculation module.

Provides efficient generation of Fibonacci sequences with proper
type annotations and error handling.
"""
from __future__ import annotations

from typing import List


def fibonacci(n: int) -> List[int]:
    """生成前 n 个斐波那契数。

    Args:
        n: 要生成的斐波那契数列元素数量。必须为非负整数。

    Returns:
        包含前 n 个斐波那契数的列表。

    Raises:
        ValueError: 如果 n 为负数。
    """
    if n < 0:
        raise ValueError("n 必须为非负整数")
    if n == 0:
        return []
    if n == 1:
        return [0]

    fib_sequence: List[int] = [0, 1]
    while len(fib_sequence) < n:
        fib_sequence.append(fib_sequence[-1] + fib_sequence[-2])

    return fib_sequence[:n]


def main() -> None:
    """独立运行入口。

    计算并打印前 10 个斐波那契数。
    """
    sequence: List[int] = fibonacci(10)
    print(sequence)


if __name__ == "__main__":
    main()
