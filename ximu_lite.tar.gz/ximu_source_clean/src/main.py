from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from flask import Flask

logger: logging.Logger = logging.getLogger(__name__)
app: Flask = Flask(__name__)


class _ModuleRegistry:
    """核心模块注册表，负责模块的注册与查询。"""

    def __init__(self) -> None:
        """初始化注册表，建立空模块字典。"""
        self._modules: Dict[str, Dict[str, Any]] = {}

    def register(self, name: str, module_class: Any) -> None:
        """注册一个核心认知模块。"""
        if not name:
            raise ValueError("模块名称不能为空")
        self._modules[name] = {"class": module_class}
        logger.info("注册模块: %s", name)

    def get(self, name: str) -> Optional[Any]:
        """获取指定名称的模块类。"""
        entry: Optional[Dict[str, Any]] = self._modules.get(name)
        return entry.get("class") if entry else None


class XIMUApplication:
    """汐沫AI主应用，负责启动Flask并加载核心引擎。"""

    def __init__(self) -> None:
        """初始化应用实例。"""
        self.registry: _ModuleRegistry = _ModuleRegistry()

    def _register_core_modules(self) -> None:
        """导入并注册核心认知引擎模块。"""
        from ximu.cognition.agi.metacognition import Metacognition
        from ximu.cognition.brain.cognitive_system import CognitiveSystem
        from ximu.cognition.brain.decision_engine import DecisionEngine
        from ximu.cognition.brain.omni_brain import OmniBrain
        from ximu.cognition.brain.planning_engine import PlanningEngine
        from ximu.cognition.brain.reflection_engine import ReflectionEngine

        core_modules: Dict[str, Any] = {
            "metacognition": Metacognition,
            "cognitive_system": CognitiveSystem,
            "omni_brain": OmniBrain,
            "reflection_engine": ReflectionEngine,
            "decision_engine": DecisionEngine,
            "planning_engine": PlanningEngine,
        }

        for module_name, module_cls in core_modules.items():
            self.registry.register(module_name, module_cls)

        logger.info("核心认知模块注册完成")

    def run(self, debug: bool = True) -> None:
        """启动应用，初始化模块并启动Flask服务。"""
        self._register_core_modules()
        app.run(debug=debug)


if __name__ == "__main__":
    XIMUApplication().run()