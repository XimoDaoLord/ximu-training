"""汐沫AI核心包

统一导出各模块公开接口，方便顶层使用：
    from src.ximu import XimuCore, ModelRouter, MemoryStore, ...
"""
from __future__ import annotations

import importlib
from functools import lru_cache
from typing import Any, Dict, List, Tuple, Optional

# 子包名（惰性加载）
_SUBPACKAGES: Tuple[str, ...] = (
    "core",
    "cognition",
    "agents",
    "common",
    "connectors",
    "security",
    "quality",
    "reliability",
    "performance",
    "deployment",
    "device",
    "data",
    "ui",
    "console",
    "skills",
    "frontier",
    "inference_opt",
    "infrastructure",
    "mcp",
    "services",
)

# 公开类名 -> 所属子包（惰性加载映射）
_SYMBOLS: Dict[str, str] = {
    # 核心运行时
    "TaskClosedLoop": "core",
    "SubtaskExecutor": "core",
    "RedoController": "core",
    "ConfirmPointManager": "core",
    "AggregationDelivery": "core",
    "ModelRouter": "core",
    "MemoryStore": "core",
    "MultimodalFusion": "core",
    "PromptSystem": "core",
    "Registry": "core",
    "Scheduling": "core",
    "Telemetry": "core",
    "TransitPool": "core",
    "VectorStore": "core",
    "Workflow": "core",
    "XimuCore": "core",
    # 认知层
    "AGIEngine": "cognition",
    "CausalReasoning": "cognition",
    "WorldModel": "cognition",
    "EvolutionEngine": "cognition",
    "Brain": "cognition",
    "SimulationEngine": "cognition",
    # 智能体层
    "LLMToolchain": "agents",
    "PluginManager": "agents",
    "SocietyAgent": "agents",
    "ToolRegistry": "agents",
}

# 兼容 from src.ximu import utils / logging_config（common 下的公共工具）
_COMMON_ATTRS: Tuple[str, ...] = ("utils", "logging_config")


def _generate_all() -> List[str]:
    """生成所有公开符号列表。

    Returns:
        包含所有公开符号的列表
    """
    symbols: List[str] = list(_SYMBOLS.keys())
    symbols.extend(_COMMON_ATTRS)
    return symbols


__all__: List[str] = _generate_all()


def lazy_import(name: str) -> Any:
    """惰性导入指定符号到当前模块命名空间。

    Args:
        name: 要导入的符号名称

    Returns:
        导入的对象

    Raises:
        ImportError: 当符号不在 ximu 包中时抛出
    """
    subpackage: Optional[str] = _SYMBOLS.get(name)
    if subpackage:
        module_name: str = f"src.ximu.{subpackage}.{name}"
        module = importlib.import_module(module_name)
        setattr(__import__(__name__), name, getattr(module, name))
        return getattr(module, name)
    raise ImportError(f"{name} not found in the ximu package.")


def __getattr__(name: str) -> Any:
    """PEP 562：按需加载模块属性。

    Args:
        name: 请求的属性名称

    Returns:
        对应的对象

    Raises:
        AttributeError: 当属性不存在时抛出
    """
    if name in _SYMBOLS:
        return lazy_import(name)
    
    if name in _COMMON_ATTRS:
        try:
            from src.ximu.common import __getattr__ as common_attr_getattr
            return common_attr_getattr(name)
        except ImportError:
            pass
    
    raise AttributeError(f"'{__name__}' object has no attribute '{name}'")
