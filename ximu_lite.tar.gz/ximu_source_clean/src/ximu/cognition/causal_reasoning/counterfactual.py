# -*- coding: utf-8 -*-
"""反事实推理引擎：结构因果模型、干预模拟与归因分析。"""

from __future__ import annotations

import copy
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .causal_graph import CausalGraph


@dataclass
class StructuralCausalModel:
    """结构因果模型（SCM）：封装因果图、生成机制及噪声项。"""

    model_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    graph: Optional[CausalGraph] = None
    mechanisms: Dict[str, Any] = field(default_factory=dict)
    noise_terms: Dict[str, str] = field(default_factory=dict)


@dataclass
class CounterfactualQuery:
    """反事实查询：描述假设干预与目标变量。"""

    query_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    hypothetical_action: Dict[str, Any] = field(default_factory=dict)
    target_variable: str = ""
    context: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CounterfactualResult:
    """反事实推理结果：包含观测事实、反事实预测、差异及置信度。"""

    result_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    query: Optional[CounterfactualQuery] = None
    factual_outcome: Any = None
    counterfactual_outcome: Any = None
    difference: Any = None
    confidence: float = 0.0
    nearest_worlds: List[Dict[str, Any]] = field(default_factory=list)
    assumptions: List[str] = field(default_factory=list)
    computed_at: float = field(default_factory=time.time)


@dataclass
class AttributionResult:
    """归因分析结果：解释特定结果中各因素的贡献度。"""

    attribution_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    outcome: str = ""
    factors: List[Dict[str, Any]] = field(default_factory=list)
    total_effect: float = 0.0
    explanation: str = ""


class CounterfactualEngine:
    """反事实推理引擎：实现三步法（abduction → action → prediction）。"""

    def __init__(self) -> None:
        """初始化反事实推理引擎，无需额外状态。"""
        pass

    @staticmethod
    def _estimate_linear_coefficients(
        var: str,
        parents: List[str],
        data: Dict[str, List[float]],
        n: int,
    ) -> Tuple[Dict[str, float], float]:
        """用简化最小二乘估计线性系数和截距。"""
        if n <= 0:
            return {}, 0.0

        y = data.get(var, [])[:n]
        if not y:
            return {}, 0.0

        y_mean = sum(y) / n
        coefficients: Dict[str, float] = {}

        for p in parents:
            x = data.get(p, [])[:n]
            if len(x) < n:
                continue
            x_mean = sum(x) / n
            num = sum((x[i] - x_mean) * (y[i] - y_mean) for i in range(n))
            den = sum((x[i] - x_mean) ** 2 for i in range(n))
            coefficients[p] = num / den if den > 1e-9 else 0.0

        intercept: float = y_mean
        for p in parents:
            p_values = data.get(p, [])[:n]
            p_mean = sum(p_values) / n if p_values else 0.0
            intercept -= coefficients.get(p, 0.0) * p_mean
        return coefficients, intercept

    def build_scm(
        self,
        graph: CausalGraph,
        data: Dict[str, List[float]],
    ) -> StructuralCausalModel:
        """从因果图和数据学习结构因果模型（简化：线性生成机制）。"""
        scm = StructuralCausalModel(graph=graph)
        for var in graph.variables:
            parents = list(graph.parents(var))
            mechanism: Dict[str, Any] = {
                "type": "linear",
                "parents": parents,
                "coefficients": {p: 0.1 for p in parents},
                "intercept": 0.0,
                "noise_std": 1.0,
            }

            if parents and var in data and all(p in data for p in parents):
                n = min(
                    len(data[var]),
                    min(len(data[p]) for p in parents),
                )
                if n > 1:
                    coeff, intercept = self._estimate_linear_coefficients(
                        var, parents, data, n,
                    )
                    mechanism["coefficients"] = coeff
                    mechanism["intercept"] = intercept

            scm.mechanisms[var] = mechanism
            scm.noise_terms[var] = f"N(0, {mechanism['noise_std']})"
        return scm

    def what_if(
        self,
        query: CounterfactualQuery,
        scm: StructuralCausalModel,
        observed: Dict[str, float],
    ) -> CounterfactualResult:
        """反事实推理：如果在观测上下文中做了假设的干预，结果会怎样。"""
        noise = self._estimate_noise(scm, observed)
        modified_scm = self._apply_intervention(scm, query.hypothetical_action)
        counterfactual = self._predict(
            modified_scm, noise, query.target_variable,
        )
        factual = observed.get(query.target_variable)

        diff: Optional[float] = None
        if factual is not None and isinstance(counterfactual, (int, float)):
            diff = float(counterfactual) - float(factual)

        confidence: float = self._estimate_confidence(scm, query.target_variable)
        return CounterfactualResult(
            query=query,
            factual_outcome=factual,
            counterfactual_outcome=counterfactual,
            difference=diff,
            confidence=confidence,
            assumptions=[
                "线性结构因果模型假设",
                "外生噪声正态分布",
                "干预不改变其他变量的生成机制",
            ],
        )

    def why(
        self,
        outcome: str,
        observed: Dict[str, float],
        scm: StructuralCausalModel,
    ) -> AttributionResult:
        """归因分析：为什么会发生这个结果，各因素贡献多少。"""
        if scm.graph is None or outcome not in scm.mechanisms:
            return AttributionResult(
                outcome=outcome,
                explanation="无法归因：缺少SCM或目标变量机制",
            )

        mechanism = scm.mechanisms[outcome]
        parents = mechanism.get("parents", [])
        factors: List[Dict[str, Any]] = []
        total: float = 0.0

        for p in parents:
            coeff = mechanism.get("coefficients", {}).get(p, 0.0)
            value = observed.get(p, 0.0)
            contribution = float(coeff) * float(value)
            total += contribution
            factors.append({
                "factor": p,
                "coefficient": coeff,
                "observed_value": value,
                "contribution": contribution,
                "percentage": 0.0,
            })

        if total != 0:
            for f in factors:
                f["percentage"] = f["contribution"] / total * 100

        factors.sort(key=lambda x: abs(x["contribution"]), reverse=True)

        if factors:
            explanation = (
                f"{outcome}主要由{factors[0]['factor']}驱动"
                f"（贡献{factors[0]['percentage']:.1f}%）"
            )
        else:
            explanation = f"{outcome}无显著驱动因素"

        return AttributionResult(
            outcome=outcome,
            factors=factors,
            total_effect=total,
            explanation=explanation,
        )

    def _estimate_noise(
        self,
        scm: StructuralCausalModel,
        observed: Dict[str, float],
    ) -> Dict[str, float]:
        """估算外生噪声项（残差）。"""
        noise: Dict[str, float] = {}
        if scm.graph is None:
            return noise
        for var in scm.graph.variables:
            if var not in scm.mechanisms:
                continue
            mechanism = scm.mechanisms[var]
            parents = mechanism.get("parents", [])
            predicted = mechanism.get("intercept", 0.0)
            for p in parents:
                coeff = mechanism.get("coefficients", {}).get(p, 0.0)
                predicted += float(coeff) * float(observed.get(p, 0.0))
            actual = observed.get(var, 0.0)
            noise[var] = float(actual) - float(predicted)
        return noise

    def _apply_intervention(
        self,
        scm: StructuralCausalModel,
        intervention: Dict[str, Any],
    ) -> StructuralCausalModel:
        """应用干预：修改指定变量的机制。"""
        modified = StructuralCausalModel(
            graph=scm.graph,
            mechanisms=copy.deepcopy(scm.mechanisms),
            noise_terms=copy.deepcopy(scm.noise_terms),
        )
        for var, value in intervention.items():
            if var in modified.mechanisms:
                modified.mechanisms[var]["type"] = "constant"
                modified.mechanisms[var]["constant"] = float(value)
        return modified

    def _predict(
        self,
        scm: StructuralCausalModel,
        noise: Dict[str, float],
        target: str,
    ) -> Any:
        """预测目标变量的反事实值。"""
        if target not in scm.mechanisms:
            return None
        mechanism = scm.mechanisms[target]
        if mechanism.get("type") == "constant":
            return mechanism.get("constant")
        parents = mechanism.get("parents", [])
        predicted = mechanism.get("intercept", 0.0)
        for p in parents:
            coeff = mechanism.get("coefficients", {}).get(p, 0.0)
            predicted += float(coeff) * float(noise.get(p, 0.0))
        return predicted + noise.get(target, 0.0)

    def _estimate_confidence(
        self,
        scm: StructuralCausalModel,
        target: str,
    ) -> float:
        """估计反事实推理的置信度。"""
        if target not in scm.mechanisms:
            return 0.0
        mechanism = scm.mechanisms[target]
        parents = mechanism.get("parents", [])
        if not parents:
            return 0.5
        coeffs = mechanism.get("coefficients", {})
        if not coeffs:
            return 0.3
        avg_abs: float = sum(abs(v) for v in coeffs.values()) / len(coeffs)
        return min(1.0, max(0.0, avg_abs))

    def _simple_predict(
        self,
        scm: StructuralCausalModel,
        observed: Dict[str, float],
    ) -> Any:
        """简单预测：用于寻找替代世界。"""
        if scm.graph is None:
            return None
        for var in scm.graph.variables:
            if var in scm.mechanisms:
                mechanism = scm.mechanisms[var]
                if mechanism.get("type") == "constant":
                    continue
                parents = mechanism.get("parents", [])
                predicted = mechanism.get("intercept", 0.0)
                for p in parents:
                    coeff = mechanism.get("coefficients", {}).get(p, 0.0)
                    predicted += float(coeff) * float(observed.get(p, 0.0))
                observed[var] = predicted
        return observed.get(list(scm.graph.variables)[-1] if scm.graph.variables else "", None)
