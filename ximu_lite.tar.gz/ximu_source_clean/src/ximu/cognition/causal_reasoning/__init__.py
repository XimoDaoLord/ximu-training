# -*- coding: utf-8 -*-
"""卷32 · 因果推理引擎（阶段311-320）

按需加载因果推理子模块，提供延迟导入优化和统一导出接口。
"""
import importlib as _importlib
import threading as _th
from typing import Any

_load_lock = _th.Lock()

_parts_modules = [
    'discovery', 'effect_estimation', 'counterfactual',
    'causal_graph', 'inference',
]
_parts_loaded: dict[str, Any] = {}


def __getattr__(name: str) -> Any:
    """按需加载子模块属性，支持懒加载优化。

    Args:
        name: 要获取的属性名称。

    Returns:
        对应的模块属性对象。

    Raises:
        AttributeError: 当属性不存在时抛出。
    """
    # P0修复：CausalReasoningEngine别名指向CausalInferenceEngine，保持向后兼容
    if name == "CausalReasoningEngine":
        name = "CausalInferenceEngine"
    for part in _parts_modules:
        if part not in _parts_loaded:
            with _load_lock:
                if part not in _parts_loaded:
                    _parts_loaded[part] = _importlib.import_module(f'.{part}', __name__)
        mod = _parts_loaded[part]
        if hasattr(mod, name):
            return getattr(mod, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "DiscoveryMethod",
    "CausalVariable",
    "CausalRelation",
    "DiscoveryResult",
    "CausalDiscoveryEngine",
    "ConditionalIndependenceTester",
    "PCSkeletonLearner",
    "GESScorer",
    "EstimationMethod",
    "CausalEffectEstimate",
    "CounterfactualQuery",
    "CausalGraph",
    "CausalEffectEngine",
    "HeterogeneityReport",
    "StructuralCausalModel",
    "CounterfactualResult",
    "AttributionResult",
    "CounterfactualEngine",
    "MinimalChangeSet",
    "MultiWorldComparison",
    "CausalPath",
    "CausalGraphEngine",
    "CausalQuery",
    "InferenceReport",
    "InferenceStats",
    "CausalQueryParser",
    "CausalInferenceEngine",
    "CausalReasoningEngine",
]
