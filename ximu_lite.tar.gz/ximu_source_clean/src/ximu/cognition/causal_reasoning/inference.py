"""阶段315 / 卷32收口：因果推理统一引擎。

将因果发现、因果图、效应估计、反事实推理编排为一个统一接口。
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import re
import time
import uuid

from .discovery import CausalVariable, DiscoveryMethod, CausalDiscoveryEngine
from .causal_graph import CausalGraphEngine
from .effect_estimation import CausalEffectEngine, CausalEffectEstimate, CausalGraph
from .counterfactual import StructuralCausalModel, CounterfactualEngine, CounterfactualResult, AttributionResult


@dataclass
class CausalQuery:
    """解析后的因果查询。"""
    query_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    raw_text: str = ""
    query_kind: str = "effect"
    cause: str = ""
    effect: str = ""
    intervention: Dict[str, float] = field(default_factory=dict)
    observed: Dict[str, float] = field(default_factory=dict)
    conditions: Dict[str, float] = field(default_factory=dict)
    parsed_at: float = field(default_factory=time.time)


@dataclass
class InferenceReport:
    """一次完整因果推理的报告。"""
    report_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    query: Optional[CausalQuery] = None
    effect_estimate: Optional[CausalEffectEstimate] = None
    counterfactual: Optional[CounterfactualResult] = None
    attribution: Optional[AttributionResult] = None
    explanation: str = ""
    validation_notes: List[str] = field(default_factory=list)
    elapsed_ms: float = 0.0
    finished_at: float = field(default_factory=time.time)


@dataclass
class InferenceStats:
    """推理统计。"""
    total_queries: int = 0
    by_kind: Dict[str, int] = field(default_factory=dict)
    total_elapsed_ms: float = 0.0
    significant_effects: int = 0
    non_significant_effects: int = 0
    failed_queries: int = 0

    def record(self, report: InferenceReport) -> None:
        """记录一次推理报告

        Args:
            report: 推理报告
        """
        self.total_queries += 1
        kind = report.query.query_kind if report.query else "unknown"
        self.by_kind[kind] = self.by_kind.get(kind, 0) + 1
        self.total_elapsed_ms += report.elapsed_ms
        if report.effect_estimate is not None:
            if report.effect_estimate.is_significant:
                self.significant_effects += 1
            else:
                self.non_significant_effects += 1
        if not report.explanation:
            self.failed_queries += 1


class CausalQueryParser:
    """将自然语言/字典查询解析为结构化CausalQuery。"""

    EFFECT_PATTERNS: List[re.Pattern] = [
        re.compile(r"(?P<cause>[^\s,，对影响导致]+?)\s*(?:对|导致|影响)\s*"
                   r"(?P<effect>[^\s,，的会怎样]+?)(?:的|会|$|影响)"),
    ]
    CF_PATTERN: re.Pattern = re.compile(
        r"如果\s*(?P<var>[^\s=，,=]+)\s*=\s*(?P<val>-?[\d.]+).*?"
        r"(?P<effect>[^\s,，会怎样]+?)(?:会怎样|的|$)"
    )
    ATTR_PATTERN: re.Pattern = re.compile(
        r"(?P<effect>[^\s,，为什么]+?)\s*(?:为什么|归因|原因)"
    )

    def parse(self, text: str) -> CausalQuery:
        """解析自然语言查询文本

        Args:
            text: 查询文本

        Returns:
            解析后的因果查询
        """
        query: CausalQuery = CausalQuery(raw_text=text)
        m = self.CF_PATTERN.search(text)
        if m:
            query.query_kind = "counterfactual"
            query.intervention = {m.group("var"): float(m.group("val"))}
            query.effect = m.group("effect")
            return query
        m = self.ATTR_PATTERN.search(text)
        if m:
            query.query_kind = "attribution"
            query.effect = m.group("effect")
            return query
        for pat in self.EFFECT_PATTERNS:
            m = pat.search(text)
            if m:
                query.query_kind = "effect"
                query.cause = m.group("cause")
                query.effect = m.group("effect")
                return query
        query.query_kind = "unknown"
        return query

    def parse_dict(self, payload: Dict[str, Any]) -> CausalQuery:
        """解析字典格式查询

        Args:
            payload: 查询参数字典

        Returns:
            解析后的因果查询
        """
        return CausalQuery(
            raw_text=str(payload),
            query_kind=payload.get("kind", "effect"),
            cause=payload.get("cause", ""),
            effect=payload.get("effect", ""),
            intervention=payload.get("intervention", {}),
            observed=payload.get("observed", {}),
            conditions=payload.get("conditions", {}),
        )


class CausalInferenceEngine:
    """统一因果推理引擎：编排发现->建图->效应估计->反事实->解释"""

    def __init__(self) -> None:
        """初始化因果推理引擎"""
        self.discovery: CausalDiscoveryEngine = CausalDiscoveryEngine()
        self.graph_engine: CausalGraphEngine = CausalGraphEngine()
        self.effect_engine: CausalEffectEngine = CausalEffectEngine()
        self.cf_engine: CounterfactualEngine = CounterfactualEngine()
        self.parser: CausalQueryParser = CausalQueryParser()
        self.stats: InferenceStats = InferenceStats()
        self._scm: Optional[StructuralCausalModel] = None
        self._data: Dict[str, List[float]] = {}

    def load_data(self, data: Dict[str, List[float]]) -> None:
        """装载观测数据

        Args:
            data: 变量名到观测值列表的映射
        """
        self._data = data

    def build_model(self, method: DiscoveryMethod = DiscoveryMethod.PC_ALGORITHM) -> Dict[str, Any]:
        """从已装载数据自动发现并构建因果模型

        Args:
            method: 发现方法

        Returns:
            模型构建结果
        """
        variables: List[CausalVariable] = [
            CausalVariable(name=name, data=list(col)) for name, col in self._data.items()
        ]
        if method == DiscoveryMethod.PC_ALGORITHM and len(variables) <= 8:
            from .discovery import PCSkeletonLearner
            learner = PCSkeletonLearner(alpha=0.1, max_cond_set=1)
            result = learner.learn_skeleton(variables, self._data)
        else:
            result = self.discovery.discover_from_observational(variables, method=method)
        for v in variables:
            self.graph_engine.add_variable(v)
        for rel in result.relations:
            self.graph_engine.add_relation(rel)
        eg: CausalGraph = CausalGraph(variables=list(self._data.keys()))
        for rel in result.relations:
            eg.add_edge(rel.cause, rel.effect)
        self._scm = self.cf_engine.build_scm(eg, self._data)
        return {
            "variables": len(variables),
            "relations": len(result.relations),
            "graph_stats": self.graph_engine.get_stats(),
        }

    def infer(self, raw_query: Any) -> InferenceReport:
        """执行因果推理

        Args:
            raw_query: 原始查询（文本或字典）

        Returns:
            推理报告
        """
        start_time: float = time.perf_counter()
        report: InferenceReport = InferenceReport()
        query: CausalQuery = self._parse_query(raw_query)
        report.query = query
        if query.query_kind == "effect":
            self._do_effect(query, report)
        elif query.query_kind == "counterfactual":
            self._do_counterfactual(query, report)
        elif query.query_kind == "attribution":
            self._do_attribution(query, report)
        else:
            report.explanation = f"无法识别的查询类型: {query.query_kind}"
        report.elapsed_ms = (time.perf_counter() - start_time) * 1000
        self.stats.record(report)
        return report

    def _parse_query(self, raw: Any) -> CausalQuery:
        """解析查询输入（文本或字典）

        Args:
            raw: 原始查询

        Returns:
            解析后的查询
        """
        if isinstance(raw, str):
            return self.parser.parse(raw)
        if isinstance(raw, dict):
            return self.parser.parse_dict(raw)
        return CausalQuery(query_kind="unknown")

    def _do_effect(self, q: CausalQuery, report: InferenceReport) -> None:
        """执行效应查询

        Args:
            q: 因果查询
            report: 推理报告
        """
        report.effect_estimate = self._run_effect(q)
        if report.effect_estimate and self._scm:
            report.explanation = self.effect_engine.explain_effect(
                report.effect_estimate, self._scm.graph
            )
        report.validation_notes.extend(self._validate_effect(report.effect_estimate))

    def _do_counterfactual(self, q: CausalQuery, report: InferenceReport) -> None:
        """执行反事实查询

        Args:
            q: 因果查询
            report: 推理报告
        """
        if not self._scm:
            report.explanation = "尚未构建因果模型，请先调用 build_model()"
            return
        report.counterfactual = self.cf_engine.query_counterfactual(
            self._scm, q.intervention, q.observed, q.effect
        )
        if report.counterfactual:
            report.explanation = f"反事实结果: {report.counterfactual.outcome}"

    def _do_attribution(self, q: CausalQuery, report: InferenceReport) -> None:
        """执行归因查询

        Args:
            q: 因果查询
            report: 推理报告
        """
        if not self._scm:
            report.explanation = "尚未构建因果模型，请先调用 build_model()"
            return
        report.attribution = self.cf_engine.compute_attribution(
            self._scm, q.effect, q.conditions
        )
        if report.attribution:
            report.explanation = f"归因结果: 主要致因为 {report.attribution.primary_cause}"

    def _run_effect(self, q: CausalQuery) -> Optional[CausalEffectEstimate]:
        """执行效应估计计算

        Args:
            q: 因果查询

        Returns:
            效应估计结果
        """
        if not self._scm:
            return None
        return self.effect_engine.estimate_causal_effect(
            self._scm.graph,
            q.cause,
            q.effect,
            adjustment=q.conditions,
        )

    def _validate_effect(self, estimate: Optional[CausalEffectEstimate]) -> List[str]:
        """验证效应估计结果的合理性

        Args:
            estimate: 效应估计结果

        Returns:
            验证备注列表
        """
        notes: List[str] = []
        if estimate is None:
            notes.append("效应估计为空，可能是变量不存在于模型中")
            return notes
        if estimate.p_value < 0.05:
            notes.append(f"统计显著 (p={estimate.p_value:.4f})")
        else:
            notes.append(f"统计不显著 (p={estimate.p_value:.4f})")
        return notes
