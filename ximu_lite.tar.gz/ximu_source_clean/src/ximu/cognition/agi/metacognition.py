# -*- coding: utf-8 -*-
"""元认知模块：思考过程监控、策略选择、认知偏差检测。"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class CognitiveStrategy:
    """认知策略数据类。"""
    name: str = ""
    description: str = ""
    success_count: int = 0
    fail_count: int = 0
    avg_latency_ms: float = 0.0


@dataclass
class BiasDetection:
    """偏差检测数据类。"""
    bias_type: str = ""
    severity: float = 0.0
    description: str = ""
    detected_at: float = field(default_factory=time.time)


class Metacognition:
    """元认知模块。"""

    def __init__(self) -> None:
        """初始化元认知模块。"""
        self._strategies: Dict[str, CognitiveStrategy] = {}
        self._bias_history: List[BiasDetection] = []
        self._thought_log: List[Dict[str, Any]] = []
        self._register_default_strategies()

    def _register_default_strategies(self) -> None:
        """注册默认推理策略。"""
        strategies = [("deductive", "演绎推理"), ("inductive", "归纳推理"),
                    ("analogical", "类比推理"), ("abductive", "溯因推理")]
        for name, desc in strategies:
            self._strategies[name] = CognitiveStrategy(name=name, description=desc)

    def select_strategy(self, problem_type: str) -> str:
        """选择最优策略。"""
        scores = {name: s.success_count - s.fail_count for name, s in self._strategies.items()}
        if problem_type == "generalization":
            scores["inductive"] += 2
        elif problem_type == "formal":
            scores["deductive"] += 2
        elif problem_type == "cross_domain":
            scores["analogical"] += 2
        return max(scores, key=scores.get)

    def record_thought(self, strategy: str, problem: str, success: bool, latency_ms: float = 0.0) -> None:
        """记录思考过程。"""
        s = self._strategies.get(strategy)
        if s:
            if success:
                s.success_count += 1
            else:
                s.fail_count += 1
            total = s.success_count + s.fail_count
            s.avg_latency_ms = ((s.avg_latency_ms * (total - 1) + latency_ms) / total) if total else 0.0
        self._thought_log.append({"strategy": strategy, "problem": problem, "success": success, "ts": time.time()})

    def detect_bias(self, reasoning_steps: List[str], conclusion: str) -> List[BiasDetection]:
        """检测认知偏差。"""
        detections: List[BiasDetection] = []
        if len(set(reasoning_steps)) < len(reasoning_steps) * 0.6:
            detections.append(BiasDetection(bias_type="confirmation_bias", severity=0.5, description="推理步骤重复"))
        if len(reasoning_steps) < 3 and len(conclusion) > 50:
            detections.append(BiasDetection(bias_type="premature_conclusion", severity=0.7, description="推理步骤过少"))
        self._bias_history.extend(detections)
        return detections

    def get_metacognition_stats(self) -> Dict[str, Any]:
        """获取元认知统计信息。"""
        total_thoughts = len(self._thought_log)
        successes = sum(1 for t in self._thought_log if t["success"])
        return {
            "total_thoughts": total_thoughts,
            "success_rate": successes / total_thoughts if total_thoughts else 0.0,
            "strategies": {name: {"success": s.success_count, "fail": s.fail_count} for name, s in self._strategies.items()},
            "bias_detections": len(self._bias_history)
        }