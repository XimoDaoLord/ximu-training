# -*- coding: utf-8 -*-
"""通用推理能力模块，支持跨领域推理、类比迁移与抽象概括。"""
from __future__ import annotations

import re
import time
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def _cn_tokenize(text: str) -> List[str]:
    """统一中文分词口径。"""
    try:
        from src.ximu.core.memory.memory_engine import tokenize_keywords as _tk
        return _tk(text)
    except ImportError:
        logger.debug("memory_engine not available, falling back to regex-based tokenizer")
    except Exception as e:
        logger.warning("Failed to import tokenize_keywords, falling back to regex-based tokenizer: %s", e)

    if not text:
        return []

    t = str(text).lower()
    toks: set = set()

    for w in re.findall(r'[a-z0-9]+', t):
        if w:
            toks.add(w)

    for seg in re.findall(r'[\u4e00-\u9fff]+', t):
        if len(seg) == 1:
            toks.add(seg)
        else:
            for i in range(len(seg) - 1):
                toks.add(seg[i:i + 2])
            for ch in seg:
                toks.add(ch)

    return list(toks)


@dataclass
class ReasoningResult:
    """推理结果数据类。"""
    conclusion: str = ""
    confidence: float = 0.0
    reasoning_steps: List[str] = field(default_factory=list)
    abstract_pattern: str = ""
    transferred: bool = False
    reasoned_at: float = field(default_factory=time.time)


class GeneralReasoningEngine:
    """通用推理引擎。"""

    def __init__(self) -> None:
        """初始化通用推理引擎。"""
        self._domain_knowledge: Dict[str, Dict[str, Any]] = {}
        self._abstract_patterns: Dict[str, List[str]] = {}
        self._reasoning_history: List[ReasoningResult] = []

    def add_domain_knowledge(self, domain: str, facts: Dict[str, Any]) -> None:
        """添加领域知识。"""
        if not domain:
            raise ValueError("domain must be a non-empty string")
        if not isinstance(facts, dict):
            raise TypeError("facts must be a dictionary")
        self._domain_knowledge.setdefault(domain, {}).update(facts)

    def reason(self, problem: str, domain: Optional[str] = None) -> ReasoningResult:
        """对给定问题进行推理。"""
        if not problem or not problem.strip():
            raise ValueError("problem must be a non-empty string")

        steps: List[str] = []
        truncated = problem[:50] + ("..." if len(problem) > 50 else "")
        steps.append(f"分析问题: {truncated}")

        knowledge: Dict[str, Any] = {}
        if domain:
            if domain not in self._domain_knowledge:
                logger.debug("Domain '%s' not found in knowledge base", domain)
            knowledge = self._domain_knowledge.get(domain, {})

        pattern = self._abstract_pattern(problem, knowledge)
        steps.append(f"提取抽象模式: {pattern}")

        if knowledge:
            relevant = [f"{k}={v}" for k, v in list(knowledge.items())[:3]]
            steps.append(f"相关知识: {'; '.join(relevant)}")

        confidence = min(0.95, 0.5 + len(knowledge) * 0.1 + len(pattern) * 0.01)

        result = ReasoningResult(
            conclusion=f"基于模式'{pattern}'推理得出的结论",
            confidence=confidence,
            reasoning_steps=steps,
            abstract_pattern=pattern,
        )
        self._reasoning_history.append(result)
        return result

    def transfer(self, src_domain: str, tgt_domain: str, knowledge_key: str) -> Optional[ReasoningResult]:
        """将知识从一个领域迁移到另一个领域。"""
        if not src_domain or not tgt_domain or not knowledge_key:
            raise ValueError("src_domain, tgt_domain, and knowledge_key must all be non-empty strings")

        src_knowledge = self._domain_knowledge.get(src_domain)
        if src_knowledge is None:
            logger.debug("Source domain '%s' not found", src_domain)
            return None

        if knowledge_key not in src_knowledge:
            logger.debug("Knowledge key '%s' not found in domain '%s'", knowledge_key, src_domain)
            return None

        value = src_knowledge[knowledge_key]
        self._domain_knowledge.setdefault(tgt_domain, {})[knowledge_key] = value

        result = ReasoningResult(
            conclusion=f"将{src_domain}的'{knowledge_key}'迁移到{tgt_domain}",
            confidence=0.7,
            reasoning_steps=[
                f"源领域知识: {knowledge_key}={value}",
                f"迁移到目标领域: {tgt_domain}",
            ],
            abstract_pattern=f"{src_domain}->{tgt_domain}:{knowledge_key}",
            transferred=True,
        )
        self._reasoning_history.append(result)
        return result

    def _abstract_pattern(self, problem: str, knowledge: Dict[str, Any]) -> str:
        """提取问题的抽象模式。"""
        keywords = [w for w in _cn_tokenize(problem) if len(w) > 2]
        pattern_parts: List[str] = []

        if "因果" in problem or "因为" in problem:
            pattern_parts.append("causal_chain")
        if "类比" in problem or "如同" in problem:
            pattern_parts.append("analogical_mapping")

        if keywords:
            pattern_parts.append("_".join(keywords[:3]))

        return "_".join(pattern_parts) if pattern_parts else "generic_pattern"

    def get_reasoning_stats(self) -> Dict[str, Any]:
        """获取推理统计信息。"""
        total = len(self._reasoning_history)
        if total == 0:
            return {
                "total_reasonings": 0,
                "transfers": 0,
                "avg_confidence": 0.0,
                "domains_covered": list(self._domain_knowledge.keys()),
            }

        transferred = sum(1 for r in self._reasoning_history if r.transferred)
        avg_conf = sum(r.confidence for r in self._reasoning_history) / total

        return {
            "total_reasonings": total,
            "transfers": transferred,
            "avg_confidence": avg_conf,
            "domains_covered": list(self._domain_knowledge.keys()),
        }