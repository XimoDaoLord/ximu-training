# -*- coding: utf-8 -*-
"""卷39 · AGI演进路径（阶段381-390）

按需加载AGI相关子模块，提供延迟导入优化和统一导出接口。
"""
import importlib as _importlib
import threading as _threading
from typing import Any

_parts_modules = [
    'agi_evolution', 'self_awareness', 'metacognition', 'general_reasoning',
]
_parts_loaded: dict[str, Any] = {}
_parts_lock = _threading.Lock()


def __getattr__(name: str) -> Any:
    """按需加载子模块属性，支持线程安全的懒加载。

    Args:
        name: 要获取的属性名称。

    Returns:
        对应的模块属性对象。

    Raises:
        AttributeError: 当属性不存在时抛出。
    """
    for part in _parts_modules:
        mod = _parts_loaded.get(part)
        if mod is None:
            with _parts_lock:
                # 双重检查：锁内再查一次，避免重复加载
                mod = _parts_loaded.get(part)
                if mod is None:
                    mod = _importlib.import_module(f'.{part}', __name__)
                    _parts_loaded[part] = mod
        if hasattr(mod, name):
            return getattr(mod, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "AGICapabilityDimension", "AGICapabilityProfile", "EvolutionMilestone",
    "AGIEvolutionEngine",
    "SelfModel", "IntrospectionResult", "SelfAwareness",
    "CognitiveStrategy", "BiasDetection", "Metacognition",
    "ReasoningResult", "GeneralReasoningEngine",
]
