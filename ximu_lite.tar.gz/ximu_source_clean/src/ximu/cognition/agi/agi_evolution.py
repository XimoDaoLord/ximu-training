# -*- coding: utf-8 -*-
"""AGI演进引擎模块，用于能力评估、路径规划与里程碑管理。"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List


class AGICapabilityDimension(Enum):
    """AGI能力维度枚举，定义评估体系中的核心能力类别。"""
    GENERAL_REASONING = "general_reasoning"
    TRANSFER_LEARNING = "transfer_learning"
    CONTINUAL_LEARNING = "continual_learning"
    AUTONOMOUS_GOAL = "autonomous_goal_setting"
    SELF_REFLECTION = "self_reflection"
    CREATIVITY = "creativity"
    COMMONSENSE = "commonsense_reasoning"
    LANGUAGE = "language_understanding"
    PLANNING = "planning_decision"
    SOCIAL_COGNITION = "social_cognition"


@dataclass
class AGICapabilityProfile:
    """AGI能力评估档案，记录单次评估的分数、阶段与优劣势。"""
    profile_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    scores: Dict[str, float] = field(default_factory=dict)
    overall_score: float = 0.0
    stage: str = ""
    assessed_at: float = field(default_factory=time.time)
    strengths: List[str] = field(default_factory=list)
    weaknesses: List[str] = field(default_factory=list)


@dataclass
class EvolutionMilestone:
    """演进里程碑，描述目标维度、目标分数及达成状态。"""
    name: str = ""
    target_dimensions: List[str] = field(default_factory=list)
    target_score: float = 0.0
    achieved: bool = False
    achieved_at: float = 0.0


class AGIEvolutionEngine:
    """AGI演进引擎，负责能力评估、路径规划、里程碑管理。"""

    def __init__(self, avg_threshold: float = 7.0, floor_threshold: float = 5.0) -> None:
        """初始化AGI演进引擎。"""
        self._avg_threshold: float = avg_threshold
        self._floor_threshold: float = floor_threshold
        self._milestones: List[EvolutionMilestone] = []
        self._history: List[AGICapabilityProfile] = []

    def assess_capability(self, scores: Dict[str, float]) -> AGICapabilityProfile:
        """评估当前能力水平，生成AGI能力档案。"""
        if not scores:
            raise ValueError("能力分数字典不能为空")
        
        profile = AGICapabilityProfile(scores=dict(scores))
        vals: List[float] = list(scores.values())
        profile.overall_score = sum(vals) / len(vals)
        
        sorted_dims: List[tuple] = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        profile.strengths = [d for d, _ in sorted_dims[:3]]
        profile.weaknesses = [d for d, _ in sorted_dims[-3:]]
        
        if profile.overall_score >= 8.5:
            profile.stage = "AGI_NEAR"
        elif profile.overall_score >= 6.0:
            profile.stage = "ADVANCED"
        elif profile.overall_score >= 3.5:
            profile.stage = "INTERMEDIATE"
        else:
            profile.stage = "EARLY"

        self._history.append(profile)
        return profile

    def is_agi(self, profile: AGICapabilityProfile) -> bool:
        """判断给定能力档案是否达到AGI标准。"""
        vals: List[float] = list(profile.scores.values())
        if not vals:
            return False
        return (
            sum(vals) / len(vals) >= self._avg_threshold
            and min(vals) >= self._floor_threshold
        )

    def compare_profiles(
        self, p1: AGICapabilityProfile, p2: AGICapabilityProfile
    ) -> Dict[str, float]:
        """对比两个能力档案在各维度上的得分差异。"""
        return {
            dim.value: p2.scores.get(dim.value, 0.0) - p1.scores.get(dim.value, 0.0)
            for dim in AGICapabilityDimension
        }

    def plan_next_milestone(self, profile: AGICapabilityProfile) -> EvolutionMilestone:
        """基于当前能力档案规划下一个演进里程碑。"""
        if not profile.scores:
            raise ValueError("能力档案无有效分数，无法规划里程碑")

        weak_dim: tuple = min(profile.scores.items(), key=lambda x: x[1])
        milestone = EvolutionMilestone(
            name=f"提升{weak_dim[0]}至{self._floor_threshold}",
            target_dimensions=[weak_dim[0]],
            target_score=self._floor_threshold,
        )
        self._milestones.append(milestone)
        return milestone

    def register_milestone(self, milestone: EvolutionMilestone) -> None:
        """注册自定义演进里程碑。"""
        self._milestones.append(milestone)

    def check_milestones(self, profile: AGICapabilityProfile) -> List[Dict[str, Any]]:
        """检查所有已注册里程碑的达成状态与进度。"""
        results: List[Dict[str, Any]] = []
        for m in self._milestones:
            achieved: bool = (
                all(
                    profile.scores.get(d, 0.0) >= m.target_score
                    for d in m.target_dimensions
                )
                if m.target_dimensions
                else False
            )

            if achieved and not m.achieved:
                m.achieved = True
                m.achieved_at = time.time()

            if m.target_dimensions and m.target_score > 0:
                progress: float = min(
                    profile.scores.get(d, 0.0) / m.target_score
                    for d in m.target_dimensions
                )
            else:
                progress = 0.0

            results.append({
                "name": m.name,
                "achieved": m.achieved,
                "progress": progress,
            })
        return results

    def get_evolution_stats(self) -> Dict[str, Any]:
        """获取演进统计信息。"""
        return {
            "profiles_recorded": len(self._history),
            "milestones": len(self._milestones),
            "milestones_achieved": sum(1 for m in self._milestones if m.achieved),
            "latest_stage": self._history[-1].stage if self._history else "NONE",
        }