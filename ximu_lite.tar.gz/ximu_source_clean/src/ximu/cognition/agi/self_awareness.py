# -*- coding: utf-8 -*-
"""自我意识模块：自我模型维护、内省、能力边界认知。"""
from __future__ import annotations

import time
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class SelfModel:
    """系统自我模型。"""
    known_capabilities: Dict[str, float] = field(default_factory=dict)
    known_limits: List[str] = field(default_factory=list)
    confidence_level: float = 0.5
    last_introspect: float = 0.0


@dataclass
class IntrospectionResult:
    """内省结果。"""
    thought_process: str = ""
    identified_biases: List[str] = field(default_factory=list)
    uncertainty_areas: List[str] = field(default_factory=list)
    introspected_at: float = field(default_factory=time.time)


class SelfAwareness:
    """自我意识模块。"""

    def __init__(self) -> None:
        """初始化自我意识模块。"""
        self._model = SelfModel()
        self._introspection_history: List[IntrospectionResult] = []
        self._capability_bounds: Dict[str, Tuple[float, float]] = {}
        self._lock = threading.Lock()

    def update_capability(self, domain: str, score: float) -> None:
        """更新能力评分。"""
        self._model.known_capabilities[domain] = score
        with self._lock:
            if domain not in self._capability_bounds:
                self._capability_bounds[domain] = (score, score)
            else:
                lo, hi = self._capability_bounds[domain]
                self._capability_bounds[domain] = (min(lo, score), max(hi, score))

    def know_limit(self, limit: str) -> None:
        """记录已知限制。"""
        if limit not in self._model.known_limits:
            self._model.known_limits.append(limit)

    def introspect(self, task_description: str, thought_trace: Optional[List[str]] = None) -> IntrospectionResult:
        """执行内省分析。"""
        biases: List[str] = []
        uncertainties: List[str] = []
        trace = thought_trace or []
        if len(set(trace)) < len(trace) * 0.5:
            biases.append("重复思考路径过多")
        weak_domains = [d for d, s in self._model.known_capabilities.items() if s < 3.0]
        for wd in weak_domains:
            uncertainties.append(f"在{wd}领域能力不足")
        self._model.confidence_level = 1.0 - len(uncertainties) * 0.15
        self._model.last_introspect = time.time()
        result = IntrospectionResult(thought_process=f"分析{task_description}", identified_biases=biases, uncertainty_areas=uncertainties)
        self._introspection_history.append(result)
        return result

    def can_handle(self, domain: str, difficulty: float = 0.5) -> bool:
        """判断是否能处理指定领域任务。"""
        score = self._model.known_capabilities.get(domain, 0.0)
        return score >= difficulty * 5.0

    def get_self_model(self) -> SelfModel:
        """获取自我模型副本。"""
        return SelfModel(known_capabilities=dict(self._model.known_capabilities), known_limits=list(self._model.known_limits), confidence_level=self._model.confidence_level, last_introspect=self._model.last_introspect)

    def get_awareness_stats(self) -> Dict[str, Any]:
        """获取自我意识统计。"""
        return {"known_domains": len(self._model.known_capabilities), "known_limits": len(self._model.known_limits), "confidence": self._model.confidence_level, "introspections": len(self._introspection_history)}