import json
import time
import uuid
import os
from enum import Enum
from typing import Dict, List, Callable, Optional, Any
from dataclasses import dataclass, field


class SimulationDomain(Enum):
    """模拟领域枚举"""
    PHYSICAL = "physical"
    SOCIAL = "social"
    ECONOMIC = "economic"
    ECOLOGICAL = "ecological"
    MULTI_AGENT = "multi_agent"
    MILITARY = "military"
    TRAFFIC = "traffic"
    HYBRID = "hybrid"
    GENERAL = "general"


@dataclass
class SimulationConfig:
    """模拟配置"""
    config_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    max_steps: int = 1000
    time_step: float = 1.0
    random_seed: Optional[int] = 42
    record_history: bool = True
    parallel_agents: bool = False
    real_time_factor: float = 1.0
    max_execution_seconds: float = 60.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SimulationState:
    """模拟状态"""
    state_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    step: int = 0
    time: float = 0.0
    agent_states: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    environment_state: Dict[str, Any] = field(default_factory=dict)
    events: List[Dict[str, Any]] = field(default_factory=list)
    metrics: Dict[str, float] = field(default_factory=dict)
    terminated: bool = False
    termination_reason: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """将状态对象转换为字典表示"""
        return {
            "state_id": self.state_id,
            "step": self.step,
            "time": self.time,
            "agent_states": self.agent_states,
            "environment_state": self.environment_state,
            "events": self.events,
            "metrics": self.metrics,
            "terminated": self.terminated,
            "termination_reason": self.termination_reason,
        }

    def record_metric(self, key: str, value: float) -> None:
        """记录一个指标值"""
        self.metrics[key] = float(value)

    def get_metric(self, key: str, default: float = 0.0) -> float:
        """获取指标值"""
        return float(self.metrics.get(key, default))


@dataclass
class SimulationScenario:
    """模拟场景"""
    scenario_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    domain: SimulationDomain = SimulationDomain.GENERAL
    config: SimulationConfig = field(default_factory=SimulationConfig)
    initial_state: Optional[SimulationState] = None
    agents: List[Dict[str, Any]] = field(default_factory=list)
    rules: List[Callable] = field(default_factory=list)
    termination_conditions: List[Callable] = field(default_factory=list)
    metrics_to_track: List[str] = field(default_factory=list)
    history: List[SimulationState] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    @staticmethod
    def _check_agent_ids(agents: List[Dict[str, Any]]) -> List[str]:
        """检查智能体ID唯一性"""
        errors: List[str] = []
        seen_ids: set = set()
        for idx, ag in enumerate(agents):
            aid = ag.get("agent_id") or ag.get("id") or f"agent_{idx}"
            if aid in seen_ids:
                errors.append(f"智能体ID重复: {aid}")
            seen_ids.add(aid)
        return errors

    def validate(self) -> List[str]:
        """验证场景完整性"""
        errors: List[str] = []
        if not self.name:
            errors.append("场景名称不能为空")
        if self.config.max_steps <= 0:
            errors.append("max_steps 必须大于0")
        if self.config.time_step <= 0:
            errors.append("time_step 必须大于0")
        if self.initial_state is None:
            errors.append("初始状态未设置")
        if not self.agents:
            errors.append("场景至少需要一个智能体")
        if not self.termination_conditions:
            errors.append("场景至少需要一个终止条件（否则可能无限运行）")
        errors.extend(self._check_agent_ids(self.agents))
        return errors


class ScenarioBuilder:
    """场景构建器"""
    __slots__ = ('_scenarios',)

    def __init__(self) -> None:
        """初始化场景构建器"""
        self._scenarios: Dict[str, SimulationScenario] = {}

    def create_scenario(
        self,
        name: str,
        domain: SimulationDomain,
        config: Optional[SimulationConfig] = None,
        description: str = "",
        tags: Optional[List[str]] = None
    ) -> SimulationScenario:
        """创建模拟场景"""
        scenario = SimulationScenario(
            name=name,
            domain=domain,
            description=description or f"{domain.value}模拟场景",
            config=config or SimulationConfig(),
            tags=tags or [],
            metrics_to_track=["step", "time", "alive_agents", "total_events"],
        )
        self._scenarios[name] = scenario
        return scenario

    def set_initial_state(self, scenario: SimulationScenario, state: SimulationState) -> None:
        """设置场景的初始状态"""
        scenario.initial_state = state

    def add_agent(self, scenario: SimulationScenario, agent_spec: Dict[str, Any]) -> None:
        """添加智能体到场景"""
        if "agent_id" not in agent_spec:
            agent_spec["agent_id"] = f"agent_{len(scenario.agents)}"

        scenario.agents.append(agent_spec)

        if scenario.initial_state is None:
            return

        agent_id = agent_spec["agent_id"]
        existing = scenario.initial_state.agent_states.get(agent_id, {})
        merged: Dict[str, Any] = {
            "type": agent_spec.get("type", existing.get("type", "generic")),
            "alive": existing.get("alive", True),
        }
        merged.update(existing)
        merged.update(agent_spec.get("initial_state", {}))
        scenario.initial_state.agent_states[agent_id] = merged

    def add_rule(self, scenario: SimulationScenario, rule: Callable[[SimulationState], None]) -> None:
        """添加模拟规则"""
        scenario.rules.append(rule)

    def add_termination_condition(self, scenario: SimulationScenario, condition: Callable[[SimulationState], bool]) -> None:
        """添加终止条件"""
        scenario.termination_conditions.append(condition)

    def validate_scenario(self, scenario: SimulationScenario) -> List[str]:
        """验证场景完整性"""
        return scenario.validate()

    def save_scenario(self, scenario: SimulationScenario, path: str) -> None:
        """保存场景到 JSON 文件"""
        data = {
            "scenario_id": scenario.scenario_id,
            "name": scenario.name,
            "description": scenario.description,
            "domain": scenario.domain.value,
            "tags": scenario.tags,
            "metrics_to_track": scenario.metrics_to_track,
            "agents": scenario.agents,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
