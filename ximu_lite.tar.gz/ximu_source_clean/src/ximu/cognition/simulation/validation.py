# -*- coding: utf-8 -*-
"""
卷33 · 模拟与推演引擎（阶段329）
- 模拟验证与安全：模型验证、结果验证、敏感性分析、极端案例测试、可信度评分
- 蓝图接口：validate_model / validate_results / sensitivity_analysis /
            extreme_case_test / rate_credibility
"""
from __future__ import annotations

import copy
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from .scenario import SimulationScenario
from .engine import EngineResult, SimulationEngine
from .monte_carlo import MonteCarloRunner


@dataclass
class ValidationReport:
    """验证报告数据类

    Attributes:
        report_id: 报告唯一标识
        model_valid: 模型是否有效
        result_valid: 结果是否有效
        issues: 问题列表
        passed_checks: 通过的检查项列表
        failed_checks: 失败的检查项列表
        credibility_score: 可信度评分 [0, 1]
    """
    report_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    model_valid: bool = False
    result_valid: bool = False
    issues: List[str] = field(default_factory=list)
    passed_checks: List[str] = field(default_factory=list)
    failed_checks: List[str] = field(default_factory=list)
    credibility_score: float = 0.0


@dataclass
class SensitivityEntry:
    """单参数敏感性条目数据类

    Attributes:
        parameter: 参数名称
        base_value: 基准值
        mean_low: 扰动下限均值
        mean_high: 扰动上限均值
        elasticity: 弹性系数
    """
    parameter: str = ""
    base_value: float = 0.0
    mean_low: float = 0.0
    mean_high: float = 0.0
    elasticity: float = 0.0


@dataclass
class SensitivityReport:
    """敏感性分析报告数据类

    Attributes:
        report_id: 报告唯一标识
        entries: 敏感性条目列表
        most_sensitive: 最敏感参数名称
    """
    report_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    entries: List[SensitivityEntry] = field(default_factory=list)
    most_sensitive: str = ""


@dataclass
class ExtremeCaseResult:
    """极端案例测试结果数据类

    Attributes:
        case_name: 案例名称
        survived: 是否存活
        output_bounds_ok: 输出是否在合理范围内
        notes: 备注信息
    """
    case_name: str = ""
    survived: bool = False
    output_bounds_ok: bool = False
    notes: str = ""


class SimulationValidator:
    """模拟验证与安全验证器

    原则："所有模型都是错的，但有些是有用的"——
    我们不追求完美，只追求明确的适用范围和边界。

    Attributes:
        engine: 模拟引擎实例
    """

    def __init__(self, engine: Optional[SimulationEngine] = None) -> None:
        """初始化验证器。

        Args:
            engine: 模拟引擎实例，若为 None 则创建默认实例。
        """
        self.engine = engine or SimulationEngine()

    def validate_model(self, scenario: SimulationScenario) -> ValidationReport:
        """验证模型实现是否正确。

        Args:
            scenario: 要验证的模拟场景。

        Returns:
            验证报告。
        """
        report = ValidationReport()
        self._validate_scenario(scenario, report)
        self._validate_reproducibility(scenario, report)
        self._validate_termination_protection(scenario, report)
        report.model_valid = len(report.failed_checks) == 0
        return report

    def _validate_scenario(self, scenario: SimulationScenario, report: ValidationReport) -> None:
        """验证场景结构完整性。

        Args:
            scenario: 模拟场景
            report: 验证报告
        """
        errors = scenario.validate()
        if errors:
            report.failed_checks.extend(f"场景问题: {e}" for e in errors)
        else:
            report.passed_checks.append("场景结构完整")

    def _validate_reproducibility(self, scenario: SimulationScenario,
                                   report: ValidationReport) -> None:
        """验证模型可复现性。

        Args:
            scenario: 模拟场景
            report: 验证报告
        """
        try:
            r1 = self.engine.run(copy.deepcopy(scenario))
            r2 = self.engine.run(copy.deepcopy(scenario))
            if r1.success and r2.success and r1.total_steps == r2.total_steps:
                report.passed_checks.append("可复现性（同种子同结果）")
            else:
                report.failed_checks.append(
                    f"可复现性失败：run1={r1.total_steps} run2={r2.total_steps}"
                )
        except Exception as exc:
            report.failed_checks.append(f"模型运行异常: {exc}")

    def _validate_termination_protection(self, scenario: SimulationScenario,
                                          report: ValidationReport) -> None:
        """验证终止条件保护。

        Args:
            scenario: 模拟场景
            report: 验证报告
        """
        if not scenario.termination_conditions and scenario.config.max_steps <= 0:
            report.failed_checks.append("无终止保护，可能无限运行")
        else:
            report.passed_checks.append("存在终止保护")

    @staticmethod
    def _check_finite_values(result: EngineResult, report: ValidationReport) -> None:
        """检查指标是否为有限数值。

        Args:
            result: 模拟结果
            report: 验证报告
        """
        non_finite = []
        for k, v in result.final_state.metrics.items():
            if v != v or v in (float("inf"), float("-inf")):
                non_finite.append(k)
        if non_finite:
            report.failed_checks.append(f"指标出现非有限值: {non_finite}")
        else:
            report.passed_checks.append("所有指标为有限数值")

    @staticmethod
    def _check_bounds(result: EngineResult, expected_bounds: Dict[str, Tuple[float, float]],
                      report: ValidationReport) -> None:
        """检查指标是否在预期范围内。

        Args:
            result: 模拟结果
            expected_bounds: 期望范围 {指标名: (下限, 上限)}
            report: 验证报告
        """
        out_of_bounds = []
        for k, (lo, hi) in expected_bounds.items():
            v = result.final_state.metrics.get(k)
            if v is None:
                report.failed_checks.append(f"缺少指标{k}")
            elif not (lo <= v <= hi):
                out_of_bounds.append(f"{k}={v}越界[{lo},{hi}]")
        if out_of_bounds:
            report.failed_checks.extend(out_of_bounds)
        else:
            report.passed_checks.append("所有指标落在预期区间")

    def validate_results(self, result: EngineResult,
                         expected_bounds: Optional[Dict[str, Tuple[float, float]]] = None
                         ) -> ValidationReport:
        """验证结果是否落在合理范围。

        Args:
            result: 模拟结果。
            expected_bounds: 各指标的期望范围。

        Returns:
            验证报告。
        """
        report = ValidationReport()
        if not result.success:
            report.failed_checks.append(f"模拟未成功: {result.error_message}")
            return report
        if result.final_state is None:
            report.failed_checks.append("无最终状态")
            return report
        report.passed_checks.append("模拟成功完成")
        self._check_finite_values(result, report)
        if expected_bounds:
            self._check_bounds(result, expected_bounds, report)
        report.result_valid = not report.failed_checks
        return report

    def sensitivity_analysis(
        self,
        scenario_template: SimulationScenario,
        parameters: Dict[str, float],
        perturb_ratio: float = 0.1,
        samples_per_point: int = 10,
        metric_extractor: Optional[Callable[[EngineResult], float]] = None,
    ) -> SensitivityReport:
        """单因素敏感性分析。

        Args:
            scenario_template: 场景模板。
            parameters: 参数名到基准值的映射。
            perturb_ratio: 扰动比例。
            samples_per_point: 每个参数点的采样数。
            metric_extractor: 可选的指标提取函数。

        Returns:
            敏感性分析报告。
        """
        report = SensitivityReport()
        runner = MonteCarloRunner(engine=self.engine, default_samples=samples_per_point)
        for name, base in parameters.items():
            low = base * (1 - perturb_ratio)
            high = base * (1 + perturb_ratio)
            mc_low = self._run_monte_carlo(
                runner, scenario_template, name, low, samples_per_point, metric_extractor
            )
            mc_high = self._run_monte_carlo(
                runner, scenario_template, name, high, samples_per_point, metric_extractor
            )
            mean_low = self._extract_metric(mc_low, metric_extractor)
            mean_high = self._extract_metric(mc_high, metric_extractor)
            elasticity = self._compute_elasticity(mean_low, mean_high, base, perturb_ratio)
            entry = SensitivityEntry(
                parameter=name,
                base_value=base,
                mean_low=mean_low,
                mean_high=mean_high,
                elasticity=elasticity,
            )
            report.entries.append(entry)
        if report.entries:
            report.most_sensitive = max(
                report.entries, key=lambda e: abs(e.elasticity)
            ).parameter
        return report

    def _run_monte_carlo(self, runner: MonteCarloRunner, scenario_template: SimulationScenario,
                         param_name: str, value: float, samples: int,
                         metric_extractor: Optional[Callable[[EngineResult], float]]) -> Any:
        """运行蒙特卡洛模拟。

        Args:
            runner: 蒙特卡洛运行器
            scenario_template: 场景模板
            param_name: 参数名称
            value: 参数值
            samples: 采样数
            metric_extractor: 指标提取函数

        Returns:
            模拟结果列表
        """
        results = []
        for _ in range(samples):
            sc = copy.deepcopy(scenario_template)
            self._set_parameter(sc, param_name, value)
            res = self.engine.run(sc)
            if res.success and metric_extractor:
                results.append(metric_extractor(res))
        return results

    def _set_parameter(self, scenario: SimulationScenario, param_name: str,
                       value: float) -> None:
        """设置场景参数。

        Args:
            scenario: 模拟场景
            param_name: 参数名称
            value: 参数值
        """
        if hasattr(scenario, 'config') and hasattr(scenario.config, param_name):
            setattr(scenario.config, param_name, value)
        elif hasattr(scenario, param_name):
            setattr(scenario, param_name, value)

    @staticmethod
    def _extract_metric(results: List[Any],
                        metric_extractor: Optional[Callable[[EngineResult], float]]) -> float:
        """从结果列表中提取指标均值。

        Args:
            results: 结果列表
            metric_extractor: 指标提取函数

        Returns:
            指标均值
        """
        if not results or metric_extractor is None:
            return 0.0
        values = [metric_extractor(r) for r in results]
        return sum(values) / len(values) if values else 0.0

    @staticmethod
    def _compute_elasticity(mean_low: float, mean_high: float, base: float,
                            perturb_ratio: float) -> float:
        """计算弹性系数。

        Args:
            mean_low: 下限均值
            mean_high: 上限均值
            base: 基准值
            perturb_ratio: 扰动比例

        Returns:
            弹性系数
        """
        if base == 0 or perturb_ratio == 0:
            return 0.0
        param_change = perturb_ratio * 2
        output_change = (mean_high - mean_low) / base if base != 0 else 0
        return output_change / param_change if param_change != 0 else 0.0

    def extreme_case_test(self, scenario: SimulationScenario) -> List[ExtremeCaseResult]:
        """极端案例测试。

        Args:
            scenario: 基础场景

        Returns:
            极端案例测试结果列表
        """
        cases = [
            ExtremeCaseResult(case_name="zero_population", survived=False, notes="零智能体场景"),
            ExtremeCaseResult(case_name="single_agent", survived=False, notes="单智能体场景"),
            ExtremeCaseResult(case_name="max_steps", survived=False, notes="最大步数终止"),
        ]
        for case in cases:
            try:
                sc = copy.deepcopy(scenario)
                if "zero" in case.case_name:
                    sc.agent_count = 0
                res = self.engine.run(sc)
                case.survived = res.success
                case.output_bounds_ok = len(res.history) > 0
            except Exception as exc:
                case.notes = f"异常: {exc}"
        return cases

    def rate_credibility(self, result: EngineResult,
                         validation_report: ValidationReport) -> float:
        """评估模拟结果的可信度评分。

        Args:
            result: 模拟结果
            validation_report: 验证报告

        Returns:
            可信度评分 [0, 1]
        """
        if not validation_report.model_valid or not validation_report.result_valid:
            return 0.0
        score = 1.0
        if result.total_steps < 10:
            score -= 0.2
        for check in validation_report.failed_checks:
            score -= 0.1
        return max(0.0, min(1.0, score))
