# -*- coding: utf-8 -*-
"""卷33 · 模拟与推演引擎（阶段324）
- 物理与社会模拟：物理规则（运动/碰撞/能量守恒）、社会规则（舆论/交易）、
  物理-社会耦合、灾害事件、影响计算
"""
from __future__ import annotations

import math
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class PhysicalObject:
    """物理对象数据类

    Attributes:
        obj_id: 对象唯一标识符
        name: 对象名称
        mass: 质量
        position: 二维位置坐标 (x, y)
        velocity: 二维速度向量 (vx, vy)
        radius: 碰撞检测半径
        restitution: 恢复系数 [0, 1]
        fixed: 是否固定不动
    """
    obj_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    mass: float = 1.0
    position: Tuple[float, float] = (0.0, 0.0)
    velocity: Tuple[float, float] = (0.0, 0.0)
    radius: float = 0.5
    restitution: float = 0.8
    fixed: bool = False


@dataclass
class SocialAgent:
    """社会智能体数据类

    Attributes:
        agent_id: 智能体唯一标识符
        name: 智能体名称
        opinion: 观点值 [0, 1]
        wealth: 财富值
        influence: 影响力权重
        risk_aversion: 风险厌恶系数
    """
    agent_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    opinion: float = 0.5
    wealth: float = 100.0
    influence: float = 1.0
    risk_aversion: float = 0.5


@dataclass
class CouplingRule:
    """物理-社会耦合规则数据类

    Attributes:
        rule_id: 规则唯一标识符
        name: 规则名称
        physical_input: 物理输入字段名
        social_output: 社会输出字段名
        coefficient: 耦合系数
        nonlinear: 是否非线性耦合
    """
    rule_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    physical_input: str = ""
    social_output: str = ""
    coefficient: float = 1.0
    nonlinear: bool = False


@dataclass
class DisasterEvent:
    """灾害事件数据类

    Attributes:
        disaster_id: 灾害唯一标识符
        kind: 灾害类型
        center: 灾害中心坐标
        radius: 影响半径
        magnitude: 灾害强度
        start_time: 开始时间
        duration: 持续时间
    """
    disaster_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    kind: str = "earthquake"
    center: Tuple[float, float] = (0.0, 0.0)
    radius: float = 5.0
    magnitude: float = 1.0
    start_time: float = 0.0
    duration: float = 1.0


class PhysicsSimulator:
    """2D 物理模拟器

    实现质点运动积分、碰撞检测与冲量解析，支持重力、阻尼和恢复系数。

    Attributes:
        dt: 时间步长
        gravity: 重力加速度
        damping: 阻尼系数
    """

    GRAVITY: float = -9.81

    def __init__(self, dt: float = 0.1, gravity: float = GRAVITY,
                 damping: float = 0.99) -> None:
        """初始化物理模拟器

        Args:
            dt: 时间步长，默认0.1
            gravity: 重力加速度，默认-9.81
            damping: 阻尼系数，默认0.99
        """
        self.dt: float = float(dt)
        self.gravity: float = float(gravity)
        self.damping: float = float(damping)

    def step(self, objects: Dict[str, PhysicalObject]) -> List[Dict[str, Any]]:
        """推进一个物理步，返回本步产生的事件列表

        Args:
            objects: 物理对象字典

        Returns:
            事件列表，包含碰撞等信息
        """
        events: List[Dict[str, Any]] = []
        self._integrate_motion(objects)
        self._resolve_collisions(objects, events)
        return events

    def _integrate_motion(self, objects: Dict[str, PhysicalObject]) -> None:
        """应用重力、阻尼和位置更新

        Args:
            objects: 物理对象字典
        """
        for obj in objects.values():
            if obj.fixed:
                continue
            vx, vy = obj.velocity
            vy += self.gravity * self.dt
            vx *= self.damping
            vy *= self.damping
            x, y = obj.position
            obj.position = (x + vx * self.dt, y + vy * self.dt)
            obj.velocity = (vx, vy)

    def _resolve_collisions(self, objects: Dict[str, PhysicalObject],
                             events: List[Dict[str, Any]]) -> None:
        """检测并解析物体间碰撞

        Args:
            objects: 物理对象字典
            events: 事件列表，用于追加碰撞事件
        """
        ids: List[str] = list(objects.keys())
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                a, b = objects[ids[i]], objects[ids[j]]
                evt = self._resolve_collision(a, b)
                if evt:
                    events.append(evt)

    def _resolve_collision(self, a: PhysicalObject, b: PhysicalObject) -> Optional[Dict[str, Any]]:
        """解析两个物体间的碰撞

        Args:
            a: 第一个物体
            b: 第二个物体

        Returns:
            碰撞事件字典，无碰撞返回 None
        """
        dx: float = b.position[0] - a.position[0]
        dy: float = b.position[1] - a.position[1]
        dist: float = math.hypot(dx, dy)
        min_dist: float = a.radius + b.radius
        if dist >= min_dist or dist == 0:
            return None
        nx: float = dx / dist
        ny: float = dy / dist
        overlap: float = min_dist - dist
        self._separate_objects(a, b, nx, ny, overlap)
        impulse: Optional[float] = self._compute_impulse(a, b, nx, ny)
        if impulse is None:
            return None
        self._apply_impulse(a, b, nx, ny, impulse)
        return {"type": "collision", "a": a.obj_id, "b": b.obj_id, "impulse": abs(impulse)}

    def _separate_objects(self, a: PhysicalObject, b: PhysicalObject,
                          nx: float, ny: float, overlap: float) -> None:
        """分离重叠的物体

        Args:
            a: 第一个物体
            b: 第二个物体
            nx: 法向量X分量
            ny: 法向量Y分量
            overlap: 重叠量
        """
        total_mass: float = a.mass + b.mass
        if not a.fixed:
            a.position = (
                a.position[0] - nx * overlap * (b.mass / total_mass),
                a.position[1] - ny * overlap * (b.mass / total_mass),
            )
        if not b.fixed:
            b.position = (
                b.position[0] + nx * overlap * (a.mass / total_mass),
                b.position[1] + ny * overlap * (a.mass / total_mass),
            )

    def _compute_impulse(self, a: PhysicalObject, b: PhysicalObject,
                         nx: float, ny: float) -> Optional[float]:
        """计算碰撞冲量大小

        Args:
            a: 第一个物体
            b: 第二个物体
            nx: 法向量X分量
            ny: 法向量Y分量

        Returns:
            冲量大小，若正在分离则返回 None
        """
        rvx: float = b.velocity[0] - a.velocity[0]
        rvy: float = b.velocity[1] - a.velocity[1]
        vel_along_normal: float = rvx * nx + rvy * ny
        if vel_along_normal > 0:
            return None
        e: float = min(a.restitution, b.restitution)
        return -(1 + e) * vel_along_normal / (1 / a.mass + 1 / b.mass)

    def _apply_impulse(self, a: PhysicalObject, b: PhysicalObject,
                       nx: float, ny: float, impulse: float) -> None:
        """应用冲量到物体速度

        Args:
            a: 第一个物体
            b: 第二个物体
            nx: 法向量X分量
            ny: 法向量Y分量
            impulse: 冲量大小
        """
        if not a.fixed:
            a.velocity = (
                a.velocity[0] - impulse * nx / a.mass,
                a.velocity[1] - impulse * ny / a.mass,
            )
        if not b.fixed:
            b.velocity = (
                b.velocity[0] + impulse * nx / b.mass,
                b.velocity[1] + impulse * ny / b.mass,
            )

    def total_energy(self, objects: Dict[str, PhysicalObject]) -> float:
        """计算总机械能（动能+势能），用于稳定性检测

        Args:
            objects: 物理对象字典

        Returns:
            总能量值
        """
        energy: float = 0.0
        for obj in objects.values():
            v2: float = obj.velocity[0] ** 2 + obj.velocity[1] ** 2
            energy += 0.5 * obj.mass * v2
            energy += obj.mass * abs(self.gravity) * obj.position[1]
        return energy


class SocialSimulator:
    """社会模拟器

    实现DeGroot观点传播模型，支持社交网络结构下的意见演化。

    Attributes:
        influence_decay: 影响衰减系数
    """

    def __init__(self, influence_decay: float = 0.15) -> None:
        """初始化社会模拟器

        Args:
            influence_decay: 影响衰减系数，默认0.15
        """
        self.influence_decay: float = float(influence_decay)

    def step_opinion(self, agents: Dict[str, SocialAgent],
                     network: Optional[Dict[str, List[str]]] = None) -> List[Dict[str, Any]]:
        """推进观点传播一个步（DeGroot 模型）

        Args:
            agents: 社会智能体字典
            network: 社交网络结构，key为agent_id，value为邻居列表

        Returns:
            观点变化事件列表
        """
        events: List[Dict[str, Any]] = []
        new_opinions: Dict[str, float] = self._compute_new_opinions(agents, network)
        for aid, new_val in new_opinions.items():
            old: float = agents[aid].opinion
            agents[aid].opinion = self._clamp_opinion(new_val)
            if abs(new_val - old) > 0.05:
                events.append({
                    "type": "opinion_shift",
                    "agent": aid,
                    "from": old,
                    "to": agents[aid].opinion,
                })
        return events

    def _compute_new_opinions(self, agents: Dict[str, SocialAgent],
                               network: Optional[Dict[str, List[str]]]) -> Dict[str, float]:
        """计算所有智能体的新观点值

        Args:
            agents: 社会智能体字典
            network: 社交网络结构

        Returns:
            新观点值字典
        """
        new_opinions: Dict[str, float] = {}
        for aid, agent in agents.items():
            neighbors = (network or {}).get(aid, list(agents.keys()))
            if not neighbors:
                new_opinions[aid] = agent.opinion
                continue
            total_w: float = 0.0
            acc: float = 0.0
            for nid in neighbors:
                if nid == aid or nid not in agents:
                    continue
                w: float = agents[nid].influence
                acc += w * agents[nid].opinion
                total_w += w
            if total_w > 0:
                target: float = acc / total_w
                new_opinions[aid] = (
                    (1 - self.influence_decay) * agent.opinion
                    + self.influence_decay * target
                )
            else:
                new_opinions[aid] = agent.opinion
        return new_opinions

    @staticmethod
    def _clamp_opinion(value: float) -> float:
        """将观点值钳制到 [0, 1] 区间

        Args:
            value: 原始观点值

        Returns:
            钳制后的观点值
        """
        return max(0.0, min(1.0, value))

    def compute_social_impact(self, disaster: DisasterEvent,
                               agents: Dict[str, SocialAgent]) -> Dict[str, Any]:
        """计算灾害对社会智能体的影响

        Args:
            disaster: 灾害事件
            agents: 社会智能体字典

        Returns:
            影响结果字典
        """
        affected: List[str] = []
        wealth_loss: float = 0.0
        for agent in agents.values():
            dist: float = math.hypot(
                agent.position[0] - disaster.center[0] if hasattr(agent, 'position') else 0.0
                - disaster.center[0],
                agent.position[1] - disaster.center[1] if hasattr(agent, 'position') else 0.0
                - disaster.center[1],
            )
            if dist <= disaster.radius:
                affected.append(agent.agent_id)
                loss: float = disaster.magnitude * (1 - dist / disaster.radius) * agent.wealth
                agent.wealth -= loss
                wealth_loss += loss
                agent.opinion = max(0.0, agent.opinion - disaster.magnitude * 0.1)
        return {
            "affected_count": len(affected),
            "total_wealth_loss": wealth_loss,
            "affected_agents": affected,
        }
