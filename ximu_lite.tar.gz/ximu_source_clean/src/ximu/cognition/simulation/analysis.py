# -*- coding: utf-8 -*-
"""卷33 · 模拟与推演引擎（阶段326）
- 推演结果分析：指标统计、趋势分析、转折点发现、因果路径追踪、
  策略排名、可视化数据生成
"""
from __future__ import annotations

import statistics
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple

from .engine import EngineResult
from .monte_carlo import StrategyComparison


@dataclass
class KeyTurningPoint:
    """关键转折点数据类

    Attributes:
        step: 时间步
        time: 模拟时间
        metric: 指标名称
        value_before: 转折前均值
        value_after: 转折后均值
        delta: 变化量
        description: 描述文本
    """
    step: int = 0
    time: float = 0.0
    metric: str = ""
    value_before: float = 0.0
    value_after: float = 0.0
    delta: float = 0.0
    description: str = ""


@dataclass
class CausalPath:
    """因果路径数据类

    Attributes:
        path_id: 路径唯一标识
        cause_event: 原因事件
        effect_event: 结果事件
        lag_steps: 滞后步数
        confidence: 置信度
        reasoning: 推理说明
    """
    path_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    cause_event: Dict[str, Any] = field(default_factory=dict)
    effect_event: Dict[str, Any] = field(default_factory=dict)
    lag_steps: int = 0
    confidence: float = 0.0
    reasoning: str = ""


@dataclass
class StrategyRanking:
    """策略排名数据类

    Attributes:
        ranking_id: 排名唯一标识
        ordered_names: 排序后的策略名称列表
        scores: 各策略得分字典
        method: 排名方法
    """
    ranking_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    ordered_names: List[str] = field(default_factory=list)
    scores: Dict[str, float] = field(default_factory=dict)
    method: str = "mean"


@dataclass
class AnalysisReport:
    """分析报告数据类

    Attributes:
        report_id: 报告唯一标识
        summary: 摘要文本
        metric_stats: 指标统计字典
        turning_points: 转折点列表
        causal_paths: 因果路径列表
        trends: 趋势标签字典
        visualization: 可视化数据
    """
    report_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    summary: str = ""
    metric_stats: Dict[str, Dict[str, float]] = field(default_factory=dict)
    turning_points: List[KeyTurningPoint] = field(default_factory=list)
    causal_paths: List[CausalPath] = field(default_factory=list)
    trends: Dict[str, str] = field(default_factory=dict)
    visualization: Dict[str, Any] = field(default_factory=dict)


class SimulationAnalyzer:
    """推演结果分析器

    对模拟结果进行统计分析、趋势识别、转折点检测和因果路径追踪。

    Attributes:
        MIN_SERIES_LENGTH: 最小序列长度
        DEFAULT_WINDOW_RATIO: 默认窗口比例
        DEFAULT_THRESHOLD_RATIO: 默认阈值比例
        MAX_CAUSAL_LAG: 最大因果滞后步数
    """

    MIN_SERIES_LENGTH: int = 6
    DEFAULT_WINDOW_RATIO: float = 0.1
    DEFAULT_THRESHOLD_RATIO: float = 0.15
    MAX_CAUSAL_LAG: int = 10

    @staticmethod
    def _compute_metric_stats(history: list, metric_names: set) -> Tuple[dict, dict]:
        """计算所有指标的统计量和趋势

        Args:
            history: 历史状态列表
            metric_names: 指标名称集合

        Returns:
            统计量字典和趋势字典
        """
        stats: Dict[str, Dict[str, float]] = {}
        trends: Dict[str, str] = {}
        for name in metric_names:
            series: List[float] = [float(s.metrics.get(name, 0.0)) for s in history]
            stats[name] = SimulationAnalyzer._compute_stats(series)
            trends[name] = SimulationAnalyzer._classify_trend(series)
        return stats, trends

    @staticmethod
    def _compute_stats(series: List[float]) -> Dict[str, float]:
        """计算序列的基本统计量

        Args:
            series: 数值序列

        Returns:
            包含均值/最小值/最大值/标准差/最后值的字典
        """
        if not series:
            return {"mean": 0.0, "min": 0.0, "max": 0.0, "std": 0.0, "last": 0.0}
        return {
            "mean": statistics.fmean(series),
            "min": min(series),
            "max": max(series),
            "std": statistics.pstdev(series) if len(series) > 1 else 0.0,
            "last": series[-1],
        }

    def analyze_result(self, result: EngineResult) -> AnalysisReport:
        """对单次模拟结果做完整分析

        Args:
            result: 模拟结果对象

        Returns:
            分析报告对象
        """
        report: AnalysisReport = AnalysisReport()
        history: List[Any] = result.history
        if not history:
            report.summary = "空结果，无法分析"
            return report
        metric_names: set = self._collect_metric_names(history)
        report.metric_stats, report.trends = self._compute_metric_stats(history, metric_names)
        report.turning_points = self._find_all_turning_points(history, metric_names)
        report.causal_paths = self.trace_causal_path(result)
        report.summary = self._build_summary(result, report)
        report.visualization = self.generate_visualization_data(result)
        return report

    def _collect_metric_names(self, history: List[Any]) -> set:
        """收集所有历史步骤中的指标名称

        Args:
            history: 历史状态列表

        Returns:
            指标名称集合
        """
        metric_names: set = set()
        for state in history:
            metric_names.update(state.metrics.keys())
        return metric_names

    def _find_all_turning_points(self, history: List[Any], metric_names: set) -> List[KeyTurningPoint]:
        """找出所有指标的转折点

        Args:
            history: 历史状态列表
            metric_names: 指标名称集合

        Returns:
            转折点列表
        """
        all_points: List[KeyTurningPoint] = []
        for name in metric_names:
            series: List[Tuple[int, float]] = [
                (s.step, float(s.metrics.get(name, 0.0))) for s in history
            ]
            points: List[KeyTurningPoint] = self.find_turning_points(series, name)
            all_points.extend(points)
        return all_points

    def _build_summary(self, result: EngineResult, report: AnalysisReport) -> str:
        """构建分析报告摘要

        Args:
            result: 模拟结果
            report: 分析报告

        Returns:
            摘要文本
        """
        alive_final: float = (
            result.history[-1].metrics.get("alive_agents", 0.0)
            if result.history else 0.0
        )
        return (
            f"模拟共{len(result.history)}步，终止原因：{result.termination_reason}；"
            f"最终存活智能体：{alive_final:.0f}；"
            f"转折点{len(report.turning_points)}个；"
            f"因果路径{len(report.causal_paths)}条。"
        )

    @staticmethod
    def _classify_trend(series: List[float], window: int = 5) -> str:
        """判断趋势：rising / falling / flat

        Args:
            series: 数值序列
            window: 窗口大小

        Returns:
            趋势标签
        """
        if len(series) < window * 2:
            return "flat"
        first: float = statistics.fmean(series[:window])
        last: float = statistics.fmean(series[-window:])
        span: float = max(abs(first), abs(last), 1e-6)
        change: float = (last - first) / span
        if change > 0.1:
            return "rising"
        if change < -0.1:
            return "falling"
        return "flat"

    def find_turning_points(self, series: List[Tuple[int, float]], metric_name: str,
                             threshold_ratio: float = 0.15) -> List[KeyTurningPoint]:
        """识别关键转折点

        Args:
            series: 时序数据列表
            metric_name: 指标名称
            threshold_ratio: 阈值比例

        Returns:
            转折点列表
        """
        if len(series) < self.MIN_SERIES_LENGTH:
            return []
        values: List[float] = [v for _, v in series]
        span: float = max(max(values) - min(values), 1e-6)
        window: int = max(2, int(len(series) * self.DEFAULT_WINDOW_RATIO))
        points: List[KeyTurningPoint] = self._detect_turning_points(
            series, window, span, threshold_ratio, metric_name
        )
        return self._merge_adjacent_points(points, window)

    @staticmethod
    def _detect_turning_points(series: list, window: int, span: float,
                                threshold_ratio: float, metric_name: str) -> list:
        """滑动窗口检测转折点

        Args:
            series: 时序数据
            window: 窗口大小
            span: 数据跨度
            threshold_ratio: 阈值比例
            metric_name: 指标名称

        Returns:
            转折点列表
        """
        points: List[KeyTurningPoint] = []
        for i in range(window, len(series) - window):
            before_vals: List[float] = [v for _, v in series[i - window:i]]
            after_vals: List[float] = [v for _, v in series[i:i + window]]
            before: float = statistics.fmean(before_vals)
            after: float = statistics.fmean(after_vals)
            delta: float = after - before
            if abs(delta) / span >= threshold_ratio:
                step, val = series[i]
                points.append(KeyTurningPoint(
                    step=step,
                    time=float(step),
                    metric=metric_name,
                    value_before=before,
                    value_after=after,
                    delta=delta,
                    description=(
                        f"指标{metric_name}在第{step}步发生显著变化："
                        f"{before:.3f} -> {after:.3f}（Δ={delta:+.3f}）"
                    ),
                ))
        return points

    @staticmethod
    def _merge_adjacent_points(points: List[KeyTurningPoint], window: int) -> List[KeyTurningPoint]:
        """合并相邻转折点

        Args:
            points: 转折点列表
            window: 合并窗口

        Returns:
            合并后的转折点列表
        """
        if not points:
            return []
        merged: List[KeyTurningPoint] = [points[0]]
        for pt in points[1:]:
            last = merged[-1]
            if pt.step - last.step <= window:
                # 合并：取更显著的点
                if abs(pt.delta) > abs(last.delta):
                    merged[-1] = pt
            else:
                merged.append(pt)
        return merged

    def trace_causal_path(self, result: EngineResult) -> List[CausalPath]:
        """追踪因果路径

        Args:
            result: 模拟结果

        Returns:
            因果路径列表
        """
        paths: List[CausalPath] = []
        history = result.history
        if len(history) < 3:
            return paths
        metrics = set()
        for state in history:
            metrics.update(state.metrics.keys())
        metric_list = sorted(metrics)
        for i in range(len(metric_list) - 1):
            for j in range(i + 1, min(i + 3, len(metric_list))):
                m1, m2 = metric_list[i], metric_list[j]
                series1 = [float(h.metrics.get(m1, 0.0)) for h in history]
                series2 = [float(h.metrics.get(m2, 0.0)) for h in history]
                if len(series1) < 5:
                    continue
                lag: int = 1
                if lag < len(series1):
                    corr: float = self._pearson_corr(series1[:-lag], series2[lag:])
                    if abs(corr) > 0.5:
                        paths.append(CausalPath(
                            cause_event={"metric": m1},
                            effect_event={"metric": m2},
                            lag_steps=lag,
                            confidence=abs(corr),
                            reasoning=f"{m1} 与 {m2} 相关系数 {corr:.2f}，滞后 {lag} 步",
                        ))
        return paths

    @staticmethod
    def _pearson_corr(x: List[float], y: List[float]) -> float:
        """计算皮尔逊相关系数

        Args:
            x: 第一个序列
            y: 第二个序列

        Returns:
            相关系数 [-1, 1]
        """
        n: int = min(len(x), len(y))
        if n < 2:
            return 0.0
        mx: float = statistics.fmean(x[:n])
        my: float = statistics.fmean(y[:n])
        sx: float = statistics.pstdev(x[:n])
        sy: float = statistics.pstdev(y[:n])
        if sx == 0 or sy == 0:
            return 0.0
        cov: float = sum((x[k] - mx) * (y[k] - my) for k in range(n)) / n
        return cov / (sx * sy)

    def generate_visualization_data(self, result: EngineResult) -> Dict[str, Any]:
        """生成可视化所需的数据

        Args:
            result: 模拟结果

        Returns:
            可视化数据字典
        """
        viz: Dict[str, Any] = {
            "steps": [],
            "metrics": {},
        }
        for state in result.history:
            viz["steps"].append(state.step)
            for key, val in state.metrics.items():
                if key not in viz["metrics"]:
                    viz["metrics"][key] = []
                viz["metrics"][key].append(float(val))
        return viz

    def rank_strategies(self, comparisons: List[StrategyComparison]) -> StrategyRanking:
        """对策略进行比较排名

        Args:
            comparisons: 策略比较列表

        Returns:
            策略排名对象
        """
        scores: Dict[str, float] = {}
        for comp in comparisons:
            name = comp.strategy_name
            if name not in scores:
                scores[name] = 0.0
            scores[name] += comp.score
        ordered: List[str] = sorted(scores.keys(), key=lambda n: scores[n], reverse=True)
        return StrategyRanking(
            ordered_names=ordered,
            scores=scores,
            method="sum",
        )
