import copy
import logging
import math
import random
import statistics
import time
import uuid
import warnings
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

from .scenario import SimulationScenario
from .engine import EngineResult, SimulationEngine

logger = logging.getLogger("src.ximu.cognition.simulation.monte_carlo")


@dataclass
class MonteCarloResult:
    """蒙特卡洛推演结果"""
    run_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    samples: int = 0
    successes: int = 0
    success_probability: float = 0.0
    mean_metric: Dict[str, float] = field(default_factory=dict)
    std_metric: Dict[str, float] = field(default_factory=dict)
    ci95_metric: Dict[str, Tuple[float, float]] = field(default_factory=dict)
    failures: List[str] = field(default_factory=list)
    elapsed_ms: float = 0.0


@dataclass
class ParameterSweep:
    """参数扫描结果"""
    sweep_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    parameter_name: str = ""
    values: List[float] = field(default_factory=list)
    results: Dict[float, Dict[str, float]] = field(default_factory=dict)


@dataclass
class StrategyComparison:
    """策略对比结果"""
    comparison_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    strategies: Dict[str, Dict[str, float]] = field(default_factory=dict)
    winner: str = ""


@dataclass
class RiskAssessment:
    """风险评估结果"""
    risk_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    var_95: float = 0.0
    var_99: float = 0.0
    expected_shortfall: float = 0.0
    tail_probability: float = 0.0
    threshold: float = 0.0


def _percentile(sorted_values: List[float], q: float) -> float:
    """计算分位数"""
    if not sorted_values:
        return 0.0
    if len(sorted_values) == 1:
        return sorted_values[0]

    k = (len(sorted_values) - 1) * q
    lo = int(math.floor(k))
    hi = min(lo + 1, len(sorted_values) - 1)
    frac = k - lo
    return sorted_values[lo] * (1 - frac) + sorted_values[hi] * frac


class MonteCarloRunner:
    """蒙特卡洛推演器"""

    def __init__(self, engine: Optional[SimulationEngine] = None, default_samples: int = 100) -> None:
        """初始化蒙特卡洛推演器"""
        self.engine = engine or SimulationEngine()
        self.default_samples = max(1, int(default_samples))

    @staticmethod
    def _process_run(
        run: EngineResult,
        success_criterion: Optional[Callable[[EngineResult], bool]],
        metric_extractor: Optional[Callable[[EngineResult], float]]
    ) -> Tuple[bool, bool, Optional[float], Dict[str, float]]:
        """处理单次模拟结果"""
        failed = not run.success
        if failed:
            logger.debug("单次模拟失败: %s", run.error_message or "(无错误信息)")
            return True, False, None, {}

        success = True if success_criterion is None else success_criterion(run)
        metric: Optional[float] = None
        state_metrics: Dict[str, float] = {}

        if metric_extractor is not None:
            try:
                metric = float(metric_extractor(run))
            except Exception as e:
                logger.debug("指标提取失败: %s", e, exc_info=True)

        if run.final_state and run.final_state.metrics:
            state_metrics = {k: float(v) for k, v in run.final_state.metrics.items()}

        return False, success, metric, state_metrics

    @staticmethod
    def _fill_statistics(
        result: MonteCarloResult,
        per_metric: Dict[str, List[float]],
        metric_values: List[float],
        n: int
    ) -> None:
        """填充汇总统计量到结果对象"""
        result.success_probability = result.successes / n if n > 0 else 0.0

        for k, vals in per_metric.items():
            MonteCarloRunner._compute_metric_stats(result, k, vals)

        if metric_values:
            result.mean_metric["__extracted__"] = statistics.fmean(metric_values)
            result.std_metric["__extracted__"] = (
                statistics.pstdev(metric_values) if len(metric_values) > 1 else 0.0
            )

    @staticmethod
    def _compute_metric_stats(
        result: MonteCarloResult,
        k: str,
        vals: List[float]
    ) -> None:
        """计算单个指标的统计量并写入结果"""
        if len(vals) < 2:
            mean_val = vals[0] if vals else 0.0
            result.mean_metric[k] = mean_val
            result.std_metric[k] = 0.0
            result.ci95_metric[k] = (mean_val, mean_val)
            return

        mean = statistics.fmean(vals)
        std = statistics.pstdev(vals)
        sorted_vals = sorted(vals)

        result.mean_metric[k] = mean
        result.std_metric[k] = std
        result.ci95_metric[k] = (
            _percentile(sorted_vals, 0.025),
            _percentile(sorted_vals, 0.975)
        )

    def run_monte_carlo(
        self,
        scenario_template: SimulationScenario,
        samples: Optional[int] = None,
        metric_extractor: Optional[Callable[[EngineResult], float]] = None,
        success_criterion: Optional[Callable[[EngineResult], bool]] = None,
        seed_base: int = 2024
    ) -> MonteCarloResult:
        """对同一场景做 N 次随机模拟"""
        n = int(samples or self.default_samples)
        t0 = time.perf_counter()
        result = MonteCarloResult(samples=n)
        metric_values: List[float] = []
        per_metric: Dict[str, List[float]] = {}
        successes = 0

        for i in range(n):
            scenario = copy.deepcopy(scenario_template)
            scenario.config.random_seed = seed_base + i
            run = self.engine.run(scenario)

            failed, is_success, metric, state_metrics = self._process_run(
                run, success_criterion, metric_extractor
            )

            if failed:
                result.failures.append(run.error_message or "unknown")
                continue

            if is_success:
                successes += 1

            if metric is not None:
                metric_values.append(metric)

            for k, v in state_metrics.items():
                per_metric.setdefault(k, []).append(v)

        if not per_metric and not metric_values:
            warnings.warn(
                f"蒙特卡洛场景 {getattr(scenario_template, 'name', '')!r} 未产生任何指标，"
                "请确认是否配置了规则/初始状态指标。",
                stacklevel=2,
            )
            per_metric["__empty_scenario__"] = [0.0]

        result.successes = successes
        self._fill_statistics(result, per_metric, metric_values, n)
        result.elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return result

    def parameter_sweep(
        self,
        scenario_template: SimulationScenario,
        parameter_name: str,
        values: List[float],
        samples_per_value: int = 20,
        metric_extractor: Optional[Callable[[EngineResult], float]] = None,
        seed_base: int = 3000
    ) -> ParameterSweep:
        """对单个参数做网格扫描"""
        result = ParameterSweep(parameter_name=parameter_name, values=values)
        for val in values:
            scenario = copy.deepcopy(scenario_template)
            setattr(scenario, parameter_name, val)
            mc_result = self.run_monte_carlo(
                scenario,
                samples=samples_per_value,
                metric_extractor=metric_extractor,
                seed_base=seed_base
            )
            result.results[val] = mc_result.mean_metric
        return result
