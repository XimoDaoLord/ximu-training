# -*- coding: utf-8 -*-
"""卷33 · 模拟与推演引擎（阶段323）
- 多智能体模拟：智能体注册、感知-决策-行动循环、通信、竞争协作、群体涌现检测
- 蓝图接口：register_agent_type / set_agent_perception / set_agent_decision /
            enable_communication / detect_emergence
"""
from __future__ import annotations

import math
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from .scenario import SimulationState


@dataclass
class AgentPerception:
    """智能体感知结果数据类

    Attributes:
        agent_id: 智能体唯一标识符
        time: 当前模拟时间步
        visible_agents: 视野内可见的其他智能体ID列表
        visible_events: 视野内可见的事件列表
        environment_snapshot: 环境状态快照字典
        messages: 已接收的消息列表
    """
    agent_id: str
    time: float = 0.0
    visible_agents: List[str] = field(default_factory=list)
    visible_events: List[Dict[str, Any]] = field(default_factory=list)
    environment_snapshot: Dict[str, Any] = field(default_factory=dict)
    messages: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class AgentDecision:
    """智能体决策数据类

    Attributes:
        action_type: 动作类型，如 move/interact/send_message/idle
        dx: X轴移动量
        dy: Y轴移动量
        target: 目标智能体ID
        payload: 额外负载数据
    """
    action_type: str = "idle"
    dx: float = 0.0
    dy: float = 0.0
    target: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)

    def to_action(self) -> Dict[str, Any]:
        """将决策转换为动作字典

        Returns:
            标准化的动作字典，包含 type/dx/dy/target 及 payload
        """
        return {
            "type": self.action_type,
            "dx": self.dx,
            "dy": self.dy,
            "target": self.target,
            **self.payload,
        }


@dataclass
class InteractionEvent:
    """智能体间交互事件数据类

    Attributes:
        interaction_id: 交互事件唯一ID
        kind: 交互类型，如 cooperate/compete/attack
        actor: 发起者智能体ID
        target: 目标智能体ID
        time: 发生时间
        magnitude: 交互强度
        payload: 额外载荷数据
    """
    interaction_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    kind: str = "cooperate"
    actor: str = ""
    target: str = ""
    time: float = 0.0
    magnitude: float = 1.0
    payload: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EmergentPattern:
    """涌现模式检测数据类

    Attributes:
        pattern_id: 涌现模式唯一ID
        name: 模式名称
        detected_at_step: 检测到的时间步
        description: 模式描述
        evidence: 证据强度字典
    """
    pattern_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    detected_at_step: int = 0
    description: str = ""
    evidence: Dict[str, float] = field(default_factory=dict)


class MultiAgentSystem:
    """多智能体模拟系统主类

    提供智能体类型的注册、感知-决策循环执行、消息传递、
    交互事件记录以及群体涌现模式检测能力。

    Attributes:
        vision_radius: 智能体感知半径
        enable_communication: 是否启用智能体间通信
    """

    DEFAULT_VISION_RADIUS: float = 10.0

    def __init__(self, vision_radius: float = DEFAULT_VISION_RADIUS,
                 enable_communication: bool = True) -> None:
        """初始化多智能体系统

        Args:
            vision_radius: 感知半径，默认10.0
            enable_communication: 是否启用通信机制，默认开启
        """
        self.vision_radius: float = float(vision_radius)
        self.enable_communication: bool = enable_communication
        self._perceptions: Dict[str, Callable] = {}
        self._decisions: Dict[str, Callable] = {}
        self._interaction_history: List[InteractionEvent] = []
        self._message_inbox: Dict[str, List[Dict[str, Any]]] = {}
        self._position_history: List[Dict[str, Tuple[float, float]]] = []
        self._emergence_threshold: float = 0.7

    def register_agent_type(self, agent_type: str,
                            perception: Callable[[Dict[str, Any], SimulationState], AgentPerception],
                            decision: Callable[[AgentPerception], AgentDecision]) -> None:
        """注册智能体类型及其感知和决策函数

        Args:
            agent_type: 智能体类型名称字符串
            perception: 感知函数，接收智能体数据和状态，返回感知结果
            decision: 决策函数，接收感知结果，返回决策对象
        """
        if not isinstance(agent_type, str) or not agent_type:
            raise ValueError("agent_type 必须为非空字符串")
        self._perceptions[agent_type] = perception
        self._decisions[agent_type] = decision

    def set_agent_perception(self, agent_type: str,
                              perception: Callable[[Dict[str, Any], SimulationState], AgentPerception]) -> None:
        """替换某类型智能体的感知函数

        Args:
            agent_type: 智能体类型名称
            perception: 新的感知函数
        """
        if agent_type not in self._perceptions:
            raise KeyError(f"未找到智能体类型: {agent_type}")
        self._perceptions[agent_type] = perception

    def set_agent_decision(self, agent_type: str,
                            decision: Callable[[AgentPerception], AgentDecision]) -> None:
        """替换某类型智能体的决策函数

        Args:
            agent_type: 智能体类型名称
            decision: 新的决策函数
        """
        if agent_type not in self._decisions:
            raise KeyError(f"未找到智能体类型: {agent_type}")
        self._decisions[agent_type] = decision

    def enable_communication(self, enabled: bool = True) -> None:
        """开启或关闭智能体间通信功能

        Args:
            enabled: True表示启用，False表示关闭
        """
        if not isinstance(enabled, bool):
            raise TypeError("enabled 必须是布尔值")
        self.enable_communication = enabled

    def perceive(self, agent_id: str, agent: Dict[str, Any],
                 state: SimulationState) -> AgentPerception:
        """为指定智能体构造感知结果

        Args:
            agent_id: 目标智能体ID
            agent: 智能体数据字典，包含 position 等信息
            state: 当前模拟状态对象

        Returns:
            AgentPerception 感知结果对象
        """
        pos: List[float] = agent.get("position", [0.0, 0.0])
        visible: List[str] = []
        for other_id, other in state.agent_states.items():
            if other_id == agent_id or not other.get("alive", True):
                continue
            opos: List[float] = other.get("position", [0.0, 0.0])
            dist: float = math.hypot(pos[0] - opos[0], pos[1] - opos[1])
            if dist <= self.vision_radius:
                visible.append(other_id)
        inbox: List[Dict[str, Any]] = self._message_inbox.get(agent_id, [])
        return AgentPerception(
            agent_id=agent_id,
            time=state.time,
            visible_agents=visible,
            visible_events=list(state.events[-20:]) if state.events else [],
            environment_snapshot=dict(state.environment_state),
            messages=list(inbox),
        )

    def act(self, agent_id: str, agent: Dict[str, Any],
            state: SimulationState) -> Optional[Dict[str, Any]]:
        """执行单个智能体的感知-决策-行动完整周期

        Args:
            agent_id: 智能体ID
            agent: 智能体数据字典
            state: 当前模拟状态

        Returns:
            生成的动作字典，若无对应控制器则返回 None
        """
        agent_type: str = agent.get("type", "generic")
        perceive_fn: Optional[Callable] = self._perceptions.get(agent_type)
        decide_fn: Optional[Callable] = self._decisions.get(agent_type)
        if perceive_fn is None or decide_fn is None:
            return None
        perception: AgentPerception = perceive_fn(agent, state)
        decision: AgentDecision = decide_fn(perception)
        action: Dict[str, Any] = decision.to_action()
        self._apply_action(agent_id, agent, action, state)
        return action

    def _apply_action(self, agent_id: str, agent: Dict[str, Any],
                      action: Dict[str, Any], state: SimulationState) -> None:
        """应用智能体动作到状态

        Args:
            agent_id: 智能体ID
            agent: 智能体数据字典
            action: 动作字典
            state: 当前模拟状态
        """
        atype: str = action.get("type", "")
        if atype == "move":
            old: List[float] = agent.get("position", [0.0, 0.0])
            dx: float = float(action.get("dx", 0.0))
            dy: float = float(action.get("dy", 0.0))
            agent["position"] = [old[0] + dx, old[1] + dy]
            self._position_history.append({agent_id: (agent["position"][0], agent["position"][1])})
        elif atype in ("interact", "cooperate", "compete", "attack"):
            self._record_interaction(
                kind=action.get("interaction_kind") or atype,
                actor=agent_id,
                target=str(action.get("target", "")),
                state=state,
                magnitude=float(action.get("magnitude", 1.0)),
                payload=action,
            )
        elif atype == "send_message" and self.enable_communication:
            self._send_message(agent_id, action, state)

    def _send_message(self, agent_id: str, action: Dict[str, Any],
                      state: SimulationState) -> None:
        """发送消息给目标智能体

        Args:
            agent_id: 发送者ID
            action: 包含 target 和 text 的动作字典
            state: 当前模拟状态
        """
        target: str = str(action.get("target", ""))
        if not target:
            return
        inbox: List[Dict[str, Any]] = self._message_inbox.setdefault(target, [])
        inbox.append({
            "from": agent_id,
            "text": str(action.get("text", "")),
            "time": state.time,
        })

    def flush_messages(self) -> None:
        """每步结束后清空所有已投递的消息收件箱"""
        self._message_inbox.clear()

    def _record_interaction(self, kind: str, actor: str, target: str,
                             state: SimulationState, magnitude: float,
                             payload: Dict[str, Any]) -> None:
        """记录一次智能体间交互事件

        Args:
            kind: 交互类型字符串
            actor: 发起者ID
            target: 目标ID
            state: 当前模拟状态
            magnitude: 交互强度
            payload: 额外数据载荷
        """
        evt: InteractionEvent = InteractionEvent(
            kind=kind,
            actor=actor,
            target=target,
            time=state.time,
            magnitude=magnitude,
            payload=payload,
        )
        self._interaction_history.append(evt)

    def detect_emergence(self) -> List[EmergentPattern]:
        """检测群体涌现模式

        分析交互历史，检测合作/竞争/攻击模式的显著聚集现象。

        Returns:
            检测到的涌现模式列表
        """
        if len(self._interaction_history) < 10:
            return []
        patterns: List[EmergentPattern] = []
        kind_counts: Dict[str, int] = {}
        for evt in self._interaction_history[-50:]:
            kind_counts[evt.kind] = kind_counts.get(evt.kind, 0) + 1
        total: int = len(self._interaction_history[-50:])
        if total == 0:
            return patterns
        for kind, count in kind_counts.items():
            ratio: float = count / total
            if ratio >= self._emergence_threshold:
                pattern: EmergentPattern = EmergentPattern(
                    name=f"{kind}_cluster",
                    detected_at_step=len(self._interaction_history),
                    description=f"{kind} 交互占比达 {ratio:.2%}",
                    evidence={kind: ratio},
                )
                patterns.append(pattern)
        return patterns

    def get_interaction_history(self) -> List[InteractionEvent]:
        """获取交互事件历史记录

        Returns:
            交互事件列表
        """
        return list(self._interaction_history)

    def get_position_history(self) -> List[Dict[str, Tuple[float, float]]]:
        """获取位置历史快照

        Returns:
            位置历史列表
        """
        return list(self._position_history)
