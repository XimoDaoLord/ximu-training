# -*- coding: utf-8 -*-
"""
卷33 · 模拟与推演引擎（阶段321-330）
提供懒加载机制以按需导入子模块。
"""

import importlib as _importlib
import threading as _th
from typing import Any

_load_lock = _th.Lock()
_parts_modules = [
    "scenario",
    "engine",
    "multi_agent",
    "physical_social",
    "monte_carlo",
    "analysis",
    "validation",
]
_parts_loaded: dict[str, Any] = {}


def __getattr__(name: str) -> Any:
    """
    PEP 562 懒加载属性访问。

    当访问模块属性时，按需加载子模块并返回对应符号。

    Args:
        name: 要获取的属性名。

    Returns:
        对应的属性对象。

    Raises:
        AttributeError: 如果属性不存在。
    """
    for part in _parts_modules:
        if part not in _parts_loaded:
            with _load_lock:
                if part not in _parts_loaded:
                    _parts_loaded[part] = _importlib.import_module(f".{part}", __name__)
        mod = _parts_loaded[part]
        if hasattr(mod, name):
            return getattr(mod, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "SimulationDomain",
    "SimulationConfig",
    "SimulationState",
    "SimulationScenario",
    "ScenarioBuilder",
    "EngineEvent",
    "EngineContext",
    "EngineResult",
    "SimulationEngine",
    "AgentPerception",
    "AgentDecision",
    "InteractionEvent",
    "EmergentPattern",
    "MultiAgentSystem",
    "PhysicalObject",
    "SocialAgent",
    "CouplingRule",
    "DisasterEvent",
    "PhysicsSimulator",
    "SocialSimulator",
    "CouplingEngine",
    "DisasterSimulator",
    "MonteCarloResult",
    "ParameterSweep",
    "StrategyComparison",
    "RiskAssessment",
    "MonteCarloRunner",
    "KeyTurningPoint",
    "CausalPath",
    "StrategyRanking",
    "AnalysisReport",
    "SimulationAnalyzer",
    "ValidationReport",
    "SensitivityEntry",
    "SensitivityReport",
    "ExtremeCaseResult",
    "SimulationValidator",
]
