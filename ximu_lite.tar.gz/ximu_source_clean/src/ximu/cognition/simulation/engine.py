# -*- coding: utf-8 -*-
"""卷33 · 模拟与推演引擎（阶段322）
- 模拟引擎核心：状态推进、时间步进、事件系统、运行循环
- 蓝图接口：SimulationEngine.run/step/reset/pause/resume
- 安全保护：最大执行时间、异常隔离、历史采样
"""
import copy
import random
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from .scenario import SimulationConfig, SimulationScenario, SimulationState


@dataclass
class EngineEvent:
    """事件队列中的事件。"""
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    type: str = "generic"
    time: float = 0.0
    source: str = ""
    target: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)
    processed: bool = False


@dataclass
class EngineContext:
    """模拟运行时上下文。"""
    current_state: SimulationState = field(default_factory=SimulationState)
    config: SimulationConfig = field(default_factory=SimulationConfig)
    rules: List[Callable[[SimulationState], None]] = field(default_factory=list)
    random_generator: random.Random = field(default_factory=random.Random)
    event_queue: List[EngineEvent] = field(default_factory=list)
    metrics_history: Dict[str, List[float]] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EngineResult:
    """单次模拟运行完整结果。"""
    result_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    scenario_name: str = ""
    final_state: Optional[SimulationState] = None
    history: List[SimulationState] = field(default_factory=list)
    event_log: List[Dict[str, Any]] = field(default_factory=list)
    metrics_history: Dict[str, List[float]] = field(default_factory=dict)
    termination_reason: str = ""
    total_steps: int = 0
    total_time_ms: float = 0.0
    success: bool = True
    error_message: Optional[str] = None


class SimulationEngine:
    """模拟引擎核心。"""

    def __init__(self, history_sample_rate: int = 1) -> None:
        """初始化模拟引擎

        Args:
            history_sample_rate: 历史记录采样率，默认每步记录
        """
        self._rule_handlers: Dict[str, Callable[[EngineContext], None]] = {}
        self._agent_controllers: Dict[str, Callable[[Dict[str, Any], EngineContext], Dict[str, Any]]] = {}
        self._paused: bool = False
        self._stop_requested: bool = False
        self._history_sample_rate: int = max(1, int(history_sample_rate))
        self._context: Optional[EngineContext] = None

    def reset(self, scenario: SimulationScenario) -> EngineContext:
        """重置模拟到初始状态

        Args:
            scenario: 模拟场景

        Returns:
            新的模拟上下文

        Raises:
            ValueError: 场景初始状态未设置
        """
        if scenario.initial_state is None:
            raise ValueError("场景初始状态未设置，无法重置")
        rng: random.Random = random.Random(scenario.config.random_seed)
        state: SimulationState = copy.deepcopy(scenario.initial_state)
        state.step = 0
        state.time = 0.0
        state.events = []
        state.terminated = False
        state.termination_reason = ""
        ctx: EngineContext = EngineContext(
            current_state=state,
            config=scenario.config,
            rules=list(scenario.rules),
            random_generator=rng,
            event_queue=[],
            metrics_history={k: [] for k in scenario.metrics_to_track},
        )
        self._context = ctx
        self._paused = False
        self._stop_requested = False
        return ctx

    def step(self, context: EngineContext) -> SimulationState:
        """执行一个模拟步

        Args:
            context: 模拟上下文

        Returns:
            更新后的状态
        """
        state: SimulationState = context.current_state
        self._process_events(context)
        for rule in context.rules:
            try:
                rule(state)
            except Exception as exc:
                state.events.append({
                    "type": "rule_error",
                    "time": state.time,
                    "message": str(exc),
                })
        for handler in self._rule_handlers.values():
            handler(context)
        self._step_agents(context)
        state.step += 1
        state.time += context.config.time_step
        self._update_basic_metrics(context)
        for key in list(context.metrics_history.keys()):
            context.metrics_history[key].append(float(state.metrics.get(key, 0.0)))
        return state

    def run(self, scenario: SimulationScenario) -> EngineResult:
        """运行一次完整模拟

        Args:
            scenario: 模拟场景

        Returns:
            模拟结果
        """
        t0: float = time.perf_counter()
        result: EngineResult = EngineResult(scenario_name=scenario.name)
        try:
            context: EngineContext = self.reset(scenario)
            result.history.append(copy.deepcopy(context.current_state))
            deadline: float = t0 + scenario.config.max_execution_seconds
            self._run_simulation_loop(context, scenario, deadline, result)
            result.final_state = copy.deepcopy(context.current_state)
            result.total_steps = context.current_state.step
            result.metrics_history = {k: list(v) for k, v in context.metrics_history.items()}
            result.event_log = list(context.current_state.events)
            result.success = True
        except Exception as exc:
            result.success = False
            result.error_message = str(exc)
            result.termination_reason = f"模拟异常: {exc}"
        result.total_time_ms = (time.perf_counter() - t0) * 1000.0
        return result

    def _run_simulation_loop(self, context: EngineContext, scenario: SimulationScenario,
                              deadline: float, result: EngineResult) -> None:
        """执行主模拟循环

        Args:
            context: 模拟上下文
            scenario: 模拟场景
            deadline: 截止时间
            result: 结果对象
        """
        while context.current_state.step < scenario.config.max_steps:
            if self._stop_requested:
                result.termination_reason = "外部停止请求"
                return
            if self._paused:
                time.sleep(0.01)
                continue
            if time.perf_counter() > deadline:
                result.termination_reason = f"超过最大执行时间 {scenario.config.max_execution_seconds}s"
                return
            self.step(context)
            if scenario.config.record_history and (
                context.current_state.step % self._history_sample_rate == 0
                or context.current_state.terminated
            ):
                result.history.append(copy.deepcopy(context.current_state))
            if context.current_state.terminated:
                result.termination_reason = context.current_state.termination_reason or "终止条件触发"
                return
        result.termination_reason = "达到最大步数"

    def register_rule_handler(self, rule_type: str, handler: Callable[[EngineContext], None]) -> None:
        """注册规则处理器

        Args:
            rule_type: 规则类型
            handler: 处理器函数
        """
        self._rule_handlers[rule_type] = handler

    def register_agent_controller(self, agent_type: str,
                                   controller: Callable[[Dict[str, Any], EngineContext], Dict[str, Any]]) -> None:
        """注册智能体控制器

        Args:
            agent_type: 智能体类型
            controller: 控制器函数
        """
        self._agent_controllers[agent_type] = controller

    def pause(self) -> None:
        """暂停模拟。"""
        self._paused = True

    def resume(self) -> None:
        """恢复模拟。"""
        self._paused = False

    def stop(self) -> None:
        """请求停止模拟。"""
        self._stop_requested = True

    def _process_events(self, context: EngineContext) -> None:
        """处理到期事件

        Args:
            context: 模拟上下文
        """
        current_time: float = context.current_state.time
        pending: List[EngineEvent] = []
        for event in context.event_queue:
            if event.time <= current_time and not event.processed:
                event.processed = True
                context.current_state.events.append({
                    "type": event.type,
                    "time": event.time,
                    "source": event.source,
                    "target": event.target,
                    "payload": event.payload,
                })
            else:
                pending.append(event)
        context.event_queue = pending

    def schedule_event(self, event_time: float, event_type: str,
                        source: str, target: str, payload: Dict[str, Any]) -> None:
        """调度一个未来事件

        Args:
            event_time: 事件发生时间
            event_type: 事件类型
            source: 事件来源
            target: 事件目标
            payload: 事件载荷
        """
        event = EngineEvent(
            type=event_type,
            time=event_time,
            source=source,
            target=target,
            payload=payload,
        )
        self._context.event_queue.append(event)
        self._context.event_queue.sort(key=lambda e: e.time)

    def _step_agents(self, context: EngineContext) -> None:
        """执行智能体步骤

        Args:
            context: 模拟上下文
        """
        state: SimulationState = context.current_state
        for agent in getattr(state, "agents", []):
            agent_type = agent.get("type", "default")
            controller = self._agent_controllers.get(agent_type)
            if controller:
                try:
                    controller(agent, context)
                except Exception:
                    pass

    def _update_basic_metrics(self, context: EngineContext) -> None:
        """更新基础指标

        Args:
            context: 模拟上下文
        """
        state: SimulationState = context.current_state
        state.metrics["step"] = state.step
        state.metrics["time"] = state.time
