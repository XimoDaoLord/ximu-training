# -*- coding: utf-8 -*-
"""世界模型推理引擎。

基于规则的推理、基于案例的推理、类比推理集成。
为世界模型提供推理能力，不仅知道"是什么"，还能推断"为什么"和"会怎样"。
"""

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from src.ximu.cognition.world_model.representation import WorldState
from src.ximu.cognition.world_model.knowledge_graph import KnowledgeGraphEngine


@dataclass
class InferenceRule:
    """推理规则：如果前提成立，则得出结论。"""
    
    rule_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    premise: Dict[str, Any] = field(default_factory=dict)
    conclusion: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0
    rule_type: str = "deductive"  # deductive, inductive, abductive
    usage_count: int = 0
    created_at: float = field(default_factory=time.time)


@dataclass
class InferenceResult:
    """推理结果封装。"""
    
    result_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    conclusion: Any = None
    confidence: float = 1.0
    reasoning_path: List[str] = field(default_factory=list)
    used_rules: List[str] = field(default_factory=list)
    explanation: str = ""
    inference_type: str = ""
    timestamp: float = field(default_factory=time.time)


@dataclass
class Case:
    """案例库中的案例。"""
    
    case_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    situation: Dict[str, Any] = field(default_factory=dict)
    outcome: Dict[str, Any] = field(default_factory=dict)
    success_rate: float = 1.0
    usage_count: int = 0


class WorldModelInferenceEngine:
    """世界模型推理引擎。

    支持三种推理模式：
    - 基于规则的推理（演绎推理）
    - 基于案例的推理（经验推理）
    - 类比推理（结构映射）
    """

    def __init__(self, kg_engine: Optional[KnowledgeGraphEngine] = None) -> None:
        """初始化推理引擎。

        Args:
            kg_engine: 可选的知识图谱引擎实例，若未提供则自动初始化。
        """
        self.kg_engine = kg_engine or KnowledgeGraphEngine()
        self.rules: List[InferenceRule] = []
        self.cases: List[Case] = []
        
        # 统计信息
        self._inference_count: int = 0
        self._rule_inferences: int = 0
        self._case_inferences: int = 0
        self._analogy_inferences: int = 0
        
        self._register_builtin_rules()

    def _register_builtin_rules(self) -> None:
        """注册内置的物理和社会常识推理规则。"""
        self.rules.extend([
            InferenceRule(
                name="物体受热膨胀",
                premise={"action": "heat", "target_type": "physical"},
                conclusion={"property_change": "volume_increase"},
                confidence=0.9,
                rule_type="deductive",
            ),
            InferenceRule(
                name="摩擦产生热量",
                premise={"action": "friction", "target_type": "physical"},
                conclusion={"property_change": "temperature_increase"},
                confidence=0.85,
                rule_type="deductive",
            ),
            InferenceRule(
                name="社会规范约束行为",
                premise={"action": "prohibited", "domain": "legal"},
                conclusion={"expected_outcome": "negative_consequence"},
                confidence=0.8,
                rule_type="deductive",
            ),
            InferenceRule(
                name="水源附近生物聚集",
                premise={"location_feature": "water_source"},
                conclusion={"likely_presence": "living_organisms"},
                confidence=0.75,
                rule_type="abductive",
            ),
        ])

    def register_rule(self, rule: InferenceRule) -> None:
        """注册自定义推理规则。

        Args:
            rule: 要注册的推理规则实例。
        """
        self.rules.append(rule)

    def add_case(self, situation: Dict[str, Any], 
                 outcome: Dict[str, Any], 
                 success_rate: float = 1.0) -> Case:
        """添加案例到案例库。

        Args:
            situation: 案例的情境描述。
            outcome: 案例的结果描述。
            success_rate: 该结果的成功率/置信度。

        Returns:
            创建的 Case 实例。
        """
        case = Case(situation=situation, outcome=outcome, success_rate=success_rate)
        self.cases.append(case)
        return case

    def rule_based_inference(self, facts: Dict[str, Any]) -> InferenceResult:
        """基于规则的推理：匹配前提，推出结论。

        Args:
            facts: 输入的事实字典，用于匹配规则前提。

        Returns:
            包含结论和置信度的推理结果。
        """
        self._inference_count += 1
        self._rule_inferences += 1
        
        matched_rules: List[InferenceRule] = []
        conclusions: Dict[str, List[Tuple[Any, float]]] = {}
        reasoning_path: List[str] = []

        for rule in self.rules:
            if self._premise_matches(rule.premise, facts):
                matched_rules.append(rule)
                rule.usage_count += 1
                
                for k, v in rule.conclusion.items():
                    if k not in conclusions:
                        conclusions[k] = []
                    conclusions[k].append((v, rule.confidence))
                
                reasoning_path.append(f"规则[{rule.name}]匹配，推出{rule.conclusion}")

        if not matched_rules:
            return InferenceResult(
                conclusion=None, 
                confidence=0.0,
                explanation="无匹配规则",
                inference_type="rule_based",
            )

        # 聚合结论
        final_conclusion: Dict[str, Any] = {}
        for key, candidates in conclusions.items():
            if candidates:
                avg_conf = sum(c[1] for c in candidates) / len(candidates)
                final_conclusion[key] = {
                    "value": candidates[0][0], # 取第一个匹配值作为主要结论
                    "confidence": avg_conf,
                    "alternatives": [c[0] for c in candidates[1:]] if len(candidates) > 1 else []
                }

        overall_confidence = sum(r.confidence for r in matched_rules) / len(matched_rules)
        
        return InferenceResult(
            conclusion=final_conclusion,
            confidence=overall_confidence,
            reasoning_path=reasoning_path,
            used_rules=[r.rule_id for r in matched_rules],
            explanation=f"匹配{len(matched_rules)}条规则，综合置信度{overall_confidence:.2f}",
            inference_type="rule_based",
        )

    @staticmethod
    def _premise_matches(premise: Dict[str, Any], facts: Dict[str, Any]) -> bool:
        """检查规则前提是否被事实满足。

        Args:
            premise: 规则的前提条件。
            facts: 当前事实集合。

        Returns:
            True 如果所有前提键值对都在事实中存在且匹配。
        """
        for key, value in premise.items():
            if key not in facts:
                return False
            # 简单匹配：如果值是列表，则检查事实值是否在列表中；否则直接相等
            if isinstance(value, list):
                if facts[key] not in value:
                    return False
            elif facts[key] != value:
                return False
        return True

    def case_based_inference(self, situation: Dict[str, Any], top_k: int = 3) -> InferenceResult:
        """基于案例的推理：找相似案例，推断结果。

        Args:
            situation: 当前情境描述。
            top_k: 检索的最相似案例数量。

        Returns:
            基于相似案例聚合的推理结果。
        """
        self._inference_count += 1
        self._case_inferences += 1
        
        if not self.cases:
            return InferenceResult(
                conclusion=None,
                confidence=0.0,
                explanation="案例库为空",
                inference_type="case_based",
            )

        similarities: List[Tuple[Case, float]] = []
        for case in self.cases:
            sim = self._compute_similarity(situation, case.situation)
            if sim > 0.3:  # 阈值过滤
                similarities.append((case, sim))

        if not similarities:
            return InferenceResult(
                conclusion=None, 
                confidence=0.0,
                explanation="案例库中无相似案例",
                inference_type="case_based",
            )

        # 按相似度降序排序
        similarities.sort(key=lambda x: x[1], reverse=True)
        top_cases = similarities[:top_k]
        
        weighted_outcome: Dict[str, List[Tuple[Any, float]]] = {}
        total_weight = 0.0
        reasoning_path: List[str] = []

        for case, sim in top_cases:
            weight = sim * case.success_rate
            total_weight += weight
            case.usage_count += 1
            
            for k, v in case.outcome.items():
                if k not in weighted_outcome:
                    weighted_outcome[k] = []
                weighted_outcome[k].append((v, weight))
            
            reasoning_path.append(f"相似案例[{case.case_id[:8]}]相似度={sim:.2f}")

        final_outcome = self._aggregate_outcomes(weighted_outcome)
        confidence = min(1.0, total_weight / max(1, len(top_cases)))
        
        return InferenceResult(
            conclusion=final_outcome,
            confidence=confidence,
            reasoning_path=reasoning_path,
            explanation=f"基于{len(top_cases)}个相似案例推理",
            inference_type="case_based",
        )

    def analogy_inference(self, source_domain: Dict[str, Any], 
                         target_domain: Dict[str, Any], 
                         relation: str) -> InferenceResult:
        """类比推理：基于结构映射，从源域推断目标域。

        简化的结构映射：计算源域和目标域在指定关系下的属性相似度，
        并将源域的已知结论映射到目标域。

        Args:
            source_domain: 源域的属性描述。
            target_domain: 目标域的属性描述。
            relation: 类比的映射关系标识。

        Returns:
            类比推理的结果。
        """
        self._inference_count += 1
        self._analogy_inferences += 1
        
        # 1. 计算结构相似度
        similarity = self._compute_similarity(source_domain, target_domain)
        
        if similarity < 0.2:
            return InferenceResult(
                conclusion=None,
                confidence=similarity,
                explanation="源域与目标域结构差异过大，类比失效",
                inference_type="analogy",
            )
        
        # 2. 提取源域的结论/属性，映射到目标域
        # 假设 source_domain 中除了描述性字段外，其他键值对代表可推断的属性
        mapped_conclusions = {}
        for key, value in source_domain.items():
            # 简化策略：如果 key 在 target_domain 中不存在或为 None，则尝试映射
            # 这里做一个简单的启发式映射：高相似度下，源域的特征可推断目标域具备类似特征
            if key not in target_domain or target_domain.get(key) is None:
                mapped_conclusions[key] = value
                mapped_conclusions[f"{key}_confidence"] = similarity
        
        reasoning_path = [
            f"源域({len(source_domain)}属性) -> 目标域({len(target_domain)}属性)",
            f"结构相似度: {similarity:.2f}",
            f"映射关系: {relation}"
        ]

        return InferenceResult(
            conclusion=mapped_conclusions if mapped_conclusions else None,
            confidence=similarity,
            reasoning_path=reasoning_path,
            explanation=f"通过{relation}关系进行类比推理",
            inference_type="analogy",
        )

    @staticmethod
    def _compute_similarity(d1: Dict[str, Any], d2: Dict[str, Any]) -> float:
        """计算两个字典的结构相似度。

        基于 Jaccard 系数变种，考虑键的重合度和值的相似性。

        Args:
            d1: 字典1。
            d2: 字典2。

        Returns:
            0.0 到 1.0 之间的浮点数。
        """
        if not d1 or not d2:
            return 0.0
            
        keys1 = set(d1.keys())
        keys2 = set(d2.keys())
        
        if not keys1 or not keys2:
            return 0.0
            
        intersection = keys1 & keys2
        union = keys1 | keys2
        
        if not union:
            return 0.0
            
        key_overlap = len(intersection) / len(union)
        
        # 值相似性：仅当键重合时计算
        value_score = 0.0
        if intersection:
            match_count = 0
            for k in intersection:
                v1, v2 = d1[k], d2[k]
                if v1 == v2:
                    match_count += 1
                elif isinstance(v1, (int, float)) and isinstance(v2, (int, float)):
                    # 数值型允许一定误差
                    if abs(v1 - v2) <= 0.1 * max(1, abs(v1), abs(v2)):
                        match_count += 0.5
            value_score = match_count / len(intersection)
            
        # 加权组合：键重合度权重 0.5，值匹配度权重 0.5
        similarity = 0.5 * key_overlap + 0.5 * value_score
        
        return min(1.0, max(0.0, similarity))

    @staticmethod
    def _aggregate_outcomes(weighted_outcome: Dict[str, List[Tuple[Any, float]]]) -> Dict[str, Any]:
        """聚合加权案例结果为最终输出。

        对于数值型结果进行加权平均，对于非数值型取权重最高的值。

        Args:
            weighted_outcome: 键为属性名，值为 [(属性值, 权重), ...] 的字典。

        Returns:
            聚合后的结果字典。
        """
        final_outcome: Dict[str, Any] = {}
        for key, items in weighted_outcome.items():
            if not items:
                continue
                
            numeric_vals = [(v, w) for v, w in items if isinstance(v, (int, float)) and not isinstance(v, bool)]
            
            if numeric_vals:
                total_w = sum(w for _, w in numeric_vals)
                if total_w > 0:
                    weighted_val = sum(v * w for v, w in numeric_vals) / total_w
                    final_outcome[key] = weighted_val
                else:
                    final_outcome[key] = items[0][0]
            else:
                # 非数值型：取权重最大的项
                max_item = max(items, key=lambda x: x[1])
                final_outcome[key] = max_item[0]
        
        return final_outcome
