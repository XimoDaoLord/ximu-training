"""阶段303 · 状态演化预测（state_evolution）

给定当前世界状态和行动，预测下一时刻的世界状态。
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import time
import uuid

from .representation import WorldState, Entity


@dataclass
class Action:
    """对世界施加的行动。"""
    action_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    action_type: str = ""
    actor_id: str = ""
    target_ids: List[str] = field(default_factory=list)
    parameters: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


@dataclass
class EvolutionStep:
    """一次状态演化的完整记录。"""
    step_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    previous_state: Optional[WorldState] = None
    action: Optional[Action] = None
    predicted_state: Optional[WorldState] = None
    actual_state: Optional[WorldState] = None
    prediction_error: float = 0.0
    created_at: float = field(default_factory=time.time)


@dataclass
class EvolutionRule:
    """状态演化规则（如果...则...）。

    规则包含触发条件、匹配的行动模式和效果字典。
    """
    rule_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    condition: Dict[str, Any] = field(default_factory=dict)
    action_pattern: str = ""
    effect: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0
    usage_count: int = 0


class StateEvolutionEngine:
    """状态演化预测引擎。"""

    def __init__(self, max_history: int = 1000) -> None:
        """初始化状态演化引擎

        Args:
            max_history: 历史记录最大数量，默认为1000
        """
        self.rules: List[EvolutionRule] = []
        self.max_history: int = max_history
        self._history: List[EvolutionStep] = []
        self._rule_index: Dict[str, List[EvolutionRule]] = {}
        self._prediction_count: int = 0
        self._total_error: float = 0.0

    def predict_next_state(self, current_state: WorldState,
                            action: Action) -> WorldState:
        """给定当前状态和行动，预测下一状态

        Args:
            current_state: 当前世界状态
            action: 要执行的动作

        Returns:
            预测的下一状态
        """
        predicted: WorldState = WorldState(
            entities=dict(current_state.entities),
            relations=dict(current_state.relations),
            metadata=dict(current_state.metadata),
            timestamp=time.time(),
        )
        matched_rules = self._get_matching_rules(action)
        matched_rules = [r for r in matched_rules if self._match_rule(r, current_state, action)]
        for rule in matched_rules:
            predicted = self._apply_effect(predicted, rule.effect, action)
            rule.usage_count += 1
        step: EvolutionStep = EvolutionStep(
            previous_state=current_state,
            action=action,
            predicted_state=predicted,
        )
        self._history.append(step)
        if len(self._history) > self.max_history:
            self._history.pop(0)
        self._prediction_count += 1
        return predicted

    def register_rule(self, rule: EvolutionRule) -> None:
        """注册一条演化规则

        Args:
            rule: 要注册的演化规则
        """
        self.rules.append(rule)
        if rule.action_pattern:
            self._rule_index.setdefault(rule.action_pattern, []).append(rule)

    def _get_matching_rules(self, action: Action) -> List[EvolutionRule]:
        """根据action_type快速索引匹配规则

        Args:
            action: 要匹配的动作

        Returns:
            匹配的规则列表
        """
        return self._rule_index.get(action.action_type, [])

    def learn_from_actual(self, step: EvolutionStep) -> float:
        """用实际状态验证预测，更新规则置信度，返回预测误差

        Args:
            step: 演化步骤记录，包含实际状态

        Returns:
            预测误差分数
        """
        if step.actual_state is None or step.predicted_state is None:
            return 0.0
        error: float = self._compute_state_distance(step.predicted_state, step.actual_state)
        step.prediction_error = error
        self._total_error += error
        for rule in self.rules:
            if rule.usage_count > 0:
                rule.confidence = max(0.0, min(1.0, rule.confidence - error * 0.1))
        return error

    def get_evolution_history(self, limit: int = 100) -> List[EvolutionStep]:
        """获取演化历史记录

        Args:
            limit: 返回的最大步数，默认100

        Returns:
            演化历史列表
        """
        return self._history[-limit:] if self._history else []

    def rollback(self, steps: int = 1) -> Optional[WorldState]:
        """回滚到N步前的状态

        Args:
            steps: 回滚步数

        Returns:
            回滚后的状态，若无历史记录则返回None
        """
        if steps <= 0 or not self._history:
            return None
        idx: int = max(0, len(self._history) - steps - 1)
        return self._history[idx].previous_state if idx < len(self._history) else None

    def predict_sequence_with_confidence(self, initial_state: WorldState,
                                          actions: List[Action],
                                          decay_rate: float = 0.15) -> List[Dict[str, Any]]:
        """多步推演，每步附带置信度（误差累积导致置信度递减）

        Args:
            initial_state: 初始状态
            actions: 动作列表
            decay_rate: 置信度衰减率，默认为0.15

        Returns:
            每步预测结果列表
        """
        results: List[Dict[str, Any]] = []
        current: WorldState = initial_state
        confidence: float = 1.0
        for i, action in enumerate(actions):
            predicted: WorldState = self.predict_next_state(current, action)
            step_confidence: float = confidence * (1.0 - decay_rate)
            results.append({
                "step": i + 1,
                "action": action.action_type,
                "state": predicted,
                "confidence": step_confidence,
            })
            current = predicted
            confidence = step_confidence
        return results

    def parallel_evolve(self, state: WorldState,
                         actions: List[Action]) -> List[WorldState]:
        """并行演化：每个行动独立应用于同一初始状态

        Args:
            state: 初始状态
            actions: 动作列表

        Returns:
            每个动作产生的状态列表
        """
        return [self.predict_next_state(state, a) for a in actions]

    def get_stats(self) -> Dict[str, Any]:
        """获取引擎统计信息

        Returns:
            统计字典
        """
        avg_error: float = self._total_error / max(1, self._prediction_count)
        return {
            "total_rules": len(self.rules),
            "prediction_count": self._prediction_count,
            "history_size": len(self._history),
            "average_error": round(avg_error, 4),
        }

    def simulate_sequence(self, initial_state: WorldState,
                          actions: List[Action]) -> List[WorldState]:
        """模拟一系列行动后的状态序列

        Args:
            initial_state: 初始状态
            actions: 动作列表

        Returns:
            状态序列列表
        """
        states: List[WorldState] = [initial_state]
        current: WorldState = initial_state
        for action in actions:
            next_state: WorldState = self.predict_next_state(current, action)
            states.append(next_state)
            current = next_state
        return states

    def _match_rule(self, rule: EvolutionRule, state: WorldState,
                     action: Action) -> bool:
        """检查规则是否匹配当前状态和行动

        Args:
            rule: 待检查的规则
            state: 当前状态
            action: 当前行动

        Returns:
            是否匹配
        """
        if rule.action_pattern and action.action_type != rule.action_pattern:
            return False
        for key, expected in rule.condition.items():
            if key in state.metadata and state.metadata[key] != expected:
                return False
        return True

    def _apply_effect(self, state: WorldState, effect: Dict[str, Any],
                      action: Action) -> WorldState:
        """应用规则效果到状态

        Args:
            state: 当前状态
            effect: 效果字典
            action: 触发动作

        Returns:
            更新后的状态
        """
        updated_entities = dict(state.entities)
        for entity_id, entity in updated_entities.items():
            if entity_id in action.target_ids or not action.target_ids:
                for key, value in effect.items():
                    if key in entity.attributes:
                        entity.attributes[key] = value
        return WorldState(
            entities=updated_entities,
            relations=dict(state.relations),
            metadata={**state.metadata, **effect},
            timestamp=time.time(),
        )

    def _compute_state_distance(self, s1: WorldState, s2: WorldState) -> float:
        """计算两个世界状态的距离（差异比例）

        Args:
            s1: 第一个状态
            s2: 第二个状态

        Returns:
            差异分数 [0, 1]
        """
        if not s1.entities and not s2.entities:
            return 0.0
        all_ids = set(s1.entities.keys()) | set(s2.entities.keys())
        if not all_ids:
            return 0.0
        diff_count = 0
        for eid in all_ids:
            e1 = s1.entities.get(eid)
            e2 = s2.entities.get(eid)
            if e1 is None or e2 is None:
                diff_count += 1
            elif e1.attributes != e2.attributes:
                diff_count += 1
        return diff_count / len(all_ids)
