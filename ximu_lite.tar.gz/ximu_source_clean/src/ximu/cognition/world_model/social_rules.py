# -*- coding: utf-8 -*-
"""社会规则模块：将人类社会的规则、规范、法律、习俗、伦理符号化表示，支持行动合规性检查和推理。"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from src.ximu.cognition.world_model.state_evolution import Action


class RuleDomain(Enum):
    """规则领域枚举。"""
    LEGAL = "legal"
    ETHICAL = "ethical"
    CULTURAL = "cultural"
    ORGANIZATIONAL = "organizational"
    SAFETY = "safety"
    PRIVACY = "privacy"


class RuleSeverity(Enum):
    """规则严重程度枚举。"""
    PROHIBITED = "prohibited"
    DISCOURAGED = "discouraged"
    NEUTRAL = "neutral"
    ENCOURAGED = "encouraged"
    REQUIRED = "required"


@dataclass
class SocialRule:
    """一条社会规则的数据结构。"""
    rule_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    domain: RuleDomain = RuleDomain.LEGAL
    severity: RuleSeverity = RuleSeverity.NEUTRAL
    description: str = ""
    condition: str = ""
    action_pattern: str = ""
    jurisdiction: str = "通用"
    source: str = ""
    priority: int = 0
    updated_at: float = field(default_factory=time.time)


@dataclass
class ComplianceResult:
    """行动合规性检查结果。"""
    action_id: str = ""
    is_compliant: bool = True
    violated_rules: List[SocialRule] = field(default_factory=list)
    warnings: List[SocialRule] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    checked_at: float = field(default_factory=time.time)


class SocialRuleEngine:
    """社会规则引擎：注册规则、检查合规性、查询规则、解释违规"""

    def __init__(self) -> None:
        """初始化规则引擎，注册内置基础规则。"""
        self.rules: List[SocialRule] = []
        self._check_count: int = 0
        self._violation_count: int = 0
        self._social_network: Dict[str, Dict[str, float]] = {}
        self._influence: Dict[str, float] = {}
        self._violation_history: List[Dict[str, Any]] = []
        self._register_builtin_rules()

    def _register_builtin_rules(self) -> None:
        """注册内置基础社会规则。"""
        builtin_rules: List[SocialRule] = [
            SocialRule(
                name="禁止人身伤害",
                domain=RuleDomain.LEGAL,
                severity=RuleSeverity.PROHIBITED,
                description="任何人不得对他人造成身体伤害",
                action_pattern="harm attack",
                priority=100,
                source="刑法通用条款",
                jurisdiction="通用",
            ),
            SocialRule(
                name="禁止盗窃",
                domain=RuleDomain.LEGAL,
                severity=RuleSeverity.PROHIBITED,
                description="不得未经允许占有他人财物",
                action_pattern="steal theft",
                priority=95,
                source="刑法财产相关条款",
                jurisdiction="通用",
            ),
            SocialRule(
                name="保护隐私",
                domain=RuleDomain.PRIVACY,
                severity=RuleSeverity.REQUIRED,
                description="不得未经授权收集或泄露个人隐私数据",
                action_pattern="collect_private data_leak",
                priority=90,
                source="个人信息保护法",
                jurisdiction="通用",
            ),
            SocialRule(
                name="禁止欺诈",
                domain=RuleDomain.LEGAL,
                severity=RuleSeverity.PROHIBITED,
                description="不得通过虚假陈述获取不正当利益",
                action_pattern="fraud deceive",
                priority=90,
                source="刑法诈骗条款",
                jurisdiction="通用",
            ),
            SocialRule(
                name="尊重他人",
                domain=RuleDomain.ETHICAL,
                severity=RuleSeverity.ENCOURAGED,
                description="社交互动中应尊重他人尊严",
                action_pattern="insult abuse",
                priority=50,
                source="社会公序良俗",
                jurisdiction="通用",
            ),
        ]
        self.rules.extend(builtin_rules)
        self.rules.sort(key=lambda r: r.priority, reverse=True)

    def register_rule(self, rule: SocialRule) -> None:
        """注册一条社会规则，若已存在则更新

        Args:
            rule: 要注册的规则
        """
        for i, existing in enumerate(self.rules):
            if existing.rule_id == rule.rule_id:
                self.rules[i] = rule
                return
        self.rules.append(rule)
        self.rules.sort(key=lambda r: r.priority, reverse=True)

    def check_compliance(self, action: Action, context: Dict[str, Any]) -> ComplianceResult:
        """检查一个行动在给定上下文中的合规性

        Args:
            action: 要检查的行动
            context: 上下文信息

        Returns:
            合规性检查结果
        """
        result: ComplianceResult = ComplianceResult(action_id=action.action_id)
        self._check_count += 1
        for rule in self.rules:
            if not self._match_condition(rule, action, context):
                continue
            self._evaluate_rule(rule, action, result)
        return result

    def _match_condition(self, rule: SocialRule, action: Action,
                         context: Dict[str, Any]) -> bool:
        """检查规则适用条件是否满足

        Args:
            rule: 规则对象
            action: 行动对象
            context: 上下文

        Returns:
            是否满足条件
        """
        if rule.jurisdiction != "通用" and context.get("jurisdiction", "通用") != rule.jurisdiction:
            return False
        return self._match_action_pattern(rule, action)

    def _match_action_pattern(self, rule: SocialRule, action: Action) -> bool:
        """检查行动是否匹配规则约束的行动模式

        Args:
            rule: 规则对象
            action: 行动对象

        Returns:
            是否匹配
        """
        if not rule.action_pattern:
            return True
        return rule.action_pattern.lower() in action.action_type.lower()

    def _evaluate_rule(self, rule: SocialRule, action: Action,
                       result: ComplianceResult) -> None:
        """根据规则严重程度评估行动合规性

        Args:
            rule: 规则对象
            action: 行动对象
            result: 合规性结果
        """
        if rule.severity == RuleSeverity.PROHIBITED and self._match_action_pattern(rule, action):
            result.is_compliant = False
            result.violated_rules.append(rule)
            result.suggestions.append(f"行动违反{rule.domain.value}规则：{rule.name}。建议停止此行动或寻求替代方案。")
            self._violation_count += 1
            self._violation_history.append({
                "rule": rule.name,
                "action": action.action_type,
                "time": time.time(),
            })
        elif rule.severity == RuleSeverity.DISCOURAGED and self._match_action_pattern(rule, action):
            result.warnings.append(rule)
            result.suggestions.append(f"行动不被鼓励（{rule.domain.value}）：{rule.name}。建议评估替代方案。")
        elif rule.severity == RuleSeverity.REQUIRED and not self._match_action_pattern(rule, action):
            result.warnings.append(rule)
            result.suggestions.append(f"建议执行{rule.domain.value}要求的行动：{rule.name}")

    def query_rules(self, domain: Optional[RuleDomain] = None,
                    severity: Optional[RuleSeverity] = None,
                    jurisdiction: Optional[str] = None) -> List[SocialRule]:
        """按条件查询规则

        Args:
            domain: 规则领域过滤
            severity: 严重程度过滤
            jurisdiction: 管辖区过滤

        Returns:
            匹配的规则列表
        """
        results: List[SocialRule] = []
        for rule in self.rules:
            if domain and rule.domain != domain:
                continue
            if severity and rule.severity != severity:
                continue
            if jurisdiction and rule.jurisdiction != jurisdiction and rule.jurisdiction != "通用":
                continue
            results.append(rule)
        return results

    def explain_violation(self, rule: SocialRule, action: Action) -> str:
        """生成人类可读的违规解释

        Args:
            rule: 被违反的规则
            action: 触发违规的行动

        Returns:
            违规解释文本
        """
        return (
            f"【{rule.severity.value}】{rule.name}\n"
            f"领域：{rule.domain.value}\n"
            f"描述：{rule.description}\n"
            f"来源：{rule.source}\n"
            f"管辖区：{rule.jurisdiction}\n"
            f"你的行动'{action.action_type}'触发了此规则。"
        )

    def get_stats(self) -> Dict[str, Any]:
        """获取引擎统计信息

        Returns:
            统计字典
        """
        by_domain: Dict[str, int] = {}
        by_severity: Dict[str, int] = {}
        for rule in self.rules:
            by_domain[rule.domain.value] = by_domain.get(rule.domain.value, 0) + 1
            by_severity[rule.severity.value] = by_severity.get(rule.severity.value, 0) + 1
        return {
            "total_rules": len(self.rules),
            "check_count": self._check_count,
            "violation_count": self._violation_count,
            "by_domain": by_domain,
            "by_severity": by_severity,
        }

    def set_social_influence(self, agent_id: str, influence: float) -> None:
        """设置智能体的社会影响力

        Args:
            agent_id: 智能体ID
            influence: 影响力值 [0, 1]
        """
        self._influence[agent_id] = max(0.0, min(1.0, influence))

    def set_social_network(self, agent_a: str, agent_b: str, strength: float) -> None:
        """建立或更新两个智能体之间的社会关系

        Args:
            agent_a: 智能体A的ID
            agent_b: 智能体B的ID
            strength: 关系强度 [0, 1]
        """
        self._social_network.setdefault(agent_a, {})[agent_b] = max(0.0, min(1.0, strength))
        self._social_network.setdefault(agent_b, {})[agent_a] = max(0.0, min(1.0, strength))

    def get_rule_count_by_domain(self) -> Dict[str, int]:
        """获取各领域的规则数量

        Returns:
            领域到规则数量的映射
        """
        counts: Dict[str, int] = {}
        for rule in self.rules:
            counts[rule.domain.value] = counts.get(rule.domain.value, 0) + 1
        return counts
