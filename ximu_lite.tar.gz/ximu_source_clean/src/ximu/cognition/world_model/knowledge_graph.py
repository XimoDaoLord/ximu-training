# -*- coding: utf-8 -*-
"""知识图谱模块：基于实体和关系构建结构化知识图谱，支持增量更新、子图查询、路径推理、邻居扩展。"""
from __future__ import annotations

import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from src.ximu.cognition.world_model.representation import Entity, Relation


@dataclass
class KnowledgeGraph:
    """知识图谱数据结构类

    Attributes:
        graph_id: 图谱唯一标识符
        nodes: 实体节点字典，key为实体ID
        edges: 关系边字典，key为关系ID
        adjacency: 正向邻接表，key为实体ID，value为关系ID列表
        inverse_adjacency: 反向邻接表
        created_at: 创建时间戳
    """
    graph_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    nodes: Dict[str, Entity] = field(default_factory=dict)
    edges: Dict[str, Relation] = field(default_factory=dict)
    adjacency: Dict[str, List[str]] = field(default_factory=dict)
    inverse_adjacency: Dict[str, List[str]] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)


@dataclass
class GraphQuery:
    """图谱查询条件数据类

    Attributes:
        query_id: 查询唯一标识符
        node_filters: 节点过滤条件字典
        edge_filters: 边过滤条件字典
        max_depth: 最大搜索深度
        max_results: 最大返回结果数
        query_type: 查询类型，默认 neighbors
    """
    query_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    node_filters: Dict[str, Any] = field(default_factory=dict)
    edge_filters: Dict[str, Any] = field(default_factory=dict)
    max_depth: int = 3
    max_results: int = 100
    query_type: str = "neighbors"


class KnowledgeGraphEngine:
    """知识图谱引擎：支持图谱构建、查询、路径推理

    提供实体和关系的增删改查、邻居扩展、最短路径查找、
    子图提取以及实体对齐等功能。

    Attributes:
        graph: 底层知识图谱数据
        _query_count: 累计查询次数
        _last_query_time: 最近一次查询时间戳
    """

    MAX_QUERY_RESULTS: int = 1000
    MAX_PATH_RESULTS: int = 50

    def __init__(self) -> None:
        """初始化知识图谱引擎"""
        self.graph: KnowledgeGraph = KnowledgeGraph()
        self._query_count: int = 0
        self._last_query_time: float = 0.0

    def add_entity(self, entity: Entity) -> None:
        """向图谱中添加实体节点

        Args:
            entity: 要添加的实体对象
        """
        self.graph.nodes[entity.entity_id] = entity
        self.graph.adjacency.setdefault(entity.entity_id, [])
        self.graph.inverse_adjacency.setdefault(entity.entity_id, [])

    def add_relation(self, relation: Relation) -> None:
        """向图谱中添加关系边，自动维护邻接表

        Args:
            relation: 要添加的关系对象
        """
        self.graph.edges[relation.relation_id] = relation
        self.graph.adjacency.setdefault(relation.source_id, []).append(relation.relation_id)
        self.graph.inverse_adjacency.setdefault(relation.target_id, []).append(relation.relation_id)

    def query_neighbors(self, entity_id: str, relation_type: Optional[str] = None,
                        max_depth: int = 1) -> List[Entity]:
        """查询指定实体的邻居节点，支持按关系类型过滤和多跳搜索

        Args:
            entity_id: 起始实体ID
            relation_type: 关系类型过滤，None表示不过滤
            max_depth: 最大搜索深度，默认1跳

        Returns:
            邻居实体列表
        """
        if entity_id not in self.graph.nodes:
            return []
        visited: set = {entity_id}
        result: List[Entity] = []
        queue: deque = deque([(entity_id, 0)])
        while queue and len(result) < self.MAX_QUERY_RESULTS:
            current, depth = queue.popleft()
            if depth >= max_depth:
                continue
            self._expand_neighbors(current, relation_type, visited, result, queue)
        self._query_count += 1
        self._last_query_time = time.time()
        return result

    def _expand_neighbors(self, current: str, relation_type: Optional[str],
                          visited: set, result: List[Entity], queue: deque) -> None:
        """展开当前节点的邻居并加入搜索队列

        Args:
            current: 当前实体ID
            relation_type: 关系类型过滤器
            visited: 已访问集合
            result: 结果列表
            queue: BFS搜索队列
        """
        for rel_id in self.graph.adjacency.get(current, []):
            rel = self.graph.edges.get(rel_id)
            if not rel:
                continue
            if relation_type is not None and rel.relation_type != relation_type:
                continue
            neighbor = self.graph.nodes.get(rel.target_id)
            if neighbor and neighbor.entity_id not in visited:
                visited.add(neighbor.entity_id)
                result.append(neighbor)
                queue.append((neighbor.entity_id, len(result)))

    def find_path(self, source_id: str, target_id: str,
                  max_depth: int = 5) -> List[List[str]]:
        """查找两个实体间的所有路径（BFS，最多返回50条）

        Args:
            source_id: 起始实体ID
            target_id: 目标实体ID
            max_depth: 最大路径深度

        Returns:
            路径列表，每条路径为节点ID列表
        """
        if source_id not in self.graph.nodes or target_id not in self.graph.nodes:
            return []
        paths: List[List[str]] = []
        queue: deque = deque([(source_id, [source_id])])
        while queue and len(paths) < self.MAX_PATH_RESULTS:
            current, path = queue.popleft()
            if current == target_id and len(path) > 1:
                paths.append(path)
                continue
            if len(path) > max_depth:
                continue
            self._enqueue_next(current, path, queue)
        return paths

    def _enqueue_next(self, current: str, path: List[str], queue: deque) -> None:
        """将当前节点的邻接节点加入路径搜索队列

        Args:
            current: 当前实体ID
            path: 当前路径
            queue: 搜索队列
        """
        for rel_id in self.graph.adjacency.get(current, []):
            rel = self.graph.edges.get(rel_id)
            if rel and rel.target_id not in path:
                queue.append((rel.target_id, path + [rel.target_id]))

    def extract_subgraph(self, center_id: str, max_depth: int = 2) -> KnowledgeGraph:
        """以指定实体为中心提取子图

        Args:
            center_id: 中心实体ID
            max_depth: 最大搜索深度

        Returns:
            子图对象
        """
        subgraph: KnowledgeGraph = KnowledgeGraph()
        if center_id not in self.graph.nodes:
            return subgraph
        visited: set = set()
        queue: deque = deque([(center_id, 0)])
        while queue:
            current, depth = queue.popleft()
            if depth > max_depth or current in visited:
                continue
            visited.add(current)
            entity = self.graph.nodes.get(current)
            if entity:
                subgraph.nodes[current] = entity
            for rel_id in self.graph.adjacency.get(current, []):
                rel = self.graph.edges.get(rel_id)
                if rel:
                    subgraph.edges[rel.relation_id] = rel
                    if rel.target_id not in visited:
                        queue.append((rel.target_id, depth + 1))
        return subgraph

    def get_stats(self) -> Dict[str, Any]:
        """获取图谱统计信息

        Returns:
            包含节点数、边数、平均度数、查询统计的字典
        """
        total_degree: int = sum(len(v) for v in self.graph.adjacency.values())
        node_count: int = len(self.graph.nodes)
        return {
            "node_count": node_count,
            "edge_count": len(self.graph.edges),
            "query_count": self._query_count,
            "avg_degree": total_degree / max(1, node_count),
            "last_query_time": self._last_query_time,
        }

    def find_shortest_path(self, source_id: str, target_id: str) -> Optional[List[str]]:
        """使用BFS查找最短路径

        Args:
            source_id: 起始实体ID
            target_id: 目标实体ID

        Returns:
            最短路径节点列表，不存在则返回 None
        """
        if source_id not in self.graph.nodes or target_id not in self.graph.nodes:
            return None
        visited: set = {source_id}
        queue: deque = deque([(source_id, [source_id])])
        while queue:
            current, path = queue.popleft()
            if current == target_id:
                return path
            for rel_id in self.graph.adjacency.get(current, []):
                rel = self.graph.edges.get(rel_id)
                if rel and rel.target_id not in visited:
                    visited.add(rel.target_id)
                    queue.append((rel.target_id, path + [rel.target_id]))
        return None

    def entity_alignment(self, threshold: float = 0.8) -> List[Dict[str, Any]]:
        """实体对齐：查找名称和类型相似的实体对

        Args:
            threshold: 相似度阈值，默认0.8

        Returns:
            对齐候选列表
        """
        entities: List[Entity] = list(self.graph.nodes.values())
        candidates: List[Dict[str, Any]] = []
        for i in range(len(entities)):
            for j in range(i + 1, len(entities)):
                e1, e2 = entities[i], entities[j]
                if e1.entity_type != e2.entity_type:
                    continue
                name_sim: float = self._name_similarity(e1.name, e2.name)
                if name_sim >= threshold:
                    candidates.append({
                        "entity_1": e1.entity_id,
                        "entity_2": e2.entity_id,
                        "similarity": name_sim,
                    })
        return candidates

    @staticmethod
    def _name_similarity(name1: str, name2: str) -> float:
        """计算两个名称的编辑距离相似度

        Args:
            name1: 第一个名称
            name2: 第二个名称

        Returns:
            相似度分数 [0, 1]
        """
        if not name1 or not name2:
            return 0.0
        len1, len2 = len(name1), len(name2)
        if len1 == 0 or len2 == 0:
            return 0.0
        # 简化版 Jaccard 相似度
        set1 = set(name1.lower())
        set2 = set(name2.lower())
        intersection = len(set1 & set2)
        union = len(set1 | set2)
        return intersection / union if union > 0 else 0.0

    def remove_entity(self, entity_id: str) -> bool:
        """从图谱中移除实体及其关联关系

        Args:
            entity_id: 要移除的实体ID

        Returns:
            移除成功返回 True
        """
        if entity_id not in self.graph.nodes:
            return False
        # 移除所有关联边
        rel_ids = self.graph.adjacency.pop(entity_id, [])
        for rel_id in rel_ids:
            rel = self.graph.edges.pop(rel_id, None)
            if rel:
                self.graph.inverse_adjacency.get(rel.source_id, []).remove(rel_id)
        self.graph.inverse_adjacency.pop(entity_id, None)
        self.graph.nodes.pop(entity_id)
        return True
