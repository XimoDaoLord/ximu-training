import math
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from src.ximu.cognition.world_model.state_evolution import Action


class PhysicsDomain(Enum):
    """物理规律领域枚举"""
    MECHANICS = "mechanics"
    THERMODYNAMICS = "thermodynamics"
    OPTICS = "optics"
    ELECTROMAGNETISM = "electromagnetism"
    FLUID = "fluid"
    QUANTUM = "quantum"


@dataclass
class PhysicsLaw:
    """物理规律定义"""
    law_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    domain: PhysicsDomain = PhysicsDomain.MECHANICS
    formula: str = ""
    variables: Dict[str, str] = field(default_factory=dict)
    conditions: List[str] = field(default_factory=list)
    constants: Dict[str, float] = field(default_factory=dict)


@dataclass
class PhysicalState:
    """物理实体状态"""
    entity_id: str = ""
    position: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    velocity: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    acceleration: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    mass: float = 1.0
    temperature: float = 300.0
    energy: float = 0.0
    extra: Dict[str, Any] = field(default_factory=dict)


SPEED_OF_LIGHT = 2.998e8
GRAVITY = 9.81
BOLTZMANN = 1.381e-23


class PhysicsLawEngine:
    """物理规律引擎"""

    def __init__(self) -> None:
        """初始化物理规律引擎并注册内置规律"""
        self.laws: Dict[str, PhysicsLaw] = {}
        self._violation_count = 0
        self._register_builtin_laws()

    def _register_builtin_laws(self) -> None:
        """注册内置物理规律"""
        self.laws["newton_second"] = PhysicsLaw(
            name="牛顿第二定律",
            domain=PhysicsDomain.MECHANICS,
            formula="F = m * a",
            variables={"F": "力", "m": "质量", "a": "加速度"},
            conditions=["宏观低速", "惯性参考系"],
            constants={"g": GRAVITY},
        )
        self.laws["newton_first"] = PhysicsLaw(
            name="牛顿第一定律（惯性定律）",
            domain=PhysicsDomain.MECHANICS,
            formula="F_net = 0 => v = const",
            variables={"F_net": "合力", "v": "速度"},
            conditions=["无外力作用"],
        )
        self.laws["newton_third"] = PhysicsLaw(
            name="牛顿第三定律（作用力反作用力）",
            domain=PhysicsDomain.MECHANICS,
            formula="F_ab = -F_ba",
            variables={"F_ab": "A对B的力", "F_ba": "B对A的力"},
        )
        self.laws["thermo_first"] = PhysicsLaw(
            name="热力学第一定律",
            domain=PhysicsDomain.THERMODYNAMICS,
            formula="ΔU = Q - W",
            variables={"ΔU": "内能变化", "Q": "吸收热量", "W": "对外做功"},
        )
        self.laws["thermo_second"] = PhysicsLaw(
            name="热力学第二定律",
            domain=PhysicsDomain.THERMODYNAMICS,
            formula="ΔS >= 0 (孤立系统)",
            variables={"ΔS": "熵变"},
            conditions=["孤立系统"],
        )
        self.laws["gravity"] = PhysicsLaw(
            name="万有引力定律",
            domain=PhysicsDomain.MECHANICS,
            formula="F = G * m1 * m2 / r^2",
            variables={"F": "引力", "G": "引力常数", "m1": "质量1", "m2": "质量2", "r": "距离"},
            constants={"G": 6.674e-11},
        )
        self.laws["momentum_conservation"] = PhysicsLaw(
            name="动量守恒定律",
            domain=PhysicsDomain.MECHANICS,
            formula="m1*v1 + m2*v2 = const",
            variables={"m1": "质量1", "v1": "速度1", "m2": "质量2", "v2": "速度2"},
            conditions=["无外力", "封闭系统"],
        )

    def register_law(self, law: PhysicsLaw) -> None:
        """注册一条物理规律"""
        self.laws[law.law_id] = law

    def apply_law(
        self,
        law_name: str,
        state: PhysicalState,
        params: Dict[str, float]
    ) -> PhysicalState:
        """应用物理规律计算新状态"""
        law = self.laws.get(law_name)
        if not law:
            return state

        new_state = PhysicalState(
            entity_id=state.entity_id,
            position=list(state.position),
            velocity=list(state.velocity),
            acceleration=list(state.acceleration),
            mass=state.mass,
            temperature=state.temperature,
            energy=state.energy,
            extra=dict(state.extra),
        )

        if law_name == "newton_second":
            force = params.get("F", 0.0)
            dt = params.get("dt", 0.01)
            if new_state.mass > 0:
                accel_mag = force / new_state.mass
                new_state.acceleration = [accel_mag, 0.0, 0.0]

            new_state.velocity = [
                v + a * dt for v, a in zip(new_state.velocity, new_state.acceleration)
            ]
            new_state.position = [
                p + v * dt for p, v in zip(new_state.position, new_state.velocity)
            ]
        elif law_name == "thermo_first":
            Q = params.get("Q", 0.0)
            W = params.get("W", 0.0)
            delta_e = Q - W
            new_state.energy += delta_e
            denom = max(1.0, new_state.mass * 1000)
            new_state.temperature = max(0.0, new_state.temperature + delta_e / denom)

        return new_state

    def check_violation(
        self,
        state: PhysicalState,
        action: Action
    ) -> List[str]:
        """检查行动是否违反物理规律"""
        violations: List[str] = []

        speed = math.sqrt(sum(v ** 2 for v in state.velocity))
        if speed > SPEED_OF_LIGHT:
            violations.append("超光速（违反相对论）")
            self._violation_count += 1

        if state.temperature < 0:
            violations.append("绝对零度以下（违反热力学第三定律）")
            self._violation_count += 1

        if state.mass <= 0:
            violations.append("质量非正（违反物理常识）")
            self._violation_count += 1

        return violations

    def predict_trajectory(
        self,
        initial: PhysicalState,
        forces: List[Dict[str, Any]],
        duration: float,
        dt: float = 0.01
    ) -> List[PhysicalState]:
        """预测物体在受力下的运动轨迹"""
        trajectory: List[PhysicalState] = []
        state = PhysicalState(
            entity_id=initial.entity_id,
            position=list(initial.position),
            velocity=list(initial.velocity),
            acceleration=list(initial.acceleration),
            mass=initial.mass,
            temperature=initial.temperature,
            energy=initial.energy,
            extra=dict(initial.extra),
        )

        t = 0.0
        force_idx = 0

        while t < duration and len(trajectory) < 10000:
            if 0 <= force_idx < len(forces):
                current_force = forces[force_idx]
                force_idx = min(force_idx + 1, len(forces) - 1)
            else:
                current_force = {"F": 0.0}

            state = self.apply_law(
                "newton_second",
                state,
                {"F": current_force.get("F", 0.0), "dt": dt}
            )

            trajectory.append(PhysicalState(
                entity_id=state.entity_id,
                position=list(state.position),
                velocity=list(state.velocity),
                acceleration=list(state.acceleration),
                mass=state.mass,
                temperature=state.temperature,
                energy=state.energy,
                extra={"time": t},
            ))
            t += dt

        return trajectory

    def common_laws(self) -> List[PhysicsLaw]:
        """返回常用物理规律列表"""
        return list(self.laws.values())
