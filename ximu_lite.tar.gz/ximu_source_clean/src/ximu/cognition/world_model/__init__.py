# -*- coding: utf-8 -*-
"""
卷31 · 世界模型基础（阶段301-310）
提供懒加载机制以按需导入子模块。
"""

import importlib as _importlib
import threading as _th
from typing import Any, Optional

_load_lock = _th.Lock()
_parts_modules = [
    "representation",
    "state_evolution",
    "knowledge_graph",
    "physics_laws",
    "social_rules",
    "storage",
    "learning",
    "query",
    "consistency",
    "brain_link",
    "inference",
    "simulation",
    "knowledge_base_loader",
]
_parts_loaded: dict[str, Any] = {}


def __getattr__(name: str) -> Any:
    """
    PEP 562 懒加载属性访问。

    当访问模块属性时，按需加载子模块并返回对应符号。

    Args:
        name: 要获取的属性名。

    Returns:
        对应的属性对象。

    Raises:
        AttributeError: 如果属性不存在。
    """
    if name == "WorldModel":
        name = "WorldModelQueryEngine"
    for part in _parts_modules:
        if part not in _parts_loaded:
            with _load_lock:
                if part not in _parts_loaded:
                    _parts_loaded[part] = _importlib.import_module(f".{part}", __name__)
        mod = _parts_loaded[part]
        if hasattr(mod, name):
            return getattr(mod, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "EntityType",
    "Entity",
    "Relation",
    "WorldState",
    "WorldRepresentationEngine",
    "Action",
    "EvolutionStep",
    "EvolutionRule",
    "StateEvolutionEngine",
    "KnowledgeGraph",
    "GraphQuery",
    "KnowledgeGraphEngine",
    "PhysicsDomain",
    "PhysicsLaw",
    "PhysicalState",
    "PhysicsLawEngine",
    "RuleDomain",
    "RuleSeverity",
    "SocialRule",
    "ComplianceResult",
    "SocialRuleEngine",
    "StorageConfig",
    "WorldModelSnapshot",
    "WorldModelStorage",
    "LearningSignal",
    "LearningStats",
    "WorldModelLearner",
    "WorldModelQuery",
    "WorldModelAnswer",
    "WorldModelQueryEngine",
    "WorldModel",
    "ConsistencyIssueType",
    "ConsistencyIssue",
    "ConsistencyReport",
    "ConsistencyChecker",
    "BrainWorldLink",
    "BrainDecisionRecord",
    "BrainWorldLinkEngine",
    "InferenceRule",
    "InferenceResult",
    "Case",
    "WorldModelInferenceEngine",
    "SimulationEvent",
    "SimulationAgent",
    "SimulationConfig",
    "SimulationResult",
    "WorldSimulationEngine",
    "KnowledgeBaseLoader",
    "get_knowledge_base_loader",
]
