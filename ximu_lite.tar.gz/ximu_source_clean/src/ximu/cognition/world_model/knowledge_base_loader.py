# -*- coding: utf-8 -*-
"""世界模型知识库加载器。"""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Any, Dict, List, Optional

logger = logging.getLogger("src.ximu.cognition.world_model.knowledge_base_loader")


def _cn_tokenize(text: str) -> List[str]:
    """统一中文分词口径。"""
    try:
        from src.ximu.core.memory.memory_engine import tokenize_keywords as _tk
        return _tk(text)
    except Exception:
        if not text:
            return []
        t: str = str(text).lower()
        toks: set = set()
        for w in re.findall(r"[a-z0-9]+", t):
            if w:
                toks.add(w)
        for seg in re.findall(r"[\u4e00-\u9fff]+", t):
            if len(seg) == 1:
                toks.add(seg)
            else:
                for i in range(len(seg) - 1):
                    toks.add(seg[i:i + 2])
                for ch in seg:
                    toks.add(ch)
        return list(toks)


_DEFAULT_DIR: Path = Path(__file__).resolve().parent.parent.parent / "data" / "knowledge" / "world_model"
_DEFAULT_MD_DIR: Path = Path(__file__).resolve().parents[4] / "蓝图" / "世界模型知识库"


class KnowledgeBaseLoader:
    """世界模型知识库加载器。"""

    def __init__(self, knowledge_dir: Optional[str] = None, markdown_dir: Optional[str] = None) -> None:
        """初始化知识库加载器。"""
        self._knowledge_dir: Path = Path(knowledge_dir) if knowledge_dir else _DEFAULT_DIR
        self._include_markdown: bool = (knowledge_dir is None or markdown_dir is not None)
        self._markdown_dir: Path = Path(markdown_dir) if markdown_dir else _DEFAULT_MD_DIR
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._file_mtimes: Dict[str, float] = {}
        self._errors: List[str] = []
        self._lock = Lock()
        self._loaded: bool = False
        self._index_built: bool = False
        self._load_time: Optional[datetime] = None
        self._version: str = "0.5"

    @property
    def knowledge_dir(self) -> Path:
        """返回知识库目录路径。"""
        return self._knowledge_dir

    @property
    def markdown_dir(self) -> Path:
        """返回 markdown 知识库目录路径。"""
        return self._markdown_dir

    def _list_json_files(self) -> List[Path]:
        """列出知识库目录下所有 .json 文件。"""
        if not self._knowledge_dir.exists():
            return []
        return sorted(self._knowledge_dir.glob("*.json"))

    def _list_markdown_files(self) -> List[Path]:
        """递归列出蓝图知识库目录下所有 .md 文件。"""
        if not self._include_markdown or not self._markdown_dir.exists():
            return []
        return sorted(self._markdown_dir.rglob("*.md"))

    def _ensure_loaded(self) -> None:
        """首次访问时加载全部文件。"""
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            self._load_all_locked()

    def _load_all_locked(self) -> None:
        """加载目录下所有文件。"""
        self._cache.clear()
        self._file_mtimes.clear()
        self._errors.clear()

        for filepath in self._list_json_files():
            data: Optional[Dict[str, Any]] = self._load_one(filepath)
            if data is not None:
                name: str = str(data.get("学科名称", filepath.stem))
                self._cache[name] = data
                self._save_mtime(filepath)

        for filepath in self._list_markdown_files():
            data = self._parse_markdown_file(filepath)
            if data is not None:
                name = str(data.get("学科名称", filepath.stem))
                if name in self._cache:
                    name = f"{name}@{data.get('_category', 'md')}"
                self._cache[name] = data
                self._save_mtime(filepath)

        self._index_built = False
        self._loaded = True
        self._load_time = datetime.now()
        logger.info("知识库加载完成：%d 个学科，%d 个错误", len(self._cache), len(self._errors))

    def _save_mtime(self, filepath: Path) -> None:
        """保存文件修改时间到缓存。"""
        try:
            self._file_mtimes[str(filepath)] = filepath.stat().st_mtime
        except OSError:
            self._file_mtimes[str(filepath)] = 0.0

    def _load_one(self, filepath: Path) -> Optional[Dict[str, Any]]:
        """加载单个 JSON 文件。"""
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data: Any = json.load(f)
            if not isinstance(data, dict):
                raise ValueError("JSON 根节点不是 dict")
            return data
        except (json.JSONDecodeError, OSError, ValueError, TypeError) as e:
            msg: str = f"知识库文件损坏，已跳过 {filepath.name}: {e}"
            self._errors.append(msg)
            logger.warning(msg)
            return None

    def _parse_markdown_file(self, filepath: Path) -> Optional[Dict[str, Any]]:
        """将单个学科 markdown 文件解析为统一 dict schema。"""
        try:
            text: str = filepath.read_text(encoding="utf-8")
        except OSError as e:
            self._errors.append(f"markdown 文件读取失败 {filepath.name}: {e}")
            return None

        lines: List[str] = text.splitlines()
        title: str = ""
        intro_lines: List[str] = []
        concepts: List[Dict[str, Any]] = []
        theories: List[Dict[str, Any]] = []
        section: Optional[str] = None
        sub_name: str = ""
        sub_buf: List[str] = []

        for line in lines:
            stripped: str = line.strip()
            if stripped.startswith("# "):
                title = stripped[2:].strip().replace("知识概述", "")
            elif stripped.startswith("## "):
                if sub_name:
                    self._flush_subsection(section, sub_name, sub_buf, concepts, theories)
                section = stripped[3:].strip()
                sub_name, sub_buf = "", []
            elif stripped.startswith("### "):
                if sub_name:
                    self._flush_subsection(section, sub_name, sub_buf, concepts, theories)
                sub_name = self._strip_numbering(stripped[4:].strip())
                sub_buf = []
            elif stripped:
                if section is None and not sub_name:
                    intro_lines.append(stripped)
                elif sub_name:
                    sub_buf.append(stripped)

        if sub_name:
            self._flush_subsection(section, sub_name, sub_buf, concepts, theories)

        category: str = filepath.parent.name
        name: str = title or filepath.stem
        return {
            "学科名称": name,
            "学科定义": " ".join(intro_lines)[:500],
            "核心概念": concepts,
            "关键理论": theories,
            "研究方法": [],
            "应用领域": [],
            "交叉学科": [],
            "世界模型应用价值": "",
            "数据来源": str(filepath),
            "版本": "0.5",
            "更新时间": datetime.now().isoformat(),
            "_category": category,
        }

    def _flush_subsection(self, section: Optional[str], sub_name: str, buf: List[str], concepts: List[Dict[str, Any]], theories: List[Dict[str, Any]]) -> None:
        """将缓冲的子节内容追加到对应集合。"""
        content: str = " ".join(buf)
        if section == "核心概念" or section is None:
            concepts.append({"概念": sub_name, "定义": content, "相关概念": []})
        elif section == "关键理论":
            theories.append({"理论": sub_name, "提出者": "", "核心内容": content, "应用场景": []})

    def _strip_numbering(self, text: str) -> str:
        """去除标题前编号前缀。"""
        return re.sub(r"^\d+\.\s*", "", text)
