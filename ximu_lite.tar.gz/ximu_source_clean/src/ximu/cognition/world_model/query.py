import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from src.ximu.cognition.world_model.representation import WorldState
from src.ximu.cognition.world_model.state_evolution import Action, StateEvolutionEngine
from src.ximu.cognition.world_model.knowledge_graph import KnowledgeGraphEngine
from src.ximu.cognition.world_model.storage import WorldModelStorage


@dataclass
class WorldModelQuery:
    """世界模型查询请求

    封装查询类型、自然语言/结构化参数、假设性行动及时间范围。
    """
    query_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    query_type: str = "fact"
    natural_language: str = ""
    structured: Dict[str, Any] = field(default_factory=dict)
    hypothetical_action: Optional[Action] = None
    time_range: Optional[Tuple[float, float]] = None
    max_results: int = 50
    include_confidence: bool = True


@dataclass
class WorldModelAnswer:
    """世界模型查询结果

    包含答案内容、置信度、支持实体/关系及查询耗时。
    """
    query_id: str = ""
    answer_type: str = ""
    content: Any = None
    confidence: float = 1.0
    supporting_entities: List[str] = field(default_factory=list)
    supporting_relations: List[str] = field(default_factory=list)
    query_time_ms: float = 0.0
    cached: bool = False


class WorldModelQueryEngine:
    """世界模型查询引擎

    提供统一查询入口，支持事实、关系、状态、假设性、趋势等查询类型。
    """

    def __init__(
        self,
        storage: WorldModelStorage,
        evolution_engine: Optional[StateEvolutionEngine] = None,
        kg_engine: Optional[KnowledgeGraphEngine] = None,
        cache_ttl: int = 60,
        knowledge_base: Optional[Any] = None
    ) -> None:
        """初始化查询引擎

        Args:
            storage: 世界模型存储
            evolution_engine: 状态演化引擎
            kg_engine: 知识图谱引擎
            cache_ttl: 缓存生存时间（秒）
            knowledge_base: 可选的知识库接口
        """
        self.storage = storage
        self.evolution_engine = evolution_engine or StateEvolutionEngine()
        self.kg_engine = kg_engine or KnowledgeGraphEngine()
        self.cache_ttl = cache_ttl
        self.knowledge_base = knowledge_base
        self._cache: Dict[str, Tuple[WorldModelAnswer, float]] = {}
        self._query_count = 0
        self._cache_hits = 0

    def _build_cache_key(self, query: WorldModelQuery) -> str:
        """构建缓存键

        Args:
            query: 查询对象

        Returns:
            缓存键字符串
        """
        parts = [
            query.query_type,
            json.dumps(query.structured, sort_keys=True, default=str)
        ]
        if query.hypothetical_action:
            parts.append(
                f"action:{query.hypothetical_action.action_id}:"
                f"{query.hypothetical_action.action_type}"
            )
        if query.time_range:
            parts.append(f"range:{query.time_range[0]}-{query.time_range[1]}")
        return ":".join(parts)

    def _dispatch_query(self, query: WorldModelQuery) -> WorldModelAnswer:
        """按查询类型分发到对应处理器

        Args:
            query: 查询对象

        Returns:
            查询结果
        """
        s = query.structured
        handlers = {
            "fact": lambda: self.query_fact(s.get("entity_name", ""), s.get("attribute", "")),
            "relation": lambda: self.query_relation(s.get("entity1", ""), s.get("entity2", "")),
            "state": lambda: self.query_state(s.get("timestamp")),
            "hypothetical": (
                lambda: self.query_hypothetical(query.hypothetical_action)
                if query.hypothetical_action
                else self._unsupported(query)
            ),
            "trend": lambda: self.query_trend(
                s.get("entity_id", ""),
                s.get("attribute", ""),
                s.get("start_time", 0.0),
                s.get("end_time", time.time())
            ),
            "knowledge": lambda: self.query_knowledge(
                s.get("query", ""), s.get("discipline_id", "")
            ),
            "multihop": lambda: self.query_multihop(
                s.get("start_entity", ""), s.get("relation_path", [])
            ),
            "neighbors": lambda: self.query_neighbors(
                s.get("entity_name", ""),
                s.get("relation_type"),
                s.get("max_depth", 1)
            ),
            "compare": lambda: self.query_compare(
                s.get("entity1", ""), s.get("entity2", "")
            ),
        }

        handler = handlers.get(query.query_type)
        if handler is None:
            return self._unsupported(query)
        return handler()

    @staticmethod
    def _unsupported(query: WorldModelQuery) -> WorldModelAnswer:
        """返回不支持类型的错误答案

        Args:
            query: 查询对象

        Returns:
            错误答案
        """
        return WorldModelAnswer(
            answer_type="error",
            content=f"不支持的查询类型: {query.query_type}",
            confidence=0.0,
        )

    def query(self, query: WorldModelQuery) -> WorldModelAnswer:
        """统一查询入口

        Args:
            query: 查询请求

        Returns:
            查询结果
        """
        start = time.monotonic()
        self._query_count += 1
        cache_key = self._build_cache_key(query)
        
        if cache_key in self._cache:
            answer, ts = self._cache[cache_key]
            if time.monotonic() - ts < self.cache_ttl:
                answer.cached = True
                answer.query_time_ms = (time.monotonic() - start) * 1000
                self._cache_hits += 1
                return answer

        answer = self._dispatch_query(query)
        answer.query_id = query.query_id
        answer.query_time_ms = (time.monotonic() - start) * 1000
        self._cache[cache_key] = (answer, time.monotonic())
        return answer

    def query_fact(
        self,
        entity_name: str,
        attribute: str
    ) -> WorldModelAnswer:
        """查询事实：某实体的某属性值

        Args:
            entity_name: 实体名称
            attribute: 属性名称

        Returns:
            查询结果
        """
        entities = self.storage.search_entities(entity_name, limit=1)
        if not entities:
            return WorldModelAnswer(
                answer_type="fact", content=None, confidence=0.0
            )
        
        entity = entities[0]
        value = entity.attributes.get(attribute)
        return WorldModelAnswer(
            answer_type="fact",
            content=value,
            confidence=entity.confidence,
            supporting_entities=[entity.entity_id],
        )

    def query_relation(
        self,
        entity1_name: str,
        entity2_name: str
    ) -> WorldModelAnswer:
        """查询关系：两个实体间的关系路径

        Args:
            entity1_name: 实体1名称
            entity2_name: 实体2名称

        Returns:
            查询结果
        """
        e1 = self.storage.search_entities(entity1_name, limit=1)
        e2 = self.storage.search_entities(entity2_name, limit=1)
        
        if not e1 or not e2:
            return WorldModelAnswer(
                answer_type="relation", content=[], confidence=0.0
            )

        paths = self.kg_engine.find_path(e1[0].entity_id, e2[0].entity_id)
        return WorldModelAnswer(
            answer_type="relation",
            content=paths,
            confidence=0.8 if paths else 0.0,
            supporting_entities=[e1[0].entity_id, e2[0].entity_id],
        )

    def query_state(self, timestamp: Optional[float] = None) -> WorldModelAnswer:
        """查询状态：某时刻的世界状态摘要

        Args:
            timestamp: 时间戳，None 则使用当前时间

        Returns:
            查询结果
        """
        stats = self.storage.get_stats()
        return WorldModelAnswer(
            answer_type="state",
            content={
                "entity_count": stats.get("entity_count", 0),
                "relation_count": stats.get("relation_count", 0),
                "timestamp": timestamp or time.time(),
            },
            confidence=1.0,
        )

    def query_hypothetical(self, action: Action) -> WorldModelAnswer:
        """假设性查询：如果执行这个行动，世界会怎样

        Args:
            action: 假设性行动

        Returns:
            查询结果
        """
        current_state = WorldState()
        predicted = self.evolution_engine.predict_next_state(current_state, action)
        return WorldModelAnswer(
            answer_type="hypothetical",
            content=predicted,
            confidence=0.7,
            supporting_entities=list(predicted.entities.keys())[:10],
        )

    def query_trend(
        self,
        entity_id: str,
        attribute: str,
        start_time: float,
        end_time: float
    ) -> WorldModelAnswer:
        """趋势查询：某实体属性随时间的变化趋势

        Args:
            entity_id: 实体ID
            attribute: 属性名称
            start_time: 起始时间
            end_time: 结束时间

        Returns:
            查询结果
        """
        entity = self.storage.get_entity(entity_id)
        if not entity:
            return WorldModelAnswer(
                answer_type="trend", content=[], confidence=0.0
            )
        
        history = self.storage.get_entity_history(entity_id)
        if not history:
            return WorldModelAnswer(
                answer_type="trend", content=[], confidence=0.0
            )
        
        trend_data = [
            point for point in history
            if start_time <= point.get("timestamp", 0.0) <= end_time
        ]
        
        return WorldModelAnswer(
            answer_type="trend",
            content=trend_data,
            confidence=0.9 if trend_data else 0.0,
            supporting_entities=[entity_id],
        )

    def query_knowledge(
        self,
        query_text: str,
        discipline_id: str
    ) -> WorldModelAnswer:
        """知识库查询

        Args:
            query_text: 查询文本
            discipline_id: 学科ID

        Returns:
            查询结果
        """
        if not self.knowledge_base:
            return WorldModelAnswer(
                answer_type="knowledge",
                content="知识库未配置",
                confidence=0.0
            )
        
        results = self.knowledge_base.search(query_text, discipline_id)
        return WorldModelAnswer(
            answer_type="knowledge",
            content=results,
            confidence=0.8 if results else 0.0
        )

    def query_multihop(
        self,
        start_entity: str,
        relation_path: List[str]
    ) -> WorldModelAnswer:
        """多跳查询

        Args:
            start_entity: 起始实体
            relation_path: 关系路径

        Returns:
            查询结果
        """
        if not relation_path:
            return WorldModelAnswer(
                answer_type="multihop", content=[], confidence=0.0
            )
        
        entities = self.storage.search_entities(start_entity, limit=1)
        if not entities:
            return WorldModelAnswer(
                answer_type="multihop", content=[], confidence=0.0
            )
        
        current_id = entities[0].entity_id
        path_results: List[str] = [start_entity]
        
        for rel_type in relation_path:
            next_entities = self.storage.find_relations(current_id, rel_type)
            if not next_entities:
                break
            current_id = next_entities[0]
            path_results.append(current_id)
        
        return WorldModelAnswer(
            answer_type="multihop",
            content=path_results,
            confidence=0.6 if len(path_results) > 1 else 0.0,
            supporting_entities=path_results,
        )

    def query_neighbors(
        self,
        entity_name: str,
        relation_type: Optional[str] = None,
        max_depth: int = 1
    ) -> WorldModelAnswer:
        """邻居查询

        Args:
            entity_name: 实体名称
            relation_type: 关系类型，None 表示所有类型
            max_depth: 最大深度

        Returns:
            查询结果
        """
        entities = self.storage.search_entities(entity_name, limit=1)
        if not entities:
            return WorldModelAnswer(
                answer_type="neighbors", content=[], confidence=0.0
            )
        
        neighbors = self.kg_engine.get_neighbors(
            entities[0].entity_id,
            relation_type=relation_type,
            depth=max_depth
        )
        
        return WorldModelAnswer(
            answer_type="neighbors",
            content=neighbors,
            confidence=0.8 if neighbors else 0.0,
            supporting_entities=[n.get("entity_id") for n in neighbors if isinstance(n, dict)]
        )

    def query_compare(
        self,
        entity1_name: str,
        entity2_name: str
    ) -> WorldModelAnswer:
        """对比查询

        Args:
            entity1_name: 实体1名称
            entity2_name: 实体2名称

        Returns:
            查询结果
        """
        e1_list = self.storage.search_entities(entity1_name, limit=1)
        e2_list = self.storage.search_entities(entity2_name, limit=1)
        
        if not e1_list or not e2_list:
            return WorldModelAnswer(
                answer_type="compare", content=[], confidence=0.0
            )
        
        e1, e2 = e1_list[0], e2_list[0]
        comparison = {
            "entity1": {
                "id": e1.entity_id,
                "name": e1.name,
                "attributes": e1.attributes,
            },
            "entity2": {
                "id": e2.entity_id,
                "name": e2.name,
                "attributes": e2.attributes,
            },
            "common_attributes": {
                k: v for k, v in e1.attributes.items()
                if k in e2.attributes and e1.attributes[k] == e2.attributes.get(k)
            },
        }
        
        return WorldModelAnswer(
            answer_type="compare",
            content=comparison,
            confidence=0.9,
            supporting_entities=[e1.entity_id, e2.entity_id],
        )
