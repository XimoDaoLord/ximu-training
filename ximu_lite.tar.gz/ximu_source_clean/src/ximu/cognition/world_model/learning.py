import time
import uuid
import logging
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from src.ximu.cognition.world_model.representation import Entity, EntityType, Relation
from src.ximu.cognition.world_model.state_evolution import EvolutionStep
from src.ximu.cognition.world_model.storage import WorldModelStorage

logger = logging.getLogger(__name__)


@dataclass
class LearningSignal:
    """学习信号

    封装世界模型更新所需的输入信息，包括类型、来源、载荷及置信度。
    """
    signal_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    signal_type: str = ""
    source: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.5
    timestamp: float = field(default_factory=time.time)
    processed: bool = False
    retry_count: int = 0


@dataclass
class LearningStats:
    """学习统计

    记录学习过程中的信号总数、新学习实体/关系数、规则更新次数等指标。
    """
    total_signals: int = 0
    new_entities_learned: int = 0
    new_relations_learned: int = 0
    rules_updated: int = 0
    errors_corrected: int = 0
    rejected_signals: int = 0
    last_update: float = field(default_factory=time.time)


class WorldModelLearner:
    """世界模型学习器

    接收学习信号并批量处理，从预测误差和用户反馈中提取学习信号，
    更新底层世界模型。线程安全。
    """

    def __init__(
        self,
        storage: WorldModelStorage,
        confidence_threshold: float = 0.6,
        max_retries: int = 3
    ) -> None:
        """初始化世界模型学习器

        Args:
            storage: 世界模型存储实例
            confidence_threshold: 信号接受的最小置信度阈值
            max_retries: 信号处理失败后的最大重试次数

        Raises:
            ValueError: 参数非法时
        """
        if not 0.0 <= confidence_threshold <= 1.0:
            raise ValueError(
                f"confidence_threshold must be in [0, 1], got {confidence_threshold}"
            )
        if max_retries < 0:
            raise ValueError(f"max_retries must be >= 0, got {max_retries}")

        self.storage = storage
        self.confidence_threshold = confidence_threshold
        self.max_retries = max_retries
        self.pending_signals: List[LearningSignal] = []
        self.dead_letter_signals: List[LearningSignal] = []
        self.stats = LearningStats()
        self._learning_log: List[Dict[str, Any]] = []
        self._lock = threading.RLock()

    def ingest_signal(self, signal: LearningSignal) -> bool:
        """接收一个学习信号

        线程安全。若置信度低于阈值则拒绝，否则加入待处理队列。

        Args:
            signal: 学习信号实例

        Returns:
            是否接受该信号
        """
        with self._lock:
            if signal.confidence < self.confidence_threshold:
                logger.debug(
                    "Rejected signal %s: confidence %.3f below threshold %.3f",
                    signal.signal_id, signal.confidence, self.confidence_threshold
                )
                self.stats.rejected_signals += 1
                return False

            self.pending_signals.append(signal)
            self.stats.total_signals += 1
            logger.debug(
                "Accepted signal %s (type=%s, source=%s, confidence=%.3f)",
                signal.signal_id, signal.signal_type, signal.source, signal.confidence
            )
            return True

    def process_pending_signals(self) -> LearningStats:
        """批量处理待处理的学习信号

        线程安全。处理失败增加重试计数，超过最大重试次数进入死信队列。

        Returns:
            更新后的学习统计信息
        """
        with self._lock:
            for signal in self.pending_signals:
                if signal.processed:
                    continue

                try:
                    self._process_single_signal(signal)
                    signal.processed = True
                except Exception as exc:
                    signal.retry_count += 1
                    signal.processed = False
                    logger.warning(
                        "Failed to process signal %s (retry %d/%d): %s",
                        signal.signal_id, signal.retry_count, self.max_retries, exc,
                        exc_info=True
                    )
                    if signal.retry_count >= self.max_retries:
                        self.dead_letter_signals.append(signal)
                        signal.processed = True
                        logger.error(
                            "Signal %s moved to dead letter queue after %d retries",
                            signal.signal_id, signal.retry_count
                        )

            self.stats.last_update = time.time()
            self.pending_signals = [s for s in self.pending_signals if not s.processed]
            return self.stats

    def _process_single_signal(self, signal: LearningSignal) -> None:
        """处理单个学习信号

        根据信号类型执行相应的模型更新操作。

        Args:
            signal: 要处理的学习信号

        Raises:
            KeyError: new_relation 类型缺少必需字段时
            Exception: 其他处理异常
        """
        if signal.signal_type == "new_entity":
            entity_type_str = signal.payload.get("type", "abstract")
            try:
                entity_type = EntityType(entity_type_str)
            except (ValueError, KeyError):
                logger.warning(
                    "Unknown entity type '%s' in signal %s, falling back to CONCEPT",
                    entity_type_str, signal.signal_id
                )
                entity_type = EntityType.CONCEPT

            name = signal.payload.get("name", "unknown")
            attributes = signal.payload.get("attributes", {})
            if not isinstance(attributes, dict):
                logger.warning(
                    "Entity attributes in signal %s is not a dict, using empty dict",
                    signal.signal_id
                )
                attributes = {}

            entity = Entity(
                entity_type=entity_type,
                name=name,
                attributes=attributes,
                confidence=signal.confidence,
            )
            self.storage.save_entity(entity)
            self.stats.new_entities_learned += 1
            self._log_learning("new_entity", entity.entity_id, signal.confidence)
            logger.info(
                "Learned new entity '%s' (type=%s) from signal %s",
                entity.name,
                getattr(entity.entity_type, "value", entity.entity_type),
                signal.signal_id
            )

        elif signal.signal_type == "new_relation":
            source_id = signal.payload.get("source_id")
            target_id = signal.payload.get("target_id")
            if source_id is None or target_id is None:
                raise KeyError(
                    f"Signal {signal.signal_id} of type 'new_relation' missing required fields "
                    f"'source_id' or 'target_id'"
                )

            relation = Relation(
                source_id=source_id,
                target_id=target_id,
                relation_type=signal.payload.get("relation_type", "related_to"),
                weight=signal.confidence,
            )
            self.storage.save_relation(relation)
            self.stats.new_relations_learned += 1
            self._log_learning("new_relation", relation.relation_id, signal.confidence)
            logger.info(
                "Learned new relation %s->%s from signal %s",
                source_id, target_id, signal.signal_id
            )

        else:
            logger.debug("Signal %s of unknown type '%s' skipped", 
                        signal.signal_id, signal.signal_type)

    def _log_learning(
        self,
        signal_type: str,
        entity_id: str,
        confidence: float
    ) -> None:
        """记录学习日志

        Args:
            signal_type: 信号类型
            entity_id: 实体/关系ID
            confidence: 置信度
        """
        self._learning_log.append({
            "type": signal_type,
            "id": entity_id,
            "confidence": confidence,
            "timestamp": time.time(),
        })
