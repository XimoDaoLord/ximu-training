import hashlib
import time
import uuid
from enum import Enum
from collections import OrderedDict
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field


class EntityType(Enum):
    """实体类型枚举

    定义世界模型中实体的分类：对象、智能体、概念等。
    """
    OBJECT = "object"
    AGENT = "agent"
    CONCEPT = "concept"
    EVENT = "event"
    LOCATION = "location"
    STATE = "state"


@dataclass
class Entity:
    """实体

    表示世界模型中的基本对象，包含属性、嵌入向量及置信度。
    """
    entity_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    entity_type: EntityType = EntityType.CONCEPT
    name: str = ""
    attributes: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    confidence: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        """将实体对象转换为字典表示

        Returns:
            包含所有公共属性的字典
        """
        return {
            "entity_id": self.entity_id,
            "entity_type": self.entity_type.value,
            "name": self.name,
            "attributes": self.attributes,
            "embedding": self.embedding,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "confidence": self.confidence,
        }


@dataclass
class Relation:
    """关系

    表示两个实体之间的关联，包含类型、权重及反向关系类型。
    """
    relation_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    source_id: str = ""
    target_id: str = ""
    relation_type: str = ""
    weight: float = 1.0
    attributes: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    confidence: float = 1.0
    inverse_type: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """将关系对象转换为字典表示

        Returns:
            包含所有公共属性的字典
        """
        return {
            "relation_id": self.relation_id,
            "source_id": self.source_id,
            "target_id": self.target_id,
            "relation_type": self.relation_type,
            "weight": self.weight,
            "attributes": self.attributes,
            "created_at": self.created_at,
            "confidence": self.confidence,
            "inverse_type": self.inverse_type,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Relation":
        """从字典创建关系实例

        Args:
            data: 源字典

        Returns:
            新的关系实例
        """
        return cls(
            relation_id=data.get("relation_id", str(uuid.uuid4())),
            source_id=data.get("source_id", ""),
            target_id=data.get("target_id", ""),
            relation_type=data.get("relation_type", ""),
            weight=data.get("weight", 1.0),
            attributes=data.get("attributes", {}),
            created_at=data.get("created_at", time.time()),
            confidence=data.get("confidence", 1.0),
            inverse_type=data.get("inverse_type", ""),
        )


@dataclass
class WorldState:
    """世界状态快照

    封装某时刻的实体集合、关系集合及元数据。
    """
    state_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: float = field(default_factory=time.time)
    entities: Dict[str, Entity] = field(default_factory=dict)
    relations: Dict[str, Relation] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def add_entity(self, entity: Entity) -> None:
        """添加实体到世界状态

        Args:
            entity: 要添加的实体实例
        """
        self.entities[entity.entity_id] = entity

    def add_relation(self, relation: Relation) -> None:
        """添加关系到世界状态

        Args:
            relation: 要添加的关系实例
        """
        self.relations[relation.relation_id] = relation

    def get_entity(self, entity_id: str) -> Optional[Entity]:
        """根据ID获取实体

        Args:
            entity_id: 实体ID

        Returns:
            对应的实体实例，不存在则返回None
        """
        return self.entities.get(entity_id)

    def entity_count(self) -> int:
        """获取实体数量

        Returns:
            世界状态中实体的总数
        """
        return len(self.entities)

    def relation_count(self) -> int:
        """获取关系数量

        Returns:
            世界状态中关系的总数
        """
        return len(self.relations)

    def to_dict(self) -> Dict[str, Any]:
        """序列化世界状态为字典

        Returns:
            包含所有字段的字典表示
        """
        return {
            "state_id": self.state_id,
            "timestamp": self.timestamp,
            "entities": {
                eid: e.to_dict() for eid, e in self.entities.items()
            },
            "relations": {
                rid: r.to_dict() for rid, r in self.relations.items()
            },
            "metadata": dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorldState":
        """从字典反序列化世界状态

        Args:
            data: 源字典

        Returns:
            新的世界状态实例
        """
        entities: Dict[str, Entity] = {}
        for eid, edata in data.get("entities", {}).items():
            try:
                etype = EntityType(edata.get("entity_type", "concept"))
            except ValueError:
                etype = EntityType.CONCEPT
            
            entities[eid] = Entity(
                entity_id=eid,
                entity_type=etype,
                name=edata.get("name", ""),
                attributes=edata.get("attributes", {}),
                embedding=edata.get("embedding"),
                created_at=edata.get("created_at", time.time()),
                updated_at=edata.get("updated_at", time.time()),
                confidence=edata.get("confidence", 1.0),
            )

        relations: Dict[str, Relation] = {}
        for rid, rdata in data.get("relations", {}).items():
            rdata_copy = dict(rdata)
            rdata_copy["relation_id"] = rid
            relations[rid] = Relation.from_dict(rdata_copy)

        return cls(
            state_id=data.get("state_id", str(uuid.uuid4())),
            timestamp=data.get("timestamp", time.time()),
            entities=entities,
            relations=relations,
            metadata=data.get("metadata", {}),
        )

    def diff(self, other: "WorldState") -> Dict[str, Any]:
        """计算与另一个状态的差异

        Args:
            other: 用于比较的世界状态实例

        Returns:
            包含实体和关系差异的字典
        """
        added_entities = set(other.entities.keys()) - set(self.entities.keys())
        removed_entities = set(self.entities.keys()) - set(other.entities.keys())
        common_entities = set(self.entities.keys()) & set(other.entities.keys())
        
        modified_entities: Dict[str, Dict[str, Any]] = {}
        for eid in common_entities:
            e1 = self.entities[eid]
            e2 = other.entities[eid]
            if e1.attributes != e2.attributes or e1.name != e2.name:
                changed_attrs: Dict[str, Dict[str, Any]] = {}
                all_keys = set(e1.attributes.keys()) | set(e2.attributes.keys())
                for k in all_keys:
                    if e1.attributes.get(k) != e2.attributes.get(k):
                        changed_attrs[k] = {
                            "old": e1.attributes.get(k),
                            "new": e2.attributes.get(k),
                        }
                modified_entities[eid] = changed_attrs
        
        added_relations = set(other.relations.keys()) - set(self.relations.keys())
        removed_relations = set(self.relations.keys()) - set(other.relations.keys())
        
        return {
            "entity_added": list(added_entities),
            "entity_removed": list(removed_entities),
            "entity_modified": modified_entities,
            "relation_added": list(added_relations),
            "relation_removed": list(removed_relations),
            "total_changes": (
                len(added_entities) + len(removed_entities) + len(modified_entities)
                + len(added_relations) + len(removed_relations)
            ),
        }


class _LRUCache:
    """简单LRU缓存，限制内存占用"""
    __slots__ = ('_data', '_maxsize')

    def __init__(self, maxsize: int = 1000) -> None:
        """初始化LRU缓存

        Args:
            maxsize: 缓存最大容量，默认为1000
        """
        self._data: OrderedDict = OrderedDict()
        self._maxsize = maxsize

    def get(self, key: str) -> Optional[Any]:
        """根据键获取值，命中则刷新LRU顺序

        Args:
            key: 缓存键

        Returns:
            缓存值或None
        """
        if key in self._data:
            self._data.move_to_end(key)
            return self._data[key]
        return None

    def set(self, key: str, value: Any) -> None:
        """设置缓存值，超出容量时淘汰最久未使用项

        Args:
            key: 缓存键
            value: 缓存值
        """
        self._data[key] = value
        self._data.move_to_end(key)
        if len(self._data) > self._maxsize:
            self._data.popitem(last=False)

    def delete(self, key: str) -> None:
        """删除缓存项

        Args:
            key: 缓存键
        """
        self._data.pop(key, None)
