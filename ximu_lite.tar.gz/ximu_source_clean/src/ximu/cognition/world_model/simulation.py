# -*- coding: utf-8 -*-
"""世界模型层面的模拟引擎。

提供场景构建、时间步进、事件系统和多智能体交互功能，
聚焦于世界状态的演化推演和多实体交互。
"""
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("src.ximu.cognition.world_model.simulation")

from src.ximu.cognition.world_model.representation import (
    Entity,
    Relation,
    WorldState,
)
from src.ximu.cognition.world_model.state_evolution import (
    Action,
    StateEvolutionEngine,
)


@dataclass
class SimulationEvent:
    """模拟中的事件。"""

    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    event_type: str = ""
    timestamp: float = 0.0
    source_entity: str = ""
    target_entities: List[str] = field(default_factory=list)
    parameters: Dict[str, Any] = field(default_factory=dict)
    processed: bool = False


@dataclass
class SimulationAgent:
    """模拟中的智能体。"""

    agent_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    entity: Optional[Entity] = None
    strategy: str = "random"
    state: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SimulationConfig:
    """模拟配置。"""

    duration: float = 10.0
    time_step: float = 0.1
    max_events: int = 10000
    record_trajectory: bool = True
    random_seed: int = 42


@dataclass
class SimulationResult:
    """模拟结果。"""

    result_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    config: Optional[SimulationConfig] = None
    initial_state: Optional[WorldState] = None
    final_state: Optional[WorldState] = None
    trajectory: List[WorldState] = field(default_factory=list)
    events: List[SimulationEvent] = field(default_factory=list)
    total_steps: int = 0
    elapsed_time: float = 0.0
    stats: Dict[str, Any] = field(default_factory=dict)


class WorldSimulationEngine:
    """世界模型模拟引擎。

    在世界模型层面执行模拟，支持场景构建、时间步进、事件系统
    和多智能体交互等功能。
    """

    def __init__(self, evolution_engine: Optional[StateEvolutionEngine] = None) -> None:
        """初始化世界模型模拟引擎。

        Args:
            evolution_engine: 状态演化引擎，默认创建新的实例。
        """
        self.evolution: StateEvolutionEngine = evolution_engine or StateEvolutionEngine()
        self.event_handlers: Dict[str, Callable[[WorldState, SimulationEvent], Optional[WorldState]]] = {}
        self.agents: Dict[str, SimulationAgent] = {}
        self._event_queue: List[SimulationEvent] = []
        self._simulation_count: int = 0

    def register_event_handler(
        self,
        event_type: str,
        handler: Callable[[WorldState, SimulationEvent], Optional[WorldState]],
    ) -> None:
        """注册事件处理器。

        Args:
            event_type: 事件类型名称。
            handler: 处理函数，接收当前状态和事件，返回新状态或 None。
        """
        self.event_handlers[event_type] = handler

    def add_agent(self, agent: SimulationAgent) -> None:
        """添加模拟智能体。

        Args:
            agent: 要添加的智能体实例。
        """
        self.agents[agent.agent_id] = agent

    def schedule_event(self, event: SimulationEvent) -> None:
        """调度一个事件到事件队列。

        Args:
            event: 要调度的事件。
        """
        self._event_queue.append(event)
        self._event_queue.sort(key=lambda e: e.timestamp)

    def build_scene(
        self,
        entities: List[Entity],
        relations: Optional[List[Relation]] = None,
    ) -> WorldState:
        """构建初始场景（世界状态）。

        Args:
            entities: 实体列表。
            relations: 关系列表，可选。

        Returns:
            构建好的初始世界状态。
        """
        state = WorldState(timestamp=time.time())
        for entity in entities:
            state.add_entity(entity)
        for rel in relations or []:
            state.add_relation(rel)
        return state

    def step(self, state: WorldState, current_time: float, dt: float) -> WorldState:
        """执行一个时间步。

        Args:
            state: 当前世界状态。
            current_time: 当前模拟时间。
            dt: 时间步长。

        Returns:
            推进后的新状态。
        """
        new_state = WorldState(
            entities=dict(state.entities),
            relations=dict(state.relations),
            metadata=dict(state.metadata),
            timestamp=current_time + dt,
        )
        events_at_t = [
            e for e in self._event_queue
            if e.timestamp <= current_time + dt and not e.processed
        ]
        for event in events_at_t:
            handler = self.event_handlers.get(event.event_type)
            if handler is not None:
                try:
                    result = handler(new_state, event)
                    if result is not None:
                        new_state = result
                except Exception as e:
                    logger.debug("事件处理失败: %s", e, exc_info=True)
            event.processed = True
        self._event_queue = [e for e in self._event_queue if not e.processed]
        return new_state

    def run(
        self,
        initial_state: WorldState,
        config: Optional[SimulationConfig] = None,
    ) -> SimulationResult:
        """运行完整模拟。

        Args:
            initial_state: 初始世界状态。
            config: 模拟配置，默认使用 SimulationConfig()。

        Returns:
            模拟结果。
        """
        config = config or SimulationConfig()
        self._simulation_count += 1
        start_time = time.monotonic()
        result = SimulationResult(config=config, initial_state=initial_state)
        current = initial_state
        t = 0.0
        steps = 0

        if config.record_trajectory:
            result.trajectory.append(current)

        while t < config.duration and steps < config.max_events:
            current = self.step(current, t, config.time_step)
            t += config.time_step
            steps += 1
            if config.record_trajectory:
                result.trajectory.append(WorldState(
                    entities=dict(current.entities),
                    relations=dict(current.relations),
                    metadata=dict(current.metadata),
                    timestamp=current.timestamp,
                ))

        result.final_state = current
        result.total_steps = steps
        result.elapsed_time = time.monotonic() - start_time
        result.events = list(self._event_queue)
        result.stats = self._compute_stats(result)
        return result

    def simulate_multi_agent(
        self,
        initial_state: WorldState,
        agent_actions: Dict[str, List[Action]],
        steps: int = 10,
    ) -> SimulationResult:
        """多智能体交互模拟。

        Args:
            initial_state: 初始世界状态。
            agent_actions: {agent_id: [Action列表]} 的动作映射。
            steps: 模拟步数。

        Returns:
            模拟结果。
        """
        self._simulation_count += 1
        start_time = time.monotonic()
        result = SimulationResult(initial_state=initial_state)
        current = initial_state
        result.trajectory.append(current)
        action_history: Dict[str, int] = {aid: 0 for aid in agent_actions}

        for _ in range(steps):
            step_actions: List[Action] = []
            for agent_id, actions in agent_actions.items():
                idx = action_history.get(agent_id, 0)
                if idx < len(actions):
                    step_actions.append(actions[idx])
                    action_history[agent_id] = idx + 1
            for action in step_actions:
                predicted = self.evolution.predict_next_state(current, action)
                if predicted is not None:
                    current = predicted
            result.trajectory.append(WorldState(
                entities=dict(current.entities),
                relations=dict(current.relations),
                metadata=dict(current.metadata),
                timestamp=time.time(),
            ))

        result.final_state = current
        result.total_steps = steps
        result.elapsed_time = time.monotonic() - start_time
        result.stats = self._compute_stats(result)
        return result

    def _compute_stats(self, result: SimulationResult) -> Dict[str, Any]:
        """计算模拟统计信息。

        Args:
            result: 模拟结果对象。

        Returns:
            统计信息字典。
        """
        return {
            "total_steps": result.total_steps,
            "elapsed_time": result.elapsed_time,
            "trajectory_length": len(result.trajectory),
            "event_count": len(result.events),
        }