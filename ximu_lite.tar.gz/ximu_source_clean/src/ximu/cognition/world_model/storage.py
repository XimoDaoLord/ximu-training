# 状态: [OK] 已实现
# 蓝图: 卷31 阶段306 世界模型持久化存储
"""世界模型存储模块：将实体、关系、状态、规则持久化存储，支持增删改查、版本管理、时间旅行。"""
import hashlib
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from src.ximu.cognition.world_model.representation import Entity, Relation


@dataclass
class StorageConfig:
    """存储配置

    Attributes:
        backend: 存储后端类型，默认为 "memory"。
        db_path: 数据库文件路径，默认为 "./data/world_model.db"。
        max_entities: 最大实体数量，默认为 10,000,000。
        max_relations: 最大关系数量，默认为 50,000,000。
        snapshot_interval: 快照间隔（秒），默认为 3600。
        retention_days: 数据保留天数，默认为 90。
    """
    backend: str = "memory"
    db_path: str = "./data/world_model.db"
    max_entities: int = 10_000_000
    max_relations: int = 50_000_000
    snapshot_interval: int = 3600
    retention_days: int = 90


@dataclass
class WorldModelSnapshot:
    """世界模型的完整快照

    Attributes:
        snapshot_id: 快照唯一标识符，默认生成 UUID。
        timestamp: 快照创建时间戳，默认为当前时间。
        entity_count: 快照中的实体数量。
        relation_count: 快照中的关系数量。
        rule_count: 快照中的规则数量。
        storage_path: 快照存储路径。
        checksum: 快照校验和。
    """
    snapshot_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: float = field(default_factory=time.time)
    entity_count: int = 0
    relation_count: int = 0
    rule_count: int = 0
    storage_path: str = ""
    checksum: str = ""


class WorldModelStorage:
    """世界模型存储：支持实体/关系的增删改查、快照管理、历史查询

    该类提供内存中的世界模型存储实现，支持实体的创建、读取、更新、删除，
    关系管理，快照创建与历史查询，以及基于时间戳的实体状态回溯。

    Attributes:
        config: 存储配置对象。
    """

    def __init__(self, config: Optional[StorageConfig] = None) -> None:
        """初始化世界模型存储

        Args:
            config: 存储配置对象，若为 None 则使用默认配置。
        """
        self.config = config or StorageConfig()
        self._entities: Dict[str, Entity] = {}
        self._relations: Dict[str, Relation] = {}
        self._snapshots: List[WorldModelSnapshot] = []
        self._entity_history: Dict[str, List[Tuple[float, Entity]]] = {}
        self._last_snapshot_time: float = time.time()
        self._write_count: int = 0
        self._read_count: int = 0

    def save_entity(self, entity: Entity) -> None:
        """保存或更新实体

        如果实体已存在，将旧版本保存到历史中。

        Args:
            entity: 要保存的实体对象。

        Raises:
            ValueError: 如果实体 ID 为空。
        """
        if not entity.entity_id:
            raise ValueError("Entity ID cannot be empty")
        
        old = self._entities.get(entity.entity_id)
        if old:
            self._entity_history.setdefault(entity.entity_id, []).append(
                (time.time(), old)
            )
        self._entities[entity.entity_id] = entity
        self._write_count += 1

    def save_relation(self, relation: Relation) -> None:
        """保存或更新关系

        Args:
            relation: 要保存的关系对象。

        Raises:
            ValueError: 如果关系 ID 为空。
        """
        if not relation.relation_id:
            raise ValueError("Relation ID cannot be empty")
        
        self._relations[relation.relation_id] = relation
        self._write_count += 1

    def get_entity(self, entity_id: str) -> Optional[Entity]:
        """按 ID 获取实体

        Args:
            entity_id: 实体 ID。

        Returns:
            如果实体存在则返回 Entity 对象，否则返回 None。
        """
        self._read_count += 1
        return self._entities.get(entity_id)

    def get_relation(self, relation_id: str) -> Optional[Relation]:
        """按 ID 获取关系

        Args:
            relation_id: 关系 ID。

        Returns:
            如果关系存在则返回 Relation 对象，否则返回 None。
        """
        self._read_count += 1
        return self._relations.get(relation_id)

    def delete_entity(self, entity_id: str) -> bool:
        """删除实体

        Args:
            entity_id: 要删除的实体 ID。

        Returns:
            删除成功返回 True，实体不存在返回 False。
        """
        if entity_id in self._entities:
            del self._entities[entity_id]
            self._entity_history.pop(entity_id, None)
            self._write_count += 1
            return True
        return False

    def delete_relation(self, relation_id: str) -> bool:
        """删除关系

        Args:
            relation_id: 要删除的关系 ID。

        Returns:
            删除成功返回 True，关系不存在返回 False。
        """
        if relation_id in self._relations:
            del self._relations[relation_id]
            self._write_count += 1
            return True
        return False

    def search_entities(self, name_pattern: str, limit: int = 50) -> List[Entity]:
        """按名称模式搜索实体

        Args:
            name_pattern: 名称匹配模式（不区分大小写的子串匹配）。
            limit: 最大返回结果数量，默认为 50。

        Returns:
            匹配的实体列表。

        Raises:
            ValueError: 如果 limit 小于等于 0。
        """
        if limit <= 0:
            raise ValueError("Limit must be greater than 0")
        
        self._read_count += 1
        results: List[Entity] = []
        pattern_lower = name_pattern.lower()
        for entity in self._entities.values():
            if pattern_lower in entity.name.lower():
                results.append(entity)
                if len(results) >= limit:
                    break
        return results

    def get_relations_for_entity(
        self, 
        entity_id: str, 
        direction: str = "both"
    ) -> List[Relation]:
        """获取与实体相关的关系

        Args:
            entity_id: 实体 ID。
            direction: 关系方向，可选 "in"、"out" 或 "both"，默认为 "both"。

        Returns:
            匹配的方向关系列表。

        Raises:
            ValueError: 如果 direction 不是 "in"、"out" 或 "both"。
        """
        if direction not in ("in", "out", "both"):
            raise ValueError(f"Invalid direction: '{direction}'. Must be one of 'in', 'out', 'both'")
        
        self._read_count += 1
        results: List[Relation] = []
        for rel in self._relations.values():
            if direction in ("out", "both") and rel.source_id == entity_id:
                results.append(rel)
            elif direction in ("in", "both") and rel.target_id == entity_id:
                results.append(rel)
        return results

    def create_snapshot(self) -> WorldModelSnapshot:
        """创建世界模型快照

        Returns:
            新创建的 WorldModelSnapshot 对象。
        """
        snapshot = WorldModelSnapshot(
            entity_count=len(self._entities),
            relation_count=len(self._relations),
        )
        checksum_data = f"{snapshot.entity_count}:{snapshot.relation_count}:{snapshot.timestamp}"
        snapshot.checksum = hashlib.sha256(checksum_data.encode()).hexdigest()[:16]
        self._snapshots.append(snapshot)
        self._last_snapshot_time = time.time()
        return snapshot

    def get_snapshot_history(self, limit: int = 50) -> List[WorldModelSnapshot]:
        """获取快照历史

        Args:
            limit: 返回最近 N 个快照，默认为 50。

        Returns:
            快照列表（按时间顺序，最新的在最后）。

        Raises:
            ValueError: 如果 limit 小于 0。
        """
        if limit < 0:
            raise ValueError("Limit must be non-negative")
        return self._snapshots[-limit:] if limit > 0 else []

    def get_entity_at_time(
        self, 
        entity_id: str, 
        timestamp: float
    ) -> Optional[Entity]:
        """时间旅行：获取实体在指定时刻的状态

        Args:
            entity_id: 实体 ID。
            timestamp: 目标时间戳。

        Returns:
            在该时间戳之前最近一次的实体状态，如果不存在则返回 None。
        """
        history = self._entity_history.get(entity_id, [])
        current = self._entities.get(entity_id)
        
        for ts, old_entity in reversed(history):
            if ts <= timestamp:
                return old_entity
        
        if current and hasattr(current, 'updated_at') and current.updated_at is not None:
            if current.updated_at <= timestamp:
                return current
        
        return None

    def get_stats(self) -> Dict[str, Any]:
        """获取存储统计信息

        Returns:
            包含实体数、关系数、快照数、读写计数的字典。
        """
        return {
            "entity_count": len(self._entities),
            "relation_count": len(self._relations),
            "snapshot_count": len(self._snapshots),
            "write_count": self._write_count,
            "read_count": self._read_count,
        }