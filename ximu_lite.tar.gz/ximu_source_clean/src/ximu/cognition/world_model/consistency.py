# -*- coding: utf-8 -*-
"""世界模型一致性检查模块：定期检查世界模型内部一致性，发现并修复矛盾的实体属性、冲突的关系、违反规则的状态。"""
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from src.ximu.cognition.world_model.storage import WorldModelStorage
from src.ximu.cognition.world_model.representation import Entity, Relation


class ConsistencyIssueType(Enum):
    """一致性问题类型枚举。"""
    ENTITY_CONTRADICTION = "entity_contradiction"
    RELATION_CONFLICT = "relation_conflict"
    RULE_VIOLATION = "rule_violation"
    DANGLING_REFERENCE = "dangling_reference"
    DUPLICATE_ENTITY = "duplicate_entity"
    STALE_DATA = "stale_data"


@dataclass
class ConsistencyIssue:
    """一致性问题。"""
    issue_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    issue_type: ConsistencyIssueType = ConsistencyIssueType.ENTITY_CONTRADICTION
    severity: str = "medium"
    description: str = ""
    related_entities: List[str] = field(default_factory=list)
    related_relations: List[str] = field(default_factory=list)
    suggested_fix: str = ""
    detected_at: float = field(default_factory=time.time)
    resolved: bool = False
    resolved_at: Optional[float] = None


@dataclass
class ConsistencyReport:
    """一致性检查报告。"""
    report_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    checked_at: float = field(default_factory=time.time)
    total_entities_checked: int = 0
    total_relations_checked: int = 0
    issues_found: int = 0
    issues_by_type: Dict[str, int] = field(default_factory=dict)
    issues: List[ConsistencyIssue] = field(default_factory=list)
    auto_fixed: int = 0
    need_manual: int = 0


class ConsistencyChecker:
    """一致性检查器：运行全量/增量检查，自动修复可修复的问题"""

    def __init__(self, storage: WorldModelStorage, stale_threshold_days: int = 30) -> None:
        """初始化一致性检查器

        Args:
            storage: 世界模型存储
            stale_threshold_days: 过期数据判定阈值（天数）
        """
        self.storage: WorldModelStorage = storage
        self.stale_threshold: int = stale_threshold_days * 86400
        self._all_issues: List[ConsistencyIssue] = []
        self._check_count: int = 0
        self._fix_count: int = 0

    def run_full_check(self) -> ConsistencyReport:
        """运行全量一致性检查

        Returns:
            一致性检查报告
        """
        report: ConsistencyReport = ConsistencyReport()
        self._check_count += 1
        entities: List[Entity] = list(self.storage._entities.values())
        relations: List[Relation] = list(self.storage._relations.values())
        report.total_entities_checked = len(entities)
        report.total_relations_checked = len(relations)
        self._check_dangling_references(entities, relations, report)
        self._check_entity_contradictions(entities, report)
        self._check_rule_violations(entities, report)
        self._check_duplicate_entities(entities, report)
        self._check_relation_conflicts(relations, report)
        self._check_stale_data(entities, report)
        self._finalize_report(report)
        return report

    def run_incremental_check(self, entity_ids: Optional[List[str]] = None) -> ConsistencyReport:
        """运行增量一致性检查

        Args:
            entity_ids: 要检查的实体ID列表，默认检查最近100个

        Returns:
            一致性检查报告
        """
        report: ConsistencyReport = ConsistencyReport()
        self._check_count += 1
        if entity_ids is None:
            entity_ids = list(self.storage._entities.keys())[-100:]
        entities = [
            self.storage._entities[eid]
            for eid in entity_ids
            if eid in self.storage._entities
        ]
        relations = [
            r for r in self.storage._relations.values()
            if r.source_id in entity_ids or r.target_id in entity_ids
        ]
        report.total_entities_checked = len(entities)
        report.total_relations_checked = len(relations)
        self._check_dangling_references(entities, relations, report)
        self._check_entity_contradictions(entities, report)
        self._check_relation_conflicts(relations, report)
        self._finalize_report(report)
        return report

    def _check_dangling_references(self, entities: List[Entity], relations: List[Relation],
                                    report: ConsistencyReport) -> None:
        """检查悬空引用

        Args:
            entities: 实体列表
            relations: 关系列表
            report: 报告对象
        """
        entity_ids: set = {e.entity_id for e in entities}
        for rel in relations:
            if rel.source_id not in entity_ids or rel.target_id not in entity_ids:
                issue = ConsistencyIssue(
                    issue_type=ConsistencyIssueType.DANGLING_REFERENCE,
                    severity="medium",
                    description=f"关系 {rel.relation_id} 指向不存在的实体",
                    related_relations=[rel.relation_id],
                    suggested_fix="删除悬空关系或创建缺失的实体",
                )
                report.issues.append(issue)
                report.issues_by_type["dangling_reference"] = report.issues_by_type.get("dangling_reference", 0) + 1

    def _check_entity_contradictions(self, entities: List[Entity], report: ConsistencyReport) -> None:
        """检查实体属性矛盾

        Args:
            entities: 实体列表
            report: 报告对象
        """
        contradiction_attrs: Dict[str, List[str]] = {
            "is_alive": ["false", "true"],
            "status": ["dead", "alive"],
        }
        for entity in entities:
            history = self.storage._entity_history.get(entity.entity_id, [])
            if not history:
                continue
            for attr_name, conflict_pairs in contradiction_attrs.items():
                if attr_name not in entity.attributes:
                    continue
                current_val: str = str(entity.attributes[attr_name]).lower()
                for _, old_entity in history:
                    old_val: str = str(old_entity.attributes.get(attr_name, "")).lower()
                    if old_val and old_val != current_val:
                        issue = ConsistencyIssue(
                            issue_type=ConsistencyIssueType.ENTITY_CONTRADICTION,
                            severity="medium",
                            description=f"实体'{entity.name}'的属性[{attr_name}]存在历史矛盾",
                            related_entities=[entity.entity_id],
                            suggested_fix="确认当前正确值并清理历史",
                        )
                        report.issues.append(issue)
                        report.issues_by_type["entity_contradiction"] = report.issues_by_type.get("entity_contradiction", 0) + 1
                        break

    def _check_rule_violations(self, entities: List[Entity], report: ConsistencyReport) -> None:
        """检查实体属性违反基本规则

        Args:
            entities: 实体列表
            report: 报告对象
        """
        for entity in entities:
            mass = entity.attributes.get("mass")
            if mass is not None and isinstance(mass, (int, float)) and mass <= 0:
                self._add_issue(
                    report, ConsistencyIssueType.RULE_VIOLATION,
                    f"实体'{entity.name}'质量为负({mass})",
                    [entity.entity_id], "修正质量属性为正值", "high",
                )
            temp = entity.attributes.get("temperature")
            if temp is not None and isinstance(temp, (int, float)) and temp < -273.15:
                self._add_issue(
                    report, ConsistencyIssueType.RULE_VIOLATION,
                    f"实体'{entity.name}'温度低于绝对零度({temp})",
                    [entity.entity_id], "修正温度属性", "high",
                )

    def _check_duplicate_entities(self, entities: List[Entity], report: ConsistencyReport) -> None:
        """检查重复实体

        Args:
            entities: 实体列表
            report: 报告对象
        """
        seen: Dict[tuple, Entity] = {}
        for entity in entities:
            key: tuple = (entity.name.lower(), entity.entity_type)
            if key in seen:
                self._add_issue(
                    report, ConsistencyIssueType.DUPLICATE_ENTITY,
                    f"实体'{entity.name}'存在重复",
                    [entity.entity_id, seen[key].entity_id],
                    "合并重复实体", "medium",
                )
            else:
                seen[key] = entity

    def _check_relation_conflicts(self, relations: List[Relation], report: ConsistencyReport) -> None:
        """检查关系冲突

        Args:
            relations: 关系列表
            report: 报告对象
        """
        conflict_pairs: Dict[tuple, List[Relation]] = {}
        for rel in relations:
            pair = tuple(sorted([rel.source_id, rel.target_id]))
            conflict_pairs.setdefault(pair, []).append(rel)
        for pair, rels in conflict_pairs.items():
            if len(rels) > 1:
                for rel in rels[1:]:
                    issue = ConsistencyIssue(
                        issue_type=ConsistencyIssueType.RELATION_CONFLICT,
                        severity="low",
                        description=f"实体 {pair[0]} 与 {pair[1]} 存在多条关系",
                        related_relations=[r.relation_id for r in rels],
                        suggested_fix="合并或区分重复关系",
                    )
                    report.issues.append(issue)
                    report.issues_by_type["relation_conflict"] = report.issues_by_type.get("relation_conflict", 0) + 1

    def _check_stale_data(self, entities: List[Entity], report: ConsistencyReport) -> None:
        """检查过期数据

        Args:
            entities: 实体列表
            report: 报告对象
        """
        now = time.time()
        for entity in entities:
            last_updated = entity.attributes.get("last_updated", 0)
            if isinstance(last_updated, (int, float)) and (now - last_updated) > self.stale_threshold:
                issue = ConsistencyIssue(
                    issue_type=ConsistencyIssueType.STALE_DATA,
                    severity="low",
                    description=f"实体'{entity.name}'数据已过 {(now - last_updated) / 86400:.0f} 天未更新",
                    related_entities=[entity.entity_id],
                    suggested_fix="刷新实体数据或标记为过期",
                )
                report.issues.append(issue)
                report.issues_by_type["stale_data"] = report.issues_by_type.get("stale_data", 0) + 1

    def _add_issue(self, report: ConsistencyReport, issue_type: ConsistencyIssueType,
                   description: str, entity_ids: List[str], fix: str, severity: str) -> None:
        """向报告添加一个问题

        Args:
            report: 报告对象
            issue_type: 问题类型
            description: 问题描述
            entity_ids: 相关实体ID列表
            fix: 建议修复措施
            severity: 严重程度
        """
        issue = ConsistencyIssue(
            issue_type=issue_type,
            severity=severity,
            description=description,
            related_entities=entity_ids,
            suggested_fix=fix,
        )
        report.issues.append(issue)
        report.issues_by_type[issue_type.value] = report.issues_by_type.get(issue_type.value, 0) + 1

    def _finalize_report(self, report: ConsistencyReport) -> None:
        """汇总报告统计信息

        Args:
            report: 报告对象
        """
        report.issues_found = len(report.issues)
        report.auto_fixed = sum(1 for i in report.issues if i.severity == "low")
        report.need_manual = sum(1 for i in report.issues if i.severity in ("high", "medium"))
        self._all_issues.extend(report.issues)

    def get_issue_summary(self) -> Dict[str, Any]:
        """获取所有历史问题的汇总统计

        Returns:
            统计字典
        """
        by_type: Dict[str, int] = {}
        for issue in self._all_issues:
            by_type[issue.issue_type.value] = by_type.get(issue.issue_type.value, 0) + 1
        return {
            "total_checks": self._check_count,
            "total_issues": len(self._all_issues),
            "by_type": by_type,
        }
