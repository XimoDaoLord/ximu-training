"""大脑世界联动模块。

连接 OMNI-BRAIN 与世界模型，为决策提供模拟能力，
并从决策结果中学习更新世界模型。
"""
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from src.ximu.cognition.world_model.representation import WorldState
from src.ximu.cognition.world_model.state_evolution import (
    Action,
    EvolutionStep,
    StateEvolutionEngine,
)
from src.ximu.cognition.world_model.query import (
    WorldModelQuery,
    WorldModelAnswer,
    WorldModelQueryEngine,
)
from src.ximu.cognition.world_model.learning import WorldModelLearner
from src.ximu.cognition.world_model.storage import WorldModelStorage


@dataclass
class BrainWorldLink:
    """大脑与世界模型的连接配置。"""

    link_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    brain_id: str = ""
    world_model_id: str = ""
    enabled: bool = True
    simulation_depth: int = 3
    learning_enabled: bool = True
    created_at: float = field(default_factory=time.time)


@dataclass
class BrainDecisionRecord:
    """大脑决策记录，用于世界模型学习。"""

    record_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    brain_id: str = ""
    decision: str = ""
    action: Optional[Action] = None
    predicted_state: Optional[WorldState] = None
    actual_state: Optional[WorldState] = None
    prediction_error: float = 0.0
    outcome: str = ""
    timestamp: float = field(default_factory=time.time)


class BrainWorldLinkEngine:
    """大脑世界联动引擎：为大脑决策提供世界模拟，从决策结果中学习。"""

    def __init__(
        self,
        storage: Optional[WorldModelStorage] = None,
        evolution_engine: Optional[StateEvolutionEngine] = None,
        query_engine: Optional[WorldModelQueryEngine] = None,
        learner: Optional[WorldModelLearner] = None,
    ) -> None:
        """初始化大脑世界联动引擎。

        Args:
            storage: 世界模型存储，默认创建新的实例。
            evolution_engine: 状态演化引擎，默认创建新的实例。
            query_engine: 世界模型查询引擎，默认基于 storage 和 evolution_engine 创建。
            learner: 世界模型学习者，默认基于 storage 创建。
        """
        self.storage: WorldModelStorage = storage or WorldModelStorage()
        self.evolution_engine: StateEvolutionEngine = evolution_engine or StateEvolutionEngine()
        self.query_engine: WorldModelQueryEngine = (
            query_engine or WorldModelQueryEngine(self.storage, self.evolution_engine)
        )
        self.learner: WorldModelLearner = learner or WorldModelLearner(self.storage)
        self.link: BrainWorldLink = BrainWorldLink()
        self._decision_history: List[BrainDecisionRecord] = []
        self._simulation_count: int = 0
        self._learning_count: int = 0

    def simulate_decision(
        self,
        action: Action,
        initial_state: Optional[WorldState] = None,
        depth: Optional[int] = None,
    ) -> Dict[str, Any]:
        """模拟一个决策的后果，返回预测状态序列。

        Args:
            action: 要模拟的动作。
            initial_state: 初始世界状态，若为 None 则使用默认空状态。
            depth: 模拟深度，若为 None 则使用配置中的 simulation_depth。

        Returns:
            包含动作、深度、状态序列、最终状态和模拟 ID 的字典。

        Raises:
            RuntimeError: 联动未启用或演化引擎返回 None。
            ValueError: 模拟深度为负数。
        """
        if not self.link.enabled:
            raise RuntimeError("联动未启用，无法模拟决策")

        self._simulation_count += 1
        effective_depth: int = depth if depth is not None else self.link.simulation_depth
        if effective_depth < 0:
            raise ValueError(f"模拟深度不能为负数，收到: {effective_depth}")

        state: WorldState = initial_state or WorldState()
        states: List[WorldState] = [state]
        current: WorldState = state

        for _ in range(effective_depth):
            predicted = self.evolution_engine.predict_next_state(current, action)
            if predicted is None:
                raise RuntimeError("演化引擎在模拟过程中返回了空状态")
            states.append(predicted)
            current = predicted

        return {
            "action": action.action_type,
            "depth": effective_depth,
            "states": states,
            "final_state": states[-1],
            "simulation_id": str(uuid.uuid4()),
        }

    def query_world(self, query: WorldModelQuery) -> WorldModelAnswer:
        """通过联动接口查询世界模型。

        Args:
            query: 世界模型查询对象。

        Returns:
            世界模型查询结果。

        Raises:
            RuntimeError: 联动未启用。
        """
        if not self.link.enabled:
            raise RuntimeError("联动未启用，无法查询世界模型")
        return self.query_engine.query(query)

    def record_decision(
        self,
        brain_id: str,
        decision: str,
        action: Action,
        predicted_state: WorldState,
        actual_state: Optional[WorldState] = None,
        outcome: str = "",
    ) -> BrainDecisionRecord:
        """记录大脑决策，用于后续学习。

        Args:
            brain_id: 大脑标识。
            decision: 决策描述。
            action: 执行的动作。
            predicted_state: 预测的世界状态。
            actual_state: 实际的世界状态，若为 None 则不计算误差，也不触发学习。
            outcome: 决策结果描述。

        Returns:
            创建的决策记录。
        """
        error: float = 0.0
        if actual_state is not None:
            error = self._compute_state_difference(predicted_state, actual_state)

        record = BrainDecisionRecord(
            brain_id=brain_id,
            decision=decision,
            action=action,
            predicted_state=predicted_state,
            actual_state=actual_state,
            prediction_error=error,
            outcome=outcome,
        )
        self._decision_history.append(record)

        if self.link.learning_enabled and actual_state is not None:
            step = EvolutionStep(
                action=action,
                predicted_state=predicted_state,
                actual_state=actual_state,
                prediction_error=error,
            )
            self.learner.learn_from_prediction_error(step)
            self._learning_count += 1

        return record

    def _compute_state_difference(self, s1: WorldState, s2: WorldState) -> float:
        """计算两个世界状态的差异度（0-1）。

        Args:
            s1: 第一个世界状态。
            s2: 第二个世界状态。

        Returns:
            差异度，范围 [0, 1]。
        """
        if not s1.entities and not s2.entities:
            return 0.0

        all_keys: set = set(s1.entities.keys()) | set(s2.entities.keys())
        if not all_keys:
            return 0.0

        differences: float = 0.0
        for key in all_keys:
            e1 = s1.entities.get(key)
            e2 = s2.entities.get(key)
            if e1 is None or e2 is None:
                differences += 1.0
            elif e1.attributes != e2.attributes:
                differences += 0.5

        return min(1.0, differences / len(all_keys))

    def get_decision_history(
        self,
        limit: int = 50,
        brain_id: Optional[str] = None,
    ) -> List[BrainDecisionRecord]:
        """获取决策历史，按时间倒序。

        Args:
            limit: 返回的最大记录数，默认 50。
            brain_id: 可选的脑 ID 过滤，若为 None 则返回所有记录。

        Returns:
            决策记录列表，最近在前。
        """
        if limit <= 0:
            return []

        results: List[BrainDecisionRecord] = []
        for record in reversed(self._decision_history):
            if brain_id is not None and record.brain_id != brain_id:
                continue
            results.append(record)
            if len(results) >= limit:
                break
        return results

    def get_link_stats(self) -> Dict[str, Any]:
        """获取联动统计信息。

        Returns:
            包含联动状态、模拟次数、学习次数、决策次数和平均预测误差的字典。
        """
        avg_error: float = 0.0
        if self._decision_history:
            total_error: float = sum(r.prediction_error for r in self._decision_history)
            avg_error = total_error / len(self._decision_history)

        return {
            "link_enabled": self.link.enabled,
            "simulation_count": self._simulation_count,
            "learning_count": self._learning_count,
            "decision_count": len(self._decision_history),
            "avg_prediction_error": avg_error,
        }