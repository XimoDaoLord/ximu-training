# -*- coding: utf-8 -*-
"""
cognition/evolution 包初始化。
提供认知进化相关的懒加载支持。
"""

import importlib as _importlib
import threading as _th
from typing import Any

_load_lock = _th.Lock()
_parts_modules: list[str] = []
_parts_loaded: dict[str, Any] = {}


def __getattr__(name: str) -> Any:
    """
    PEP 562 懒加载属性访问。

    Args:
        name: 要获取的属性名。

    Returns:
        对应的属性对象。

    Raises:
        AttributeError: 如果属性不存在。
    """
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
