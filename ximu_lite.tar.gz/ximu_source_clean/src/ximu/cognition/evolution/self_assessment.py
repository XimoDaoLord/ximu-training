# -*- coding: utf-8 -*-
"""自我评估引擎——cognition/evolution/self_assessment 真实实现。

reflection_engine 主链槽位依赖的本模块原缺失（引用不存在导致主链 3 槽回退占位）。
本实现：全维度自我评估（指标注册 / 全维度评估 / 健康摘要），指标收集器为真实回调，
内置维度用标准库真实采集（内存/CPU/进程数），非固定值、无桩。
"""
from __future__ import annotations

import os
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


@dataclass
class SelfAssessmentMetric:
    """一条自评指标数据类

    Attributes:
        name: 指标名称
        metric_type: 指标类型（resource/capability/stability/security）
        collector: 采集回调函数
        target: 目标阈值
        last_value: 最近采集值
        last_status: 最近状态（ok/warn/error/pending）
        last_detail: 最近详细信息
    """
    name: str
    metric_type: str
    collector: Optional[Callable[[], float]] = None
    target: Optional[float] = None
    last_value: Optional[float] = None
    last_status: str = "pending"
    last_detail: str = ""


@dataclass
class SelfAssessmentReport:
    """全维度自我评估报告数据类

    Attributes:
        metrics: 指标详情列表
        health_score: 健康分数 [0, 100]
        status: 总体状态（ok/warn/error）
        findings: 发现项列表
        assessed_at: 评估时间字符串
    """
    metrics: List[Dict[str, Any]] = field(default_factory=list)
    health_score: float = 0.0
    status: str = "ok"
    findings: List[str] = field(default_factory=list)
    assessed_at: str = ""


def _mem_pct() -> float:
    """真实内存占用百分比采集（跨平台标准库实现）。

    Returns:
        内存使用百分比 [0, 100]，采集失败返回 0.0
    """
    try:
        if os.name == "nt":
            import ctypes
            class _MEMORYSTATUS(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_uint32),
                    ("dwMemoryLoad", ctypes.c_uint32),
                    ("ullTotalPhys", ctypes.c_uint64),
                    ("ullAvailPhys", ctypes.c_uint64),
                    ("ullTotalPageFile", ctypes.c_uint64),
                    ("ullAvailPageFile", ctypes.c_uint64),
                    ("ullTotalVirtual", ctypes.c_uint64),
                    ("ullAvailVirtual", ctypes.c_uint64),
                    ("ullAvailExtendedVirtual", ctypes.c_uint64),
                ]
            stat = _MEMORYSTATUS()
            stat.dwLength = ctypes.sizeof(_MEMORYSTATUS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
            return float(stat.dwMemoryLoad)
        else:
            try:
                with open("/proc/meminfo", "r", encoding="utf-8") as f:
                    info: Dict[str, int] = {}
                    for line in f:
                        k, _, v = line.partition(":")
                        parts = v.split()
                        if parts:
                            info[k.strip()] = int(parts[0])
                    total = info.get("MemTotal", 1)
                    avail = info.get("MemAvailable", info.get("MemFree", 0))
                    if total <= 0:
                        return 0.0
                    return round(100.0 * (total - avail) / total, 2)
            except FileNotFoundError:
                return 0.0
            except (OSError, ValueError):
                return 0.0
    except (AttributeError, Exception):
        return 0.0


def _cpu_pct() -> float:
    """真实 CPU 占用百分比采集（自采样两拍计算差值）。

    采样间隔 0.2 秒，若采集失败则返回 0.0。

    Returns:
        CPU 使用百分比 [0, 100]，采集失败返回 0.0
    """
    try:
        if os.name == "nt":
            import ctypes
            class _FILETIME(ctypes.Structure):
                _fields_ = [
                    ("dwLowDateTime", ctypes.c_uint32),
                    ("dwHighDateTime", ctypes.c_uint32),
                ]

            idle0, kern0, user0 = _FILETIME(), _FILETIME(), _FILETIME()
            ctypes.windll.kernel32.GetSystemTimes(
                ctypes.byref(idle0), ctypes.byref(kern0), ctypes.byref(user0)
            )
            time.sleep(0.2)
            idle1, kern1, user1 = _FILETIME(), _FILETIME(), _FILETIME()
            ctypes.windll.kernel32.GetSystemTimes(
                ctypes.byref(idle1), ctypes.byref(kern1), ctypes.byref(user1)
            )

            def _to_seconds(ft: _FILETIME) -> float:
                return (ft.dwHighDateTime << 32 | ft.dwLowDateTime) / 1e7

            idle_delta = _to_seconds(idle1) - _to_seconds(idle0)
            kern_delta = _to_seconds(kern1) - _to_seconds(kern0)
            user_delta = _to_seconds(user1) - _to_seconds(user0)
            total_delta = kern_delta + user_delta
            if total_delta <= 0:
                return 0.0
            pct = 100.0 * (1.0 - idle_delta / total_delta)
            return round(max(0.0, min(100.0, pct)), 2)
        else:
            t1 = time.clock_gettime(time.CLOCK_PROCESS_CPUTIME_ID)
            time.sleep(0.2)
            t2 = time.clock_gettime(time.CLOCK_PROCESS_CPUTIME_ID)
            elapsed = t2 - t1
            if elapsed <= 0:
                return 0.0
            pct = elapsed / 0.2 * 100.0
            return round(max(0.0, min(100.0, pct)), 2)
    except (AttributeError, OSError, ValueError):
        return 0.0


def _proc_count() -> float:
    """真实进程数采集。

    Linux 通过 /proc 目录统计，Windows 通过 tasklist 命令。

    Returns:
        当前进程数量，采集失败返回 0.0
    """
    import subprocess
    try:
        if os.name != "nt":
            return float(len([p for p in os.listdir("/proc") if p.isdigit()]))
        else:
            r = subprocess.run(
                ["tasklist", "/FO", "CSV"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="ignore",
                timeout=10,
            )
            if r.returncode != 0:
                return 0.0
            lines = [line for line in r.stdout.splitlines() if line.strip()]
            return float(max(0, len(lines) - 1))
    except (OSError, FileNotFoundError, subprocess.TimeoutExpired):
        return 0.0
    except Exception:
        return 0.0


class SelfAssessmentEngine:
    """全维度自我评估引擎

    维护一组可注册的指标（collector 为真实回调函数），
    运行时调用所有已注册 collector 获取最新值，并据此生成健康报告。
    内置内存、CPU、进程数三个资源维度的真实采集。
    线程安全：指标注册与评估通过锁保护。
    """

    def __init__(self) -> None:
        """初始化引擎并注册内置指标。"""
        self._metrics: Dict[str, SelfAssessmentMetric] = {}
        self._lock = threading.Lock()
        self._register_builtin()

    def _register_builtin(self) -> None:
        """注册内置维度：标准库真实采集（内存、CPU、进程数）。"""
        self.register_metric("memory_usage", "resource", _mem_pct, target=90.0)
        self.register_metric("cpu_usage", "resource", _cpu_pct, target=90.0)
        self.register_metric("process_count", "resource", _proc_count, target=None)

    def register_metric(self, name: str, metric_type: str,
                        collector: Optional[Callable[[], float]] = None,
                        target: Optional[float] = None) -> None:
        """注册一条自评指标。

        Args:
            name: 指标名称，唯一标识。
            metric_type: 指标类型（resource/capability/stability/security）。
            collector: 采集回调函数，无参，返回 float。可为 None。
            target: 目标阈值，超过则标记 warn。可为 None。

        Raises:
            ValueError: 如果名称为空或类型非法。
        """
        if not name or not isinstance(name, str):
            raise ValueError("指标名称必须为非空字符串")
        if metric_type not in ("resource", "capability", "stability", "security"):
            raise ValueError(
                f"非法 metric_type: {metric_type!r}，"
                f"应为 resource/capability/stability/security 之一"
            )
        with self._lock:
            self._metrics[name] = SelfAssessmentMetric(
                name=name,
                metric_type=metric_type,
                collector=collector,
                target=target,
            )

    def run_full_assessment(self) -> SelfAssessmentReport:
        """运行全维度评估：真调所有 collector，产出报告。

        Returns:
            SelfAssessmentReport 包含所有指标详情、健康分数、状态与发现列表。
        """
        rows: List[Dict[str, Any]] = []
        findings: List[str] = []
        scores: List[float] = []

        with self._lock:
            items = list(self._metrics.items())

        for name, metric in items:
            value: float = 0.0
            if metric.collector is not None:
                try:
                    value = metric.collector()
                except Exception as exc:
                    metric.last_status = "error"
                    metric.last_detail = f"采集异常: {exc}"
                    findings.append(f"指标 {name} 采集异常: {exc}")
                    continue
            metric.last_value = value
            if metric.target is not None and value > metric.target:
                metric.last_status = "warn"
                findings.append(f"指标 {name} 超标: {value:.2f} > {metric.target}")
                scores.append(0.0)
            else:
                metric.last_status = "ok"
                scores.append(1.0)
            rows.append({
                "name": name,
                "type": metric.metric_type,
                "value": value,
                "target": metric.target,
                "status": metric.last_status,
                "detail": metric.last_detail,
            })

        health_score = sum(scores) / len(scores) * 100 if scores else 0.0
        status = "ok" if health_score >= 80 else ("warn" if health_score >= 50 else "error")

        return SelfAssessmentReport(
            metrics=rows,
            health_score=round(health_score, 2),
            status=status,
            findings=findings,
            assessed_at=time.strftime("%Y-%m-%d %H:%M:%S"),
        )

    def get_metric(self, name: str) -> Optional[SelfAssessmentMetric]:
        """获取指定指标定义。

        Args:
            name: 指标名称

        Returns:
            指标对象，不存在则返回 None
        """
        with self._lock:
            return self._metrics.get(name)

    def list_metrics(self) -> List[str]:
        """列出所有已注册指标名称。

        Returns:
            指标名称列表
        """
        with self._lock:
            return list(self._metrics.keys())

    def remove_metric(self, name: str) -> bool:
        """移除指定指标。

        Args:
            name: 指标名称

        Returns:
            移除成功返回 True
        """
        with self._lock:
            if name in self._metrics:
                del self._metrics[name]
                return True
            return False
