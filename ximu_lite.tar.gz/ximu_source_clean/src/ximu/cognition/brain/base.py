# -*- coding: utf-8 -*-
"""认知主链适配层基类。

把 cognition/ 下的真实引擎统一成 main.py 注册表所需生命周期：
无参构造 -> initialize() -> (对外认知方法) -> shutdown()；
并聚合所持子引擎的健康状态，保证 health_check 反映真实装配情况。
"""
from __future__ import annotations

from typing import Any, Dict


class CognitiveModule:
    """所有主链认知模块的统一基类（真实组合，非占位）。"""

    def __init__(self) -> None:
        """初始化认知模块，设置默认状态。"""
        self.initialized: bool = False
        self._engines: Dict[str, Any] = {}

    def _build_engines(self) -> None:
        """子类覆盖：实例化并持有真实认知引擎，写入 self._engines。

        Raises:
            NotImplementedError: 子类未实现此方法时抛出。
        """
        raise NotImplementedError("认知模块必须实现 _build_engines 以装配真实引擎")

    def initialize(self) -> None:
        """初始化模块，构建并装配所有引擎。"""
        if not self.initialized:
            self._build_engines()
            self.initialized = True

    def _ensure_ready(self) -> None:
        """确保模块已初始化，若未初始化则自动调用 initialize()。"""
        if not self.initialized:
            self.initialize()

    def shutdown(self) -> None:
        """关闭模块，清理所有引擎实例和状态。"""
        self._engines.clear()
        self.initialized = False

    def health_check(self) -> Dict[str, Any]:
        """检查模块健康状态。

        Returns:
            包含模块名称、状态、引擎数量和引擎名称映射的健康状态字典。
        """
        return {
            "module": type(self).__name__,
            "status": "healthy" if self.initialized and self._engines else "uninitialized",
            "engine_count": len(self._engines),
            "engines": {k: type(v).__name__ for k, v in self._engines.items()},
        }
