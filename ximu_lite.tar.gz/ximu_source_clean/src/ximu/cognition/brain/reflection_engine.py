# -*- coding: utf-8 -*-
"""反思引擎——主链 reflection_engine 槽位的真实实现。"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .base import CognitiveModule
from ..agi.self_awareness import SelfAwareness
from ..agi.metacognition import Metacognition
from ..evolution.self_assessment import SelfAssessmentEngine


class ReflectionEngine(CognitiveModule):
    """事后/在线反思。"""

    def _build_engines(self) -> None:
        """构建内部引擎实例。"""
        self._engines["self_assessment"] = SelfAssessmentEngine()
        self._engines["self_awareness"] = SelfAwareness()
        self._engines["metacognition"] = Metacognition()

    def reflect(self, task_description: str,
                thought_trace: Optional[List[str]] = None,
                conclusion: str = "") -> Dict[str, Any]:
        """对一次任务的思维过程做反思。"""
        self._ensure_ready()
        trace = thought_trace or []
        intro = self._engines["self_awareness"].introspect(task_description, trace)
        biases = self._engines["metacognition"].detect_bias(trace, conclusion or task_description)
        recalled = []
        try:
            from src.ximu.core.memory.memory_system import recall_experience
            recalled = recall_experience(task_description or "", top_k=2)
        except Exception:
            recalled = []
        return {
            "task": task_description,
            "identified_biases": list(getattr(intro, "identified_biases", [])),
            "uncertainty_areas": list(getattr(intro, "uncertainty_areas", [])),
            "metacognitive_biases": [b.bias_type for b in biases],
            "recalled_experiences": [{"lesson": e.get("lesson", ""),
                                      "avoid": e.get("avoid_hint", "")} for e in recalled],
            "recalled_count": len(recalled),
        }

    def run_self_assessment(self):
        """运行一次全维度自我评估。"""
        self._ensure_ready()
        return self._engines["self_assessment"].run_full_assessment()

    def register_metric(self, name: str, metric_type: str, collector, target: Any = None) -> None:
        """注册自评指标。"""
        self._ensure_ready()
        self._engines["self_assessment"].register_metric(name, metric_type, collector, target)

    def stats(self) -> Dict[str, Any]:
        """返回自我意识统计与最近一次健康摘要。"""
        self._ensure_ready()
        return {
            "awareness": self._engines["self_awareness"].get_awareness_stats(),
            "health": self._engines["self_assessment"].get_health_summary(),
        }