# -*- coding: utf-8 -*-
"""决策引擎——主链 decision_engine 槽位的真实实现。"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

from .base import CognitiveModule
from ..world_model.state_evolution import StateEvolutionEngine, EvolutionRule, Action
from ..world_model.representation import WorldState
from ..causal_reasoning.inference import CausalInferenceEngine


@dataclass
class DecisionResult:
    """决策结果数据类。"""
    chosen_action: Optional[Action]
    chosen_index: int
    scores: List[float]
    predicted_states: List[Any]
    rationale: str = ""


class DecisionEngine(CognitiveModule):
    """基于状态预测 + 目标打分的真实决策器。"""

    def _build_engines(self) -> None:
        """构建内部引擎实例。"""
        self._engines["state_evolution"] = StateEvolutionEngine()
        self._engines["causal_inference"] = CausalInferenceEngine()

    def register_rule(self, action_pattern: str, effect: Dict[str, Any],
                      condition: Optional[Dict[str, Any]] = None, confidence: float = 1.0) -> None:
        """注册“某类行动 -> 状态效果”的演化规则。"""
        self._ensure_ready()
        self._engines["state_evolution"].register_rule(EvolutionRule(
            condition=condition or {}, action_pattern=action_pattern,
            effect=effect, confidence=confidence))

    @staticmethod
    def _default_evaluator(state: WorldState) -> float:
        """默认评估器。"""
        try:
            return float(state.metadata.get("utility", 0.0))
        except (TypeError, ValueError):
            return 0.0

    def decide(self, current_state: WorldState, candidate_actions: List[Action],
               evaluator: Optional[Callable[[WorldState], float]] = None) -> DecisionResult:
        """预测每个候选行动的后果并按评估函数选最优。"""
        self._ensure_ready()
        ev = evaluator or self._default_evaluator
        preds = self._engines["state_evolution"].parallel_evolve(current_state, candidate_actions)
        scores = [float(ev(s)) for s in preds]
        if not scores:
            return DecisionResult(None, -1, scores, preds, "无候选行动")
        idx = max(range(len(scores)), key=scores.__getitem__)
        return DecisionResult(
            candidate_actions[idx], idx, scores, preds,
            f"在{len(scores)}个候选中按目标函数选第{idx + 1}个，得分{scores[idx]:.4g}")

    def predict(self, state: WorldState, action: Action) -> WorldState:
        """预测单个行动后的下一状态。"""
        self._ensure_ready()
        return self._engines["state_evolution"].predict_next_state(state, action)

    def what_if(self, action_values: Dict[str, float], target: str, observed: Dict[str, float]):
        """因果反事实。"""
        self._ensure_ready()
        return self._engines["causal_inference"].what_if(action_values, target, observed)

    def stats(self) -> Dict[str, Any]:
        """获取统计信息。"""
        self._ensure_ready()
        return self._engines["state_evolution"].get_stats()