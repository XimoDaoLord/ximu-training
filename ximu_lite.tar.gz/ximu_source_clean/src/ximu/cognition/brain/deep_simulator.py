# -*- coding: utf-8 -*-
"""更深认知引擎纳入层。"""
from __future__ import annotations

from typing import Any, Callable, Dict, Optional

from ..causal_reasoning.inference import CausalInferenceEngine
from ..simulation.monte_carlo import MonteCarloRunner
from ..world_model.simulation import WorldSimulationEngine


class DeepSimulator:
    """深度模拟引擎封装。"""

    def __init__(self, mc_samples: int = 20) -> None:
        """初始化深度模拟引擎。"""
        self.world_sim = WorldSimulationEngine()
        self.monte_carlo = MonteCarloRunner(default_samples=mc_samples)
        self.causal = CausalInferenceEngine()

    def simulate_world(self, world_state, config=None) -> Dict[str, Any]:
        """对世界状态跑完整世界模型模拟。"""
        result = self.world_sim.run(world_state, config)
        traj = getattr(result, "trajectory", []) or []
        final = getattr(result, "final_state", None) or (traj[-1] if traj else world_state)
        return {"total_steps": getattr(result, "total_steps", len(traj)),
                "trajectory_len": len(traj),
                "final_metadata": getattr(final, "metadata", {})}

    def compare_strategies(self, scenario, strategies: Dict[str, Callable],
                           metric_extractor: Callable, samples: Optional[int] = None):
        """蒙特卡洛多策略对比。"""
        return self.monte_carlo.compare_strategies(
            scenario, strategies, metric_extractor, samples=samples)

    def causal_what_if(self, action_values: Dict[str, float],
                       target: str, observed: Dict[str, float]):
        """因果反事实推断。"""
        return self.causal.what_if(action_values, target, observed)