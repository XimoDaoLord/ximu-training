# -*- coding: utf-8 -*-
"""规划引擎——主链 planning_engine 槽位的真实实现。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from .base import CognitiveModule
from ..world_model.state_evolution import StateEvolutionEngine, EvolutionRule, Action
from ..world_model.representation import WorldState


@dataclass
class PlanResult:
    """规划结果数据类。"""
    chosen_plan: Optional[List[Action]]
    chosen_index: int
    scores: List[float]
    sequences: List[List[Dict[str, Any]]] = field(default_factory=list)
    rationale: str = ""


class PlanningEngine(CognitiveModule):
    """前向多步规划器。"""

    def _build_engines(self) -> None:
        """构建内部引擎实例。"""
        self._engines["state_evolution"] = StateEvolutionEngine()

    def register_rule(self, action_pattern: str, effect: Dict[str, Any],
                      condition: Optional[Dict[str, Any]] = None, confidence: float = 1.0) -> None:
        """注册演化规则。"""
        self._ensure_ready()
        self._engines["state_evolution"].register_rule(EvolutionRule(
            condition=condition or {}, action_pattern=action_pattern,
            effect=effect, confidence=confidence))

    @staticmethod
    def _default_evaluator(state: WorldState) -> float:
        """默认评估器。"""
        try:
            return float(state.metadata.get("utility", 0.0))
        except (TypeError, ValueError):
            return 0.0

    def plan(self, initial_state: WorldState, candidate_plans: List[List[Action]],
             evaluator: Optional[Callable[[WorldState], float]] = None,
             decay_rate: float = 0.15) -> PlanResult:
        """对每个候选行动序列做多步推演并打分择优。"""
        self._ensure_ready()
        ev = evaluator or self._default_evaluator
        evo = self._engines["state_evolution"]
        sequences: List[List[Dict[str, Any]]] = []
        scores: List[float] = []
        for plan in candidate_plans:
            seq = evo.predict_sequence_with_confidence(initial_state, plan, decay_rate)
            sequences.append(seq)
            if not seq:
                scores.append(0.0)
                continue
            robustness = sum(s["confidence"] for s in seq) / len(seq)
            scores.append(float(ev(seq[-1]["state"])) * robustness)
        if not scores:
            return PlanResult(None, -1, scores, sequences, "无候选计划")
        idx = max(range(len(scores)), key=scores.__getitem__)
        return PlanResult(candidate_plans[idx], idx, scores, sequences,
                          f"在{len(scores)}个候选计划中选第{idx + 1}个，综合得分{scores[idx]:.4g}")

    def simulate(self, initial_state: WorldState, actions: List[Action]) -> List[WorldState]:
        """返回某行动序列的完整状态轨迹。"""
        self._ensure_ready()
        return self._engines["state_evolution"].simulate_sequence(initial_state, actions)

    def stats(self) -> Dict[str, Any]:
        """获取统计信息。"""
        self._ensure_ready()
        return self._engines["state_evolution"].get_stats()