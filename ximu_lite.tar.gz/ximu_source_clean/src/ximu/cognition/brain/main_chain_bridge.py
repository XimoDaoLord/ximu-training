# -*- coding: utf-8 -*-
"""认知主链自动贯通：感知/记忆 → 决策/规划 → 行动。

从感知关键词与记忆命中结果，构造世界状态与候选行动，
利用 DecisionEngine/PlanningEngine 预测择优，
将选定行动交给可注入的 action_executor；未注入时返回 pending。
"""

from __future__ import annotations

import re
from typing import Any, Callable, Dict, List, Optional

from .decision_engine import DecisionEngine
from .deep_simulator import DeepSimulator
from .planning_engine import PlanningEngine
from ..world_model.representation import Entity, EntityType, WorldState
from ..world_model.state_evolution import Action

_SAFE_NAME = re.compile(r"\W+")


def _safe(name: Any) -> str:
    """将任意输入转换为安全标识符字符串。"""
    return _SAFE_NAME.sub("_", str(name)).strip("_").lower() or "x"


class MainChainBridge:
    """认知主链桥接器：连接感知/记忆到决策/规划/行动的自动贯通。"""

    def __init__(
        self,
        decision: Optional[DecisionEngine] = None,
        planning: Optional[PlanningEngine] = None,
        deep: Optional[DeepSimulator] = None,
    ) -> None:
        """初始化 MainChainBridge。"""
        self.decision: DecisionEngine = decision if decision is not None else DecisionEngine()
        self.planning: PlanningEngine = planning if planning is not None else PlanningEngine()
        self.deep: DeepSimulator = deep if deep is not None else DeepSimulator()

        for engine in (self.decision, self.planning):
            if hasattr(engine, "initialize"):
                try:
                    engine.initialize()
                except Exception:
                    pass

    @staticmethod
    def build_world(keywords: List[str], recalled: List[Any]) -> WorldState:
        """从关键词和召回记忆构建世界状态。"""
        keywords = keywords or []
        recalled = recalled or []

        entities: Dict[str, Entity] = {
            f"kw_{i}": Entity(
                name=kw,
                entity_type=EntityType.CONCEPT,
                attributes={"rank": i},
            )
            for i, kw in enumerate(keywords)
        }
        return WorldState(
            entities=entities,
            relations={},
            metadata={
                "keywords": list(keywords),
                "recalled": len(recalled),
                "utility": 0.0,
            },
        )

    def _auto_rules(self, keywords: List[str], recalled_text: str) -> List[Action]:
        """从感知关键词和记忆文本自动派生候选行动及其演化规则。"""
        keywords = keywords or []
        recalled_text = recalled_text or ""

        n = max(1, len(keywords))
        actions: List[Action] = []
        seen: set = set()

        for i, kw in enumerate(keywords):
            atype = f"address_{_safe(kw)}"
            if atype in seen:
                continue
            seen.add(atype)

            salience = 0.5 + 0.4 * (1 - i / n)
            if kw and kw in recalled_text:
                salience = min(1.0, salience + 0.1)

            effect: Dict[str, Any] = {
                "utility": round(salience, 4),
                "addressed": kw,
                "progress": i + 1,
            }

            for engine in (self.decision, self.planning):
                try:
                    engine.register_rule(atype, effect)
                except Exception:
                    pass

            actions.append(Action(action_type=atype))

        defer_effect: Dict[str, Any] = {"utility": 0.1}
        try:
            self.decision.register_rule("defer", defer_effect)
            self.planning.register_rule("defer", defer_effect)
        except Exception:
            pass

        try:
            self.planning.register_rule("consolidate", {"utility": 0.05, "closed": True})
        except Exception:
            pass

        actions.append(Action(action_type="defer"))
        return actions

    @staticmethod
    def _utility(state: WorldState) -> float:
        """提取世界状态的效用值。"""
        if state is None or state.metadata is None:
            return 0.0
        try:
            return float(state.metadata.get("utility", 0.0))
        except (TypeError, ValueError):
            return 0.0

    def step(
        self,
        keywords: List[str],
        recalled: Optional[List[Any]] = None,
        action_executor: Optional[Callable[[Action, WorldState], Any]] = None,
    ) -> Dict[str, Any]:
        """执行一次认知主链步骤。"""
        keywords = keywords or []
        recalled = recalled or []

        recalled_text = " ".join(str(r) for r in recalled)
        state = self.build_world(keywords, recalled)
        actions = self._auto_rules(keywords, recalled_text)

        if len(actions) == 1:
            return {
                "world": state,
                "decision": None,
                "plan": None,
                "deep_rollout": None,
                "chosen_action": None,
                "action_executed": False,
                "action_result": None,
                "candidate_count": len(actions),
                "note": "无感知关键词，仅基线行动",
            }

        try:
            decision = self.decision.decide(state, actions, self._utility)
        except Exception:
            return {
                "world": state,
                "decision": None,
                "plan": None,
                "deep_rollout": None,
                "chosen_action": None,
                "action_executed": False,
                "action_result": None,
                "candidate_count": len(actions),
                "note": "决策引擎异常",
            }

        chosen = getattr(decision, "chosen_action", None)
        chosen_index = getattr(decision, "chosen_index", -1)

        try:
            plans = [
                [chosen] if chosen else [],
                [chosen, Action(action_type="consolidate")] if chosen else [Action(action_type="consolidate")],
            ]
            plan = self.planning.plan(state, plans, self._utility)
        except Exception:
            plan = None

        deep_rollout: Optional[Any] = None
        if self.deep is not None and chosen is not None:
            try:
                deep_rollout = self.deep.rollout(state, [chosen], horizon=3)
            except Exception:
                deep_rollout = None

        chosen_action_type = chosen.action_type if chosen else None
        action_executed = False
        action_result: Any = None

        if chosen is not None and action_executor is not None:
            try:
                action_result = action_executor(chosen, state)
                action_executed = True
            except Exception as e:
                action_executed = False
                action_result = {"error": str(e)}

        return {
            "world": state,
            "decision": decision,
            "plan": plan,
            "deep_rollout": deep_rollout,
            "chosen_action": chosen_action_type,
            "action_executed": action_executed,
            "action_result": action_result,
            "candidate_count": len(actions),
        }
