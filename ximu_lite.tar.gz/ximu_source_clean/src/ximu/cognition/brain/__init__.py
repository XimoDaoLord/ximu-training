# -*- coding: utf-8 -*-
"""认知主链适配层（brain）

把 src/ximu/cognition/ 下原本孤立的真实认知引擎（agi / causal_reasoning /
simulation / world_model / evolution）按蓝图 OMNI-BRAIN V2 的层级组合成
main.py 注册表可直接装配的模块：

- CognitiveSystem  认知/推理核心（GeneralReasoningEngine）
- DecisionEngine   决策（因果推断 + 状态演化预测）
- PlanningEngine   规划（多步序列推演 + 蒙特卡洛策略对比）
- ReflectionEngine 反思（自我评估 + 自我意识 + 元认知偏差检测）
- OmniBrain        总大脑编排（组合上述全部 + Metacognition）

适配器只做组合与生命周期封装，不含占位逻辑；真实算法全部来自既有引擎。
"""
from __future__ import annotations

from .base import CognitiveModule
from .main_chain_bridge import MainChainBridge
from .deep_simulator import DeepSimulator
from .cognitive_pipeline import CognitivePipeline

__all__ = ["CognitiveModule", "MainChainBridge", "DeepSimulator", "CognitivePipeline"]
