# -*- coding: utf-8 -*-
"""认知主链自动贯通编排。"""
from __future__ import annotations

import hashlib
from typing import Any, Dict, List, Optional

from .omni_brain import OmniBrain


class CognitivePipeline:
    """认知主链自动贯通编排器。"""
    RECALL_DOMAIN = "recall"

    def __init__(self, brain: Optional[OmniBrain] = None,
                 perception: Any = None, memory: Any = None,
                 action_executor: Any = None) -> None:
        """初始化认知管线。"""
        self.brain = brain or OmniBrain()
        self.brain.initialize()
        self.perception = perception
        self.memory = memory
        self.action_executor = action_executor
        self._bridge = None

    def bridge(self):
        """懒加载主链贯通桥。"""
        if self._bridge is None:
            from .main_chain_bridge import MainChainBridge
            self._bridge = MainChainBridge(
                decision=self.brain._engines["decision_engine"],
                planning=self.brain._engines["planning_engine"])
        return self._bridge

    def _perceiver(self):
        """获取感知器。"""
        if self.perception is None:
            from src.ximu.core.multimodal._text_perception_parts.part1 import TextPerception
            self.perception = TextPerception()
        return self.perception

    def perceive(self, raw_text: str) -> List[str]:
        """主链真实感知：确定性关键词抽取。"""
        result = self._perceiver().perceive(raw_text, task="KEYWORDS")
        return [str(k) for k in (getattr(result, "labels", None) or [])]

    def recall(self, keywords: List[str], limit: int = 5) -> List[Dict[str, Any]]:
        """按关键词召回中期记忆。"""
        if self.memory is None or not keywords:
            return []
        hits = self.memory.search_middle(keywords, limit=limit)
        facts = {}
        for i, hit in enumerate(hits):
            content = hit.get("content")
            facts[f"经验{i + 1}"] = content if isinstance(content, (str, int, float)) else str(content)[:80]
        if facts:
            self.brain.add_background_knowledge(facts, self.RECALL_DOMAIN)
        return hits

    def memorize(self, problem: str, conclusion: str, keywords: List[str]) -> bool:
        """把本次结论写回中期记忆。"""
        if self.memory is None:
            return False
        key = "cog:" + hashlib.md5(problem.encode("utf-8"), usedforsecurity=False).hexdigest()[:12]
        self.memory.store_middle(key, {"problem": problem, "conclusion": conclusion,
                                       "keywords": keywords}, tags=keywords)
        return True

    def run(self, raw_text: str, problem: Optional[str] = None, memorize: bool = True) -> Dict[str, Any]:
        """跑一条真实输入的完整认知闭环。"""
        target = problem or raw_text
        keywords = self.perceive(raw_text)
        hits = self.recall(keywords)
        cycle = self.brain.cognitive_cycle(target, domain=self.RECALL_DOMAIN if hits else None)
        acting = self.bridge().step(keywords, hits, self.action_executor)
        written = self.memorize(target, cycle["thought"]["conclusion"], keywords) if memorize else False
        return {"keywords": keywords, "recalled_count": len(hits), "recalled": hits,
                "thought": cycle["thought"], "reflection": cycle["reflection"],
                "meta_stats": cycle["meta_stats"], "acting": acting, "memorized": written}