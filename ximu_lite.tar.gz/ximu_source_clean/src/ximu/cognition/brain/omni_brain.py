# -*- coding: utf-8 -*-
"""OMNI-BRAIN 总大脑编排器。"""
from __future__ import annotations

from typing import Any, Callable, Dict, Optional

from .base import CognitiveModule
from .cognitive_system import CognitiveSystem
from .decision_engine import DecisionEngine, DecisionResult
from .planning_engine import PlanningEngine, PlanResult
from .reflection_engine import ReflectionEngine
from .deep_simulator import DeepSimulator
from ..agi.metacognition import Metacognition


class OmniBrain(CognitiveModule):
    """认知核心编排器。"""

    def _build_engines(self) -> None:
        """构建内部引擎实例。"""
        self._engines["cognitive_system"] = CognitiveSystem()
        self._engines["planning_engine"] = PlanningEngine()
        self._engines["decision_engine"] = DecisionEngine()
        self._engines["reflection_engine"] = ReflectionEngine()
        self._engines["metacognition"] = Metacognition()
        self._engines["deep_simulator"] = DeepSimulator()
        for eng in self._engines.values():
            if hasattr(eng, "initialize"):
                eng.initialize()

    def add_background_knowledge(self, facts: Dict[str, Any], domain: str = "recall") -> None:
        """把主链记忆召回的历史经验作为领域知识注入推理核心。"""
        self._ensure_ready()
        self._engines["cognitive_system"].add_knowledge(domain, facts)

    def think(self, problem: str, problem_type: str = "general",
              domain: Optional[str] = None) -> Dict[str, Any]:
        """元认知选策略后执行通用推理。"""
        self._ensure_ready()
        meta: Metacognition = self._engines["metacognition"]
        strategy = meta.select_strategy(problem_type)
        result = self._engines["cognitive_system"].reason(problem, domain)
        return {"strategy": strategy, "conclusion": result.conclusion,
                "confidence": result.confidence, "reasoning_steps": result.reasoning_steps}

    def deliberate(self, state, candidate_actions,
                   evaluator: Optional[Callable] = None) -> DecisionResult:
        """单步决策。"""
        self._ensure_ready()
        return self._engines["decision_engine"].decide(state, candidate_actions, evaluator)

    def make_plan(self, state, candidate_plans,
                  evaluator: Optional[Callable] = None) -> PlanResult:
        """多步规划。"""
        self._ensure_ready()
        return self._engines["planning_engine"].plan(state, candidate_plans, evaluator)

    def deep_simulate(self, world_state, config=None) -> dict:
        """更深世界模型。"""
        return self._engines["deep_simulator"].simulate_world(world_state, config)

    def compare_strategies(self, scenario, strategies, metric_extractor, samples=None):
        """更深模拟：蒙特卡洛多策略对比择优。"""
        return self._engines["deep_simulator"].compare_strategies(
            scenario, strategies, metric_extractor, samples)

    def causal_what_if(self, action_values, target, observed):
        """更深因果：行动变量对目标的反事实推断。"""
        return self._engines["deep_simulator"].causal_what_if(action_values, target, observed)

    def cognitive_cycle(self, problem: str, success: bool = True,
                        domain: Optional[str] = None) -> Dict[str, Any]:
        """完整认知闭环。"""
        self._ensure_ready()
        thought = self.think(problem, domain=domain)
        reflection = self._engines["reflection_engine"].reflect(
            problem, thought["reasoning_steps"], thought["conclusion"])
        self._engines["metacognition"].record_thought(
            thought["strategy"], problem, success, 0.0)
        return {"thought": thought, "reflection": reflection,
                "meta_stats": self._engines["metacognition"].get_metacognition_stats()}