# -*- coding: utf-8 -*-
"""认知系统（推理核心）——主链 cognitive_system 槽位的真实实现。

蓝图 OMNI-BRAIN V2 中 REASONING（推理）层的落地：组合 cognition/agi 的
GeneralReasoningEngine（跨领域推理/类比迁移/抽象概括），
对外暴露 reason/transfer 等真实认知能力，替代此前的 CRUD 模板壳。
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from .base import CognitiveModule
from ..agi.general_reasoning import GeneralReasoningEngine, ReasoningResult


class CognitiveSystem(CognitiveModule):
    """推理核心：封装通用推理引擎，负责问题理解、模式抽取与跨域推理。"""

    def _build_engines(self) -> None:
        """构建并初始化推理引擎实例。"""
        self._engines["general_reasoning"] = GeneralReasoningEngine()

    @property
    def reasoning(self) -> GeneralReasoningEngine:
        """获取通用推理引擎实例。"""
        return self._engines["general_reasoning"]

    def add_knowledge(self, domain: str, facts: Dict[str, Any]) -> None:
        """注入领域知识，供后续推理使用。

        Args:
            domain: 领域标识符。
            facts: 领域知识的事实字典。
        """
        self._ensure_ready()
        self.reasoning.add_domain_knowledge(domain, facts)

    def reason(self, problem: str, domain: Optional[str] = None) -> ReasoningResult:
        """对问题执行通用推理，返回 ReasoningResult（结论/置信度/推理步骤）。

        Args:
            problem: 待推理的问题描述。
            domain: 可选的领域上下文。

        Returns:
            推理结果，包含结论、置信度和推理步骤。
        """
        self._ensure_ready()
        return self.reasoning.reason(problem, domain)

    def transfer(self, src_domain: str, tgt_domain: str, knowledge_key: str) -> Any:
        """把源领域知识类比迁移到目标领域。

        Args:
            src_domain: 源领域标识符。
            tgt_domain: 目标领域标识符。
            knowledge_key: 要迁移的知识键。

        Returns:
            迁移结果。
        """
        self._ensure_ready()
        return self.reasoning.transfer(src_domain, tgt_domain, knowledge_key)

    def stats(self) -> Dict[str, Any]:
        """返回推理统计信息。

        Returns:
            包含推理次数、迁移次数、平均置信度、覆盖领域等统计数据的字典。
        """
        self._ensure_ready()
        return self.reasoning.get_reasoning_stats()
