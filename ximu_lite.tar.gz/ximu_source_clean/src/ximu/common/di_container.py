# -*- coding: utf-8 -*-
"""依赖注入容器

DIContainer 单例：
- register / register_instance / resolve
- 生命周期：singleton / transient / request
- @inject 装饰器自动注入
- 循环依赖检测
- Mock 注入（测试用）
"""
from __future__ import annotations

import functools
import inspect
import threading
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Set,
    Type,
    get_type_hints,
)


class CircularDependencyError(Exception):
    """循环依赖异常。"""


class UnregisteredDependencyError(KeyError):
    """请求未注册接口时抛出的异常。"""

    def __init__(self, interface: Any) -> None:
        """初始化异常。

        Args:
            interface: 未注册的接口
        """
        super().__init__(f"未注册的接口: {interface}")
        self.interface = interface


class DIContainer:
    """线程安全的依赖注入容器单例。

    支持 singleton/transient/request 三种生命周期，
    自动解析构造函数依赖，支持循环依赖检测。
    """

    _instance: Optional[DIContainer] = None
    _lock: threading.Lock = threading.Lock()

    def __init__(self) -> None:
        """初始化容器内部状态。"""
        self._registrations: Dict[Any, Dict[str, Any]] = {}
        self._singletons: Dict[Any, Any] = {}
        self._resolving: Set[Any] = set()
        self._instance_lock: threading.Lock = threading.Lock()
        self._registrations_lock: threading.Lock = threading.Lock()

    @classmethod
    def get_instance(cls) -> DIContainer:
        """获取容器单例（线程安全，双重检查锁模式）。

        Returns:
            DIContainer 单例实例
        """
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls) -> None:
        """重置单例引用，清空所有状态（测试用）。

        下次调用 get_instance 将重建实例。
        """
        with cls._lock:
            if cls._instance is not None:
                cls._instance.reset()
                cls._instance = None

    def reset(self) -> None:
        """重置容器状态。"""
        self._registrations.clear()
        self._singletons.clear()
        self._resolving.clear()

    def register(self, interface: Any, implementation: Optional[Type[Any]] = None,
                 lifetime: str = "singleton", eager: bool = False) -> None:
        """注册接口与实现的绑定。

        Args:
            interface: 用于查找的键（通常是抽象类或字符串标识）。
            implementation: 具体实现类。若为 None，则使用 interface 本身。
            lifetime: 生命周期策略，支持 singleton/transient/request。
            eager: 若为 True 且 lifetime 为 singleton，注册后立即实例化。

        Raises:
            ValueError: 若 lifetime 不在支持列表中。
        """
        valid_lifetimes = {"singleton", "transient", "request"}
        if lifetime not in valid_lifetimes:
            raise ValueError(f"无效的生命周期 '{lifetime}'，支持: {sorted(valid_lifetimes)}")
        impl = implementation if implementation is not None else interface
        with self._registrations_lock:
            self._registrations[interface] = {
                "implementation": impl,
                "lifetime": lifetime,
                "eager": eager,
            }
        if eager and lifetime == "singleton":
            self.resolve(interface)

    def register_instance(self, interface: Any, instance: Any) -> None:
        """注册一个已有实例（强制 singleton 生命周期）。

        Args:
            interface: 用于查找的键。
            instance: 已构造好的对象实例。
        """
        with self._registrations_lock:
            self._registrations[interface] = {
                "implementation": type(instance),
                "lifetime": "singleton",
                "eager": True,
            }
        with self._instance_lock:
            self._singletons[interface] = instance

    def resolve(self, interface: Any) -> Any:
        """解析接口为实例，自动注入构造函数依赖。

        Args:
            interface: 用于查找的键。

        Returns:
            解析得到的实例对象。

        Raises:
            UnregisteredDependencyError: 若接口未注册。
            CircularDependencyError: 若检测到循环依赖。
        """
        with self._registrations_lock:
            if interface not in self._registrations:
                raise UnregisteredDependencyError(interface)
            info = self._registrations[interface]
            lifetime: str = info["lifetime"]
        if lifetime == "singleton":
            with self._instance_lock:
                if interface in self._singletons:
                    return self._singletons[interface]
        if interface in self._resolving:
            chain = " -> ".join(str(i) for i in self._resolving)
            raise CircularDependencyError(f"检测到循环依赖: {chain} -> {interface}")
        self._resolving.add(interface)
        try:
            impl_cls: Type[Any] = info["implementation"]
            instance = self._instantiate(impl_cls)
            if lifetime == "singleton":
                with self._instance_lock:
                    self._singletons[interface] = instance
            return instance
        finally:
            self._resolving.discard(interface)

    def _instantiate(self, cls: Type[Any]) -> Any:
        """实例化类，根据类型注解自动注入已注册的依赖。

        Args:
            cls: 要实例化的类。

        Returns:
            新创建的实例。
        """
        if cls is None or not isinstance(cls, type):
            raise TypeError(f"实现必须是类类型，收到: {type(cls)}")
        try:
            sig = inspect.signature(cls.__init__)
        except (ValueError, TypeError):
            sig = inspect.signature(cls)
        try:
            hints = get_type_hints(cls.__init__)
        except (NameError, AttributeError, TypeError):
            hints = getattr(cls.__init__, "__annotations__", {}) or {}
        kwargs: Dict[str, Any] = {}
        for name, param in sig.parameters.items():
            if name == "self":
                continue
            if name in hints:
                dep_type = hints[name]
                with self._registrations_lock:
                    registered = dep_type in self._registrations
                if registered:
                    kwargs[name] = self.resolve(dep_type)
                elif param.default is not param.empty:
                    kwargs[name] = param.default
                else:
                    raise UnregisteredDependencyError(dep_type)
            elif param.default is not param.empty:
                kwargs[name] = param.default
            else:
                with self._registrations_lock:
                    registered = name in self._registrations
                if registered:
                    kwargs[name] = self.resolve(name)
                else:
                    raise UnregisteredDependencyError(name)
        return cls(**kwargs)

    def resolve_all(self, interface: Any) -> List[Any]:
        """解析所有实现了同一接口的注册项。

        Args:
            interface: 用于查找的键。

        Returns:
            包含解析结果的列表。
        """
        try:
            return [self.resolve(interface)]
        except (UnregisteredDependencyError, CircularDependencyError):
            return []

    def is_registered(self, interface: Any) -> bool:
        """检查接口是否已注册。

        Args:
            interface: 用于查找的键。

        Returns:
            若已注册则返回 True。
        """
        with self._registrations_lock:
            return interface in self._registrations

    def list_registrations(self) -> List[Dict[str, Any]]:
        """获取所有注册项的只读快照。

        Returns:
            包含注册信息的字典列表。
        """
        with self._registrations_lock:
            return [{"interface": k, **dict(v)} for k, v in self._registrations.items()]

    def register_mock(self, interface: Any, mock_instance: Any) -> None:
        """注册 mock 实例（测试用）。

        Args:
            interface: 用于查找的键。
            mock_instance: mock 实例对象。
        """
        self.register_instance(interface, mock_instance)


def inject(cls: Type[Any]) -> Type[Any]:
    """类装饰器：自动注入构造函数依赖。

    使用容器单例解析类及其依赖。

    Args:
        cls: 要装饰的类

    Returns:
        装饰后的类
    """
    original_init = cls.__init__

    @functools.wraps(original_init)
    def wrapped_init(self: Any, *args: Any, **kwargs: Any) -> None:
        container = DIContainer.get_instance()
        sig = inspect.signature(original_init)
        for name, param in sig.parameters.items():
            if name == "self" or name in kwargs:
                continue
            if container.is_registered(name):
                kwargs[name] = container.resolve(name)
        original_init(self, *args, **kwargs)

    cls.__init__ = wrapped_init
    return cls
