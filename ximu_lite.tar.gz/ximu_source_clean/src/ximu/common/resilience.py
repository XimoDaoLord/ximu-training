"""弹性工具整合模块。

整合重试（指数退避+抖动）、熔断（CLOSED/OPEN/HALF_OPEN 三态）、
限流（令牌桶）以及 Fallback 降级功能。
"""
from __future__ import annotations

import functools
import re
import threading
import time
from typing import Any, Callable, Dict, Optional, Tuple, TypeVar

F = TypeVar("F", bound=Callable[..., Any])

_PER_SECOND_MAP: Dict[str, int] = {"s": 1, "m": 60, "h": 3600}


class CircuitBreakerOpen(Exception):
    """熔断器打开时抛出。"""


class RateLimitExceeded(Exception):
    """限流触发时抛出。"""


class _TokenBucket:
    """令牌桶限流器。"""

    def __init__(self, rate_str: str) -> None:
        """
        初始化令牌桶限流器。

        Args:
            rate_str: 限流格式字符串，如 '10/s'、'100/m'、'1000/h'。

        Raises:
            ValueError: 限流格式无法解析时抛出。
        """
        match = re.match(r"(\d+)\s*/\s*(s|m|h)", rate_str.strip())
        if not match:
            raise ValueError(f"无法解析限流格式: {rate_str}，示例: '10/s'")
        count = int(match.group(1))
        unit = match.group(2)
        per_second = _PER_SECOND_MAP[unit]
        self._rate: float = count / per_second
        self._capacity: int = count
        self._tokens: float = float(count)
        self._last_refill: float = time.monotonic()
        self._lock = threading.Lock()

    def acquire(self, block: bool = False) -> bool:
        """
        获取一个令牌。

        Args:
            block: 若为 True，等待直到获得令牌；否则立即返回。

        Returns:
            成功获取令牌返回 True，否则返回 False。
        """
        while True:
            with self._lock:
                now: float = time.monotonic()
                elapsed: float = now - self._last_refill
                self._tokens = min(self._capacity, self._tokens + elapsed * self._rate)
                self._last_refill = now
                if self._tokens >= 1:
                    self._tokens -= 1
                    return True
                if not block:
                    return False
                if self._rate <= 0:
                    return False
                needed: float = (1 - self._tokens) / self._rate
            time.sleep(needed)


class _CircuitBreaker:
    """三态熔断器（CLOSED / OPEN / HALF_OPEN）。"""

    CLOSED: str = "CLOSED"
    OPEN: str = "OPEN"
    HALF_OPEN: str = "HALF_OPEN"

    def __init__(self, threshold: int, cooldown: float = 30.0) -> None:
        """
        初始化熔断器。

        Args:
            threshold: 触发熔断的连续失败次数。
            cooldown: 熔断后进入半开状态的冷却时间（秒）。
        """
        self.threshold: int = threshold
        self.cooldown: float = cooldown
        self.state: str = self.CLOSED
        self._failures: int = 0
        self._opened_at: float = 0.0
        self._inflight: bool = False
        self._lock = threading.Lock()

    def allow_request(self) -> bool:
        """
        检查是否允许请求通过。

        Returns:
            允许请求返回 True，否则返回 False。
        """
        with self._lock:
            if self.state == self.CLOSED:
                return True
            if self.state == self.OPEN:
                if time.monotonic() - self._opened_at >= self.cooldown:
                    self.state = self.HALF_OPEN
                    self._inflight = True
                    return True
                return False
            if self._inflight:
                return False
            self._inflight = True
            return True

    def record_success(self) -> None:
        """
        记录一次成功调用：HALF_OPEN 探测成功则闭合，CLOSED 态清零失败计数。
        """
        with self._lock:
            if self.state == self.HALF_OPEN:
                self.state = self.CLOSED
                self._failures = 0
                self._inflight = False
            elif self.state == self.CLOSED:
                self._failures = 0

    def record_failure(self) -> None:
        """
        记录一次失败调用：HALF_OPEN 探测失败重新打开，CLOSED 态累计到阈值则熔断。
        """
        with self._lock:
            if self.state == self.HALF_OPEN:
                self.state = self.OPEN
                self._opened_at = time.monotonic()
                self._inflight = False
                return
            self._failures += 1
            if self._failures >= self.threshold:
                self.state = self.OPEN
                self._opened_at = time.monotonic()


def _res_check_bucket(
    bucket: Optional[_TokenBucket],
    rate_limit_block: bool,
    fallback: Optional[Callable[..., Any]],
    stats: Dict[str, int],
    *args: Any,
    **kwargs: Any,
) -> Optional[Any]:
    """
    限流闸门：放行返回 None；拦截返回 fallback 结果或抛异常。

    Args:
        bucket: 令牌桶实例，None 表示不限流。
        rate_limit_block: 是否阻塞等待令牌。
        fallback: 降级函数。
        stats: 统计字典。
        args: 原始函数位置参数。
        kwargs: 原始函数关键字参数。

    Returns:
        放行时返回 None，拦截时返回 fallback 结果。

    Raises:
        RateLimitExceeded: 限流触发且无 fallback 时抛出。
    """
    if bucket is None:
        return None
    if bucket.acquire(block=rate_limit_block):
        return None
    stats["rate_limited"] += 1
    if fallback is not None:
        return fallback(*args, **kwargs)
    raise RateLimitExceeded("限流触发")


def _res_check_breaker(
    breaker: Optional[_CircuitBreaker],
    fallback: Optional[Callable[..., Any]],
    stats: Dict[str, int],
    *args: Any,
    **kwargs: Any,
) -> Optional[Any]:
    """
    熔断闸门：允许返回 None；打开返回 fallback 结果或抛异常。

    Args:
        breaker: 熔断器实例，None 表示不熔断。
        fallback: 降级函数。
        stats: 统计字典。
        args: 原始函数位置参数。
        kwargs: 原始函数关键字参数。

    Returns:
        允许时返回 None，拦截时返回 fallback 结果。

    Raises:
        CircuitBreakerOpen: 熔断器打开且无 fallback 时抛出。
    """
    if breaker is None or breaker.allow_request():
        return None
    stats["circuit_open"] += 1
    if fallback is not None:
        return fallback(*args, **kwargs)
    raise CircuitBreakerOpen("熔断器打开")


def _res_invoke_retry(
    func: Callable[..., Any],
    retry: int,
    retry_exc: Tuple[type, ...],
    init_delay: float,
    backoff: float,
    max_delay: float,
    breaker: Optional[_CircuitBreaker],
    stats: Dict[str, int],
    *args: Any,
    **kwargs: Any,
) -> Tuple[Any, Optional[Exception]]:
    """
    重试循环：返回 (result, last_exc)；非可重试异常向外抛。

    Args:
        func: 待执行的函数。
        retry: 最大重试次数。
        retry_exc: 触发重试的异常类型元组。
        init_delay: 首次重试延迟秒数。
        backoff: 退避倍数。
        max_delay: 最大延迟秒数。
        breaker: 熔断器实例。
        stats: 统计字典。
        args: 原始函数位置参数。
        kwargs: 原始函数关键字参数。

    Returns:
        元组 (result, last_exception)，成功时 last_exception 为 None。
    """
    delay: float = init_delay
    last_exc: Optional[Exception] = None

    for attempt in range(retry + 1):
        try:
            result = func(*args, **kwargs)
            if breaker is not None:
                breaker.record_success()
            return result, None
        except retry_exc as exc:  # type: ignore[misc]
            last_exc = exc
            if attempt >= retry:
                break
            stats["retries"] += 1
            time.sleep(min(delay, max_delay))
            delay *= backoff

    if last_exc is not None:
        if breaker is not None:
            breaker.record_failure()
    return None, last_exc


def resilient(
    retry: int = 3,
    circuit_threshold: int = 5,
    circuit_cooldown: float = 30.0,
    rate_limit: Optional[str] = None,
    fallback: Optional[Callable[..., Any]] = None,
    retry_exceptions: Tuple[type, ...] = (Exception,),
    initial_delay: float = 0.1,
    backoff: float = 2.0,
    max_delay: float = 5.0,
    rate_limit_block: bool = False,
) -> Callable[[F], F]:
    """
    弹性装饰器：组合重试 + 熔断 + 限流 + fallback。

    Args:
        retry: 重试次数，0 表示不重试。
        circuit_threshold: 失败多少次后熔断，0 表示不熔断。
        circuit_cooldown: 熔断冷却时间（秒）。
        rate_limit: 限流格式如 '10/s'，None 表示不限流。
        fallback: 降级函数，签名与原函数一致。
        retry_exceptions: 触发重试的异常类型元组。
        initial_delay: 首次重试延迟秒数。
        backoff: 退避倍数。
        max_delay: 最大延迟秒数。
        rate_limit_block: 限流时是否等待，False 则抛 RateLimitExceeded。

    Returns:
        装饰后的函数，保持原始签名不变。
    """
    bucket: Optional[_TokenBucket] = _TokenBucket(rate_limit) if rate_limit else None
    breaker: Optional[_CircuitBreaker] = (
        _CircuitBreaker(circuit_threshold, circuit_cooldown)
        if circuit_threshold > 0
        else None
    )
    stats: Dict[str, int] = {"retries": 0, "circuit_open": 0, "rate_limited": 0}

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            gated = _res_check_bucket(bucket, rate_limit_block, fallback, stats, *args, **kwargs)
            if gated is not None:
                return gated

            gated = _res_check_breaker(breaker, fallback, stats, *args, **kwargs)
            if gated is not None:
                return gated

            result, last_exc = _res_invoke_retry(
                func, retry, retry_exceptions, initial_delay, backoff,
                max_delay, breaker, stats, *args, **kwargs,
            )
            if last_exc is None:
                return result
            if fallback is not None:
                return fallback(*args, **kwargs)
            raise last_exc

        wrapper.get_stats = lambda: dict(stats)  # type: ignore[attr-defined]
        return wrapper  # type: ignore[return-value]

    return decorator
