from __future__ import annotations

import hashlib
import heapq
import math
import threading
import time
from collections import OrderedDict
from queue import Full as QueueFull
from typing import Any, Dict, Iterator, List, Optional, Tuple


# ------------------------------------------------------------------ #
# LRUCache
# ------------------------------------------------------------------ #


class LRUCache:
    """带 TTL 的 LRU 缓存，支持命中率统计。

    线程安全实现，适合单进程并发读写场景。
    """

    def __init__(self, max_size: int = 128, ttl: Optional[float] = None) -> None:
        """初始化LRU缓存

        Args:
            max_size: 缓存最大容量
            ttl: 生存时间（秒），None表示永不过期

        Raises:
            ValueError: max_size 不是正整数时
        """
        if not isinstance(max_size, int) or max_size <= 0:
            raise ValueError(f"LRUCache max_size 必须为正整数，当前: {max_size!r}")

        self._store: OrderedDict[Any, Tuple[float, Any]] = OrderedDict()
        self._max_size = max_size
        self._ttl = ttl
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0

    def get(self, key: Any) -> Optional[Any]:
        """读取缓存：命中则刷新 LRU 顺序并返回值；未命中或已过期返回 None。

        Args:
            key: 缓存键

        Returns:
            缓存值或 None
        """
        with self._lock:
            now = time.monotonic()
            if key in self._store:
                expire_at, value = self._store[key]
                if self._ttl is None or now < expire_at:
                    self._store.move_to_end(key)
                    self._hits += 1
                    return value
                self._store.pop(key, None)
            self._misses += 1
            return None

    def set(self, key: Any, value: Any) -> None:
        """写入缓存：超出 max_size 时淘汰最久未使用项。

        Args:
            key: 缓存键
            value: 缓存值
        """
        with self._lock:
            expire_at = time.monotonic() + self._ttl if self._ttl else 0.0
            self._store[key] = (expire_at, value)
            self._store.move_to_end(key)
            while len(self._store) > self._max_size:
                self._store.popitem(last=False)

    def delete(self, key: Any) -> None:
        """删除指定键；键不存在时静默忽略。

        Args:
            key: 缓存键
        """
        with self._lock:
            self._store.pop(key, None)

    def clear(self) -> None:
        """清空所有条目并重置命中/未命中统计。"""
        with self._lock:
            self._store.clear()
            self._hits = 0
            self._misses = 0

    @property
    def size(self) -> int:
        """当前缓存条目数。"""
        return len(self._store)

    @property
    def hit_rate(self) -> float:
        """命中率：hits / (hits + misses)；无访问记录时返回 0.0。"""
        total = self._hits + self._misses
        return self._hits / total if total > 0 else 0.0

    @property
    def stats(self) -> Dict[str, int]:
        """返回命中/未命中统计字典。

        Returns:
            {'hits': int, 'misses': int}
        """
        with self._lock:
            return {"hits": self._hits, "misses": self._misses}


# ------------------------------------------------------------------ #
# PriorityQueue
# ------------------------------------------------------------------ #


class PriorityQueue:
    """线程安全的优先级队列，越小的优先级越先出队。

    可选 maxsize 用于限制队列长度：0 表示无界；正整数时 put 在满时抛出 QueueFull。
    """

    def __init__(self, maxsize: int = 0) -> None:
        """初始化优先级队列

        Args:
            maxsize: 最大容量，0表示无界

        Raises:
            ValueError: maxsize 为负数时
        """
        if not isinstance(maxsize, int) or maxsize < 0:
            raise ValueError(f"PriorityQueue maxsize 必须为非负整数，当前: {maxsize!r}")

        self._heap: List[Tuple[int, int, Any]] = []
        self._counter = 0
        self._maxsize = maxsize
        self._lock = threading.Lock()
        self._not_empty = threading.Condition(self._lock)

    def put(self, item: Any, priority: int = 0) -> None:
        """入队：priority 越小越先出；同 priority 按入队 FIFO；队列已满时抛 QueueFull。

        Args:
            item: 要入队的元素
            priority: 优先级

        Raises:
            QueueFull: 队列已满
        """
        with self._lock:
            if self._maxsize > 0 and len(self._heap) >= self._maxsize:
                raise QueueFull(f"优先级队列已满，maxsize={self._maxsize}")
            heapq.heappush(self._heap, (priority, self._counter, item))
            self._counter += 1
            self._not_empty.notify()

    def get(self, block: bool = True, timeout: Optional[float] = None) -> Any:
        """出队：默认阻塞等待；block=False 时空队列抛 IndexError；超时抛 TimeoutError。

        Args:
            block: 是否阻塞
            timeout: 阻塞超时时间（秒）

        Returns:
            队首元素

        Raises:
            IndexError: 非阻塞且队列为空
            TimeoutError: 阻塞超时
        """
        with self._not_empty:
            if not block:
                if not self._heap:
                    raise IndexError("队列为空")
                return heapq.heappop(self._heap)[2]

            deadline = None if timeout is None else time.monotonic() + timeout
            while not self._heap:
                remaining = None if deadline is None else deadline - time.monotonic()
                if remaining is not None and remaining <= 0:
                    raise TimeoutError("等待超时")
                self._not_empty.wait(timeout=remaining)

            return heapq.heappop(self._heap)[2]

    def get_nowait(self) -> Any:
        """非阻塞出队；空队列立即抛 IndexError。

        Returns:
            队首元素

        Raises:
            IndexError: 队列为空
        """
        return self.get(block=False)

    def qsize(self) -> int:
        """当前队列长度。"""
        with self._lock:
            return len(self._heap)

    def empty(self) -> bool:
        """队列是否为空。"""
        return self.qsize() == 0


# ------------------------------------------------------------------ #
# BloomFilter
# ------------------------------------------------------------------ #


class BloomFilter:
    """布隆过滤器，使用双重哈希，线程安全。

    适用于大规模元素的存在性判断，允许误判但不允许漏判。
    """

    def __init__(self, capacity: int = 10000, error_rate: float = 0.01) -> None:
        """初始化布隆过滤器

        Args:
            capacity: 预计插入的元素数量
            error_rate: 期望错误率

        Raises:
            ValueError: 参数不合法时
        """
        if not isinstance(capacity, int) or capacity <= 0:
            raise ValueError(f"BloomFilter capacity 必须为正整数，当前: {capacity!r}")
        if not (0.0 < error_rate < 1.0):
            raise ValueError(f"BloomFilter error_rate 必须在 (0,1) 之间，当前: {error_rate!r}")

        self._capacity = capacity
        self._error_rate = error_rate
        self._num_bits = max(
            1,
            int(-capacity * math.log(error_rate) / (math.log(2) ** 2)),
        )
        self._num_hashes = max(
            1,
            int(self._num_bits / capacity * math.log(2)),
        )
        self._bits = bytearray((self._num_bits + 7) // 8)
        self._count = 0
        self._lock = threading.Lock()

    def _hashes(self, item: str) -> List[int]:
        """生成 item 对应的 num_hashes 个位索引列表（双重哈希法）。

        优化：返回完整列表而非生成器。add/contains 均需遍历全部位，
        一次构建列表可省去生成器逐次 yield 的协程切换开销。

        Args:
            item: 要哈希的字符串

        Returns:
            位索引列表
        """
        digest = hashlib.sha256(item.encode()).digest()
        h1 = int.from_bytes(digest[0:4], "big")
        h2 = int.from_bytes(digest[4:8], "big")
        m = self._num_bits
        k = self._num_hashes
        return [(h1 + i * h2) % m for i in range(k)]

    def add(self, item: str) -> None:
        """将 item 加入布隆过滤器；重复加入只会让计数近似+1。

        Args:
            item: 要添加的元素
        """
        with self._lock:
            for bit in self._hashes(item):
                self._bits[bit >> 3] |= 1 << (bit & 7)
            self._count += 1

    def __contains__(self, item: str) -> bool:
        """检查 item 是否可能存在于布隆过滤器中

        Args:
            item: 要检查的元素

        Returns:
            True 表示可能存在，False 表示一定不存在
        """
        with self._lock:
            for bit in self._hashes(item):
                if not (self._bits[bit >> 3] & (1 << (bit & 7))):
                    return False
            return True

    def __len__(self) -> int:
        """返回近似的已插入元素数量。"""
        return self._count

    def merge(self, other: "BloomFilter") -> None:
        """合并另一个同规格的布隆过滤器。

        合并后误差率会上升，适用于分布式布隆过滤器的归并场景。

        Args:
            other: 要合并的布隆过滤器

        Raises:
            ValueError: 位长度或哈希数量不匹配时
        """
        if other._num_bits != self._num_bits or other._num_hashes != self._num_hashes:
            raise ValueError("只能合并规格相同的布隆过滤器")
        with self._lock:
            for i in range(len(self._bits)):
                self._bits[i] |= other._bits[i]
            self._count += other._count

    @property
    def estimated_error_rate(self) -> float:
        """估算当前误判率。

        Returns:
            当前误判率估算值
        """
        if self._count == 0:
            return 0.0
        # _count_set_bits 返回已置位比特数（int）；原先误套 len() 会抛 TypeError，
        # 此处直接用比特数除以总位数得到填充率。
        fill_ratio = self._count_set_bits() / self._num_bits
        return fill_ratio ** self._num_hashes

    def _count_set_bits(self) -> int:
        """统计已置位的比特数。

        优化：整体 bytearray 转大整数后调用 C 层 ``int.bit_count``
        （机器字级 popcount），替代原先逐字节 ``bin(byte).count("1")``
        的 Python 循环，大过滤器下数量级提速。

        Returns:
            已置位的比特总数
        """
        return int.from_bytes(self._bits, "big").bit_count()
