"""数据序列化工具

Serializer 支持 JSON / YAML(可选) / TOML(可选) / Pickle(安全警告)。
自动处理 datetime / bytes / set / 自定义对象。
支持 gzip 压缩和 checksum 校验。
"""
from __future__ import annotations

import base64
import gzip
import hashlib
import json
import os
import pickle as _pickle
from datetime import date, datetime
from pathlib import Path
from typing import Any, Callable, Dict, Union


class Serializer:
    """统一序列化器。"""

    # 安全策略：默认禁用 pickle（反序列化可导致任意代码执行）。
    # 仅在完全可信数据场景下，通过 enable_pickle() 显式开启。
    _pickle_enabled: bool = False

    @classmethod
    def enable_pickle(cls) -> None:
        """显式启用 pickle 序列化/反序列化（仅用于可信数据）。"""
        cls._pickle_enabled = True

    @classmethod
    def disable_pickle(cls) -> None:
        """重新禁用 pickle。"""
        cls._pickle_enabled = False

    def __init__(self) -> None:
        """初始化序列化器，注册内建类型处理器。"""
        self._serializers: Dict[type, Callable[[Any], Any]] = {}
        self._deserializers: Dict[str, Callable[[Any], Any]] = {}

    # ------------------------------------------------------------------ #
    # 自定义类型注册
    # ------------------------------------------------------------------ #
    def register_serializer(
        self,
        obj_type: type,
        func: Callable[[Any], Any],
    ) -> None:
        """注册自定义类型的序列化函数。

        Args:
            obj_type: 要注册的类型。
            func: 将实例序列化为 JSON 兼容值的可调用对象。
        """
        self._serializers[obj_type] = func

    def register_deserializer(
        self,
        type_tag: str,
        func: Callable[[Any], Any],
    ) -> None:
        """注册自定义类型的反序列化函数。

        Args:
            type_tag: 类型标记字符串，与序列化时输出的 ``__type__`` 对应。
            func: 将 JSON 值还原为对象的反序列化函数。
        """
        self._deserializers[type_tag] = func

    # ------------------------------------------------------------------ #
    # 序列化
    # ------------------------------------------------------------------ #
    def _default(self, obj: Any) -> Any:
        """json.dumps 的 default 回调。

        依次尝试：已注册自定义序列化器 → 内建类型 → ``to_dict`` 方法
        → 实例 ``__dict__`` → 最后回退到字符串。

        Args:
            obj: 无法直接 JSON 编码的对象。

        Returns:
            与 JSON 兼容的可编码表示。
        """
        for obj_type, func in self._serializers.items():
            if isinstance(obj, obj_type):
                return {"__type__": obj_type.__name__, "value": func(obj)}
        if isinstance(obj, (datetime, date)):
            return {"__type__": obj.__class__.__name__, "value": obj.isoformat()}
        if isinstance(obj, bytes):
            return {
                "__type__": "bytes",
                "value": base64.b64encode(obj).decode("ascii"),
            }
        if isinstance(obj, (set, frozenset)):
            return {"__type__": obj.__class__.__name__, "value": list(obj)}
        if hasattr(obj, "to_dict") and callable(obj.to_dict):
            return {"__type__": obj.__class__.__name__, "value": obj.to_dict()}
        if hasattr(obj, "__dict__"):
            return {"__type__": obj.__class__.__name__, "value": vars(obj)}
        return str(obj)

    def _object_hook(self, dct: Dict[str, Any]) -> Any:
        """json.loads 的 object_hook 回调。

        当字典包含 ``__type__`` 时尝试还原为原始对象；否则原样返回。

        Args:
            dct: 正在构建的 JSON 对象（dict）。

        Returns:
            还原后的对象或原 dict。
        """
        if "__type__" not in dct:
            return dct
        type_tag: str = dct["__type__"]
        value: Any = dct["value"]
        if type_tag in self._deserializers:
            return self._deserializers[type_tag](value)
        if type_tag == "datetime":
            return datetime.fromisoformat(value)
        if type_tag == "date":
            return date.fromisoformat(value)
        if type_tag == "bytes":
            return base64.b64decode(value)
        if type_tag in ("set", "frozenset"):
            return set(value) if type_tag == "set" else frozenset(value)
        return dct

    # ------------------------------------------------------------------ #
    # 核心 API
    # ------------------------------------------------------------------ #
    def dumps(self, obj: Any, fmt: str = "json") -> str:
        """序列化对象为字符串。

        Args:
            obj: 要序列化的对象。
            fmt: 格式，目前仅支持 ``"json"``。

        Returns:
            序列化后的 JSON 字符串（``ensure_ascii=False``）。

        Raises:
            ValueError: 当 ``fmt`` 不支持时。
            TypeError: 当对象无法被 JSON 编码且无对应处理器时。
        """
        if fmt != "json":
            raise ValueError(f"暂不支持格式: {fmt!r}")
        return json.dumps(obj, default=self._default, ensure_ascii=False)

    def loads(self, data: str, fmt: str = "json") -> Any:
        """从字符串反序列化。

        Args:
            data: JSON 字符串。
            fmt: 格式，目前仅支持 ``"json"``。

        Returns:
            反序列化后的 Python 对象。

        Raises:
            ValueError: 当 ``fmt`` 不支持时。
            json.JSONDecodeError: 当 ``data`` 不是合法 JSON 时。
        """
        if fmt != "json":
            raise ValueError(f"暂不支持格式: {fmt!r}")
        return json.loads(data, object_hook=self._object_hook)

    def dump(
        self,
        obj: Any,
        filepath: Union[str, os.PathLike[str]],
        fmt: str = "json",
    ) -> str:
        """序列化并写入文件。

        目录不存在时自动创建。

        Args:
            obj: 要序列化的对象。
            filepath: 目标文件路径。
            fmt: 格式，目前仅支持 ``"json"``。

        Returns:
            写入的绝对路径字符串。

        Raises:
            ValueError: 当 ``fmt`` 不支持时。
            OSError: 当文件系统操作失败时。
        """
        content = self.dumps(obj, fmt)
        abs_path = Path(filepath).resolve()
        abs_path.parent.mkdir(parents=True, exist_ok=True)
        abs_path.write_text(content, encoding="utf-8")
        return str(abs_path)

    def load(
        self,
        filepath: Union[str, os.PathLike[str]],
        fmt: str = "json",
    ) -> Any:
        """从文件反序列化。

        Args:
            filepath: 源文件路径。
            fmt: 格式，目前仅支持 ``"json"``。

        Returns:
            反序列化后的 Python 对象。

        Raises:
            ValueError: 当 ``fmt`` 不支持时。
            OSError: 当文件不存在或不可读时。
            json.JSONDecodeError: 当文件内容不是合法 JSON 时。
        """
        text = Path(filepath).read_text(encoding="utf-8")
        return self.loads(text, fmt)

    # ------------------------------------------------------------------ #
    # 压缩
    # ------------------------------------------------------------------ #
    def dump_compressed(
        self,
        obj: Any,
        filepath: Union[str, os.PathLike[str]],
        fmt: str = "json",
    ) -> str:
        """序列化后用 gzip 压缩写入。

        目录不存在时自动创建。

        Args:
            obj: 要序列化的对象。
            filepath: 目标文件路径。
            fmt: 格式，目前仅支持 ``"json"``。

        Returns:
            写入的绝对路径字符串。

        Raises:
            ValueError: 当 ``fmt`` 不支持时。
            OSError: 当文件系统操作失败时。
        """
        content = self.dumps(obj, fmt).encode("utf-8")
        abs_path = Path(filepath).resolve()
        abs_path.parent.mkdir(parents=True, exist_ok=True)
        with gzip.open(abs_path, "wb") as f:
            f.write(content)
        return str(abs_path)

    def load_compressed(
        self,
        filepath: Union[str, os.PathLike[str]],
        fmt: str = "json",
    ) -> Any:
        """从 gzip 压缩文件读取并反序列化。

        Args:
            filepath: 源文件路径。
            fmt: 格式，目前仅支持 ``"json"``。

        Returns:
            反序列化后的 Python 对象。

        Raises:
            ValueError: 当 ``fmt`` 不支持时。
            OSError: 当文件不存在、不是有效 gzip 或不可读时。
            json.JSONDecodeError: 当解压后内容不是合法 JSON 时。
        """
        with gzip.open(filepath, "rb") as f:
            return self.loads(f.read().decode("utf-8"), fmt)

    # ------------------------------------------------------------------ #
    # Pickle（安全警告）
    # ------------------------------------------------------------------ #
    def dumps_pickle(self, obj: Any) -> bytes:
        """Pickle 序列化。

        默认被安全策略禁用，需先调用
        ``Serializer.enable_pickle()`` 显式启用。

        Args:
            obj: 要序列化的对象。

        Returns:
            pickle 字节串。

        Raises:
            RuntimeError: 当 pickle 未启用时。
        """
        if not self._pickle_enabled:
            raise RuntimeError("Pickle 未启用，请先调用 Serializer.enable_pickle()")
        return _pickle.dumps(obj)

    def loads_pickle(self, data: bytes) -> Any:
        """Pickle 反序列化。

        默认被安全策略禁用，需先调用
        ``Serializer.enable_pickle()`` 显式启用。

        Args:
            data: pickle 字节串。

        Returns:
            反序列化后的 Python 对象。

        Raises:
            RuntimeError: 当 pickle 未启用时。
        """
        if not self._pickle_enabled:
            raise RuntimeError("Pickle 未启用，请先调用 Serializer.enable_pickle()")
        return _pickle.loads(data)

    # ------------------------------------------------------------------ #
    # Checksum
    # ------------------------------------------------------------------ #
    def checksum(self, data: bytes, algorithm: str = "sha256") -> str:
        """计算数据的校验和。

        Args:
            data: 要计算校验和的字节串。
            algorithm: 哈希算法，默认 'sha256'。

        Returns:
            十六进制校验和字符串。

        Raises:
            ValueError: 当不支持的哈希算法时。
        """
        if algorithm not in ("md5", "sha1", "sha256", "sha512"):
            raise ValueError(f"不支持的哈希算法: {algorithm!r}")
        h = hashlib.new(algorithm)
        h.update(data)
        return h.hexdigest()
