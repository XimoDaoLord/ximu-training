"""通用工具函数。"""

import hashlib
import json
import os
import re
import threading
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Iterable, List, Optional, Set, Tuple, Type, Union

try:
    from .constants import ModuleStatus
except ImportError:
    class ModuleStatus:
        NOT_IMPLEMENTED = "not_implemented"

_MODULE_STATUS_REGISTRY: Dict[str, Dict[str, Any]] = {}
_lock: threading.Lock = threading.Lock()


def generate_id(prefix: str = "id") -> str:
    """生成带前缀的随机短ID。"""
    return f"{prefix}_{os.urandom(6).hex()}"


def timestamp() -> float:
    """返回当前Unix时间戳。"""
    return datetime.now(timezone.utc).timestamp()


def datetime_now() -> str:
    """返回当前UTC时间的ISO8601字符串。"""
    return datetime.now(timezone.utc).isoformat()


def safe_json_dumps(obj: Any, indent: int = 2) -> str:
    """JSON序列化，容忍非标准类型。"""
    def default(o: Any) -> Any:
        if isinstance(o, datetime):
            return o.isoformat()
        if isinstance(o, bytes):
            return o.decode("utf-8", errors="replace")
        if hasattr(o, "__dict__"):
            return o.__dict__
        return str(o)
    return json.dumps(obj, default=default, indent=indent, ensure_ascii=False)


def safe_json_loads(text: str) -> Optional[Any]:
    """JSON反序列化，失败时返回None。"""
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError, ValueError):
        return None


def sha256_hash(data: Union[str, bytes]) -> str:
    """返回数据的SHA256十六进制摘要。"""
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def md5_hash(data: Union[str, bytes]) -> str:
    """返回数据的MD5十六进制摘要。"""
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.md5(data, usedforsecurity=False).hexdigest()


def dedup_list(lst: List[Any], key: Optional[Callable[[Any], Any]] = None) -> List[Any]:
    """保序去重。"""
    seen: Set[Any] = set()
    out: List[Any] = []
    for item in lst:
        k = key(item) if key is not None else item
        if k not in seen:
            seen.add(k)
            out.append(item)
    return out


def human_readable_size(size_bytes: float) -> str:
    """把字节数格式化为人类可读字符串。"""
    if size_bytes < 0:
        size_bytes = 0
    units: List[str] = ["B", "KB", "MB", "GB", "TB", "PB"]
    val = float(size_bytes)
    for unit in units:
        if val < 1024.0 or unit == units[-1]:
            return f"{val:.2f} {unit}"
        val /= 1024.0
    return f"{val:.2f} {units[-1]}"


def format_date(dt: Optional[Any] = None) -> str:
    """格式化日期为YYYY-MM-DD。"""
    if dt is None:
        dt = datetime.now()
    if isinstance(dt, (int, float)):
        dt = datetime.fromtimestamp(dt)
    return dt.strftime("%Y-%m-%d")


def format_time(dt: Optional[Any] = None) -> str:
    """格式化时间为HH:MM:SS。"""
    if dt is None:
        dt = datetime.now()
    if isinstance(dt, (int, float)):
        dt = datetime.fromtimestamp(dt)
    return dt.strftime("%H:%M:%S")


def parse_datetime(text: Optional[str]) -> Optional[datetime]:
    """尝试解析常见日期时间格式字符串。"""
    if not isinstance(text, str) or not text:
        return None
    fmts: Tuple[str, ...] = (
        "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d",
        "%Y/%m/%d %H:%M:%S", "%Y/%m/%d",
    )
    for fmt in fmts:
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return None


def now_iso() -> str:
    """当前UTC时间ISO8601字符串。"""
    return datetime_now()


def safe_get(d: Any, key: str, default: Any = None) -> Any:
    """从dict安全取值。"""
    if isinstance(d, dict):
        return d.get(key, default)
    return default


def ensure_file(path: str, default_content: str = "") -> str:
    """确保文件存在。"""
    abs_path: str = os.path.abspath(path)
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    if not os.path.exists(abs_path):
        with open(abs_path, "w", encoding="utf-8") as f:
            f.write(default_content)
    return abs_path


def safe_remove(path: str) -> Optional[bool]:
    """安全删除文件。"""
    try:
        os.remove(path)
        return True
    except FileNotFoundError:
        return False
    except OSError:
        return None


def dir_exists(path: str) -> bool:
    """检查目录是否存在。"""
    return os.path.isdir(path)


def file_mtime(path: str) -> float:
    """获取文件修改时间。"""
    try:
        return os.path.getmtime(path)
    except OSError:
        return 0.0


def truncate(text: str, max_length: int = 100) -> str:
    """截断文本。"""
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."


def chunk_list(lst: List[Any], size: int) -> List[List[Any]]:
    """把列表按size切成等长子列表。"""
    if not isinstance(size, int) or size <= 0:
        raise ValueError(f"chunk_list size 必须为正整数，当前: {size!r}")
    return [lst[i:i + size] for i in range(0, len(lst), size)]


def flatten_dict(d: Dict[str, Any], parent_key: str = "", sep: str = ".") -> Dict[str, Any]:
    """递归展平嵌套字典。"""
    items: List[Tuple[str, Any]] = []
    for k, v in d.items():
        safe_k: str = k if k != "" else "[empty]"
        new_key: str = f"{parent_key}{sep}{safe_k}" if parent_key else safe_k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """深度合并两个字典。"""
    result = dict(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def validate_email(email: str) -> bool:
    """宽松校验邮箱格式。"""
    if not isinstance(email, str):
        return False
    pattern: str = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return bool(re.match(pattern, email))


def validate_url(url: str) -> bool:
    """宽松校验http/https URL格式。"""
    if not isinstance(url, str):
        return False
    pattern: str = r"^https?://[\w\-]+(\.[\w\-]+)+[/#?]?.*$"
    return bool(re.match(pattern, url))


def retry(max_attempts: int = 3, delay: float = 1.0) -> Callable[..., Any]:
    """返回装饰器，对被装饰函数按指数递增间隔重试。"""
    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exc: Optional[Exception] = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exc = e
                    if attempt < max_attempts:
                        time.sleep(delay * attempt)
            raise last_exc  # type: ignore[misc]
        return wrapper
    return decorator


def register_module_status(module_name: str, status: str, version: str = "0.5", details: Optional[Dict[str, Any]] = None) -> None:
    """注册模块状态。"""
    with _lock:
        _MODULE_STATUS_REGISTRY[module_name] = {
            "status": status, "version": version, "details": details or {},
        }


def get_module_status(module_name: str) -> Dict[str, Any]:
    """查询模块状态。"""
    with _lock:
        info = _MODULE_STATUS_REGISTRY.get(module_name)
    if info is None:
        return {"status": ModuleStatus.NOT_IMPLEMENTED, "version": "0.5", "details": {}}
    return info


def list_module_statuses() -> List[str]:
    """返回所有已注册模块名列表。"""
    with _lock:
        return list(_MODULE_STATUS_REGISTRY.keys())

class Stopwatch:
    """计时器"""
    def __init__(self) -> None:
        self._start: Optional[float] = None
        self._stop: Optional[float] = None
        self.elapsed: float = 0.0

    def start(self) -> "Stopwatch":
        self._start = time.time()
        return self

    def stop(self) -> "Stopwatch":
        self._stop = time.time()
        if self._start is not None:
            self.elapsed = self._stop - self._start
        return self

def now_timestamp() -> float:
    """获取当前时间戳"""
    return time.time()


def ensure_dir(path: str) -> str:
    """确保目录存在。"""
    os.makedirs(path, exist_ok=True)
    return path


def score_stored_item(item: Any, query: str) -> float:
    """为存储项与查询的相关性打分。"""
    return 0.0


class Result:
    """统一返回结果。"""
    def __init__(self, success: bool = True, data: Any = None, error: str = "") -> None:
        self.success = success
        self.data = data
        self.error = error

    def __bool__(self) -> bool:
        return self.success
