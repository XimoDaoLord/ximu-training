"""系统信息收集工具

收集硬件、系统、Python、进程和网络信息，用于诊断和调试。
优先使用 psutil，不可用时回退到标准库。

版本: 0.5
"""
from __future__ import annotations

import json
import logging
import os
import platform
import socket
import sys
import time
from datetime import datetime, timezone
from typing import Any, Dict

try:
    import psutil  # type: ignore
    _HAS_PSUTIL = True
except ImportError:  # pragma: no cover
    _HAS_PSUTIL = False

__version__ = "0.5"
logger = logging.getLogger(__name__)


def _hardware_info() -> Dict[str, Any]:
    """收集硬件信息：CPU、内存、磁盘、GPU。

    Returns:
        包含硬件详细信息的字典。
    """
    info: Dict[str, Any] = {}
    if _HAS_PSUTIL:
        info["cpu_count_logical"] = psutil.cpu_count(logical=True)
        info["cpu_count_physical"] = psutil.cpu_count(logical=False)
        freq = psutil.cpu_freq()
        info["cpu_freq_mhz"] = freq.current if freq else 0.0
        vm = psutil.virtual_memory()
        info["memory_total_gb"] = round(vm.total / (1024 ** 3), 2)
        du = psutil.disk_usage("/")
        info["disk_total_gb"] = round(du.total / (1024 ** 3), 2)
    else:  # pragma: no cover
        info["cpu_count_logical"] = os.cpu_count() or 0
        info["cpu_count_physical"] = None
        info["cpu_freq_mhz"] = None
        info["memory_total_gb"] = None
        info["disk_total_gb"] = None

    # GPU 信息（可选，通过 nvidia-smi 或 CUDA 环境变量探测）
    gpu_info: Dict[str, Any] = {"available": False}
    cuda_visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if cuda_visible:
        gpu_info["available"] = True
        gpu_info["cuda_visible_devices"] = cuda_visible
    info["gpu"] = gpu_info
    return info


def _system_info() -> Dict[str, Any]:
    """收集操作系统信息。

    Returns:
        包含操作系统详细信息的字典。
    """
    boot_ts: float | None = None
    uptime: float | None = None

    if _HAS_PSUTIL:
        try:
            boot_ts = psutil.boot_time()
            uptime = time.time() - boot_ts
        except Exception as e:
            logger.warning("Failed to get system boot time via psutil: %s", e)
    else:  # pragma: no cover
        # 标准库无法获取精确启动时间，标记为不可用
        logger.warning("psutil not available, boot time estimation unavailable.")
        boot_ts = None
        uptime = None

    system_info: Dict[str, Any] = {
        "os": platform.system(),
        "os_release": platform.release(),
        "os_version": platform.version(),
        "machine": platform.machine(),
        "hostname": socket.gethostname(),
        "boot_time": datetime.fromtimestamp(boot_ts, tz=timezone.utc).isoformat() if boot_ts else None,
        "uptime_seconds": round(uptime, 1) if uptime is not None else None,
    }
    return system_info


def _python_info() -> Dict[str, Any]:
    """收集 Python 运行时信息。

    Returns:
        包含 Python 版本和路径信息的字典。
    """
    return {
        "version": platform.python_version(),
        "implementation": platform.python_implementation(),
        "executable": sys.executable,
        "prefix": sys.prefix,
        "path": list(sys.path[:5]),
    }


def _process_info() -> Dict[str, Any]:
    """收集当前进程信息。

    Returns:
        包含进程 ID、内存、CPU 使用率和线程数的字典。
    """
    pid = os.getpid()
    result: Dict[str, Any] = {"pid": pid}
    if _HAS_PSUTIL:
        try:
            p = psutil.Process(pid)
            result["threads"] = p.num_threads()
            mem = p.memory_info()
            result["memory_rss_mb"] = round(mem.rss / (1024 ** 2), 2)
            result["cpu_percent"] = p.cpu_percent(interval=0.1)
            result["create_time"] = datetime.fromtimestamp(
                p.create_time(), tz=timezone.utc
            ).isoformat()
        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            logger.warning("Failed to read process details for PID %d: %s", pid, e)
            result["error"] = "无法读取进程详情"
    else:  # pragma: no cover
        result["error"] = "psutil 不可用，无法读取进程详情"
    return result


def _network_info() -> Dict[str, Any]:
    """收集网络信息。

    Returns:
        包含主机名、IP 地址和连接统计的字典。
    """
    result: Dict[str, Any] = {"hostname": socket.gethostname()}
    try:
        result["ip_address"] = socket.gethostbyname(socket.gethostname())
    except socket.gaierror:  # pragma: no cover
        logger.warning("Failed to resolve hostname to IP address.")
        result["ip_address"] = "127.0.0.1"

    if _HAS_PSUTIL:
        try:
            conns = psutil.net_connections()
            result["connection_count"] = len(conns)
            result["established_count"] = sum(
                1 for c in conns if c.status == "ESTABLISHED"
            )
        except (psutil.AccessDenied, PermissionError) as e:
            logger.warning("Failed to get network connections: %s", e)
            result["connection_count"] = None
            result["established_count"] = None
    else:  # pragma: no cover
        result["connection_count"] = None
        result["established_count"] = None

    return result


def get_system_info() -> Dict[str, Any]:
    """收集完整的系统信息。

    Returns:
        包含 hardware / system / python / process / network 五个字段的字典。
    """
    logger.info("Collecting system diagnostic information...")
    return {
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "hardware": _hardware_info(),
        "system": _system_info(),
        "python": _python_info(),
        "process": _process_info(),
        "network": _network_info(),
        "psutil_available": _HAS_PSUTIL,
    }


def export_diagnostic_report(filepath: str) -> str:
    """一键导出诊断报告到 JSON 文件。

    Args:
        filepath: 输出文件路径。

    Returns:
        实际写入的文件绝对路径。

    Raises:
        OSError: 如果文件写入失败。
    """
    report = get_system_info()
    abs_path = os.path.abspath(filepath)
    dir_path = os.path.dirname(abs_path) or "."
    os.makedirs(dir_path, exist_ok=True)

    try:
        with open(abs_path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        logger.info("Diagnostic report exported to: %s", abs_path)
        return abs_path
    except (IOError, OSError) as e:
        logger.error("Failed to write diagnostic report to %s: %s", abs_path, e)
        raise
