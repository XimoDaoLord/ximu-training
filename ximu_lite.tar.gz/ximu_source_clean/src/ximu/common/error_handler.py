"""统一错误处理工具。

提供以下功能：
- @catch_exceptions 装饰器：捕获异常、记录日志、返回 Result
- 错误码映射表
- format_error 统一格式化
- ErrorContext 错误上下文管理器
- 全局错误上报回调注册

版本: 0.5
"""

from __future__ import annotations

import functools
import logging
import traceback
from typing import Any, Callable, Dict, Optional, Tuple, Type

from .utils import Result

logger = logging.getLogger(__name__)

# 错误码映射表
ERROR_CODES: Dict[Type[BaseException], str] = {
    ConnectionError: "E1001",
    TimeoutError: "E1002",
    OSError: "E1003",
    ValueError: "E2001",
    KeyError: "E2002",
    TypeError: "E2003",
    AttributeError: "E2004",
    FileNotFoundError: "E2005",
    PermissionError: "E2006",
    NotImplementedError: "E3001",
    RuntimeError: "E3002",
}

# 全局错误上报回调
_report_callback: Optional[Callable[[Dict[str, Any]], None]] = None


def register_report_callback(cb: Optional[Callable[[Dict[str, Any]], None]]) -> None:
    """注册全局错误上报回调；传 None 注销。

    Args:
        cb: 回调函数，接收格式化后的错误信息字典；为 None 时清除当前回调。
    """
    global _report_callback
    _report_callback = cb
    if cb:
        logger.debug("已注册错误上报回调")
    else:
        logger.debug("已注销错误上报回调")


def _error_code(exc: BaseException) -> str:
    """根据异常类型查找错误码。

    Args:
        exc: 异常实例。

    Returns:
        对应的错误代码字符串；若未找到匹配，返回 "E9999"。
    """
    for exc_type, code in ERROR_CODES.items():
        if isinstance(exc, exc_type):
            return code
    return "E9999"


def format_error(
    exc: BaseException,
    context: Optional[Dict[str, Any]] = None,
    include_traceback: bool = False,
) -> Dict[str, Any]:
    """统一格式化错误信息为结构化字典。

    Args:
        exc: 异常对象。
        context: 可选上下文信息。
        include_traceback: 是否在结果中携带完整堆栈（默认 False，安全）。
            完整堆栈默认只写入日志，不返回，避免泄露文件路径/代码行。

    Returns:
        包含 code / message / type / traceback / context 的字典。
    """
    context_dict = context if context is not None else {}
    tb = traceback.format_exc() if include_traceback else None
    return {
        "code": _error_code(exc),
        "message": str(exc),
        "type": type(exc).__name__,
        "traceback": tb,
        "context": context_dict,
    }


def _safe_call_report_callback(info: Dict[str, Any], func_name: str) -> None:
    """安全调用全局错误上报回调。

    Args:
        info: 格式化后的错误信息字典。
        func_name: 触发异常的函数或上下文名称，用于日志。
    """
    if _report_callback is not None:
        try:
            _report_callback(info)
        except Exception:
            logger.warning("错误上报回调执行失败 [%s]", func_name, exc_info=True)


def catch_exceptions(
    exceptions: Tuple[Type[BaseException], ...] = (Exception,),
    default_return: Any = None,
    log_error: bool = True,
    return_result: bool = True,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """异常捕获装饰器。

    Args:
        exceptions: 要捕获的异常类型元组。
        default_return: 发生异常时的默认返回值（return_result=False 时生效）。
        log_error: 是否记录错误日志。
        return_result: 为 True 时返回 Result 对象，否则返回 default_return。

    Returns:
        装饰器函数。
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                data = func(*args, **kwargs)
                if return_result:
                    return Result(success=True, data=data)
                return data
            except exceptions as exc:
                info = format_error(exc, {"function": func.__name__})
                if log_error:
                    logger.error(
                        "错误 [%s] %s: %s",
                        info["code"],
                        func.__name__,
                        exc,
                        exc_info=True,
                    )
                _safe_call_report_callback(info, func.__name__)
                if return_result:
                    return Result(
                        success=False,
                        error=info["code"],
                        metadata=info,
                    )
                return default_return

        return wrapper

    return decorator


class ErrorContext:
    """错误上下文管理器：在 with 块中统一捕获并格式化异常。

    用法::

        with ErrorContext("处理用户请求", raise_on_error=False) as ctx:
            do_something()
        if ctx.has_error:
            print(ctx.error_info)
    """

    def __init__(
        self,
        name: str = "",
        raise_on_error: bool = False,
        log_error: bool = True,
    ) -> None:
        """初始化错误上下文。

        Args:
            name: 上下文名称，用于日志和错误信息。
            raise_on_error: 若为 True，发生异常时重新抛出；否则抑制异常。
            log_error: 是否记录错误日志。
        """
        self.name = name
        self.raise_on_error = raise_on_error
        self.log_error = log_error
        self.error_info: Optional[Dict[str, Any]] = None
        self.has_error = False

    def __enter__(self) -> "ErrorContext":
        """进入上下文。

        Returns:
            自身实例。
        """
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Any,
    ) -> bool:
        """退出上下文，处理异常。

        Args:
            exc_type: 异常类型。
            exc_val: 异常实例。
            exc_tb: 异常回溯。

        Returns:
            True 表示异常被抑制，False 表示异常继续传播。
        """
        if exc_val is not None:
            self.error_info = format_error(exc_val, {"context_name": self.name})
            self.has_error = True
            if self.log_error:
                logger.error(
                    "上下文 [%s] 发生错误 [%s]: %s",
                    self.name,
                    self.error_info["code"],
                    exc_val,
                    exc_info=True,
                )
            _safe_call_report_callback(self.error_info, self.name)
            return not self.raise_on_error
        return False
