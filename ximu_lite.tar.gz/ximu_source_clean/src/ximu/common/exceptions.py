"""汐沫AI - 通用异常类定义。"""

import json
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional


class XIMUBaseError(Exception):
    """汐沫AI基础异常类。"""

    def __init__(self, message: str = "发生未知错误", error_code: str = "UNKNOWN_ERROR", details: Optional[Dict[str, Any]] = None, cause: Optional[Exception] = None) -> None:
        """初始化基础异常。"""
        self.message: str = message
        self.error_code: str = error_code
        self.details: Dict[str, Any] = details or {}
        self.cause: Optional[Exception] = cause
        self.timestamp: str = datetime.now().isoformat()
        self.error_id: str = uuid.uuid4().hex[:16]
        super().__init__(self.message)

    def to_dict(self) -> Dict[str, Any]:
        """将异常序列化为字典。"""
        result: Dict[str, Any] = {
            "error_id": self.error_id,
            "error_code": self.error_code,
            "message": self.message,
            "timestamp": self.timestamp,
            "details": self.details,
        }
        if self.cause:
            result["cause"] = str(self.cause)
            result["cause_type"] = type(self.cause).__name__
        return result

    def to_json(self) -> str:
        """将异常序列化为JSON字符串。"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)

    def __str__(self) -> str:
        return f"[{self.error_code}] {self.message}"

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(error_code='{self.error_code}', "
            f"message='{self.message}')"
        )


class BusinessError(XIMUBaseError):
    """业务逻辑异常。"""

    def __init__(self, message: str = "业务逻辑错误", error_code: str = "BUSINESS_ERROR", business_type: str = "general", details: Optional[Dict[str, Any]] = None, cause: Optional[Exception] = None) -> None:
        """初始化业务异常。"""
        self.business_type: str = business_type
        super().__init__(message, error_code, details, cause)

    def to_dict(self) -> Dict[str, Any]:
        """序列化异常为字典。"""
        result = super().to_dict()
        result["business_type"] = self.business_type
        return result


class SystemError(XIMUBaseError):
    """系统级异常。"""

    def __init__(self, message: str = "系统错误", error_code: str = "SYSTEM_ERROR", system_component: str = "unknown", severity: str = "error", details: Optional[Dict[str, Any]] = None, cause: Optional[Exception] = None) -> None:
        """初始化系统异常。"""
        self.system_component: str = system_component
        self.severity: str = severity
        super().__init__(message, error_code, details, cause)

    def to_dict(self) -> Dict[str, Any]:
        """序列化异常为字典。"""
        result = super().to_dict()
        result["system_component"] = self.system_component
        result["severity"] = self.severity
        return result


class NetworkError(XIMUBaseError):
    """网络异常。"""

    def __init__(self, message: str = "网络错误", error_code: str = "NETWORK_ERROR", url: Optional[str] = None, status_code: Optional[int] = None, timeout: bool = False, details: Optional[Dict[str, Any]] = None, cause: Optional[Exception] = None) -> None:
        """初始化网络异常。"""
        self.url: Optional[str] = url
        self.status_code: Optional[int] = status_code
        self.timeout: bool = timeout
        super().__init__(message, error_code, details, cause)

    def to_dict(self) -> Dict[str, Any]:
        """序列化异常为字典。"""
        result = super().to_dict()
        result["url"] = self.url
        result["status_code"] = self.status_code
        result["timeout"] = self.timeout
        return result


class DataError(XIMUBaseError):
    """数据异常。"""

    def __init__(self, message: str = "数据错误", error_code: str = "DATA_ERROR", data_type: str = "unknown", record_id: Optional[str] = None, details: Optional[Dict[str, Any]] = None, cause: Optional[Exception] = None) -> None:
        """初始化数据异常。"""
        self.data_type: str = data_type
        self.record_id: Optional[str] = record_id
        super().__init__(message, error_code, details, cause)

    def to_dict(self) -> Dict[str, Any]:
        """序列化异常为字典。"""
        result = super().to_dict()
        result["data_type"] = self.data_type
        result["record_id"] = self.record_id
        return result


class ValidationError(XIMUBaseError):
    """验证异常。"""

    def __init__(self, message: str = "验证失败", error_code: str = "VALIDATION_ERROR", field: Optional[str] = None, field_value: Any = None, constraints: Optional[List[str]] = None, details: Optional[Dict[str, Any]] = None, cause: Optional[Exception] = None) -> None:
        """初始化验证异常。"""
        self.field: Optional[str] = field
        self.field_value: Any = field_value
        self.constraints: List[str] = constraints or []
        super().__init__(message, error_code, details, cause)

    def to_dict(self) -> Dict[str, Any]:
        """序列化异常为字典。"""
        result = super().to_dict()
        result["field"] = self.field
        result["field_value"] = (str(self.field_value) if self.field_value is not None else None)
        result["constraints"] = self.constraints
        return result


class ConfigurationError(XIMUBaseError):
    """配置异常。"""

    def __init__(self, message: str = "配置错误", error_code: str = "CONFIG_ERROR", config_key: Optional[str] = None, config_value: Any = None, expected_type: Optional[str] = None, details: Optional[Dict[str, Any]] = None, cause: Optional[Exception] = None) -> None:
        """初始化配置异常。"""
        self.config_key: Optional[str] = config_key
        self.config_value: Any = config_value
        self.expected_type: Optional[str] = expected_type
        super().__init__(message, error_code, details, cause)

    def to_dict(self) -> Dict[str, Any]:
        """序列化异常为字典。"""
        result = super().to_dict()
        result["config_key"] = self.config_key
        result["config_value"] = (str(self.config_value) if self.config_value is not None else None)
        result["expected_type"] = self.expected_type
        return result


class PermissionError(XIMUBaseError):
    """权限异常。"""

    def __init__(self, message: str = "权限不足", error_code: str = "PERMISSION_DENIED", user_id: Optional[str] = None, required_permission: Optional[str] = None, resource: Optional[str] = None, details: Optional[Dict[str, Any]] = None, cause: Optional[Exception] = None) -> None:
        """初始化权限异常。"""
        self.user_id: Optional[str] = user_id
        self.required_permission: Optional[str] = required_permission
        self.resource: Optional[str] = resource
        super().__init__(message, error_code, details, cause)

    def to_dict(self) -> Dict[str, Any]:
        """序列化异常为字典。"""
        result = super().to_dict()
        result["user_id"] = self.user_id
        result["required_permission"] = self.required_permission
        result["resource"] = self.resource
        return result


class TimeoutError(XIMUBaseError):
    """超时异常。"""

    def __init__(self, message: str = "操作超时", error_code: str = "TIMEOUT_ERROR", operation: str = "unknown", timeout_seconds: float = 30.0, elapsed_seconds: Optional[float] = None, details: Optional[Dict[str, Any]] = None, cause: Optional[Exception] = None) -> None:
        """初始化超时异常。"""
        self.operation: str = operation
        self.timeout_seconds: float = timeout_seconds
        self.elapsed_seconds: Optional[float] = elapsed_seconds
        super().__init__(message, error_code, details, cause)

    def to_dict(self) -> Dict[str, Any]:
        """序列化异常为字典。"""
        result = super().to_dict()
        result["operation"] = self.operation
        result["timeout_seconds"] = self.timeout_seconds
        result["elapsed_seconds"] = self.elapsed_seconds
        return result
