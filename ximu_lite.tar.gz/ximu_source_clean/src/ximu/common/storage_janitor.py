# -*- coding: utf-8 -*-
"""数据工作区存储巡检与安全清理（端侧磁盘紧张，且数据要收拢在单一分类目录）。

基于 ``src.ximu.common.constants.XIMU_DATA_ROOT`` 统一数据根，按类别统计占用，
并只清理“可再生垃圾”：tmp/cache 内容、__pycache__、*.tmp、过期 *.part、
超量轮转日志、超量备份。**绝不删除**数据库、模型、记忆、上传/导出的用户数据、
快照（断点保存）、沙箱数据，以及源码/技能/蓝图。

默认 ``dry_run=True`` 只报告不动盘；真正删除需显式 ``dry_run=False``，且每个
待删路径都做根目录约束（commonpath），任何越界路径直接跳过。
"""
from __future__ import annotations

import os
import shutil
import time
from typing import Any, Dict, List, Optional

try:  # 同层模块，包内绝对导入；单测从仓库根运行
    from src.ximu.common.constants import XIMU_DATA_ROOT
except Exception:  # pragma: no cover - 兼容直接执行
    XIMU_DATA_ROOT = os.environ.get("XIMU_DATA_ROOT", "./data")


def data_root(root: Optional[str] = None) -> str:
    """返回数据根的绝对路径；root 可覆盖（测试用）。

    【数据根统一】权威解析集中在 ``src.ximu.core.data_root.get_data_root()``
    （Android 真机可写根 -> 项目根 data/）。此处保留旧函数名做薄包装并委托之，
    禁止再散落第二套根解析。
    """
    if root:
        return os.path.abspath(root)
    try:
        from src.ximu.core.data_root import get_data_root
        return os.path.abspath(get_data_root())
    except Exception:
        base = XIMU_DATA_ROOT
        return os.path.abspath(base)

# 已知类别（统一分类目录）
CATEGORY_DIRS = ["db", "logs", "models", "downloads", "backups", "cache",
                 "tmp", "uploads", "memory", "exports", "snapshots", "sandbox",
                 "maintenance"]
# 可整体清理内容的目录（都是可再生的临时/缓存）
CLEANABLE_DIRS = {"tmp", "cache"}
# 按保留份数清理的类别
ROTATION_CATEGORIES = {"logs": 5, "backups": 5}
# 绝对禁止自动删除的类别（用户数据/资产/状态）
PROTECTED_CATEGORIES = {"db", "models", "memory", "uploads", "exports",
                        "snapshots", "sandbox", "maintenance",
                        "config", "skills", "blueprints"}
# 不允许把这些根设为清理根，防止误删
_FORBIDDEN_ROOTS = {"/", os.path.expanduser("~"), os.path.expanduser("~/.")}


def _within_root(path: str, root: str) -> bool:
    """判断路径是否在根目录下。

    Args:
        path: 待检查的路径。
        root: 根目录路径。

    Returns:
        如果路径在根目录下返回 True，否则返回 False。
    """
    try:
        return os.path.commonpath([os.path.abspath(path), root]) == root
    except ValueError:
        return False


def _scan_dir(path: str) -> Dict[str, int]:
    """递归统计目录字节数/文件数（不跟随符号链接，避免越界统计）。

    Args:
        path: 要扫描的目录路径。

    Returns:
        包含 'bytes' 和 'files' 键的字典。
    """
    size = 0
    files = 0
    for dirpath, dirnames, filenames in os.walk(path, followlinks=False):
        for name in filenames:
            fp = os.path.join(dirpath, name)
            if os.path.islink(fp):
                continue
            try:
                size += os.path.getsize(fp)
                files += 1
            except OSError:
                pass
    return {"bytes": size, "files": files}


def usage_report(root: Optional[str] = None) -> Dict[str, Any]:
    """按类别统计数据根占用，并返回磁盘可用空间与 other（未归类）。

    Args:
        root: 可选的根目录覆盖值。

    Returns:
        包含 root, exists, total_bytes, total_files, categories, other, disk 键的字典。
    """
    base = data_root(root)
    report: Dict[str, Any] = {"root": base, "exists": os.path.isdir(base),
                              "total_bytes": 0, "total_files": 0,
                              "categories": {}, "other": {"bytes": 0, "files": 0}}
    if not report["exists"]:
        return report
    accounted: Dict[str, Dict[str, int]] = {}
    known = set(CATEGORY_DIRS)
    for name in CATEGORY_DIRS:
        d = os.path.join(base, name)
        if os.path.isdir(d):
            accounted[name] = _scan_dir(d)
    # 顶层未归类内容计入 other（不含已知类别）
    other = {"bytes": 0, "files": 0}
    for entry in os.scandir(base):
        if entry.name in known or entry.name.startswith("."):
            continue
        try:
            p = entry.path
            if entry.is_dir(follow_symlinks=False):
                st = _scan_dir(p)
            elif entry.is_file(follow_symlinks=False):
                st = {"bytes": entry.stat().st_size, "files": 1}
            else:
                continue
            other["bytes"] += st["bytes"]
            other["files"] += st["files"]
        except OSError:
            pass
    report["categories"] = accounted
    report["other"] = other
    for grp in list(accounted.values()) + [other]:
        report["total_bytes"] += grp["bytes"]
        report["total_files"] += grp["files"]
    try:
        du = shutil.disk_usage(base)
        report["disk"] = {"total": du.total, "used": du.used, "free": du.free,
                          "used_pct": round(du.used * 100.0 / du.total, 2)}
    except OSError:
        report["disk"] = None
    return report


def _list_files_mtime(path: str) -> List[str]:
    """列出目录下所有文件，按修改时间降序排序。

    Args:
        path: 目录路径。

    Returns:
        按修改时间降序排序的文件路径列表。
    """
    out: List[str] = []
    if not os.path.isdir(path):
        return out
    for dirpath, _dirs, files in os.walk(path, followlinks=False):
        for name in files:
            fp = os.path.join(dirpath, name)
            if not os.path.islink(fp):
                out.append(fp)
    out.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return out


def plan_cleanup(root: Optional[str] = None, keep_logs: int = 5,
                 keep_backups: int = 5, stale_part_hours: float = 24.0) -> List[Dict[str, str]]:
    """列出待清理项 [{path, category}]，不删除；受保护类别永不入列。

    Args:
        root: 可选的根目录覆盖值。
        keep_logs: 保留的日志文件数量。
        keep_backups: 保留的备份文件数量。
        stale_part_hours: 过期 .part 文件的阈值小时数。

    Returns:
        待清理项列表，每项包含 path 和 category。
    """
    base = data_root(root)
    candidates: List[Dict[str, str]] = []
    if not os.path.isdir(base) or os.path.abspath(base) in _FORBIDDEN_ROOTS:
        return candidates
    now = time.time()
    stale_secs = max(0.0, float(stale_part_hours)) * 3600.0

    def add(path: str, category: str) -> None:
        ap = os.path.abspath(path)
        if _within_root(ap, base) and not os.path.islink(ap):
            candidates.append({"path": ap, "category": category})

    # 1) tmp/cache 内全部文件；任意层级 __pycache__；*.tmp
    for top in CLEANABLE_DIRS:
        for fp in _list_files_mtime(os.path.join(base, top)):
            add(fp, top)
    for dirpath, dirnames, filenames in os.walk(base, followlinks=False):
        if "__pycache__" in dirnames:
            pdir = os.path.join(dirpath, "__pycache__")
            for fp in _list_files_mtime(pdir):
                add(fp, "pycache")
            dirnames.remove("__pycache__")
        for name in filenames:
            if name.endswith(".tmp"):
                add(os.path.join(dirpath, name), "tmp_ext")
    # 2) downloads 下过期 *.part（未完成且长时间无变化）
    for fp in _list_files_mtime(os.path.join(base, "downloads")):
        if fp.endswith(".part") and (now - os.path.getmtime(fp)) >= stale_secs:
            add(fp, "stale_part")
    # 3) 超量轮转日志 / 备份
    old_logs = _plan_rotation_for(base, "logs", keep_logs)
    old_backups = _plan_rotation_for(base, "backups", keep_backups)
    for fp in old_logs:
        add(fp, "logs")
    for fp in old_backups:
        add(fp, "backups")
    # 去重并保持顺序
    seen = set()
    uniq = []
    for item in candidates:
        if item["path"] not in seen:
            seen.add(item["path"])
            uniq.append(item)
    return uniq


def _plan_rotation_for(base: str, category: str, keep: int) -> List[str]:
    """计划保留指定数量的文件，返回超出保留量的文件路径列表。

    Args:
        base: 基础目录路径。
        category: 类别名称（logs 或 backups）。
        keep: 保留的文件数量。

    Returns:
        需要删除的文件路径列表。
    """
    d = os.path.join(base, category)
    files = _list_files_mtime(d)
    if category == "backups":
        files = [p for p in files if p.lower().endswith((".zip", ".tar", ".gz", ".bak"))]
    return files[keep:] if keep >= 0 else []


def cleanup(dry_run: bool = True, root: Optional[str] = None, keep_logs: int = 5,
            keep_backups: int = 5, stale_part_hours: float = 24.0) -> Dict[str, Any]:
    """执行（或预演）清理，返回删除清单、释放字节数与分类统计。

    Args:
        dry_run: 是否只预演不实际删除。
        root: 可选的根目录覆盖值。
        keep_logs: 保留的日志文件数量。
        keep_backups: 保留的备份文件数量。
        stale_part_hours: 过期 .part 文件的阈值小时数。

    Returns:
        包含 removed, freed, errors, by_category 键的字典。
    """
    base = data_root(root)
    plan = plan_cleanup(root=base, keep_logs=keep_logs, keep_backups=keep_backups,
                        stale_part_hours=stale_part_hours)
    by_cat: Dict[str, int] = {}
    removed: List[str] = []
    errors: List[Dict[str, str]] = []
    freed = 0
    for item in plan:
        fp = item["path"]
        cat = item["category"]
        try:
            sz = os.path.getsize(fp)
        except OSError:
            sz = 0
        if dry_run:
            by_cat[cat] = by_cat.get(cat, 0) + sz
            freed += sz
            removed.append(fp)
            continue
        try:
            os.remove(fp)
            by_cat[cat] = by_cat.get(cat, 0) + sz
            freed += sz
            removed.append(fp)
        except OSError as e:
            errors.append({"path": fp, "error": str(e)})
    # 真正清理时顺带删除清空后的 tmp/cache/pycache 空目录
    if not dry_run:
        for dirpath, dirnames, _files in os.walk(base, topdown=False, followlinks=False):
            # 检查是否为可清理目录且为空
            if dirpath.endswith(("tmp", "cache", "__pycache__")):
                try:
                    if not os.listdir(dirpath):
                        os.rmdir(dirpath)
                except OSError:
                    pass
    return {
        "removed": removed,
        "freed_bytes": freed,
        "errors": errors,
        "by_category": by_cat,
    }
