from __future__ import annotations

import logging
import json
import os
import re
import threading
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

_ENV_PREFIX = "XIMU_"
_CONFIG_CANDIDATES = ("config.json", "ximu_config.json")
_SENSITIVE_KEY_PATTERN = re.compile(
    r"(api_key|apikey|token|secret|password|passwd|_key$|_key\b)",
    re.IGNORECASE,
)


def _is_sensitive_key(key: str) -> bool:
    """判断配置 key 是否包含敏感信息

    Args:
        key: 配置键名

    Returns:
        是否敏感
    """
    return bool(_SENSITIVE_KEY_PATTERN.search(key))


def _mask_value(value: Any) -> str:
    """对敏感值做脱敏掩码，保留前2位便于辨认

    Args:
        value: 要脱敏的值

    Returns:
        脱敏后的字符串
    """
    s = str(value)
    if len(s) <= 4:
        return "****"
    return s[:2] + "*" * (len(s) - 2)


class ConfigManager:
    """配置管理器单例。

    优先级：环境变量(XIMU_*) > 配置文件 > 内置默认值。
    支持热加载、配置校验、命名空间分组、JSON 导出。
    """

    _instance: Optional[ConfigManager] = None
    _lock = threading.Lock()

    def __init__(
        self,
        config_dir: Optional[str] = None,
        defaults: Optional[Dict[str, Any]] = None,
    ) -> None:
        """初始化配置管理器

        Args:
            config_dir: 配置文件所在目录，可选
            defaults: 内置默认配置字典，可选
        """
        self._defaults: Dict[str, Any] = defaults or {
            "server.host": "0.0.0.0",
            "server.port": 8000,
            "log.level": "INFO",
        }
        self._file_config: Dict[str, Any] = {}
        self._config_path: Optional[Path] = None
        self._last_mtime: float = 0.0
        self._watch_thread: Optional[threading.Thread] = None
        self._watch_stop = threading.Event()
        self._change_subscribers: List[Callable[[Set[str]], None]] = []
        self._subscribers_lock = threading.Lock()
        self._validation_rules: Dict[str, Any] = {}

        self._find_config_file(config_dir)
        self.reload()

    @classmethod
    def get_instance(cls) -> "ConfigManager":
        """获取全局唯一实例（线程安全）。

        Returns:
            全局唯一的 ConfigManager 实例
        """
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls) -> None:
        """重置单例（主要用于测试）。"""
        with cls._lock:
            cls._instance = None

    def _find_config_file(self, config_dir: Optional[str]) -> None:
        """在指定目录或当前工作目录查找配置文件

        Args:
            config_dir: 指定目录，None 则搜索默认位置
        """
        search_dirs: List[Path] = []
        if config_dir:
            search_dirs.append(Path(config_dir))
        search_dirs.append(Path.cwd())
        search_dirs.append(Path.cwd() / "config")

        for d in search_dirs:
            if not d.is_dir():
                continue
            for name in _CONFIG_CANDIDATES:
                candidate = d / name
                if candidate.is_file():
                    self._config_path = candidate
                    return

    def reload(self) -> Dict[str, Any]:
        """重新从配置文件加载，并刷新环境变量映射。

        热加载前做 schema 校验，坏配置拒载并保留旧配置。

        Returns:
            加载后的完整配置字典
        """
        old_config = dict(self._file_config)
        new_config: Dict[str, Any] = {}

        if self._config_path and self._config_path.is_file():
            try:
                raw = json.loads(self._config_path.read_text(encoding="utf-8"))
                new_config = self._flatten(raw)
            except (json.JSONDecodeError, OSError, UnicodeDecodeError) as e:
                logger.warning("配置文件读取失败，回退到默认配置: %s", self._config_path, exc_info=True)
                new_config = {}

        if self._validation_rules and new_config:
            temp_manager = ConfigManager.__new__(ConfigManager)
            temp_manager._file_config = new_config
            temp_manager._defaults = self._defaults
            errors = temp_manager.validate(**self._validation_rules)
            if errors:
                logger.warning(
                    "配置热加载校验失败，保留旧配置不动。错误: %s",
                    "; ".join(errors),
                )
                return self.dump()

        self._file_config = new_config
        if self._config_path and self._config_path.is_file():
            try:
                self._last_mtime = self._config_path.stat().st_mtime
            except OSError:
                pass

        changed_keys = self._diff_keys(old_config, new_config)
        if changed_keys:
            self._notify_subscribers(changed_keys)

        return self.dump()

    @staticmethod
    def _diff_keys(old: Dict[str, Any], new: Dict[str, Any]) -> Set[str]:
        """对比新旧配置，返回变更的 key 集合（新增/删除/修改）。

        Args:
            old: 旧配置
            new: 新配置

        Returns:
            变更的键集合
        """
        changed: Set[str] = set()
        all_keys = set(old.keys()) | set(new.keys())
        for key in all_keys:
            old_val = old.get(key, "__MISSING__")
            new_val = new.get(key, "__MISSING__")
            if old_val != new_val:
                changed.add(key)
        return changed

    def subscribe(self, callback: Callable[[Set[str]], None]) -> None:
        """订阅配置变更事件

        Args:
            callback: 变更回调函数，参数为本次变更的 key 集合
        """
        with self._subscribers_lock:
            self._change_subscribers.append(callback)

    def unsubscribe(self, callback: Callable[[Set[str]], None]) -> None:
        """取消订阅配置变更事件

        Args:
            callback: 要取消的回调函数
        """
        with self._subscribers_lock:
            if callback in self._change_subscribers:
                self._change_subscribers.remove(callback)

    def _notify_subscribers(self, changed_keys: Set[str]) -> None:
        """通知所有订阅者配置已变更。回调异常静默降级。

        Args:
            changed_keys: 变更的键集合
        """
        with self._subscribers_lock:
            callbacks = list(self._change_subscribers)

        for cb in callbacks:
            try:
                cb(changed_keys)
            except Exception:
                logger.exception("配置变更订阅者回调异常，已跳过: %s", cb)

    def register_validation_rules(self, rules: Dict[str, Any]) -> None:
        """注册热加载前的校验规则

        Args:
            rules: 校验规则字典
        """
        self._validation_rules = rules

    @staticmethod
    def _flatten(nested: Dict[str, Any], prefix: str = "") -> Dict[str, Any]:
        """将嵌套字典展平为点号命名空间字典

        Args:
            nested: 嵌套字典
            prefix: 前缀

        Returns:
            展平后的字典
        """
        flat: Dict[str, Any] = {}
        for key, value in nested.items():
            full_key = f"{prefix}{key}" if not prefix else f"{prefix}.{key}"
            if isinstance(value, dict):
                flat.update(ConfigManager._flatten(value, full_key))
            else:
                flat[full_key] = value
        return flat

    @staticmethod
    def _env_key(key: str) -> str:
        """将配置键映射为环境变量名

        Args:
            key: 配置键，如 database.host

        Returns:
            环境变量名，如 XIMU_DATABASE_HOST
        """
        return _ENV_PREFIX + key.upper().replace(".", "_")

    def _get_from_env(self, key: str) -> Optional[str]:
        """从环境变量读取原始字符串；未设置返回 None

        Args:
            key: 配置键

        Returns:
            环境变量值或 None
        """
        return os.environ.get(self._env_key(key))

    @staticmethod
    def _parse_value(raw: str) -> Any:
        """尝试将字符串解析为合适的 Python 类型

        Args:
            raw: 原始字符串值

        Returns:
            解析后的 Python 对象
        """
        if raw.lower() in ("true", "false"):
            return raw.lower() == "true"
        if raw.lower() == "none":
            return None
        try:
            return int(raw)
        except ValueError:
            pass
        try:
            return float(raw)
        except ValueError:
            pass
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            return raw

    def get(self, key: str, default: Any = None) -> Any:
        """获取配置值，按优先级：环境变量 > 文件 > 默认值

        Args:
            key: 配置键，支持点号命名空间
            default: 默认值

        Returns:
            配置值
        """
        env_val = self._get_from_env(key)
        if env_val is not None:
            return self._parse_value(env_val)

        if key in self._file_config:
            return self._file_config[key]

        if key in self._defaults:
            return self._defaults[key]

        return default

    def dump(self) -> Dict[str, Any]:
        """导出当前完整配置字典（合并默认值）。

        Returns:
            完整配置字典
        """
        merged: Dict[str, Any] = dict(self._defaults)
        merged.update(self._file_config)
        return merged

    def validate(self, **rules: Any) -> List[str]:
        """根据规则校验配置，返回错误信息列表。

        Args:
            **rules: 形如 key=str|int, key2={'min': 0, 'max': 100} 的校验规则

        Returns:
            错误信息列表，空列表表示校验通过
        """
        errors: List[str] = []
        for key, rule in rules.items():
            value = self.get(key)
            if value is None:
                continue
            if isinstance(rule, type) and issubclass(rule, (str, int, float, bool)):
                if not isinstance(value, rule):
                    errors.append(f"配置 {key} 类型错误，期望 {rule.__name__}")
            elif isinstance(rule, dict):
                if "min" in rule and value < rule["min"]:
                    errors.append(f"配置 {key} 值过小，最小为 {rule['min']}")
                if "max" in rule and value > rule["max"]:
                    errors.append(f"配置 {key} 值过大，最大为 {rule['max']}")
        return errors

    def mask_sensitive(self) -> Dict[str, Any]:
        """导出配置但脱敏敏感字段。

        Returns:
            脱敏后的配置字典
        """
        config = self.dump()
        masked: Dict[str, Any] = {}
        for key, value in config.items():
            if _is_sensitive_key(key):
                masked[key] = _mask_value(value)
            else:
                masked[key] = value
        return masked

    def start_watching(self, interval: float = 5.0) -> None:
        """启动后台文件监控线程，自动热加载。

        Args:
            interval: 轮询间隔（秒）
        """
        if self._watch_thread and self._watch_thread.is_alive():
            return

        def _loop() -> None:
            """后台监控循环"""
            while not self._watch_stop.wait(interval):
                if self._config_path and self._config_path.is_file():
                    try:
                        mtime = self._config_path.stat().st_mtime
                    except OSError:
                        continue
                    if mtime > self._last_mtime:
                        self.reload()

        self._watch_thread = threading.Thread(target=_loop, daemon=True)
        self._watch_thread.start()

    def stop_watching(self) -> None:
        """停止后台文件监控线程。"""
        self._watch_stop.set()
        if self._watch_thread:
            self._watch_thread.join(timeout=2.0)
            self._watch_thread = None
