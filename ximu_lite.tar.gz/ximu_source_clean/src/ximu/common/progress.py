# -*- coding: utf-8 -*-
"""
进度条模块：提供可定制的进度显示与跟踪能力。
"""

import sys
import time
from abc import ABC, abstractmethod
from typing import Optional


class ProgressTracker(ABC):
    """进度跟踪器抽象基类。"""

    @abstractmethod
    def update(self, current: int, total: int, desc: Optional[str] = None) -> None:
        """
        更新进度。

        Args:
            current: 当前进度。
            total: 总进度。
            desc: 描述信息。
        """
        pass

    @abstractmethod
    def close(self) -> None:
        """关闭进度跟踪器。"""
        pass


class ConsoleProgress(ProgressTracker):
    """控制台进度条实现。"""

    def __init__(self, bar_length: int = 30, enable: bool = True) -> None:
        """
        初始化控制台进度条。

        Args:
            bar_length: 进度条长度。
            enable: 是否启用显示。
        """
        self._bar_length = bar_length
        self._enable = enable
        self._last_time = 0.0
        self._last_pct = -1.0

    def update(self, current: int, total: int, desc: Optional[str] = None) -> None:
        """
        更新并显示进度。

        Args:
            current: 当前进度。
            total: 总进度。
            desc: 描述信息。
        """
        if not self._enable or total <= 0:
            return
        pct = current / total
        now = time.time()
        if now - self._last_time < 0.1 and pct < 1.0:
            return
        self._last_time = now
        self._last_pct = pct
        bar = "=" * int(self._bar_length * pct) + "-" * int(self._bar_length * (1 - pct))
        label = f"[{desc}]" if desc else ""
        sys.stdout.write(f"\r{label} {bar} {pct * 100:5.1f}%  ({current}/{total})")
        sys.stdout.flush()
        if pct >= 1.0:
            sys.stdout.write("\n")
            sys.stdout.flush()

    def close(self) -> None:
        """关闭进度条，打印换行。"""
        if self._enable and self._last_pct < 1.0:
            sys.stdout.write("\n")
            sys.stdout.flush()


class NullProgress(ProgressTracker):
    """空进度跟踪器，用于禁用显示。"""

    def update(self, current: int, total: int, desc: Optional[str] = None) -> None:
        """空操作。"""
        pass

    def close(self) -> None:
        """空操作。"""
        pass


def create_progress_tracker(
    enable: bool = True, bar_length: int = 30
) -> ProgressTracker:
    """
    工厂方法创建进度跟踪器。

    Args:
        enable: 是否启用控制台显示。
        bar_length: 进度条长度。

    Returns:
        ProgressTracker 实例。
    """
    if enable:
        return ConsoleProgress(bar_length=bar_length)
    return NullProgress()
