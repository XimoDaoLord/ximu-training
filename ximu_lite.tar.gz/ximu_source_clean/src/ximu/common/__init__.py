# -*- coding: utf-8 -*-
"""
汐沫AI - 公共工具层
包含通用工具函数、协议定义、异常类等。

性能优化：以下符号采用 PEP 562 懒加载，避免在导入时立即加载 utils 模块，
仅在真正访问对应名字时才导入，公共 API 保持不变。
"""

from typing import Any

__all__ = [
    "format_datetime",
    "now_timestamp",
    "generate_id",
    "Stopwatch",
    "XIMUError",
    "ModuleStatus",
    "mark_status",
    "ensure_dir",
]

_LAZY_ATTRS: frozenset[str] = frozenset(__all__)


def __getattr__(name: str) -> Any:
    """
    PEP 562：按需加载 utils 中的符号，避免顶层 eager 导入。

    Args:
        name: 要获取的属性名。

    Returns:
        对应的工具函数或类。

    Raises:
        AttributeError: 如果属性不存在。
    """
    if name in _LAZY_ATTRS:
        from . import utils as _utils
        return getattr(_utils, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
