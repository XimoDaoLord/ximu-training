"""汐沫AI - 通用验证工具"""

import re
from typing import Any, List, Optional, Union

from .exceptions import ValidationError


class Validator:
    """验证器基类"""

    def __init__(self, field_name: str = "field") -> None:
        self.field_name: str = field_name
        self.errors: List[str] = []
        self.warnings: List[str] = []

    def add_error(self, message: str) -> None:
        """添加错误"""
        self.errors.append(f"[{self.field_name}] {message}")

    def add_warning(self, message: str) -> None:
        """添加警告"""
        self.warnings.append(f"[{self.field_name}] {message}")

    def is_valid(self) -> bool:
        """检查是否有效"""
        return len(self.errors) == 0

    def get_errors(self) -> List[str]:
        """获取错误列表"""
        return self.errors

    def get_warnings(self) -> List[str]:
        """获取警告列表"""
        return self.warnings

    def raise_if_invalid(self) -> None:
        """如果无效则抛出异常"""
        if not self.is_valid():
            raise ValidationError(
                message=f"验证失败: {'; '.join(self.errors)}",
                field=self.field_name,
                constraints=self.errors,
            )


class StringValidator(Validator):
    """字符串验证器"""

    def __init__(self, field_name: str = "string") -> None:
        super().__init__(field_name)

    def _check_length_constraints(self, value: str, min_length: Optional[int], max_length: Optional[int]) -> None:
        """检查长度约束"""
        if min_length is not None and len(value) < min_length:
            self.add_error(f"长度不能小于{min_length}，当前长度: {len(value)}")
        if max_length is not None and len(value) > max_length:
            self.add_error(f"长度不能大于{max_length}，当前长度: {len(value)}")

    def _check_value_constraints(self, value: str, pattern: Optional[str], allowed_values: Optional[List[str]], forbidden_values: Optional[List[str]]) -> None:
        """检查值约束"""
        if pattern is not None and not re.match(pattern, value):
            self.add_error(f"格式不符合要求，模式: {pattern}")
        if allowed_values is not None and value not in allowed_values:
            self.add_error(f"值不在允许列表中，允许值: {allowed_values}")
        if forbidden_values is not None and value in forbidden_values:
            self.add_error(f"值在禁止列表中，禁止值: {forbidden_values}")

    def validate(
        self,
        value: Any,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        pattern: Optional[str] = None,
        allowed_values: Optional[List[str]] = None,
        forbidden_values: Optional[List[str]] = None,
        required: bool = True,
        allow_empty: bool = False,
    ) -> bool:
        """验证字符串"""
        if value is None:
            if required:
                self.add_error("不能为空")
            return False

        if not isinstance(value, str):
            self.add_error(f"必须是字符串类型，当前类型: {type(value).__name__}")
            return False

        if not allow_empty and len(value.strip()) == 0:
            self.add_error("不能为空字符串")
            return False

        self._check_length_constraints(value, min_length, max_length)
        self._check_value_constraints(value, pattern, allowed_values, forbidden_values)
        return self.is_valid()


class NumberValidator(Validator):
    """数字验证器"""

    def __init__(self, field_name: str = "number") -> None:
        super().__init__(field_name)

    def _check_type_constraints(self, value: Any, integer_only: bool, allowed_type: Optional[type]) -> None:
        """检查类型约束"""
        if integer_only and not isinstance(value, int):
            self.add_error("必须是整数")
        if allowed_type is not None and not isinstance(value, allowed_type):
            self.add_error(f"必须是{allowed_type.__name__}类型")

    def _check_range_constraints(self, value: Union[int, float], min_value: Optional[Union[int, float]], max_value: Optional[Union[int, float]]) -> None:
        """检查范围约束"""
        if min_value is not None and value < min_value:
            self.add_error(f"值不能小于{min_value}，当前值: {value}")
        if max_value is not None and value > max_value:
            self.add_error(f"值不能大于{max_value}，当前值: {value}")

    def _check_sign_constraints(self, value: Union[int, float], positive: bool, negative: bool, non_zero: bool) -> None:
        """检查符号约束"""
        if positive and value <= 0:
            self.add_error("必须是正数")
        if negative and value >= 0:
            self.add_error("必须是负数")
        if non_zero and value == 0:
            self.add_error("不能为零")

    def validate(
        self,
        value: Any,
        min_value: Optional[Union[int, float]] = None,
        max_value: Optional[Union[int, float]] = None,
        allowed_type: Optional[type] = None,
        positive: bool = False,
        negative: bool = False,
        non_zero: bool = False,
        integer_only: bool = False,
        required: bool = True,
    ) -> bool:
        """验证数字"""
        if value is None:
            if required:
                self.add_error("不能为空")
            return False

        if not isinstance(value, (int, float)):
            self.add_error(f"必须是数字类型，当前类型: {type(value).__name__}")
            return False

        if isinstance(value, float) and value != value:
            self.add_error("不能为 NaN(非数字)")
            return False

        self._check_type_constraints(value, integer_only, allowed_type)
        self._check_range_constraints(value, min_value, max_value)
        self._check_sign_constraints(value, positive, negative, non_zero)
        return self.is_valid()


class BooleanValidator(Validator):
    """布尔值验证器"""

    def __init__(self, field_name: str = "boolean") -> None:
        super().__init__(field_name)

    def validate(self, value: Any, required: bool = True) -> bool:
        """验证布尔值"""
        if value is None:
            if required:
                self.add_error("不能为空")
            return False

        if not isinstance(value, bool):
            self.add_error(f"必须是布尔值类型，当前类型: {type(value).__name__}")
            return False

        return self.is_valid()


class ListValidator(Validator):
    """列表验证器"""

    def __init__(self, field_name: str = "list") -> None:
        super().__init__(field_name)

    def _check_length_constraints(self, value: list, min_length: Optional[int], max_length: Optional[int]) -> None:
        """检查长度约束"""
        if min_length is not None and len(value) < min_length:
            self.add_error(f"长度不能小于{min_length}，当前长度: {len(value)}")
        if max_length is not None and len(value) > max_length:
            self.add_error(f"长度不能大于{max_length}，当前长度: {len(value)}")

    def _validate_items(self, value: list, item_type: Optional[type], allowed_values: Optional[List[Any]]) -> None:
        """验证列表元素"""
        if item_type is not None:
            for i, item in enumerate(value):
                if not isinstance(item, item_type):
                    self.add_error(f"第{i}个元素类型错误，必须是{item_type.__name__}，当前类型: {type(item).__name__}")
        if allowed_values is not None:
            for i, item in enumerate(value):
                if item not in allowed_values:
                    self.add_error(f"第{i}个元素不在允许列表中")

    def validate(
        self,
        value: Any,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        item_type: Optional[type] = None,
        allowed_values: Optional[List[Any]] = None,
        required: bool = True,
    ) -> bool:
        """验证列表"""
        if value is None:
            if required:
                self.add_error("不能为空")
            return False

        if not isinstance(value, list):
            self.add_error(f"必须是列表类型，当前类型: {type(value).__name__}")
            return False

        self._check_length_constraints(value, min_length, max_length)
        self._validate_items(value, item_type, allowed_values)
        return self.is_valid()


def clamp_max_results(value: int, max_value: int = 100) -> int:
    """限制最大值。"""
    return max(0, min(value, max_value))


def validate_search_query(query: str, max_length: int = 1000) -> bool:
    """验证搜索查询是否合法。"""
    if not query or not isinstance(query, str):
        return False
    return len(query) <= max_length
