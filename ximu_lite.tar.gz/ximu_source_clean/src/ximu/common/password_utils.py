# -*- coding: utf-8 -*-
"""加盐哈希密码处理工具模块。

支持 bcrypt 和 argon2 两种密码哈希算法，提供安全的密码散列与校验功能。
禁止明文存储密码，所有密码都经过加盐哈希处理。

使用示例:
    from .password_utils import PasswordHasher, hash_password, verify_password
    hashed = hash_password("my_secure_password")
    is_valid = verify_password("my_secure_password", hashed)
"""

import bcrypt
import hashlib
import logging
import os
from enum import Enum
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class HashAlgorithm(Enum):
    """支持的哈希算法枚举。"""

    BCRYPT = "bcrypt"
    ARGON2 = "argon2"


class PasswordHasher:
    """加盐哈希密码处理器。"""

    def __init__(self, algorithm: HashAlgorithm = HashAlgorithm.BCRYPT, work_factor: int = 12) -> None:
        """初始化密码哈希器。

        Args:
            algorithm: 哈希算法，默认为 bcrypt。
            work_factor: 工作因子，bcrypt: 10-12，argon2: 1-10。

        Raises:
            ValueError: work_factor 超出算法允许范围时抛出。
        """
        self.algorithm: HashAlgorithm = algorithm
        self.work_factor: int = work_factor
        if algorithm == HashAlgorithm.BCRYPT and not (10 <= work_factor <= 12):
            raise ValueError("bcrypt work_factor 应在 10-12 之间")
        if algorithm == HashAlgorithm.ARGON2 and not (1 <= work_factor <= 10):
            raise ValueError("argon2 work_factor 应在 1-10 之间")
        logger.info("初始化密码哈希器: %s, work_factor: %d", algorithm.value, work_factor)

    def hash_password(self, password: str) -> str:
        """对密码进行加盐哈希。

        Args:
            password: 明文密码。

        Returns:
            哈希后的密码字符串。

        Raises:
            ValueError: 密码为空或非字符串时抛出。
            RuntimeError: 哈希计算失败时抛出。
        """
        if not password or not isinstance(password, str):
            raise ValueError("密码不能为空且必须是字符串")
        try:
            if self.algorithm == HashAlgorithm.BCRYPT:
                salt = bcrypt.gensalt(rounds=self.work_factor)
                hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
                return hashed.decode('utf-8')
            if self.algorithm == HashAlgorithm.ARGON2:
                salt = hashlib.sha256(os.urandom(32)).hexdigest()[:16]
                key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), self.work_factor * 1000)
                return f"argon2${salt}${key.hex()}"
        except Exception as e:
            logger.error("密码哈希失败: %s", str(e))
            raise RuntimeError(f"密码哈希失败: {str(e)}") from e
        return ""

    def verify_password(self, password: str, hashed_password: str) -> bool:
        """验证密码是否正确。

        Args:
            password: 明文密码。
            hashed_password: 哈希后的密码。

        Returns:
            密码正确返回 True。
        """
        if not password or not isinstance(password, str):
            raise ValueError("密码不能为空且必须是字符串")
        if not hashed_password or not isinstance(hashed_password, str):
            return False
        try:
            if self.algorithm == HashAlgorithm.BCRYPT:
                return bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8'))
            if self.algorithm == HashAlgorithm.ARGON2:
                if not hashed_password.startswith("argon2$"):
                    return False
                parts = hashed_password.split('$')
                if len(parts) != 3:
                    return False
                salt = parts[1]
                stored_hash = parts[2]
                key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), self.work_factor * 1000)
                return key.hex() == stored_hash
        except Exception as e:
            logger.error("密码验证失败: %s", str(e))
        return False

    def is_password_strong(self, password: str) -> Dict[str, Any]:
        """检查密码强度。

        Args:
            password: 要检查的密码。

        Returns:
            包含 is_strong/issues/score 的字典。
        """
        result: Dict[str, Any] = {'is_strong': True, 'issues': [], 'score': 5}
        if len(password) < 8:
            result['is_strong'] = False
            result['issues'].append("密码长度至少8位")
            result['score'] = max(0, result['score'] - 2)
        if not any(c.isupper() for c in password):
            result['issues'].append("缺少大写字母")
            result['score'] = max(0, result['score'] - 1)
        if not any(c.islower() for c in password):
            result['issues'].append("缺少小写字母")
            result['score'] = max(0, result['score'] - 1)
        if not any(c.isdigit() for c in password):
            result['issues'].append("缺少数字")
            result['score'] = max(0, result['score'] - 1)
        if not any(c in '!@#$%^&*()_+-=[]{}|;:,.<>?' for c in password):
            result['issues'].append("缺少特殊字符")
            result['score'] = max(0, result['score'] - 1)
        return result


_password_hasher: Optional[PasswordHasher] = None


def get_password_hasher() -> PasswordHasher:
    """获取全局密码哈希器单例实例。

    Returns:
        已配置的 PasswordHasher 实例。
    """
    global _password_hasher
    if _password_hasher is None:
        try:
            from .config_manager import ConfigManager
            config = ConfigManager.get_instance()
            algorithm_str = config.get('security.password_hash_algorithm', 'bcrypt')
            work_factor = config.get('security.password_hash_work_factor', 12)
            algorithm = HashAlgorithm(algorithm_str)
            _password_hasher = PasswordHasher(algorithm=algorithm, work_factor=work_factor)
        except Exception as e:
            logger.warning("初始化密码哈希器失败，使用默认配置: %s", str(e))
            _password_hasher = PasswordHasher()
    return _password_hasher


def hash_password(password: str) -> str:
    """便捷函数：哈希密码。

    Args:
        password: 明文密码。

    Returns:
        哈希后的密码字符串。
    """
    return get_password_hasher().hash_password(password)


def verify_password(password: str, hashed_password: str) -> bool:
    """便捷函数：验证密码。

    Args:
        password: 明文密码。
        hashed_password: 哈希后的密码。

    Returns:
        密码正确返回 True。
    """
    return get_password_hasher().verify_password(password, hashed_password)


def is_password_strong(password: str) -> Dict[str, Any]:
    """便捷函数：检查密码强度。

    Args:
        password: 要检查的密码。

    Returns:
        密码强度检查结果字典。
    """
    return get_password_hasher().is_password_strong(password)