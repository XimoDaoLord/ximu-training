"""事件总线 / 发布订阅

EventBus 单例：subscribe / unsubscribe / publish / publish_async。
支持通配符、优先级、过滤、历史、错误隔离。
"""
from __future__ import annotations

import fnmatch
import functools
import logging
import os
import re
import threading
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


def _adaptive_async_workers() -> int:
    """异步事件投递池按设备 CPU 核数自适应。

    事件处理器多为 I/O 型（网络/落库），按核数*2 取池大小并封顶 16。

    Returns:
        线程池大小。
    """
    return min(16, (os.cpu_count() or 4) * 2)


class EventBus:
    """线程安全的事件总线单例。"""

    _instance: Optional[EventBus] = None
    _lock = threading.Lock()

    def __init__(self, history_size: int = 100) -> None:
        """初始化事件总线。

        Args:
            history_size: 事件历史保留的最大条数。
        """
        self._handlers: Dict[str, List[Tuple[int, Callable, Optional[Callable]]]] = {}
        self._history: Deque[Dict[str, Any]] = deque(maxlen=history_size)
        self._history_size = history_size
        self._seen_keys: Deque[str] = deque(maxlen=history_size * 4)
        self._seen_set: set = set()
        self.duplicate_suppressed = 0
        self._exact_handlers: Dict[str, List[Tuple[int, Callable, Optional[Callable]]]] = {}
        self._wildcard_patterns: List[Tuple[re.Pattern, str, List[Tuple[int, Callable, Optional[Callable]]]]] = []
        self._async_pool = ThreadPoolExecutor(
            max_workers=_adaptive_async_workers(),
            thread_name_prefix="eventbus"
        )

    @classmethod
    def get_instance(cls) -> EventBus:
        """获取事件总线单例（线程安全，双重检查锁）。"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls) -> None:
        """重置单例引用（测试用）。"""
        with cls._lock:
            cls._instance = None

    def subscribe(
        self,
        event_name: str,
        handler: Callable[..., None],
        priority: int = 0,
        filter_func: Optional[Callable[..., bool]] = None,
    ) -> None:
        """注册事件处理器。priority 越小越先执行。

        Args:
            event_name: 事件名称。
            handler: 事件处理器函数。
            priority: 优先级，默认 0。
            filter_func: 可选的过滤函数，返回 False 时跳过该事件。
        """
        entry = (priority, handler, filter_func)
        with self._lock:
            self._handlers.setdefault(event_name, []).append(entry)
            self._handlers[event_name].sort(key=lambda x: x[0])
            self._rebuild_index()

    def unsubscribe(self, event_name: str, handler: Callable[..., None]) -> None:
        """移除事件处理器。

        Args:
            event_name: 事件名称。
            handler: 要移除的处理器函数。
        """
        with self._lock:
            if event_name not in self._handlers:
                return
            self._handlers[event_name] = [
                h for h in self._handlers[event_name] if h[1] != handler
            ]
            if not self._handlers[event_name]:
                del self._handlers[event_name]
            self._rebuild_index()

    def _rebuild_index(self) -> None:
        """重建精确名/通配符两张索引表。"""
        exact: Dict[str, List[Tuple[int, Callable, Optional[Callable]]]] = {}
        wildcard: List[Tuple[re.Pattern, str, List[Tuple[int, Callable, Optional[Callable]]]]] = []
        for pattern, handlers in self._handlers.items():
            if any(ch in pattern for ch in "*?["):
                regex = re.compile(fnmatch.translate(pattern))
                wildcard.append((regex, pattern, list(handlers)))
            else:
                exact[pattern] = list(handlers)
        self._exact_handlers = exact
        self._wildcard_patterns = wildcard

    def _matching_handlers(self, event_name: str) -> List[Tuple[int, Callable, Optional[Callable]]]:
        """查找所有匹配事件名的处理器。

        Args:
            event_name: 事件名称。

        Returns:
            匹配的处理器列表，按优先级排序。
        """
        result: List[Tuple[int, Callable, Optional[Callable]]] = []
        if event_name in self._exact_handlers:
            result.extend(self._exact_handlers[event_name])
        for regex, _pattern, handlers in self._wildcard_patterns:
            if regex.match(event_name):
                result.extend(handlers)
        result.sort(key=lambda x: x[0])
        return result

    def publish(self, event_name: str, dedup_key: Optional[str] = None, **kwargs: Any) -> None:
        """同步发布事件，按优先级依次调用处理器。

        Args:
            event_name: 事件名称。
            dedup_key: 去重键，可选。
            **kwargs: 事件数据。
        """
        if dedup_key is not None:
            with self._lock:
                if dedup_key in self._seen_set:
                    self.duplicate_suppressed += 1
                    return
                self._seen_set.add(dedup_key)
                self._seen_keys.append(dedup_key)
                if len(self._seen_set) > self._seen_keys.maxlen:
                    old = self._seen_keys.popleft()
                    self._seen_set.discard(old)
        record = {
            "event": event_name,
            "data": kwargs,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        with self._lock:
            handlers = self._matching_handlers(event_name)
            self._history.append(record)
        for _, handler, filter_func in handlers:
            try:
                if filter_func is not None and not filter_func(**kwargs):
                    continue
                handler(**kwargs)
            except Exception as exc:  # noqa: BLE001
                logger.error(
                    "事件处理器 %s 处理 %s 时出错: %s",
                    getattr(handler, "__name__", handler), event_name, exc,
                )

    def publish_async(self, event_name: str, **kwargs: Any) -> None:
        """异步发布事件，复用全局线程池。

        Args:
            event_name: 事件名称。
            **kwargs: 事件数据。
        """
        self._async_pool.submit(self.publish, event_name, **kwargs)

    def stats(self) -> Dict[str, Any]:
        """返回事件总线统计信息。

        Returns:
            包含处理器数量、模式数量、历史大小等统计信息的字典。
        """
        with self._lock:
            total_handlers = sum(len(h) for h in self._handlers.values())
            return {
                "handlers_count": total_handlers,
                "exact_patterns": len(self._exact_handlers),
                "wildcard_patterns": len(self._wildcard_patterns),
                "history_size": len(self._history),
                "duplicate_suppressed": self.duplicate_suppressed,
                "seen_keys_count": len(self._seen_set),
            }

    def query_history(self, event_prefix: Optional[str] = None) -> List[Dict[str, Any]]:
        """查询事件历史。

        Args:
            event_prefix: 可选的事件名前缀过滤。

        Returns:
            匹配的事件历史记录列表。
        """
        with self._lock:
            records = list(self._history)
        if event_prefix:
            return [r for r in records if r["event"].startswith(event_prefix)]
        return records