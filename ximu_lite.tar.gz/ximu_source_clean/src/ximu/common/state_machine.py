"""轻量级状态机工具

- StateMachine 基类：状态定义、转移规则、守卫条件、回调、历史、持久化
- @transition(from_state, to_state, guard) 方法装饰器
- @state_machine(states, initial_state) 类装饰器
"""

from __future__ import annotations

import functools
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple, Type, TypeVar, Generic

# 支持带类型参数的实例
T = TypeVar("T", bound="StateMachine")


class InvalidStateTransition(Exception):
    """非法状态转移异常。

    当状态机尝试执行一个未定义的转移、被守卫拒绝，或目标状态不在合法集合中时抛出。
    """


class StateMachineError(Exception):
    """状态机通用异常，用于包装底层错误（如 JSON 解析失败）。"""


@dataclass(frozen=True)
class TransitionRecord:
    """单次状态转移记录（不可变）。

    包含转移的来源状态、目标状态、原因描述及 UTC 时间戳。
    """
    from_state: str
    to_state: str
    reason: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典，便于 JSON 导出。

        Returns:
            包含所有字段的字典。
        """
        return {
            "from_state": self.from_state,
            "to_state": self.to_state,
            "reason": self.reason,
            "timestamp": self.timestamp,
        }


def transition(
    from_state: str,
    to_state: str,
    guard: Optional[Callable[..., bool]] = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """方法装饰器：声明一个状态转移动作。

    被装饰方法执行前会校验当前状态是否为 ``from_state``，并可选地调用守卫函数。
    方法成功返回后，状态机将自动切换到 ``to_state`` 并记录历史。

    Args:
        from_state: 期望的当前状态名称。
        to_state: 目标状态名称。
        guard: 可选的守卫函数，签名为 ``guard(self, *args, **kwargs) -> bool``。
               若返回 False，则转移被拒绝并抛出 :class:`InvalidStateTransition`。

    Returns:
        装饰器函数。

    Raises:
        ValueError: 若 ``from_state`` 或 ``to_state`` 为空字符串。

    Example:
        >>> @transition("idle", "running")
        ... def start(self):
        ...     pass
    """
    if not from_state:
        raise ValueError("from_state 不能为空字符串")
    if not to_state:
        raise ValueError("to_state 不能为空字符串")

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        """包装转移动作方法，在执行前后校验状态与守卫。"""

        @functools.wraps(func)
        def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
            """实际执行：校验当前状态→守卫→原方法→切换状态。

            Args:
                self: 状态机实例（必须继承自 StateMachine）。
                *args: 传递给原始方法的额外位置参数。
                **kwargs: 传递给原始方法的额外关键字参数。

            Returns:
                原始方法的返回值。

            Raises:
                InvalidStateTransition: 当前状态不匹配、守卫拒绝或目标状态非法。
            """
            current: str = self.state
            if current != from_state:
                raise InvalidStateTransition(
                    f"非法转移: 当前状态={current}, 期望={from_state}, 目标={to_state}"
                )
            if guard is not None:
                try:
                    if not guard(self, *args, **kwargs):
                        self._on_invalid_transition(current, to_state, "守卫条件未通过")
                        raise InvalidStateTransition(
                            f"转移被守卫拒绝: {from_state} -> {to_state}"
                        )
                except InvalidStateTransition:
                    raise
                except Exception as exc:
                    raise StateMachineError(f"守卫函数执行异常: {exc}") from exc

            # 提取可选的 reason 参数，避免污染原始调用
            reason = kwargs.pop("reason", func.__name__)
            result = func(self, *args, **kwargs)
            self._do_transition(to_state, reason)
            return result

        return wrapper

    return decorator


def state_machine(
    states: List[str],
    initial_state: str,
) -> Callable[[Type[T]], Type[T]]:
    """类装饰器：为类注入状态机所需的状态集合和初始状态。

    Args:
        states: 所有合法状态名称的列表，不能为空。
        initial_state: 初始状态，必须包含在 ``states`` 中。

    Returns:
        类装饰器函数。

    Raises:
        ValueError: 若 ``states`` 为空，或 ``initial_state`` 不在 ``states`` 中，
                    或 ``states`` 中包含非字符串元素。

    Example:
        >>> @state_machine(states=["idle", "running"], initial_state="idle")
        ... class MyMachine(StateMachine):
        ...     pass
    """
    if not states:
        raise ValueError("states 不能为空")
    for s in states:
        if not isinstance(s, str) or not s:
            raise ValueError(f"states 中每个元素必须为非空字符串，收到: {s!r}")
    if initial_state not in states:
        raise ValueError(f"initial_state '{initial_state}' 必须包含在 states 中")

    def decorator(cls: Type[T]) -> Type[T]:
        """把 states/initial_state 注入类属性，供 StateMachine.__init__ 使用。"""
        cls._states = list(states)
        cls._initial_state = initial_state
        # 【优化】类级frozenset，所有实例共享，O(1)状态校验
        cls._states_set = frozenset(states)
        return cls

    return decorator


class StateMachine:
    """状态机基类。

    子类可通过类属性 ``_states`` 和 ``_initial_state`` 定义合法状态与初始状态，
    或使用 :func:`state_machine` 装饰器自动注入。

    特性：
        - 默认允许所有已定义状态之间的转移
        - 支持通过 :meth:`add_rule` 自定义转移矩阵
        - 提供转移前/后回调钩子
        - 记录完整转移历史并支持 JSON 序列化/反序列化

    用法::

        @state_machine(states=["idle", "running", "stopped"], initial_state="idle")
        class MyMachine(StateMachine):
            @transition("idle", "running")
            def start(self) -> None:
                ...

            @transition("running", "stopped", guard=lambda self: self.is_safe())
            def stop(self) -> None:
                ...
    """

    _states: List[str] = []
    _initial_state: str = ""
    _states_set: frozenset = frozenset()  # 【优化】O(1)状态校验集合，替代线性搜索O(N)

    def __init__(self) -> None:
        """初始化状态机实例。

        将状态设为初始值，并清空历史记录与默认转移规则表。
        """
        if not self._states:
            raise ValueError(
                "状态机未定义任何状态。请设置 _states 或使用 @state_machine 装饰器。"
            )
        # 【优化】惰性构建frozenset，避免每次实例化重复计算
        if not self._states_set:
            object.__setattr__(self, '_states_set', frozenset(self._states))
        if self._initial_state not in self._states_set:
            raise ValueError(
                f"初始状态 '{self._initial_state}' 不在已定义状态 {self._states} 中"
            )

        self.state: str = self._initial_state
        self._history: List[TransitionRecord] = []
        self._transition_rules: Dict[Tuple[str, str], bool] = {}
        self._before_cbs: List[Callable[[str, str], None]] = []
        self._after_cbs: List[Callable[[str, str], None]] = []
        self._setup_default_rules()

    def _setup_default_rules(self) -> None:
        """默认允许任意已定义状态之间的转移。

        填充完整的 N×N 转移矩阵，所有条目初始为 True。
        """
        for src in self._states:
            for dst in self._states:
                self._transition_rules[(src, dst)] = True

    @property
    def history(self) -> List[TransitionRecord]:
        """返回状态转移历史的快照副本。

        Returns:
            包含所有历史记录的列表（不会随后续转移改变）。
        """
        return list(self._history)

    def _do_transition(self, to_state: str, reason: str = "") -> None:
        """执行实际的状态切换。

        Args:
            to_state: 目标状态名称。
            reason: 本次转移的原因描述。

        Raises:
            InvalidStateTransition: 若目标状态未定义或当前转移被规则禁止。
            StateMachineError: 若回调函数执行异常。
        """
        # 【优化前】to_state not in self._states → O(N) 线性搜索
        # 【优化后】to_state not in self._states_set → O(1) 哈希查找
        if to_state not in self._states_set:
            raise InvalidStateTransition(f"未定义的状态: {to_state}")
        if not self._transition_rules.get((self.state, to_state), False):
            raise InvalidStateTransition(f"禁止转移: {self.state} -> {to_state}")

        old = self.state
        for cb in self._before_cbs:
            try:
                cb(old, to_state)
            except Exception as exc:
                raise StateMachineError(f"转移前回调执行异常: {exc}") from exc

        self.state = to_state
        self._history.append(
            TransitionRecord(from_state=old, to_state=to_state, reason=reason)
        )

        for cb in self._after_cbs:
            try:
                cb(old, to_state)
            except Exception as exc:
                raise StateMachineError(f"转移后回调执行异常: {exc}") from exc

    def can_transition(self, to_state: str) -> bool:
        """判断当前状态是否可以转移到目标状态。

        Args:
            to_state: 目标状态名称。

        Returns:
            若转移合法返回 True，否则返回 False。
            若 ``to_state`` 未定义，返回 False。
        """
        # 【优化前】to_state not in self._states → O(N) 线性搜索
        # 【优化后】to_state not in self._states_set → O(1) 哈希查找
        if to_state not in self._states_set:
            return False
        return self._transition_rules.get((self.state, to_state), False)
