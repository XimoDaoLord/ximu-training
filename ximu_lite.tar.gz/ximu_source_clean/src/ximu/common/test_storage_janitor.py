# -*- coding: utf-8 -*-
"""storage_janitor 单元测试模块。

本模块提供对 `src.ximu.common.storage_janitor` 的自动化测试，
包括磁盘用量报告、清理计划、预演/实际删除、自动维护及审计记录等功能。
测试用例通过 pytest 收集执行，也可作为脚本直接运行。

版本: 0.5
"""

import os
import sys
import tempfile
import time
import traceback
from typing import Any, Callable, Dict, List, Optional, Tuple

# 将项目根目录加入模块搜索路径，确保导入一致性
_project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from src.ximu.common import storage_janitor as sj
from src.ximu.common.atomic_store import read_jsonl

__version__ = "0.5"

def _touch(path: str, size: int = 10, mtime: Optional[float] = None) -> None:
    """创建父目录并写入指定大小的测试文件，可选设置修改时间。

    Args:
        path: 目标文件的绝对或相对路径。
        size: 要写入的字节数。
        mtime: 若提供，则将该文件的 mtime/atime 设置为该 Unix 时间戳；
               若为 None，则保留默认时间。

    Raises:
        OSError: 如果创建目录或写入文件失败。
    """
    parent_dir = os.path.dirname(path)
    if parent_dir:
        os.makedirs(parent_dir, exist_ok=True)
    with open(path, "wb") as f:
        f.write(b"x" * size)
    if mtime is not None:
        os.utime(path, (mtime, mtime))

def _build_root() -> Tuple[str, List[str]]:
    """构造一个包含受保护数据与可再生垃圾文件的临时测试根目录。

    测试目录布局：
        - 受保护资产：数据库、模型、记忆、上传、导出、快照、沙箱等
        - 可再生垃圾：tmp、cache、__pycache__、过期 part
        - 日志与备份：各 7 份（用于测试保留最新 5 份的行为）
        - 顶层散落文件：属于 'other' 类别，不应被删除

    Returns:
        一个二元组 (root, protected)：
            root: 临时根目录的绝对路径。
            protected: 受保护文件的相对路径列表（用于后续校验）。
    """
    root = tempfile.mkdtemp(prefix="ximu_janitor_")
    # 受保护用户数据/资产（绝不能被删）
    protected: List[str] = [
        "db/chat.db", "models/qwen.gguf", "memory/mem.json",
        "uploads/a.png", "exports/doc.md", "snapshots/checkpoint.zip",
        "sandbox/s1/task.json",
    ]
    for rel in protected:
        _touch(os.path.join(root, rel), 20)
    
    # 可再生垃圾
    _touch(os.path.join(root, "tmp/a.tmp"), 5)
    _touch(os.path.join(root, "tmp/sub/b.tmp"), 5)
    _touch(os.path.join(root, "cache/c.bin"), 7)
    _touch(os.path.join(root, "models/__pycache__/x.pyc"), 3)
    
    # 新/旧 part：仅过期的删
    _touch(os.path.join(root, "downloads/active.part"), 11)
    old_part_path = os.path.join(root, "downloads/old.part")
    _touch(old_part_path, 13, mtime=time.time() - 48 * 3600)
    
    # 日志 7 份（保留最新 5）
    for i in range(7):
        _touch(os.path.join(root, f"logs/app.log.{i}"), 2,
               mtime=time.time() - (7 - i) * 3600)
    
    # 备份 7 份（保留最新 5）
    for i in range(7):
        _touch(os.path.join(root, f"backups/b{i}.zip"), 4,
               mtime=time.time() - (7 - i) * 3600)
    
    # 顶层散落文件计入 other，不删
    _touch(os.path.join(root, "offline_outbox.jsonl"), 6)
    
    return root, protected

def test_usage_report_classifies() -> None:
    """验证 usage_report 正确分类字节占用。"""
    root, _ = _build_root()
    rep = sj.usage_report(root)
    assert rep["exists"], f"Root directory does not exist: {root}"
    assert rep["total_bytes"] > 0, "Total bytes should be greater than 0"
    
    categories = rep.get("categories", {})
    assert categories.get("models", {}).get("bytes", 0) >= 20, "Models bytes should be >= 20"
    assert categories.get("tmp", {}).get("bytes", 0) >= 10, "Tmp bytes should be >= 10"
    
    assert rep.get("other", {}).get("bytes", 0) >= 6, "Other bytes should be >= 6"

def test_dry_run_deletes_nothing() -> None:
    """验证 dry_run=True 时不实际删除任何文件。"""
    root, protected = _build_root()
    before = sj.usage_report(root)["total_bytes"]
    res = sj.cleanup(dry_run=True, root=root)
    assert res["dry_run"], "Result should indicate dry run mode"
    assert res["freed_bytes"] > 0, "Freed bytes should be greater than 0 in dry run"
    
    after = sj.usage_report(root)["total_bytes"]
    assert after == before, "No files should be deleted in dry run mode"
    
    for rel in protected:
        full_path = os.path.join(root, rel)
        assert os.path.exists(full_path), f"Protected file missing: {rel}"

def test_cleanup_only_removes_regenerable() -> None:
    """验证实际清理只移除可再生资源，保留受保护及用户文件。"""
    root, protected = _build_root()
    res = sj.cleanup(dry_run=False, root=root, keep_logs=5, keep_backups=5,
                     stale_part_hours=24)
    assert not res["dry_run"], "Result should indicate actual cleanup mode"
    
    # 受保护数据原样保留
    for rel in protected:
        full_path = os.path.join(root, rel)
        assert os.path.exists(full_path), f"Protected file missing: {rel}"
    
    # tmp/cache/pycache/过期 part 被清
    assert not os.path.exists(os.path.join(root, "tmp/a.tmp")), "tmp/a.tmp should be deleted"
    assert not os.path.exists(os.path.join(root, "cache/c.bin")), "cache/c.bin should be deleted"
    assert not os.path.exists(os.path.join(root, "models/__pycache__/x.pyc")), "models/__pycache__/x.pyc should be deleted"
    assert not os.path.exists(os.path.join(root, "downloads/old.part")), "downloads/old.part should be deleted"
    
    # 活跃 part 保留
    assert os.path.exists(os.path.join(root, "downloads/active.part")), "downloads/active.part should be kept"
    
    # 日志/备份各保留最新 5
    logs_dir = os.path.join(root, "logs")
    backups_dir = os.path.join(root, "backups")
    assert len(os.listdir(logs_dir)) == 5, "Should keep 5 log files"
    assert len(os.listdir(backups_dir)) == 5, "Should keep 5 backup files"
    
    assert os.path.exists(os.path.join(logs_dir, "app.log.6")), "Latest log should be kept"
    assert not os.path.exists(os.path.join(logs_dir, "app.log.0")), "Oldest log should be deleted"
    assert os.path.exists(os.path.join(backups_dir, "b6.zip")), "Latest backup should be kept"
    assert not os.path.exists(os.path.join(backups_dir, "b0.zip")), "Oldest backup should be deleted"
    
    # 顶层散落用户文件不删
    assert os.path.exists(os.path.join(root, "offline_outbox.jsonl")), "offline_outbox.jsonl should be kept"

def test_protected_categories_never_planned() -> None:
    """验证清理计划中绝不含受保护类别的路径。"""
    root, _ = _build_root()
    plan = sj.plan_cleanup(root=root)
    paths = "\n".join(p["path"] for p in plan)
    
    forbidden_substrings: List[str] = [
        "/db/", "/models/qwen.gguf", "/memory/", "/uploads/",
        "/exports/", "/snapshots/", "/sandbox/"
    ]
    for bad in forbidden_substrings:
        assert bad not in paths, f"Protected path leaked into cleanup plan: {bad}"

def test_within_root_guard_and_forbidden_root() -> None:
    """验证 _within_root 的安全边界及根路径的防护。"""
    assert sj._within_root("/data/x/y", "/data"), "Should be within root"
    assert not sj._within_root("/etc/passwd", "/data"), "Should not be within root"
    
    # 根路径 / 的特殊处理
    result = sj.plan_cleanup(root="/")
    assert result == [], "Planning on root '/' should return empty list"

def test_auto_maintain_threshold() -> None:
    """验证 auto_maintain 的阈值触发、预演与强制授权行为。"""
    root, _ = _build_root()
    
    # 未超阈值：不动作
    assert sj.auto_maintain(root=root, disk_threshold_pct=90, disk_pct=50) is None, \
        "Should return None when threshold not exceeded"
    
    # 超阈值但未授权（无 force、无环境变量）：只预演，文件不丢
    res = sj.auto_maintain(root=root, disk_threshold_pct=90, disk_pct=99)
    assert res is not None, "Result should not be None when threshold exceeded"
    assert res["dry_run"] is True, "Should be in dry run mode without force"
    assert os.path.exists(os.path.join(root, "tmp/a.tmp")), "Files should not be deleted in dry run"
    
    # force 授权：真正清理可再生垃圾，受保护数据仍在
    res2 = sj.auto_maintain(root=root, force=True, disk_pct=99)
    assert res2["dry_run"] is False, "Should be in actual cleanup mode with force"
    assert not os.path.exists(os.path.join(root, "tmp/a.tmp")), "Files should be deleted with force"
    assert os.path.exists(os.path.join(root, "db/chat.db")), "Protected data should remain"
    
    # 真实删除已原子记账，且审计目录受保护、不被自身清理
    audit_path = os.path.join(root, "maintenance", "history.jsonl")
    assert os.path.exists(audit_path), "Audit file should exist"
    assert res2.get("audited_to") == audit_path, "Audit path should match"
    
    plan_after = "\n".join(p["path"] for p in sj.plan_cleanup(root=root))
    assert "/maintenance/" not in plan_after, "Maintenance dir should not be in cleanup plan"
    
    records = read_jsonl(audit_path)
    assert len(records) > 0, "Audit records should exist"
    rec = records[0]
    assert rec["freed_bytes"] > 0, "Freed bytes in audit should be > 0"
    assert rec["removed_count"] > 0, "Removed count in audit should be > 0"

def _run_all() -> int:
    """收集并运行所有以 'test_' 开头的可调用对象，返回失败数量。

    供脚本直接执行时使用。打印每个用例的 PASS/FAIL 结果及异常栈。

    Returns:
        失败的测试数量。若为 0，则脚本退出码为 0。
    """
    test_fns: List[Callable[[], None]] = [
        obj for name, obj in sorted(globals().items())
        if name.startswith("test_") and callable(obj)
    ]
    
    failed: int = 0
    for fn in test_fns:
        try:
            fn()
            print(f"PASS {fn.__name__}")
        except Exception as e:
            failed += 1
            print(f"FAIL {fn.__name__}: {repr(e)}")
            traceback.print_exc()
    
    print(f"total={len(test_fns)} failed={failed}")
    return failed

if __name__ == "__main__":
    sys.exit(1 if _run_all() else 0)
