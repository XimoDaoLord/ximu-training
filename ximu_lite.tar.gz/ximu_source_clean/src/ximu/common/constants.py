#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
汐沫AI - 通用常量定义模块。

本模块集中管理枚举类型、错误码与默认值，消除跨模块硬编码，
确保系统内状态、级别、后端类型等标识符的全局唯一性与一致性。
"""

import os
from enum import Enum
from typing import Dict, Optional

# 尝试从核心模块获取数据根目录，若失败则回退到环境变量或默认值
try:
    from src.ximu.core.data_root import get_data_root as _get_data_root
    
    XIMU_DATA_ROOT: str = _get_data_root()
except Exception:
    # 核心模块尚未就绪时兜底，优先读取环境变量，否则使用相对路径
    XIMU_DATA_ROOT: str = os.environ.get("XIMU_DATA_ROOT", "./data")


class ModuleStatus(Enum):
    """模块生命周期状态枚举。"""
    UNINITIALIZED = "uninitialized"
    INITIALIZING = "initializing"
    READY = "ready"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"
    DEGRADED = "degraded"
    MAINTENANCE = "maintenance"


class TaskStatus(Enum):
    """任务状态枚举（全局唯一权威定义）。"""
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"
    RETRYING = "retrying"
    SKIPPED = "skipped"
    PAUSED = "paused"


class MemoryLevel(Enum):
    """记忆层级枚举，L0~L5 分别对应不同持久化层级。"""
    L0_SHORT_TERM = "l0_short_term"
    L1_MEDIUM_TERM = "l1_medium_term"
    L2_LONG_TERM = "l2_long_term"
    L3_EPISODIC = "l3_episodic"
    L4_SEMANTIC = "l4_semantic"
    L5_PROCEDURAL = "l5_procedural"


class ModelProvider(Enum):
    """模型提供商枚举。"""
    XIMU = "ximu"
    OPENAI = "openai"
    OPENAI_COMPATIBLE = "openai_compatible"
    ANTHROPIC = "anthropic"
    ANTHROPIC_COMPATIBLE = "anthropic_compatible"
    GOOGLE = "google"
    GOOGLE_GEMINI = "google_gemini"
    DEEPSEEK = "deepseek"
    HUGGINGFACE = "huggingface"
    OPENROUTER = "openrouter"
    LOCAL = "local"
    CUSTOM = "custom"


class CircuitBreakerState(Enum):
    """熔断器状态枚举。"""
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class LogLevel(Enum):
    """日志级别枚举。"""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class EnvironmentType(Enum):
    """环境类型枚举。"""
    DEVELOPMENT = "development"
    TESTING = "testing"
    STAGING = "staging"
    PRODUCTION = "production"


class EncryptionAlgorithm(Enum):
    """加密算法枚举。"""
    XIMU_ENC1 = "ximu-enc1"
    AES_256_CBC = "aes-256-cbc"
    AES_256_GCM = "aes-256-gcm"
    RSA_2048 = "rsa-2048"
    RSA_4096 = "rsa-4096"
    CHACHA20_POLY1305 = "chacha20-poly1305"


class CacheBackend(Enum):
    """缓存后端枚举。"""
    MEMORY = "memory"
    REDIS = "redis"
    MEMCACHED = "memcached"
    FILE = "file"
    SQLITE = "sqlite"


class DatabaseBackend(Enum):
    """数据库后端枚举。"""
    SQLITE = "sqlite"
    POSTGRESQL = "postgresql"
    MYSQL = "mysql"
    MONGODB = "mongodb"
    REDIS = "redis"


class MessageRole(Enum):
    """消息角色枚举。"""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"
    FUNCTION = "function"


class MessageType(Enum):
    """消息类型枚举。"""
    TEXT = "text"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    FILE = "file"
    CODE = "code"
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    SYSTEM_NOTICE = "system_notice"


class PriorityLevel(Enum):
    """优先级枚举。"""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3
    URGENT = 4


class ErrorCode:
    """错误码常量类，集中管理所有语义化错误码与数字码映射。

    注意：此类中的属性均为字符串常量，用于标识错误类型。
    NUMERIC_TO_SYMBOLIC 提供了数字码到语义码的映射，用于兼容旧版API。
    """

    # 通用错误
    UNKNOWN_ERROR = "UNKNOWN_ERROR"
    INTERNAL_ERROR = "INTERNAL_ERROR"
    INVALID_INPUT = "INVALID_INPUT"
    NOT_FOUND = "NOT_FOUND"
    ALREADY_EXISTS = "ALREADY_EXISTS"
    PERMISSION_DENIED = "PERMISSION_DENIED"
    UNAUTHORIZED = "UNAUTHORIZED"
    RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED"
    SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE"
    TIMEOUT = "TIMEOUT"

    # 业务逻辑错误
    BUSINESS_ERROR = "BUSINESS_ERROR"
    BUSINESS_RULE_VIOLATION = "BUSINESS_RULE_VIOLATION"
    INVALID_STATE = "INVALID_STATE"
    OPERATION_NOT_ALLOWED = "OPERATION_NOT_ALLOWED"

    # 系统资源错误
    SYSTEM_ERROR = "SYSTEM_ERROR"
    RESOURCE_EXHAUSTED = "RESOURCE_EXHAUSTED"
    OUT_OF_MEMORY = "OUT_OF_MEMORY"
    DISK_FULL = "DISK_FULL"
    NETWORK_ERROR = "NETWORK_ERROR"
    CONNECTION_REFUSED = "CONNECTION_REFUSED"
    DNS_RESOLUTION_FAILED = "DNS_RESOLUTION_FAILED"

    # 数据一致性错误
    DATA_ERROR = "DATA_ERROR"
    DATA_CORRUPTED = "DATA_CORRUPTED"
    DATA_INTEGRITY_VIOLATION = "DATA_INTEGRITY_VIOLATION"
    DATABASE_ERROR = "DATABASE_ERROR"
    DATABASE_CONNECTION_FAILED = "DATABASE_CONNECTION_FAILED"
    QUERY_FAILED = "QUERY_FAILED"

    # 验证错误
    VALIDATION_ERROR = "VALIDATION_ERROR"
    FIELD_REQUIRED = "FIELD_REQUIRED"
    FIELD_TOO_SHORT = "FIELD_TOO_SHORT"
    FIELD_TOO_LONG = "FIELD_TOO_LONG"
    INVALID_FORMAT = "INVALID_FORMAT"
    INVALID_VALUE = "INVALID_VALUE"
    OUT_OF_RANGE = "OUT_OF_RANGE"

    # 配置错误
    CONFIG_ERROR = "CONFIG_ERROR"
    CONFIG_NOT_FOUND = "CONFIG_NOT_FOUND"
    CONFIG_INVALID = "CONFIG_INVALID"
    CONFIG_MISSING_KEY = "CONFIG_MISSING_KEY"

    # 模型服务错误
    MODEL_ERROR = "MODEL_ERROR"
    MODEL_NOT_FOUND = "MODEL_NOT_FOUND"
    MODEL_UNAVAILABLE = "MODEL_UNAVAILABLE"
    MODEL_TIMEOUT = "MODEL_TIMEOUT"
    MODEL_RATE_LIMITED = "MODEL_RATE_LIMITED"
    MODEL_INVALID_RESPONSE = "MODEL_INVALID_RESPONSE"
    MODEL_AUTH_FAILED = "MODEL_AUTH_FAILED"

    # 记忆系统错误
    MEMORY_ERROR = "MEMORY_ERROR"
    MEMORY_NOT_FOUND = "MEMORY_NOT_FOUND"
    MEMORY_CORRUPTED = "MEMORY_CORRUPTED"
    MEMORY_FULL = "MEMORY_FULL"

    # 任务系统错误
    TASK_ERROR = "TASK_ERROR"
    TASK_NOT_FOUND = "TASK_NOT_FOUND"
    TASK_ALREADY_RUNNING = "TASK_ALREADY_RUNNING"
    TASK_CANCELLED = "TASK_CANCELLED"
    TASK_FAILED = "TASK_FAILED"
    TASK_TIMEOUT = "TASK_TIMEOUT"

    # 文件系统错误
    FILE_ERROR = "FILE_ERROR"
    FILE_NOT_FOUND = "FILE_NOT_FOUND"
    FILE_ALREADY_EXISTS = "FILE_ALREADY_EXISTS"
    FILE_TOO_LARGE = "FILE_TOO_LARGE"
    FILE_PERMISSION_DENIED = "FILE_PERMISSION_DENIED"
    FILE_CORRUPTED = "FILE_CORRUPTED"

    # 加密系统错误
    ENCRYPTION_ERROR = "ENCRYPTION_ERROR"
    ENCRYPTION_FAILED = "ENCRYPTION_FAILED"
    DECRYPTION_FAILED = "DECRYPTION_FAILED"
    INVALID_KEY = "INVALID_KEY"
    KEY_EXPIRED = "KEY_EXPIRED"

    # 插件系统错误
    PLUGIN_ERROR = "PLUGIN_ERROR"
    PLUGIN_NOT_FOUND = "PLUGIN_NOT_FOUND"
    PLUGIN_ALREADY_INSTALLED = "PLUGIN_ALREADY_INSTALLED"
    PLUGIN_INCOMPATIBLE = "PLUGIN_INCOMPATIBLE"
    PLUGIN_LOAD_FAILED = "PLUGIN_LOAD_FAILED"

    # 数字码兼容映射 (旧版 API 兼容)
    E1001 = "E1001"
    E1002 = "E1002"
    E1003 = "E1003"
    E2001 = "E2001"
    E2002 = "E2002"
    E2003 = "E2003"
    E501 = "E501"
    E9001 = "E9001"
    E9002 = "E9002"
    E9999 = "E9999"

    @staticmethod
    def get_numeric_mapping() -> Dict[str, str]:
        """获取数字码到语义码的映射字典。

        Returns:
            包含映射关系的字典。
        """
        return {
            "E1001": ErrorCode.INVALID_INPUT,
            "E1002": ErrorCode.NOT_FOUND,
            "E1003": ErrorCode.INTERNAL_ERROR,
            "E2001": ErrorCode.VALIDATION_ERROR,
            "E2002": ErrorCode.CONFIG_ERROR,
            "E2003": ErrorCode.NETWORK_ERROR,
            "E501": ErrorCode.TIMEOUT,
            "E9001": ErrorCode.MODEL_ERROR,
            "E9002": ErrorCode.MODEL_TIMEOUT,
            "E9999": ErrorCode.UNKNOWN_ERROR,
        }


class DefaultValues:
    """系统默认值常量类。"""

    # 基础配置
    DEFAULT_ENVIRONMENT: str = "production"
    DEFAULT_LOG_LEVEL: str = "info"
    DEFAULT_TIMEZONE: str = "Asia/Shanghai"
    DEFAULT_LANGUAGE: str = "zh-CN"
    DEFAULT_VERSION: str = "0.5"
    DEFAULT_VERSION_CODE: int = 5

    # 网络配置
    DEFAULT_HOST: str = "0.0.0.0"
    DEFAULT_PORT: int = 7860
    DEFAULT_API_PORT: int = 8000
    DEFAULT_TIMEOUT: float = 30.0
    DEFAULT_RETRY_COUNT: int = 3
    DEFAULT_RETRY_DELAY: float = 1.0

    # 缓存配置
    DEFAULT_CACHE_BACKEND: str = "memory"
    DEFAULT_CACHE_TTL: int = 3600
    DEFAULT_CACHE_MAX_SIZE: int = 10000

    # 数据库配置
    DEFAULT_DB_BACKEND: str = "sqlite"
    DEFAULT_DB_PATH: str = "./data/ximu.db"
    DEFAULT_DB_POOL_SIZE: int = 5

    # 目录结构默认值
    DEFAULT_KNOWLEDGE_DIR: str = "./data/knowledge"
    DEFAULT_MEMORY_DIR: str = "./data/memory"
    DEFAULT_LOG_DIR: str = "./data/logs"
    DEFAULT_TEMP_DIR: str = "./data/tmp"
