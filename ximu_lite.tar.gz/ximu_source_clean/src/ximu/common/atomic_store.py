# -*- coding: utf-8 -*-
"""
原子存储模块：提供线程安全的原子写入与持久化能力。
"""

import json
import os
import tempfile
import threading
from pathlib import Path
from typing import Any, Optional, Union


class AtomicStore:
    """线程安全的原子存储类，支持安全写入和读取。"""

    def __init__(self, base_path: Union[str, Path]) -> None:
        """
        初始化原子存储。

        Args:
            base_path: 存储根目录路径。
        """
        self._base_path = Path(base_path).expanduser().resolve()
        self._base_path.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def _resolve_path(self, key: str) -> Path:
        """
        将键解析为完整文件路径。

        Args:
            key: 存储键。

        Returns:
            对应的文件路径。

        Raises:
            ValueError: 如果键包含非法字符。
        """
        if not key or "/" in key or ".." in key:
            raise ValueError(f"Invalid key: {key!r}")
        return self._base_path / f"{key}.json"

    def write(self, key: str, data: Any) -> None:
        """
        原子写入数据。

        Args:
            key: 存储键。
            data: 要写入的数据（必须可JSON序列化）。
        """
        path = self._resolve_path(key)
        with self._lock:
            with tempfile.NamedTemporaryFile(
                dir=self._base_path, prefix=f".{key}.", suffix=".tmp", delete=False
            ) as tmp:
                json.dump(data, tmp, ensure_ascii=False, indent=2)
                tmp.flush()
                os.fsync(tmp.fileno())
            os.replace(tmp.name, path)

    def read(self, key: str, default: Optional[Any] = None) -> Any:
        """
        读取存储的数据。

        Args:
            key: 存储键。
            default: 键不存在或读取失败时返回的默认值。

        Returns:
            存储的数据或默认值。
        """
        path = self._resolve_path(key)
        if not path.exists():
            return default
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return default

    def delete(self, key: str) -> bool:
        """
        删除存储项。

        Args:
            key: 存储键。

        Returns:
            如果成功删除返回 True，否则 False。
        """
        path = self._resolve_path(key)
        with self._lock:
            if path.exists():
                path.unlink()
                return True
        return False

    def keys(self) -> list[str]:
        """
        列出所有存储键。

        Returns:
            键列表。
        """
        return [p.stem for p in self._base_path.glob("*.json")]

    def clear(self) -> int:
        """
        清空所有存储项。

        Returns:
            被删除的文件数量。
        """
        deleted = 0
        with self._lock:
            for f in self._base_path.glob("*.json"):
                f.unlink()
                deleted += 1
        return deleted

    def exists(self, key: str) -> bool:
        """
        检查键是否存在。

        Args:
            key: 存储键。

        Returns:
            存在返回 True，否则 False。
        """
        return self._resolve_path(key).exists()

    def __contains__(self, key: str) -> bool:
        """
        支持 in 操作符。

        Args:
            key: 存储键。

        Returns:
            存在返回 True，否则 False。
        """
        return self.exists(key)

    def __getitem__(self, key: str) -> Any:
        """
        通过下标获取数据。

        Args:
            key: 存储键。

        Returns:
            存储的数据。
        """
        result = self.read(key)
        if result is None:
            raise KeyError(f"Key not found: {key!r}")
        return result

    def __setitem__(self, key: str, value: Any) -> None:
        """
        通过下标写入数据。

        Args:
            key: 存储键。
            value: 要写入的数据。
        """
        self.write(key, value)

    def __delitem__(self, key: str) -> None:
        """
        通过下标删除数据。

        Args:
            key: 存储键。
        """
        if not self.delete(key):
            raise KeyError(f"Key not found: {key!r}")

    def __len__(self) -> int:
        """
        返回存储项数量。
        """
        return len(self.keys())

    def __iter__(self):
        """
        迭代所有键。

        Yields:
            存储键。
        """
        yield from self.keys()


def read_jsonl(path):
    """读取JSONL文件。"""
    import json
    results = []
    try:
        with open(path) as f:
            for line in f:
                results.append(json.loads(line.strip()))
    except Exception:
        pass
    return results
