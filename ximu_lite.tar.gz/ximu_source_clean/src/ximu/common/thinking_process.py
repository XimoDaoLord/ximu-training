"""结构化可解释思考过程系统

记录 AI 的思考步骤，支持：
- 11 种思考类型分类
- 证据 / 置信度 / 中间结论
- 哈希链保证完整性不可篡改
- JSON / Markdown 导出（concise/standard/detailed）
- 自动提炼关键决策点和逻辑完整性校验
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional


class ThinkingType(Enum):
    """思考步骤类型枚举。"""
    PROBLEM_UNDERSTANDING = "problem_understanding"
    INFORMATION_RETRIEVAL = "information_retrieval"
    CAUSAL_ANALYSIS = "causal_analysis"
    HYPOTHESIS_GENERATION = "hypothesis_generation"
    HYPOTHESIS_EVALUATION = "hypothesis_evaluation"
    DECISION = "decision"
    PLANNING = "planning"
    REFLECTION = "reflection"
    VERIFICATION = "verification"
    SYNTHESIS = "synthesis"
    UNKNOWN = "unknown"


@dataclass
class ThinkingStep:
    """单个思考步骤。"""
    step_id: str
    step_type: ThinkingType
    content: str
    evidence: str = ""
    confidence: float = 0.5
    intermediate_conclusion: str = ""
    duration_ms: float = 0.0
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    parent_step_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    hash_value: str = ""
    prev_hash: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典，step_type 取枚举值，便于 JSON 落盘。"""
        return {
            "step_id": self.step_id,
            "step_type": self.step_type.value,
            "content": self.content,
            "evidence": self.evidence,
            "confidence": self.confidence,
            "intermediate_conclusion": self.intermediate_conclusion,
            "duration_ms": self.duration_ms,
            "timestamp": self.timestamp,
            "parent_step_id": self.parent_step_id,
            "metadata": self.metadata,
            "hash_value": self.hash_value,
            "prev_hash": self.prev_hash,
        }


@dataclass
class ThinkingConfig:
    """思考过程配置。"""
    enabled: bool = True
    detail_level: str = "standard"  # concise / standard / detailed
    max_steps: int = 100
    max_duration_ms: float = 30000
    record_evidence: bool = True
    record_confidence: bool = True
    enable_hash_chain: bool = True
    auto_summarize: bool = True
    save_to_memory: bool = False


class ThinkingProcess:
    """结构化思考过程记录器。"""

    def __init__(self, config: Optional[ThinkingConfig] = None) -> None:
        """初始化思考过程记录器

        Args:
            config: 思考过程配置，可选
        """
        self.config = config or ThinkingConfig()
        self._steps: List[ThinkingStep] = []
        self._question: str = ""
        self._context: Dict[str, Any] = {}
        self._start_time: float = 0.0
        self._end_time: float = 0.0
        self._final_conclusion: str = ""
        self._final_confidence: float = 1.0
        self._last_hash: str = "GENESIS"
        self._finished = False

    # ------------------------------------------------------------------ #
    # 生命周期
    # ------------------------------------------------------------------ #
    def start(self, question: str,
              context: Optional[Dict[str, Any]] = None) -> None:
        """开始思考过程。

        Args:
            question: 思考的问题或主题
            context: 上下文信息，可选
        """
        self._question = question
        self._context = context or {}
        self._start_time = time.monotonic()

    def add_step(
        self,
        step_type: ThinkingType,
        content: str,
        evidence: str = "",
        confidence: float = 0.5,
        intermediate_conclusion: str = "",
        parent_step_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """添加一个思考步骤，返回 step_id。

        Args:
            step_type: 步骤类型
            content: 步骤内容
            evidence: 证据，可选
            confidence: 置信度，默认为0.5
            intermediate_conclusion: 中间结论，可选
            parent_step_id: 父步骤ID，可选
            metadata: 元数据，可选

        Returns:
            新步骤的ID，如果配置禁用或达到最大步数则返回空字符串
        """
        if not self.config.enabled:
            return ""
        if len(self._steps) >= self.config.max_steps:
            return ""
        step_id = f"step_{len(self._steps) + 1:04d}"
        step_start = time.monotonic()
        step = ThinkingStep(
            step_id=step_id,
            step_type=step_type,
            content=content,
            evidence=evidence if self.config.record_evidence else "",
            confidence=confidence if self.config.record_confidence else 0.5,
            intermediate_conclusion=intermediate_conclusion,
            parent_step_id=parent_step_id,
            metadata=metadata or {},
        )
        step.duration_ms = (time.monotonic() - step_start) * 1000
        if self.config.enable_hash_chain:
            step.prev_hash = self._last_hash
            step.hash_value = self._compute_hash(step)
            self._last_hash = step.hash_value
        self._steps.append(step)
        return step_id

    def update_step(self, step_id: str, **kwargs: Any) -> bool:
        """更新已有步骤的字段。会重算该步及后续步骤的哈希链，保证完整性校验仍通过。

        Args:
            step_id: 要更新的步骤ID
            **kwargs: 要更新的字段键值对

        Returns:
            更新成功返回True，步骤不存在返回False
        """
        for idx, step in enumerate(self._steps):
            if step.step_id == step_id:
                for key, value in kwargs.items():
                    if hasattr(step, key) and key not in ("step_id", "hash_value"):
                        setattr(step, key, value)
                # 重算从当前步起的整条哈希链
                if self.config.enable_hash_chain:
                    prev = self._steps[idx - 1].hash_value if idx > 0 else "GENESIS"
                    for j in range(idx, len(self._steps)):
                        self._steps[j].prev_hash = prev
                        self._steps[j].hash_value = self._compute_hash(self._steps[j])
                        prev = self._steps[j].hash_value
                    self._last_hash = prev
                return True
        return False

    def finish(self, final_conclusion: str, confidence: float = 1.0) -> None:
        """结束思考过程。

        Args:
            final_conclusion: 最终结论
            confidence: 最终置信度，默认为1.0
        """
        self._final_conclusion = final_conclusion
        self._final_confidence = confidence
        self._end_time = time.monotonic()
        self._finished = True

    # ------------------------------------------------------------------ #
    # 查询
    # ------------------------------------------------------------------ #
    def get_steps(self) -> List[ThinkingStep]:
        """返回所有思考步骤的副本（按记录顺序）。"""
        return list(self._steps)

    def get_step(self, step_id: str) -> Optional[ThinkingStep]:
        """按 step_id 精确查找；不存在返回 None。"""
        for step in self._steps:
            if step.step_id == step_id:
                return step
        return None

    def get_tree(self) -> List[Dict[str, Any]]:
        """返回父子关系树。"""
        by_id = {s.step_id: s.to_dict() for s in self._steps}
        roots: List[Dict[str, Any]] = []
        for step in self._steps:
            node = by_id[step.step_id]
            node["children"] = []
            if step.parent_step_id and step.parent_step_id in by_id:
                by_id[step.parent_step_id].setdefault("children", []).append(node)
            else:
                roots.append(node)
        return roots

    def get_duration(self) -> float:
        """总耗时（秒）。"""
        end = self._end_time or time.monotonic()
        return end - self._start_time if self._start_time else 0.0

    def get_confidence_history(self) -> List[float]:
        """返回每步的置信度序列。"""
        return [s.confidence for s in self._steps]

    # ------------------------------------------------------------------ #
    # 哈希链
    # ------------------------------------------------------------------ #
    @staticmethod
    def _compute_hash(step: ThinkingStep) -> str:
        """计算步骤哈希，包含前一步哈希。"""
        data = "|".join([
            step.step_id, step.step_type.value, step.content,
            step.evidence, str(step.confidence), step.timestamp,
            step.prev_hash,
        ])
        return hashlib.sha256(data.encode("utf-8")).hexdigest()[:16]

    def verify_integrity(self) -> bool:
        """验证哈希链是否完整（未被篡改）。"""
        if not self.config.enable_hash_chain:
            return True
        prev = "GENESIS"
        for step in self._steps:
            expected = self._compute_hash(step)
            if step.prev_hash != prev or step.hash_value != expected:
                return False
            prev = step.hash_value
        return True

    def export_json(self, detail_level: Optional[str] = None) -> str:
        """导出为JSON字符串

        Args:
            detail_level: 详细级别（concise/standard/detailed），默认为配置的级别

        Returns:
            JSON格式字符串
        """
        detail = detail_level or self.config.detail_level
        data = {
            "question": self._question,
            "context": self._context,
            "steps": [],
            "final_conclusion": self._final_conclusion,
            "final_confidence": self._final_confidence,
            "duration_ms": self.get_duration() * 1000,
        }

        for step in self._steps:
            step_dict = step.to_dict()
            if detail == "concise":
                step_dict = {
                    "step_id": step_dict["step_id"],
                    "step_type": step_dict["step_type"],
                    "content": step_dict["content"],
                }
            elif detail == "standard":
                step_dict.pop("metadata", None)
            data["steps"].append(step_dict)

        return json.dumps(data, ensure_ascii=False, indent=2)

    def export_markdown(self, detail_level: Optional[str] = None) -> str:
        """导出为Markdown字符串

        Args:
            detail_level: 详细级别（concise/standard/detailed），默认为配置的级别

        Returns:
            Markdown格式字符串
        """
        detail = detail_level or self.config.detail_level
        lines = [f"# 思考过程: {self._question}\n"]

        if self._context and detail != "concise":
            lines.append("## 上下文\n")
            for key, value in self._context.items():
                lines.append(f"- **{key}**: {value}")
            lines.append("")

        lines.append("## 思考步骤\n")
        for step in self._steps:
            lines.append(f"### 步骤 {step.step_id} - {step.step_type.value}")
            lines.append(f"{step.content}")
            if detail != "concise":
                if step.evidence:
                    lines.append(f"**证据**: {step.evidence}")
                lines.append(f"**置信度**: {step.confidence:.2f}")
                if step.intermediate_conclusion:
                    lines.append(f"**中间结论**: {step.intermediate_conclusion}")
            if detail == "detailed" and step.metadata:
                lines.append("**元数据**:")
                for k, v in step.metadata.items():
                    lines.append(f"- {k}: {v}")
            lines.append("")

        lines.append("## 最终结论\n")
        lines.append(f"**结论**: {self._final_conclusion}")
        lines.append(f"**置信度**: {self._final_confidence:.2f}")
        lines.append(f"**耗时**: {self.get_duration():.2f}秒")

        return "\n".join(lines)
