"""统一文件处理工具

提供以下核心功能：
- 文件读写（文本/JSON/行）
- 目录操作（创建/列表/查找/删除）
- 压缩解压（zipfile）
- 文件哈希（MD5/SHA256，8KB 分块）
- 安全路径（safe_join / is_subpath）

所有公开接口保持向后兼容，内部增强了类型注解、文档字符串、错误处理与资源管理。
"""

from __future__ import annotations

import fnmatch
import hashlib
import json
import os
import shutil
import zipfile
from typing import Any, List, Optional, Union

# 文件哈希分块大小（字节），8KB 兼顾内存与吞吐
_HASH_CHUNK_BYTES = 8192


# ------------------------------------------------------------------ #
# 基础读写
# ------------------------------------------------------------------ #


def read_file(path: str, encoding: str = "utf-8") -> str:
    """读取文本文件内容。

    Args:
        path: 文件路径。
        encoding: 文件编码，默认 UTF-8。

    Returns:
        文件全文字符串。

    Raises:
        FileNotFoundError: 文件不存在时抛出。
        UnicodeDecodeError: 编码不匹配时抛出。
    """
    with open(path, "r", encoding=encoding) as f:
        return f.read()


def write_file(path: str, content: str, encoding: str = "utf-8") -> str:
    """写入文本文件，自动创建父目录。

    Args:
        path: 目标文件路径。
        content: 要写入的文本内容。
        encoding: 文件编码，默认 UTF-8。

    Returns:
        写入文件的绝对路径。

    Raises:
        OSError: 创建目录或写入文件失败时抛出。
    """
    abs_path = os.path.abspath(path)
    parent_dir = os.path.dirname(abs_path)
    if parent_dir:
        os.makedirs(parent_dir, exist_ok=True)
    with open(abs_path, "w", encoding=encoding) as f:
        f.write(content)
    return abs_path


def read_json(path: str) -> Any:
    """读取 JSON 文件并解析。

    Args:
        path: JSON 文件路径。

    Returns:
        解析后的 Python 对象（dict, list, str, int, float, bool 或 None）。

    Raises:
        FileNotFoundError: 文件不存在时抛出。
        json.JSONDecodeError: JSON 格式错误时抛出。
    """
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str, data: Any, indent: int = 2) -> str:
    """写入 JSON 文件，自动创建父目录。

    Args:
        path: 目标 JSON 文件路径。
        data: 要序列化的 Python 对象。
        indent: JSON 缩进空格数，默认 2。

    Returns:
        写入文件的绝对路径。

    Raises:
        OSError: 创建目录或写入文件失败时抛出。
        TypeError: 数据不可序列化时抛出。
    """
    abs_path = os.path.abspath(path)
    parent_dir = os.path.dirname(abs_path)
    if parent_dir:
        os.makedirs(parent_dir, exist_ok=True)
    with open(abs_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=indent)
    return abs_path


def write_lines(path: str, lines: List[str], encoding: str = "utf-8") -> str:
    """按行写入文件，每行后追加换行符。

    Args:
        path: 目标文件路径。
        lines: 行列表。
        encoding: 文件编码，默认 UTF-8。

    Returns:
        写入文件的绝对路径。

    Raises:
        OSError: 创建目录或写入文件失败时抛出。
    """
    content = "\n".join(lines)
    if lines:
        content += "\n"
    return write_file(path, content, encoding=encoding)


def read_lines(path: str, encoding: str = "utf-8") -> List[str]:
    """按行读取文件，返回行列表（不含换行符）。

    Args:
        path: 文件路径。
        encoding: 文件编码，默认 UTF-8。

    Returns:
        行列表，不包含行尾换行符。若文件以换行结尾，最后一行为空字符串。

    Raises:
        FileNotFoundError: 文件不存在时抛出。
        UnicodeDecodeError: 编码不匹配时抛出。
    """
    with open(path, "r", encoding=encoding) as f:
        return f.read().splitlines()


# ------------------------------------------------------------------ #
# 目录操作
# ------------------------------------------------------------------ #


def ensure_dir(path: str) -> str:
    """确保目录存在，返回绝对路径。

    Args:
        path: 目标目录路径。

    Returns:
        目录的绝对路径。

    Raises:
        OSError: 创建目录失败时抛出。
    """
    abs_path = os.path.abspath(path)
    os.makedirs(abs_path, exist_ok=True)
    return abs_path


def list_files(
    directory: str,
    pattern: str = "*",
    recursive: bool = False,
) -> List[str]:
    """列出目录下匹配 pattern 的文件。

    Args:
        directory: 目标目录路径。
        pattern: fnmatch 格式通配符，如 "*.txt"。
        recursive: 是否递归搜索子目录。

    Returns:
        匹配文件的绝对路径列表，按路径排序。若目录不存在返回空列表。

    Raises:
        OSError: 访问目录权限不足时抛出。
    """
    result: List[str] = []
    if not os.path.isdir(directory):
        return result

    if recursive:
        for root, _, files in os.walk(directory, onerror=_walk_error_handler):
            for name in files:
                if fnmatch.fnmatch(name, pattern):
                    result.append(os.path.join(root, name))
    else:
        try:
            entries = os.listdir(directory)
        except OSError:
            return result
        for name in entries:
            full = os.path.join(directory, name)
            if os.path.isfile(full) and fnmatch.fnmatch(name, pattern):
                result.append(full)
    return sorted(result)


def find_files(directory: str, pattern: str = "*", recursive: bool = False) -> List[str]:
    """查找匹配 pattern 的文件（list_files 的别名，语义一致）。

    Args:
        directory: 目标目录路径。
        pattern: fnmatch 格式通配符。
        recursive: 是否递归搜索。

    Returns:
        匹配文件的绝对路径列表。

    参见:
        :func:`list_files`
    """
    return list_files(directory, pattern=pattern, recursive=recursive)


def _walk_error_handler(error: OSError) -> None:
    """os.walk 的错误处理器，静默忽略访问错误。

    Args:
        error: 捕获到的 OSError。
    """
    pass


# ------------------------------------------------------------------ #
# 文件哈希
# ------------------------------------------------------------------ #


def _file_hash(path: str, algorithm: str) -> str:
    """通用文件哈希计算，8KB 分块读取。

    Args:
        path: 文件路径。
        algorithm: 哈希算法名称（如 "md5", "sha256"）。

    Returns:
        十六进制哈希字符串。

    Raises:
        FileNotFoundError: 文件不存在时抛出。
        ValueError: 不支持的哈希算法时抛出。
        PermissionError: 无读取权限时抛出。
    """
    try:
        h = hashlib.new(algorithm)
    except (ValueError, TypeError) as e:
        raise ValueError(f"不支持的哈希算法: {algorithm}") from e

    with open(path, "rb") as f:
        while True:
            chunk = f.read(_HASH_CHUNK_BYTES)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def file_md5(path: str) -> str:
    """计算文件 MD5 哈希值。

    Args:
        path: 文件路径。

    Returns:
        32 字符十六进制 MD5 哈希字符串。

    Raises:
        FileNotFoundError: 文件不存在时抛出。
        PermissionError: 无读取权限时抛出。
    """
    return _file_hash(path, "md5")


def file_sha256(path: str) -> str:
    """计算文件 SHA256 哈希值。

    Args:
        path: 文件路径。

    Returns:
        64 字符十六进制 SHA256 哈希字符串。

    Raises:
        FileNotFoundError: 文件不存在时抛出。
        PermissionError: 无读取权限时抛出。
    """
    return _file_hash(path, "sha256")


# ------------------------------------------------------------------ #
# 压缩解压
# ------------------------------------------------------------------ #


def zip_dir(src_dir: str, zip_path: str) -> str:
    """将 src_dir 目录打包为 zip 文件。

    Args:
        src_dir: 源目录路径。
        zip_path: 目标 zip 文件路径。

    Returns:
        zip 文件的绝对路径。

    Raises:
        FileNotFoundError: src_dir 不存在时抛出。
        OSError: 创建父目录或写入 zip 失败时抛出。
    """
    if not os.path.isdir(src_dir):
        raise FileNotFoundError(f"源目录不存在: {src_dir}")

    abs_zip = os.path.abspath(zip_path)
    parent_dir = os.path.dirname(abs_zip)
    if parent_dir:
        os.makedirs(parent_dir, exist_ok=True)

    with zipfile.ZipFile(abs_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(src_dir, onerror=_walk_error_handler):
            for name in files:
                full = os.path.join(root, name)
                arc = os.path.relpath(full, src_dir)
                zf.write(full, arc)
    return abs_zip


def unzip_file(zip_path: str, dest_dir: str) -> str:
    """解压 zip 到 dest_dir，防止 Zip Slip 路径遍历攻击。

    在解压前校验所有条目路径，拒绝任何包含 ".." 逃逸的条目。

    Args:
        zip_path: zip 文件路径。
        dest_dir: 目标解压目录。

    Returns:
        解压目标目录的绝对路径。

    Raises:
        FileNotFoundError: zip 文件不存在时抛出。
        RuntimeError: 检测到非法路径遍历条目时抛出。
        zipfile.BadZipFile: zip 文件损坏时抛出。
        OSError: 创建目标目录或写入文件失败时抛出。
    """
    abs_dest = os.path.abspath(dest_dir)
    os.makedirs(abs_dest, exist_ok=True)

    with zipfile.ZipFile(zip_path, "r") as zf:
        for entry in zf.namelist():
            target_path = os.path.join(abs_dest, entry)
            if not os.path.realpath(target_path).startswith(abs_dest):
                raise RuntimeError(f"非法路径遍历: {entry}")
        zf.extractall(abs_dest)
    return abs_dest


# ------------------------------------------------------------------ #
# 安全路径
# ------------------------------------------------------------------ #


def safe_join(base: str, *paths: str) -> str:
    """安全拼接路径，拒绝包含 '..' 的组件。

    Args:
        base: 基准目录路径。
        *paths: 附加路径组件。

    Returns:
        拼接后的绝对路径。

    Raises:
        ValueError: 拼接结果逃逸出 base 目录时抛出。
    """
    normalized_base = os.path.realpath(base)
    joined = os.path.join(normalized_base, *paths)
    resolved = os.path.realpath(joined)
    if not resolved.startswith(normalized_base + os.sep) and resolved != normalized_base:
        raise ValueError(f"路径逃逸: {joined}")
    return resolved


def is_subpath(child: str, parent: str) -> bool:
    """检查 child 是否是 parent 的子路径。

    Args:
        child: 待检查路径。
        parent: 父路径。

    Returns:
        是否为子路径
    """
    normalized_child = os.path.realpath(child)
    normalized_parent = os.path.realpath(parent)
    return normalized_child.startswith(normalized_parent + os.sep) or normalized_child == normalized_parent


# ------------------------------------------------------------------ #
# 目录操作扩展
# ------------------------------------------------------------------ #


def remove_dir(path: str, ignore_errors: bool = False) -> bool:
    """递归删除目录。

    Args:
        path: 目标目录路径。
        ignore_errors: 是否忽略错误。

    Returns:
        删除是否成功。
    """
    try:
        shutil.rmtree(path, ignore_errors=ignore_errors)
        return True
    except OSError:
        if not ignore_errors:
            raise
        return False


def copy_dir(src: str, dst: str) -> str:
    """递归复制目录。

    Args:
        src: 源目录路径。
        dst: 目标目录路径。

    Returns:
        目标目录的绝对路径。

    Raises:
        FileNotFoundError: 源目录不存在时抛出。
        OSError: 复制失败时抛出。
    """
    if not os.path.isdir(src):
        raise FileNotFoundError(f"源目录不存在: {src}")
    abs_dst = os.path.abspath(dst)
    shutil.copytree(src, abs_dst)
    return abs_dst


def get_dir_size(path: str) -> int:
    """递归计算目录总大小（字节）。

    Args:
        path: 目录路径。

    Returns:
        目录总字节数。
    """
    total = 0
    for dirpath, _, files in os.walk(path):
        for f in files:
            fp = os.path.join(dirpath, f)
            try:
                total += os.path.getsize(fp)
            except OSError:
                pass
    return total
