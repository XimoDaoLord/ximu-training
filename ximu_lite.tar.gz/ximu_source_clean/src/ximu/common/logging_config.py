"""统一日志配置模块。

提供控制台彩色输出、文件按天轮转、敏感信息自动脱敏，
以及支持按模块单独设置日志级别的功能。
"""
from __future__ import annotations

import logging
import os
import re
import sys
import threading
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
from typing import Dict, Optional, Union

_COLORS: Dict[int, str] = {
    logging.DEBUG: "\033[36m",
    logging.INFO: "\033[32m",
    logging.WARNING: "\033[33m",
    logging.ERROR: "\033[31m",
    logging.CRITICAL: "\033[1;41m",
}
_RESET: str = "\033[0m"

_SENSITIVE_PATTERNS: list = [
    re.compile(r'(password\s*[=:]\s*)["\']?[^"\'\s&]+', re.IGNORECASE),
    re.compile(r'(secret\s*[=:]\s*)["\']?[^"\'\s&]+', re.IGNORECASE),
    re.compile(r'(token\s*[=:]\s*)["\']?[^"\'\s&]+', re.IGNORECASE),
    re.compile(r'(api[_-]?key\s*[=:]\s*)["\']?[^"\'\s&]+', re.IGNORECASE),
    re.compile(r'(authorization\s*[=:]\s*Bearer\s+)[^\s&]+', re.IGNORECASE),
]

_setup_lock = threading.Lock()
_setup_done = False

_VALID_LEVELS: Dict[str, int] = {
    "DEBUG": logging.DEBUG,
    "INFO": logging.INFO,
    "WARNING": logging.WARNING,
    "ERROR": logging.ERROR,
    "CRITICAL": logging.CRITICAL,
}


class _SensitiveFilter(logging.Filter):
    """日志脱敏过滤器：将敏感值替换为 ******。"""

    def filter(self, record: logging.LogRecord) -> bool:
        """对日志记录中的敏感信息进行脱敏处理。

        Args:
            record: 日志记录对象。

        Returns:
            始终返回 True，确保日志不被丢弃。
        """
        try:
            msg = record.getMessage()
        except Exception:
            return True
        original_msg = msg
        for pat in _SENSITIVE_PATTERNS:
            msg = pat.sub(r"\1******", msg)
        if msg != original_msg:
            record.msg = msg
            record.args = ()
        return True


class _ColorFormatter(logging.Formatter):
    """控制台彩色格式化器。"""

    def format(self, record: logging.LogRecord) -> str:
        """格式化日志记录，添加 ANSI 颜色代码。

        Args:
            record: 日志记录对象。

        Returns:
            带有颜色代码的格式化字符串。
        """
        original_levelname = record.levelname
        color = _COLORS.get(record.levelno, "")
        if color:
            record.levelname = f"{color}{record.levelname}{_RESET}"
        try:
            return super().format(record)
        finally:
            record.levelname = original_levelname


def _resolve_level(name: Union[str, int, None], default: int = logging.INFO) -> int:
    """将级别字符串解析为数字级别；非法或为空时回退到默认值。

    Args:
        name: 日志级别名称或数值。
        default: 默认级别值。

    Returns:
        解析后的数字日志级别。
    """
    if isinstance(name, int):
        if logging.DEBUG <= name <= logging.CRITICAL:
            return name
        return default
    if not name:
        return default
    return _VALID_LEVELS.get(str(name).strip().upper(), default)


def _build_console_handler(fmt: str, date_fmt: str) -> logging.Handler:
    """构造带脱敏过滤器的控制台彩色处理器。

    Args:
        fmt: 格式字符串。
        date_fmt: 日期格式。

    Returns:
        配置好的控制台日志处理器。
    """
    console = logging.StreamHandler(stream=sys.stderr)
    console.setFormatter(_ColorFormatter(fmt, datefmt=date_fmt))
    console.addFilter(_SensitiveFilter())
    return console


def _build_file_handler(log_dir: str, fmt: str, date_fmt: str) -> Optional[logging.Handler]:
    """构造按天轮转的文件处理器；目录不可写时返回 None。

    Args:
        log_dir: 日志目录路径。
        fmt: 格式字符串。
        date_fmt: 日期格式。

    Returns:
        配置好的文件日志处理器，或目录不可写时为 None。
    """
    try:
        path = Path(log_dir)
        path.mkdir(parents=True, exist_ok=True)
        log_file = path / "ximu.log"
        fh = TimedRotatingFileHandler(
            filename=str(log_file),
            when="midnight",
            interval=1,
            backupCount=30,
            encoding="utf-8",
        )
        fh.setFormatter(logging.Formatter(fmt, datefmt=date_fmt))
        fh.addFilter(_SensitiveFilter())
        try:
            fh.close()
            os.chmod(str(log_file), 0o600)
        except OSError:
            pass
        return fh
    except (OSError, PermissionError) as e:
        logging.getLogger(__name__).warning("日志目录不可写 (%s)，降级为仅控制台输出", log_dir, exc_info=True)
        return None
    except Exception:
        logging.getLogger(__name__).exception("创建文件日志处理器时发生未知错误，降级为仅控制台输出")
        return None


def setup_logging(
    level: Optional[str] = None,
    log_dir: str = "logs",
    module_levels: Optional[Dict[str, str]] = None,
) -> logging.Logger:
    """初始化全局日志配置。

    Args:
        level: 根日志级别，优先使用参数，其次环境变量 XIMU_LOG_LEVEL，默认 INFO。
        log_dir: 日志文件目录，默认 ./logs。
        module_levels: 按模块设置级别，如 {"ximu.core": "DEBUG"}。

    Returns:
        配置好的根 logger。
    """
    global _setup_done
    with _setup_lock:
        root = logging.getLogger()
        if _setup_done:
            lvl = _resolve_level(level or os.environ.get("XIMU_LOG_LEVEL"))
            root.setLevel(lvl)
            _apply_module_levels(module_levels or {})
            return root

        lvl = _resolve_level(level or os.environ.get("XIMU_LOG_LEVEL", "INFO"))
        root.setLevel(lvl)
        root.handlers.clear()

        fmt = "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s"
        date_fmt = "%Y-%m-%d %H:%M:%S"
        root.addHandler(_build_console_handler(fmt, date_fmt))
        fh = _build_file_handler(log_dir, fmt, date_fmt)
        if fh is not None:
            root.addHandler(fh)

        _apply_module_levels(module_levels or {})
        _setup_done = True
        return root


def _apply_module_levels(module_levels: Dict[str, str]) -> None:
    """为指定模块设置独立日志级别；非法级别跳过，不影响其他模块。

    Args:
        module_levels: 模块名称到级别字符串的映射。
    """
    for mod_name, lvl in module_levels.items():
        resolved = _VALID_LEVELS.get(str(lvl).strip().upper())
        if resolved is None:
            logging.getLogger(__name__).warning("模块 %s 的日志级别 %r 非法，已跳过", mod_name, lvl)
            continue
        logging.getLogger(mod_name).setLevel(resolved)


def get_logger(name: str) -> logging.Logger:
    """获取已配置好的 logger；若未初始化则自动调用 setup_logging。

    Args:
        name: 日志器名称。

    Returns:
        对应的 logger 实例。
    """
    if not _setup_done:
        setup_logging()
    return logging.getLogger(name)