# -*- coding: utf-8 -*-
"""环境检测工具

EnvironmentChecker 提供操作系统/Python/依赖/资源/网络检测，
每项返回 {status: pass/warning/fail, details, suggestion}。
"""
from __future__ import annotations

import importlib.metadata
import logging
import platform
import socket
import sys
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# 资源阈值常量
_CPU_WARN_PCT: float = 90.0
_MEM_WARN_PCT: float = 90.0
_DISK_FAIL_PCT: float = 95.0
_DEFAULT_NETWORK_TIMEOUT: float = 3.0
_DEFAULT_NETWORK_HOST: str = "8.8.8.8"
_DEFAULT_NETWORK_PORT: int = 53

try:
    import psutil  # type: ignore
    _HAS_PSUTIL: bool = True
except ImportError:  # pragma: no cover
    _HAS_PSUTIL = False


class EnvironmentChecker:
    """环境检测器。所有 check_* 方法返回统一格式的结果字典。

    该检测器提供对操作系统、Python 版本、依赖包、系统资源及网络连通性的
    综合检测。每个检测项返回一个字典，包含 status、details 和 suggestion 字段。

    典型用法：
        checker = EnvironmentChecker()
        result = checker.check_all()
        if result["overall"] == "fail":
            print("环境不满足要求")
    """

    def check_os(self) -> Dict[str, Any]:
        """检测当前操作系统是否受支持。

        Returns:
            包含 status/details/suggestion 的字典。
        """
        system = platform.system()
        supported = {"Linux", "Darwin", "Windows"}
        if system in supported:
            return {
                "status": "pass",
                "details": f"{system} {platform.release()}",
                "suggestion": "",
            }
        return {
            "status": "warning",
            "details": f"未知系统: {system}",
            "suggestion": "建议在 Linux/Darwin/Windows 上运行",
        }

    def check_python(self, min_version: Tuple[int, int] = (3, 10)) -> Dict[str, Any]:
        """检测 Python 版本是否满足最低要求。

        Args:
            min_version: 期望的最低 Python 版本，默认为 (3, 10)。

        Returns:
            包含 status/details/suggestion 的字典。
        """
        current = sys.version_info[:2]
        if current >= min_version:
            return {
                "status": "pass",
                "details": f"Python {platform.python_version()}",
                "suggestion": "",
            }
        return {
            "status": "fail",
            "details": f"Python {platform.python_version()} < {min_version[0]}.{min_version[1]}",
            "suggestion": f"请升级到 Python {min_version[0]}.{min_version[1]} 或更高",
        }

    def check_dependency(self, package: str,
                         min_version: Optional[str] = None) -> Dict[str, Any]:
        """检查依赖包是否已安装及版本是否满足要求。

        Args:
            package: 包名称。
            min_version: 最低版本要求，None 则跳过版本检查。

        Returns:
            包含 status/details/suggestion 的字典。
        """
        try:
            version = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            return {
                "status": "fail",
                "details": f"包 {package} 未安装",
                "suggestion": f"pip install {package}",
            }
        except Exception as exc:
            logger.warning("检查包 %s 时发生异常: %s", package, exc)
            return {
                "status": "warning",
                "details": f"检查包 {package} 时发生异常: {exc}",
                "suggestion": "请检查 Python 环境完整性",
            }
        if min_version is not None:
            version_check = self._check_version(package, version, min_version)
            if version_check:
                return version_check
        return {
            "status": "pass",
            "details": f"{package}=={version}",
            "suggestion": "",
        }

    def _check_version(self, package: str, version: str,
                       min_version: str) -> Optional[Dict[str, Any]]:
        """检查包版本是否满足最低要求。

        Args:
            package: 包名称。
            version: 当前版本。
            min_version: 最低版本要求。

        Returns:
            如果不满足要求则返回错误字典，否则返回 None。
        """
        try:
            from packaging.version import Version
            if Version(version) < Version(min_version):
                return {
                    "status": "warning",
                    "details": f"{package}=={version} < {min_version}",
                    "suggestion": f"pip install --upgrade {package}",
                }
        except ImportError:
            logger.debug("packaging 不可用，跳过版本比较: %s", package)
        except ValueError:
            logger.debug("版本号解析失败，跳过比较: %s==%s", package, version)
        except Exception as exc:
            logger.debug("版本比较过程中发生未预期异常: %s", exc)
        return None

    def check_resources(self) -> Dict[str, Any]:
        """检查系统资源使用情况（CPU、内存、磁盘）。

        Returns:
            包含 status/details/suggestion 的字典。
        """
        if not _HAS_PSUTIL:
            return {
                "status": "warning",
                "details": "psutil 未安装，无法检测资源",
                "suggestion": "pip install psutil",
            }
        try:
            cpu_pct = psutil.cpu_percent(interval=0.1)
            mem = psutil.virtual_memory()
            disk = psutil.disk_usage("/")
        except Exception as exc:
            logger.warning("获取系统资源信息失败: %s", exc)
            return {
                "status": "warning",
                "details": f"获取系统资源信息失败: {exc}",
                "suggestion": "请检查系统权限或 psutil 状态",
            }
        issues: List[str] = []
        status = "pass"
        if cpu_pct > _CPU_WARN_PCT:
            issues.append(f"CPU 使用率高: {cpu_pct}%")
            status = "warning"
        if mem.percent > _MEM_WARN_PCT:
            issues.append(f"内存使用率高: {mem.percent}%")
            if status == "pass":
                status = "warning"
        if disk.percent > _DISK_FAIL_PCT:
            issues.append(f"磁盘几乎满: {disk.percent}%")
            status = "fail"
        details = f"CPU={cpu_pct}%, 内存={mem.percent}%, 磁盘={disk.percent}%"
        suggestion = "；".join(issues) if issues else ""
        return {"status": status, "details": details, "suggestion": suggestion}

    def check_network(self, host: str = _DEFAULT_NETWORK_HOST,
                      port: int = _DEFAULT_NETWORK_PORT,
                      timeout: float = _DEFAULT_NETWORK_TIMEOUT) -> Dict[str, Any]:
        """检查网络连通性。

        Args:
            host: 目标主机地址，默认为 8.8.8.8。
            port: 目标端口号，默认为 53。
            timeout: 连接超时时间（秒），默认为 3.0。

        Returns:
            包含 status/details/suggestion 的字典。
        """
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(timeout)
                sock.connect((host, port))
            return {
                "status": "pass",
                "details": f"可连接到 {host}:{port}",
                "suggestion": "",
            }
        except socket.timeout:
            return {
                "status": "warning",
                "details": f"连接 {host}:{port} 超时",
                "suggestion": "请检查网络连接或防火墙设置",
            }
        except OSError as exc:
            return {
                "status": "warning",
                "details": f"连接 {host}:{port} 失败: {exc}",
                "suggestion": "请检查网络连接",
            }

    def check_all(self) -> Dict[str, Any]:
        """执行所有环境检测。

        Returns:
            包含各检测项结果及 overall 状态的字典。
        """
        checks = {
            "os": self.check_os(),
            "python": self.check_python(),
            "resources": self.check_resources(),
            "network": self.check_network(),
        }
        statuses = [c["status"] for c in checks.values()]
        if "fail" in statuses:
            overall = "fail"
        elif "warning" in statuses:
            overall = "warning"
        else:
            overall = "pass"
        return {"overall": overall, **checks}
