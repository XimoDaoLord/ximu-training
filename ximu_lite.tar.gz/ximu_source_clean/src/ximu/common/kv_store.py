"""简单内存键值存储

KVStore 支持：
- 基本 CRUD / TTL / 持久化 / 事务 / 命名空间 / 观察者 / 计数器
- 线程安全
"""
from __future__ import annotations

import fnmatch
import logging
import json
import os
import threading
import time
from contextlib import contextmanager
from typing import Any, Callable, Dict, Iterator, List, Optional, Tuple

logger = logging.getLogger(__name__)


class KVStore:
    """线程安全的内存键值存储。

    支持 TTL 过期、键前缀命名空间、变化监听、持久化和简单事务。
    """

    def __init__(self, cleanup_interval: float = 60.0) -> None:
        """初始化KV存储

        Args:
            cleanup_interval: 后台清扫间隔（秒），默认为60.0，0或负数表示禁用
        """
        self._data: Dict[str, Tuple[Any, Optional[float]]] = {}
        self._lock = threading.RLock()
        self._watchers: Dict[str, List[Callable[[str, Any], None]]] = {}
        self._prefix_watchers: List[Tuple[str, Callable[[str, Any], None]]] = []
        # C1: TTL 过期键后台清扫
        self._cleanup_thread: Optional[threading.Thread] = None
        self._cleanup_stop = threading.Event()
        if cleanup_interval > 0:
            self._start_cleanup_thread(cleanup_interval)

    def _start_cleanup_thread(self, interval: float) -> None:
        """启动后台线程定期清扫过期键。"""
        def _loop() -> None:
            """后台清扫循环"""
            while not self._cleanup_stop.wait(interval):
                try:
                    self._sweep_expired()
                except Exception:
                    logger.debug("KV过期键清扫异常", exc_info=True)

        self._cleanup_thread = threading.Thread(target=_loop, daemon=True)
        self._cleanup_thread.start()

    def _sweep_expired(self) -> int:
        """持锁扫一遍，删除所有已过期键。返回删除数量。"""
        now = time.monotonic()
        expired: List[str] = []
        with self._lock:
            for key, (_, expire_at) in self._data.items():
                if expire_at is not None and now > expire_at:
                    expired.append(key)
            for key in expired:
                del self._data[key]
        if expired:
            logger.debug("KV清扫过期键 %d 个", len(expired))
        return len(expired)

    def close(self) -> None:
        """停止后台清扫线程。"""
        self._cleanup_stop.set()
        if self._cleanup_thread:
            self._cleanup_thread.join(timeout=2.0)
            self._cleanup_thread = None

    def get(self, key: str, default: Any = None) -> Any:
        """获取键值；过期键视同不存在并返回 default。

        Args:
            key: 键名
            default: 键不存在或已过期时的默认值

        Returns:
            键对应的值
        """
        with self._lock:
            entry = self._data.get(key)
            if entry is None:
                return default
            value, expire_at = entry
            if expire_at is not None and time.monotonic() > expire_at:
                del self._data[key]
                return default
            return value

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """设置键值，可选 TTL 秒数。写入后通知 watcher。

        Args:
            key: 键名
            value: 要存储的值
            ttl: 过期时间（秒），None 表示永不过期
        """
        expire_at = time.monotonic() + ttl if ttl else None
        with self._lock:
            self._data[key] = (value, expire_at)
        self._notify(key, value)

    def delete(self, key: str) -> bool:
        """删除键，返回是否原本存在。

        Args:
            key: 要删除的键名

        Returns:
            是否存在并被成功删除
        """
        with self._lock:
            existed = key in self._data
            self._data.pop(key, None)
        if existed:
            self._notify(key, None)
        return existed

    def exists(self, key: str) -> bool:
        """判断 key 是否存在（含未过期）。整次检查持锁原子完成。

        Args:
            key: 键名

        Returns:
            是否存在且未过期
        """
        with self._lock:
            entry = self._data.get(key)
            if entry is None:
                return False
            value, expire_at = entry
            if expire_at is not None and time.monotonic() > expire_at:
                del self._data[key]
                return False
            return True

    def atomic_set_if_absent(self, key: str, value: Any,
                             ttl: Optional[float] = None) -> bool:
        """原子 set-if-absent：key 不存在（或已过期）才写入。返回是否写入成功。

        Args:
            key: 键名
            value: 要存储的值
            ttl: 过期时间（秒）

        Returns:
            写入成功返回 True，已存在且未过期返回 False
        """
        expire_at = time.monotonic() + ttl if ttl else None
        with self._lock:
            entry = self._data.get(key)
            if entry is not None:
                _, old_exp = entry
                if old_exp is None or time.monotonic() <= old_exp:
                    return False
                # 已过期，视同不存在，允许覆盖
            self._data[key] = (value, expire_at)
        self._notify(key, value)
        return True

    def keys(self, pattern: Optional[str] = None) -> List[str]:
        """列出所有键，可按 fnmatch 通配符过滤。

        Args:
            pattern: fnmatch 格式通配符，None 表示不过滤

        Returns:
            键列表（已排序）
        """
        with self._lock:
            result = list(self._data.keys())
        if pattern:
            result = [k for k in result if fnmatch.fnmatch(k, pattern)]
        return sorted(result)

    def keys_paginated(self, pattern: Optional[str] = None,
                        cursor: str = "", page_size: int = 200) -> Tuple[Optional[str], List[str]]:
        """C2: keys() 游标分页。

        Args:
            pattern: fnmatch 通配符过滤
            cursor: 分页游标，首次调用传空串
            page_size: 每页大小

        Returns:
            (next_cursor, keys)，next_cursor 为 None 表示已到末尾
        """
        all_keys = self.keys(pattern)
        if not cursor:
            start = 0
        else:
            try:
                start = int(cursor)
            except ValueError:
                start = 0
        end = start + page_size
        page_keys = all_keys[start:end]
        next_cursor = str(end) if end < len(all_keys) else None
        return next_cursor, page_keys

    def values(self) -> List[Any]:
        """返回所有未过期键的值列表。

        Returns:
            值列表
        """
        return [self.get(k) for k in self.keys()]

    def items(self) -> List[Tuple[str, Any]]:
        """返回所有未过期键的 (键, 值) 列表。

        Returns:
            (键, 值) 元组列表
        """
        return [(k, self.get(k)) for k in self.keys()]

    def clear(self) -> None:
        """清空所有键值（不通知 watcher）。"""
        with self._lock:
            self._data.clear()

    def size(self) -> int:
        """返回当前键总数（含未过期键）。

        Returns:
            键数量
        """
        with self._lock:
            return len(self._data)

    def ttl(self, key: str) -> Optional[float]:
        """返回键剩余 TTL 秒数。None 表示永不过期或键不存在。

        Args:
            key: 键名

        Returns:
            剩余秒数或 None
        """
        with self._lock:
            entry = self._data.get(key)
            if entry is None:
                return None
            _, expire_at = entry
            if expire_at is None:
                return None
            return max(0.0, expire_at - time.monotonic())

    def persist(self, key: str) -> bool:
        """移除键的过期时间。

        Args:
            key: 键名

        Returns:
            键是否存在
        """
        with self._lock:
            entry = self._data.get(key)
            if entry is None:
                return False
            value, _ = entry
            self._data[key] = (value, None)
            return True

    def save(self, filepath: str) -> str:
        """持久化到 JSON 文件。先写临时文件再原子 rename，避免崩溃损坏。

        Args:
            filepath: 目标文件路径

        Returns:
            实际写入的绝对路径
        """
        with self._lock:
            now = time.monotonic()
            saved_at = time.time()
            serializable = {
                "_saved_at": saved_at,
                "items": {
                    k: {
                        "value": v,
                        "remaining_ttl": (exp - now) if exp is not None else None,
                    }
                    for k, (v, exp) in self._data.items()
                },
            }
        abs_path = os.path.abspath(filepath)
        parent = os.path.dirname(abs_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        tmp_path = abs_path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(serializable, f, ensure_ascii=False, indent=2, default=str)
        os.replace(tmp_path, abs_path)
        return abs_path

    def load(self, filepath: str) -> int:
        """从 JSON 文件恢复数据，覆盖当前存储。

        Args:
            filepath: 源文件路径

        Returns:
            恢复的键数量

        Raises:
            FileNotFoundError: 文件不存在时
        """
        if not os.path.isfile(filepath):
            raise FileNotFoundError(f"持久化文件不存在: {filepath}")
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        now = time.monotonic()
        restored = 0
        with self._lock:
            self._data.clear()
            for key, item in data.get("items", {}).items():
                remaining = item.get("remaining_ttl")
                if remaining is None or remaining > 0:
                    ttl = remaining if remaining is not None else None
                    self._data[key] = (item["value"], now + ttl if ttl else None)
                    restored += 1
        return restored

    def watch(self, key: str, callback: Callable[[str, Any], None]) -> None:
        """注册单个键的变更监听。

        Args:
            key: 要监听的键名，支持 * 前缀通配
            callback: 回调函数，参数为 (key, new_value)
        """
        if key.endswith("*"):
            self._prefix_watchers.append((key[:-1], callback))
        else:
            self._watchers.setdefault(key, []).append(callback)

    def unwatch(self, key: str, callback: Callable[[str, Any], None]) -> None:
        """注销单个键的变更监听。

        Args:
            key: 要取消监听的键名
            callback: 要取消的回调函数
        """
        if key.endswith("*"):
            prefix = key[:-1]
            self._prefix_watchers = [
                (p, cb) for p, cb in self._prefix_watchers if p != prefix or cb != callback
            ]
        else:
            if key in self._watchers:
                self._watchers[key] = [
                    cb for cb in self._watchers[key] if cb != callback
                ]
                if not self._watchers[key]:
                    del self._watchers[key]

    def _notify(self, key: str, value: Any) -> None:
        """通知相关 watcher 键值已变更。

        Args:
            key: 变更的键名
            value: 新值（删除时为 None）
        """
        for cb in self._watchers.get(key, []):
            try:
                cb(key, value)
            except Exception:
                logger.debug("KV watcher 回调异常", exc_info=True)
        for prefix, cb in self._prefix_watchers:
            if key.startswith(prefix):
                try:
                    cb(key, value)
                except Exception:
                    logger.debug("KV prefix watcher 回调异常", exc_info=True)

    @contextmanager
    def transaction(self) -> Iterator[None]:
        """简单事务上下文管理器：批量操作后可手动提交或回滚。

        用法::
            with store.transaction() as txn:
                txn.set('a', 1)
                txn.set('b', 2)
                # txn.rollback()  # 取消提交

        Yields:
            Transaction 对象
        """
        txn = self._Transaction(self)
        try:
            yield txn
            txn.commit()
        except Exception:
            txn.rollback()
            raise

    class _Transaction:
        """事务内部对象，暂存操作并在 commit 时批量写入。"""

        def __init__(self, store: KVStore) -> None:
            self._store = store
            self._ops: List[Tuple[str, Any, Optional[float]]] = []
            self._deleted: set = set()

        def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
            """暂存 set 操作。

            Args:
                key: 键名
                value: 值
                ttl: 过期时间
            """
            expire_at = time.monotonic() + ttl if ttl else None
            self._ops.append((key, value, expire_at))
            self._deleted.discard(key)

        def delete(self, key: str) -> None:
            """暂存 delete 操作。

            Args:
                key: 要删除的键名
            """
            self._deleted.add(key)

        def commit(self) -> None:
            """批量提交暂存操作。"""
            with self._store._lock:
                for key, value, expire_at in self._ops:
                    self._store._data[key] = (value, expire_at)
                for key in self._deleted:
                    self._store._data.pop(key, None)
            for key in self._deleted:
                self._store._notify(key, None)
            for key, value, _ in self._ops:
                self._store._notify(key, value)

        def rollback(self) -> None:
            """放弃暂存操作。"""
            self._ops.clear()
            self._deleted.clear()
