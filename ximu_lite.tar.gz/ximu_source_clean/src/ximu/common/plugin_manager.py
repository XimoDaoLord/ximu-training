# -*- coding: utf-8 -*-
"""简单插件管理器

PluginManager 单例：注册/加载/卸载/发现插件。
插件生命周期：init / start / stop / destroy。
支持依赖排序和错误隔离。
"""
from __future__ import annotations

import inspect
import logging
from typing import Callable, Dict, List, Optional, Set, Type

logger = logging.getLogger(__name__)


class BasePlugin:
    """插件基类。子类应重写生命周期方法。

    Attributes:
        name: 插件名称。
        version: 插件版本号。
        description: 插件描述。
        dependencies: 依赖的插件名称列表。
        is_loaded: 插件是否已加载。
    """

    name: str = "base"
    version: str = "1.0.0"
    description: str = ""
    dependencies: List[str] = []

    def __init__(self) -> None:
        """初始化插件实例。"""
        self.is_loaded: bool = False

    def init(self) -> None:
        """初始化插件。子类可重写此方法以执行初始化操作。"""
        pass

    def start(self) -> None:
        """启动插件。子类可重写此方法以执行启动操作。"""
        pass

    def stop(self) -> None:
        """停止插件。子类可重写此方法以执行停止操作。"""
        pass

    def destroy(self) -> None:
        """销毁插件，释放资源。子类可重写此方法以执行资源清理操作。"""
        pass


def plugin(
    name: str,
    version: str = "1.0.0",
    description: str = "",
    dependencies: Optional[List[str]] = None,
) -> Callable[[Type[BasePlugin]], Type[BasePlugin]]:
    """类装饰器：标记类为插件并注册元信息。

    Args:
        name: 插件名称。
        version: 插件版本号，默认为 "1.0.0"。
        description: 插件描述，默认为空字符串。
        dependencies: 依赖的插件名称列表，默认为 None。

    Returns:
        装饰器函数。

    Raises:
        ValueError: 如果插件名称为空。
    """
    def decorator(cls: Type[BasePlugin]) -> Type[BasePlugin]:
        """装饰器内部实现。

        Args:
            cls: 被装饰的类。

        Returns:
            装饰后的类。
        """
        if not name or not isinstance(name, str):
            raise ValueError("插件名称不能为空")
        cls.name = name
        cls.version = version
        cls.description = description
        cls.dependencies = list(dependencies) if dependencies else []
        manager = PluginManager.get_instance()
        manager.register(cls)
        return cls
    return decorator


class PluginManager:
    """插件管理器单例。

    负责管理插件的注册、加载、卸载和自动发现。

    Attributes:
        _instance: 单例实例。
        _registered: 已注册的插件类映射。
        _instances: 已加载的插件实例映射。
        _errors: 插件错误信息映射。
        _loading: 正在加载中的插件名集合。
    """

    _instance: Optional[PluginManager] = None

    def __init__(self) -> None:
        """初始化插件管理器。

        注意：应使用 get_instance() 方法获取实例。
        """
        self._registered: Dict[str, Type[BasePlugin]] = {}
        self._instances: Dict[str, BasePlugin] = {}
        self._errors: Dict[str, str] = {}
        self._loading: Set[str] = set()

    @classmethod
    def get_instance(cls) -> PluginManager:
        """获取插件管理器单例实例。

        Returns:
            插件管理器单例实例。
        """
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls) -> None:
        """重置单例实例（主要用于测试）。

        注意：生产环境中不应随意调用此方法。
        """
        cls._instance = None

    def register(self, plugin_class: Type[BasePlugin]) -> None:
        """注册插件类。

        Args:
            plugin_class: 插件类。

        Raises:
            TypeError: 如果 plugin_class 不是 BasePlugin 的子类。
            ValueError: 如果插件名称为空或已注册。
        """
        if not inspect.isclass(plugin_class):
            raise TypeError(f"期望类对象，得到 {type(plugin_class).__name__}")
        if not issubclass(plugin_class, BasePlugin):
            raise TypeError(f"{plugin_class.__name__} 必须是 BasePlugin 的子类")
        plugin_name = getattr(plugin_class, 'name', None)
        if not plugin_name:
            raise ValueError(f"插件类 {plugin_class.__name__} 缺少有效的 name 属性")
        self._registered[plugin_name] = plugin_class
        logger.debug("插件 %s 已注册", plugin_name)

    def list_plugins(self) -> List[str]:
        """列出所有已注册插件名。

        Returns:
            排序后的插件名称列表。
        """
        return sorted(self._registered.keys())

    def is_loaded(self, name: str) -> bool:
        """检查插件是否已加载。

        Args:
            name: 插件名称。

        Returns:
            如果插件已加载且 is_loaded 为 True 则返回 True。
        """
        inst = self._instances.get(name)
        return inst is not None and inst.is_loaded

    def get(self, name: str) -> Optional[BasePlugin]:
        """获取插件实例。

        Args:
            name: 插件名称。

        Returns:
            插件实例，如果不存在则返回 None。
        """
        return self._instances.get(name)

    def load(self, name: str) -> bool:
        """加载插件（按依赖顺序）。

        递归加载插件依赖，检测循环依赖。

        Args:
            name: 插件名称。

        Returns:
            如果加载成功返回 True，否则返回 False。
        """
        if name not in self._registered:
            self._errors[name] = "未注册的插件"
            logger.warning("尝试加载未注册的插件: %s", name)
            return False
        if self.is_loaded(name):
            logger.debug("插件 %s 已加载，跳过", name)
            return True
        if name in self._loading:
            chain = " -> ".join(sorted(self._loading | {name}))
            self._errors[name] = f"检测到循环依赖: {chain}"
            logger.error("插件循环依赖: %s", chain)
            return False
        self._loading.add(name)
        try:
            plugin_cls = self._registered[name]
            for dep in plugin_cls.dependencies:
                if not self.is_loaded(dep):
                    if not self.load(dep):
                        dep_err = self._errors.get(dep, "")
                        if "循环依赖" in dep_err:
                            self._errors[name] = dep_err
                        else:
                            self._errors[name] = f"依赖 {dep} 加载失败"
                        return False
            try:
                instance = plugin_cls()
                instance.init()
                instance.start()
                instance.is_loaded = True
                self._instances[name] = instance
                logger.info("插件 %s 加载成功", name)
                return True
            except Exception as exc:
                self._errors[name] = str(exc)
                logger.error("插件 %s 加载失败: %s", name, exc, exc_info=True)
                return False
        finally:
            self._loading.discard(name)

    def unload(self, name: str) -> bool:
        """卸载插件。

        调用插件的 stop 和 destroy 方法。

        Args:
            name: 插件名称。

        Returns:
            如果卸载成功返回 True，否则返回 False。
        """
        inst = self._instances.get(name)
        if inst is None:
            logger.debug("插件 %s 未加载，无法卸载", name)
            return False
        try:
            inst.stop()
            inst.destroy()
            inst.is_loaded = False
            del self._instances[name]
            logger.info("插件 %s 已卸载", name)
            return True
        except Exception as exc:
            self._errors[name] = str(exc)
            logger.error("插件 %s 卸载失败: %s", name, exc, exc_info=True)
            return False

    def get_errors(self) -> Dict[str, str]:
        """获取所有插件错误信息。

        Returns:
            插件名称到错误信息的映射。
        """
        return dict(self._errors)

    def clear_errors(self) -> None:
        """清空所有插件错误信息。"""
        self._errors.clear()

    def load_all(self) -> List[str]:
        """加载所有已注册的插件。

        Returns:
            加载失败的插件名称列表。
        """
        failed: List[str] = []
        for name in self.list_plugins():
            if not self.load(name):
                failed.append(name)
        return failed

    def unload_all(self) -> List[str]:
        """卸载所有已加载的插件。

        Returns:
            卸载失败的插件名称列表。
        """
        failed: List[str] = []
        for name in list(self._instances.keys()):
            if not self.unload(name):
                failed.append(name)
        return failed
