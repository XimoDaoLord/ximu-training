"""通用装饰器集合。

提供 @retry（指数退避重试+抖动）、@timeout（超时中断）和
@cache（TTL+LRU 结果缓存）三个常用装饰器。
"""
from __future__ import annotations

import functools
import random
import threading
import time
from collections import OrderedDict
from typing import Any, Callable, Dict, Optional, Tuple, TypeVar

F = TypeVar("F", bound=Callable[..., Any])


def retry(
    max_retries: int = 3,
    backoff_factor: float = 2.0,
    exceptions: Tuple[type, ...] = (Exception,),
    initial_delay: float = 1.0,
    max_delay: float = 60.0,
    on_retry: Optional[Callable[[Exception, int], None]] = None,
) -> Callable[[F], F]:
    """自动重试装饰器（指数退避 + 抖动）。

    Args:
        max_retries: 最大重试次数（不含首次调用）。
        backoff_factor: 退避倍数。
        exceptions: 触发重试的异常类型元组。
        initial_delay: 首次重试前的等待秒数。
        max_delay: 单次等待上限秒数。
        on_retry: 每次重试时的回调，参数为 (异常, 当前重试次数)。

    Returns:
        装饰后的函数，保持原始签名不变。

    Raises:
        ValueError: 参数不合法时抛出。
        最后一次重试失败后，抛出捕获到的异常。

    Examples:
        >>> @retry(max_retries=5, backoff_factor=2.0, exceptions=(ConnectionError,))
        ... def fetch_data():
        ...     ...
    """
    if max_retries < 0:
        raise ValueError("max_retries must be non-negative")
    if backoff_factor <= 0:
        raise ValueError("backoff_factor must be positive")
    if initial_delay < 0:
        raise ValueError("initial_delay must be non-negative")
    if max_delay < 0:
        raise ValueError("max_delay must be non-negative")

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            delay = initial_delay
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as exc:
                    if attempt >= max_retries:
                        raise
                    if on_retry is not None:
                        on_retry(exc, attempt + 1)
                    jitter = random.uniform(0, delay * 0.25)
                    time.sleep(min(delay + jitter, max_delay))
                    delay *= backoff_factor
            raise RuntimeError("Retry loop exited without returning or raising")
        return wrapper  # type: ignore[return-value]
    return decorator


def timeout(
    seconds: float = 30.0,
    callback: Optional[Callable[[], None]] = None,
) -> Callable[[F], F]:
    """函数超时装饰器。超时后抛出 TimeoutError。

    注意: 由于 Python 无法真正终止线程，超时后线程仍在后台运行，
    但主线程会继续执行后续代码。装饰器本身是线程安全的。

    Args:
        seconds: 超时秒数，必须为正数。
        callback: 超时触发时的回调函数（可选）。

    Returns:
        装饰后的函数，保持原始签名不变。

    Raises:
        TimeoutError: 当函数执行时间超过 seconds 时抛出。
        ValueError: 当 seconds <= 0 时抛出。

    Examples:
        >>> @timeout(seconds=5)
        ... def long_task():
        ...     ...
    """
    if seconds <= 0:
        raise ValueError("seconds must be positive")

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            result_container: Dict[str, Any] = {}

            def runner() -> None:
                try:
                    result_container["value"] = func(*args, **kwargs)
                except BaseException as exc:  # noqa: BLE001
                    result_container["error"] = exc

            thread = threading.Thread(target=runner, daemon=True)
            thread.start()
            thread.join(timeout=seconds)
            if thread.is_alive():
                if callback is not None:
                    callback()
                raise TimeoutError(f"函数 {func.__name__} 执行超过 {seconds} 秒")
            if "error" in result_container:
                raise result_container["error"]
            return result_container.get("value")
        return wrapper  # type: ignore[return-value]
    return decorator


def cache(ttl: float = 300.0, max_size: int = 1000) -> Callable[[F], F]:
    """函数结果缓存装饰器（TTL 过期 + LRU 淘汰）。

    包装后函数自动获得 cache_clear() 和 cache_info() 方法。

    Args:
        ttl: 缓存生存时间（秒），必须为非负数。
        max_size: 最大缓存条目数，必须为正整数，超出后按 LRU 淘汰。

    Returns:
        装饰后的函数，保持原始签名不变，并附加 cache_clear 和 cache_info 方法。

    Raises:
        ValueError: 当 ttl < 0 或 max_size <= 0 时抛出。

    Examples:
        >>> @cache(ttl=60, max_size=100)
        ... def expensive_computation(x: int) -> int:
        ...     ...
    """
    if ttl < 0:
        raise ValueError("ttl must be non-negative")
    if max_size <= 0:
        raise ValueError("max_size must be positive")

    def decorator(func: F) -> F:
        store: OrderedDict = OrderedDict()
        lock = threading.Lock()
        stats: Dict[str, int] = {"hits": 0, "misses": 0}

        def _make_key(args: Any, kwargs: Any) -> tuple:
            return (args, tuple(sorted(kwargs.items())))

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            key = _make_key(args, kwargs)
            now = time.monotonic()
            with lock:
                if key in store:
                    expire_at, value = store[key]
                    if now < expire_at:
                        store.move_to_end(key)
                        stats["hits"] += 1
                        return value
                    store.pop(key, None)
                stats["misses"] += 1
            result = func(*args, **kwargs)
            with lock:
                store[key] = (now + ttl, result)
                store.move_to_end(key)
                while len(store) > max_size:
                    store.popitem(last=False)
            return result

        def cache_clear() -> None:
            """清空缓存并重置命中统计。"""
            with lock:
                store.clear()
                stats["hits"] = 0
                stats["misses"] = 0

        def cache_info() -> Dict[str, Any]:
            """返回当前缓存状态：条目数、上限、命中/未命中次数、TTL。

            Returns:
                包含 size/max_size/hits/misses/ttl 的字典。
            """
            with lock:
                return {
                    "size": len(store),
                    "max_size": max_size,
                    "hits": stats["hits"],
                    "misses": stats["misses"],
                    "ttl": ttl,
                }

        wrapper.cache_clear = cache_clear  # type: ignore[attr-defined]
        wrapper.cache_info = cache_info  # type: ignore[attr-defined]
        return wrapper  # type: ignore[return-value]
    return decorator