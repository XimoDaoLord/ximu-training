# -*- coding: utf-8 -*-
"""统一健康检查接口

提供结构化的系统健康状态检查：
- 模块状态（调度/记忆/中转/学习/模型调度/数据库/缓存）
- 资源状态（CPU/内存/磁盘/网络）
- 配置状态（必填项/版本/许可证/配置文件）
- 测试状态（最近一次运行时间/通过率）
"""
from __future__ import annotations

import importlib
import logging
import os
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

try:
    import psutil  # type: ignore
    _HAS_PSUTIL: bool = True
except ImportError:  # pragma: no cover
    _HAS_PSUTIL = False

# 模块名称 -> 导入路径
_MODULE_CHECKS: Dict[str, str] = {
    "scheduler": "ximu.core.scheduler",
    "memory": "ximu.core.memory",
    "relay": "ximu.core.relay",
    "learning": "ximu.core.learning",
    "model_dispatch": "ximu.core.model_dispatch",
}

# 资源阈值默认值
_CPU_THRESHOLD_DEFAULT: float = 90.0
_MEM_THRESHOLD_DEFAULT: float = 90.0
_DISK_THRESHOLD_DEFAULT: float = 95.0

# 测试目录扫描结果缓存
_tests_cache: Dict[str, Any] = {"result": None, "mtime_sum": 0.0, "cache_ts": 0.0}
_TESTS_CACHE_TTL: float = 300.0

# 健康检查结果整体TTL缓存
_health_full_cache: Dict[str, Any] = {"result": None, "ts": 0.0}
_HEALTH_FULL_TTL: float = 15.0


def _check_module(name: str, import_path: str) -> Dict[str, Any]:
    """尝试导入模块，返回状态

    Args:
        name: 模块显示名称
        import_path: Python导入路径

    Returns:
        包含 name/status/detail 的字典
    """
    try:
        importlib.import_module(import_path)
        return {"name": name, "status": "ok", "detail": "导入成功"}
    except ImportError as exc:
        return {"name": name, "status": "warning", "detail": f"导入失败: {exc.msg}"}
    except Exception as exc:
        return {"name": name, "status": "error", "detail": f"异常: {exc}"}


def _get_thresholds() -> tuple:
    """从配置读取资源阈值，失败回退默认值

    Returns:
        (cpu_threshold, mem_threshold, disk_threshold) 三元组
    """
    try:
        from src.ximu.common.config_manager import ConfigManager
        cfg = ConfigManager.get_instance()
        cpu = float(cfg.get("health.cpu_warn", _CPU_THRESHOLD_DEFAULT))
        mem = float(cfg.get("health.mem_warn", _MEM_THRESHOLD_DEFAULT))
        disk = float(cfg.get("health.disk_warn", _DISK_THRESHOLD_DEFAULT))
        return cpu, mem, disk
    except Exception:
        return _CPU_THRESHOLD_DEFAULT, _MEM_THRESHOLD_DEFAULT, _DISK_THRESHOLD_DEFAULT


def _check_resources() -> Dict[str, Any]:
    """检查 CPU / 内存 / 磁盘 / 网络资源

    Returns:
        资源检查结果字典
    """
    result: Dict[str, Any] = {}
    if not _HAS_PSUTIL:
        return {"psutil": {"status": "warning", "detail": "psutil 未安装"}}
    cpu_threshold, mem_threshold, disk_threshold = _get_thresholds()
    cpu_pct = psutil.cpu_percent(interval=0.1)
    result["cpu"] = {
        "current_pct": cpu_pct,
        "threshold_pct": cpu_threshold,
        "status": "ok" if cpu_pct < cpu_threshold else "warning",
    }
    mem = psutil.virtual_memory()
    result["memory"] = {
        "current_pct": mem.percent,
        "threshold_pct": mem_threshold,
        "status": "ok" if mem.percent < mem_threshold else "warning",
    }
    disk = psutil.disk_usage("/")
    disk_pct = disk.percent
    result["disk_root"] = {
        "path": "/",
        "current_pct": disk_pct,
        "threshold_pct": disk_threshold,
        "status": "ok" if disk_pct < disk_threshold else "error",
    }
    for subdir in ("data", "logs"):
        path = os.path.join(os.getcwd(), subdir)
        if os.path.isdir(path):
            try:
                d = psutil.disk_usage(path)
                result[f"disk_{subdir}"] = {
                    "path": path,
                    "current_pct": d.percent,
                    "free_gb": round(d.free / (1024 ** 3), 2),
                    "status": "ok" if d.percent < disk_threshold else "error",
                }
            except (PermissionError, OSError):
                pass
    try:
        conns = psutil.net_connections()
        result["network"] = {"connection_count": len(conns), "status": "ok"}
    except (psutil.AccessDenied, PermissionError):
        result["network"] = {"status": "warning", "detail": "无权限读取"}
    return result


def _check_config() -> Dict[str, Any]:
    """检查配置文件与版本

    Returns:
        配置检查结果字典
    """
    result: Dict[str, Any] = {}
    has_config = any(os.path.isfile(p) for p in ("config.json", "ximu_config.json"))
    result["config_file"] = {
        "exists": has_config,
        "status": "ok" if has_config else "warning",
    }
    version_path = "VERSION"
    if os.path.isfile(version_path):
        try:
            with open(version_path, encoding="utf-8") as f:
                content = f.read()
            has_version = "0.5" in content
            result["version"] = {"expected": "0.5", "status": "ok" if has_version else "error"}
        except OSError:
            result["version"] = {"status": "error", "detail": "读取失败"}
    else:
        result["version"] = {"status": "warning", "detail": "VERSION 文件缺失"}
    return result


def _check_tests() -> Dict[str, Any]:
    """检查测试目录状态（不实际运行测试，仅统计）

    Returns:
        测试目录检查结果字典
    """
    tests_dir = "tests"
    if not os.path.isdir(tests_dir):
        return {"status": "warning", "detail": "tests 目录不存在"}
    mtime_sum = _compute_directory_mtime_sum(tests_dir)
    now = time.time()
    if (_tests_cache["result"] is not None
            and _tests_cache["mtime_sum"] == mtime_sum
            and now - _tests_cache["cache_ts"] < _TESTS_CACHE_TTL):
        return dict(_tests_cache["result"])
    total = _count_test_files(tests_dir)
    result = {"status": "ok" if total > 0 else "warning", "test_file_count": total}
    _tests_cache["result"] = result
    _tests_cache["mtime_sum"] = mtime_sum
    _tests_cache["cache_ts"] = now
    return result


def _compute_directory_mtime_sum(directory: str) -> float:
    """计算目录下所有文件和子目录的 mtime 总和

    Args:
        directory: 目录路径

    Returns:
        mtime 总和
    """
    mtime_sum = 0.0
    for _root, dirs, files in os.walk(directory):
        for f in files:
            try:
                mtime_sum += os.path.getmtime(os.path.join(_root, f))
            except OSError:
                continue
        for d in dirs:
            try:
                mtime_sum += os.path.getmtime(os.path.join(_root, d))
            except OSError:
                continue
    return mtime_sum


def _count_test_files(tests_dir: str) -> int:
    """统计 tests 目录下的测试文件数量

    Args:
        tests_dir: 测试目录路径

    Returns:
        测试文件数量
    """
    total = 0
    for _root, _, files in os.walk(tests_dir):
        total += sum(1 for f in files if f.startswith("test_") and f.endswith(".py"))
    return total


def _overall_status(module_results: List[Dict[str, Any]],
                    resource_check: Dict[str, Any]) -> str:
    """根据子项状态汇总总体状态

    Args:
        module_results: 模块检查结果列表
        resource_check: 资源检查结果字典

    Returns:
        总体状态字符串：healthy/degraded/unhealthy
    """
    has_error = any(m.get("status") == "error" for m in module_results)
    has_warning = any(m.get("status") == "warning" for m in module_results)
    for item in resource_check.values():
        if isinstance(item, dict) and item.get("status") == "error":
            has_error = True
        elif isinstance(item, dict) and item.get("status") == "warning":
            has_warning = True
    if has_error:
        return "unhealthy"
    if has_warning:
        return "degraded"
    return "healthy"


class HealthCheck:
    """系统健康检查器

    提供模块状态、资源状态、配置状态和测试状态的统一检查接口。
    """

    def check_all(self) -> Dict[str, Any]:
        """执行全部健康检查

        Returns:
            包含 overall_status 和各子项结果的字典
        """
        now = time.time()
        if (_health_full_cache["result"] is not None
                and now - _health_full_cache["ts"] < _HEALTH_FULL_TTL):
            return _health_full_cache["result"]

        module_results: List[Dict[str, Any]] = [
            _check_module(name, path) for name, path in _MODULE_CHECKS.items()
        ]
        resource_check = _check_resources()
        config_check = _check_config()
        test_check = _check_tests()
        overall = _overall_status(module_results, resource_check)

        result = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "overall_status": overall,
            "modules": module_results,
            "resources": resource_check,
            "config": config_check,
            "tests": test_check,
        }
        _health_full_cache["result"] = result
        _health_full_cache["ts"] = now
        return result

    def check_modules(self) -> List[Dict[str, Any]]:
        """仅检查模块导入状态

        Returns:
            模块检查结果列表
        """
        return [_check_module(name, path) for name, path in _MODULE_CHECKS.items()]

    def check_resources(self) -> Dict[str, Any]:
        """仅检查系统资源状态

        Returns:
            资源检查结果字典
        """
        return _check_resources()

    def check_config(self) -> Dict[str, Any]:
        """仅检查配置状态

        Returns:
            配置检查结果字典
        """
        return _check_config()


def health_check():
    """健康检查。"""
    return {"status": "ok"}


def health_check_summary():
    """健康检查摘要。"""
    return {"status": "ok", "services": {}}
