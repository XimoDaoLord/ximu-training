"""
用户数据库管理模块。

提供基于 SQLAlchemy 和 bcrypt 的用户注册、查询及登录记录功能。
"""
from typing import Optional, Dict, Any, List, Union
import bcrypt
import logging
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, DateTime, UniqueConstraint, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.exc import SQLAlchemyError

Base = declarative_base()
logger = logging.getLogger(__name__)


class User(Base):
    """代表用户数据库表的 SQLAlchemy 模型。"""

    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(64), unique=True, nullable=False)
    password_hash = Column(String(256), nullable=False)
    email = Column(String(128), unique=True, nullable=False)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint('username', 'email'),
        Index('idx_username', 'username'),
        Index('idx_email', 'email'),
    )

    def __init__(
        self,
        username: str,
        password_hash: str,
        email: str,
        created_at: Optional[datetime] = None,
    ) -> None:
        """初始化 User 实例。

        Args:
            username: 用户名。
            password_hash: 密码哈希值。
            email: 邮箱地址。
            created_at: 创建时间，默认为当前 UTC 时间。
        """
        self.username = username
        self.password_hash = password_hash
        self.email = email
        self.created_at = created_at or datetime.utcnow()

    def set_password(self, password: str) -> bool:
        """使用 bcrypt 生成并设置密码哈希。

        Args:
            password: 明文密码。

        Returns:
            始终返回 True。

        Raises:
            TypeError: 如果 password 不是字符串类型。
            ValueError: 如果密码为空字符串。
        """
        if not isinstance(password, str):
            raise TypeError("password 必须是字符串类型")
        if not password:
            raise ValueError("密码不能为空")
        
        salt = bcrypt.gensalt()
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        self.password_hash = hashed.decode('utf-8')
        return True

    def verify_password(self, password: str) -> bool:
        """验证密码是否匹配。

        Args:
            password: 待验证的明文密码。

        Returns:
            验证成功返回 True，否则返回 False。
        """
        if not isinstance(password, str):
            logger.warning("验证失败：password 必须是字符串类型")
            return False
        if not password:
            logger.warning("验证失败：密码不能为空")
            return False

        try:
            return bcrypt.checkpw(
                password.encode('utf-8'),
                self.password_hash.encode('utf-8')
            )
        except (ValueError, AttributeError, TypeError) as e:
            logger.warning(f"密码验证异常: {e}")
            return False


class UserDB:
    """用户数据库管理器。

    封装了 SQLite + SQLAlchemy 的用户 CRUD 操作，
    使用 bcrypt 进行密码哈希。
    """

    def __init__(self, db_path: str = "users.db") -> None:
        """初始化数据库连接与元数据。

        Args:
            db_path: SQLite 数据库文件路径。

        Raises:
            SQLAlchemyError: 数据库连接或创建失败。
            ValueError: 如果数据库路径无效。
        """
        if not db_path or not isinstance(db_path, str):
            raise ValueError("数据库路径必须是非空字符串")
            
        self.db_path: str = db_path
        try:
            self.engine = create_engine(f'sqlite:///{db_path}')
            Base.metadata.create_all(self.engine)
        except SQLAlchemyError as e:
            logger.error(f"数据库初始化失败: {e}")
            raise
        
        self.Session: sessionmaker = sessionmaker(bind=self.engine)
        self.logger = logging.getLogger(__name__)

    def _get_session(self) -> Session:
        """获取一个新的数据库会话。

        Returns:
            新的 SQLAlchemy Session 实例。

        Raises:
            SQLAlchemyError: 会话创建失败。
        """
        return self.Session()

    def _user_to_dict(self, user: User, include_password_hash: bool = False) -> Dict[str, Any]:
        """将 User 对象序列化为字典。

        Args:
            user: User 实例。
            include_password_hash: 是否在结果中包含 password_hash 字段。

        Returns:
            包含用户基本信息的字典。
        """
        if user is None:
            return {}
            
        result: Dict[str, Any] = {
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'created_at': user.created_at.isoformat() if user.created_at else None,
        }
        if include_password_hash:
            result['password_hash'] = user.password_hash
        return result

    def create_user(self, username: str, password: str, email: Optional[str] = None) -> Dict[str, Any]:
        """创建新用户。

        Args:
            username: 用户名，必须唯一。
            password: 明文密码。
            email: 邮箱（可选）。若不提供，则设为空字符串。

        Returns:
            包含新创建用户信息的字典。

        Raises:
            ValueError: 当用户名或邮箱已存在，或输入无效时。
            SQLAlchemyError: 数据库操作失败。
        """
        if not username or not isinstance(username, str) or not username.strip():
            raise ValueError("用户名不能为空")
        if not password or not isinstance(password, str):
            raise ValueError("密码不能为空")

        email = email or ""

        session = self._get_session()
        try:
            # 检查用户名是否已存在
            existing_user = session.query(User).filter_by(username=username).first()
            if existing_user:
                raise ValueError(f"用户名 '{username}' 已存在")

            # 检查邮箱是否已存在（如果提供了邮箱）
            if email:
                existing_email = session.query(User).filter_by(email=email).first()
                if existing_email:
                    raise ValueError(f"邮箱 '{email}' 已被使用")

            # 创建新用户
            salt = bcrypt.gensalt()
            password_hash = bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

            user = User(
                username=username,
                password_hash=password_hash,
                email=email,
                created_at=datetime.utcnow(),
            )

            session.add(user)
            session.commit()

            self.logger.info(f"用户创建成功: {username}")

            return self._user_to_dict(user, include_password_hash=False)

        except ValueError:
            session.rollback()
            raise
        except SQLAlchemyError as e:
            session.rollback()
            self.logger.error(f"创建用户数据库操作失败: {e}", exc_info=True)
            raise
        except Exception as e:
            session.rollback()
            self.logger.error(f"创建用户失败: {str(e)}", exc_info=True)
            raise ValueError(f"创建用户失败: {str(e)}")
        finally:
            session.close()

    def get_user_by_id(self, user_id: int) -> Optional[Dict[str, Any]]:
        """根据 ID 获取用户。

        Args:
            user_id: 用户 ID。

        Returns:
            用户信息字典，若不存在则返回 None。
        """
        if not isinstance(user_id, int):
            logger.warning(f"无效的 user_id 类型: {type(user_id)}")
            return None

        session = self._get_session()
        try:
            user = session.query(User).filter_by(id=user_id).first()
            if user:
                return self._user_to_dict(user, include_password_hash=True)
            return None
        except SQLAlchemyError as e:
            self.logger.error(f"查询用户 ID {user_id} 失败: {e}", exc_info=True)
            return None
        finally:
            session.close()

    def get_user_by_username(self, username: str) -> Optional[Dict[str, Any]]:
        """根据用户名获取用户。

        Args:
            username: 用户名。

        Returns:
            用户信息字典，若不存在则返回 None。
        """
        if not username or not isinstance(username, str):
            logger.warning("无效的用户名")
            return None

        session = self._get_session()
        try:
            user = session.query(User).filter_by(username=username).first()
            if user:
                return self._user_to_dict(user, include_password_hash=True)
            return None
        except SQLAlchemyError as e:
            self.logger.error(f"查询用户 {username} 失败: {e}", exc_info=True)
            return None
        finally:
            session.close()
