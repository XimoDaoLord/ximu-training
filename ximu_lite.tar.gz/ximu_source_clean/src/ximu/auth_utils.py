# -*- coding: utf-8 -*-
"""认证工具函数，提供密码哈希、JWT令牌、格式校验等功能。"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional, Tuple, Union

import bcrypt
import jwt

from .common.config_manager import ConfigManager

logger = logging.getLogger(__name__)


class AuthUtils:
    """认证工具类，提供密码哈希、验证、强度检查、JWT令牌等功能。"""

    def __init__(self) -> None:
        """初始化认证工具类，从配置加载JWT参数。"""
        self.config = ConfigManager.get_instance()
        self.jwt_secret_key: Union[str, bytes] = self.config.get(
            'security.jwt_secret_key',
            'your-secret-key-change-in-production'
        )
        self.jwt_expiration_hours: int = int(
            self.config.get('security.jwt_expiration_hours', 1)
        )

    def hash_password(self, password: str) -> str:
        """对密码进行 bcrypt 哈希。"""
        if not password:
            raise ValueError("密码不能为空")
        password_bytes = password.encode('utf-8')
        salt = bcrypt.gensalt()
        hashed_bytes = bcrypt.hashpw(password_bytes, salt)
        return hashed_bytes.decode('utf-8')

    def verify_password(self, password: str, hashed_password: str) -> bool:
        """验证明文密码与哈希密码是否匹配。"""
        if not password or not hashed_password:
            raise ValueError("密码和哈希密码不能为空")
        try:
            return bcrypt.checkpw(
                password.encode('utf-8'),
                hashed_password.encode('utf-8')
            )
        except (ValueError, TypeError) as e:
            logger.warning("密码验证失败 - 无效的哈希格式: %s", e)
            return False

    def validate_password_strength(self, password: str) -> Tuple[bool, str]:
        """验证密码强度是否符合要求。"""
        if not password:
            return False, "密码不能为空"
        if len(password) < 8:
            return False, "密码长度至少8位"
        if not re.search(r'[A-Z]', password):
            return False, "密码必须包含大写字母"
        if not re.search(r'[a-z]', password):
            return False, "密码必须包含小写字母"
        if not re.search(r'\d', password):
            return False, "密码必须包含数字"
        if not re.search(r'[!@#$%^&*(),.?\":{}|<>]', password):
            return False, "密码必须包含特殊字符"
        return True, "密码强度符合要求"

    def validate_email(self, email: str) -> bool:
        """验证邮箱地址格式是否有效。"""
        if not email or not isinstance(email, str):
            return False
        email = email.strip()
        if not email:
            return False
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None

    def validate_username(self, username: str) -> Tuple[bool, str]:
        """验证用户名格式是否有效。"""
        if not username or not isinstance(username, str):
            return False, "用户名不能为空"
        trimmed = username.strip()
        if len(trimmed) < 3:
            return False, "用户名至少3个字符"
        if len(trimmed) > 20:
            return False, "用户名最多20个字符"
        pattern = r'^[a-zA-Z_][a-zA-Z0-9_]{1,19}$'
        if not re.match(pattern, trimmed):
            return False, "用户名只能包含字母、数字和下划线，且不能以数字开头"
        return True, "用户名格式正确"

    def generate_jwt_token(self, user_id: int, username: str) -> str:
        """生成 JWT 访问令牌。"""
        if user_id <= 0:
            raise ValueError("user_id 必须为正整数")
        if not username or not username.strip():
            raise ValueError("username 不能为空")

        now = datetime.now(timezone.utc)
        expiration = now + timedelta(hours=self.jwt_expiration_hours)

        payload: Dict[str, Any] = {
            'user_id': user_id,
            'username': username,
            'exp': expiration,
            'iat': now,
            'type': 'access'
        }

        return jwt.encode(payload, self.jwt_secret_key, algorithm='HS256')

    def decode_jwt_token(self, token: str) -> Optional[Dict[str, Any]]:
        """解码并验证 JWT 令牌。"""
        if not token or not isinstance(token, str):
            return None
        try:
            payload = jwt.decode(token, self.jwt_secret_key, algorithms=['HS256'])
            if 'user_id' not in payload:
                return None
            return payload
        except jwt.ExpiredSignatureError:
            logger.warning("JWT 令牌已过期")
            return None
        except jwt.InvalidTokenError as e:
            logger.warning("JWT 令牌无效: %s", e)
            return None
        except Exception as e:
            logger.error("JWT 解码异常: %s", e)
            return None

    def generate_password_reset_token(self, user_id: int) -> str:
        """生成密码重置令牌，有效期1小时。"""
        if user_id <= 0:
            raise ValueError("user_id 必须为正整数")

        now = datetime.now(timezone.utc)
        expiration = now + timedelta(hours=1)

        payload: Dict[str, Any] = {
            'user_id': user_id,
            'type': 'password_reset',
            'exp': expiration,
            'iat': now
        }

        return jwt.encode(payload, self.jwt_secret_key, algorithm='HS256')

    def is_password_reset_token_valid(self, token: str) -> bool:
        """验证密码重置令牌是否有效。"""
        if not token or not isinstance(token, str):
            return False
        try:
            payload = jwt.decode(token, self.jwt_secret_key, algorithms=['HS256'])
            return payload.get('type') == 'password_reset' and 'user_id' in payload
        except jwt.ExpiredSignatureError:
            logger.warning("密码重置令牌已过期")
            return False
        except jwt.InvalidTokenError as e:
            logger.warning("密码重置令牌无效: %s", e)
            return False
        except Exception as e:
            logger.error("密码重置令牌验证异常: %s", e)
            return False

    def invalidate_token(self, token: str) -> bool:
        """使令牌失效（预留接口，实际由客户端删除）。"""
        if not token or not isinstance(token, str):
            return False
        try:
            payload = jwt.decode(token, self.jwt_secret_key, algorithms=['HS256'])
            return 'user_id' in payload
        except Exception:
            return False
