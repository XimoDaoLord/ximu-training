"""汐沫AI 统一命令行入口

提供 `ximu` 命令，支持子命令：
  start   — 启动系统
  check   — 全量健康检查
  test    — 运行测试并显示覆盖率
  config  — 查看/修改配置
  status  — 查看系统运行状态
  doctor  — 环境诊断
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import subprocess
import sys
import time
from typing import Any, Dict, List, Optional

from .common.config_manager import ConfigManager
from .common.health_check import health_check, health_check_summary
from .common.logging_config import setup_logging
from .common.system_info import export_diagnostic_report, get_system_info

logger = logging.getLogger("ximu.cli")


def _detect_local_chat_model() -> bool:
    """检测本地对话模型是否可用。

    Returns:
        本地对话模型可用返回 True，否则返回 False。
    """
    try:
        from src.ximu.core.local_model_manager import is_local_model_available

        return bool(is_local_model_available())
    except Exception as e:
        logger.debug("本地对话模型检测失败: %s", e)
        return False


def _detect_local_embed_model() -> bool:
    """检测本地嵌入模型是否可用。

    Returns:
        本地嵌入模型可用返回 True，否则返回 False。
    """
    try:
        from src.ximu.core.local_bge_embedder import is_local_embedding_available

        return bool(is_local_embedding_available())
    except Exception as e:
        logger.debug("本地嵌入模型检测失败: %s", e)
        return False


def _detect_cloud_free_model() -> bool:
    """检测云端免费模型是否可用。

    Returns:
        云端免费模型可用返回 True，否则返回 False。
    """
    try:
        from src.ximu.core.live_model_gateway import check_cloud_available

        return bool(check_cloud_available())
    except Exception:
        logger.debug("云端模型检测失败", exc_info=True)
        return False


def _step0_model_detection() -> Dict[str, Any]:
    """第0步：模型可用性检测（唯一允许的识别规则）。

    先检测本地模型是否可用 → 本地不可用检测云端免费模型 → 都不可用提示用户配置。
    检测结果记录到日志。不允许用规则代替模型做决策。

    Returns:
        包含模型可用性状态和建议的字典，键包括：
        - local_chat: 本地对话模型是否可用
        - local_embed: 本地嵌入模型是否可用
        - cloud_free: 云端免费模型是否可用
        - available: 是否有任一模型可用
        - recommendation: 使用建议
    """
    local_chat = _detect_local_chat_model()
    local_embed = _detect_local_embed_model()
    cloud_free = _detect_cloud_free_model()

    result: Dict[str, Any] = {
        "local_chat": local_chat,
        "local_embed": local_embed,
        "cloud_free": cloud_free,
        "available": local_chat or local_embed or cloud_free,
        "recommendation": "",
    }

    if local_chat:
        result["recommendation"] = "本地模型可用，优先使用本地模型"
    elif cloud_free:
        result["recommendation"] = "本地模型不可用，使用云端免费模型"
    else:
        result["recommendation"] = "无可用模型，请配置API密钥或下载本地模型"

    logger.info(
        "第0步模型检测结果: local_chat=%s local_embed=%s cloud_free=%s → %s",
        local_chat,
        local_embed,
        cloud_free,
        result["recommendation"],
    )
    print(
        f"  模型检测: 本地对话={'✓' if local_chat else '✗'} "
        f"本地嵌入={'✓' if local_embed else '✗'} "
        f"云端={'✓' if cloud_free else '✗'}"
    )
    print(f"  建议: {result['recommendation']}")
    return result


def _cmd_start(_args: argparse.Namespace) -> int:
    """启动系统：初始化日志和配置，进入运行状态。

    Args:
        _args: 解析后的命令行参数（未使用）。

    Returns:
        退出码，0 表示成功。
    """
    setup_logging()
    config = ConfigManager.get_instance()
    config.start_watch()
    print("=== 汐沫AI 系统启动 ===")
    host: Optional[str] = config.get("server.host")
    port: Optional[Any] = config.get("server.port")
    log_level: Optional[str] = config.get("log.level")
    print(f"  监听地址: {host}:{port}")
    print(f"  日志级别: {log_level}")
    _step0_model_detection()
    print("  状态: 运行中 (Ctrl+C 退出)")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        print("\n  正在停止...")
        config.stop_watch()
        print("  已停止。")
    return 0


def _cmd_check(_args: argparse.Namespace) -> int:
    """全量健康检查：py_compile + import + 测试 + 配置。

    Args:
        _args: 解析后的命令行参数（未使用）。

    Returns:
        退出码，0 表示健康，1 表示不健康。
    """
    print("=== 全量健康检查 ===")
    result = health_check()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("overall") != "unhealthy" else 1


def _cmd_test(args: argparse.Namespace) -> int:
    """运行测试并显示结果。

    Args:
        args: 包含 --module 和 --coverage 的解析参数。

    Returns:
        退出码，0 表示测试通过，非0 表示失败，2 表示参数错误。
    """
    cmd: List[str] = [sys.executable, "-m", "pytest"]
    module: Optional[str] = getattr(args, "module", None)
    if module:
        if not re.match(r"^[A-Za-z0-9_]+$", module):
            print(f"错误: 模块名非法: {module!r}（仅允许字母数字下划线）")
            return 2
        cmd.append(f"tests/unit_common/test_{module}.py")
    else:
        cmd.append("tests/")

    if getattr(args, "coverage", False):
        cmd.extend(["--cov=ximu", "--cov-report=term"])

    cmd.extend(["-v", "--tb=short"])
    logger.debug("运行测试命令: %s", " ".join(cmd))
    print(f"运行命令: {' '.join(cmd)}")
    return subprocess.call(cmd)


def _cmd_config(args: argparse.Namespace) -> int:
    """查看/修改配置。

    Args:
        args: 包含 action, key, value 的解析参数。

    Returns:
        退出码，0 表示成功，2 表示用法错误。
    """
    config = ConfigManager.get_instance()
    action: str = args.action
    key: Optional[str] = args.key
    value: Optional[str] = args.value

    if action == "list":
        print(json.dumps(config.dump(), ensure_ascii=False, indent=2, sort_keys=True))
    elif action == "get" and key:
        val = config.get(key)
        print(f"{key} = {val}")
    elif action == "set" and key and value is not None:
        config.set(key, value)
        logger.info("配置已修改: %s = %s", key, value)
        print(f"已设置 {key} = {value}")
    else:
        print("用法: ximu config <list|get|set> [key] [value]")
        return 2
    return 0


def _cmd_status(_args: argparse.Namespace) -> int:
    """查看系统运行状态。

    Args:
        _args: 解析后的命令行参数（未使用）。

    Returns:
        退出码，0 表示成功。
    """
    summary = health_check_summary()
    print("=== 汐沫AI 运行状态 ===")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


def _cmd_doctor(args: argparse.Namespace) -> int:
    """环境诊断：Python/依赖/资源/配置/常见问题。

    Args:
        args: 包含 --export 的解析参数。

    Returns:
        退出码，0 表示成功。
    """
    print("=== 环境诊断 ===")
    info = get_system_info()
    python_version: str = info["python"]["version"]
    os_name: str = info["system"]["os"]
    os_release: str = info["system"]["os_release"]
    cpu_count: int = info["hardware"]["cpu_count_logical"]
    memory_total_gb: float = info["hardware"]["memory_total_gb"]
    psutil_available: bool = info["psutil_available"]

    print(f"  Python: {python_version}")
    print(f"  系统: {os_name} {os_release}")
    print(f"  CPU 逻辑核数: {cpu_count}")
    print(f"  内存: {memory_total_gb} GB")
    print(f"  psutil 可用: {psutil_available}")

    export_path: Optional[str] = getattr(args, "export", None)
    if export_path:
        path = export_diagnostic_report(export_path)
        logger.info("诊断报告已导出: %s", path)
        print(f"  诊断报告已导出: {path}")
    return 0


def _add_start_subcommand(subparsers: argparse._SubParsersAction) -> None:
    """添加 start 子命令解析器。

    Args:
        subparsers: 子解析器集合。
    """
    p_start = subparsers.add_parser("start", help="启动系统")
    p_start.set_defaults(func=_cmd_start)


def _add_check_subcommand(subparsers: argparse._SubParsersAction) -> None:
    """添加 check 子命令解析器。

    Args:
        subparsers: 子解析器集合。
    """
    p_check = subparsers.add_parser("check", help="全量健康检查")
    p_check.set_defaults(func=_cmd_check)


def _add_test_subcommand(subparsers: argparse._SubParsersAction) -> None:
    """添加 test 子命令解析器。

    Args:
        subparsers: 子解析器集合。
    """
    p_test = subparsers.add_parser("test", help="运行测试")
    p_test.add_argument("--module", help="只运行指定模块的测试")
    p_test.add_argument("--coverage", action="store_true", help="显示覆盖率")
    p_test.set_defaults(func=_cmd_test)


def _add_config_subcommand(subparsers: argparse._SubParsersAction) -> None:
    """添加 config 子命令解析器。

    Args:
        subparsers: 子解析器集合。
    """
    p_config = subparsers.add_parser("config", help="查看/修改配置")
    p_config.add_argument("action", choices=["list", "get", "set"])
    p_config.add_argument("key", nargs="?", help="配置键")
    p_config.add_argument("value", nargs="?", help="配置值")
    p_config.set_defaults(func=_cmd_config)


def _add_status_subcommand(subparsers: argparse._SubParsersAction) -> None:
    """添加 status 子命令解析器。

    Args:
        subparsers: 子解析器集合。
    """
    p_status = subparsers.add_parser("status", help="查看系统状态")
    p_status.set_defaults(func=_cmd_status)


def _add_doctor_subcommand(subparsers: argparse._SubParsersAction) -> None:
    """添加 doctor 子命令解析器。

    Args:
        subparsers: 子解析器集合。
    """
    p_doctor = subparsers.add_parser("doctor", help="环境诊断")
    p_doctor.add_argument("--export", help="导出诊断报告到指定 JSON 文件")
    p_doctor.set_defaults(func=_cmd_doctor)


def build_parser() -> argparse.ArgumentParser:
    """构建命令行参数解析器。

    Returns:
        配置好的 ArgumentParser 实例。
    """
    parser = argparse.ArgumentParser(
        prog="ximu",
        description="汐沫AI 统一命令行入口",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    _add_start_subcommand(sub)
    _add_check_subcommand(sub)
    _add_test_subcommand(sub)
    _add_config_subcommand(sub)
    _add_status_subcommand(sub)
    _add_doctor_subcommand(sub)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    """CLI 主入口。

    Args:
        argv: 命令行参数列表，默认使用 sys.argv。

    Returns:
        进程退出码。
    """
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
