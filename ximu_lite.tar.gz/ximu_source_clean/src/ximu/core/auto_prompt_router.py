"""自动提示词路由模块。

该模块提供文本意图检测、提示词模板渲染、核心任务压缩、多格式输出路由及
记忆化存储等核心功能，用于在调用 LLM 前对原始用户输入进行结构化预处理。

版本: 0.5
"""

import json
import logging
import os
import re
import sqlite3
import time
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 正则表达式与常量
# ---------------------------------------------------------------------------

_LEAD_INTERJECT_RE = re.compile(
    r"^(?:那个那个|那个嘛|嗯那个|我觉得吧|说实话|怎么说呢|就是说|其实|反正|那个|"
    r"嗯|呃|啊|哦|就是|我觉得)\s*[，,、。.！!？?～~]*"
)

_FILLER_PATTERNS: List[re.Pattern] = [
    _LEAD_INTERJECT_RE,
    re.compile(
        r"(?:麻烦(?:你|您)?(?:帮(?:我|你|您)?(?:一下|个忙)?)?"
        r"|请(?:你|您)?(?:帮(?:我|你|您)?(?:一下|个忙)?)?"
        r"|劳驾|拜托|辛苦(?:你|您)?了?|帮个忙"
        r"|帮(?:我|你|您)(?:一下|个忙)?\s*)"
        r"\s*[，,。.！!？?]*"
    ),
    re.compile(
        r"(?:可以吗|行不行|好吗|对吧|是吧|你知道吗|你懂吧|总而言之|总之)"
        r"[\s。.！!？?]*$"
    ),
]

_MID_FILLERS: List[str] = [
    "就是说", "那个那个", "那个嘛", "你知道吗", "你懂吧", "反正呢", "嗯那个",
    "就是那个", "怎么说呢", "这个这个", "然后呢",
]

_PUNCT_COLLAPSE_RE = re.compile(r"[ \t]{2,}")
_COMMA_COLLAPSE_RE = re.compile(r"[，,]{2,}")
_LEAD_TRASH_RE = re.compile(r"^[，,。\.\s]+")
_CJK_RE = re.compile(r"[一-龥]")

# ---------------------------------------------------------------------------
# 意图规则与模板字段
# ---------------------------------------------------------------------------

_INTENT_RULES: List[Tuple[str, Tuple[str, ...]]] = [
    (
        "howto",
        (
            "怎么", "如何", "咋弄", "咋办", "怎样", "教我", "请问怎么",
            "怎么做", "怎么搞", "怎么弄", "how to", "how do i", "how can i",
        ),
    ),
    (
        "diagnose",
        (
            "报错", "异常", "不工作", "失败了", "排查", "定位", "用不了",
            "不能用", "打不开", "没反应", "卡住", "崩溃", "error", "exception",
            "crash", "not working", "debugging", "日志", "帮我看看",
        ),
    ),
    (
        "consult",
        (
            "咨询", "了解一下", "想知道", "打听", "请问一下", "想问一下",
            "i want to know", "i'd like to know", "tell me about",
        ),
    ),
    (
        "dev",
        (
            "写代码", "写个代码", "写函数", "写个函数", "写一个函数", "写个脚本",
            "写脚本", "写个程序", "写一个程序", "写个系统", "做一个网站",
            "写一个网站", "开发", "搭建", "实现一个", "实现", "爬虫", "写个爬虫",
            "写个工具", "debug", "调错", "修bug", "python", "代码", "算法",
            "接口", "数据库", "部署", "重构", "写测试", "代码审查", "函数",
            "code", "function", "bug", "api",
            "小应用", "应用", "写个应用", "做应用", "做个应用", "做个程序",
            "做个工具", "做个网站", "小程序", "客户端", "页面", "写个工具",
            "做个小工具", "开发一个", "搭一个", "搞一个", "app", "tool",
            "utility", "page", "frontend", "backend", "系统", "工具",
            "登录", "登陆", "注册", "加密", "解密", "认证", "鉴权", "哈希",
            "散列", "验证码", "会话", "令牌", "接口对接", "sso", "oauth",
            "jwt", "bcrypt", "hash", "md5", "sha1", "sha256", "pbkdf2",
        ),
    ),
    (
        "write",
        (
            "写一篇", "写个", "写一份", "写个文章", "写文章", "写个总结",
            "写个报告", "写个文案", "写个小说", "写个故事", "写个邮件", "写个信",
            "润色", "改写", "文案", "稿子", "大纲", "提纲", "起个标题", "标题",
            "写个简介", "写个说明", "写一个", "写篇", "小故事", "短篇小说",
            "短文", "散文", "随笔", "作文", "写一个小故事", "写个短文",
            "写个散文", "写个随笔", "写个作文",
        ),
    ),
    (
        "translate",
        (
            "翻译", "译成", "翻译成", "translate", "translator", "英译中",
            "中译英", "翻译一下", "翻成",
        ),
    ),
    (
        "analyze",
        (
            "分析", "分析一下", "对比", "比较", "评估", "评价",
            "如何看待", "解读", "剖析", "推理", "一步步",
            "reasoning", "分析这个",
        ),
    ),
    (
        "summarize",
        (
            "总结", "概括", "摘要", "归纳", "要点", "提炼", "缩成", "浓缩",
            "summarize", "summary", "总结一下", "归纳一下",
        ),
    ),
]

_TEMPLATE_FIELDS: Dict[str, Dict[str, str]] = {
    "howto": {
        "intent_label": "方法咨询",
        "constraint": "给出可操作步骤；分点列出；标注前提条件与常见坑点",
        "output": "分步操作指南 + 注意事项",
    },
    "diagnose": {
        "intent_label": "故障排查",
        "constraint": "先复现现象→列可能原因→给排查命令/步骤；不臆测",
        "output": "现象 + 原因假设 + 排查步骤 + 修复建议",
    },
    "consult": {
        "intent_label": "咨询了解",
        "constraint": "客观陈述；列要点；不确定处显式标注；不编造",
        "output": "要点说明 + 必要时附参考方向",
    },
    "dev": {
        "intent_label": "开发实现",
        "constraint": "代码可直接运行；关键逻辑加注释；标注依赖与版本",
        "output": "可运行代码 + 简要实现说明 + 验证方式",
    },
    "write": {
        "intent_label": "写作",
        "constraint": "结构清晰（开头/主体/结尾）；语气与篇幅贴合受众；不编造事实",
        "output": "成文 + 必要时附大纲",
    },
    "translate": {
        "intent_label": "翻译",
        "constraint": "忠实原意不增删；目标语言地道；专有名词保留或括注",
        "output": "译文（必要时附对照）",
    },
    "analyze": {
        "intent_label": "分析推理",
        "constraint": "先结论后依据；分点列证据/因果；不确定处显式标注",
        "output": "结论 + 分点依据",
    },
    "summarize": {
        "intent_label": "总结提炼",
        "constraint": "保留全部关键要点不丢；分条列出；用简洁中文",
        "output": "分条核心结论",
    },
}

# 默认意图：无法匹配任何规则时使用
_DEFAULT_INTENT = "consult"

# 门控阈值映射：意图 -> 触发压缩的最低置信度
_GATE_THRESHOLDS: Dict[str, float] = {
    "howto": 0.3,
    "diagnose": 0.4,
    "consult": 0.2,
    "dev": 0.5,
    "write": 0.4,
    "translate": 0.5,
    "analyze": 0.4,
    "summarize": 0.5,
}


# ---------------------------------------------------------------------------
# 内部辅助函数
# ---------------------------------------------------------------------------

def _is_pure_greeting(text: str) -> bool:
    """判断文本是否为纯问候语（如'你好'、'hi'等），不含实质任务。"""
    stripped = text.strip().lower()
    greetings = {"你好", "您好", "hi", "hello", "嗨", "哈喽", "哈啰", "hey",
                 "你好呀", "您好呀", "在吗", "在不在"}
    return stripped in greetings


def _is_math_or_fact(text: str) -> bool:
    """判断文本是否为简单数学计算或事实查询，可直接回答无需复杂模板。"""
    math_pattern = re.compile(r"^\s*[\d\s\+\-\*\/\.\(\)\=\?]+\s*$")
    if math_pattern.match(text.strip()):
        return True
    fact_keywords = ["是多少", "几岁", "哪个国家", "首都", "定义是"]
    lower_text = text.lower()
    return any(kw in lower_text for kw in fact_keywords) and len(text.strip()) < 30


def _gate_threshold_for(intent: str) -> float:
    """获取指定意图的门控阈值，用于决定是否触发压缩/转换。"""
    return _GATE_THRESHOLDS.get(intent, 0.5)


def _normalize_term(s: str) -> str:
    """标准化术语：去除首尾空白，统一小写，并替换全角字符为半角。"""
    s = s.strip().lower()
    result = []
    for ch in s:
        code = ord(ch)
        if 0xFF01 <= code <= 0xFF5E:
            result.append(chr(code - 0xFEE0))
        elif code == 0x3000:
            result.append(' ')
        else:
            result.append(ch)
    return ''.join(result)


def _keyword_retained(kw: str, blob: str) -> bool:
    """检查关键词是否保留在压缩后的文本中（支持部分匹配）。"""
    if not kw:
        return True
    normalized_kw = _normalize_term(kw)
    normalized_blob = _normalize_term(blob)
    return normalized_kw in normalized_blob


def _retention_ok(blob: str, keywords: List[str]) -> bool:
    """检查所有关键关键词是否都保留在 blob 中。"""
    if not keywords:
        return True
    for kw in keywords:
        if not _keyword_retained(kw, blob):
            logger.debug(f"关键词 '{kw}' 未保留在 blob 中")
            return False
    return True


def _extract_feature_phrases(text: str) -> List[str]:
    """从文本中提取特征短语（名词、动词短语等），用于关键术语识别。"""
    phrases: List[str] = []
    tokens = re.split(r"[，,。！？;；\s]+", text.strip())
    for token in tokens:
        token = token.strip()
        if 2 <= len(token) <= 10:
            if token and not re.match(r"^[\d\.\,\;]+$", token):
                phrases.append(token)
    return phrases


def _refine_key_terms(task: str, terms: Optional[List[str]]) -> List[str]:
    """精炼关键术语列表：去除已在 task 中明确出现的重复项，保留重要术语。"""
    if not terms:
        return _extract_feature_phrases(task)
    unique_terms: List[str] = []
    seen = set()
    for term in terms:
        normalized_term = _normalize_term(term)
        if normalized_term and normalized_term not in seen:
            seen.add(normalized_term)
            unique_terms.append(term)
    # 从 task 中提取额外特征短语并补充
    extra_phrases = _extract_feature_phrases(task)
    for phrase in extra_phrases:
        normalized_phrase = _normalize_term(phrase)
        if normalized_phrase and normalized_phrase not in seen:
            seen.add(normalized_phrase)
            unique_terms.append(phrase)
    return unique_terms


def detect_intent(text: str) -> Tuple[str, float]:
    """检测文本意图，返回意图标签和置信度。

    Args:
        text: 用户输入文本

    Returns:
        意图标签和置信度元组
    """
    normalized = _normalize_term(text)
    scores: Dict[str, float] = {}
    for intent, keywords in _INTENT_RULES:
        score = 0.0
        matched = 0
        for kw in keywords:
            if _normalize_term(kw) in normalized:
                matched += 1
                score += 1.0
        total = len(keywords)
        if total > 0:
            scores[intent] = matched / total
    if not scores or max(scores.values()) < 0.1:
        return _DEFAULT_INTENT, 0.0
    best_intent = max(scores, key=scores.get)  # type: ignore
    return best_intent, scores[best_intent]


def render_prompt_template(intent: str, task: str, extra: Optional[Dict[str, Any]] = None) -> str:
    """渲染提示词模板。

    Args:
        intent: 意图标签
        task: 核心任务描述
        extra: 额外上下文参数

    Returns:
        渲染后的提示词字符串
    """
    fields = _TEMPLATE_FIELDS.get(intent, _TEMPLATE_FIELDS[_DEFAULT_INTENT])
    parts = [
        f"[意图] {fields['intent_label']}",
        f"[任务] {task}",
        f"[约束] {fields['constraint']}",
        f"[输出] {fields['output']}",
    ]
    if extra:
        for k, v in extra.items():
            parts.append(f"[附加] {k}: {v}")
    return "\n".join(parts)
