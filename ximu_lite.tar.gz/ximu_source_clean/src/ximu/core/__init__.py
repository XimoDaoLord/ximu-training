"""
ximu.core模块初始化文件

该模块作为ximu核心功能的统一入口，提供模块化架构的各个子模块访问。
所有子模块导入使用try/except降级处理，避免单个模块失败导致整个core包无法导入。
"""

__version__ = "0.5"

import logging
logger = logging.getLogger(__name__)

# 导入各子模块的公共API（降级处理：单个模块失败不影响其他模块）
_submodules = [
    'task_closed_loop', 'subtask_executor', 'redo_controller',
    'confirm_point_manager', 'aggregation_delivery', 'ai',
    'connectors', 'data_judge', 'emotion', 'governance',
    'interface', 'learning', 'local_workspace', 'memory',
    'model_router', 'multimodal', 'paradigm', 'personality_team',
    'prompt_system', 'registry', 'scheduling', 'self_optimization',
    'telemetry', 'transit', 'vector_store', 'workflow',
]

for _mod in _submodules:
    try:
        exec(f'from .{_mod} import *')
    except Exception as e:
        logger.warning("core子模块 %s 导入失败（降级）: %s", _mod, e)
