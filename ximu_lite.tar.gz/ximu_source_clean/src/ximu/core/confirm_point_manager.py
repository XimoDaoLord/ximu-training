import json
import logging
import os
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger("src.ximu.core.confirm_point_manager")

_HIGH_RISK_KW = (
    "delete", "删除", "清空", "卸载", "uninstall",
    "send", "发送", "邮件", "email", "webhook", "外发",
    "system", "系统级", "install", "权限",
    "格式化", "format", "mkfs", "抹掉", "抹除", "擦除",
    "清空磁盘", "恢复出厂", "恢复工厂", "工厂重置", "factory reset",
    "wipe", "擦除磁盘", "全盘删除", "重新分区", "partition",
    "清除全部数据", "卸载系统", "rm -rf", "rm -fr",
)

_HIGH_RISK_KW_EXTREME = (
    *(_HIGH_RISK_KW),
    "kill -9", "格式化磁盘", "mkfs.ext4", "mkfs.xfs",
    "dd if=", "shred", "wipefs",
)

def _is_high_risk_confirm(kind: str, question: str) -> bool:
    """判断确认点是否属于高危操作。"""
    text = f"{kind} {question}".lower()
    return any(kw in text for kw in _HIGH_RISK_KW)

def _is_extreme_risk(kind: str, question: str) -> bool:
    """判断确认点是否属于极度高危操作。"""
    text = f"{kind} {question}".lower()
    return any(kw in text for kw in _HIGH_RISK_KW_EXTREME)

@dataclass
class ConfirmPoint:
    """确认点实体"""
    confirm_id: str
    kind: str
    question: str
    options: List[Dict[str, str]]
    note_hint: str = ""
    created_at: float = field(default_factory=time.time)
    decision: Optional[str] = None
    note: str = ""
    _event: threading.Event = field(default_factory=threading.Event)
    timeout_policy: str = "hang"

    def wait(self, timeout_s: float) -> Dict[str, Any]:
        """等待用户回应"""
        got = self._event.wait(timeout_s)
        if got:
            return {"resolved": True, "decision": self.decision, "note": self.note}
        if self.timeout_policy == "abort":
            return {"resolved": False, "decision": "abort", "note": "确认超时，任务中止"}
        if self.timeout_policy == "release":
            return {"resolved": True, "decision": self.options[0]["id"] if self.options else "confirm", "note": "确认超时，自动放行"}
        return {"resolved": False, "decision": "hang", "note": "等待人类确认"}

    def respond(self, decision: str, note: str = "") -> bool:
        """用户回应"""
        if self._event.is_set():
            return False
        self.decision = decision
        self.note = note or ""
        self._event.set()
        return True

    def to_dict(self) -> Dict[str, Any]:
        """序列化"""
        return {
            "confirm_id": self.confirm_id,
            "kind": self.kind,
            "question": self.question,
            "options": self.options,
            "note_hint": self.note_hint,
            "created_at": self.created_at,
            "decision": self.decision,
            "note": self.note,
            "timeout_policy": self.timeout_policy,
            "resolved": self._event.is_set()
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConfirmPoint":
        """反序列化"""
        cp = cls(
            kind=data.get("kind", ""),
            question=data.get("question", ""),
            options=data.get("options", []),
            note_hint=data.get("note_hint", ""),
            timeout_policy=data.get("timeout_policy", "hang")
        )
        cp.confirm_id = data.get("confirm_id", uuid.uuid4().hex)
        cp.created_at = data.get("created_at", time.time())
        cp.decision = data.get("decision")
        cp.note = data.get("note", "")
        if data.get("resolved"):
            cp._event.set()
        return cp

class ConfirmPointManager:
    """确认点管理器"""

    def __init__(self, loop_id: str, checkpoint_dir: str = ""):
        """初始化"""
        self.loop_id = loop_id
        self.checkpoint_dir = checkpoint_dir
        self.pending_confirms: Dict[str, ConfirmPoint] = {}
        self._lock = threading.Lock()
        self._suspend_path = os.path.join(checkpoint_dir, f"confirm_{loop_id}.json") if checkpoint_dir else ""

    def ask(self, kind: str, question: str, options: List[Dict[str, str]],
            note_hint: str = "", timeout_s: float = 300.0) -> Dict[str, Any]:
        """创建并等待确认"""
        if (kind == "auto" and not _is_high_risk_confirm(kind, question)
                and not _is_extreme_risk(kind, question)):
            return {"resolved": True, "decision": (options[0]["id"] if options else "confirm"), "note": "auto 放行"}

        if not any(o.get("id") == "custom" for o in options):
            options = list(options) + [{"id": "custom", "label": "自定义"}]

        with self._lock:
            cp = ConfirmPoint(
                confirm_id=uuid.uuid4().hex,
                kind=kind,
                question=question,
                options=options,
                note_hint=note_hint
            )
            self.pending_confirms[cp.confirm_id] = cp
            self._persist_suspend()
            return cp.wait(timeout_s)

    def confirm(self, confirm_id: str, decision: str, note: str = "") -> bool:
        """回应确认"""
        with self._lock:
            cp = self.pending_confirms.get(confirm_id)
            if cp is None:
                return False
            result = cp.respond(decision, note)
            if result:
                del self.pending_confirms[confirm_id]
                self._persist_suspend()
            return result

    def get_pending(self) -> List[Dict[str, Any]]:
        """获取待处理列表"""
        with self._lock:
            return [cp.to_dict() for cp in self.pending_confirms.values()]

    def clear_all(self) -> int:
        """清除全部"""
        with self._lock:
            n = len(self.pending_confirms)
            self.pending_confirms.clear()
            self._persist_suspend()
            return n

    def _persist_suspend(self) -> None:
        """持久化"""
        if not self._suspend_path:
            return
        try:
            import tempfile
            data = {
                "loop_id": self.loop_id,
                "pending": {cp.confirm_id: cp.to_dict() for cp in self.pending_confirms.values()},
                "saved_at": time.time()
            }
            d = os.path.dirname(self._suspend_path)
            if d and not os.path.isdir(d):
                os.makedirs(d, exist_ok=True)
            _tmp = tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=d, suffix=".tmp", delete=False)
            try:
                json.dump(data, _tmp, ensure_ascii=False, indent=2)
                _tmp.flush()
                os.fsync(_tmp.fileno())
                _tmp.close()
                os.replace(_tmp.name, self._suspend_path)
            except Exception:
                try:
                    _tmp.close()
                except Exception:
                    pass
                try:
                    os.unlink(_tmp.name)
                except Exception:
                    pass
        except Exception as e:
            logger.warning("持久化失败: %s", e)

    def restore_suspend(self) -> List[ConfirmPoint]:
        """恢复挂起点"""
        if not self._suspend_path or not os.path.exists(self._suspend_path):
            return []
        try:
            with open(self._suspend_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            pending = data.get("pending", {})
            with self._lock:
                for cid, cp_data in pending.items():
                    if not cp_data.get("resolved"):
                        cp = ConfirmPoint.from_dict(cp_data)
                        self.pending_confirms[cid] = cp
            return list(self.pending_confirms.values())
        except Exception as e:
            logger.warning("恢复失败: %s", e)
            return []
