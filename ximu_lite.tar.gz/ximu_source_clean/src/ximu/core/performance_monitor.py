# -*- coding: utf-8 -*-
"""性能监控器（性能优化 · 延迟/吞吐/资源/告警/导出）。

能力：
    - 延迟测量：每个操作名维护最近 N 次样本，提供 P50/P90/P95/P99；
    - 吞吐量：滑动时间窗口内每秒请求数（QPS）；
    - 资源占用：CPU / 内存 / 磁盘采样（优先 psutil，缺失时降级为占位值）；
    - 性能基准：记录基准值并对比当前值，计算提升比例；
    - 告警：延迟或资源超过阈值时产生告警记录；
    - 历史数据：每个指标仅保留最近 ``history_size`` 次测量；
    - 导出：性能报告导出为 JSON（dict 可被 json.dumps）。
"""
from __future__ import annotations

import json
import logging
import os
import tempfile
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional

try:  # psutil 为可选依赖；缺失时资源采样降级
    import psutil  # type: ignore
    _HAS_PSUTIL = True
except Exception:  # pragma: no cover - 环境相关
    psutil = None  # type: ignore
    _HAS_PSUTIL = False

logger = logging.getLogger(__name__)


def _percentile(sorted_vals: List[float], pct: float) -> float:
    """对已升序排列的列表取百分位（pct in 0..100）。

    Args:
        sorted_vals: 已排序的数值列表
        pct: 百分位数值 (0-100)

    Returns:
        对应百分位的数值
    """
    if not sorted_vals:
        return 0.0
    if len(sorted_vals) == 1:
        return float(sorted_vals[0])
    idx = int(round((len(sorted_vals) - 1) * pct / 100.0))
    idx = max(0, min(idx, len(sorted_vals) - 1))
    return float(sorted_vals[idx])


@dataclass
class ThresholdAlert:
    """阈值告警记录。"""
    name: str
    metric: str
    value: float
    threshold: float
    at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        """将告警对象转换为可序列化的字典。

        Returns:
            包含告警详细信息的字典
        """
        return {"name": self.name, "metric": self.metric,
                "value": round(self.value, 4), "threshold": self.threshold,
                "at": self.at}


class PerformanceMonitor:
    """进程内性能监控器（线程安全）。

    Attributes:
        history_size: 历史数据保留的最大数量
        throughput_window: 吞吐量计算的时间窗口（秒）
    """

    def __init__(self, history_size: int = 1024,
                 throughput_window: float = 5.0) -> None:
        """初始化性能监控器。

        Args:
            history_size: 每个指标保留的历史样本数量
            throughput_window: 吞吐量计算的时间窗口（秒）
        """
        self._history_size = max(16, int(history_size))
        self._throughput_window = float(throughput_window)
        self._latency: Dict[str, Deque[float]] = {}
        self._timestamps: Dict[str, Deque[float]] = {}
        self._failures: Dict[str, int] = {}  # B16：失败计数
        self._fail_lock = threading.RLock()
        self._active: Dict[str, float] = {}
        self._baselines: Dict[str, Dict[str, float]] = {}
        self._thresholds: Dict[str, float] = {}  # name -> 延迟 ms 告警阈值
        self._alerts: Deque[ThresholdAlert] = deque(maxlen=200)
        self._resource_history: Deque[Dict[str, float]] = deque(maxlen=history_size)
        self._lock = threading.RLock()
        self._proc = psutil.Process() if _HAS_PSUTIL else None

    # ------------------------------------------------------------------ timing
    def start(self, name: str) -> None:
        """开始计时指定操作。

        Args:
            name: 操作名称
        """
        with self._lock:
            self._active[name] = time.perf_counter()

    def stop(self, name: str) -> float:
        """结束计时并记录该次延迟（毫秒），返回本次耗时。

        Args:
            name: 操作名称

        Returns:
            本次操作耗时（毫秒）
        """
        with self._lock:
            start = self._active.pop(name, None)
            if start is None:
                return 0.0
            ms = (time.perf_counter() - start) * 1000.0
            self.record_latency(name, ms)
            return ms

    def record_latency(self, name: str, ms: float) -> None:
        """直接记录一次延迟样本（毫秒）。

        Args:
            name: 操作名称
            ms: 延迟毫秒值
        """
        with self._lock:
            dq = self._latency.get(name)
            if dq is None:
                dq = self._latency[name] = deque(maxlen=self._history_size)
            dq.append(float(ms))
            tq = self._timestamps.get(name)
            if tq is None:
                tq = self._timestamps[name] = deque(maxlen=self._history_size)
            now = time.time()
            # B17：写入时顺手剔除过期时间戳，throughput() 直接 O(1) 读 len
            cutoff = now - self._throughput_window
            while tq and tq[0] < cutoff:
                tq.popleft()
            tq.append(now)
            thr = self._thresholds.get(name)
            if thr is not None and ms > thr:
                self._alerts.append(ThresholdAlert(
                    name=name, metric="latency_ms", value=ms, threshold=thr))

    # ------------------------------------------------------------------ failure (B16)
    def record_failure(self, name: str, ms: Optional[float] = None) -> None:
        """B16：记录一次失败样本（可附带耗时）。

        Args:
            name: 操作名称
            ms: 可选的耗时毫秒值
        """
        with self._lock:
            self._failures[name] = int(self._failures.get(name, 0)) + 1
            if ms is not None:
                self.record_latency(name, float(ms))

    # ------------------------------------------------------------------ stats
    def latency_percentiles(self, name: str) -> Dict[str, float]:
        """返回 P50/P90/P95/P99（毫秒）与样本数。

        Args:
            name: 操作名称

        Returns:
            包含各百分位统计值的字典
        """
        with self._lock:
            vals = sorted(self._latency.get(name, ()))
        if not vals:
            return {"count": 0, "p50": 0.0, "p90": 0.0, "p95": 0.0, "p99": 0.0}
        return {
            "count": len(vals),
            "p50": round(_percentile(vals, 50), 4),
            "p90": round(_percentile(vals, 90), 4),
            "p95": round(_percentile(vals, 95), 4),
            "p99": round(_percentile(vals, 99), 4),
        }

    def throughput(self, name: str) -> float:
        """滑动窗口内该操作的平均 QPS（次/秒）。B17：直接读写入时已剔除过期项的 deque 长度。

        Args:
            name: 操作名称

        Returns:
            每秒请求数
        """
        with self._lock:
            tq = self._timestamps.get(name)
            n = len(tq) if tq else 0
        if n < 2:
            return 0.0
        return round(n / self._throughput_window, 3)

    # ------------------------------------------------------------------ resource
    def sample_resources(self) -> Dict[str, float]:
        """采样一次 CPU / 内存 / 磁盘占用并返回。

        Returns:
            包含资源采样数据的字典
        """
        snap: Dict[str, float] = {"ts": time.time()}
        if _HAS_PSUTIL and self._proc is not None:
            try:
                snap["cpu_percent"] = float(self._proc.cpu_percent(interval=None))
                mem = self._proc.memory_info()
                snap["memory_rss_mb"] = round(mem.rss / (1024 * 1024), 2)
                du = self._proc.io_counters()
                snap["disk_read_mb"] = round(getattr(du, "read_bytes", 0) / (1024 * 1024), 2)
                snap["disk_write_mb"] = round(getattr(du, "write_bytes", 0) / (1024 * 1024), 2)
            except Exception:
                snap.setdefault("cpu_percent", 0.0)
        else:
            snap["cpu_percent"] = 0.0
            snap["memory_rss_mb"] = 0.0
        with self._lock:
            self._resource_history.append(snap)
        return snap

    # ------------------------------------------------------------------ baseline
    def record_baseline(self, name: str, metrics: Dict[str, float]) -> None:
        """记录某操作的性能基准值（如优化前 P99）。

        Args:
            name: 操作名称
            metrics: 基准指标字典
        """
        with self._lock:
            self._baselines[name] = dict(metrics)

    def compare_baseline(self, name: str) -> Dict[str, Any]:
        """对比基准与当前 P99，返回提升比例（负值=变快，正值=变慢）。

        Args:
            name: 操作名称

        Returns:
            包含基准、当前值和变化比例的字典
        """
        with self._lock:
            base = dict(self._baselines.get(name, {}))
        cur = self.latency_percentiles(name)
        out: Dict[str, Any] = {"baseline": base, "current": cur}
        if "p99" in base and base["p99"] > 0 and cur.get("p99", 0) > 0:
            change_pct = (cur["p99"] - base["p99"]) / base["p99"] * 100.0
            out["p99_change_pct"] = round(change_pct, 2)
            out["improved"] = change_pct < 0
        return out

    # ------------------------------------------------------------------ alert
    def set_threshold(self, name: str, latency_ms: float) -> None:
        """设置延迟告警阈值。

        Args:
            name: 操作名称
            latency_ms: 延迟阈值（毫秒）
        """
        with self._lock:
            self._thresholds[name] = float(latency_ms)

    def recent_alerts(self) -> List[Dict[str, Any]]:
        """获取最近的告警列表。

        Returns:
            告警字典列表
        """
        with self._lock:
            return [a.to_dict() for a in list(self._alerts)]

    # ------------------------------------------------------------------ export
    def names(self) -> List[str]:
        """获取所有被监控的操作名称。

        Returns:
            操作名称列表
        """
        with self._lock:
            return list(self._latency.keys())

    # ------------------------------------------------------------------ obs bridge (可观测打磨)
    def _obs(self) -> Any:
        """懒加载 ObsCollector 单例（避免循环导入）。

        Returns:
            ObsCollector 实例
        """
        from .obs_collector import get_obs_collector
        return get_obs_collector()

    def sample_full(self) -> Dict[str, Any]:
        """全量指标采样：CPU/RSS/进程IO/系统磁盘IO/系统网络IO/句柄/线程/GPU(降级)。

        Returns:
            包含全量采样数据的字典
        """
        return self._obs().sample_once()

    def start_obs(self, interval: float = 1.0) -> None:
        """启动后台非阻塞采集线程。

        Args:
            interval: 采样间隔（秒）
        """
        self._obs().start(interval=interval)

    def stop_obs(self, join_timeout: float = 3.0) -> bool:
        """停止后台采集线程。

        Args:
            join_timeout: 等待线程结束超时时间（秒）

        Returns:
            是否在超时前成功停止
        """
        return self._obs().stop(join_timeout=join_timeout)

    def set_resource_threshold(self, metric: str, op: str, value: float) -> None:
        """资源阈值告警：op in {'>','<'}。命中后进入 recent_obs_alerts()。

        Args:
            metric: 资源指标名称
            op: 比较运算符 ('>' 或 '<')
            value: 阈值
        """
        self._obs().set_threshold(metric, op, value)

    def recent_obs_alerts(self) -> List[Dict[str, Any]]:
        """获取最近的可观测性告警。

        Returns:
            告警字典列表
        """
        return self._obs().recent_alerts()

    def obs_cost_stats(self) -> Dict[str, Any]:
        """后台采样耗时统计（ms）：min/p50/p95/max/mean。

        Returns:
            耗时统计字典
        """
        return self._obs().cost_stats()

    def obs_latest(self) -> Optional[Dict[str, Any]]:
        """获取最新一次可观测性采样结果。

        Returns:
            最新采样数据或 None
        """
        return self._obs().latest()

    def report(self) -> Dict[str, Any]:
        """汇总性能报告（可直接 json.dumps）。
        P5：operations 按 p99 降序（慢请求 Top N），并附 rank；
        B16：每操作补 fail_count / error_rate。

        Returns:
            完整的性能报告字典
        """
        with self._lock:
            names = list(self._latency.keys())
            failures = dict(self._failures)
        rows = []
        for n in names:
            pct = self.latency_percentiles(n)
            pct["qps"] = self.throughput(n)
            f_cnt = int(failures.get(n, 0))
            pct["fail_count"] = f_cnt
            total = int(pct.get("count", 0)) + f_cnt
            pct["error_rate"] = round(f_cnt / total, 4) if total > 0 else 0.0
            rows.append((n, pct))
        # P5：按 p99 降序排序，附 rank
        rows.sort(key=lambda x: x[1].get("p99", 0.0), reverse=True)
        ordered: Dict[str, Any] = {}
        for rank, (n, pct) in enumerate(rows, 1):
            pct["rank"] = rank
            ordered[n] = pct
        return {
            "generated_at": time.time(),
            "operations": ordered,
            "baselines": {k: dict(v) for k, v in self._baselines.items()},
            "alerts": self.recent_alerts()[-20:],
            "resources": list(self._resource_history)[-10:],
            "psutil_available": _HAS_PSUTIL,
        }

    def export_json(self, path: str) -> str:
        """导出性能报告到 JSON 文件，返回文件路径。B18：原子写（tmp + os.replace）。

        Args:
            path: 目标文件路径

        Returns:
            导出的文件路径

        Raises:
            Exception: 当写入文件失败时
        """
        _dir = os.path.dirname(path) or "."
        os.makedirs(_dir, exist_ok=True)
        _tmp = tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=_dir, suffix=".tmp", delete=False)
        try:
            json.dump(self.report(), _tmp, ensure_ascii=False, indent=2)
            _tmp.flush()
            os.fsync(_tmp.fileno())
            _tmp.close()
            os.replace(_tmp.name, path)
            logger.info(f"Performance report exported to {path}")
        except Exception as e:
            try:
                _tmp.close()
            except Exception:
                pass
            try:
                os.unlink(_tmp.name)
            except Exception:
                pass
            logger.error(f"Failed to export performance report to {path}: {e}")
            raise
        return path
