import logging
import math
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union, cast
from threading import RLock
from collections import deque
from datetime import datetime
from dataclasses import dataclass, field
from abc import ABC, abstractmethod

logger = logging.getLogger("src.ximu.core._dag_scheduler_parts.part5")


@dataclass
class ModelHistoryEntry:
    """记录模型执行的历史快照。"""
    timestamp: datetime
    event: str
    sample_count: int
    metric: float = 0.0


class ModelConfig(ABC):
    """模型配置基类，提供参数初始化与验证。"""

    def __init__(self, **kwargs: Any) -> None:
        self._params = self._init_params()
        if kwargs:
            self._params.update(kwargs)
        self._validate_params()

    @abstractmethod
    def _init_params(self) -> Dict[str, Any]:
        """初始化基础参数配置。"""
        raise NotImplementedError

    @abstractmethod
    def _validate_params(self) -> None:
        """参数合法性校验。"""
        raise NotImplementedError

    @property
    def params(self) -> Dict[str, Any]:
        """只读参数字典。"""
        return dict(self._params)


class ModelBase(ABC):
    """线程安全的模型抽象基类，提供参数管理、历史记录追踪与状态重置。"""

    def __init__(self, config: ModelConfig) -> None:
        self._params = config.params
        self._iterations: int = 0
        self._converged: bool = False
        self._history: deque[ModelHistoryEntry] = deque(
            maxlen=self._params.get("history_maxlen", 1000)
        )
        self._lock = RLock()
        self._model_state: Optional[Dict[str, Any]] = None

    def fit(self, data: Sequence[Any], **kwargs: Any) -> Dict[str, Any]:
        """训练模型，内部调用 _compute 并记录历史。"""
        with self._lock:
            self._iterations = 0
            self._converged = False
            logger.info("开始模型拟合，样本数: %d", len(data))
            self._validate_input(data)
            try:
                result = self._compute(data, **kwargs)
            except Exception as e:
                logger.error("模型拟合失败: %s", str(e))
                raise
            final_loss = result.get("final_loss", 0.0)
            self._history.append(
                ModelHistoryEntry(datetime.now(), "fit", len(data), final_loss)
            )
            return result

    def predict(self, data: Sequence[Any]) -> Any:
        """根据已训练模型执行预测。"""
        with self._lock:
            if self._model_state is None:
                logger.warning("模型尚未训练，返回空预测")
                return None
            self._validate_input(data)
            try:
                return self._predict_impl(data)
            except Exception as e:
                logger.error("模型预测失败: %s", str(e))
                raise

    @abstractmethod
    def _compute(self, data: Sequence[Any], **kwargs: Any) -> Dict[str, Any]:
        """核心计算逻辑，由子类实现。"""
        raise NotImplementedError

    @abstractmethod
    def _predict_impl(self, data: Sequence[Any]) -> Any:
        """预测实现逻辑，由子类实现。"""
        raise NotImplementedError

    @abstractmethod
    def _validate_input(self, data: Sequence[Any]) -> None:
        """验证输入数据是否符合模型要求。"""
        raise NotImplementedError

    def get_params(self) -> Dict[str, Any]:
        """返回当前模型参数的只读副本。"""
        return dict(self._params)

    def set_param(self, key: str, value: Any) -> None:
        """设置单个模型参数（需先验证合法性）。"""
        self._params[key] = value

    def get_history(self) -> List[ModelHistoryEntry]:
        """返回历史记录列表。"""
        return list(self._history)

    def reset(self) -> None:
        """重置模型状态到初始值。"""
        with self._lock:
            self._iterations = 0
            self._converged = False
            self._history.clear()
            self._model_state = None
            logger.debug("模型状态已重置")

    def to_dict(self) -> Dict[str, Any]:
        """将模型序列化为字典形式。"""
        return {
            "name": self.__class__.__name__,
            "params": dict(self._params),
            "iterations": self._iterations,
            "converged": self._converged,
            "history": list(self._history),
        }


class GradientDescentModel(ModelBase):
    """梯度下降算法基类，封装线性与逻辑回归共有的迭代逻辑。"""

    def __init__(self, config: "GradientDescentConfig") -> None:
        super().__init__(config)
        self._params["w"] = [0.0]
        self._params["b"] = 0.0
        self._params.setdefault("check_interval", 10)

    def _loss_and_gradients(
        self,
        x: Sequence[float],
        y: float,
        w: Sequence[float],
        b: float,
        weight_decay: float,
    ) -> Tuple[float, List[float], float]:
        """计算损失和梯度。子类实现具体的损失函数。"""
        raise NotImplementedError

    def _compute(self, data: Sequence[Tuple[Sequence[float], float]], **kwargs: Any) -> Dict[str, Any]:
        """通用梯度下降迭代过程。"""
        lr = self._params["learning_rate"]
        max_iter = self._params["max_iterations"]
        tol = self._params["tolerance"]
        weight_decay = self._params.get("weight_decay", 0.0)
        check_interval = self._params.get("check_interval", 10)

        if not data:
            raise ValueError("训练数据不能为空")

        num_features = len(data[0][0])
        w = [0.0] * num_features
        b = 0.0
        prev_loss = float("inf")
        self._model_state = {"iterations": 0, "converged": False}

        for i in range(max_iter):
            self._iterations += 1
            # 批量处理：对整个数据集计算梯度
            total_dw = [0.0] * num_features
            total_db = 0.0
            current_loss = 0.0

            for x, y in data:
                loss, dw, db = self._loss_and_gradients(x, y, w, b, weight_decay)
                current_loss += loss
                for j in range(num_features):
                    total_dw[j] += dw[j]
                total_db += db

            n = len(data)
            current_loss /= n
            for j in range(num_features):
                total_dw[j] /= n
            total_db /= n

            for j in range(num_features):
                w[j] -= lr * total_dw[j]
            b -= lr * total_db

            if i % check_interval == 0:
                logger.info("迭代 %d，当前损失: %.6f", i + 1, current_loss)
                self._history.append(
                    ModelHistoryEntry(datetime.now(), "iter", len(data), current_loss)
                )

            if abs(prev_loss - current_loss) < tol:
                self._converged = True
                break
            prev_loss = current_loss

        self._params["w"] = w
        self._params["b"] = b
        self._model_state["iterations"] = self._iterations
        self._model_state["converged"] = self._converged
        return {
            "iterations": self._iterations,
            "converged": self._converged,
            "final_loss": prev_loss,
        }

    def _validate_input(self, data: Sequence[Tuple[Sequence[float], float]]) -> None:
        """验证输入数据是否符合线性回归要求。"""
        if not isinstance(data, Sequence):
            raise ValueError("输入数据必须为特征-标签元组序列")
        if len(data) == 0:
            raise ValueError("输入数据不能为空")
        num_features = None
        for x, y in data:
            if not isinstance(x, Sequence):
                raise ValueError("特征向量必须为序列类型")
            if num_features is None:
                num_features = len(x)
            elif len(x) != num_features:
                raise ValueError("所有特征向量维度必须一致")
            for v in x:
                if not isinstance(v, (int, float)):
                    raise ValueError("特征值必须为数值类型")
            if not isinstance(y, (int, float)):
                raise ValueError("标签必须为数值类型")


class GradientDescentConfig(ModelConfig):
    """梯度下降模型通用配置基类。"""

    def _init_params(self) -> Dict[str, Any]:
        return {
            "learning_rate": 0.01,
            "max_iterations": 100,
            "tolerance": 1e-06,
            "history_maxlen": 1000,
            "weight_decay": 0.0,
            "check_interval": 10,
        }

    def _validate_params(self) -> None:
        lr = self._params.get("learning_rate", 0.01)
        max_iter = self._params.get("max_iterations", 100)
        tol = self._params.get("tolerance", 1e-06)
        if not (0 < lr <= 1):
            raise ValueError("学习率必须在(0,1]范围内")
        if max_iter <= 0:
            raise ValueError("最大迭代次数必须大于0")
        if tol <= 0:
            raise ValueError("收敛阈值必须大于0")


class LinearRegressionConfig(GradientDescentConfig):
    """线性回归模型专属配置类。"""

    def _init_params(self) -> Dict[str, Any]:
        return {
            "learning_rate": 0.01,
            "max_iterations": 100,
            "tolerance": 1e-06,
            "history_maxlen": 1000,
            "weight_decay": 0.0,
            "check_interval": 10,
        }

    def _validate_params(self) -> None:
        super()._validate_params()


class LinearRegressionModel(GradientDescentModel):
    """线性回归模型，使用带正则化的梯度下降迭代最小化均方误差损失函数。"""

    def __init__(self, config: LinearRegressionConfig) -> None:
        super().__init__(config)

    def _loss_and_gradients(
        self,
        x: Sequence[float],
        y: float,
        w: Sequence[float],
        b: float,
        weight_decay: float,
    ) -> Tuple[float, List[float], float]:
        """计算线性回归的MSE损失和梯度。"""
        num_features = len(w)
        prediction = sum(w[i] * x[i] for i in range(num_features)) + b
        error = prediction - y
        squared_error = error * error
        regularization = weight_decay * sum(wi * wi for wi in w)
        loss = squared_error + regularization

        dw = [2 * error * x[i] + 2 * weight_decay * w[i] for i in range(num_features)]
        db = 2 * error
        return loss, dw, db

    def _predict_impl(self, data: Sequence[Sequence[float]]) -> List[float]:
        """对一批特征向量执行线性回归预测。"""
        w = self._params.get("w", [0.0])
        b = self._params.get("b", 0.0)
        results = []
        for x in data:
            pred = sum(w[i] * x[i] for i in range(len(w))) + b
            results.append(pred)
        return results


class LogisticRegressionConfig(LinearRegressionConfig):
    """逻辑回归模型专属配置类。"""

    def _init_params(self) -> Dict[str, Any]:
        params = super()._init_params()
        params["tolerance"] = 1e-05
        return params

    def _validate_params(self) -> None:
        super()._validate_params()
        tol = self._params.get("tolerance", 1e-05)
        if tol <= 1e-08:
            raise ValueError("逻辑回归收敛阈值需大于1e-8")


class LogisticRegressionModel(GradientDescentModel):
    """逻辑回归模型，使用带样本权重的逻辑损失函数。"""

    def __init__(self, config: LogisticRegressionConfig) -> None:
        super().__init__(config)

    def _loss_and_gradients(
        self,
        x: Sequence[float],
        y: float,
        w: Sequence[float],
        b: float,
        weight_decay: float,
    ) -> Tuple[float, List[float], float]:
        """计算逻辑回归的交叉熵损失和梯度。"""
        num_features = len(w)
        z = sum(w[i] * x[i] for i in range(num_features)) + b
        # 数值稳定的sigmoid计算
        if z >= 0:
            exp_neg_z = math.exp(-z)
            sigmoid = 1.0 / (1.0 + exp_neg_z)
        else:
            exp_z = math.exp(z)
            sigmoid = exp_z / (1.0 + exp_z)

        error = sigmoid - y
        eps = 1e-15
        clipped_sigmoid = max(eps, min(1 - eps, sigmoid))
        loss = -(y * math.log(clipped_sigmoid) + (1 - y) * math.log(1 - clipped_sigmoid))
        regularization = weight_decay * sum(wi * wi for wi in w)
        loss += regularization

        dw = [error * x[i] + 2 * weight_decay * w[i] for i in range(num_features)]
        db = error
        return loss, dw, db

    def _validate_input(self, data: Sequence[Tuple[Sequence[float], float]]) -> None:
        """验证逻辑回归输入数据。"""
        super()._validate_input(data)
        for _, y in data:
            if not (0.0 <= y <= 1.0):
                raise ValueError("逻辑回归标签必须在[0, 1]范围内")

    def _predict_impl(self, data: Sequence[Sequence[float]]) -> List[float]:
        """对一批特征向量执行逻辑回归预测，返回概率值。"""
        w = self._params.get("w", [0.0])
        b = self._params.get("b", 0.0)
        results = []
        for x in data:
            z = sum(w[i] * x[i] for i in range(min(len(w), len(x)))) + b
            if z >= 0:
                exp_neg_z = math.exp(-z)
                prob = 1.0 / (1.0 + exp_neg_z)
            else:
                exp_z = math.exp(z)
                prob = exp_z / (1.0 + exp_z)
            results.append(prob)
        return results


class ExponentialSmootherConfig(ModelConfig):
    """指数平滑预测器配置类。"""

    def _init_params(self) -> Dict[str, Any]:
        return {
            "alpha": 0.9,
            "window_size": 10,
            "history_maxlen": 1000,
        }

    def _validate_params(self) -> None:
        alpha = self._params.get("alpha", 0.9)
        window_size = self._params.get("window_size", 10)
        if not (0 < alpha <= 1):
            raise ValueError("平滑因子必须在(0,1]范围内")
        if window_size <= 0:
            raise ValueError("窗口大小必须大于0")


class ExponentialSmoother(ModelBase):
    """指数平滑预测器，使用带滑动窗口的加权均值进行平滑。"""

    def __init__(self, config: ExponentialSmootherConfig) -> None:
        super().__init__(config)
        self._params["alpha"] = self._params.get("alpha", 0.9)
        self._params["window_size"] = self._params.get("window_size", 10)

    def _validate_input(self, data: Sequence[float]) -> None:
        """验证输入数据为浮点数序列。"""
        if not isinstance(data, Sequence):
            raise ValueError("输入数据必须为序列类型")
        for v in data:
            if not isinstance(v, (int, float)):
                raise ValueError("输入数据元素必须为数值类型")

    def _compute(self, data: Sequence[float], **kwargs: Any) -> Dict[str, Any]:
        """执行指数平滑计算，返回平滑后的序列。"""
        if not data:
            raise ValueError("数据不能为空")

        alpha = self._params.get("alpha", 0.9)
        window_size = self._params.get("window_size", 10)
        smoothed: List[float] = []

        # 使用滚动窗口计算加权平均
        window: deque[float] = deque(maxlen=window_size)
        smoothed_value = 0.0

        for val in data:
            window.append(float(val))
            if len(window) < window_size:
                # 窗口未满时使用简单均值
                smoothed_value = sum(window) / len(window)
            else:
                # 窗口满后使用指数平滑递推公式
                smoothed_value = alpha * smoothed_value + (1 - alpha) * val
            smoothed.append(smoothed_value)

        metric = sum(smoothed) / len(smoothed) if smoothed else 0.0
        self._history.append(
            ModelHistoryEntry(datetime.now(), "fit", len(data), metric)
        )
        self._model_state = {"smoothed_last": smoothed[-1] if smoothed else 0.0}
        return {
            "smoothed_values": smoothed,
            "final_loss": metric,
        }

    def _predict_impl(self, data: Sequence[float]) -> float:
        """基于最近数据预测下一个值。"""
        if not data:
            raise ValueError("预测数据不能为空")
        alpha = self._params.get("alpha", 0.9)
        window_size = self._params.get("window_size", 10)

        # 使用最近window_size个点计算加权预测
        recent = list(data[-window_size:]) if len(data) >= window_size else list(data)
        if not recent:
            return 0.0
        # 指数权重：越新的点权重越大
        weights = [alpha ** (len(recent) - 1 - i) for i in range(len(recent))]
        weight_sum = sum(weights)
        if weight_sum == 0:
            return recent[-1]
        prediction = sum(w * v for w, v in zip(weights, recent)) / weight_sum
        return prediction


class ARIMAForecasterConfig(ModelConfig):
    """ARIMA预测器配置类。"""

    def _init_params(self) -> Dict[str, Any]:
        return {
            "p": 1,
            "d": 1,
            "q": 1,
            "history_maxlen": 1000,
        }

    def _validate_params(self) -> None:
        p = self._params.get("p", 1)
        d = self._params.get("d", 1)
        q = self._params.get("q", 1)
        if not (0 <= p <= 5):
            raise ValueError("ARIMA参数p必须在0-5之间")
        if d < 0 or d > 2:
            raise ValueError("差分阶数d必须在0-2之间")
        if not (0 <= q <= 5):
            raise ValueError("ARIMA参数q必须在0-5之间")


class ARIMAForecaster(ModelBase):
    """ARIMA预测器，实现带差分、自回归和滑动平均的时间序列预测。"""

    def __init__(self, config: ARIMAForecasterConfig) -> None:
        super().__init__(config)
        self._residuals: List[float] = []
        self._phi: List[float] = []
        self._theta: List[float] = []
        self._last_differenced: List[float] = []

    def _validate_input(self, data: Sequence[float]) -> None:
        """验证ARIMA输入数据。"""
        if not isinstance(data, Sequence):
            raise ValueError("输入数据必须为序列类型")
        for v in data:
            if not isinstance(v, (int, float)):
                raise ValueError("输入数据元素必须为数值类型")
        d = self._params.get("d", 1)
        p = self._params.get("p", 1)
        q = self._params.get("q", 1)
        min_length = d + max(p, q) + 1
        if len(data) < min_length:
            raise ValueError(
                f"数据长度({len(data)})不足差分阶数({d})加最大阶数({max(p, q)})要求({min_length})"
            )

    def _apply_differencing(self, data: Sequence[float], d: int) -> List[float]:
        """对序列应用d阶差分。"""
        result: List[float] = [float(v) for v in data]
        for _ in range(d):
            result = [result[i + 1] - result[i] for i in range(len(result) - 1)]
        return result

    def _estimate_ar_coefficients(
        self, series: Sequence[float], order: int
    ) -> List[float]:
        """使用简单的自相关方法估计AR系数。"""
        if order == 0 or len(series) <= order:
            return [0.0] * order
        n = len(series)
        mean_val = sum(series) / n
        centered = [v - mean_val for v in series]

        phi: List[float] = []
        for k in range(1, order + 1):
            num = sum(centered[i] * centered[i - k] for i in range(k, n))
            den = sum(c * c for c in centered)
            if den > 1e-15:
                phi.append(num / den)
            else:
                phi.append(0.0)
        return phi

    def _estimate_ma_coefficients(
        self, residuals: Sequence[float], order: int
    ) -> List[float]:
        """估计MA系数，简化为残差自相关。"""
        if order == 0 or len(residuals) <= order:
            return [0.0] * order
        n = len(residuals)
        mean_val = sum(residuals) / n
        centered = [v - mean_val for v in residuals]

        theta: List[float] = []
        for k in range(1, order + 1):
            num = sum(centered[i] * centered[i - k] for i in range(k, n))
            den = sum(c * c for c in centered)
            if den > 1e-15:
                theta.append(num / den)
            else:
                theta.append(0.0)
        return theta

    def _compute(self, data: Sequence[float], **kwargs: Any) -> Dict[str, Any]:
        """执行ARIMA拟合，估计系数并计算残差。"""
        p = self._params.get("p", 1)
        d = self._params.get("d", 1)
        q = self._params.get("q", 1)

        # 差分
        differenced = self._apply_differencing(data, d)
        self._last_differenced = differenced

        if len(differenced) == 0:
            raise ValueError("差分后数据为空，无法进行ARMA估计")

        # 估计AR系数
        self._phi = self._estimate_ar_coefficients(differenced, p)
        logger.info("AR系数估计完成: %s", self._phi)

        # 初步计算残差（用AR部分）
        initial_residuals: List[float] = []
        for i in range(len(differenced)):
            pred = 0.0
            for j in range(1, p + 1):
                if i >= j:
                    pred += self._phi[j - 1] * differenced[i - j]
            initial_residuals.append(differenced[i] - pred)

        # 估计MA系数
        self._theta = self._estimate_ma_coefficients(initial_residuals, q)
        logger.info("MA系数估计完成: %s", self._theta)

        # 最终残差计算
        residuals: List[float] = []
        prev_values: List[float] = []
        prev_residuals: List[float] = []

        for i in range(len(differenced)):
            ar_part = 0.0
            for j in range(1, p + 1):
                if i >= j:
                    ar_part += self._phi[j - 1] * differenced[i - j]

            ma_part = 0.0
            for j in range(1, q + 1):
                if i >= j:
                    ma_part += self._theta[j - 1] * initial_residuals[i - j]

            pred = ar_part - ma_part
            residuals.append(differenced[i] - pred)
            prev_values.append(differenced[i])
            prev_residuals.append(initial_residuals[i])

        self._residuals = residuals

        # 计算最终指标：残差均方根
        final_loss = math.sqrt(sum(r * r for r in residuals) / len(residuals)) if residuals else 0.0

        self._model_state = {
            "residuals": residuals,
            "phi": self._phi,
            "theta": self._theta,
            "last_differenced": differenced,
        }

        self._history.append(
            ModelHistoryEntry(datetime.now(), "fit", len(data), final_loss)
        )

        return {
            "iterations": 1,
            "converged": True,
            "final_loss": final_loss,
            "residuals": residuals,
            "ar_coefficients": self._phi,
            "ma_coefficients": self._theta,
        }

    def _predict_impl(self, data: Sequence[float]) -> float:
        """基于ARIMA模型预测下一个值。"""
        if not self._model_state:
            raise ValueError("模型未训练，无法进行预测")

        residuals = self._model_state.get("residuals", [])
        phi = self._model_state.get("phi", [0.0])
        theta = self._model_state.get("theta", [0.0])
        last_differenced = self._model_state.get("last_differenced", [])

        if not last_differenced:
            return 0.0

        p = len(phi)
        q = len(theta)

        # AR部分
        ar_part = 0.0
        for j in range(1, p + 1):
            if len(last_differenced) >= j:
                ar_part += phi[j - 1] * last_differenced[-j]

        # MA部分
        ma_part = 0.0
        for j in range(1, q + 1):
            if len(residuals) >= j:
                ma_part += theta[j - 1] * residuals[-j]

        predicted_differenced = ar_part - ma_part

        # 反差分：如果d>0，需要累积
        d = self._params.get("d", 1)
        if d == 1:
            last_value = data[-1]
            return last_value + predicted_differenced
        elif d == 2:
            # 假设二次差分，简单处理
            if len(data) >= 2:
                first_diff = data[-1] - data[-2]
                return data[-1] + first_diff + predicted_differenced
            else:
                return predicted_differenced
        else:
            return predicted_differenced
