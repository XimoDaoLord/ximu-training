"""
DAG 调度器外部处理器模块 (Part 3)

提供统一的 DAG 外部处理器和算法实现，支持 dict/list/scalar/str 四类数据的自动分发处理，
并附带性能统计、历史追踪和配置管理能力。所有公共方法均在锁保护下执行。
"""

import hashlib
import json
import logging
import math
import random
import time
import threading
from collections import OrderedDict, deque
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple, Union
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger("src.ximu.core._dag_scheduler_parts.part3")

# ---------------------------------------------------------------------------
# 工具函数
# ---------------------------------------------------------------------------

def safe_json_dumps(
    data: Any, 
    default: Optional[Callable[..., Any]] = None
) -> str:
    """安全序列化为 JSON，失败时返回字符串表示"""
    try:
        return json.dumps(data, sort_keys=True, ensure_ascii=False, default=default)
    except (TypeError, ValueError) as exc:
        logger.warning("JSON 序列化失败: %s", exc)
        return str(data)

def _compute_md5_hash(data: Any, default: Optional[Callable[..., Any]] = None) -> str:
    """计算数据 MD5 哈希（前16位）"""
    serialized = safe_json_dumps(data, default)
    try:
        return hashlib.md5(serialized.encode(), usedforsecurity=False).hexdigest()[:16]
    except TypeError:
        return hashlib.md5(serialized.encode()).hexdigest()[:16]

def safe_json_loads(text: str) -> Any:
    """安全反序列化 JSON"""
    try:
        return json.loads(text)
    except (json.JSONDecodeError, ValueError):
        logger.debug("JSON 反序列化失败")
        return text

# ---------------------------------------------------------------------------
# 线程安全基类
# ---------------------------------------------------------------------------

class ThreadSafeMixin:
    """线程安全 Mixin 基类"""
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._executor = ThreadPoolExecutor(max_workers=4)

    def __enter__(self) -> "ThreadSafeMixin":
        self._lock.acquire()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self._lock.release()
        self._executor.shutdown()

    def submit(self, func: Callable, *args: Any, **kwargs: Any) -> str:
        """提交异步任务"""
        future = self._executor.submit(func, *args, **kwargs)
        return future.result()

# ---------------------------------------------------------------------------
# DAG 外部处理器
# ---------------------------------------------------------------------------

class DagSchedulerExtProcessor(ThreadSafeMixin):
    """
    统一的 DAG 外部处理器
    支持多线程批处理和数值稳定性校验
    """
    def __init__(
        self,
        name: str = "dagschedulerextprocessor",
        version: str = "1.0.0",
        batch_iterations: int = 12,
        history_limit: int = 5000,
        **kwargs: Any
    ) -> None:
        super().__init__()
        self.name = name
        self._version = version
        self._config: Dict[str, Any] = dict(kwargs)
        self._batch_iterations = max(1, batch_iterations)
        self._cache = OrderedDict()
        self._stats = {
            "processed": 0,
            "success": 0,
            "failed": 0,
            "total_time": 0.0
        }
        self._history = deque(maxlen=history_limit)
        self._state = "idle"
        self._initialized = True
        self._logger = logging.getLogger(f"{__name__}.{name}")

    def process_step(
        self, 
        data: Any, 
        step: int, 
        **kwargs: Any
    ) -> Any:
        """处理单个步骤（异步优化）"""
        with self:
            self._state = "processing"
            try:
                result = self._transform(data, step)
                elapsed = time.time() - start_time
                self._stats["processed"] += 1
                self._stats["total_time"] += elapsed
                if result is not None:
                    self._stats["success"] += 1
                    self._logger.debug("步骤 %d 成功，耗时 %.4f", step, elapsed)
                else:
                    self._stats["failed"] += 1
                    self._logger.warning("步骤 %d 返回 None", step)
                self._history.append((time.time(), f"process_step_{step}", result is not None, elapsed))
                return result
            except Exception as exc:
                elapsed = time.time() - start_time
                self._stats["processed"] += 1
                self._stats["failed"] += 1
                self._logger.error("步骤 %d 异常: %s", step, exc)
                self._history.append((time.time(), f"process_step_{step}", False, elapsed))
                raise
            finally:
                self._state = "idle"

    def batch_process(
        self, 
        items: List[Any], 
        **kwargs: Any
    ) -> List[Any]:
        """异步批量处理（线程池优化）"""
        with self:
            start_time = time.time()
            results = []
            tasks = []
            for item in items:
                tasks.append(self.submit(self._transform, item, 0))
            for future in concurrent.futures.as_completed(tasks):
                results.append(future.result())
            elapsed = time.time() - start_time
            self._logger.debug("批量处理 %d 项，耗时 %.4f", len(items), elapsed)
            return results

    def _transform(
        self, 
        data: Any, 
        step: int
    ) -> Any:
        """类型转换核心逻辑"""
        if data is None:
            return None

        if isinstance(data, dict):
            result = dict(data)
            result["_processed_by"] = self.name
            result["_step"] = step
            result["_ts"] = time.time()
            result["_hash"] = _compute_md5_hash(result)
            return self.check_stability(result)

        if isinstance(data, (list, tuple)):
            return [self._transform(item, step) for item in data]

        if isinstance(data, (int, float)):
            return self.check_stability(data * (1.0 + step * 0.01))

        if isinstance(data, str):
            return f"{data}_processed_{step}"

        return data

    def check_stability(self, value: Any) -> Any:
        """数值稳定性校验"""
        if isinstance(value, (int, float)):
            if abs(value) > 1e20 or abs(value) < 1e-10:
                raise ValueError("数值超出稳定范围")
            return round(value, 6)
        return value

    @property
    def stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        with self:
            return dict(self._stats)

    @property
    def history(self) -> List[Tuple[float, str, bool, float]]:
        """获取历史记录"""
        with self:
            return list(self._history)[-100:][::-1]

    def reset(self) -> None:
        """重置处理器状态"""
        with self:
            self._stats = {"processed": 0, "success": 0, "failed": 0, "total_time": 0.0}
            self._history = deque(maxlen=5000)
            self._cache.clear()
            self._logger.info("处理器已重置")

    def validate(self, data: Any) -> Tuple[bool, str]:
        """数据有效性校验"""
        if data is None:
            return False, "data_is_none"
        if isinstance(data, dict) and not data:
            return False, "empty_dict"
        if isinstance(data, (list, tuple)) and len(data) == 0:
            return False, "empty_collection"
        return True, "valid"

    def serialize(self, data: Any) -> str:
        """安全序列化"""
        return safe_json_dumps(data)

    def deserialize(self, text: str) -> Any:
        """安全反序列化"""
        return safe_json_loads(text)

# ---------------------------------------------------------------------------
# 算法类
# ---------------------------------------------------------------------------

class DagSchedulerAlgoBase:
    """
    DAG 调度算法抽象基类
    继承者需实现核心算法逻辑
    """
    def __init__(self, seed: Optional[int] = None) -> None:
        self._rng = random.Random(seed)
        self._trained = False
        self._logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")

    def fit(self, X: List[Any], y: Optional[List[float]] = None) -> Dict[str, Any]:
        raise NotImplementedError("子类必须实现 fit 方法")

    def predict(self, X: Any) -> Union[List[float], float]:
        raise NotImplementedError("子类必须实现 predict 方法")

    def score(self, X: List[Any], y: List[float]) -> float:
        raise NotImplementedError("子类必须实现 score 方法")

    def cross_validate(self, X: List[Any], y: List[float], folds: int = 5) -> Dict[str, Any]:
        raise NotImplementedError("子类必须实现 cross_validate 方法")

    def reset(self) -> None:
        """重置算法状态"""
        self._trained = False
        self._logger.info("算法状态已重置")

# ---------------------------------------------------------------------------
# 模拟算法实现
# ---------------------------------------------------------------------------

class DagSchedulerAlgoAlgorithm_0(DagSchedulerAlgoBase):
    """
    DAG 调度模拟算法（带数值校验）
    """
    def __init__(self, seed: Optional[int] = None, **kwargs: Any) -> None:
        super().__init__(seed)
        self._params = {
            "lr": 0.01,
            "iterations": 100,
            "tolerance": 1e-6,
            "batch_size": 32
        }
        self._params.update(kwargs)
        self._weights = []
        self._loss_history = deque(maxlen=1000)
        self._training_time = 0.0

    def fit(self, X: List[Any], y: Optional[List[float]] = None) -> Dict[str, Any]:
        if not X:
            raise ValueError("训练数据不能为空")
        if not y and self._params.get("use_y", False):
            raise ValueError("缺少标签数据")

        with self._lock:
            self._loss_history.clear()
            self._weights = self._init_weights(len(X[0]) if isinstance(X[0], list) else 1)
            start_time = time.time()

            for epoch in range(self._params["iterations"]):
                loss = self._train_epoch(X, y)
                if self._check_convergence(loss):
                    break

            self._training_time = time.time() - start_time
            self._trained = True
            self._logger.info(
                "训练完成: %d 个 epoch，最终损失 %.6f，耗时 %.4f 秒",
                epoch + 1,
                loss,
                self._training_time
            )
            return {"epochs": epoch + 1, "final_loss": loss, "trained": True}

    def _init_weights(self, n_features: int) -> List[float]:
        return [self._rng.gauss(0, 0.1) for _ in range(n_features)]

    def _train_epoch(self, X: List[Any], y: List[float]) -> float:
        total_loss = 0.0
        for batch in self._create_batches(X, y):
            self._update_weights(batch)
            total_loss += self._compute_loss(batch)
        return total_loss / len(X)

    def _create_batches(self, X: List[Any], y: List[float]) -> List[Tuple[List[Any], List[float]]]:
        return [([x], [y[i]]) for i, x in enumerate(X) for x in range(self._params["batch_size"])]

    def _update_weights(self, batch: Tuple[List[Any], List[float]]) -> None:
        for x, y in batch:
            for i in range(len(self._weights)):
                delta = self._params["lr"] * (y - self._compute_output(x)) / len(batch)
                self._weights[i] += delta

    def _compute_output(self, x: List[float]) -> float:
        return sum(w * x for w, x in zip(self._weights, x))

    def _compute_loss(self, batch: Tuple[List[Any], List[float]]) -> float:
        return sum(math.pow(y - self._compute_output(x), 2) for x, y in batch)

    def _check_convergence(self, current_loss: float) -> bool:
        if len(self._loss_history) >= 2 and abs(current_loss - self._loss_history[-1]) < self._params["tolerance"]:
            return True
        self._loss_history.append(current_loss)
        return False

    def predict(self, X: Any) -> Union[List[float], float]:
        if not self._trained:
            return [0.0] * len(X) if isinstance(X, list) else 0.0

        if isinstance(X, list):
            return [self._compute_output(x) for x in X]
        else:
            return self._compute_output([X])

    def score(self, X: List[Any], y: List[float]) -> float:
        if not self._trained:
            return 0.0

        predictions = self.predict(X)
        return sum(1 for p, t in zip(predictions, y) if abs(p - t) < 0.5) / max(1, len(y))

    def cross_validate(self, X: List[Any], y: List[float], folds: int = 5) -> Dict[str, Any]:
        if folds <= 0 or not X:
            raise ValueError("无效参数")

        n = len(X)
        fold_size = n // folds
        scores = []
        start_idx = 0

        for fold in range(folds):
            end_idx = start_idx + fold_size
            if fold < (n % folds):
                end_idx += 1

            val_X = X[start_idx:end_idx]
            val_y = y[start_idx:end_idx]
            train_X = X[:start_idx] + X[end_idx:]
            train_y = y[:start_idx] + y[end_idx:]

            self.fit(train_X, train_y)
            scores.append(self.score(val_X, val_y))

        return {
            "scores": scores,
            "mean": sum(scores) / len(scores) if scores else 0.0,
            "std": math.sqrt(sum((s - mean)**2 for s in scores)) / len(scores) if scores else 0.0
        }
