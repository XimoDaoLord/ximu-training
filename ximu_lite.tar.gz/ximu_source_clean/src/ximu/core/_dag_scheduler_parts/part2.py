import logging
import threading
import time
from collections import OrderedDict
from typing import Any, Dict, Generic, List, Optional, Tuple, Type, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar('T')

def now_timestamp() -> float:
    """获取当前时间戳。

    Returns:
        当前 Unix 时间戳（浮点数，秒）。
    """
    return time.time()

class BaseStore(Generic[T]):
    """基于TTL和LRU策略的线程安全内存缓存基类。

    提供统一的 put、get、remove、contains、keys、values、items、
    cleanup、clear 等接口，支持自动后台清理过期条目。
    消除原有代码中 MetricStore、LogStore、StateStore 等类的重复逻辑。

    Attributes:
        name (str): 存储名称，用于日志和统计信息。
        max_size (int): 最大容量，超过此值将触发LRU淘汰。
        ttl (float): 生存时间（秒），超过此时间的条目将失效。
    """

    def __init__(self, name: str, max_size: int = 10000, ttl: float = 3600.0,
                 auto_cleanup_interval: float = 300.0) -> None:
        """初始化存储实例。

        Args:
            name: 存储名称，用于日志和统计信息。
            max_size: 最大容量，超过此值将触发LRU淘汰。
            ttl: 生存时间（秒），超过此时间的条目将在访问或清理时失效。
            auto_cleanup_interval: 自动清理间隔（秒），设为0则禁用自动清理。
        """
        self._name = name
        self._store: "OrderedDict[str, Tuple[T, float]]" = OrderedDict()
        self._max_size = max_size
        self._ttl = ttl
        self._auto_cleanup_interval = auto_cleanup_interval
        self._lock = threading.RLock()

        # 统计信息
        self._hits = 0
        self._misses = 0
        self._evictions = 0
        self._total_writes = 0
        self._total_cleanups = 0

        # 自动清理线程相关
        self._cleanup_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._cleanup_interval_lock = threading.Lock()

        if auto_cleanup_interval > 0:
            self._start_auto_cleanup()
            logger.debug(f"初始化 {self._name} 存储: max_size={max_size}, ttl={ttl}s, "
                         f"auto_cleanup_interval={auto_cleanup_interval}s")
        else:
            logger.debug(f"初始化 {self._name} 存储: max_size={max_size}, ttl={ttl}s, "
                         f"auto_cleanup disabled")

    def _start_auto_cleanup(self) -> None:
        """启动后台自动清理线程。"""
        self._stop_event.clear()
        self._cleanup_thread = threading.Thread(
            target=self._auto_cleanup_loop,
            name=f"{self._name}-cleanup",
            daemon=True
        )
        self._cleanup_thread.start()

    def _stop_auto_cleanup(self) -> None:
        """停止后台自动清理线程。"""
        self._stop_event.set()
        if self._cleanup_thread and self._cleanup_thread.is_alive():
            self._cleanup_thread.join(timeout=5.0)
            self._cleanup_thread = None

    def _auto_cleanup_loop(self) -> None:
        """自动清理循环，按固定间隔执行清理。"""
        while not self._stop_event.is_set():
            try:
                self._stop_event.wait(timeout=self._auto_cleanup_interval)
                if self._stop_event.is_set():
                    break
                self.cleanup()
            except Exception as e:
                logger.error(f"{self._name}: 自动清理线程异常: {e}", exc_info=True)

    def _is_expired(self, timestamp: float) -> bool:
        """判断条目是否已过期。

        Args:
            timestamp: 条目的写入时间戳。

        Returns:
            如果条目已过期则返回 True，否则返回 False。
        """
        return (now_timestamp() - timestamp) > self._ttl

    def put(self, key: str, value: T) -> None:
        """写入键值对。

        如果键已存在，则更新值并移至末尾（更新LRU状态）。
        如果超出最大容量，则淘汰最久未使用的条目。

        Args:
            key: 键。
            value: 值。
        """
        with self._lock:
            self._store[key] = (value, now_timestamp())
            self._store.move_to_end(key)
            self._total_writes += 1

            if len(self._store) > self._max_size:
                evicted_key, _ = self._store.popitem(last=False)
                self._evictions += 1
                logger.debug(f"{self._name}: 淘汰键 '{evicted_key}' (容量限制)")

    def get(self, key: str, default: Optional[T] = None) -> Optional[T]:
        """根据键获取值。

        如果键存在且未过期，返回值并更新LRU状态。
        如果键过期或不存在，返回默认值。

        Args:
            key: 查找键。
            default: 键不存在或过期时返回的默认值。

        Returns:
            对应的值，或默认值。
        """
        with self._lock:
            if key in self._store:
                value, ts = self._store[key]
                if not self._is_expired(ts):
                    self._store.move_to_end(key)
                    self._hits += 1
                    return value
                else:
                    self._store.pop(key, None)
                    logger.debug(f"{self._name}: 键 '{key}' 已过期")
            self._misses += 1
            return default

    def remove(self, key: str) -> bool:
        """移除指定键。

        Args:
            key: 要移除的键。

        Returns:
            如果键存在并成功移除则返回 True，否则返回 False。
        """
        with self._lock:
            if key in self._store:
                del self._store[key]
                return True
            return False

    def contains(self, key: str) -> bool:
        """检查键是否存在且未过期。

        Args:
            key: 要检查的键。

        Returns:
            如果键存在且未过期则返回 True，否则返回 False。
        """
        with self._lock:
            if key in self._store:
                _, ts = self._store[key]
                if not self._is_expired(ts):
                    return True
                else:
                    self._store.pop(key, None)
            return False

    def keys(self) -> List[str]:
        """获取所有未过期的键列表。

        Returns:
            未过期键的列表。
        """
        with self._lock:
            return [k for k, (_, ts) in self._store.items() if not self._is_expired(ts)]

    def values(self) -> List[T]:
        """获取所有未过期的值列表。

        Returns:
            未过期值的列表。
        """
        with self._lock:
            return [v for k, (v, _) in self._store.items() if not self._is_expired(self._store[k][1])]

    def items(self) -> List[Tuple[str, T]]:
        """获取所有未过期的键值对列表。

        Returns:
            未过期键值对的列表。
        """
        with self._lock:
            return [(k, v) for k, (v, ts) in self._store.items() if not self._is_expired(ts)]

    def cleanup(self) -> int:
        """清理所有过期条目。

        Returns:
            被清理的过期条目数量。
        """
        with self._lock:
            expired_keys: List[str] = []
            for key, (_, ts) in self._store.items():
                if self._is_expired(ts):
                    expired_keys.append(key)

            for key in expired_keys:
                self._store.pop(key, None)

            if expired_keys:
                self._total_cleanups += len(expired_keys)
                logger.info(f"{self._name}: 清理了 {len(expired_keys)} 个过期条目")
            return len(expired_keys)

    def clear(self) -> None:
        """清空所有数据及统计信息。"""
        with self._lock:
            self._store.clear()
            self._hits = 0
            self._misses = 0
            self._evictions = 0
            self._total_writes = 0
            self._total_cleanups = 0
            logger.info(f"{self._name}: 存储已清空")

    def __len__(self) -> int:
        """返回当前存储中的条目数量。"""
        with self._lock:
            return len(self._store)

    def __contains__(self, key: str) -> bool:
        """支持 'in' 运算符。"""
        return self.contains(key)

    def __del__(self) -> None:
        """析构函数，停止自动清理线程。"""
        self._stop_auto_cleanup()

    @property
    def hit_rate(self) -> float:
        """计算命中率。"""
        total = self._hits + self._misses
        return self._hits / max(1, total)

    @property
    def size(self) -> int:
        """返回当前存储大小。"""
        return len(self)

    def get_stats(self) -> Dict[str, Any]:
        """获取存储统计信息。

        Returns:
            包含 name, size, max_size, hits, misses, hit_rate, evictions,
            writes, total_cleanups 的字典。
        """
        with self._lock:
            return {
                'name': self._name,
                'size': len(self._store),
                'max_size': self._max_size,
                'ttl': self._ttl,
                'hits': self._hits,
                'misses': self._misses,
                'hit_rate': round(self.hit_rate, 4),
                'evictions': self._evictions,
                'writes': self._total_writes,
                'total_cleanups': self._total_cleanups,
                'auto_cleanup_interval': self._auto_cleanup_interval
            }

    def to_dict(self) -> Dict[str, T]:
        """将存储内容转换为普通字典。

        Returns:
            键值对组成的字典。
        """
        with self._lock:
            return {k: v for k, (v, _) in self._store.items()}

    def __repr__(self) -> str:
        """返回对象的字符串表示。"""
        return (f"{self.__class__.__name__}(name={self._name!r}, size={self.size}, "
                f"max_size={self._max_size}, ttl={self._ttl}s)")

class StoreManager:
    """存储实例集中管理器。

    负责创建、注册和获取不同类型的存储实例，
    避免各Store实例相互独立导致的分散管理。
    所有存储实例共享同一套自动清理机制配置。
    """

    _stores: Dict[str, BaseStore[Any]] = {}
    _lock = threading.RLock()

    @classmethod
    def get_store(cls, name: str, max_size: int = 10000, ttl: float = 3600.0,
                  auto_cleanup_interval: float = 300.0,
                  store_class: Type[BaseStore[T]] = BaseStore) -> BaseStore[T]:
        """获取或创建指定名称的存储实例。

        Args:
            name: 存储实例的唯一名称。
            max_size: 最大容量。
            ttl: 生存时间（秒）。
            auto_cleanup_interval: 自动清理间隔（秒），设为0则禁用自动清理。
            store_class: 存储基类类型，默认为 BaseStore。

        Returns:
            存储实例。
        """
        with cls._lock:
            key = name
            if key not in cls._stores:
                logger.info(f"StoreManager: 创建新存储实例 '{key}', "
                             f"max_size={max_size}, ttl={ttl}s, "
                             f"auto_cleanup={auto_cleanup_interval}s")
                cls._stores[key] = store_class(
                    name=name,
                    max_size=max_size,
                    ttl=ttl,
                    auto_cleanup_interval=auto_cleanup_interval
                )
            return cls._stores[key]

    @classmethod
    def clear_all(cls) -> None:
        """清空所有由管理器创建的存储实例。"""
        with cls._lock:
            for store in cls._stores.values():
                store.clear()
            cls._stores.clear()
            logger.info("StoreManager: 已清空所有存储实例")

    @classmethod
    def get_all_stats(cls) -> Dict[str, Dict[str, Any]]:
        """获取所有存储实例的统计信息。

        Returns:
            以存储名称为键，统计字典为值的映射。
        """
        with cls._lock:
            return {name: store.get_stats() for name, store in cls._stores.items()}

    @classmethod
    def get_store_names(cls) -> List[str]:
        """获取所有已注册存储的名称列表。

        Returns:
            存储名称列表。
        """
        with cls._lock:
            return list(cls._stores.keys())

    @classmethod
    def has_store(cls, name: str) -> bool:
        """检查指定名称的存储实例是否已注册。

        Args:
            name: 存储名称。

        Returns:
            如果存在则返回 True，否则返回 False。
        """
        with cls._lock:
            return name in cls._stores
