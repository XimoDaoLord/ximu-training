"""DAG调度引擎核心数据结构、枚举类型及通用工具函数模块。"""

import json
import logging
import os
import time
import uuid
from collections import deque, defaultdict
from dataclasses import asdict, dataclass, field
from enum import Enum
from functools import wraps
from threading import RLock
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple, Union

logger = logging.getLogger("src.ximu.core._dag_scheduler_parts.part1")

# ---------------------------------------------------------------------------
# 通用工具函数（已提取为util模块）
# ---------------------------------------------------------------------------

def generate_id(prefix: str = "id") -> str:
    """生成带前缀的唯一标识符。

    Args:
        prefix: 标识符前缀（默认值：id）

    Returns:
        唯一的字符串标识符（16进制UUID）
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


def now_timestamp() -> float:
    """获取当前单调时钟时间戳（秒）

    Returns:
        当前时间戳（秒）
    """
    return time.monotonic()


def now_wall_time() -> float:
    """获取当前Unix时间戳（秒）

    Returns:
        当前时间戳（秒）
    """
    return time.time()


def now_timestamp_ms() -> int:
    """获取当前时间戳（毫秒）

    Returns:
        时间戳（毫秒）
    """
    return int(time.monotonic() * 1000)


def _json_default(obj: Any) -> Any:
    """JSON序列化默认处理函数

    Args:
        obj: 待序列化的对象

    Returns:
        可序列化的表示形式
    """
    if isinstance(obj, Enum):
        return obj.value
    if hasattr(obj, "__dataclass_fields__"):
        return asdict(obj)
    if isinstance(obj, (set, frozenset)):
        return list(obj)
    return str(obj)


def safe_json_dumps(obj: Any, **kwargs: Any) -> str:
    """安全JSON序列化

    支持处理枚举、dataclass、集合等类型

    Args:
        obj: 要序列化的对象
        **kwargs: json.dumps参数

    Returns:
        JSON字符串

    Raises:
        json.JSONDecodeError: 序列化失败时抛出
    """
    try:
        return json.dumps(obj, default=_json_default, **kwargs)
    except (TypeError, ValueError, OverflowError) as exc:
        logger.warning("JSON序列化失败: %s", exc)
        raise json.JSONDecodeError("无效对象", None, exc) from exc


def safe_json_loads(data: str, **kwargs: Any) -> Optional[Any]:
    """安全JSON反序列化

    Args:
        data: JSON字符串
        **kwargs: json.loads参数

    Returns:
        反序列化对象或None
    """
    if not isinstance(data, str) or not data.strip():
        return None
    try:
        return json.loads(data, **kwargs)
    except (json.JSONDecodeError, TypeError, ValueError) as exc:
        logger.debug("JSON反序列化失败: %s", exc)
        return None


def retry_on_failure(
    max_retries: int = 3,
    delay: float = 0.1,
    backoff: float = 2.0,
    retryable_exceptions: Tuple[type, ...] = (Exception,),
) -> Callable:
    """指数退避重试装饰器

    Args:
        max_retries: 最大重试次数（默认3）
        delay: 初始延迟（秒，默认0.1）
        backoff: 退避系数（默认2.0）
        retryable_exceptions: 可重试异常类型

    Returns:
        装饰器函数
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exception: Optional[Exception] = None
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except retryable_exceptions as exc:
                    last_exception = exc
                    if attempt < max_retries:
                        sleep_time = delay * (backoff ** attempt)
                        logger.warning(
                            "重试 %d/%d: %s 预计 %0.2fs 后重试",
                            attempt + 1, max_retries, func.__qualname__, sleep_time
                        )
                        time.sleep(sleep_time)
                    else:
                        logger.error(
                            "重试 %d 次失败: %s", max_retries, exc
                        )
            raise last_exception
        return wrapper
    return decorator


# ---------------------------------------------------------------------------
# Stopwatch
# ---------------------------------------------------------------------------


@dataclass
class Stopwatch:
    """高精度时间统计工具"""
    _start: float = 0.0
    _end: float = 0.0
    _running: bool = False

    def start(self) -> "Stopwatch":
        """开始计时"""
        self._start = time.monotonic()
        self._running = True
        return self

    def stop(self) -> float:
        """停止计时并返回耗时"""
        if self._running:
            self._end = time.monotonic() - self._start
            self._running = False
            logger.info("耗时 %.6f 秒", self._end)
        return self._end

    def elapsed(self) -> float:
        """实时耗时"""
        return time.monotonic() - self._start if self._running else self._end


# ---------------------------------------------------------------------------
# 枚举类型定义
# ---------------------------------------------------------------------------


class TaskStatus(Enum):
    """任务执行状态"""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


class Priority(Enum):
    """任务优先级"""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


class NodeState(Enum):
    """节点状态"""
    INITIALIZED = "initialized"
    READY = "ready"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"


class EdgeType(Enum):
    """边类型"""
    DATA_DEPENDENCY = "data_dependency"
    CONTROLFLOW = "control_flow"
    RESOURCE_SHARING = "resource_sharing"


class ExecutionMode(Enum):
    """执行模式"""
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    PRIORITY_BASED = "priority_based"


class FailureStrategy(Enum):
    """失败处理策略"""
    RETRY = "retry"
    SKIP = "skip"
    ABORT = "abort"
    FALLBACK = "fallback"


class TimeoutPolicy(Enum):
    """超时策略"""
    STRICT = "strict"
    GRACEFUL = "graceful"
    IGNORE = "ignore"


# ---------------------------------------------------------------------------
# DAG 核心数据结构
# ---------------------------------------------------------------------------


@dataclass
class Node:
    """DAG图节点"""
    node_id: str = field(default_factory=generate_id)
    task_name: str = ""
    state: NodeState = NodeState.INITIALIZED
    priority: Priority = Priority.NORMAL
    timeout_seconds: float = 30.0
    max_retries: int = 3
    metadata: Dict[str, Any] = field(default_factory=dict)
    result: Optional[Any] = None
    error: Optional[str] = None
    created_at: float = now_wall_time()
    updated_at: float = now_wall_time()

    def mark_started(self) -> None:
        """标记开始执行"""
        self.state = NodeState.EXECUTING
        self.updated_at = now_wall_time()
        logger.debug("节点 %s 开始执行", self.node_id)

    def mark_completed(self, result: Any = None) -> None:
        """标记执行完成"""
        self.state = NodeState.COMPLETED
        self.result = result
        self.updated_at = now_wall_time()
        logger.info("节点 %s 完成执行", self.node_id)

    def mark_failed(self, error: str) -> None:
        """标记执行失败"""
        self.state = NodeState.FAILED
        self.error = error
        self.updated_at = now_wall_time()
        logger.error("节点 %s 失败: %s", self.node_id, error)

    @retry_on_failure(max_retries=max_retries)
    def execute_with_retry(self, func: Callable, *args: Any, **kwargs: Any) -> Any:
        """带重试的执行方法"""
        logger.info("开始执行任务 %s", func.__qualname__)
        last_exception: Optional[Exception] = None

        for attempt in range(self.max_retries + 1):
            try:
                self.mark_started()
                result = func(*args, **kwargs)
                self.mark_completed(result)
                return result
            except Exception as exc:
                last_exception = exc
                self.error = str(exc)
                if attempt < self.max_retries:
                    sleep_time = self.retry_delay * (2 ** attempt)
                    logger.warning(
                        "重试 %d/%d: %s 预计 %0.2fs 后重试",
                        attempt + 1, self.max_retries, func.__qualname__, sleep_time
                    )
                    time.sleep(sleep_time)
                else:
                    self.mark_failed(str(exc))
                    logger.error(
                        "重试 %d 次失败: %s", max_retries, exc
                    )

        raise last_exception


@dataclass
class Edge:
    """DAG边"""
    source_id: str
    target_id: str
    edge_type: EdgeType = EdgeType.DATA_DEPENDENCY
    weight: Union[int, float] = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.weight, (int, float)):
            raise TypeError(f"weight必须是数字类型")
        if self.weight < 0:
            raise ValueError(f"weight不能为负数: {self.weight}")

    @classmethod
    def validate(cls, source: Node, target: Node, weight: Union[int, float]) -> "Edge":
        if not isinstance(weight, (int, float)):
            raise TypeError("weight必须是数字类型")
        if weight < 0:
            raise ValueError("weight不能为负数")
        return cls(source.node_id, target.node_id, weight=weight, metadata={})


@dataclass
class DAGGraph:
    """DAG图结构"""
    nodes: Dict[str, Node] = field(default_factory=dict)
    edges: List[Edge] = field(default_factory=list)
    incoming: Dict[str, List[str]] = field(default_factory=lambda: {})
    outgoing: Dict[str, List[str]] = field(default_factory=lambda: {})
    in_degree: Dict[str, int] = field(default_factory=lambda: {})
    out_degree: Dict[str, int] = field(default_factory=lambda: {})
    _lock: RLock = field(default_factory=RLock, repr=False)

    def add_node(self, node: Node) -> None:
        """添加节点"""
        with self._lock:
            if node.node_id in self.nodes:
                logger.warning("节点已存在: %s", node.node_id)
                return
            self.nodes[node.node_id] = node
            self.in_degree[node.node_id] = 0
            self.out_degree[node.node_id] = 0
            self.incoming[node.node_id] = []
            self.outgoing[node.node_id] = []
            logger.debug("添加节点: %s", node.node_id)

    def add_edge(self, source: Node, target: Node, weight: Union[int, float] = 1.0) -> None:
        """添加边"""
        with self._lock:
            Edge.validate(source, target, weight)
            if source.node_id == target.node_id:
                raise ValueError("节点不能依赖自身")
            if source.node_id not in self.nodes or target.node_id not in self.nodes:
                raise ValueError("节点不存在")
            self.edges.append(Edge(source.node_id, target.node_id, weight=weight))
            self.incoming[target.node_id].append(source.node_id)
            self.outgoing[source.node_id].append(target.node_id)
            self.in_degree[target.node_id] += 1
            self.out_degree[source.node_id] += 1
            logger.debug("添加边: %s -> %s", source.node_id, target.node_id)

    def topological_sort(self) -> List[str]:
        """拓扑排序（Kahn算法/BFS）

        复杂度：
            - 优化前：DFS递归 O(V+E)，递归深度>1000易栈溢出
            - 优化后：Kahn BFS O(V+E)，迭代实现，无递归深度问题
            - 优化前还包含环检测重试逻辑（图有环时sleep重试3次，纯浪费时间）
            - 优化后移除重试：图有环就是有环，重试无意义

        Raises:
            ValueError: 图中存在环时抛出
        """
        # 【优化前】重试3次，每次sleep，环检测是确定性的，重试毫无意义
        # 【优化后】单次执行，有环直接抛错
        with self._lock:
            local_in_degree = self.in_degree.copy()
            queue = deque([node_id for node_id, deg in local_in_degree.items() if deg == 0])

            result = []
            while queue:
                current = queue.popleft()
                result.append(current)
                for neighbor in self.outgoing.get(current, []):
                    local_in_degree[neighbor] -= 1
                    if local_in_degree[neighbor] == 0:
                        queue.append(neighbor)

            if len(result) != len(self.nodes):
                raise ValueError("Graph contains cycles")
            return result

    def get_ready_nodes(self) -> List[str]:
        """获取就绪节点"""
        with self._lock:
            return [node_id for node_id, deg in self.in_degree.items() if deg == 0 and node_id in self.nodes]

    def reduce_incoming(self, source_id: str) -> None:
        """更新依赖关系"""
        with self._lock:
            if source_id not in self.nodes:
                raise KeyError("节点不存在")
            for target_id in self.outgoing[source_id]:
                if source_id in self.incoming[target_id]:
                    self.incoming[target_id].remove(source_id)
                    self.in_degree[target_id] -= 1
                    logger.debug("更新入度: %s -> %d", target_id, self.in_degree[target_id])
            self.outgoing[source_id].clear()
            logger.debug("节点出边已处理: %s", source_id)

    def get_dependencies(self, node_id: str) -> List[str]:
        """获取依赖节点"""
        with self._lock:
            return self.incoming.get(node_id, [])

    def get_dependents(self, node_id: str) -> List[str]:
        """获取依赖者节点"""
        with self._lock:
            return self.outgoing.get(node_id, [])


# ---------------------------------------------------------------------------
# 执行上下文与结果封装
# ---------------------------------------------------------------------------


@dataclass
class ExecutionContext:
    """执行上下文"""
    context_id: str = field(default_factory=generate_id)
    task_name: str = ""
    mode: ExecutionMode = ExecutionMode.PARALLEL
    timeout_seconds: float = 300.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = now_wall_time()


@dataclass
class ExecutionResult:
    """执行结果"""
    context_id: str
    success: bool
    completed_nodes: List[str] = field(default_factory=list)
    failed_nodes: List[str] = field(default_factory=list)
    cancelled_nodes: List[str] = field(default_factory=list)
    duration_seconds: float = 0.0
    error_message: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
