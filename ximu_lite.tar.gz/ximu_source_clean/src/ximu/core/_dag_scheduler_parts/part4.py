import logging
import time
import threading
from collections import defaultdict, deque
from typing import Any, Dict, List, Optional, Tuple, Union

logger = logging.getLogger("src.ximu.core._dag_scheduler_parts.part4")

class MetricsBase:
    """
    指标收集基础类。

    通过子类声明 _METRIC_NAMES 类变量来定义指标集合。
    提供统一的 record/get/reset 方法、滑动窗口统计以及速率计算。
    线程安全，使用 RLock 保护。
    
    优化特性:
    - 指标名校验: 若 _METRIC_NAMES 非空，仅允许集合内的指标
    - 滑动窗口优化: 使用双指针维护窗口索引，避免每次全量遍历
    - 可配置历史窗口: 支持实例级配置 _DEFAULT_HISTORY_SIZE
    """

    _METRIC_NAMES: Tuple[str, ...] = ()
    _DEFAULT_HISTORY_SIZE: int = 10000

    def __init__(self, name: str = "", history_size: Optional[int] = None) -> None:
        self.name: str = name
        self._lock: threading.RLock = threading.RLock()
        self._data: Dict[str, float] = defaultdict(float)
        self._history_size: int = history_size if history_size is not None else self._DEFAULT_HISTORY_SIZE
        self._history: Dict[str, deque] = defaultdict(deque, maxlen=self._history_size)
        self._window: float = 60.0
        self._last_reset: float = time.time()
        self._window_start: Dict[str, int] = defaultdict(int)

        metric_names: Tuple[str, ...] = self._METRIC_NAMES
        if metric_names:
            logger.debug("Initializing MetricsBase '%s' with metrics: %s, history_size: %d", 
                        name, metric_names, self._history_size)

    def _validate_metric(self, metric: str) -> None:
        if self._METRIC_NAMES and metric not in self._METRIC_NAMES:
            raise ValueError(
                f"Metric '{metric}' is not in the declared metrics: {self._METRIC_NAMES}"
            )

    def record(self, metric: str, value: float) -> None:
        self._validate_metric(metric)
        with self._lock:
            self._data[metric] += value
            self._history[metric].append((time.time(), value))
            self._update_window_start(metric)

    def _update_window_start(self, metric: str) -> None:
        hist = self._history[metric]
        if len(hist) > 0:
            last_time = hist[-1][0]
            window_start_time = last_time - self._window
            start_idx = self._window_start[metric]
            while start_idx < len(hist) and hist[start_idx][0] < window_start_time:
                start_idx += 1
            self._window_start[metric] = start_idx

    def get(self, metric: str) -> float:
        with self._lock:
            return self._data.get(metric, 0.0)

    def reset(self, metric: str) -> None:
        with self._lock:
            self._data[metric] = 0.0
            self._history[metric].clear()
            self._window_start[metric] = 0

    def get_all(self) -> Dict[str, float]:
        with self._lock:
            return dict(self._data)

    def get_rate(self, metric: str) -> float:
        with self._lock:
            elapsed: float = max(1.0, time.time() - self._last_reset)
            return self._data.get(metric, 0.0) / elapsed

    def get_window_stats(self, metric: str, window: int = 60) -> Dict[str, Any]:
        with self._lock:
            if not self._history[metric]:
                return {"count": 0, "sum": 0, "avg": 0, "min": 0, "max": 0}

            now: float = time.time()
            hist = self._history[metric]
            window_start_time = now - window
            start_idx = self._window_start[metric]

            while start_idx < len(hist) and hist[start_idx][0] < window_start_time:
                start_idx += 1
            self._window_start[metric] = start_idx

            window_values = [v for t, v in hist[start_idx:] if (now - t) < window]
            if not window_values:
                return {"count": 0, "sum": 0, "avg": 0, "min": 0, "max": 0}

            total_sum: float = sum(window_values)
            return {
                "count": len(window_values),
                "sum": total_sum,
                "avg": total_sum / len(window_values),
                "min": min(window_values),
                "max": max(window_values),
            }

    def reset_all(self) -> None:
        with self._lock:
            self._data.clear()
            self._history.clear()
            self._window_start.clear()
            self._last_reset = time.time()

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "name": self.name,
                "metrics": dict(self._data),
                "window": self._window,
                "last_reset": self._last_reset,
            }

class RoundRobinStrategy:
    """
    基础轮询策略，用于多节点或任务选择。

    线程安全，使用 Lock 保护内部计数器。
    支持序列类型和生成器类型（生成器需先转换为列表）。
    """

    def __init__(self, **kwargs: Any) -> None:
        self.strategy_name: str = "round_robin"
        self._params: Dict[str, Any] = kwargs
        self._call_count: int = 0
        self._success_count: int = 0
        self._lock: threading.Lock = threading.Lock()

    def _ensure_list(self, candidates: Any) -> Optional[List[Any]]:
        if candidates is None:
            return None
        if hasattr(candidates, '__len__'):
            if len(candidates) == 0:
                return []
            if hasattr(candidates, '__iter__'):
                return list(candidates)
            raise TypeError(f"Expected iterable, got {type(candidates)}")
        if hasattr(candidates, '__iter__'):
            lst = list(candidates)
            return lst
        raise TypeError(f"Expected iterable, got {type(candidates)}")

    def calculate(self, candidates: Any, context: Optional[Dict[str, Any]] = None) -> Any:
        candidates_list = self._ensure_list(candidates)
        if not candidates_list:
            return None

        with self._lock:
            selected_index: int = self._call_count % len(candidates_list)
            selected_item: Any = candidates_list[selected_index]
            self._call_count += 1
            return selected_item

    def reset(self) -> None:
        with self._lock:
            self._call_count = 0
            self._success_count = 0

    def get_stats(self) -> Dict[str, int]:
        with self._lock:
            return {"call_count": self._call_count, "success_count": self._success_count}
