"""
DAG调度器核心模块初始化文件
版本号：0.5
"""

import logging
from typing import Optional, Dict, List, Tuple, Type
from src.ximu.core._dag_scheduler_parts.dag_config import DagSchedulerConfig

# 全局日志配置
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class DagSchedulerParts:
    """DAG调度器组件管理类
    
    负责管理调度器各个核心组件的初始化与协作
    """
    def __init__(self, config: DagSchedulerConfig) -> None:
        """初始化调度器组件
        
        Args:
            config: DAG调度器配置对象
        """
        self.config = config
        self._components: Dict[str, Type[object]] = {}
        self._initialized: Dict[str, bool] = {}

    def register_component(self, component_name: str, component_class: Type[object]) -> None:
        """注册调度器组件
        
        Args:
            component_name: 组件唯一标识名称
            component_class: 组件实现类
        """
        if component_name in self._components:
            raise ValueError(f"组件 {component_name} 已存在")
        self._components[component_name] = component_class

    def initialize_components(self) -> List[Tuple[str, object]]:
        """初始化所有注册的调度器组件
        
        Returns:
            初始化成功的组件列表（名称，实例）
        """
        try:
            logger.info("开始初始化调度器组件")
            initialized = []
            for name, cls in self._components.items():
                if not self._initialized.get(name, False):
                    instance = cls(config=self.config)
                    initialized.append((name, instance))
                    self._initialized[name] = True
            logger.info(f"成功初始化 {len(initialized)} 个组件")
            return initialized
        except Exception as e:
            logger.error("组件初始化失败", exc_info=True)
            raise RuntimeError("组件初始化失败") from e

def init_logger(log_level: str = "INFO") -> None:
    """全局日志初始化
    
    Args:
        log_level: 日志级别（可选值：DEBUG, INFO, WARNING, ERROR, CRITICAL）
    """
    logger.setLevel(logging.getLevelName(log_level))
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

# 导出核心组件
__all__ = ["DagSchedulerParts", "init_logger", "DagSchedulerConfig"]
