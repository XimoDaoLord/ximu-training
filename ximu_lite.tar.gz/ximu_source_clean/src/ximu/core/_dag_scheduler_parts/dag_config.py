"""
DAG调度器配置模块。
提供 DagSchedulerConfig 配置类。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class DagSchedulerConfig:
    """DAG调度器配置。"""
    max_workers: int = 4
    task_timeout: int = 300
    retry_limit: int = 3
    retry_backoff: float = 1.5
    queue_size: int = 1000
    enable_priority: bool = True
    enable_circuit_breaker: bool = True
    circuit_breaker_threshold: int = 5
    circuit_breaker_reset_timeout: int = 60
    extra: Dict[str, Any] = field(default_factory=dict)
