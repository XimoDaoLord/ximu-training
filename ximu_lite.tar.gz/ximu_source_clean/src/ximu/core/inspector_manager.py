# -*- coding: utf-8 -*-
"""汐沫AI · 检查官管理器（两个 3B 检查官懒加载单例）。

层级定位：子任务层质检。
  - 检查官 A（正确性）：inspect_correctness  —— 查 bug / 语法错误 / 逻辑错误 / 边界条件 / 能否跑
  - 检查官 B（质量）：  inspect_quality       —— 查代码风格 / 性能 / 安全 / 可维护性 / 最佳实践

设计要点：
  * 单例模式，所有子任务共享同一对检查官。
  * 懒加载：_load() 首次调用时才真正加载本地 3B 模型；release() 验收完卸载释放显存/内存。
  * 模型文件后续下载；当前先把加载/卸载接口与降级路径写死。
  * 模型未加载 / 加载失败时，降级到「技术兜底评分」：
        语法检查(ast.parse) + 格式检查(非空/结构) + 基本安全检查
    绝不使用随机数或默认通过。
  * 加载/卸载全程 threading.Lock 保护，线程安全。
"""
from __future__ import annotations

import ast
import logging
import os
import re
import threading
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("src.ximu.core.inspector_manager")

# 本地 3B 检查官模型预期存放目录（后续由 download_models 脚本落盘）
# __file__ = <root>/src/ximu/core/inspector_manager.py  -> 上溯 4 级到项目根
_HERE = os.path.dirname(os.path.abspath(__file__))          # .../src/ximu/core
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(_HERE)))  # <root>
_INSPECTOR_MODEL_DIR = os.path.join(_PROJECT_ROOT, "models", "inspectors")


class InspectorManager:
    """两个 3B 检查官的懒加载单例管理器。"""

    _instance: Optional["InspectorManager"] = None
    _instance_lock = threading.Lock()

    def __new__(cls) -> "InspectorManager":
        if cls._instance is None:
            with cls._instance_lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self) -> None:
        if getattr(self, "_initialized", False):
            return
        self._initialized = True
        self._lock = threading.Lock()
        self._inspector_a_loaded: bool = False
        self._inspector_b_loaded: bool = False
        self._inspector_a_model: Optional[Any] = None
        self._inspector_b_model: Optional[Any] = None
        self._ref_count: int = 0  # 正在使用检查官的子任务计数
        logger.info("InspectorManager 单例已初始化（模型未加载，使用技术兜底）")

    # ------------------------------------------------------------------ #
    # 懒加载 / 卸载                                                       #
    # ------------------------------------------------------------------ #
    def _load(self) -> None:
        """按需加载两个 3B 检查官模型（线程安全）。

        模型文件尚未下载时，保持未加载状态，调用方走技术兜底评分。
        """
        with self._lock:
            self._ref_count += 1
            if self._inspector_a_loaded and self._inspector_b_loaded:
                return
            # 尝试加载本地检查官模型（文件后续下载）
            a_path = os.path.join(_INSPECTOR_MODEL_DIR, "inspector_a")
            b_path = os.path.join(_INSPECTOR_MODEL_DIR, "inspector_b")
            if os.path.isdir(a_path):
                self._inspector_a_model = self._try_load_model(a_path, "A")
                self._inspector_a_loaded = self._inspector_a_model is not None
            if os.path.isdir(b_path):
                self._inspector_b_model = self._try_load_model(b_path, "B")
                self._inspector_b_loaded = self._inspector_b_model is not None
            if not self._inspector_a_loaded:
                logger.info("检查官 A 模型未就位（%s），使用技术兜底评分", a_path)
            if not self._inspector_b_loaded:
                logger.info("检查官 B 模型未就位（%s），使用技术兜底评分", b_path)

    def _try_load_model(self, path: str, tag: str) -> Optional[Any]:
        """尝试加载本地模型对象（当前为占位，模型文件下载后实现真实加载）。"""
        try:
            # 预留：后续用 transformers / 本地推理引擎加载 3B 权重
            logger.info("检查官 %s 模型目录存在，预留加载钩子: %s", tag, path)
            return None  # 当前返回 None，走技术兜底
        except Exception as e:  # pragma: no cover
            logger.warning("检查官 %s 模型加载失败: %s", tag, e)
            return None

    def release(self) -> None:
        """验收完毕释放检查官（引用计数归零后真正卸载）。"""
        with self._lock:
            self._ref_count = max(0, self._ref_count - 1)
            if self._ref_count == 0:
                self._inspector_a_model = None
                self._inspector_b_model = None
                self._inspector_a_loaded = False
                self._inspector_b_loaded = False
                logger.info("检查官已全部卸载（引用计数归零）")

    # ------------------------------------------------------------------ #
    # 对外检查接口                                                       #
    # ------------------------------------------------------------------ #
    def inspect_correctness(self, content: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """检查官 A：正确性检查。

        Returns:
            {"passed": bool, "errors": [str], "score": float(0-100), "details": {...}}
        """
        self._load()
        try:
            if self._inspector_a_loaded and self._inspector_a_model is not None:
                result = self._ai_inspect_correctness(content, context)
            else:
                result = self._tech_inspect_correctness(content, context)
        finally:
            self.release()
        logger.info("检查官A 正确性检查: passed=%s score=%s errors=%d",
                    result.get("passed"), result.get("score"), len(result.get("errors", [])))
        return result

    def inspect_quality(self, content: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """检查官 B：质量检查。

        Returns:
            {"passed": bool, "suggestions": [str], "score": float(0-100), "details": {...}}
        """
        self._load()
        try:
            if self._inspector_b_loaded and self._inspector_b_model is not None:
                result = self._ai_inspect_quality(content, context)
            else:
                result = self._tech_inspect_quality(content, context)
        finally:
            self.release()
        logger.info("检查官B 质量检查: passed=%s score=%s suggestions=%d",
                    result.get("passed"), result.get("score"), len(result.get("suggestions", [])))
        return result

    # ------------------------------------------------------------------ #
    # AI 路径（模型加载后启用，当前为占位转发到技术兜底）                  #
    # ------------------------------------------------------------------ #
    def _ai_inspect_correctness(self, content: str, context: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """调用 3B 检查官 A 做正确性评审（模型未就位时回退技术兜底）。"""
        # 预留：真实模型推理。当前模型未加载，回退到技术兜底。
        return self._tech_inspect_correctness(content, context)

    def _ai_inspect_quality(self, content: str, context: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """调用 3B 检查官 B 做质量评审（模型未就位时回退技术兜底）。"""
        return self._tech_inspect_quality(content, context)

    # ------------------------------------------------------------------ #
    # 技术兜底评分（确定性，无随机数，无默认通过）                         #
    # ------------------------------------------------------------------ #
    def _tech_inspect_correctness(self, content: str, context: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """正确性技术检查：非空 + 语法检查(ast) + 明显错误检测。"""
        errors: List[str] = []
        content = str(content or "")
        # 1. 非空检查
        if not content.strip():
            return {"passed": False, "errors": ["输出为空"], "score": 0.0,
                    "details": {"method": "tech_correctness"}}
        # 2. 提取代码块做语法检查
        code_blocks = self._extract_code_blocks(content)
        syntax_errors: List[str] = []
        if code_blocks:
            for idx, code in enumerate(code_blocks):
                try:
                    ast.parse(code)
                except SyntaxError as e:
                    syntax_errors.append(f"代码块{idx + 1} 语法错误: {e.msg} (行{e.lineno})")
        errors.extend(syntax_errors)
        # 3. 明显逻辑/运行时错误特征：除零、未定义变量直接抛出
        if re.search(r'Returned None|NoneType.*has no attribute|NameError', content):
            errors.append("输出含未处理运行时错误特征")
        # 4. 边界条件：输出是否包含可执行的结构（函数/类定义或可运行语句）
        has_executable = bool(code_blocks) or bool(re.search(
            r'\b(def|class|import|print|return|if|for|while)\b', content))
        if not has_executable:
            errors.append("无可执行代码/逻辑结构")
        # 评分：100 起，每个错误扣 25
        score = 100.0 - 25.0 * len(errors)
        score = max(0.0, min(100.0, score))
        passed = len(errors) == 0  # 只要无错误即通过（不强制要求```代码块，LLM可能直接输出代码）
        return {"passed": passed, "errors": errors, "score": round(score, 1),
                "details": {"method": "tech_correctness", "code_blocks": len(code_blocks)}}

    def _tech_inspect_quality(self, content: str, context: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """质量技术检查：代码风格 + 性能 + 安全 + 可维护性 + 最佳实践。"""
        suggestions: List[str] = []
        content = str(content or "")
        if not content.strip():
            return {"passed": False, "suggestions": ["输出为空"], "score": 0.0,
                    "details": {"method": "tech_quality"}}
        code_blocks = self._extract_code_blocks(content)
        score = 100.0
        # 1. 代码风格：函数/类是否带 docstring（抽样）
        for code in code_blocks:
            if re.search(r'\bdef \w+\([^)]*\):(?!\s*"""[^\n]+""")', code):
                suggestions.append("部分函数缺少 docstring")
                score -= 5.0
                break
        # 2. 安全：危险调用检测
        danger_hits = re.findall(r'\b(eval|exec|os\.system|subprocess\.call|shell=True)\b', content)
        if danger_hits:
            suggestions.append(f"检测到危险调用: {', '.join(set(danger_hits))}")
            score -= 15.0
        # 3. 性能：明显的反模式（循环内重复 .append 大对象除外，查低效模式）
        if re.search(r'\bfor\s+\w+\s+in\s+range\([^)]*\):\s*\n\s*.*\.append\([^)]*\)', content) and 'enumerate' not in content:
            # 这是常见写法，不扣过分；仅查 while True 无 break
            pass
        if re.search(r'while\s+True\s*:(?!\s*\n\s*.*break)', content):
            suggestions.append("存在无 break 的 while True 死循环风险")
            score -= 10.0
        # 4. 可维护性：单行过长（>120字符）
        long_lines = [ln for ln in content.splitlines() if len(ln) > 120]
        if long_lines:
            suggestions.append(f"{len(long_lines)} 行超过120字符，建议折行")
            score -= 3.0 * min(len(long_lines), 3)
        # 5. 最佳实践：裸 except
        if re.search(r'except\s*:\s*$', content, re.MULTILINE):
            suggestions.append("存在裸 except，建议捕获具体异常")
            score -= 5.0
        score = max(0.0, min(100.0, score))
        passed = score >= 70.0 and not danger_hits
        return {"passed": passed, "suggestions": suggestions, "score": round(score, 1),
                "details": {"method": "tech_quality", "code_blocks": len(code_blocks)}}

    @staticmethod
    def _extract_code_blocks(content: str) -> List[str]:
        """从 markdown 文本中提取 ``` 代码块内容。"""
        blocks: List[str] = []
        for m in re.finditer(r"```(?:\w+)?\s*\n(.*?)```", content, re.DOTALL):
            code = m.group(1).strip()
            if code:
                blocks.append(code)
        return blocks


# 模块级便捷单例获取
_default_manager: Optional[InspectorManager] = None
_default_lock = threading.Lock()


def get_inspector_manager() -> InspectorManager:
    """获取 InspectorManager 全局单例。"""
    global _default_manager
    if _default_manager is None:
        with _default_lock:
            if _default_manager is None:
                _default_manager = InspectorManager()
    return _default_manager
