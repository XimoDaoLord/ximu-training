# -*- coding: utf-8 -*-
"""汐沫AI 0.5 · 模型盘点 + 成本分级路由。

自动识别可用云端模型并按成本分级为后台任务选模型，避免大量烧付费额度。
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

__version__ = "0.5"

# ---------------------------------------------------------------------------
# 后台任务类型 → 小 Token 预算
# ---------------------------------------------------------------------------
TASK_TOKEN_BUDGETS: Dict[str, int] = {
    "learning_root_cause": 512,
    "correction": 512,
    "embedding": 64,
    "auto_compress": 256,
    "multimodal_translation": 512,
}
DEFAULT_TOKEN_BUDGET = 256


def token_budget_for(task_type: str) -> int:
    """获取后台任务的默认小 token 预算；未知类型返回最小默认值。"""
    return TASK_TOKEN_BUDGETS.get(task_type, DEFAULT_TOKEN_BUDGET)


# ---------------------------------------------------------------------------
# 内置「已知免费」种子清单
# ---------------------------------------------------------------------------
BUILTIN_FREE_SEED: Dict[str, str] = {
    "glm-4-flash": "zhipu 官方免费文本模型",
    "glm-4.7-flash": "zhipu 官方免费文本模型",
    "glm-z1-flash": "zhipu 官方免费推理模型",
    ":free": "openrouter 免费档位",
    "Qwen/Qwen2.5-7B-Instruct": "siliconflow 免费开源模型",
    "THUDM/glm-4-9b-chat": "siliconflow 免费开源模型",
    "DeepSeek-V4-Flash-0731": "llm7 免费 flash 档",
    "glm-5.3-flash": "llm7 免费 flash 档",
    "agnes-2.5-flash": "agnes 免费档",
    "agnes-3.0-flash": "agnes 免费档",
}

_BUILTIN_PRICING: Dict[str, Dict[str, float]] = {
    "glm-4-flash": {"input": 0.0, "output": 0.0, "currency": "CNY"},
    "glm-4.7-flash": {"input": 0.0, "output": 0.0, "currency": "CNY"},
    "glm-z1-flash": {"input": 0.0, "output": 0.0, "currency": "CNY"},
    "qwen-turbo": {"input": 0.3, "output": 0.6, "currency": "CNY"},
    "qwen2.5-7b-instruct": {"input": 0.3, "output": 0.6, "currency": "CNY"},
    "gpt-4": {"input": 30.0, "output": 60.0, "currency": "USD"},
    "gpt-3.5": {"input": 0.5, "output": 1.5, "currency": "USD"},
    "claude-3.5-sonnet": {"input": 3.0, "output": 15.0, "currency": "USD"},
    "qwen-max": {"input": 20.0, "output": 60.0, "currency": "CNY"},
}

LOCAL_STANDARD_PARAMS_M = 4000.0


@dataclass
class ModelCandidate:
    """一个可被路由的模型候选。"""
    model_id: str
    provider: str
    base_url: str = ""
    side: str = "cloud"
    kind: str = "llm"
    parameters_m: float = 0.0
    is_free: bool = False
    pricing_label: str = "pricing_unknown"
    pricing: Optional[Dict[str, float]] = None
    evidence: List[str] = field(default_factory=list)
    reachable: bool = False
    health: str = "unknown"
    latency_ms: Optional[float] = None
    probe_msg: str = ""

    def is_local_standard(self) -> bool:
        """判断是否为本地标准模型：已下载且参数量 >= 阈值。"""
        if self.side != "local":
            return False
        if self.parameters_m <= 0:
            return True
        return self.parameters_m >= LOCAL_STANDARD_PARAMS_M

    def cost_rank(self) -> int:
        """返回成本优先级（数值越小优先级越高）。"""
        if self.kind == "fallback":
            return 3
        if self.side == "cloud" and self.is_free and self.pricing_label == "free":
            return 0
        if self.side == "local":
            return 1 if self.is_local_standard() else 2
        return 4

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式用于序列化。"""
        return {
            "model_id": self.model_id,
            "provider": self.provider,
            "base_url": self.base_url,
            "side": self.side,
            "kind": self.kind,
            "parameters_m": self.parameters_m,
            "is_free": self.is_free,
            "pricing_label": self.pricing_label,
            "pricing": self.pricing,
            "evidence": list(self.evidence),
            "reachable": self.reachable,
            "health": self.health,
            "latency_ms": self.latency_ms,
            "probe_msg": self.probe_msg,
            "cost_rank": self.cost_rank(),
        }


def _audit(event: str, detail: Dict[str, Any], result: str = "success",
           level: str = "info") -> None:
    """记录审计日志，失败时静默处理不阻断主流程。"""
    try:
        from src.ximu.core import audit_chain
        audit_chain.record(event, action=event, source="model_inventory",
                           result=result, level=level, detail=detail)
    except Exception:
        pass


def _is_local_endpoint(provider_name: str, base_url: str) -> bool:
    """判断是否为本地端点。"""
    b = (base_url or "").lower()
    n = (provider_name or "").lower()
    return n == "local" or "localhost" in b or "127.0.0.1" in b or b.startswith("http://0.0.0.0")


def _load_real_providers() -> List[Dict[str, Any]]:
    """调用 live_model_gateway.load_providers 获取已配置来源。"""
    try:
        from src.ximu.core import live_model_gateway as gw
        return list(gw.load_providers(force=False) or [])
    except Exception:
        return []


def _discover_local_models() -> List[Dict[str, Any]]:
    """调用 local_model_manager 发现已实际下载的本地模型。"""
    out: List[Dict[str, Any]] = []
    try:
        from src.ximu.core import local_model_manager as lmm
        mgr = lmm.get_local_model_manager()
        try:
            mgr.initialize()
        except Exception:
            pass
        for info in (mgr.get_models(enabled_only=True) or []):
            d = info.to_dict() if hasattr(info, "to_dict") else dict(info)
            out.append({
                "model_id": str(d.get("model_id") or info.model_id),
                "name": str(d.get("name", "")),
                "parameters_m": float(d.get("parameters", 0) or 0),
            })
    except Exception:
        pass
    return out


def _match_free_seed(model_id: str) -> str:
    """根据模型 ID 匹配内置免费种子，返回说明或空字符串。"""
    for key, desc in BUILTIN_FREE_SEED.items():
        if key in model_id or model_id.endswith(key):
            return desc
    return ""


def _get_pricing(model_id: str) -> Optional[Dict[str, float]]:
    """查询内置定价表，匹配到返回定价信息，否则返回 None。"""
    for key, price in _BUILTIN_PRICING.items():
        if key in model_id:
            return price
    return None


def _build_candidates(providers: List[Dict[str, Any]],
                      local_models: List[Dict[str, Any]]) -> List[ModelCandidate]:
    """从云端提供商和本地模型构建候选列表。"""
    candidates: List[ModelCandidate] = []
    seen_ids: set = set()

    for prov in providers:
        mid = str(prov.get("model_id", ""))
        if not mid or mid in seen_ids:
            continue
        seen_ids.add(mid)
        free_desc = _match_free_seed(mid)
        pricing = _get_pricing(mid)
        is_free = bool(free_desc or (pricing and pricing.get("input", 0) == 0 and pricing.get("output", 0) == 0))
        pricing_label = "free" if is_free else ("known_price" if pricing else "pricing_unknown")
        evidence = [free_desc] if free_desc else []
        if pricing:
            evidence.append(f"pricing={pricing}")
        candidates.append(ModelCandidate(
            model_id=mid,
            provider=prov.get("provider", "unknown"),
            base_url=prov.get("base_url", ""),
            side="cloud",
            is_free=is_free,
            pricing_label=pricing_label,
            pricing=pricing,
            evidence=evidence,
        ))

    for local in local_models:
        mid = str(local.get("model_id", ""))
        if not mid or mid in seen_ids:
            continue
        seen_ids.add(mid)
        params_m = local.get("parameters_m", 0.0)
        candidates.append(ModelCandidate(
            model_id=mid,
            provider="local",
            side="local",
            parameters_m=params_m,
            is_free=True,
            pricing_label="free",
            pricing={"input": 0.0, "output": 0.0, "currency": "NONE"},
            evidence=["本地模型，0成本"],
        ))

    return candidates


def rank_candidates(candidates: List[ModelCandidate]) -> List[ModelCandidate]:
    """按成本优先级排序候选模型，排除不可达的模型。"""
    reachable = [c for c in candidates if c.reachable and c.health not in ("unavailable", "unreachable")]
    sorted_candidates = sorted(reachable, key=lambda c: (c.cost_rank(), c.pricing.get("input", 0) if c.pricing else 0))
    return sorted_candidates


def build_inventory(providers: Optional[List[Dict[str, Any]]] = None,
                    local_models: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """构建完整的模型库存快照，包含候选列表和统计信息。"""
    if providers is None:
        providers = _load_real_providers()
    if local_models is None:
        local_models = _discover_local_models()

    candidates = _build_candidates(providers, local_models)
    ranked = rank_candidates(candidates)

    stats = {
        "total": len(candidates),
        "free_count": sum(1 for c in candidates if c.is_free),
        "local_count": sum(1 for c in candidates if c.side == "local"),
        "cloud_count": sum(1 for c in candidates if c.side == "cloud"),
        "reachable_count": sum(1 for c in candidates if c.reachable),
    }

    return {
        "candidates": [c.to_dict() for c in ranked],
        "stats": stats,
        "timestamp": time.time(),
        "version": __version__,
    }


def select_for_task(task_type: str,
                    candidates: Optional[List[ModelCandidate]] = None,
                    budget_override: Optional[int] = None) -> Optional[ModelCandidate]:
    """为指定任务类型选择最合适的模型候选。"""
    if candidates is None:
        inventory = build_inventory()
        candidates = [ModelCandidate(**c) for c in inventory.get("candidates", [])]

    budget = budget_override or token_budget_for(task_type)
    ranked = [c for c in candidates if c.reachable and c.health not in ("unavailable", "unreachable")]

    if not ranked:
        return None

    for candidate in ranked:
        if candidate.is_free or candidate.side == "local":
            return candidate

    return ranked[0] if ranked else None
