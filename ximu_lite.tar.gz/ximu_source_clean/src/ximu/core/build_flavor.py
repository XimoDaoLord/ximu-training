# -*- coding: utf-8 -*-
"""构建风味与 API 信息监控开关。

- flavor=plaintext（明文components包）：允许通过开关查看 API/连接等调试信息，默认关闭。
- flavor=encrypted（加密/Demo/正式包）：强制不允许查看/监控任何 API 信息，连设置项都不暴露。

加密打包流程会向 config/flavor.json 写入 {"flavor": "encrypted"}；源码树默认 plaintext。

版本: 0.5
"""

import json
import logging
import os
import threading
from typing import Any, Dict

# 配置日志
logger = logging.getLogger(__name__)

# 路径定义
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
_FLAVOR_FILE = os.path.join(_ROOT, "config", "flavor.json")

# 常量定义
_FLAVOR_PLAINTEXT = "plaintext"
_FLAVOR_ENCRYPTED = "encrypted"
_DEFAULT_FLAVOR = _FLAVOR_PLAINTEXT

# 线程锁
_lock = threading.RLock()

# 运行时状态
_runtime_show = False  # 运行时开关，默认关闭


def _read_flavor_from_file() -> str:
    """
    从配置文件读取构建风味。

    Returns:
        str: 返回解析后的风味字符串，若读取失败或文件不存在则返回默认值 'plaintext'。
    """
    global _FLAVOR_CACHE  # 这里其实不需要 global，因为我们是函数级返回，但为了逻辑清晰，我们直接读取文件
    try:
        with open(_FLAVOR_FILE, encoding="utf-8") as f:
            data: Dict[str, Any] = json.load(f)
            flavor: str = data.get("flavor", _DEFAULT_FLAVOR)
            # 确保返回值是已知类型，防止配置错误
            if flavor not in (_FLAVOR_PLAINTEXT, _FLAVOR_ENCRYPTED):
                logger.warning(f"未知风味配置: '{flavor}', 使用默认值 '{_DEFAULT_FLAVOR}'")
                return _DEFAULT_FLAVOR
            return flavor
    except FileNotFoundError:
        logger.info(f"风味配置文件未找到: {_FLAVOR_FILE}, 使用默认值 '{_DEFAULT_FLAVOR}'")
        return _DEFAULT_FLAVOR
    except json.JSONDecodeError as e:
        logger.error(f"风味配置文件 JSON 解析失败: {_FLAVOR_FILE}, 错误: {e}, 使用默认值 '{_DEFAULT_FLAVOR}'")
        return _DEFAULT_FLAVOR
    except Exception as e:
        # 捕获其他未预期异常，但记录日志，不吞掉具体原因
        logger.exception(f"读取风味配置文件时发生未知错误: {_FLAVOR_FILE}, 错误: {e}, 使用默认值 '{_DEFAULT_FLAVOR}'")
        return _DEFAULT_FLAVOR


# 在模块加载时确定风味
# 注意：原始代码在模块级别调用 _read_flavor() 并赋值给 FLAVOR。
# 为了保持兼容性和性能，我们保持这种方式，但确保读取过程是健壮的。
def _init_flavor() -> str:
    """
    初始化模块级 FLAVOR 变量。

    Returns:
        str: 当前的构建风味。
    """
    return _read_flavor_from_file()

FLAVOR: str = _init_flavor()


def is_encrypted() -> bool:
    """
    判断当前构建是否为加密包。

    Returns:
        bool: 如果风味为 'encrypted' 则返回 True，否则返回 False。
    """
    return FLAVOR == _FLAVOR_ENCRYPTED


def api_monitor_allowed() -> bool:
    """
    判断是否允许查看 API 信息。
    
    仅当构建为明文包且运行时开关显式打开时，才允许监控。

    Returns:
        bool: 如果允许查看 API 信息则返回 True，否则返回 False。
    """
    return (not is_encrypted()) and _runtime_show


def show_api_info() -> bool:
    """
    获取当前 API/连接等调试信息的展示状态。

    如果构建为加密包，始终返回 False。
    否则，返回运行时开关的状态。

    Returns:
        bool: 当前是否展示调试信息。
    """
    with _lock:
        if is_encrypted():
            logger.debug("构建为加密包，强制禁用 API 调试信息展示")
            return False
        return _runtime_show


def set_show_api_info(value: bool) -> bool:
    """
    设置 API/连接调试信息的展示状态。

    加密包禁止更改此设置，始终返回 False 并重置内部状态为 False。
    明文包则根据传入值更新内部状态。

    Args:
        value (bool): 期望的设置状态。

    Returns:
        bool: 设置后的实际状态。
    """
    global _runtime_show
    with _lock:
        if is_encrypted():
            logger.info("尝试在加密包中设置 API 调试信息，已拒绝并重置为 False")
            _runtime_show = False
            return False
        
        _runtime_show = bool(value)
        logger.debug(f"明文包中设置 API 调试信息状态为: {_runtime_show}")
        return _runtime_show


def public_settings() -> Dict[str, Any]:
    """
    获取供设置面板使用的公共配置项。

    加密包不暴露 API 调试相关的设置项，仅返回可用标志为 False。
    明文包则返回完整的设置项，包括可用标志和当前状态。

    Returns:
        Dict[str, Any]: 包含设置项信息的字典。
    """
    if is_encrypted():
        logger.debug("返回加密包的公共设置项")
        return {
            "api_debug_available": False
        }
    
    logger.debug("返回明文包的公共设置项")
    return {
        "api_debug_available": True,
        "show_api_info": show_api_info()
    }
