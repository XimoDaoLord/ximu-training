# -*- coding: utf-8 -*-
"""通用连接池管理器（性能优化 · 连接池）。

设计目标：
    - 通用连接池基类，支持 HTTP 连接 / 模型 API 连接 / 数据库连接等任意资源；
    - 连接预建：常用端点在启动时预建到池中，避免首次请求握手延迟；
    - 连接复用：相同 key（如同一模型 endpoint）的连续请求复用空闲连接；
    - 懒加载：不常用 key 按需创建，避免冷启动建满；
    - 空闲超时释放：可配置超时，到期空闲连接被回收，控制资源占用；
    - 连接健康监控：acquire 前对空闲连接做健康探测，坏连接丢弃重建；
    - 线程安全：所有池状态由一把 ``threading.RLock`` 保护；
    - 统计：连接创建数 / 复用数 / 失败数 / 当前活跃数 / 空闲数。

不引入任何第三方依赖，纯标准库实现，可在任何后端下工作。
"""
from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

__version__ = "0.5"

logger = logging.getLogger(__name__)


def _adaptive_max_per_key() -> int:
    """R12性能：每 key 空闲连接上限按 CPU 核数自适应。
    原固定 4，在 16 核设备上并发 model-api 请求时空闲槽位不足、反复建连/关闭。
    取 min(cpu_count*2, 16)：I/O 型连接可适当多于核数，封顶 16 防资源失控。"""
    try:
        cpu = os.cpu_count() or 2
    except Exception:
        cpu = 2
    return max(4, min(cpu * 2, 16))


@dataclass
class _IdleEntry:
    """一条空闲连接及其最后归还时间（monotonic 秒）。"""

    conn: Any
    last_used: float


@dataclass
class PoolStats:
    """连接池统计快照。"""

    created: int = 0
    reused: int = 0
    failed: int = 0
    active: int = 0
    idle: int = 0
    evicted: int = 0

    def to_dict(self) -> Dict[str, int]:
        """将统计信息转换为字典。"""
        return {
            "created": self.created,
            "reused": self.reused,
            "failed": self.failed,
            "active": self.active,
            "idle": self.idle,
            "evicted": self.evicted,
        }


class ConnectionPool:
    """按 key 分组的通用连接池。

    Parameters
    ----------
    factory:
        无参可调用，创建一个新连接。``factory(key)`` 接收当前 key。
    max_per_key:
        每个 key 最多保留的空闲连接数（活跃连接不额外限流，由调用方控制）。
        缺省 None → 按 CPU 核数自适应（_adaptive_max_per_key，min(cpu*2,16)）。
    idle_timeout:
        空闲超过该秒数的连接在下次清扫时被释放。
    health_check:
        可选 ``(conn) -> bool``；acquire 空闲连接前调用，返回 False 视为坏连接。
    on_close:
        可选 ``(conn) -> None``；连接被丢弃/关闭时调用，用于释放底层资源。
    name:
        池名称，用于日志与统计标识。
    """

    def __init__(
        self,
        factory: Callable[[str], Any],
        max_per_key: Optional[int] = None,
        idle_timeout: float = 300.0,
        health_check: Optional[Callable[[Any], bool]] = None,
        on_close: Optional[Callable[[Any], None]] = None,
        name: str = "connection_pool",
    ) -> None:
        self._factory = factory
        self._max_per_key = max(1, int(max_per_key if max_per_key is not None else _adaptive_max_per_key()))
        self._idle_timeout = float(idle_timeout)
        self._health_check = health_check
        self._on_close = on_close
        self.name = name
        self._lock = threading.RLock()
        # key -> list[_IdleEntry]（队尾为最近归还，优先复用）
        self._free: Dict[str, List[_IdleEntry]] = {}
        self._stats = PoolStats()

    # ------------------------------------------------------------------ acquire
    def acquire(self, key: str = "default") -> Any:
        """取一条连接：优先复用该 key 的健康空闲连接，否则锁外新建、锁内入池。"""
        # 1. 尝试从池中获取有效连接
        conn = self._get_valid_connection(key)
        if conn:
            return conn

        # 2. 池中无可用连接，锁外创建新连接（避免阻塞其他线程）
        logger.debug("[%s] creating new connection for key: %s", self.name, key)
        conn = self._factory(key)

        # 3. 锁内二次检查：若建连期间其他线程已归还连接，尝试复用
        with self._lock:
            if self._can_add_to_pool(key):
                self._add_to_pool(conn, key)
                # 成功加入池中，返回刚加入的连接（即 conn）
                return conn

        # 4. 池已满，直接返回新建连接
        return conn

    # ------------------------------------------------------------------ release
    def release(self, conn: Any, key: str = "default") -> None:
        """归还连接到池中；超过每 key 上限时直接关闭。"""
        with self._lock:
            self._stats.active = max(0, self._stats.active - 1)
            free = self._free.setdefault(key, [])
            if len(free) >= self._max_per_key:
                self._drop(conn)
                self._stats.evicted += 1
                logger.debug("[%s] evicting connection for key: %s (pool full)", self.name, key)
            else:
                free.append(_IdleEntry(conn=conn, last_used=time.monotonic()))
                self._stats.idle += 1

    # ------------------------------------------------------------------ prebuild
    def prebuild(self, key: str, n: int = 1) -> int:
        """预建 n 条连接放入 key 的空闲队列（常用模型连接预热）。

        返回实际预建数量（受 max_per_key 上限约束）。
        """
        built = 0
        for _ in range(max(0, int(n))):
            with self._lock:
                free = self._free.setdefault(key, [])
                if len(free) >= self._max_per_key:
                    break
            try:
                conn = self._factory(key)
            except Exception as exc:  # 预建失败不致命，记录后继续
                logger.warning("[%s] prebuild failed for %s: %s", self.name, key, exc)
                self._stats.failed += 1
                break
            with self._lock:
                free.append(_IdleEntry(conn=conn, last_used=time.monotonic()))
                self._stats.created += 1
                self._stats.idle += 1
                built += 1
        return built

    # ------------------------------------------------------------------ eviction
    def reap_idle(self, now: Optional[float] = None) -> int:
        """释放空闲超时连接，返回释放数量。"""
        now = time.monotonic() if now is None else now
        released = 0
        with self._lock:
            for key, free in list(self._free.items()):
                kept: List[_IdleEntry] = []
                for entry in free:
                    age = now - entry.last_used
                    if age > self._idle_timeout:
                        self._drop(entry.conn)
                        released += 1
                        self._stats.evicted += 1
                    else:
                        kept.append(entry)
                self._free[key] = kept
                if not kept:
                    self._free.pop(key, None)
            self._stats.idle = max(0, self._stats.idle - released)
        return released

    def health_scan(self) -> int:
        """对全部空闲连接做健康探测，丢弃坏连接，返回丢弃数量。"""
        dropped = 0
        with self._lock:
            for key, free in list(self._free.items()):
                kept: List[_IdleEntry] = []
                for entry in free:
                    if self._is_healthy(entry.conn):
                        kept.append(entry)
                    else:
                        self._drop(entry.conn)
                        dropped += 1
                        self._stats.failed += 1
                self._free[key] = kept
                if not kept:
                    self._free.pop(key, None)
            self._stats.idle = max(0, self._stats.idle - dropped)
        return dropped

    # ------------------------------------------------------------------ helpers
    def _get_valid_connection(self, key: str) -> Optional[Any]:
        """从池中获取一条健康连接，更新统计信息。"""
        free = self._free.get(key)
        while free:
            entry = free.pop()
            if self._is_healthy(entry.conn):
                self._stats.reused += 1
                self._stats.active += 1
                self._stats.idle = max(0, self._stats.idle - 1)
                return entry.conn
            # 坏连接：关闭并计入失败
            self._drop(entry.conn)
            self._stats.failed += 1
        return None

    def _can_add_to_pool(self, key: str) -> bool:
        """检查是否可以添加新连接到池中。"""
        free = self._free.get(key)
        return free is not None and len(free) < self._max_per_key

    def _add_to_pool(self, conn: Any, key: str) -> None:
        """将连接加入空闲队列。"""
        self._free.setdefault(key, []).append(_IdleEntry(conn=conn, last_used=time.monotonic()))
        self._stats.idle += 1

    def _is_healthy(self, conn: Any) -> bool:
        """检查连接是否健康。"""
        if self._health_check is None:
            return True
        try:
            return bool(self._health_check(conn))
        except Exception:
            return False

    def _drop(self, conn: Any) -> None:
        """丢弃连接并调用 on_close 回调。"""
        if self._on_close:
            try:
                self._on_close(conn)
            except Exception as e:
                logger.warning("on_close callback failed: %s", e)


class ConnectionPoolManager:
    """连接池管理器 - 管理多个连接池实例。"""

    def __init__(self):
        self._pools: Dict[str, ConnectionPool] = {}
        self._lock = threading.RLock()

    def get_pool(self, name: str) -> Optional[ConnectionPool]:
        """获取指定名称的连接池。"""
        with self._lock:
            return self._pools.get(name)

    def register_pool(self, name: str, pool: ConnectionPool) -> None:
        """注册连接池。"""
        with self._lock:
            self._pools[name] = pool

    def close_all(self) -> None:
        """关闭所有连接池。"""
        with self._lock:
            for pool in self._pools.values():
                try:
                    pool.close()
                except Exception:
                    pass
