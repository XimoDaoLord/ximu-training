import logging
import os
import threading
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_PREFERRED_FREE: List[str] = []
_LOCAL_QWEN_HINT = ("qwen",)
_PREFERRED_LOCAL_MODELS: List[str] = ["", ""]
_LOW_MEMORY_GB: float = 0.0
_HIGH_CPU_PERCENT: float = 0.0
_resource_cache: Dict[str, Any] = {"ts": 0.0, "use_3b": True}
_config_loaded: bool = False
_lock = threading.Lock()
_cloud_fail_at: Dict[str, float] = {}
_CLOUD_BREAK_S = 30.0

def _load_model_config() -> None:
    """加载模型配置"""
    global _PREFERRED_FREE, _PREFERRED_LOCAL_MODELS
    global _LOW_MEMORY_GB, _HIGH_CPU_PERCENT, _config_loaded

    if _config_loaded:
        return

    try:
        from src.ximu.core.model_config import get_model_config
        mc = get_model_config()
        _PREFERRED_FREE = mc.get_cloud_free_models()
        _PREFERRED_LOCAL_MODELS = [
            mc.get_llm_primary().get("name", ""),
            mc.get_llm_fallback().get("name", ""),
        ]
        thresholds = mc.get_device_thresholds()
        _LOW_MEMORY_GB = float(thresholds.get("low_memory_gb", 4.0))
        _HIGH_CPU_PERCENT = float(thresholds.get("high_cpu_percent", 90.0))
    except Exception as e:
        logger.warning("配置加载失败: %s", e)
    _config_loaded = True

def _check_device_resources() -> bool:
    """检测设备资源"""
    _load_model_config()

    now = time.time()
    if now - _resource_cache.get("ts", 0) < 60:
        return _resource_cache.get("use_3b", True)

    try:
        import psutil
        mem = psutil.virtual_memory()
        available_gb = mem.available / (1024 ** 3)
        cpu_percent = psutil.cpu_percent(interval=0.5)
        use_3b = available_gb >= _LOW_MEMORY_GB and cpu_percent <= _HIGH_CPU_PERCENT
        if not use_3b:
            logger.info("降级到1.5B")
        _resource_cache["ts"] = now
        _resource_cache["use_3b"] = use_3b
        return use_3b
    except Exception as e:
        logger.debug("资源检测失败: %s", e)
        _resource_cache["ts"] = now
        _resource_cache["use_3b"] = True
        return True

def _cloud_once(model: str, prompt: str, timeout: float) -> Optional[str]:
    """调用云端模型"""
    from src.ximu.core.live_model_gateway import chat

    r = chat(prompt, model=model, timeout=timeout)
    if r.get("ok"):
        c = str(r.get("content") or "").strip()
        if c and not c.startswith("[local:"):
            return c
    return None

def _find_local_qwen_id() -> Optional[str]:
    """查找本地qwen模型"""
    _load_model_config()
    try:
        from src.ximu.core.local_model_manager import get_local_model_manager
        lmm = get_local_model_manager()
        lmm.initialize()
        repo = lmm.resolve_unified_repo_dir()
        if repo and os.path.isdir(repo):
            lmm.scan_directory(repo)
            all_qwen = []
            for m in (lmm.get_models(enabled_only=True) or []):
                path = str(getattr(m, "path", "") or "").lower()
                name = str(getattr(m, "name", "") or "").lower()
                if path.endswith(".gguf") and any(h in path for h in _LOCAL_QWEN_HINT):
                    mid = getattr(m, "model_id", None) or getattr(m, "name", None)
                    all_qwen.append((mid, path))
                elif any(h in name for h in _LOCAL_QWEN_HINT) and "vlm" not in path and "multimodal" not in path:
                    mid = getattr(m, "model_id", None) or getattr(m, "name", None)
                    all_qwen.append((mid, path))
            if not all_qwen:
                return None
            use_3b = _check_device_resources()
            preferred = _PREFERRED_LOCAL_MODELS[0] if use_3b else _PREFERRED_LOCAL_MODELS[1]
            fallback = _PREFERRED_LOCAL_MODELS[1] if use_3b else _PREFERRED_LOCAL_MODELS[0]
            for mid, path in all_qwen:
                if preferred in path or preferred in str(mid).lower():
                    return mid
            for mid, path in all_qwen:
                if fallback in path or fallback in str(mid).lower():
                    return mid
            return all_qwen[0][0]
    except Exception as e:
        logger.debug("查找本地qwen失败: %s", e)
    return None

def _local_once(prompt: str, timeout: float, max_tokens: int) -> Optional[str]:
    """本地推理"""
    mid = _find_local_qwen_id()
    if not mid:
        return None
    from src.ximu.core.local_model_manager import get_local_model_manager
    lmm = get_local_model_manager()
    try:
        lmm._max_loaded_bytes = 2 * 1024 * 1024 * 1024
    except Exception:
        pass
    res = lmm.call_model(mid, prompt, timeout=timeout, max_tokens=max_tokens)
    if getattr(res, "success", False):
        out = str(getattr(res, "output", "") or "").strip()
        if out and not out.startswith("[local:"):
            return out
    return None

def auxiliary_chat(
    prompt: str, timeout: float = 20.0, *, prefer_local: bool = False, max_tokens: int = 512
) -> Optional[str]:
    """统一辅助模型调用"""
    _load_model_config()
    if not prompt or not str(prompt).strip():
        return None

    if not prefer_local:
        now = time.time()
        for m in _PREFERRED_FREE:
            with _lock:
                fail_t = _cloud_fail_at.get(m, 0.0)
                if fail_t and now - fail_t < _CLOUD_BREAK_S:
                    continue
            try:
                c = _cloud_once(m, prompt, min(timeout, 15.0))
                if c:
                    return c
                with _lock:
                    _cloud_fail_at[m] = time.time()
            except Exception as e:
                logger.debug("云端失败: %s", e)
                with _lock:
                    _cloud_fail_at[m] = time.time()

    try:
        c = _local_once(prompt, max(timeout, 30.0), max_tokens)
        if c:
            return c
    except Exception as e:
        logger.debug("本地失败: %s", e)

    return None

def auxiliary_available() -> bool:
    """探测辅助模型可用性"""
    try:
        return auxiliary_chat("只回复：ok", timeout=8.0, max_tokens=4) is not None
    except Exception:
        return False
