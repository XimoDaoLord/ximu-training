"""
ximu.core.ai 模块

这是一个兼容性存根，用于将 ximu.core.ai 映射到 cognition.brain。
它确保旧代码可以继续工作，而无需更改导入路径，同时提供类型安全和日志记录。

版本: 0.5
"""

import logging
from typing import Any, List

# 初始化模块日志记录器
logger = logging.getLogger(__name__)

# 版本号
__version__ = "0.5"

# 公共 API 列表
__all__: List[str] = []

# 源模块引用
_source_module: Any = None

try:
    # 动态导入源模块（优先完整路径，兼容旧路径）
    try:
        _source_module = __import__('ximu.cognition.brain', fromlist=[''])
    except ImportError:
        _source_module = __import__('cognition.brain', fromlist=[''])
    
    # 将源模块的公共属性转发到当前命名空间
    for attr in dir(_source_module):
        if not attr.startswith('_'):
            globals()[attr] = getattr(_source_module, attr)
            __all__.append(attr)
            
    logger.info("成功加载兼容性存根: ximu.core.ai -> cognition.brain")
    
except ImportError as e:
    # 降级处理：不抛出异常，AI核心功能不可用但不影响其他模块
    logger.warning("无法加载源模块 'cognition.brain'，AI 核心功能不可用（降级模式）: %s", e)

def get_brain() -> Any:
    """获取核心大脑实例的引用。
    
    此函数提供对底层大脑模块的直接访问，便于高级用户进行调试或扩展。

    Returns:
        Any: 大脑模块的引用对象。
    """
    return _source_module
