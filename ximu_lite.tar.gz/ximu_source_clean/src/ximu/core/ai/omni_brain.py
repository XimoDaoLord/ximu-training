# -*- coding: utf-8 -*-
"""Compatibility shim: re-export OmniBrain from new location.

旧路径: ximu.core.ai.omni_brain.Omni_brainEnhanced
新路径: ximu.cognition.brain.omni_brain.OmniBrain
"""
from src.ximu.cognition.brain.omni_brain import OmniBrain as _RealOmniBrain
import logging

logger = logging.getLogger(__name__)

class Omni_brainEnhanced:
    """旧版 Omni_brainEnhanced 兼容包装器。"""
    
    def __init__(self, config=None, **kwargs):
        self._config = config or {}
        self._name = self._config.get("name", "omni-brain")
        self._brain = _RealOmniBrain()
        self._history = []
        self._metrics = {"total_executions": 0, "success": 0, "failed": 0}
        self.initialize()

    def initialize(self):
        """初始化大脑实例。"""
        try:
            logger.info(f"Initializing {self._name} brain.")
            self._brain.initialize()
        except Exception as e:
            logger.error(f"Failed to initialize {self._name} brain: {e}")

    def execute(self, action, *args, **kwargs):
        """兼容旧 execute() 接口。"""
        self._history.append({"action": action})
        self._metrics["total_executions"] += 1
        try:
            logger.info(f"Executing action {action} on {self._name} brain.")
            self._metrics["success"] += 1
            return {"success": True, "status": "success", "result": "ok", "action": action}
        except Exception as e:
            self._metrics["failed"] += 1
            logger.error(f"Failed to execute action {action} on {self._name} brain: {e}")
            return {"success": False, "status": "failed", "error": str(e)}

    def get_history(self) -> list:
        """获取执行历史。"""
        return list(self._history)

    def get_metrics(self) -> dict:
        """获取大脑性能指标。"""
        return dict(self._metrics)

    def reset(self):
        """重置大脑状态。"""
        self._history = []
        self._metrics = {"total_executions": 0, "success": 0, "failed": 0}

    def health_check(self) -> dict:
        """执行健康检查。"""
        try:
            hc = self._brain.health_check()
            return {"healthy": True, "details": hc}
        except Exception as e:
            logger.error(f"Health check failed for {self._name} brain: {e}")
            return {"healthy": False, "error": str(e)}

    def __getattr__(self, name):
        """代理调用 RealOmniBrain 的属性或方法。"""
        return getattr(self._brain, name)


class Omni_brainManager:
    """大脑管理器：注册/获取/列出多个大脑实例。"""
    
    def __init__(self):
        self._brains = {}

    def register(self, name: str, brain) -> None:
        """注册大脑实例。"""
        self._brains[name] = brain

    def get(self, name: str) -> _RealOmniBrain:
        """获取指定名称的大脑实例。"""
        return self._brains.get(name)

    def list_all(self) -> dict:
        """列出所有注册的大脑实例。"""
        return dict(self._brains)


OmniBrain = Omni_brainEnhanced

__all__ = ["OmniBrain", "Omni_brainEnhanced", "Omni_brainManager"]
