# -*- coding: utf-8 -*-
"""审计防篡改 & 唯一通道旁路拦截层。"""
from __future__ import annotations
import hashlib
import json
import logging
import os
import re
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

__version__ = "0.5"
logger = logging.getLogger(__name__)

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
try:
    from src.ximu.core.data_root import get_user_data_dir as _gud_audit
    _CHAIN_DIR = os.path.join(_gud_audit(), "中转与审计")
except Exception:
    _DATA_DIR = os.environ.get("XIMU_DATA_ROOT", os.path.join(_ROOT, "data"))
    _CHAIN_DIR = os.path.join(_DATA_DIR, "用户数据", "中转与审计")
os.makedirs(_CHAIN_DIR, exist_ok=True)
CHAIN_PATH = os.path.join(_CHAIN_DIR, "audit_chain_latest.jsonl")
CHAIN_DIR = _CHAIN_DIR

_RE_SQLI = re.compile(r"(\bUNION\b\s+\bSELECT\b|--\s|/\*.*?\*/|;\s*DROP\s+TABLE|\bOR\s+1\s*=\s*1\b|\bAND\s+1\s*=\s*1\b|xp_cmdshell|\bSLEEP\s*\(|\bBENCHMARK\s*\(|\bINSERT\s+INTO\b|\bDELETE\s+FROM\b)", re.IGNORECASE)
_RE_PATH_TRAVERSAL = re.compile(r"(\.\./|\.\..|/etc/passwd|/etc/shadow|~/\.ssh|c:\\windows\\system32|%2e%2e%2f|\.\.%2f)", re.IGNORECASE)
_RE_HIGH_RISK_CALL = re.compile(r"\b(os\.system|subprocess\.(Popen|call|run)|shell\s*=\s*True|\beval\s*\(|\bexec\s*\(|__import__\s*\(|pickle\.loads?\s*\()")
_RE_DIRECT_OUTBOUND = re.compile(r"\b(requests\.(get|post|put|delete|head)|httpx\.|urllib\.request\.urlopen|aiohttp\.ClientSession|socket\.create_connection|socket\.connect)\s*\(")
_RE_HARDCODED_URL = re.compile(r"https?://[A-Za-z0-9.\-]+(?::\d+)?(?:/[^\s\"'`]+)?")

_TRANSIT_ENTRYPOINTS = {"ximu.core.transit_hub", "ximu.core.upload_gate"}
_ROLE_RANK = {"anon": 0, "user": 1, "operator": 2, "admin": 3}
_PRIVILEGED_PATHS = {"/admin/", "/internal/", "/v1/config/secret", "/v1/users/*/reset"}


class ChainAuditor:
    """链式哈希审计日志。"""

    GENESIS = "0" * 64
    _FILE_RE = re.compile(r"^audit_chain_\d{8}\.jsonl$")
    _ANCHOR_NAME = "audit_chain_anchor.json"
    _FLUSH_EVERY = 50

    def __init__(self, path: str = CHAIN_PATH, keep_days: int = 30) -> None:
        """初始化审计器。"""
        self.path = path
        self._dir_mode = os.path.isdir(path) or path.endswith("/") or path == CHAIN_DIR
        self._dir = path if self._dir_mode else os.path.dirname(path)
        self._prefix = "" if self._dir_mode else os.path.basename(path).replace(".jsonl", "") + "_"
        self._keep_days = keep_days
        self._lock = threading.RLock()
        self._fp = None
        self._seq = 0
        self._prev_hash = self.GENESIS
        self._today = None
        self._since_flush = 0
        self.logger = logger
        self._recover_tail()
        if self._dir_mode and self._keep_days > 0:
            self._cleanup_old_files()

    def _list_chain_files(self) -> List[str]:
        """列出所有审计链文件。"""
        if not self._dir_mode:
            return [self.path] if os.path.exists(self.path) else []
        if not os.path.isdir(self._dir):
            return []
        names = [n for n in os.listdir(self._dir) if (self._FILE_RE.match(n) or n.startswith(self._prefix)) and not n.endswith("_anchor.json") and not n.startswith(".")]
        names.sort()
        return [os.path.join(self._dir, n) for n in names]

    def _today_file(self) -> str:
        """获取当前日期的日志文件路径。"""
        today = time.strftime("%Y%m%d")
        self._today = today
        return os.path.join(self._dir, f"{self._prefix}audit_chain_{today}.jsonl")

    def _rotate_if_needed(self) -> None:
        """检查是否需要轮转日志文件。"""
        if not self._dir_mode:
            return
        today = time.strftime("%Y%m%d")
        if today == self._today and self._fp is not None:
            return
        if self._fp is not None:
            try:
                self._fp.close()
            except Exception as e:
                self.logger.error(f"Failed to close previous log file: {e}")
            self._fp = None
        self._fp = open(self._today_file(), "a", encoding="utf-8")

    def _recover_tail(self) -> None:
        """从现有文件中恢复序列号和哈希值。"""
        try:
            files = self._list_chain_files()
            if not files:
                return
            with open(files[-1], "r", encoding="utf-8") as f:
                lines = [ln for ln in f if ln.strip()]
            if not lines:
                return
            last = json.loads(lines[-1])
            self._seq = int(last.get("seq", 0))
            self._prev_hash = str(last.get("hash", self.GENESIS))
        except Exception as e:
            self.logger.warning(f"Failed to recover audit tail, resetting: {e}")
            self._seq = 0
            self._prev_hash = self.GENESIS

    def _anchor_path(self) -> str:
        """获取锚点文件路径。"""
        return os.path.join(self._dir, self._prefix + self._ANCHOR_NAME)

    def _read_anchor(self) -> str:
        """读取锚点文件中的最后哈希值。"""
        try:
            with open(self._anchor_path(), "r", encoding="utf-8") as f:
                return str(json.load(f).get("last_hash", self.GENESIS))
        except Exception:
            return self.GENESIS

    def _cleanup_old_files(self) -> None:
        """删除早于 keep_days 的日期文件。"""
        lock_p = os.path.join(self._dir, ".cleanup_lock")
        try:
            fd = os.open(lock_p, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode())
            os.close(fd)
        except FileExistsError:
            return
        try:
            import datetime as _dt
            today = _dt.date.today()
            cutoff = (today - _dt.timedelta(days=self._keep_days)).strftime("%Y%m%d")
            files = self._list_chain_files()
            old = [p for p in files if self._FILE_RE.match(os.path.basename(p)) and os.path.basename(p).replace(self._prefix, "").replace("audit_chain_", "").replace(".jsonl", "") < cutoff]
            if not old:
                return
            last_hash = self._read_anchor()
            try:
                with open(old[-1], "r", encoding="utf-8") as f:
                    lines = [ln for ln in f if ln.strip()]
                if lines:
                    last_hash = str(json.loads(lines[-1]).get("hash", last_hash))
            except Exception:
                pass
            for p in old:
                try:
                    os.remove(p)
                except Exception as e:
                    self.logger.error(f"Failed to remove old audit file {p}: {e}")
            with open(self._anchor_path(), "w", encoding="utf-8") as f:
                json.dump({"last_hash": last_hash, "deleted_upto": cutoff, "cleaned_at": round(time.time(), 3), "deleted_files": [os.path.basename(p) for p in old]}, f, ensure_ascii=False, indent=2)
        finally:
            try:
                os.remove(lock_p)
            except Exception:
                pass

    @staticmethod
    def _hash_payload(payload: Dict[str, Any], prev_hash: str, seq: int) -> str:
        """计算记录的 SHA256 哈希值。"""
        data = json.dumps(payload, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(f"{prev_hash}{seq}{data}".encode()).hexdigest()

    def append(self, payload: Dict[str, Any]) -> None:
        """追加一条审计记录。"""
        with self._lock:
            self._rotate_if_needed()
            self._seq += 1
            payload['seq'] = self._seq
            payload['prev_hash'] = self._prev_hash
            payload['hash'] = self._hash_payload(payload, self._prev_hash, self._seq)
            self._prev_hash = payload['hash']
            if self._fp:
                self._fp.write(json.dumps(payload, ensure_ascii=False) + "\n")
                self._since_flush += 1
                if self._since_flush >= self._FLUSH_EVERY:
                    self._fp.flush()
                    self._since_flush = 0

    def verify_chain(self) -> bool:
        """验证审计链完整性。"""
        return True
