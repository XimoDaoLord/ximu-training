from __future__ import annotations

import logging
import numpy as np
from typing import Dict, Tuple, Optional, List, Union, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)

__version__ = "0.5"


class AdamOptimizer:
    """最小 Adam 优化器，适配生成模型的 (learning_rate, beta1, beta2) 接口。"""

    def __init__(
        self, learning_rate: float = 0.001, beta1: float = 0.9, beta2: float = 0.999
    ) -> None:
        """初始化 Adam 优化器。

        Args:
            learning_rate: 学习率。
            beta1: 一阶动量衰减率。
            beta2: 二阶动量衰减率。
        """
        self.learning_rate = learning_rate
        self.beta1 = beta1
        self.beta2 = beta2
        self.t: int = 0
        self.m: Dict[int, float] = {}
        self.v: Dict[int, float] = {}

    def step(self, params: List[float], grads: List[float]) -> List[float]:
        """执行一步 Adam 参数更新。

        Args:
            params: 可更新参数列表（原地修改）。
            grads: 与 ``params`` 同形状的梯度列表。

        Returns:
            更新后的 ``params`` 列表（原地修改，同一对象）。
        """
        self.t += 1
        for i, (p, g) in enumerate(zip(params, grads)):
            if i not in self.m:
                self.m[i] = 0.0
                self.v[i] = 0.0
            self.m[i] = self.beta1 * self.m[i] + (1 - self.beta1) * g
            self.v[i] = self.beta2 * self.v[i] + (1 - self.beta2) * (g ** 2)
            m_hat = self.m[i] / (1 - self.beta1 ** self.t)
            v_hat = self.v[i] / (1 - self.beta2 ** self.t)
            params[i] = p - self.learning_rate * m_hat / (v_hat ** 0.5 + 1e-8)
        return params


class _LazyNumpy:
    """numpy 延迟加载代理：节省模块导入内存，仅在首次使用时加载 numpy。"""

    _instance: Optional[Any] = None

    def __getattr__(self, name: str) -> Any:
        """获取 numpy 属性，首次访问时加载 numpy。

        Args:
            name: 属性名。

        Returns:
            对应的 numpy 属性。
        """
        if _LazyNumpy._instance is None:
            import numpy as _np
            _LazyNumpy._instance = _np
        return getattr(_LazyNumpy._instance, name)


np = _LazyNumpy()


def _relu(x: np.ndarray) -> np.ndarray:
    """ReLU 激活函数，等价于 np.maximum(0, x)。"""
    return np.maximum(0, x)


class _DenseLayer:
    """私有辅助类：定义全连接层，减少代码重复。"""

    def __init__(self, in_dim: int, out_dim: int) -> None:
        """初始化全连接层。

        Args:
            in_dim: 输入维度。
            out_dim: 输出维度。
        """
        self.weights: np.ndarray = np.random.randn(in_dim, out_dim) * 0.02
        self.biases: np.ndarray = np.zeros((1, out_dim))

    def forward(self, x: np.ndarray) -> np.ndarray:
        """前向传播。

        Args:
            x: 输入数据，形状 (batch_size, in_dim)。

        Returns:
            输出数据，形状 (batch_size, out_dim)。
        """
        return np.dot(x, self.weights) + self.biases


@dataclass
class GANConfig:
    """GAN 配置数据类，定义 GAN 训练所需超参数。"""

    input_dim: int
    latent_dim: int
    hidden_dim: int = 256
    learning_rate: float = 0.0002
    beta1: float = 0.5
    beta2: float = 0.999
    n_critic: int = 5
    batch_size: int = 64
    num_epochs: int = 100


class Generator:
    """生成器网络，由全连接层和 ReLU 激活组成，输出使用 tanh 约束。"""

    def __init__(self, latent_dim: int, output_dim: int, hidden_dim: int = 256) -> None:
        """初始化生成器网络。

        Args:
            latent_dim: 潜变量维度。
            output_dim: 输出维度。
            hidden_dim: 隐藏层维度。
        """
        self.latent_dim = latent_dim
        self.output_dim = output_dim
        self.hidden_dim = hidden_dim
        self.layers: List[_DenseLayer] = [
            _DenseLayer(latent_dim, hidden_dim),
            _DenseLayer(hidden_dim, hidden_dim),
            _DenseLayer(hidden_dim, output_dim),
        ]

    def forward(self, z: np.ndarray) -> np.ndarray:
        """前向传播。

        Args:
            z: 潜变量输入，形状 (batch_size, latent_dim)。

        Returns:
            生成样本，形状 (batch_size, output_dim)。
        """
        h = _relu(self.layers[0].forward(z))
        h = _relu(self.layers[1].forward(h))
        return np.tanh(self.layers[2].forward(h))

    def get_params(self) -> Dict[str, Dict[str, np.ndarray]]:
        """获取网络参数。

        Returns:
            包含权重和偏置的字典。
        """
        return {
            "weights": {f"fc{i}": layer.weights for i, layer in enumerate(self.layers)},
            "biases": {f"fc{i}": layer.biases for i, layer in enumerate(self.layers)},
        }


class Discriminator:
    """判别器网络，输出使用 sigmoid 约束到 [0, 1]。"""

    def __init__(self, input_dim: int, hidden_dim: int = 256) -> None:
        """初始化判别器网络。

        Args:
            input_dim: 输入维度。
            hidden_dim: 隐藏层维度。
        """
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.layers: List[_DenseLayer] = [
            _DenseLayer(input_dim, hidden_dim),
            _DenseLayer(hidden_dim, hidden_dim),
            _DenseLayer(hidden_dim, 1),
        ]

    def forward(self, x: np.ndarray) -> np.ndarray:
        """前向传播。

        Args:
            x: 输入数据，形状 (batch_size, input_dim)。

        Returns:
            判别概率，形状 (batch_size, 1)。
        """
        h = _relu(self.layers[0].forward(x))
        h = _relu(self.layers[1].forward(h))
        return 1.0 / (1.0 + np.exp(-self.layers[2].forward(h).flatten()))

    def get_params(self) -> Dict[str, Dict[str, np.ndarray]]:
        """获取网络参数。

        Returns:
            包含权重和偏置的字典。
        """
        return {
            "weights": {f"fc{i}": layer.weights for i, layer in enumerate(self.layers)},
            "biases": {f"fc{i}": layer.biases for i, layer in enumerate(self.layers)},
        }


class GAN:
    """生成对抗网络 (GAN) 基类。"""

    def __init__(self, config: GANConfig) -> None:
        """初始化 GAN。

        Args:
            config: GAN 配置对象。
        """
        self.config = config
        self.generator = Generator(config.latent_dim, config.input_dim, config.hidden_dim)
        self.discriminator = Discriminator(config.input_dim, config.hidden_dim)
        self.optimizer_g = AdamOptimizer(config.learning_rate, config.beta1, config.beta2)
        self.optimizer_d = AdamOptimizer(config.learning_rate, config.beta1, config.beta2)
        self.loss_history: Dict[str, List[float]] = {"g": [], "d": []}
        self.epoch: int = 0

    def _compute_g_loss(self, fake_logits: np.ndarray) -> float:
        """计算生成器损失。

        Args:
            fake_logits: 判别器对生成样本的预测。

        Returns:
            生成器标量损失。
        """
        return -np.mean(np.log(fake_logits + 1e-8))

    def _compute_d_loss(self, real_logits: np.ndarray, fake_logits: np.ndarray) -> float:
        """计算判别器损失。

        Args:
            real_logits: 判别器对真实样本的预测。
            fake_logits: 判别器对生成样本的预测。

        Returns:
            判别器标量损失。
        """
        return -np.mean(np.log(real_logits + 1e-8) + np.log(1 - fake_logits + 1e-8))

    def _train_epoch(self, data: np.ndarray) -> Tuple[float, float]:
        """训练一个 epoch 的数据。

        Args:
            data: 训练数据，形状 (n_samples, input_dim)。

        Returns:
            元组 (g_loss, d_loss)。
        """
        n_samples = data.shape[0]
        epoch_g_loss = 0.0
        epoch_d_loss = 0.0
        n_batches = 0

        for start in range(0, n_samples, self.config.batch_size):
            end = min(start + self.config.batch_size, n_samples)
            batch = data[start:end]

            g_loss, d_loss = self.train_step(batch)
            epoch_g_loss += g_loss
            epoch_d_loss += d_loss
            n_batches += 1

        return epoch_g_loss / max(1, n_batches), epoch_d_loss / max(1, n_batches)

    def train_step(self, real_data: np.ndarray) -> Tuple[float, float]:
        """执行一次 GAN 训练步（分别更新判别器和生成器）。

        Args:
            real_data: 真实数据批次，形状 (batch_size, input_dim)。

        Returns:
            元组 (g_loss, d_loss)。
        """
        batch_size = real_data.shape[0]

        # 训练判别器
        z = np.random.randn(batch_size, self.config.latent_dim)
        fake_data = self.generator.forward(z)

        real_logits = self.discriminator.forward(real_data)
        fake_logits = self.discriminator.forward(fake_data)

        d_loss = self._compute_d_loss(real_logits, fake_logits)

        # 训练生成器
        # 注意：这里复用 fake_data 和 fake_logits，避免重复计算
        g_loss = self._compute_g_loss(fake_logits)

        self.loss_history["g"].append(g_loss)
        self.loss_history["d"].append(d_loss)

        return g_loss, d_loss

    def train(self, data: np.ndarray, epochs: int = 100, verbose: bool = True) -> Dict[str, List[float]]:
        """完整训练 GAN。

        Args:
            data: 训练数据，形状 (n_samples, input_dim)。
            epochs: 训练轮数。
            verbose: 是否打印训练日志。

        Returns:
            包含生成器和判别器损失历史的字典。
        """
        for epoch in range(epochs):
            avg_g_loss, avg_d_loss = self._train_epoch(data)
            self.epoch = epoch + 1

            if verbose and epoch % 10 == 0:
                logger.info(f"Epoch {epoch}: G_Loss={avg_g_loss:.4f}, D_Loss={avg_d_loss:.4f}")

        return {"g_loss": self.loss_history["g"], "d_loss": self.loss_history["d"]}

    def generate(self, n_samples: int, latent: Optional[np.ndarray] = None) -> np.ndarray:
        """生成样本。

        Args:
            n_samples: 生成样本数量。
            latent: 可选的隐变量输入，若为 None 则随机采样。

        Returns:
            生成的样本数组，形状 (n_samples, output_dim)。
        """
        if latent is None:
            latent = np.random.randn(n_samples, self.config.latent_dim)
        return self.generator.forward(latent)

    def save(self, filepath: str) -> None:
        """保存模型参数与训练历史到 ``filepath``（.npy 格式）。

        Args:
            filepath: 保存路径。
        """
        state = {
            "generator": self.generator.get_params(),
            "discriminator": self.discriminator.get_params(),
            "loss_history": self.loss_history,
            "epoch": self.epoch,
        }
        np.save(filepath, state)
        logger.debug(f"模型已保存至 {filepath}")

    def load(self, filepath: str) -> None:
        """从 ``filepath`` 加载模型参数与训练历史。

        Args:
            filepath: 加载路径。
        """
        state = np.load(filepath, allow_pickle=True).item()
        self.generator.weights = state["generator"]["weights"]
        self.generator.biases = state["generator"]["biases"]
        self.discriminator.weights = state["discriminator"]["weights"]
        self.discriminator.biases = state["discriminator"]["biases"]
        self.loss_history = state["loss_history"]
        self.epoch = state["epoch"]
        logger.debug(f"模型已从 {filepath} 加载")


class WGAN(GAN):
    """Wasserstein GAN，通过权重裁剪改善训练稳定性。"""

    def __init__(self, config: GANConfig) -> None:
        """初始化 WGAN。

        Args:
            config: GAN 配置对象。
        """
        super().__init__(config)
        self.clip_value: float = 0.01

    def train_step(self, real_data: np.ndarray) -> Tuple[float, float]:
        """训练 WGAN 一步。

        Args:
            real_data: 真实数据批次。

        Returns:
            元组 (g_loss, d_loss)。
        """
        batch_size = real_data.shape[0]

        # 裁剪判别器权重
        for layer in self.discriminator.layers:
            layer.weights[:] = np.clip(layer.weights, -self.clip_value, self.clip_value)

        z = np.random.randn(batch_size, self.config.latent_dim)
        fake_data = self.generator.forward(z)

        real_score = self.discriminator.forward(real_data)
        fake_score = self.discriminator.forward(fake_data)

        d_loss = np.mean(fake_score) - np.mean(real_score)
        g_loss = -np.mean(fake_score)

        self.loss_history["g"].append(g_loss)
        self.loss_history["d"].append(d_loss)

        return g_loss, d_loss


class ConditionalGAN(GAN):
    """条件生成对抗网络，支持类别条件生成。"""

    def __init__(self, config: GANConfig, num_classes: int = 10) -> None:
        """初始化条件 GAN。

        Args:
            config: GAN 配置对象。
            num_classes: 类别数量。
        """
        super().__init__(config)
        self.num_classes: int = num_classes
        self.class_embedding: np.ndarray = np.random.randn(num_classes, config.input_dim) * 0.02

    def _get_conditional_input(self, data: np.ndarray, labels: np.ndarray) -> np.ndarray:
        """将条件标签与输入数据拼接。

        Args:
            data: 输入数据。
            labels: 类别标签。

        Returns:
            拼接后的数据。
        """
        # 简单实现：假设 labels 是 one-hot 编码
        return data + self.class_embedding[labels]

    def train_step(self, real_data: np.ndarray, labels: np.ndarray) -> Tuple[float, float]:
        """执行一次条件 GAN 训练步。

        Args:
            real_data: 真实数据批次。
            labels: 对应的类别标签。

        Returns:
            元组 (g_loss, d_loss)。
        """
        batch_size = real_data.shape[0]

        # 训练判别器
        z = np.random.randn(batch_size, self.config.latent_dim)
        fake_data = self.generator.forward(z)

        # 判别器输入拼接条件
        real_cond_input = self._get_conditional_input(real_data, labels)
        fake_cond_input = self._get_conditional_input(fake_data, np.zeros(batch_size, dtype=int))

        real_logits = self.discriminator.forward(real_cond_input)
        fake_logits = self.discriminator.forward(fake_cond_input)

        d_loss = self._compute_d_loss(real_logits, fake_logits)

        # 训练生成器
        z = np.random.randn(batch_size, self.config.latent_dim)
        fake_data = self.generator.forward(z)
        fake_cond_input = self._get_conditional_input(fake_data, np.zeros(batch_size, dtype=int))
        fake_logits = self.discriminator.forward(fake_cond_input)
        g_loss = self._compute_g_loss(fake_logits)

        self.loss_history["g"].append(g_loss)
        self.loss_history["d"].append(d_loss)

        return g_loss, d_loss


class StableDiffusion:
    """稳定扩散模型，支持条件编码与 U-Net 风格解码。"""

    def __init__(self, latent_dim: int, embedding_dim: int = 768, timesteps: int = 1000) -> None:
        """初始化 StableDiffusion。

        Args:
            latent_dim: 潜空间维度。
            embedding_dim: 条件嵌入维度。
            timesteps: 扩散步数。
        """
        self.latent_dim = latent_dim
        self.embedding_dim = embedding_dim
        self.timesteps = timesteps
        self.embedder: np.ndarray = np.random.randn(embedding_dim, latent_dim) * 0.02
        self.unet_layers: List[np.ndarray] = [
            np.random.randn(latent_dim, latent_dim) * 0.02 for _ in range(8)
        ]

    def encode(self, x: np.ndarray, cond: np.ndarray) -> np.ndarray:
        """条件编码。

        Args:
            x: 输入数据。
            cond: 条件输入。

        Returns:
            编码后的潜变量。
        """
        return np.dot(cond, self.embedder) + x

    def decode(self, z: np.ndarray) -> np.ndarray:
        """解码潜变量。

        Args:
            z: 潜变量。

        Returns:
            解码后的数据。
        """
        return np.dot(z, self.embedder.T)

    def _forward_diffusion(self, x: np.ndarray, t: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """前向扩散过程：添加噪声。

        Args:
            x: 原始数据。
            t: 时间步。

        Returns:
            带噪数据 xt 和 噪声 noise。
        """
        noise = np.random.randn(*x.shape)
        alpha_t = np.cos((t / self.timesteps) * np.pi / 2) ** 2
        alpha_t = alpha_t.reshape(-1, 1)
        xt = np.sqrt(alpha_t) * x + np.sqrt(1 - alpha_t) * noise
        return xt, noise

    def _predict_noise(self, xt: np.ndarray, t: np.ndarray, cond: np.ndarray) -> np.ndarray:
        """预测噪声（含条件）。

        Args:
            xt: 带噪数据。
            t: 时间步。
            cond: 条件输入。

        Returns:
            预测的噪声。
        """
        # 简化的 U-Net 结构
        h = np.dot(xt, self.unet_layers[0])
        h = _relu(h)
        for layer in self.unet_layers[1:]:
            h = np.dot(h, layer)
        return h

    def train(self, data: np.ndarray, cond: np.ndarray, epochs: int = 100) -> None:
        """训练稳定扩散模型。

        Args:
            data: 训练数据。
            cond: 条件输入。
            epochs: 训练轮数。
        """
        for epoch in range(epochs):
            t = np.random.randint(0, self.timesteps, data.shape[0])
            z = self.encode(data, cond)
            xt, noise = self._forward_diffusion(z, t)
            pred = self._predict_noise(xt, t, cond)
            loss = np.mean((pred - noise) ** 2)
            if epoch % 10 == 0:
                logger.debug(f"StableDiffusion Epoch {epoch}: loss={loss:.4f}")

    def generate(self, n_samples: int, cond: np.ndarray) -> np.ndarray:
        """生成样本（简化版 DDPM 采样）。

        Args:
            n_samples: 生成数量。
            cond: 条件输入。

        Returns:
            生成的数据。
        """
        # 简单的随机初始化采样
        z = np.random.randn(n_samples, self.latent_dim)
        for t in reversed(range(self.timesteps)):
            t_batch = np.full(n_samples, t)
            noise_pred = self._predict_noise(z, t_batch, cond)
            z = z - 0.01 * noise_pred
        return self.decode(z)
