# -*- coding: utf-8 -*-
"""端口冲突自愈守卫（可注入，测试不抢 5000/5002）。

启动时若目标端口被占：
  1) 探测占用者；
  2) 可注入 killer 强杀占用者；
  3) 释放后复用原端口，否则向上挑选一个空闲端口。

所有副作用（探测、杀进程）都通过参数注入，默认实现走真实 socket + os.kill，
测试时传临时端口/假 killer 即可，绝不真抢 5000/5002。
"""
from __future__ import annotations

import logging
import os
import socket
import time
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

__version__ = "0.5"

# 定义类型别名
OccupantFinder = Callable[[str, int], Optional[int]]
Killer = Callable[[int], bool]
Probe = Callable[[str, int], bool]

# 日志器
logger = logging.getLogger(__name__)

# 常量定义
_MAX_PORT = 65535
_DEFAULT_SCAN_LIMIT = 50
_DEFAULT_SETTLE_S = 0.05


def is_port_busy(port: int, host: str = "127.0.0.1",
                 probe: Optional[Probe] = None) -> bool:
    """探测端口是否被占用。probe 可注入；默认尝试 bind 失败即视为占用。

    Args:
        port: 要检查的端口号。
        host: 绑定目标地址，默认为 "127.0.0.1"。
        probe: 可选的探测函数，签名为 (host, port) -> bool。如果提供，
               将调用该函数并返回其结果。

    Returns:
        bool: 如果端口被占用返回 True，否则返回 False。

    Raises:
        ValueError: 如果 probe 不是有效的 callable。
    """
    if probe is not None:
        if not callable(probe):
            raise ValueError("probe must be callable or None")
        return probe(host, port)
    
    s: Optional[socket.socket] = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # 关闭 REUSEADDR 以确保检测行为一致
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 0)
        s.bind((host, port))
        return False  # 能 bind 说明空闲
    except OSError:
        return True
    finally:
        if s is not None:
            s.close()


def free_port(host: str = "127.0.0.1") -> int:
    """最快的空闲端口探测：bind(0) 让 OS 分配一个再关闭。

    Args:
        host: 绑定目标地址，默认为 "127.0.0.1"。

    Returns:
        int: 操作系统分配的空闲端口号。

    Raises:
        OSError: 如果无法创建 socket 或绑定失败。
    """
    s: Optional[socket.socket] = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((host, 0))
        return s.getsockname()[1]
    finally:
        if s is not None:
            s.close()


def _default_kill(pid: int) -> bool:
    """默认强杀：SIGKILL。

    Args:
        pid: 目标进程 ID。

    Returns:
        bool: 如果成功发送终止信号返回 True，否则返回 False。
    """
    try:
        os.kill(pid, 9)
        logger.debug("Successfully sent SIGKILL to PID %d", pid)
        return True
    except ProcessLookupError:
        logger.debug("Process %d not found", pid)
        return False
    except PermissionError:
        logger.warning("No permission to kill PID %d", pid)
        return False
    except OSError as e:
        logger.warning("Failed to kill PID %d: %s", pid, e)
        return False


def _try_find_victim(find_occupant: Optional[OccupantFinder],
                     host: str, port: int) -> Optional[int]:
    """尝试查找端口占用者。

    Args:
        find_occupant: 查找占用进程 PID 的函数。
        host: 目标主机。
        port: 目标端口。

    Returns:
        占用进程 PID 或 None。
    """
    if find_occupant is None:
        return None
    if not callable(find_occupant):
        raise ValueError("find_occupant must be callable or None")
    
    try:
        victim = find_occupant(host, port)
        if victim is not None:
            logger.debug("Found occupant PID %d for port %d", victim, port)
        return victim
    except Exception as e:
        logger.debug("Exception while finding occupant for port %d: %s", port, e)
        return None


def _try_kill_victim(killer: Optional[Killer], victim: Optional[int]) -> bool:
    """尝试杀死占用者。

    Args:
        killer: 杀死进程的函数。
        victim: 目标进程 PID。

    Returns:
        bool: 是否成功杀死进程。
    """
    if victim is None:
        return False
    
    if killer is None:
        killer = _default_kill
    
    if not callable(killer):
        raise ValueError("killer must be callable")
    
    try:
        killed = bool(killer(victim))
        if killed:
            logger.debug("Successfully killed PID %d", victim)
        else:
            logger.debug("Failed to kill PID %d", victim)
        return killed
    except Exception as e:
        logger.warning("Exception while killing PID %d: %s", victim, e)
        return False


def resolve_port(preferred: int, host: str = "127.0.0.1",
                 probe: Optional[Probe] = None,
                 find_occupant: Optional[OccupantFinder] = None,
                 killer: Optional[Killer] = None,
                 scan_limit: int = _DEFAULT_SCAN_LIMIT,
                 settle_s: float = _DEFAULT_SETTLE_S) -> Tuple[int, Dict[str, Any]]:
    """解决端口冲突。

    首先检查首选端口是否可用。如果被占用，尝试查找并杀死占用进程。
    如果无法杀死或找不到占用者，则向上扫描 scan_limit 个端口寻找空闲端口。
    如果仍未找到，则使用 OS 分配随机端口作为兜底。

    Args:
        preferred: 首选端口号。
        host: 绑定目标地址。
        probe: 端口占用探测函数，默认为基于 bind 的探测。
        find_occupant: 查找端口占用进程 PID 的函数，可选。
        killer: 杀死进程函数，默认为 os.kill(pid, SIGKILL)。
        scan_limit: 向上扫描的最大端口数量。
        settle_s: 杀死进程后等待端口释放的时间（秒）。

    Returns:
        元组 (chosen_port, info)，其中 info 字典包含：
        - "action": "reused"|"killed_and_reused"|"switched"
        - "victim_pid": int 或 None
        - "killed": bool
        - "tried": 尝试过的端口列表
        - "fallback_os": 仅在兜底时使用，值为 True

    Raises:
        ValueError: 如果 scan_limit 小于 1。
    """
    if scan_limit < 1:
        raise ValueError("scan_limit must be at least 1")
        
    tried: List[int] = []
    
    # 检查首选端口
    if not is_port_busy(preferred, host, probe):
        logger.debug("Port %d is free", preferred)
        return preferred, {
            "action": "reused",
            "victim_pid": None,
            "killed": False,
            "tried": tried
        }

    logger.info("Port %d is busy, trying to resolve conflict", preferred)
    
    # 端口被占：找占用者并强杀
    victim = _try_find_victim(find_occupant, host, preferred)
    killed = _try_kill_victim(killer, victim)
    
    if killed:
        logger.debug("Killed PID %d, settling for %.3f seconds", victim, settle_s)
        time.sleep(settle_s)
        if not is_port_busy(preferred, host, probe):
            logger.info("Port %d is now free after killing PID %d", preferred, victim)
            return preferred, {
                "action": "killed_and_reused",
                "victim_pid": victim,
                "killed": True,
                "tried": tried
            }
        logger.debug("Port %d still busy after killing PID %d", preferred, victim)
    
    # 杀不掉/没有占用者信息：向上挑一个空闲端口
    for off in range(1, scan_limit + 1):
        cand = preferred + off
        tried.append(cand)
        if cand > _MAX_PORT:
            break
        if not is_port_busy(cand, host, probe):
            logger.info("Switched to port %d from preferred %d", cand, preferred)
            return cand, {
                "action": "switched",
                "victim_pid": victim,
                "killed": killed,
                "tried": tried
            }

    # 兜底：让 OS 分配
    p = free_port(host)
    tried.append(p)
    logger.info("Fallback to OS-assigned port %d", p)
    return p, {
        "action": "switched",
        "victim_pid": victim,
        "killed": killed,
        "tried": tried,
        "fallback_os": True
    }


# ============ 编排复用别名（稳定 API，勿改名） ============

def pick_free_port(host: str = "127.0.0.1") -> int:
    """返回一个立即可用的空闲端口（bind(0) 后关闭）。编排一可直接 import 复用。

    Args:
        host: 绑定目标地址。

    Returns:
        int: 一个空闲端口号。
    """
    return free_port(host)


def kill_port_occupant(port: int, host: str = "127.0.0.1",
                       find_occupant: Optional[OccupantFinder] = None,
                       killer: Optional[Killer] = None) -> Dict[str, Union[bool, int, None]]:
    """强杀占用指定端口的进程。

    Args:
        port: 目标端口。
        host: 目标地址。
        find_occupant: 查找占用进程 PID 的函数，可选。
        killer: 杀死进程的函数，默认为 SIGKILL。

    Returns:
        dict: 包含 "killed" (bool) 和 "victim_pid" (int 或 None)。
    """
    victim = _try_find_victim(find_occupant, host, port)
    killed = _try_kill_victim(killer, victim)
    
    result = {"killed": killed, "victim_pid": victim}
    if killed:
        logger.info("Killed PID %d for port %d", victim, port)
    elif victim is not None:
        logger.warning("Failed to kill PID %d for port %d", victim, port)
    else:
        logger.debug("No occupant found for port %d", port)
    
    return result


def obtain_listener(preferred: int = 0, host: str = "127.0.0.1",
                    backlog: int = 128) -> Tuple[socket.socket, int]:
    """解决 TOCTOU：直接 bind 一个仍持有的监听 socket 返回。

    编排一拿到后**不要 close**，直接 serve_forever/serve；OS 在 bind 成功到
    close 期间独占该端口，彻底消除"先选号再 bind 被抢"的竞态。
    preferred=0 表示让 OS 从 ephemeral 段分配。

    Args:
        preferred: 首选端口，0 表示由 OS 分配。
        host: 绑定地址。
        backlog: 监听队列长度。

    Returns:
        元组 (socket, chosen_port)，其中 socket 是已绑定并处于监听状态的 socket 对象。

    Raises:
        OSError: 如果所有候选端口绑定失败且兜底绑定也失败。
    """
    last_err: Optional[OSError] = None
    af = socket.AF_INET6 if ":" in host else socket.AF_INET
    candidates: List[int] = []
    
    if preferred > 0:
        candidates.append(preferred)
        # 向上扫描 50 个候选端口
        for i in range(1, _DEFAULT_SCAN_LIMIT + 1):
            p = preferred + i
            if p > _MAX_PORT:
                break
            candidates.append(p)

    for p in candidates:
        s: Optional[socket.socket] = None
        try:
            s = socket.socket(af, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((host, p))
            s.listen(backlog)
            actual_port = s.getsockname()[1]
            logger.debug("Bound listener on port %d", actual_port)
            return s, actual_port
        except OSError as e:
            last_err = e
            if s is not None:
                s.close()
            continue

    # 兜底：ephemeral
    try:
        s = socket.socket(af, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, 0))
        s.listen(backlog)
        actual_port = s.getsockname()[1]
        logger.info("Fallback to ephemeral port %d", actual_port)
        return s, actual_port
    except OSError as e:
        if last_err is not None:
            logger.error("All port candidates failed, last error: %s", last_err)
            raise e from last_err
        logger.error("Ephemeral port binding failed: %s", e)
        raise


__all__ = [
    "is_port_busy",
    "free_port",
    "pick_free_port",
    "kill_port_occupant",
    "resolve_port",
    "obtain_listener",
]
