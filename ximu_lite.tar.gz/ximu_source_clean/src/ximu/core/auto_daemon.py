# -*- coding: utf-8 -*-
"""后台自动巡检守护（用户无感）。

启动后静默在后台跑，不占界面、不弹窗：
  - 定期检查各模型连通性，挂了自动降权切换到可用模型
  - 清理过期的断点/中转临时数据
  - 检测到挂起任务自动续跑
  - 按权限等级决定巡检频率（等级越高越积极）
"""

import logging
import os
import threading
import time
from typing import Any, Dict, Optional

# 配置日志记录器
logger = logging.getLogger(__name__)

# 全局状态
_running: bool = False
_thread: Optional[threading.Thread] = None


def _interval() -> int:
    """获取当前巡检间隔。

    根据权限模式返回对应的巡检间隔（秒）。
    - standard: 120s
    - shizuku: 60s
    - root: 30s

    返回:
        int: 巡检间隔（秒）
    """
    try:
        from src.ximu.core import permission_gate

        mode = permission_gate.get_mode()
        intervals: Dict[str, int] = {
            "standard": 120,
            "shizuku": 60,
            "root": 30,
        }
        return intervals.get(mode, 120)
    except Exception as e:
        logger.warning("获取巡检间隔失败，使用默认值120s: %s", e)
        return 120


def _check_models() -> None:
    """模型健康巡检：挂了就记一次失败，触发自动降权切换。"""
    try:
        from src.ximu.core.subtask_supervisor import register_model_failure
        from src.ximu.core import live_model_gateway as gw

        providers = gw.load_providers(force=True)
        for provider in providers:
            if not provider.get("ok", True):
                model_name = provider.get("name")
                if model_name:
                    logger.info("模型 %s 健康检查失败，记录一次失败", model_name)
                    register_model_failure(model_name, 1)
                else:
                    logger.warning("模型提供商缺少名称字段: %s", provider)
    except Exception as e:
        logger.error("模型健康巡检失败: %s", e, exc_info=True)


def _cleanup() -> None:
    """清理过期断点文件（7天前的）。"""
    try:
        now = time.time()
        seven_days = 7 * 86400  # 7天的秒数
        checkpoint_pattern = "data/loops/checkpoint_*.json"

        for filepath in __import__('glob').glob(checkpoint_pattern):
            try:
                mtime = os.path.getmtime(filepath)
                if now - mtime > seven_days:
                    logger.info("清理过期断点文件: %s", filepath)
                    os.remove(filepath)
            except FileNotFoundError:
                # 文件可能已被其他进程删除
                logger.debug("文件不存在，跳过: %s", filepath)
            except OSError as e:
                logger.warning("清理文件 %s 失败: %s", filepath, e)
    except Exception as e:
        logger.error("清理过期断点文件失败: %s", e, exc_info=True)


def _resumetask() -> None:
    """检测挂起任务并自动续跑。

    此函数检查是否有中断的任务需要恢复执行。
    由于原始代码中未实现具体逻辑，此处保留占位函数以维护API兼容性。
    """
    try:
        # 原始代码未实现具体续跑逻辑，此处保持为空但记录日志
        logger.debug("执行任务续跑检查（当前无具体实现）")
    except Exception as e:
        logger.error("任务续跑检查失败: %s", e, exc_info=True)


def loop() -> None:
    """主循环：持续执行巡检、清理和任务续跑。

    此函数在独立线程中运行，直到 _running 被设为 False。
    每次迭代间隔由 _interval() 动态决定。
    """
    global _running

    logger.info("守护进程主循环启动")

    while _running:
        try:
            _check_models()
            _cleanup()
            _resumetask()
        except Exception as e:
            # 不吞异常，记录日志但不中断循环
            logger.error("守护循环执行出错: %s", e, exc_info=True)

        # 使用小步睡眠，以便快速响应停止信号
        interval = _interval()
        for _ in range(interval):
            if not _running:
                break
            time.sleep(1)

    logger.info("守护进程主循环结束")


def start() -> Dict[str, Any]:
    """启动后台守护线程。

    如果守护线程已在运行，则直接返回。

    返回:
        dict: 包含状态信息的字典
    """
    global _running, _thread

    if _running:
        logger.debug("守护进程已在运行，忽略启动请求")
        return {"ok": True, "already": True}

    _running = True
    _thread = threading.Thread(target=loop, daemon=True, name="XimuAutoDaemon")
    _thread.start()
    logger.info("守护进程已启动，间隔: %s秒", _interval())
    return {"ok": True, "interval_s": _interval()}


def stop() -> Dict[str, Any]:
    """停止后台守护线程。

    设置标志位让主循环自然退出。

    返回:
        dict: 包含状态信息的字典
    """
    global _running

    _running = False
    logger.info("守护进程停止请求已发出")
    return {"ok": True}


def status() -> Dict[str, Any]:
    """获取守护进程当前状态。

    返回:
        dict: 包含运行状态和当前间隔的字典
    """
    return {
        "running": _running,
        "interval_s": _interval(),
    }
