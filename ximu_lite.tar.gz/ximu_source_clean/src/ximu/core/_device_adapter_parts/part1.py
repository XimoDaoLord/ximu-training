"""设备适配层基础工具模块 - 核心基础设施部分

提供计时器、重试机制、安全 JSON 处理、ID 生成等通用工具。
业务枚举请参见 enums.py，数据模型请参见 models.py。

模块职责:
- 提供线程安全的 Stopwatch 计时器
- 提供指数退避重试装饰器（同步/异步）
- 提供安全 JSON 序列化/反序列化工具
- 提供唯一 ID 生成器
- 提供时间戳工具函数

使用示例:
    from src.ximu.core._device_adapter_parts.part1 import (
        Stopwatch, retry_on_failure, safe_json_dumps, safe_json_loads,
        generate_id, now_timestamp, now_timestamp_ms
    )
"""

import asyncio
import json
import logging
import threading
import time
import uuid
from functools import wraps
from typing import Any, Callable, Optional, Tuple, TypeVar, Union
from contextlib import contextmanager

logger = logging.getLogger(__name__)

T = TypeVar("T")
F = TypeVar("F", bound=Callable[..., Any])


class ConfigProxy:
    """配置代理对象，支持熔断和兜底机制

    通过状态机管理配置加载过程，失败时自动降级
    """

    def __init__(self) -> None:
        self.config: dict[str, Any] = {}
        self.get_config: Callable[[str, Any], Any] = self._default_config
        self.get_key_manager: Optional[Callable[[], Any]] = None
        self.meltdown_count = 0

    @property
    def is_melted(self) -> bool:
        """熔断状态检查"""
        return self.meltdown_count >= 3

    @contextmanager
    def config_maintenance(self) -> None:
        """配置维护上下文，自动处理熔断"""
        try:
            yield
        except ImportError as e:
            logger.error(f"配置模块熔断：{e}")
            self.meltdown_count += 1
            if self.is_melted:
                self._force_melt()

    def _force_melt(self) -> None:
        """强制熔断，使用默认配置"""
        self.get_config = self._default_config
        self.get_key_manager = lambda: None

    def _default_config(self, key: str, default: Any = None) -> Any:
        """默认配置获取器"""
        logger.warning("配置服务熔断，使用默认值")
        return default

    def _build_config(self) -> None:
        """构建配置代理，带熔断机制"""
        self.config = {}
        self.get_config = self._default_config
        self.get_key_manager = lambda: None

        try:
            with self.config_maintenance():
                from config.settings import config as _config, get_config as _get_config
                self.config = _config
                self.get_config = _get_config
                logger.info("成功加载 config.settings")
        except ImportError:
            logger.error("核心配置模块缺失，强制熔断")
            self._force_melt()

        try:
            from config.key_manager import get_key_manager as _get_km
            self.get_key_manager = _get_km
            logger.info("成功加载 config.key_manager")
        except ImportError:
            logger.warning("密钥管理模块缺失，使用默认实现")

config = ConfigProxy()
get_config = config.get_config
get_key_manager = config.get_key_manager


def generate_id(prefix: str = "id") -> str:
    """生成唯一标识符

    使用 UUID4 生成 16 位十六进制字符串，拼接前缀形成唯一 ID。

    Args:
        prefix: 标识前缀，默认为 'id'

    Returns:
        带前缀的十六进制唯一 ID，格式为 "{prefix}_{16位hex}"
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


def now_timestamp() -> float:
    """获取当前时间戳（秒）

    Returns:
        当前 Unix 时间戳（浮点数，单位：秒）
    """
    return time.time()


def now_timestamp_ms() -> int:
    """获取当前时间戳（毫秒）

    Returns:
        当前 Unix 时间戳（整数，单位：毫秒）
    """
    return int(time.time() * 1000)


class Stopwatch:
    """线程安全的计时器工具类

    用于测量代码段执行时间，支持多次启动和停止，
    累计多次启停的总耗时。内部使用单调时钟确保精度。

    线程安全：所有公开方法均通过锁保护内部状态。
    """

    def __init__(self) -> None:
        self._accumulated: float = 0.0
        self._last_start: float = 0.0
        self._running: bool = False
        self._lock: threading.Lock = threading.Lock()

    def start(self) -> "Stopwatch":
        """开始计时

        如果已在运行中则忽略重复启动。

        Returns:
            self，支持链式调用
        """
        with self._lock:
            if not self._running:
                self._last_start = time.monotonic()
                self._running = True
        return self

    def stop(self) -> float:
        """停止计时

        将本次运行时间累加到总耗时中。

        Returns:
            累计总耗时（秒）
        """
        with self._lock:
            if self._running:
                self._accumulated += time.monotonic() - self._last_start
                self._running = False
            return self._accumulated

    def elapsed(self) -> float:
        """获取当前累计耗时（秒）

        包括已停止的运行段和正在进行的运行段。

        Returns:
            累计总耗时（秒）
        """
        with self._lock:
            return self._accumulated + (time.monotonic() - self._last_start) if self._running else self._accumulated

    def reset(self) -> None:
        """重置计时器，清除所有累计时间并停止运行"""
        with self._lock:
            self._accumulated = 0.0
            self._last_start = 0.0
            self._running = False

    @contextmanager
    def measure(self) -> float:
        """测量上下文，自动开始和停止计时"""
        start = time.monotonic()
        yield
        elapsed = time.monotonic() - start
        logger.debug(f"代码段耗时: {elapsed:.3f}s")
        return elapsed


def _execute_with_retry(
    func: Callable[..., T],
    max_retries: int,
    base_delay: float,
    exceptions: Tuple[type, ...],
    wait_func: Callable[[float], Any],
    is_async: bool,
    func_name: str,
    *args: Any,
    **kwargs: Any,
) -> T:
    """执行带重试的逻辑，同步和异步版本共用

    Args:
        func: 待执行的函数
        max_retries: 最大重试次数
        base_delay: 基础延迟时间（秒）
        exceptions: 需要捕获的异常类型元组
        wait_func: 等待函数（time.sleep 或 asyncio.sleep）
        is_async: 是否异步执行
        func_name: 函数名称用于日志
        *args: 位置参数
        **kwargs: 关键字参数

    Returns:
        函数执行结果

    Raises:
        exceptions: 所有重试均失败时抛出最后一次异常
    """
    last_exception: Optional[Exception] = None

    for attempt in range(max_retries):
        try:
            return func(*args, **kwargs)
        except exceptions as e:
            last_exception = e
            if attempt == max_retries - 1:
                logger.error(f"{'异步' if is_async else '同步'}重试 {func_name} 失败，已尝试 {max_retries} 次: {e}")
                raise
            delay = base_delay * (2 ** attempt)
            logger.debug(
                f"{'异步' if is_async else '同步'}重试 {func_name} 第 {attempt + 1} 次失败，"
                f"{delay:.2f}秒后重试: {e}"
            )
            wait_func(delay)

    if last_exception is not None:
        raise last_exception
    raise RuntimeError(f"重试逻辑异常：未捕获到任何异常但达到重试上限 - {func_name}")


def retry_on_failure(
    max_retries: int = 3,
    base_delay: float = 0.1,
    exceptions: Tuple[type, ...] = (Exception,),
    use_async: bool = False,
) -> Callable[[F], F]:
    """指数退避重试装饰器

    同步版本使用 time.sleep，异步版本使用 asyncio.sleep。
    在高并发场景下建议使用 use_async=True 以避免阻塞线程。

    Args:
        max_retries: 最大重试次数，必须大于 0，默认为 3
        base_delay: 基础延迟时间（秒），默认为 0.1
        exceptions: 需要捕获的异常类型元组，默认为 (Exception,)
        use_async: 是否生成异步装饰器，默认为 False

    Returns:
        装饰器函数，返回与原函数签名兼容的包装函数

    Raises:
        ValueError: 当 max_retries 小于等于 0 时
    """
    if max_retries <= 0:
        raise ValueError(f"max_retries 必须大于 0，当前值: {max_retries}")

    def decorator(func: F) -> F:
        func_name = func.__qualname__

        if use_async:

            @wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                return await _execute_with_retry(
                    func,
                    max_retries,
                    base_delay,
                    exceptions,
                    asyncio.sleep,
                    is_async=True,
                    func_name=func_name,
                    *args,
                    **kwargs,
                )

            return async_wrapper  # type: ignore[return-value]
        else:

            @wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                return _execute_with_retry(
                    func,
                    max_retries,
                    base_delay,
                    exceptions,
                    time.sleep,
                    is_async=False,
                    func_name=func_name,
                    *args,
                    **kwargs,
                )

            return sync_wrapper

    return decorator


class SafeJsonHandler:
    """安全 JSON 处理工具类

    统一处理序列化和反序列化，提供明确的异常类型
    """

    @staticmethod
    def dumps(obj: Any, **kwargs: Any) -> str:
        """安全的 JSON 序列化

        使用 ensure_ascii=False 保留 Unicode 字符，
        使用 default=str 处理不可序列化对象。

        Args:
            obj: 要序列化的对象
            **kwargs: 传递给 json.dumps 的其他参数

        Returns:
            JSON 字符串

        Raises:
            SafeJsonDumpError: 对象无法序列化
            SafeJsonValueError: 序列化为无效值时
        """
        if "ensure_ascii" not in kwargs:
            kwargs["ensure_ascii"] = False
        if "default" not in kwargs:
            kwargs["default"] = str
        try:
            result = json.dumps(obj, **kwargs)
            logger.debug(f"JSON 序列化成功，长度: {len(result)}")
            return result
        except (TypeError, ValueError) as e:
            logger.warning(f"JSON 序列化失败: {e}", exc_info=True)
            raise SafeJsonDumpError from e

    @staticmethod
    def loads(json_str: str, **kwargs: Any) -> Any:
        """安全的 JSON 反序列化

        解析 JSON 字符串，支持字典、列表及标量类型。
        解析失败时抛出明确异常。

        Args:
            json_str: JSON 字符串
            **kwargs: 传递给 json.loads 的其他参数

        Returns:
            解析后的对象

        Raises:
            SafeJsonDecodeError: 解析失败时
            SafeJsonTypeError: 无法转换为标准类型时
        """
        if not json_str:
            logger.debug("JSON 反序列化输入为空")
            return None
        try:
            result = json.loads(json_str, **kwargs)
            logger.debug(f"JSON 反序列化成功，类型: {type(result).__name__}")
            return result
        except (json.JSONDecodeError, TypeError) as e:
            logger.debug(f"JSON 反序列化失败: {e}")
            raise SafeJsonDecodeError from e


class SafeJsonDumpError(Exception):
    """JSON 序列化失败异常"""
    pass


class SafeJsonDecodeError(Exception):
    """JSON 反序列化失败异常"""
    pass


def safe_json_dumps(obj: Any, **kwargs: Any) -> str:
    """安全 JSON 序列化接口"""
    return SafeJsonHandler.dumps(obj, **kwargs)


def safe_json_loads(json_str: str, **kwargs: Any) -> Any:
    """安全 JSON 反序列化接口"""
    return SafeJsonHandler.loads(json_str, **kwargs)
