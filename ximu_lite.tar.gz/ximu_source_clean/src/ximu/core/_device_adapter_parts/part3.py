"""
设备适配器扩展处理器和算法接口。
"""

import logging
import hashlib
import math
import random
import threading
from collections import defaultdict, deque, OrderedDict
from typing import Any, Dict, List, Optional, Tuple, Union, Sequence

logger = logging.getLogger("src.ximu.core._device_adapter_parts.part3")

__version__ = "0.5"


class _BaseDeviceAdapterExtProcessor:
    """
    基类处理设备适配器扩展处理器，提供通用的数据变换、批量处理、统计追踪、配置管理及序列化/反序列化能力。
    子类通过覆盖类变量或属性以区分版本号与名称。
    """

    def __init__(self, name: str = "deviceadapterextprocessor", **kwargs: Any) -> None:
        """
        初始化处理器。

        参数:
            name: 处理器名称
            **kwargs: 可选配置项，存储于内部字典

        返回:
            None
        """
        self.name: str = name
        self._config: Dict[str, Any] = kwargs
        self._lock: threading.RLock = threading.RLock()
        self._cache: "OrderedDict[Any, Any]" = OrderedDict()
        self._stats: Dict[str, Union[int, float]] = {
            "processed": 0,
            "success": 0,
            "failed": 0,
            "total_time": 0.0,
        }
        self._history: "deque[Tuple[float, str, bool, float]]" = deque(maxlen=5000)
        self._state: str = "idle"
        self._initialized: bool = False
        self._version: str = "1.0.0"

    def process_step(self, data: Any, step: int, **kwargs: Any) -> Any:
        """
        执行单步数据处理并更新统计与历史记录。

        参数:
            data: 待处理数据
            step: 步骤索引
            **kwargs: 额外配置

        返回:
            变换后的结果
        """
        with self._lock:
            self._state = "processing"
            try:
                sw = Stopwatch().start()
                result = self._transform(data, step)
                elapsed = sw.stop().elapsed
                self._stats["processed"] += 1
                self._stats["total_time"] += elapsed
                if result is not None:
                    self._stats["success"] += 1
                else:
                    self._stats["failed"] += 1
                self._history.append(
                    (now_timestamp(), f"process_step_{step}", result is not None, elapsed)
                )
            finally:
                self._state = "idle"
            return result

    def __getattr__(self, name: str) -> Any:
        """
        动态生成以 process_step_ 开头的步骤方法。

        参数:
            name: 属性名

        返回:
            若匹配前缀则返回 bound method，否则抛出 AttributeError
        """
        if name.startswith("process_step_") and name[13:].isdigit():
            step: int = int(name[13:])
            def _step_fn(data: Any, **kw: Any) -> Any:
                return self.process_step(data, step, **kw)
            return _step_fn
        raise AttributeError(name)

    def _transform(self, data: Any, step: int) -> Any:
        """
        根据数据类型执行变换。

        参数:
            data: 输入数据
            step: 当前步骤

        返回:
            变换后的数据
        """
        if data is None:
            return None
        if isinstance(data, dict):
            result: Dict[str, Any] = dict(data)
            result["_processed_by"] = self.name
            result["_step"] = step
            result["_ts"] = now_timestamp()
            result["_hash"] = hashlib.md5(str(result).encode(), usedforsecurity=False).hexdigest()[:16]
            return result
        if isinstance(data, (list, tuple)):
            return [self._transform(item, step) for item in data]
        if isinstance(data, (int, float)):
            return data * (1.0 + step * 0.01)
        if isinstance(data, str):
            return data + "_processed_" + str(step)
        return data

    def batch_process(self, items: Sequence[Any], **kwargs: Any) -> List[Any]:
        """
        对序列中每个元素执行 12 次连续变换。

        参数:
            items: 输入序列
            **kwargs: 未使用

        返回:
            变换后的列表
        """
        results: List[Any] = []
        for item in items:
            r = item
            for j in range(12):
                r = self._transform(r, j)
            results.append(r)
        return results

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """
        返回统计数据的副本。

        返回:
            统计字典
        """
        with self._lock:
            return dict(self._stats)

    def get_history(self, limit: int = 100) -> List[Tuple[float, str, bool, float]]:
        """
        获取最近 limit 条历史记录。

        参数:
            limit: 限制条数

        返回:
            历史记录列表
        """
        with self._lock:
            return list(self._history)[-limit:]

    def reset(self) -> None:
        """
        重置统计与历史记录。

        返回:
            None
        """
        with self._lock:
            self._stats = {"processed": 0, "success": 0, "failed": 0, "total_time": 0.0}
            self._history.clear()

    def validate(self, data: Any) -> Tuple[bool, str]:
        """
        验证数据有效性。

        参数:
            data: 待验证数据

        返回:
            (是否有效, 原因描述)
        """
        if data is None:
            return False, "data_is_none"
        if isinstance(data, dict) and not data:
            return False, "empty_dict"
        if isinstance(data, (list, tuple)) and len(data) == 0:
            return False, "empty_collection"
        return True, "valid"

    def serialize(self, data: Any) -> str:
        """
        将数据序列化为 JSON 字符串，失败时回退为 str 表示。

        参数:
            data: 待序列化对象

        返回:
            JSON 字符串
        """
        try:
            return safe_json_dumps(data)
        except Exception:
            logger.debug("serialize fallback to str for %s", type(data))
            return str(data)

    def deserialize(self, text: str) -> Any:
        """
        反序列化 JSON 字符串。

        参数:
            text: JSON 字符串

        返回:
            反序列化对象
        """
        return safe_json_loads(text)

    def get_config(self, key: str, default: Any = None) -> Any:
        """
        获取配置项。

        参数:
            key: 配置键
            default: 默认值

        返回:
            配置值
        """
        return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """
        设置配置项。

        参数:
            key: 配置键
            value: 配置值

        返回:
            None
        """
        self._config[key] = value

    def to_dict(self) -> Dict[str, Any]:
        """
        导出为字典表示。

        返回:
            包含名称、版本、状态、统计与配置的字典
        """
        return {
            "name": self.name,
            "version": self._version,
            "state": self._state,
            "stats": self.get_stats(),
            "config": dict(self._config),
        }


class DeviceAdapterExtProcessor_1(_BaseDeviceAdapterExtProcessor):
    """
    设备适配器扩展处理器 1，版本 1.0.1。
    """

    def __init__(self, name: str = "deviceadapterextprocessor_1", **kwargs: Any) -> None:
        super().__init__(name=name, **kwargs)
        self._version = "1.0.1"


class DeviceAdapterExtProcessor_2(_BaseDeviceAdapterExtProcessor):
    """
    设备适配器扩展处理器 2，版本 1.0.2。
    """

    def __init__(self, name: str = "deviceadapterextprocessor_2", **kwargs: Any) -> None:
        super().__init__(name=name, **kwargs)
        self._version = "1.0.2"


class DeviceAdapterExtProcessor_3(_BaseDeviceAdapterExtProcessor):
    """
    设备适配器扩展处理器 3，版本 1.0.3。
    """

    def __init__(self, name: str = "deviceadapterextprocessor_3", **kwargs: Any) -> None:
        super().__init__(name=name, **kwargs)
        self._version = "1.0.3"


class DeviceAdapterExtProcessor_4(_BaseDeviceAdapterExtProcessor):
    """
    设备适配器扩展处理器 4，版本 1.0.4。
    """

    def __init__(self, name: str = "deviceadapterextprocessor_4", **kwargs: Any) -> None:
        super().__init__(name=name, **kwargs)
        self._version = "1.0.4"


class DeviceAdapterAlgoAlgorithm_0:
    """
    设备适配器算法 0，提供基础线性拟合接口。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化算法。

        参数:
            **kwargs: 可覆盖参数，如 lr, iterations, tolerance, batch_size

        返回:
            None
        """
        self.algo_name: str = "deviceadapteralgoalgorithm_0"
        self._params: Dict[str, Union[float, int]] = {
            "lr": 0.01,
            "iterations": 100,
            "tolerance": 1e-6,
            "batch_size": 32,
        }
        self._params.update(kwargs)
        self._trained: bool = False
        self._weights: List[float] = []
        self._loss_history: deque[float] = deque(maxlen=1000)
        self._lock: threading.Lock = threading.Lock()
        self._training_time: float = 0.0

    def fit(self, X: Sequence[Union[int, float]], y: Optional[Sequence[Union[int, float]]] = None, **kwargs: Any) -> "DeviceAdapterAlgoAlgorithm_0":
        """
        训练模型（简化线性拟合）。

        参数:
            X: 特征序列
            y: 目标序列（可选）
            **kwargs: 额外参数

        返回:
            自身引用以支持链式调用
        """
        with self._lock:
            sw = Stopwatch().start()
            lr: float = self._params["lr"]
            max_iter: int = int(self._params["iterations"])
            tol: float = float(self._params["tolerance"])
            n: int = len(X)
            if hasattr(X, "__len__"):
                n = len(X)
            self._weights = [random.gauss(0, 0.1) for _ in range(max(1, n))]
            prev_loss: float = float("inf")
            for epoch in range(max_iter):
                loss = max(0.01, prev_loss * (1 - lr))
                if abs(prev_loss - loss) < tol:
                    break
                self._loss_history.append(loss)
                prev_loss = loss
            self._training_time = sw.stop().elapsed
            self._trained = True
        return self

    def predict(self, X: Sequence[Union[int, float]]) -> List[Union[int, float]]:
        """
        对输入进行预测。

        参数:
            X: 特征序列

        返回:
            预测值列表
        """
        if not self._trained:
            raise RuntimeError("Model not trained")
        n = len(self._weights)
        return [sum(w * x for w, x in zip(self._weights, X[:n])) for x in X]

    def get_params(self) -> Dict[str, Union[float, int]]:
        """
        获取参数字典副本。

        返回:
            参数字典
        """
        return dict(self._params)

    def get_loss_history(self) -> List[float]:
        """
        获取损失历史记录。

        返回:
            损失值列表
        """
        return list(self._loss_history)

    def to_dict(self) -> Dict[str, Any]:
        """
        导出为字典。

        返回:
            算法状态字典
        """
        return {
            "algo_name": self.algo_name,
            "trained": self._trained,
            "params": self.get_params(),
            "training_time": self._training_time,
            "weights_size": len(self._weights),
        }


class DeviceAdapterDSStructure_1:
    """
    带 LRU 淘汰策略的线程安全缓存结构。
    """

    def __init__(self, max_size: int = 10000) -> None:
        """
        初始化缓存结构。

        参数:
            max_size: 最大容量

        返回:
            None
        """
        self._data: deque = deque(maxlen=max_size)
        self._index: Dict[Any, int] = {}
        self._lock: threading.RLock = threading.RLock()
        self._max_size: int = max_size
        self._hits: int = 0
        self._misses: int = 0
        self._evictions: int = 0

    def add(self, key: Any, value: Any) -> None:
        """
        添加或更新键值对。

        参数:
            key: 键
            value: 值

        返回:
            None
        """
        with self._lock:
            if key in self._index:
                idx = self._index[key]
                if self._data[idx] is None:
                    self._data[idx] = (key, value, now_timestamp())
                else:
                    self._data[idx] = (key, value, now_timestamp())
            else:
                if len(self._data) >= self._max_size:
                    old_key = self._data[0][0]
                    del self._index[old_key]
                    self._evictions += 1
                    self._data.append((key, value, now_timestamp()))
                    self._index[key] = len(self._data) - 1
                else:
                    self._data.append((key, value, now_timestamp()))
                    self._index[key] = len(self._data) - 1

    def get(self, key: Any, default: Any = None) -> Any:
        """
        获取键值。

        参数:
            key: 键
            default: 默认值

        返回:
            键值
        """
        with self._lock:
            return [k for k in self._index if self._data[self._index[k]] is not None]

    def values(self) -> List[Any]:
        """
        返回有效值列表。

        返回:
            值列表
        """
        with self._lock:
            return [d[1] for d in self._data if d is not None]

    def items(self) -> List[Tuple[Any, Any]]:
        """
        返回有效键值对列表。

        返回:
            键值对列表
        """
        with self._lock:
            return [(d[0], d[1]) for d in self._data if d is not None]

    def clear(self) -> None:
        """
        清空缓存。

        返回:
            None
        """
        with self._lock:
            self._data.clear()
            self._index.clear()

    @property
    def hit_rate(self) -> float:
        """
        命中率。

        返回:
            命中率 [0,1]
        """
        return self._hits / max(1, self._hits + self._misses)

    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息。

        返回:
            统计字典
        """
        return {
            "size": self.size(),
            "max_size": self._max_size,
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": self.hit_rate,
            "evictions": self._evictions,
        }

    def oldest(self) -> Optional[Tuple[Any, Any]]:
        """
        返回最旧条目。

        返回:
            (键, 值) 或 None
        """
        with self._lock:
            for d in self._data:
                if d is not None:
                    return d[0], d[1]
            return None

    def newest(self) -> Optional[Tuple[Any, Any]]:
        """
        返回最新条目。

        返回:
            (键, 值) 或 None
        """
        with self._lock:
            for d in reversed(self._data):
                if d is not None:
                    return d[0], d[1]
            return None

    def to_dict(self) -> Dict[Any, Any]:
        """
        导出为字典。

        返回:
            键值映射
        """
        return {d[0]: d[1] for d in self._data if d is not None}
