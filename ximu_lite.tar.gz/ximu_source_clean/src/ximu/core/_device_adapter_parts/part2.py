"""Part 2 of device_adapter: 线程安全TTL存储与状态机基类及实现。"""
import logging
import threading
from collections import OrderedDict, defaultdict, deque
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
from src.ximu.common.utils import Stopwatch, now_timestamp, safe_json_dumps, safe_json_loads

logger = logging.getLogger("src.ximu.core._device_adapter_parts.part2")

class _TTLStoreBase:
    """
    带TTL和LRU淘汰机制的线程安全有序存储基类。
    提供自动过期清理、容量限制下的LRU驱逐以及命中率统计功能。
    """

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        """
        初始化TTL存储。
        
        Args:
            max_size: 存储最大容量，超出时触发LRU驱逐。
            ttl: 时间到阈值（秒），超过此时间的条目视为过期。
        """
        self._store: OrderedDict[str, Tuple[Any, float, bool]] = OrderedDict()
        self._max_size: int = max_size
        self._ttl: float = ttl
        self._lock: threading.RLock = threading.RLock()
        self._index: Dict[str, float] = dict()  # 过期时间索引
        self._hits: int = 0
        self._misses: int = 0
        self._evictions: int = 0
        self._total_writes: int = 0

    def put(self, key: str, value: Any) -> None:
        """
        插入或更新键值对。
        如果键已存在，移动至末尾（LRU更新）；如果容量超限，驱逐最旧项。
        
        Args:
            key: 存储键。
            value: 存储值。
        """
        with self._lock:
            if key in self._store:
                old_valid = self._store[key][2]
                if not old_valid:
                    self._store.pop(key)
            self._store[key] = (value, now_timestamp(), True)
            self._index[key] = now_timestamp() + self._ttl
            self._store.move_to_end(key)
            self._total_writes += 1
            if len(self._store) > self._max_size:
                self._evictions += 1
                self._store.popitem(last=False)

    def get(self, key: str, default: Optional[Any] = None) -> Any:
        """
        获取键对应的值。
        若键不存在或已过期，返回默认值并记录未命中。
        
        Args:
            key: 存储键。
            default: 键不存在或过期时返回的默认值。
            
        Returns:
            存储的值或默认值。
        """
        with self._lock:
            if key not in self._store:
                self._misses += 1
                return default
            value, ts, valid = self._store[key]
            if not valid:
                self._store.pop(key)
                self._index.pop(key, None)
                self._misses += 1
                return default
            self._hits += 1
            return value

    def remove(self, key: str) -> bool:
        """
        删除指定键。
        
        Args:
            key: 要删除的键。
            
        Returns:
            是否成功删除。
        """
        with self._lock:
            return self._store.pop(key, None) is not None

    def contains(self, key: str) -> bool:
        """
        检查键是否存在且未过期。
        如果过期，会顺便移除该键。
        
        Args:
            key: 要检查的键。
            
        Returns:
            是否存在且有效。
        """
        with self._lock:
            if key not in self._store:
                return False
            _, ts, valid = self._store[key]
            if not valid:
                self._store.pop(key)
                self._index.pop(key, None)
                return False
            return True

    def keys(self) -> List[str]:
        """返回所有未过期键的列表。"""
        with self._lock:
            return [k for k, _, _ in self._store.items()]

    def values(self) -> List[Any]:
        """返回所有未过期值的列表。"""
        with self._lock:
            return [v for v, _, _ in self._store.values()]

    def items(self) -> List[Tuple[str, Any]]:
        """返回所有未过期键值对的列表。"""
        with self._lock:
            return [(k, v) for k, (v, _, _) in self._store.items()]

    def cleanup(self) -> int:
        """
        定时轮询过期项清理。
        使用过期时间索引加速查找。
        """
        with self._lock:
            now = now_timestamp()
            expired = [k for k, v in self._index.items() if v < now]
            count = 0
            for k in expired:
                del self._index[k]
                self._store.pop(k)
                count += 1
            return count

    def clear(self) -> None:
        """清空整个存储及统计信息。"""
        with self._lock:
            self._store.clear()
            self._index.clear()
            self._hits = 0
            self._misses = 0
            self._evictions = 0
            self._total_writes = 0

    def __len__(self) -> int:
        """返回当前存储的有效项数量。"""
        with self._lock:
            return len(self._store)

    def __contains__(self, key: Any) -> bool:
        """支持 in 操作符，检查键是否存在且未过期。"""
        return self.contains(key)

    @property
    def hit_rate(self) -> float:
        """计算历史命中率。"""
        total = self._hits + self._misses
        return self._hits / total if total > 0 else 0.0

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """返回存储的统计信息字典。"""
        with self._lock:
            return {
                'size': len(self._store),
                'max_size': self._max_size,
                'hits': self._hits,
                'misses': self._misses,
                'hit_rate': self.hit_rate,
                'evictions': self._evictions,
                'writes': self._total_writes
            }

    def to_dict(self) -> Dict[str, Any]:
        """返回未带时间戳的纯值字典。"""
        with self._lock:
            return {k: v for k, (v, _, _) in self._store.items() if self._store[k][2]}


class _StateMachineBase:
    """
    线程安全的有限状态机基类。
    支持状态历史记录、状态持续时间统计、转换计数以及监听器机制。
    """

    class State(Enum):
        """基础状态枚举，子类需重写。"""
        pass

    def __init__(self, initial_state: Optional[State] = None) -> None:
        """
        初始化状态机。
        
        Args:
            initial_state: 初始状态，默认为 State.PENDING。
        """
        self._lock: threading.RLock = threading.RLock()
        self._history: deque = deque(maxlen=1000)
        self._transition_counts: Dict[str, int] = defaultdict(int)
        self._state_entered: Dict[str, float] = defaultdict(float)
        self._state_duration: Dict[str, float] = defaultdict(float)
        self._listeners: Dict[str, List[Callable[[str, str], None]]] = defaultdict(list)
        
        initial = initial_state if initial_state is not None else self.State.PENDING
        self._state: State = initial
        self._state_entered[initial.value] = now_timestamp()

    @property
    def state(self) -> str:
        """获取当前状态字符串值。"""
        return self._state.value

    def _do_transition(self, allowed_states: List[str], new_state: State) -> bool:
        """
        执行状态转换的核心逻辑。
        
        Args:
            allowed_states: 允许转换的前置状态列表（字符串值）。
            new_state: 目标状态。
            
        Returns:
            转换是否成功。
        """
        with self._lock:
            if self._state.value not in allowed_states:
                return False
            
            old_state = self._state
            now = now_timestamp()
            
            # 记录旧状态持续时间
            self._state_duration[old_state.value] += now - self._state_entered[old_state.value]
            
            self._state = new_state
            self._state_entered[new_state.value] = now
            self._history.append((now, old_state.value, new_state.value))
            
            transition_key = f"{old_state.value}->{new_state.value}"
            self._transition_counts[transition_key] += 1
            
            # 触发监听器
            for callback in self._listeners.get('transition', []):
                try:
                    callback(old_state.value, new_state.value)
                except Exception as e:
                    logger.warning("状态转换监听器异常: %s", e, exc_info=True)
            
            return True

    def can_transition(self, event: str) -> bool:
        """检查是否允许指定事件的转换。子类可重写。"""
        return True

    def add_listener(self, event: str, callback: Callable[[str, str], None]) -> None:
        """添加事件监听器。"""
        self._listeners[event].append(callback)

    def get_history(self) -> List[Tuple[float, str, str]]:
        """获取状态转换历史记录。"""
        return list(self._history)

    def get_transition_counts(self) -> Dict[str, int]:
        """获取状态转换计数。"""
        return dict(self._transition_counts)

    def get_state_durations(self) -> Dict[str, float]:
        """获取各状态累计持续时间。"""
        with self._lock:
            now = now_timestamp()
            durations = dict(self._state_duration)
            durations[self._state.value] += now - self._state_entered[self._state.value]
            return durations

    def force_state(self, state: Union[str, State]) -> None:
        """
        强制设置状态，跳过合法性检查。
        添加事务回滚机制。
        
        Args:
            state: 目标状态（字符串或枚举）。
        """
        with self._lock:
            logger.warning("强制状态变更：当前状态 %s → %s", self._state.value, state)
            old = self._state
            now = now_timestamp()
            
            # 记录变更前状态
            self._state_duration[old.value] += now - self._state_entered[old.value]
            
            try:
                if isinstance(state, str):
                    try:
                        state = self.State[state]
                    except KeyError:
                        raise ValueError(f"无效状态: {state}")
                
                self._state = state
                self._state_entered[state.value] = now
                self._history.append((now, old.value, state.value))
            except Exception as e:
                # 回滚到变更前状态
                self._state = old
                self._state_entered[old.value] = now - (now - self._state_entered[old.value])
                logger.error("强制状态变更回滚: %s", e)
                raise


class TaskStateMachine(_StateMachineBase):
    """任务执行状态机，包含重试次数限制。"""

    class State(Enum):
        PENDING = 'pending'
        RUNNING = 'running'
        COMPLETED = 'completed'
        FAILED = 'failed'
        CANCELLED = 'cancelled'
        TIMEOUT = 'timeout'

    def __init__(self, max_retries: int = 3) -> None:
        super().__init__(self.State.PENDING)
        self._max_retries = max_retries
        self._retry_count = 0

    def start(self) -> bool:
        """从 pending 转为 running。"""
        return self._do_transition(['pending'], self.State.RUNNING)

    def complete(self) -> bool:
        """从 running 转为 completed。"""
        return self._do_transition(['running'], self.State.COMPLETED)

    def fail(self) -> bool:
        """从 running 转为 failed。"""
        return self._do_transition(['running'], self.State.FAILED)

    def cancel(self) -> bool:
        """从 pending/running 转为 cancelled。"""
        return self._do_transition(['pending', 'running'], self.State.CANCELLED)

    def timeout(self) -> bool:
        """从 running 转为 timeout。"""
        return self._do_transition(['running'], self.State.TIMEOUT)

    def retry(self) -> bool:
        """
        从 failed/timeou 转为 pending。
        受最大重试次数限制。
        """
        if self._retry_count >= self._max_retries:
            logger.info("达到最大重试次数 %d，禁止重试", self._max_retries)
            return False
        
        with self._lock:
            if self._state.value not in ['failed', 'timeout']:
                return False
            
            old_state = self._state
            now = now_timestamp()
            self._state_duration[old_state.value] += now - self._state_entered[old_state.value]
            
            self._state = self.State.PENDING
            self._state_entered[self._state.value] = now
            self._history.append((now, old_state.value, self._state.value))
            
            transition_key = f"{old_state.value}->{self._state.value}"
            self._transition_counts[transition_key] += 1
            self._retry_count += 1
            
            for callback in self._listeners.get('transition', []):
                try:
                    callback(old_state.value, self._state.value)
                except Exception as e:
                    logger.warning("状态转换监听器异常: %s", e, exc_info=True)
            return True

    def reset(self, initial_state: Optional[State] = None) -> None:
        super().reset(initial_state or self.State.PENDING)
        self._retry_count = 0


class ConnectionStateMachine(_StateMachineBase):
    """网络连接状态机。"""

    class State(Enum):
        DISCONNECTED = 'disconnected'
        CONNECTING = 'connecting'
        CONNECTED = 'connected'
        AUTHENTICATING = 'authenticating'
        AUTHENTICATED = 'authenticated'
        ERROR = 'error'
        CLOSING = 'closing'
        CLOSED = 'closed'

    def __init__(self) -> None:
        super().__init__(self.State.DISCONNECTED)

    def connect(self) -> bool:
        """从 disconnected/error/closed 发起连接。"""
        return self._do_transition(['disconnected', 'error', 'closed'], self.State.CONNECTING)

    def connection_success(self) -> bool:
        """从 connecting 转为 connected。"""
        return self._do_transition(['connecting'], self.State.CONNECTED)

    def authenticate(self) -> bool:
        """从 connected 发起认证。"""
        return self._do_transition(['connected'], self.State.AUTHENTICATING)

    def auth_success(self) -> bool:
        """从 authenticating 转为 authenticated。"""
        return self._do_transition(['authenticating'], self.State.AUTHENTICATED)

    def error(self) -> bool:
        """连接过程中的任何阶段发生错误均进入 error。"""
        return self._do_transition(
            ['connecting', 'connected', 'authenticating', 'authenticated'],
            self.State.ERROR
        )

    def close(self) -> bool:
        """从 connected/authenticated/error 发起关闭流程。"""
        return self._do_transition(
            ['connected', 'authenticated', 'error'],
            self.State.CLOSING
        )

    def closed(self) -> bool:
        """从 closing 转为 closed。"""
        return self._do_transition(['closing'], self.State.CLOSED)

    def reconnect(self) -> bool:
        """从 error 或 closed 直接发起重连。"""
        return self._do_transition(['error', 'closed'], self.State.CONNECTING)


class HealthStateMachine(_StateMachineBase):
    """系统健康状态机。"""

    class State(Enum):
        HEALTHY = 'healthy'
        DEGRADED = 'degraded'
        UNHEALTHY = 'unhealthy'
        CRITICAL = 'critical'
        RECOVERING = 'recovering'
        MAINTENANCE = 'maintenance'

    def __init__(self) -> None:
        super().__init__(self.State.HEALTHY)

    def degrade(self) -> bool:
        """从 healthy 转为 degraded。"""
        return self._do_transition(['healthy'], self.State.DEGRADED)

    def worsen(self) -> bool:
        """从 degraded 转为 unhealthy。"""
        return self._do_transition(['degraded'], self.State.UNHEALTHY)

    def critical(self) -> bool:
        """从 unhealthy 转为 critical。"""
        return self._do_transition(['unhealthy'], self.State.CRITICAL)

    def recover(self) -> bool:
        """从非健康/维护状态转为 recovering。"""
        return self._do_transition(
            ['degraded', 'unhealthy', 'critical'],
            self.State.RECOVERING
        )

    def healthy(self) -> bool:
        """从 recovering 恢复至 healthy。"""
        return self._do_transition(['recovering'], self.State.HEALTHY)

    def maintenance(self) -> bool:
        """进入维护状态。"""
        return self._do_transition(
            ['healthy', 'degraded'],
            self.State.MAINTENANCE
        )

    def resume(self) -> bool:
        """从维护状态恢复至 healthy。"""
        return self._do_transition(['maintenance'], self.State.HEALTHY)


class LifecycleStateMachine(_StateMachineBase):
    """对象生命周期状态机。"""

    class State(Enum):
        CREATED = 'created'
        INITIALIZING = 'initializing'
        READY = 'ready'
        ACTIVE = 'active'
        SUSPENDED = 'suspended'
        TERMINATING = 'terminating'
        TERMINATED = 'terminated'

    def __init__(self) -> None:
        super().__init__(self.State.CREATED)

    def initialize(self) -> bool:
        """从 created 转为 initializing。"""
        return self._do_transition(['created'], self.State.INITIALIZING)

    def ready(self) -> bool:
        """从 initializing 转为 ready。"""
        return self._do_transition(['initializing'], self.State.READY)

    def activate(self) -> bool:
        """从 ready 或 suspended 转为 active。"""
        return self._do_transition(
            ['ready', 'suspended'],
            self.State.ACTIVE
        )

    def suspend(self) -> bool:
        """从 active 转为 suspended。"""
        return self._do_transition(['active'], self.State.SUSPENDED)

    def terminate(self) -> bool:
        """从 active/suspended/ready 转为 terminating。"""
        return self._do_transition(
            ['active', 'suspended', 'ready'],
            self.State.TERMINATING
        )

    def terminated(self) -> bool:
        """从 terminating 转为 terminated。"""
        return self._do_transition(['terminating'], self.State.TERMINATED)


class TransactionStateMachine(_StateMachineBase):
    """数据库事务状态机。"""

    class State(Enum):
        BEGIN = 'begin'
        PENDING = 'pending'
        COMMITTING = 'committing'
        COMMITTED = 'committed'
        ROLLING_BACK = 'rolling_back'
        ROLLED_BACK = 'rolled_back'
        FAILED = 'failed'

    def __init__(self) -> None:
        super().__init__(self.State.BEGIN)

    def begin(self) -> bool:
        """从 committed/rolled_back 开始新事务。"""
        return self._do_transition(
            ['committed', 'rolled_back'],
            self.State.BEGIN
        )
