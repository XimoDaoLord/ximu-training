"""
阶段4: DAG引擎 V3实现
按照v3框架卷1完整实现

本模块提供基于有向无环图（DAG）的任务调度引擎，支持节点管理、依赖关系定义、就绪节点查询、执行顺序分层以及图有效性验证等功能。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Set, Tuple

logger = logging.getLogger("src.ximu.core.dag_engine_v3")

class DagStatus(Enum):
    """DAG节点生命周期状态。

    状态流转: PENDING -> RUNNING -> SUCCESS / FAILED / CANCELLED。
    """

    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"

@dataclass
class DagNode:
    """DAG节点数据结构。

    属性:
        node_id (str): 节点唯一标识符。
        task_id (str): 关联的任务标识符。
        children (List[str]): 子节点ID列表。
        parents (List[str]): 父节点ID列表。
        in_degree (int): 入度，表示依赖的父节点数量。
        status (DagStatus): 当前执行状态。
    """

    node_id: str
    task_id: str
    children: List[str] = field(default_factory=list)
    parents: List[str] = field(default_factory=list)
    in_degree: int = 0
    status: DagStatus = DagStatus.PENDING


class DAGEngineV3:
    """
    阶段4: DAG引擎 V3
    按照v3框架卷1完整实现

    该引擎维护一个有向无环图结构，支持动态添加节点和边，
    并提供了拓扑排序、就绪节点管理和图验证等核心功能。
    """

    def __init__(self) -> None:
        """初始化DAG引擎内部数据结构。"""
        self._nodes: Dict[str, DagNode] = {}
        self._edges: Dict[str, Set[str]] = {}  # parent -> children 的映射
        self._root_nodes: List[str] = []
        self._logger = logger

    def add_node(self, node_id: str, task_id: str) -> DagNode:
        """添加节点到DAG中。

        Args:
            node_id (str): 节点的唯一标识符。
            task_id (str): 该节点关联的任务标识符。

        Returns:
            DagNode: 新创建的节点对象。

        Note:
            新添加的节点默认入度为0，因此会被加入根节点列表。
            若节点已存在，将覆盖原有节点并可能导致数据不一致，调用者应确保node_id唯一性。
        """
        if node_id in self._nodes:
            old_node = self._nodes[node_id]
            self._logger.warning(f"节点 {node_id} 已存在，将被覆盖")
            # 移除旧的根节点记录（如果之前是根）
            if node_id in self._root_nodes:
                self._root_nodes.remove(node_id)
            # 清理旧的边关系
            for child_id in old_node.children:
                self._edges[child_id].discard(node_id)
                if node_id in self._nodes[child_id].parents:
                    self._nodes[child_id].parents.remove(node_id)
                    self._nodes[child_id].in_degree -= 1
            for parent_id in old_node.parents:
                self._edges[parent_id].discard(node_id)
                self._nodes[parent_id].in_degree -= 1
            # 更新父节点和子节点的edges
            for parent_id in old_node.parents:
                if parent_id not in self._edges:
                    self._edges[parent_id] = set()
                self._edges[parent_id].discard(node_id)
            for child_id in old_node.children:
                if child_id not in self._edges:
                    self._edges[child_id] = set()
                self._edges[child_id].discard(node_id)
            # 清理旧的根节点记录
            if node_id in self._root_nodes:
                self._root_nodes.remove(node_id)
            # 更新新节点的父节点和子节点关系
            new_node = DagNode(node_id=node_id, task_id=task_id, parents=old_node.parents, children=old_node.children)
            self._nodes[node_id] = new_node
            # 更新根节点列表
            if new_node.in_degree == 0:
                self._root_nodes.append(node_id)
        else:
            new_node = DagNode(node_id=node_id, task_id=task_id)
            self._nodes[node_id] = new_node
            self._root_nodes.append(node_id)
        return new_node

    def add_edge(self, from_node: str, to_node: str) -> None:
        """添加从 from_node 到 to_node 的有向边。

        Args:
            from_node (str): 父节点ID。
            to_node (str): 子节点ID。

        Raises:
            ValueError: 如果任一节点不存在于DAG中。

        Note:
            此操作会增加子节点的入度，并将子节点从根节点列表中移除（如果它之前是根）。
        """
        if from_node not in self._nodes or to_node not in self._nodes:
            raise ValueError(f"节点 {from_node} 或 {to_node} 不存在")
        if from_node == to_node:
            raise ValueError("不允许自环边")
        if to_node in self._edges.get(from_node, set()):
            self._logger.debug(f"边 {from_node} -> {to_node} 已存在，跳过重复添加")
            return
        self._edges[from_node] = self._edges.get(from_node, set()) | {to_node}
        self._nodes[to_node].parents.append(from_node)
        self._nodes[from_node].children.append(to_node)
        self._nodes[to_node].in_degree += 1
        if to_node in self._root_nodes:
            self._root_nodes.remove(to_node)
            self._logger.debug(f"节点 {to_node} 移出根节点列表")

    def get_ready_nodes(self) -> List[str]:
        """获取所有就绪节点（入度为0且状态为PENDING的节点）。

        Returns:
            List[str]: 就绪节点的ID列表。
        """
        return [nid for nid, node in self._nodes.items() if node.in_degree == 0 and node.status == DagStatus.PENDING]

    def mark_finished(self, node_id: str) -> List[str]:
        """标记节点为成功完成，并返回因此新变为就绪状态的子节点列表。

        Args:
            node_id (str): 要标记完成的节点ID。

        Returns:
            List[str]: 新就绪的子节点ID列表。如果节点不存在则返回空列表。
        """
        if node_id not in self._nodes:
            self._logger.debug(f"尝试标记不存在的节点 {node_id} 为完成")
            return []
        node = self._nodes[node_id]
        if node.status != DagStatus.PENDING:
            self._logger.warning(f"节点 {node_id} 状态异常，无法标记完成")
            return []
        node.status = DagStatus.SUCCESS
        newly_ready = []
        for child in node.children:
            child_node = self._nodes[child]
            child_node.in_degree -= 1
            if child_node.in_degree == 0 and child_node.status == DagStatus.PENDING:
                child_node.status = DagStatus.PENDING
                newly_ready.append(child)
                self._logger.debug(f"节点 {child} 新变为就绪状态")
        return newly_ready

    def get_execution_order(self) -> List[List[str]]:
        """获取DAG的分层执行顺序（拓扑分层）。

        此方法只读操作，不会修改节点的入度状态，确保不影响后续的
        mark_finished 等状态管理流程。

        Returns:
            List[List[str]]: 分层列表，每层包含可以同时执行的节点ID。
                如果存在环，则返回能处理的部分层级。
        """
        in_deg = {nid: self._nodes[nid].in_degree for nid in self._nodes}
        levels = []
        remaining = set(in_deg.keys())
        while remaining:
            current_level = [nid for nid in remaining if in_deg[nid] == 0]
            if not current_level:
                self._logger.warning(f"DAG存在无法处理的环或死节点: {sorted(remaining)}")
                break
            levels.append(current_level)
            for nid in current_level:
                remaining.discard(nid)
                for child in self._nodes[nid].children:
                    if child in remaining:
                        in_deg[child] -= 1
        return levels

    def validate(self) -> Tuple[bool, str]:
        """验证DAG的有效性：无环且存在至少一个根节点。

        Returns:
            Tuple[bool, str]: 布尔值表示是否有效，字符串为验证结果描述。
        """
        visited = set()
        processing = set()
        for start in self._nodes:
            if start in visited:
                continue
            stack = [(start, False)]
            while stack:
                node, processed = stack.pop()
                if processed:
                    processing.discard(node)
                    continue
                if node in processing:
                    return (False, f"检测到环：{node}")
                if node in visited:
                    continue
                processing.add(node)
                stack.append((node, True))
                for child in self._nodes[node].children:
                    if child not in visited and child not in processing:
                        stack.append((child, False))
            visited.update(processing)
        if not self._root_nodes:
            return (False, "缺少根节点")
        return (True, "DAG有效")

# 模块结尾标记
# END OF dag_engine_v3.py
