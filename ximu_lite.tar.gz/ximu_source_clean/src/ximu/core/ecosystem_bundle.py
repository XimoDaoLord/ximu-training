# -*- coding: utf-8 -*-
"""生态资源 bundle 读取器（0.5版本）。

管理4个zip包的缓存加载，提供资源元数据查询与文件读取服务。
所有操作均带原子锁和访问统计，支持并发安全访问。
"""

import json
import os
import logging
import zipfile
import threading
from typing import Any, Dict, List, Optional, Tuple
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 全局配置
BUNDLE_ROOT = os.path.abspath(__file__)
for _ in range(4):
    BUNDLE_ROOT = os.path.dirname(BUNDLE_ROOT)
CACHES = {
    'zip_files': defaultdict(lambda: {'file': None, 'open_time': 0}),
    'index_data': defaultdict(lambda: {'data': None, 'build_time': 0})
}
STATS = {'zip_opens': 0, 'file_reads': 0}
LOCK = threading.Lock()
EXECUTOR = ThreadPoolExecutor(max_workers=4)

def _check_path(cat: str) -> bool:
    """验证资源包是否存在"""
    return os.path.exists(os.path.join(BUNDLE_ROOT, f"{cat}.zip"))

class BundleReader:
    """资源包管理器，封装缓存和并发控制"""
    
    def __init__(self) -> None:
        self._executor = ThreadPoolExecutor(max_workers=4)
        self._cache_expiries = {'zip_files': 600, 'index_data': 600}
    
    def available(self, cat: str) -> bool:
        """检查资源包是否存在"""
        with self._lock():
            return _check_path(cat)
    
    def _open_zip(self, cat: str) -> Optional[zipfile.ZipFile]:
        """原子化打开zip包并缓存"""
        with self._lock():
            if cat in CACHES['zip_files']:
                if time.time() - CACHES['zip_files'][cat]['open_time'] > self._cache_expiries['zip_files']:
                    self._close_zip(cat)
                if CACHES['zip_files'][cat]['file'] is not None:
                    return CACHES['zip_files'][cat]['file']
            zp = os.path.join(BUNDLE_ROOT, f"{cat}.zip")
            if not _check_path(cat):
                return None
            try:
                zf = zipfile.ZipFile(zp, 'r')
                CACHES['zip_files'][cat] = {'file': zf, 'open_time': time.time()}
                STATS['zip_opens'] += 1
                return zf
            except Exception as e:
                logger.error(f"Failed to open zip {zp}: {str(e)}")
                return None
    
    def _close_zip(self, cat: str) -> None:
        """安全关闭zip包并释放资源"""
        with self._lock():
            if cat in CACHES['zip_files'] and CACHES['zip_files'][cat]['file'] is not None:
                CACHES['zip_files'][cat]['file'].close()
                del CACHES['zip_files'][cat]
    
    def list_items(self, cat: str) -> List[str]:
        """获取资源分类下的所有资源ID（按字典序）"""
        with self._lock():
            if cat in CACHES['index_data'] and CACHES['index_data'][cat]['build_time'] > time.time() - self._cache_expiries['index_data']:
                return sorted(CACHES['index_data'][cat]['data'])
        try:
            index: Dict[str, List[str]] = defaultdict(list)
            if not (zf := self._open_zip(cat)):
                return []
            for name in zf.namelist():
                parts = name.split('/', 1)
                if len(parts) >= 2:
                    index[parts[0]].append(name)
            CACHES['index_data'][cat] = {'data': index, 'build_time': time.time()}
            return sorted(index.keys())
        except Exception as e:
            logger.error(f"Index build failed for {cat}: {str(e)}")
            return []
    
    def read_json(self, cat: str, item_id: str, filename: str) -> Optional[Dict[str, Any]]:
        """读取资源JSON文件，处理Unicode解码异常"""
        with self._lock():
            if not (zf := self._open_zip(cat)):
                return None
            prefix = f"{item_id}/"
            found = False
            for name in zf.namelist():
                if (name.startswith(prefix) and 
                    (name.endswith(f"/{filename}") or name == filename)):
                    try:
                        content = zf.read(name).decode('utf-8', errors='replace')
                        return json.loads(content)
                    except (json.JSONDecodeError, UnicodeDecodeError) as e:
                        logger.warning(f"JSON parse error in {name}: {str(e)}")
                        return None
            return None
    
    def read_text(self, cat: str, item_id: str, filename: str) -> Optional[str]:
        """读取资源文本文件，自动处理编码问题"""
        data = self._read_bytes(cat, item_id, filename)
        if data is None:
            return None
        return data.decode('utf-8', errors='replace')
    
    def _read_bytes(self, cat: str, item_id: str, filename: str) -> Optional[bytes]:
        """通用字节读取方法，处理文件路径匹配"""
        with self._lock():
            if not (zf := self._open_zip(cat)):
                return None
            prefix = f"{item_id}/"
            for name in zf.namelist():
                if (name.startswith(prefix) and 
                    (name.endswith(f"/{filename}") or name == filename)):
                    try:
                        return zf.read(name)
                    except OSError as e:
                        logger.error(f"File read error {name}: {str(e)}")
                        return None
            return None
    
    def stat_zip(self, cat: str, item_id: str) -> Dict[str, Any]:
        """生成资源包元数据统计"""
        zp = os.path.join(BUNDLE_ROOT, f"{cat}.zip")
        exists = os.path.exists(zp)
        return {
            'id': item_id,
            'type': cat,
            'filename': os.path.basename(zp) if exists else '',
            'size': os.path.getsize(zp) if exists else 0,
            'path': zp,
            'exists': exists,
            'stats': {
                'zip_opens': STATS['zip_opens'],
                'file_reads': STATS['file_reads']
            }
        }

# 单例模式确保全局唯一实例
BUNDLE_READER = BundleReader()

def available(cat: str) -> bool:
    """检查资源包是否存在"""
    return BUNDLE_READER.available(cat)

def list_items(cat: str) -> List[str]:
    """获取资源分类下的所有资源ID（按字典序）"""
    return BUNDLE_READER.list_items(cat)

def read_json(cat: str, item_id: str, filename: str) -> Optional[Dict[str, Any]]:
    """读取资源JSON文件，处理Unicode解码异常"""
    return BUNDLE_READER.read_json(cat, item_id, filename)

def read_text(cat: str, item_id: str, filename: str) -> Optional[str]:
    """读取资源文本文件，自动处理编码问题"""
    return BUNDLE_READER.read_text(cat, item_id, filename)

def read_bytes(cat: str, item_id: str, filename: str) -> Optional[bytes]:
    """通用字节读取方法，处理文件路径匹配"""
    return BUNDLE_READER._read_bytes(cat, item_id, filename)

def stat_zip(cat: str, item_id: str) -> Dict[str, Any]:
    """生成资源包元数据统计"""
    return BUNDLE_READER.stat_zip(cat, item_id)
