# -*- coding: utf-8 -*-
"""
实时模型网关：多供应商LLM调用与故障管理。
核心功能：
- 多供应商路由（OpenAI兼容）
- 熔断降级（支持状态机与自动恢复）
- 鉴权失败诊断（区分配置错误与认证失败）
- 密钥解密（Fernet加密）
- 线程安全与异常隔离
设计规范：
- 单一职责原则（拆分4个独立模块）
- 显式依赖注入
- 线程安全锁封装
- 类型注解与文档
- 日志记录关键操作
"""
import json
import logging
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Type
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64
import struct

@dataclass
class CircuitBreakerConfig:
    """
    熔断器配置参数。
    Args:
        consecutive_failures: 连续失败次数触发熔断（默认3次）
        cooldown_seconds: 熔断后冷却时间（默认60秒）
        error_threshold: 总错误阈值（可选，默认3次）
    """
    consecutive_failures: int = 3
    cooldown_seconds: float = 60.0
    error_threshold: int = 3

class CircuitBreaker:
    """
    线程安全熔断器，支持状态机与自动恢复。
    状态转换：
        CLOSED → OPEN（触发熔断） → HALF_OPEN（探测阶段） → CLOSED（恢复成功）
    Args:
        config: 熔断器配置参数
    """
    def __init__(self, config: CircuitBreakerConfig) -> None:
        """
        初始化熔断器状态与原子锁。
        Args:
            config: 熔断器配置参数
        """
        self.config = config
        self._failure_count = 0
        self._last_failure_time = 0.0
        self._cooldown_end = 0.0
        self._lock = threading.Lock()
        self._state = "CLOSED"

    def should_break(self, error: bool) -> bool:
        """
        判断是否触发熔断。
        Args:
            error: 是否发生错误（True表示失败）
        Returns:
            是否熔断（True表示隔离）
        """
        now = time.time()
        with self._lock:
            if error:
                if self._state == "OPEN":
                    # 进入半开状态，重置计数并开始探测
                    self._failure_count = 0
                    self._cooldown_end = now + self.config.cooldown_seconds
                    self._state = "HALF_OPEN"
                    return False
                # 持续失败，累计错误次数
                self._failure_count += 1
                self._last_failure_time = now
                # 检查总错误阈值
                return self._failure_count >= self.config.error_threshold
            else:
                # 成功响应，处理半开状态
                if self._state == "HALF_OPEN":
                    if now >= self._cooldown_end:
                        self._state = "CLOSED"
                        self._failure_count = 0
                    return False

    def reset(self) -> None:
        """
        强制重置熔断状态。
        """
        with self._lock:
            self._state = "CLOSED"
            self._failure_count = 0
            self._last_failure_time = 0.0
            self._cooldown_end = 0.0

class BreakerManager:
    """
    熔断器管理器，支持线程安全创建与获取。
    Args:
        config: 熔断器配置字典（可选，使用默认配置）
    """
    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        """
        初始化熔断器注册表与原子锁。
        Args:
            config: 熔断器配置字典
        """
        self._registry: Dict[str, CircuitBreaker] = {}
        self._lock = threading.Lock()
        self._default_config = CircuitBreakerConfig()
        self._global_config = config or {}

    def get_breaker(self, name: str) -> CircuitBreaker:
        """
        获取或创建指定名称的熔断器实例。
        Args:
            name: 熔断器名称（区分大小写）
        Returns:
            熔断器对象
        """
        with self._lock:
            if name not in self._registry:
                # 合并全局配置与默认配置
                merged_config = CircuitBreakerConfig(
                    consecutive_failures=self._global_config.get("consecutive_failures", self._default_config.consecutive_failures),
                    cooldown_seconds=self._global_config.get("cooldown_seconds", self._default_config.cooldown_seconds),
                    error_threshold=self._global_config.get("error_threshold", self._default_config.error_threshold)
                )
                self._registry[name] = CircuitBreaker(merged_config)
            return self._registry[name]

class AuthDiagStrategy:
    """
    鉴权失败诊断策略，区分配置错误与真实鉴权失败。
    Args:
        auth_codes: 鉴权相关HTTP状态码（默认401,403）
        auth_hints: 鉴权失败响应体关键词（默认空）
    """
    def __init__(self, auth_codes: Tuple[int, ...] = (401, 403), auth_hints: Tuple[str, ...] = ()) -> None:
        """
        初始化鉴权诊断策略。
        Args:
            auth_codes: 鉴权相关HTTP状态码
            auth_hints: 鉴权失败响应体关键词
        """
        self.auth_codes = auth_codes
        self.auth_hints = auth_hints
        self._config = self._load_config()

    def diagnose(self, provider: Dict[str, Any], model: str, code: int, detail: str = "") -> Dict[str, Any]:
        """
        诊断鉴权失败原因。
        Args:
            provider: 供应商配置字典
            model: 模型标识
            code: HTTP状态码
            detail: 响应体片段
        Returns:
            诊断结果字典，包含：
                - is_config_error: 是否配置错误
                - real_auth_failure: 是否真实鉴权失败
                - checks: 检查项列表
                - message: 错误描述
        """
        checks = []
        is_config_error = False
        provider_name = provider.get("name", "").lower()
        # 模型名检查
        if provider.get("models", []) and model not in provider["models"]:
            checks.append({"check": "model_name", "ok": False, "detail": f"模型 {model} 不在供应商模型列表中"})
            is_config_error = True
        else:
            checks.append({"check": "model_name", "ok": True, "detail": "模型存在于供应商列表"})
        # 密钥前缀检查
        key_prefix = self._check_key_prefix(provider, provider_name)
        if key_prefix:
            expected_vendors = self._config.get("key_prefixes", {}).get(key_prefix, set())
            if provider_name not in expected_vendors:
                checks.append({"check": "key_prefix", "ok": False, "detail": f"密钥前缀错误，供应商应为 {sorted(expected_vendors)}"})
                is_config_error = True
            else:
                checks.append({"check": "key_prefix", "ok": True, "detail": "密钥前缀匹配供应商"})
        else:
            checks.append({"check": "key_prefix", "ok": True, "detail": "未知密钥前缀或无前缀"})
        # 端点URL检查
        base_url = provider.get("base_url", "")
        if base_url:
            if not base_url.startswith(("http://", "https://")):
                checks.append({"check": "endpoint", "ok": False, "detail": "缺少协议头"})
                is_config_error = True
            elif base_url.rstrip("/").endswith("/chat/completions"):
                checks.append({"check": "endpoint", "ok": False, "detail": "URL不应包含 /chat/completions"})
                is_config_error = True
            else:
                checks.append({"check": "endpoint", "ok": True, "detail": "有效端点URL"})
        else:
            checks.append({"check": "endpoint", "ok": False, "detail": "缺少端点URL"})
            is_config_error = True
        # 响应体错误线索检查
        config_error_hints = self._config.get("error_hints", {}).get("config", [])
        detail_lower = detail.lower()
        for hint in config_error_hints:
            if hint in detail_lower:
                checks.append({"check": "error_body", "ok": False, "detail": f"响应体提示 {hint}"})
                is_config_error = True
                break
        # 真实鉴权失败判断
        real_auth_failure = not is_config_error and code in self.auth_codes
        if real_auth_failure:
            checks.append({"check": "auth_status", "ok": False, "detail": f"HTTP {code} 真实鉴权失败"})
        else:
            checks.append({"check": "auth_status", "ok": True, "detail": "非配置错误且非典型鉴权失败状态码"})
        return {
            "is_config_error": is_config_error,
            "real_auth_failure": real_auth_failure,
            "checks": checks,
            "message": "配置错误，非密钥无效" if is_config_error else f"确认鉴权失败 HTTP {code}"
        }

    def _load_config(self) -> Dict[str, Any]:
        """
        加载鉴权诊断配置（默认加载api_auth_diag.json）。
        """
        config_path = os.environ.get("XIMU_AUTH_DIAG_CONFIG") or \
            os.path.join(os.path.dirname(__file__), "..", "config", "api_auth_diag.json")
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.error("鉴权诊断配置加载失败: %s", e)
            return {}

    def _check_key_prefix(self, provider: Dict[str, Any], provider_name: str) -> Optional[str]:
        """
        检查密钥前缀与供应商匹配性。
        Args:
            provider: 供应商配置
            provider_name: 供应商名称（小写）
        Returns:
            匹配的密钥前缀，或None表示未匹配
        """
        key_prefixes = self._config.get("key_prefixes", {})
        api_key = provider.get("key", "")
        for prefix in sorted(key_prefixes.keys(), key=len, reverse=True):
            if api_key.startswith(prefix):
                return prefix
        return None

class SecretDecryptor:
    """
    密钥解密器，支持Fernet加密与主密钥缓存。
    Args:
        master_key_path: 主密钥文件路径（可选）
    """
    def __init__(self, master_key_path: Optional[str] = None) -> None:
        """
        初始化密钥解密器。
        Args:
            master_key_path: 主密钥文件路径
        """
        self.master_key_path = master_key_path
        self._fernet_instance: Optional[Fernet] = None
        self._key_cache: Dict[str, Any] = {}
        self._lock = threading.Lock()

    def _load_key(self) -> Optional[bytes]:
        """
        加载数据库主密钥，带哈希校验与缓存。
        Returns:
            主密钥字节串，或None表示加载失败
        """
        if not self.master_key_path:
            return None
        try:
            with open(self.master_key_path, "rb") as f:
                key_bytes = f.read().strip()
                # 使用PBKDF2生成密钥
                salt = os.urandom(16)
                kdf = PBKDF2HMAC(
                    algorithm=hashes.SHA256(),
                    length=32,
                    salt=salt,
                    iterations=100000
                )
                key = kdf.derive(key_bytes)
                # 校验密钥哈希
                stored_hash = self._key_cache.get("hash", None)
                if stored_hash is None or stored_hash != hash(key):
                    self._key_cache["hash"] = hash(key)
                    self._fernet_instance = Fernet(key)
                    self._key_cache["key"] = key
                    self._key_cache["salt"] = salt
                    self._key_cache["iterations"] = 100000
                return self._key_cache["key"]
        except Exception as e:
            logger.error("密钥加载失败: %s", e)
            return None

    def decrypt(self, value: str) -> str:
        """
        解密Fernet加密数据。
        Args:
            value: 加密字符串（格式：p140:cipher:<base64编码>)
        Returns:
            解密明文或原值（如果解密失败）
        """
        if not value.startswith("p140:cipher:"):
            return value
        cipher_part = value[11:]
        if not cipher_part:
            return value
        try:
            with self._lock:
                if not self._fernet_instance:
                    logger.warning("Fernet实例未初始化，跳过解密")
                    return value
                decrypted = self._fernet_instance.decrypt(cipher_part.encode())
                return decrypted.decode("utf-8")
        except Exception as e:
            logger.error("解密失败: %s", e)
            raise ValueError(f"解密失败: {e}")

    def _is_cipher(self, value: str) -> bool:
        """
        判断是否为Fernet加密格式。
        """
        return value.startswith("p140:cipher:")

@dataclass
class ProviderState:
    """
    供应商运行状态数据类。
    封装鉴权失败计数、恢复探测标记等状态，提升线程安全性。
    """
    auth_fail_streak: int = 0
    recovery_probe_started: bool = False
    last_probe_time: float = 0.0
    last_error_code: int = 0

class LiveModelGateway:
    """
    多供应商LLM调用网关，集成熔断、鉴权诊断与自动恢复。
    所有实例方法均线程安全，通过依赖注入实现解耦。
    Args:
        breaker_manager: 熔断器管理器
        auth_diag_strategy: 鉴权诊断策略
        secret_decryptor: 密钥解密器
        providers_cache: 供应商配置缓存（可选）
    """
    def __init__(self, breaker_manager: BreakerManager, auth_diag_strategy: AuthDiagStrategy, secret_decryptor: SecretDecryptor, providers_cache: Optional[List[Dict[str, Any]]] = None) -> None:
        """
        初始化网关核心状态。
        Args:
            breaker_manager: 熔断器管理器
            auth_diag_strategy: 鉴权诊断策略
            secret_decryptor: 密钥解密器
            providers_cache: 供应商配置缓存
        """
        self._state_lock = threading.RLock()
        self._auth_lock = threading.Lock()
        self._providers_cache = providers_cache or []
        self._provider_states = {}
        self._probe_stop_event = threading.Event()
        self._probe_thread = None
        self._shutdown = False
        self._breaker_manager = breaker_manager
        self._auth_diag_strategy = auth_diag_strategy
        self._secret_decryptor = secret_decryptor

    def shutdown(self) -> None:
        """
        优雅关闭网关，停止后台线程。
        """
        with self._state_lock:
            if self._shutdown:
                return
            self._shutdown = True
            logger.info("开始关闭LiveModelGateway...")
            self._probe_stop_event.set()
            if self._probe_thread and self._probe_thread.is_alive():
                self._probe_thread.join(timeout=5.0)
                if self._probe_thread.is_alive():
                    logger.warning("恢复探测线程未正常终止")
            with self._state_lock:
                self._providers_cache = []
                self._provider_states.clear()

    def _registry_path(self) -> str:
        """
        解析供应商配置路径。
        Returns:
            配置文件绝对路径
        """
        env_path = os.environ.get("XIMU_API_REGISTRY")
        if env_path and os.path.exists(env_path):
            return env_path
        default_path = os.path.join(
            os.path.dirname(__file__),
            "..",
            "config",
            "api_registry.json"
        )
        if not os.path.exists(default_path):
            raise FileNotFoundError(f"配置文件不存在: {default_path}")
        return default_path

    def load_providers(self) -> List[Dict[str, Any]]:
        """
        加载数据库供应商配置（带缓存）。
        """
        with self._state_lock:
            if self._providers_cache:
                return list(self._providers_cache)
            if self._shutdown:
                raise ProviderConfigError("网关已关闭，无法加载配置")
            try:
                path = self._registry_path()
                providers = self._load_and_decrypt_providers(path, self._secret_decryptor)
                self._providers_cache = providers
                logger.info("成功加载 %d 个供应商配置", len(providers))
                return list(providers)
            except Exception as e:
                raise ProviderConfigError(f"配置加载失败: {str(e)}", e)

    def get_provider(self, provider_name: str) -> Optional[Dict[str, Any]]:
        """
        按名称获取供应商配置。
        """
        providers = self.load_providers()
        for provider in providers:
            if provider.get("name", "").lower() == provider_name.lower():
                return dict(provider)
        return None

    def get_breaker(self, provider_name: str) -> CircuitBreaker:
        """
        获取供应商熔断器实例。
        """
        return self._breaker_manager.get_breaker(provider_name)

    def _record_model_auth_success(self, provider_name: str, model_id: str) -> None:
        """
        鉴权成功时重置失败计数。
        """
        with self._auth_lock:
            state = self._provider_states.get(provider_name)
            if state and state.auth_fail_streak > 0:
                state.auth_fail_streak = 0
                logger.debug("供应商 %s 鉴权成功，重置失败计数", provider_name)

    def _on_auth_failure(self, provider_name: str, model_id: str, http_code: int, detail: str = "") -> Dict[str, Any]:
        """
        处理鉴权失败：诊断、状态更新、触发恢复探测。
        """
        provider = self.get_provider(provider_name)
        if not provider:
            raise ValueError(f"未知供应商: {provider_name}")
        diag_result = self._auth_diag_strategy.diagnose(provider, model_id, http_code, detail)
        with self._auth_lock:
            if provider_name not in self._provider_states:
                self._provider_states[provider_name] = ProviderState()
            state = self._provider_states[provider_name]
            state.auth_fail_streak += 1
            state.last_error_code = http_code
            if diag_result["is_config_error"]:
                logger.warning("配置错误: %s", diag_result["message"])
                return diag_result
            if not state.recovery_probe_started and state.auth_fail_streak >= 2:
                state.recovery_probe_started = True
                self._start_recovery_probe(provider_name, state)
            logger.info("鉴权失败（第 %d 次）: %s", state.auth_fail_streak, diag_result["message"])
            return diag_result

    def _start_recovery_probe(self, provider_name: str, state: ProviderState) -> None:
        """
        启动恢复探测线程，间隔60秒检测熔断状态。
        """
        if self._shutdown:
            return
        def probe_thread():
            try:
                while not self._probe_stop_event.is_set():
                    if self._shutdown:
                        break
                    time.sleep(60)
                    provider = self.get_provider(provider_name)
                    if provider and self.get_breaker(provider_name).should_break(False):
                        self._on_auth_failure(provider_name, provider.get("default_model", ""), 200, "recovery")
                    else:
                        state.recovery_probe_started = False
            except Exception as e:
                logger.error("探测线程异常: %s", e)
                self._probe_stop_event.clear()
        self._probe_thread = threading.Thread(target=probe_thread, daemon=True)
        self._probe_thread.start()

    @classmethod
    def from_config(cls, config_path: str, auth_codes: Tuple[int, ...] = (401, 403), auth_hints: Tuple[str, ...] = (), master_key_path: Optional[str] = None) -> "LiveModelGateway":
        """
        从配置文件创建网关实例。
        """
        decryptor = SecretDecryptor(master_key_path)
        auth_strategy = AuthDiagStrategy(auth_codes, auth_hints)
        breaker = BreakerManager()
        providers = cls._load_providers(config_path, decryptor)
        return cls(breaker, auth_strategy, decryptor, providers)

    @staticmethod
    def _load_providers(config_path: str, decryptor: SecretDecryptor) -> List[Dict[str, Any]]:
        """
        加载数据库配置并解密密钥字段。
        """
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            raise ProviderConfigError(f"配置加载失败: {str(e)}", e)
        for entry in data.values():
            if isinstance(entry, dict) and "key" in entry:
                entry["key"] = decryptor.decrypt(str(entry["key"]))
        providers = data.get("api_keys", []) or data.get("providers", [])
        if not providers:
            logger.warning("未找到供应商配置")
            return providers
