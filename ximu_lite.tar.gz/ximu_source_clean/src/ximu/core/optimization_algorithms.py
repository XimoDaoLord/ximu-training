# -*- coding: utf-8 -*-
"""
优化算法系统 - 包含多种现代优化算法
"""
from __future__ import annotations
import logging
from dataclasses import dataclass
from typing import Dict, Any, Optional, Union, Tuple
import numpy as np

logger = logging.getLogger(__name__)

class _LazyNumpy:
    _instance: Optional[np.ndarray] = None

    def __getattr__(self, name: str) -> np.ndarray:
        if _LazyNumpy._instance is None:
            import numpy as _np
            _LazyNumpy._instance = _np
            logger.debug("Numpy 模块已加载")
        return getattr(_LazyNumpy._instance, name)

np = _LazyNumpy()

@dataclass
class OptimizationConfig:
    """
    优化配置类
    
    定义优化算法所需的超参数，包括学习率、最大迭代次数、
    容差、批量大小、动量、权重衰减和梯度裁剪阈值。
    """
    learning_rate: float = 0.001
    max_iterations: int = 10000
    tolerance: float = 1e-6
    batch_size: int = 32
    momentum: float = 0.9
    weight_decay: float = 0.0
    gradient_clipping: float = 1.0

class BaseOptimizer:
    def __init__(self, config: OptimizationConfig) -> None:
        self.config = config
        self.iteration: int = 0
        self.loss_history: list[float] = []
        logger.debug(f"初始化 {self.__class__.__name__} 优化器")

    def optimize(self, parameters: Dict[str, Any], gradients: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行参数更新
        
        Args:
            parameters: 当前参数字典
            gradients: 对应梯度字典
            
        Returns:
            更新后的参数字典
        """
        raise NotImplementedError

    def step(self, loss: float) -> None:
        """
        记录一次迭代
        
        Args:
            loss: 当前损失值
        """
        self.loss_history.append(loss)
        self.iteration += 1

class GradientDescent(BaseOptimizer):
    def optimize(self, parameters: Dict[str, Any], gradients: Dict[str, Any]) -> Dict[str, Any]:
        updated = {}
        for key in parameters:
            param_val = parameters[key]
            grad_val = gradients[key]
            new_val = param_val - self.config.learning_rate * grad_val
            updated[key] = new_val
        return updated

class MomentumOptimizer(GradientDescent):
    def __init__(self, config: OptimizationConfig) -> None:
        super().__init__(config)
        self.velocity: Dict[str, np.ndarray] = {}

    def _init_velocity(self, key: str, param_shape: np.ndarray) -> None:
        if key not in self.velocity:
            self.velocity[key] = np.zeros_like(param_shape)

    def optimize(self, parameters: Dict[str, Any], gradients: Dict[str, Any]) -> Dict[str, Any]:
        updated = {}
        for key in parameters:
            if key in gradients:
                self._init_velocity(key, parameters[key])
                self.velocity[key] = self.config.momentum * self.velocity[key] - \
                    self.config.learning_rate * gradients[key]
                updated[key] = parameters[key] + self.velocity[key]
            else:
                updated[key] = parameters[key]
        return updated

# ... (省略其他优化器类的实现，格式和实现方式与上述类似) ...

class ConjugateGradient(BaseOptimizer):
    def __init__(self, config: OptimizationConfig) -> None:
        super().__init__(config)
        self.direction: Dict[str, np.ndarray] = {}
        self.prev_gradient: Dict[str, np.ndarray] = {}

    def optimize(self, parameters: Dict[str, Any], gradients: Dict[str, Any]) -> Dict[str, Any]:
        updated = {}
        for key in parameters:
            if key in gradients:
                grad = gradients[key]

                if key not in self.prev_gradient:
                    self.direction[key] = -grad
                    self.prev_gradient[key] = grad.copy()
                else:
                    diff = grad - self.prev_gradient[key]
                    beta = np.sum(diff * grad) / np.sum(self.prev_gradient[key] ** 2 + 1e-8)
                    self.direction[key] = -grad + beta * self.direction[key]
                    self.prev_gradient[key] = grad.copy()

                alpha = self._line_search(parameters[key], grad, self.direction[key])
                updated[key] = parameters[key] + alpha * self.direction[key]
            else:
                updated[key] = parameters[key]

        return updated

    def _line_search(self, x: np.ndarray, grad: np.ndarray, direction: np.ndarray) -> float:
        return self.config.learning_rate
