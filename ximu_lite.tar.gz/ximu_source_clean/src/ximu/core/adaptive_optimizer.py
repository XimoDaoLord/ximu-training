import logging
import threading
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("src.ximu.core.adaptive_optimizer")

# Constants
_METRICS_HISTORY_LIMIT = 100
_LOAD_HISTORY_LIMIT = 60
_HIGH_LOAD_THRESHOLD = 0.8
_LOW_LOAD_THRESHOLD = 0.3
_MEMORY_STEP_MB = 512
_ANOMALY_HISTORY_LIMIT = 1000

_CPU_HIGH_PCT = 80.0
_CPU_LOW_PCT = 50.0
_QUALITY_LOW_SCORE = 70.0
_QUALITY_HIGH_SCORE = 90.0
_CONCURRENCY_MAX = 100.0
_CONCURRENCY_MIN = 1.0
_BATCH_MAX = 1000.0
_BATCH_MIN = 10.0
_BATCH_STEP = 10.0
_TIMEOUT_MAX = 30.0
_TIMEOUT_MIN = 1.0
_TIMEOUT_STEP = 0.5
_CONSERVATIVE_FACTOR = 0.9
_AGGRESSIVE_FACTOR = 1.1

# 版本
__version__ = "0.5"


class OptimizationGoal(Enum):
    """定义优化目标枚举类型。"""
    LATENCY = auto()
    THROUGHPUT = auto()
    RESOURCE_EFFICIENCY = auto()
    COST = auto()
    BALANCED = auto()


@dataclass
class PerformanceMetrics:
    """性能指标数据类，用于记录系统运行时的关键指标。"""
    timestamp: float
    latency_ms: float = 0.0
    throughput_rps: float = 0.0
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    error_rate: float = 0.0
    queue_depth: int = 0

    @property
    def quality_score(self) -> float:
        """计算质量得分，基于错误率、CPU使用率和内存使用率。

        Returns:
            float: 质量得分范围在 [0, 100] 之间。
        """
        score = 100.0
        score -= min(self.error_rate * 100, 30)
        score -= min(self.cpu_usage, 30)
        score -= min(self.memory_usage, 20)
        return max(0.0, min(100.0, score))


class AdaptiveOptimizer:
    """自适应优化器，根据性能指标动态调整系统参数。"""

    def __init__(
        self,
        optimization_goal: OptimizationGoal = OptimizationGoal.BALANCED,
        sampling_interval: float = 1.0,
        adjustment_step: float = 0.1,
    ) -> None:
        """初始化自适应优化器。

        Args:
            optimization_goal: 优化目标，默认为 BALANCED。
            sampling_interval: 采样间隔时间（秒）。
            adjustment_step: 参数调整步长。
        """
        self._goal = optimization_goal
        self._sampling_interval = sampling_interval
        self._adjustment_step = adjustment_step
        self._metrics_history: List[PerformanceMetrics] = []
        self._parameters: Dict[str, float] = {
            "concurrency": 10.0,
            "batch_size": 100.0,
            "timeout": 5.0,
            "retry_delay": 1.0,
        }
        self._optimal_params: Dict[str, float] = dict(self._parameters)
        self._lock = threading.RLock()
        self._running = False
        self._optimizer_thread: Optional[threading.Thread] = None
        self._callbacks: List[Callable[[Dict[str, float]], None]] = []
        logger.info("AdaptiveOptimizer initialized: goal=%s", self._goal.name)

    def start(self) -> None:
        """启动优化器线程。"""
        with self._lock:
            if self._running:
                return
            self._running = True
            self._optimizer_thread = threading.Thread(
                target=self._optimize_loop,
                daemon=True,
                name="AdaptiveOptimizer",
            )
            self._optimizer_thread.start()
        logger.info("AdaptiveOptimizer started")

    def stop(self) -> None:
        """停止优化器线程。"""
        with self._lock:
            self._running = False
        if self._optimizer_thread:
            self._optimizer_thread.join(timeout=5.0)
        logger.info("AdaptiveOptimizer stopped")

    def record_metrics(self, metrics: PerformanceMetrics) -> None:
        """记录性能指标。

        Args:
            metrics: 性能指标对象。
        """
        with self._lock:
            self._metrics_history.append(metrics)
            if len(self._metrics_history) > _METRICS_HISTORY_LIMIT:
                self._metrics_history = self._metrics_history[-_METRICS_HISTORY_LIMIT:]

    def _apply_goal_adjustment(
        self, adjusted: Dict[str, float], metrics: PerformanceMetrics
    ) -> None:
        """根据优化目标应用参数调整。

        Args:
            adjusted: 待调整的参数字典。
            metrics: 当前性能指标。
        """
        step = self._adjustment_step
        if self._goal == OptimizationGoal.LATENCY:
            adjusted["concurrency"] = max(_CONCURRENCY_MIN, adjusted["concurrency"] - step)
            adjusted["batch_size"] = max(_BATCH_MIN, adjusted["batch_size"] - _BATCH_STEP)
            adjusted["timeout"] = min(_TIMEOUT_MAX, adjusted["timeout"] + _TIMEOUT_STEP)
        elif self._goal == OptimizationGoal.THROUGHPUT:
            adjusted["concurrency"] = min(_CONCURRENCY_MAX, adjusted["concurrency"] + step)
            adjusted["batch_size"] = min(_BATCH_MAX, adjusted["batch_size"] + _BATCH_STEP)
            adjusted["timeout"] = max(_TIMEOUT_MIN, adjusted["timeout"] - _TIMEOUT_STEP)
        elif self._goal == OptimizationGoal.RESOURCE_EFFICIENCY:
            if metrics.cpu_usage > _CPU_HIGH_PCT:
                adjusted["concurrency"] = max(_CONCURRENCY_MIN, adjusted["concurrency"] - step)
            elif metrics.cpu_usage < _CPU_LOW_PCT:
                adjusted["concurrency"] = min(_CONCURRENCY_MAX, adjusted["concurrency"] + step)
        elif self._goal == OptimizationGoal.BALANCED:
            if metrics.quality_score < _QUALITY_LOW_SCORE:
                adjusted["concurrency"] *= _CONSERVATIVE_FACTOR
                adjusted["batch_size"] *= _CONSERVATIVE_FACTOR
            elif metrics.quality_score > _QUALITY_HIGH_SCORE:
                adjusted["concurrency"] *= _AGGRESSIVE_FACTOR
                adjusted["batch_size"] *= _AGGRESSIVE_FACTOR

    def adjust_parameters(
        self, metrics: Optional[PerformanceMetrics] = None
    ) -> Dict[str, float]:
        """调整参数并返回调整后的参数。

        Args:
            metrics: 可选的性能指标，若为 None 则使用历史记录中的最新指标。

        Returns:
            调整后的参数字典。
        """
        if metrics is None:
            with self._lock:
                if not self._metrics_history:
                    return self._parameters.copy()
                metrics = self._metrics_history[-1]

        adjusted = self._parameters.copy()

        with self._lock:
            self._apply_goal_adjustment(adjusted, metrics)

            for key, value in adjusted.items():
                self._parameters[key] = value

            for callback in self._callbacks:
                try:
                    callback(adjusted)
                except Exception as e:
                    logger.error("Parameter adjustment callback error: %s", e)

        logger.info("Parameters adjusted: %s", adjusted)
        return adjusted

    def get_parameters(self) -> Dict[str, float]:
        """获取当前参数。

        Returns:
            当前参数字典的副本。
        """
        with self._lock:
            return self._parameters.copy()

    def set_parameters(self, params: Dict[str, float]) -> None:
        """手动设置参数。

        Args:
            params: 要设置的参数字典。
        """
        with self._lock:
            self._parameters.update(params)
            logger.info("Parameters manually set: %s", params)

    def on_adjustment(self, callback: Callable[[Dict[str, float]], None]) -> None:
        """注册参数调整回调。

        Args:
            callback: 回调函数，接受参数字典作为参数。
        """
        self._callbacks.append(callback)

    def _optimize_loop(self) -> None:
        """优化器主循环。"""
        while self._running:
            try:
                with self._lock:
                    if self._metrics_history:
                        last_metrics = self._metrics_history[-1]
                        self.adjust_parameters(last_metrics)
            except Exception as e:
                logger.error("Optimization loop error: %s", e)
            time.sleep(self._sampling_interval)


class ResourceAdaptor:
    """资源适配器，根据负载动态调整 CPU 和内存分配。"""

    def __init__(
        self,
        min_cpu: int = 1,
        max_cpu: int = 16,
        min_memory_mb: int = 512,
        max_memory_mb: int = 8192,
    ) -> None:
        """初始化资源适配器。

        Args:
            min_cpu: 最小 CPU 核心数。
            max_cpu: 最大 CPU 核心数。
            min_memory_mb: 最小内存（MB）。
            max_memory_mb: 最大内存（MB）。
        """
        self._min_cpu = min_cpu
        self._max_cpu = max_cpu
        self._min_memory_mb = min_memory_mb
        self._max_memory_mb = max_memory_mb
        self._current_cpu = min_cpu
        self._current_memory_mb = min_memory_mb
