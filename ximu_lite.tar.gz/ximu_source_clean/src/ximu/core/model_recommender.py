# -*- coding: utf-8 -*-
"""模型推荐器 - 根据设备配置和用户偏好推荐模型。"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


class ModelPurpose(Enum):
    """模型用途枚举。"""
    CODE_GENERATION = "code_generation"
    CREATIVE_WRITING = "creative_writing"
    REASONING = "reasoning"
    MULTIMODAL = "multimodal"
    TRANSLATION = "translation"
    GENERAL = "general"


@dataclass
class ModelRecommendation:
    """模型推荐结果数据类。"""
    model_id: str
    source: str
    size_gb: float
    quantization: str
    purpose: str
    score: float
    download_url: str
    description: str = ""


class ModelRecommender:
    """模型推荐器，根据设备配置和用途推荐合适模型。"""

    MEM_OVERHEAD = 1.3

    def __init__(self, device_config: Dict[str, Any]) -> None:
        self._config = device_config
        self._cache: Dict[str, ModelRecommendation] = {}

    def recommend(self,
                  purpose: str = "general",
                  limit: int = 5) -> List[ModelRecommendation]:
        """根据用途、显存、内存和 CPU 能力推荐模型。

        Args:
            purpose: 模型用途
            limit: 返回推荐数量上限

        Returns:
            按评分排序的去重推荐列表
        """
        try:
            limit = int(limit)
        except (TypeError, ValueError):
            limit = 5
        limit = max(1, min(50, limit))

        gpu_mem = self._config.get('gpu_memory_gb', 0)
        cpu_cores = self._config.get('cpu_cores', 0) or 0
        memory_gb = self._config.get('memory_gb', 0) or 0

        candidates: List[ModelRecommendation] = []

        if gpu_mem >= 24:
            candidates.extend(self._get_large_models(purpose))
        elif gpu_mem >= 16:
            candidates.extend(self._get_medium_models(purpose))
        elif gpu_mem >= 8:
            candidates.extend(self._get_small_models(purpose))
        else:
            candidates.extend(self._get_tiny_models(purpose))

        if gpu_mem < 8:
            if memory_gb > 0:
                fit = [m for m in candidates if m.size_gb * self.MEM_OVERHEAD <= memory_gb]
                if fit:
                    candidates = fit
            if cpu_cores and cpu_cores <= 2:
                light = [m for m in candidates if m.size_gb <= 2.0]
                if light:
                    candidates = light

        candidates.sort(key=lambda x: x.score, reverse=True)

        seen: set = set()
        unique: List[ModelRecommendation] = []
        for m in candidates:
            if m.model_id not in seen:
                seen.add(m.model_id)
                unique.append(m)
                if len(unique) >= limit:
                    break

        return unique

    def _get_large_models(self, purpose: str) -> List[ModelRecommendation]:
        """获取大模型推荐（显存>=24GB）。"""
        return [
            ModelRecommendation(
                model_id="Qwen/Qwen2-72B-Instruct",
                source="modelscope",
                size_gb=72.0, quantization="Q4_K_M",
                purpose=purpose, score=95.0,
                download_url="https://modelscope.cn/models/Qwen/Qwen2-72B-Instruct",
                description="通义千问2.0，72B参数，中文能力强"
            ),
            ModelRecommendation(
                model_id="THUDM/chatglm3-6b",
                source="modelscope",
                size_gb=12.0, quantization="Q4_K_M",
                purpose=purpose, score=90.0,
                download_url="https://modelscope.cn/models/THUDM/chatglm3-6b",
                description="ChatGLM3，6B参数，中英文均衡"
            ),
            ModelRecommendation(
                model_id="meta-llama/Llama-2-70b-chat-hf",
                source="huggingface",
                size_gb=70.0, quantization="Q4_K_M",
                purpose=purpose, score=92.0,
                download_url="https://huggingface.co/meta-llama/Llama-2-70b-chat-hf",
                description="Llama 2，70B参数，英文能力强"
            ),
        ]

    def _get_medium_models(self, purpose: str) -> List[ModelRecommendation]:
        """获取中等模型推荐（显存16-24GB）。"""
        return [
            ModelRecommendation(
                model_id="Qwen/Qwen2-7B-Instruct",
                source="modelscope",
                size_gb=7.0, quantization="Q5_K_M",
                purpose=purpose, score=93.0,
                download_url="https://modelscope.cn/models/Qwen/Qwen2-7B-Instruct",
                description="通义千问2.0，7B参数，性能与速度平衡"
            ),
            ModelRecommendation(
                model_id="meta-llama/Llama-2-13b-chat-hf",
                source="huggingface",
                size_gb=13.0, quantization="Q4_K_M",
                purpose=purpose, score=88.0,
                download_url="https://huggingface.co/meta-llama/Llama-2-13b-chat-hf",
                description="Llama 2，13B参数"
            ),
        ]

    def _get_small_models(self, purpose: str) -> List[ModelRecommendation]:
        """获取小模型推荐（显存8-16GB）。"""
        return [
            ModelRecommendation(
                model_id="Qwen/Qwen2-1.5B-Instruct",
                source="modelscope",
                size_gb=1.5, quantization="Q4_K_M",
                purpose=purpose, score=85.0,
                download_url="https://modelscope.cn/models/Qwen/Qwen2-1.5B-Instruct",
                description="通义千问2.0，1.5B参数，速度快"
            ),
            ModelRecommendation(
                model_id="microsoft/Phi-3-mini-4k-instruct",
                source="huggingface",
                size_gb=2.3, quantization="Q4_K_M",
                purpose=purpose, score=82.0,
                download_url="https://huggingface.co/microsoft/Phi-3-mini-4k-instruct",
                description="Phi-3，3.8B参数，微软出品"
            ),
        ]

    def _get_tiny_models(self, purpose: str) -> List[ModelRecommendation]:
        """获取微型模型推荐（无GPU或显存<8GB）。"""
        return [
            ModelRecommendation(
                model_id="Qwen/Qwen2-0.5B-Instruct",
                source="modelscope",
                size_gb=0.5, quantization="Q4_0",
                purpose=purpose, score=75.0,
                download_url="https://modelscope.cn/models/Qwen/Qwen2-0.5B-Instruct",
                description="通义千问2.0，0.5B参数，CPU友好"
            ),
            ModelRecommendation(
                model_id="gpt2",
                source="huggingface",
                size_gb=0.35, quantization="Q4_0",
                purpose=purpose, score=60.0,
                download_url="https://huggingface.co/openai-community/gpt2",
                description="GPT-2，经典小模型"
            ),
        ]


if __name__ == "__main__":
    config = {
        'cpu_cores': 8,
        'memory_gb': 32.0,
        'gpu_memory_gb': 24.0,
        'os_name': 'Windows'
    }
    recommender = ModelRecommender(config)
    recs = recommender.recommend(purpose="general", limit=5)
    print("=== 模型推荐 ===")
    for i, rec in enumerate(recs, 1):
        print(f"{i}. {rec.model_id}")
        print(f"   来源: {rec.source}")
        print(f"   大小: {rec.size_gb}GB ({rec.quantization})")
        print(f"   用途: {rec.purpose}")
        print(f"   评分: {rec.score}")
        print(f"   描述: {rec.description}")
        print()
