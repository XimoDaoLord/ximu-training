# -*- coding: utf-8 -*-
"""全局状态向量系统。"""
from __future__ import annotations

import json
import logging
import math
import re
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence

logger = logging.getLogger("src.ximu.core.global_state_vector")

COLLECTION_OBL: str = "obl_vectors"
COLLECTION_GLOBAL: str = "global_state_vectors"

_obl_dim_cache: Optional[int] = None


def _get_obl_dim() -> int:
    """获取 OBL 向量维度。"""
    global _obl_dim_cache
    if _obl_dim_cache is not None:
        return _obl_dim_cache
    try:
        from src.ximu.core.model_config import get_model_config
        _obl_dim_cache = int(get_model_config().get_dim("embedding"))
    except Exception as e:
        logger.debug("[gsv] ModelConfig 维度读取失败，使用兜底: %s", e)
        _obl_dim_cache = 1024
    return _obl_dim_cache


def __getattr__(name: str):
    if name == "OBL_DIM":
        return _get_obl_dim()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


_STATE_OK = "SUCCESS"
_STATE_FAIL = "FAIL"
_STATE_PARTIAL = "PARTIAL"

_LOCK = threading.RLock()

_TOPIC_MEMBERS: Dict[str, List[Dict[str, Any]]] = {}
_TOPIC_GLOBAL: Dict[str, Dict[str, Any]] = {}
_vs_singleton: Any = None


def new_obl_id() -> str:
    """生成 OBL ID。"""
    return f"tsk_{uuid.uuid4().hex[:12]}"


def new_vector_id() -> str:
    """生成向量 ID。"""
    return f"v_{_get_obl_dim()}_{uuid.uuid4().hex[:12]}"


def new_global_vector_id() -> str:
    """生成全局向量 ID。"""
    return f"v_{_get_obl_dim()}_global_{uuid.uuid4().hex[:10]}"


def _resolve_persist_dir() -> Path:
    """获取向量持久化目录。"""
    root = Path(__file__).resolve().parents[3]
    return root / "data" / "vectors" / "global_state"


def _get_vector_store() -> Optional[Any]:
    """获取向量库单例。"""
    global _vs_singleton
    with _LOCK:
        if _vs_singleton is not None:
            return _vs_singleton
        try:
            from src.ximu.core.vector_store import VectorStore
            vs = VectorStore(str(_resolve_persist_dir()))
            dim = _get_obl_dim()
            vs.create_collection(COLLECTION_OBL, dim=dim)
            vs.create_collection(COLLECTION_GLOBAL, dim=dim)
            _vs_singleton = vs
            logger.info("[gsv] 向量库就绪: %s", _resolve_persist_dir())
            return _vs_singleton
        except Exception as e:
            logger.warning("[gsv] 向量库初始化失败（降级为仅内存）: %s", e)
            _vs_singleton = None
            return None


_JUNK_LINE = re.compile(
    r"^\s*(你好|您好|谢谢|感谢|辛苦了|好的|好的，|我会|以下是|这是我|希望这|请查收|"
    r"总之|综上所述|首先，?|其次，?|最后，?|当然，?|其实，?|基本上|我觉得|我认为|"
    r"as an ai|here is|i have|please|thank you|sure[,!]?|of course|in conclusion|"
    r"first of all|let me|the answer is|如下|希望对你|祝你)\b",
    re.IGNORECASE,
)


def compress_to_chinese_essence(
    text: str, src_lang: str = "zh", model_refiner: Optional[Callable[[str, str], str]] = None
) -> str:
    """将子任务原始输出精炼成中文精华。"""
    raw = (text or "").strip()
    if not raw:
        return ""
    if model_refiner is not None:
        try:
            refined = model_refiner(raw, src_lang)
            if refined and str(refined).strip():
                return str(refined).strip()
        except Exception as e:
            logger.debug("[gsv] model_refiner 失败，降级算法: %s", e)
    kept: List[str] = []
    seen = set()
    for line in raw.splitlines():
        s = line.strip()
        if not s:
            continue
        if _JUNK_LINE.match(s) and len(s) < 40:
            continue
        fp = s[:64]
        if fp in seen:
            continue
        seen.add(fp)
        kept.append(s)
    essence = "\n".join(kept).strip()
    if len(essence) > 1200:
        essence = essence[:800] + "\n…\n" + essence[-300:]
    return essence or raw[:500]


def build_obl_payload(
    obl_id: str, src_lang: str = "zh", state: str = _STATE_OK, conf: float = 1.0,
    payload: Optional[Dict[str, Any]] = None, vector_id: Optional[str] = None
) -> Dict[str, Any]:
    """组装标准 OBL 协议包。"""
    if state not in (_STATE_OK, _STATE_FAIL, _STATE_PARTIAL):
        state = _STATE_OK
    try:
        conf = float(conf)
    except Exception:
        conf = 1.0
    conf = max(0.0, min(1.0, conf))
    return {
        "OBL_ID": obl_id, "SRC_LANG": (src_lang or "zh").strip()[:8], "STATE": state,
        "CONF": round(conf, 4), "PAYLOAD": dict(payload or {}), "VECTOR_ID": vector_id,
    }


def _embed_essence(essence: str) -> Optional[List[float]]:
    """用本地嵌入模型把中文精华压成向量。"""
    if not essence:
        return None
    try:
        from src.ximu.core.local_bge_embedder import embed_text_local
        vec = embed_text_local(essence)
        if vec is None:
            return None
        dim = _get_obl_dim()
        if len(vec) < dim:
            vec = vec + [0.0] * (dim - len(vec))
        else:
            vec = vec[:dim]
        norm = math.sqrt(sum(v * v for v in vec))
        if norm == 0:
            return None
        return [v / norm for v in vec]
    except Exception as e:
        logger.warning("[gsv] 嵌入失败: %s", e)
        return None
    