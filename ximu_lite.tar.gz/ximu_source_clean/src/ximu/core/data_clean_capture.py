"""自动保存用例干净数据器 (Clean Data Capture)。

项目跑任务时，自动捕获任务输入/输出/中间结果，经过提纯过滤后自动保存为
JSONL 干净数据，供后续训练/评测/记忆沉淀使用。设计上松耦合、可扩展：
通过依赖注入联上中转系统/三级记忆/错误学习/反思/缓存系统，任一系统缺失
时自动降级为本地文件写入，不影响主任务执行。

典型用法:
    capture = CleanDataCapture()
    capture.capture(task_id="t1", task_type="chat",
                     input_data="怎么学Python", output="建议...",
                     intermediate_results={"step": "retrieval"})
    capture.close()
"""
from __future__ import annotations

import ast
import hashlib
import json
import logging
import os
import queue
import re
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class CleanRecord:
    """一条干净数据记录，序列化为 JSONL 一行。"""

    task_id: str
    task_type: str
    input: Any
    output: Any
    intermediate_results: Any = None
    quality_score: float = 0.0
    timestamp: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# 硬编码密钥/令牌的兜底正则（字段名 + 可疑值形态）
_SECRET_PATTERNS = [
    re.compile(r"(?i)(api[_-]?key|secret|password|passwd|token|access[_-]?key)\s*[=:]\s*['\"][^'\"]{6,}['\"]"),
    re.compile(r"(?i)sk-[A-Za-z0-9]{16,}"),
    re.compile(r"(?i)AKIA[0-9A-Z]{16}"),
]

# 纯标点/空白垃圾字符
_PUNCT_RE = re.compile(r"^[\s\W_]+$", re.UNICODE)


class DataPurifier:
    """提纯过滤器：技术兜底，不做死板规则。

    只做"明显该拦"的检查（空、过短、纯标点、乱码、硬编码密钥、JSON 结构、
    Python 语法），质量评分交给模型自己决定，不设硬性阈值。
    """

    def __init__(self, min_length: int = 10) -> None:
        self.min_length = min_length

    @staticmethod
    def dedup_key(input_data: Any, output: Any) -> str:
        """相同输入/输出的重复数据只保留一条。"""
        blob = json.dumps([input_data, output], ensure_ascii=False, sort_keys=True, default=str)
        return hashlib.sha256(blob.encode("utf-8")).hexdigest()

    def is_junk(self, text: str) -> bool:
        """空内容/纯标点/过短 视为垃圾。"""
        if text is None:
            return True
        s = str(text).strip()
        if len(s) < self.min_length:
            return True
        if _PUNCT_RE.match(s):
            return True
        return False

    def has_secret_leak(self, text: str) -> bool:
        """过滤含硬编码密钥/密码/token 的数据。"""
        if not text:
            return False
        return any(p.search(str(text)) for p in _SECRET_PATTERNS)

    @staticmethod
    def valid_jsonable(obj: Any) -> bool:
        """确保数据结构完整可 JSON 序列化。"""
        try:
            json.dumps(obj, ensure_ascii=False, default=str)
            return True
        except (TypeError, ValueError):
            return False

    @staticmethod
    def valid_python_snippet(code: str) -> bool:
        """对疑似 Python 代码片段做基本语法检查。"""
        if not code or not isinstance(code, str):
            return True
        try:
            ast.parse(code)
            return True
        except (SyntaxError, ValueError):
            return False


class CleanDataCapture:
    """自动保存用例干净数据器。

    任务完成后自动捕获、提纯、落盘 JSONL；异步后台写入不阻塞主任务。
    通过可选注入联上各系统，任一缺失自动降级。
    """

    def __init__(
        self,
        storage_dir: str = "data/用户数据/干净数据/",
        transit_hub: Any = None,
        memory_tier: Any = None,
        error_storage: Any = None,
        feedback_collector: Any = None,
        smart_cache: Any = None,
        purifier: Optional[DataPurifier] = None,
        data_classifier: Any = None,
    ) -> None:
        self.storage_dir = storage_dir
        self.transit_hub = transit_hub          # 中转系统：捕获任务流转
        self.memory_tier = memory_tier          # 三级记忆：写高质量数据
        self.error_storage = error_storage      # 错误学习：错误案例
        self.feedback_collector = feedback_collector  # 反思/反馈
        self.smart_cache = smart_cache          # 缓存：避免重复写入
        self.data_classifier = data_classifier  # 数据分类器：分类+向量化+写训练数据
        self.purifier = purifier or DataPurifier()

        os.makedirs(self.storage_dir, exist_ok=True)
        self._queue: "queue.Queue[Optional[Dict[str, Any]]]" = queue.Queue(maxsize=10000)
        self._seen: set[str] = set()            # 内存去重
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._worker = threading.Thread(target=self._worker_loop, daemon=True,
                                        name="clean-data-capture")
        self._worker.start()
        logger.info("CleanDataCapture 启动, 存储目录=%s", self.storage_dir)

    def capture(
        self,
        task_id: str,
        task_type: str,
        input_data: Any,
        output: Any,
        intermediate_results: Any = None,
        quality_score: float = 0.0,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """任务完成后调用：捕获并异步保存一条干净数据。非阻塞。

        返回 True 表示已受理入队（或被去重/过滤跳过），False 表示提交失败。
        """
        try:
            inp_text = input_data if isinstance(input_data, str) else json.dumps(input_data, ensure_ascii=False, default=str)
            out_text = output if isinstance(output, str) else json.dumps(output, ensure_ascii=False, default=str)

            if self.purifier.is_junk(inp_text) or self.purifier.is_junk(out_text):
                logger.debug("跳过垃圾数据 task=%s", task_id)
                return False
            if self.purifier.has_secret_leak(inp_text) or self.purifier.has_secret_leak(out_text):
                logger.warning("拦截疑似密钥泄漏 task=%s", task_id)
                return False
            if not self.purifier.valid_jsonable({"i": input_data, "o": output}):
                return False
            if isinstance(output, str) and "def " in output or isinstance(output, str) and "import " in output:
                if not self.purifier.valid_python_snippet(out_text):
                    logger.warning("Python 语法检查失败 task=%s", task_id)
                    return False

            key = self.purifier.dedup_key(input_data, output)
            if self._is_dup(key):
                logger.debug("跳过重复数据 task=%s", task_id)
                return False

            record = CleanRecord(
                task_id=task_id, task_type=task_type, input=input_data,
                output=output, intermediate_results=intermediate_results,
                quality_score=float(quality_score),
                timestamp=datetime.now().isoformat(),
                metadata=metadata or {},
            )
            self._queue.put_nowait({"record": record.to_dict(), "dedup_key": key})
            return True
        except queue.Full:
            logger.error("干净数据队列已满, task=%s 丢弃", task_id)
            return False
        except Exception as e:  # 兜底：绝不影响主任务
            logger.exception("capture 异常: %s", e)
            return False

    def _is_dup(self, key: str) -> bool:
        """先查缓存系统，再查内存集合，避免重复写入。"""
        if self.smart_cache is not None:
            try:
                if self.smart_cache.get(key, namespace="clean_data_dedup") is not None:
                    return True
            except Exception:
                pass  # 缓存故障不阻塞，降级内存判断
        with self._lock:
            if key in self._seen:
                return True
            self._seen.add(key)
        return False

    def _worker_loop(self) -> None:
        """后台线程：从队列取记录，落盘并联动各系统。"""
        while not self._stop.is_set():
            try:
                item = self._queue.get(timeout=0.5)
            except queue.Empty:
                continue
            if item is None:  # 退出信号
                self._queue.task_done()
                break
            try:
                self._flush_record(item["record"])
                self._classify_and_export(item["record"])
                self._link_systems(item["record"])
                self._mark_cached(item["dedup_key"])
            except Exception as e:
                logger.exception("写入干净数据失败: %s", e)
            finally:
                self._queue.task_done()

    def _flush_record(self, record: Dict[str, Any]) -> None:
        """按日期分文件追加写一行 JSONL。"""
        day = datetime.now().strftime("%Y%m%d")
        path = os.path.join(self.storage_dir, f"clean_{day}.jsonl")
        line = json.dumps(record, ensure_ascii=False)
        with open(path, "a", encoding="utf-8") as f:
            f.write(line + "\n")
        logger.debug("干净数据已写入 %s", path)

    def _classify_and_export(self, record: Dict[str, Any]) -> None:
        """调用数据分类器分类，并把可训练数据写入训练文件。"""
        if self.data_classifier is None:
            return
        try:
            text = f"输入：{record.get('input', '')}\n输出：{record.get('output', '')}"
            clf_record = {
                "id": record.get("task_id", ""),
                "text": text,
                "quality_score": record.get("quality_score", 0.8) / 100.0,
                "task_type": record.get("task_type", "other_general"),
                "review_status": "approved",
            }
            result = self.data_classifier.classify(clf_record)
            if result.trainable:
                path = self.data_classifier.export_record_to_training(result, text)
                logger.debug("已写入训练数据: %s", path)
        except Exception as e:
            logger.warning("数据分类联动失败: %s", e)

    def _link_systems(self, record: Dict[str, Any]) -> None:
        """联动：三级记忆(高质量)/错误学习(错误案例)/反思(改进建议)。"""
        # 高质量数据 -> 长期记忆
        if self.memory_tier is not None and record.get("quality_score", 0) >= 80:
            try:
                self.memory_tier.store(
                    key=f"clean_{record['task_id']}",
                    content=record,
                    tags=["clean_data", record.get("task_type", "unknown")],
                )
            except Exception:
                pass
        # 错误案例/修复方案 -> 错误学习系统
        if self.error_storage is not None and record.get("task_type") == "error_fix":
            try:
                from src.ximu.core.learning.error_learning import ErrorRecord
                err_record = ErrorRecord(
                    error_message=str(record.get("output", "")),
                    error_category="runtime",
                    features={
                        "task_id": record.get("task_id"),
                        "task_type": record.get("task_type"),
                    },
                )
                self.error_storage.save_error(err_record)
            except Exception:
                pass
        # 反思结果/改进建议 -> 反思引擎
        if self.feedback_collector is not None and record.get("task_type") == "reflection":
            try:
                self.feedback_collector.reflect(
                    task_description=str(record.get("input", "")),
                    conclusion=str(record.get("output", "")),
                )
            except Exception:
                pass

    def _mark_cached(self, key: str) -> None:
        """把 dedup_key 写回缓存系统，避免下次重复处理。"""
        if self.smart_cache is None:
            return
        try:
            self.smart_cache.put(key, True, namespace="clean_data_dedup", ttl=3600)
        except Exception:
            pass

    def close(self, wait: bool = True, timeout: float = 10.0) -> None:
        """停止后台线程并 flush 剩余队列。"""
        if self._stop.is_set():
            return
        # 顺序很关键：先让存活的 worker 把队列排空(join)，再通知停止，
        # 否则 worker 提前 break 会让残留任务永远无人 task_done 导致死锁。
        if wait:
            self._queue.join()
        self._stop.set()
        self._queue.put(None)  # 唤醒阻塞在 get 的 worker 退出
        self._worker.join(timeout=timeout)
        logger.info("CleanDataCapture 已关闭, 累计去重 %d 条", len(self._seen))

    def stats(self) -> Dict[str, Any]:
        """返回运行统计。"""
        return {
            "storage_dir": self.storage_dir,
            "queue_size": self._queue.qsize(),
            "dedup_count": len(self._seen),
            "running": not self._stop.is_set(),
        }

    def __enter__(self) -> "CleanDataCapture":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
