# -*- coding: utf-8 -*-
"""P54 多人格团队执行层（宿主层注入，红线文件零改动）。

职责：
  1. 把 dev_team 预设的 4 个角色（pm/developer/tester/reviewer）分配到拆解后的子任务；
  2. 每个子任务调 PersonalityTeam.assign_to_subtask 落盘绑定（消费配置层）；
  3. 按子任务名读取绑定，返回该子任务执行时应注入的人格 system_prompt 前缀与绑定模型；
  4. 交付前调 PersonalityTeam.review_collaboration 做真实 writer→reviewer 审查。

纯函数 + 真实文件 IO，宿主层(app.py)在子任务拆解后、执行前调用本模块。
"""
from __future__ import annotations

import os
import re
from typing import Any, Dict, List, Optional, Set


_ROLE_ANCHORS: Dict[str, str] = {
    "pm": "需求分析与梳理、项目规划、任务拆解与进度跟踪、验收标准制定、最终交付汇总与总装",
    "tester": "测试用例编写与验证、质量保证、回归测试、bug 复现与修复确认、测试覆盖",
    "reviewer": "代码审查与评审、设计审查、审核把关、挑错、交付前质量把关与风险审查",
    "developer": "编码实现、函数与类编写、接口设计与开发、数据库表设计、服务实现与部署、逻辑实现",
}

_ROLE_ORDER = ["pm", "developer", "tester", "reviewer"]

_ROLE_VEC_CACHE: Dict[str, Optional[List[float]]] = {}


def _bigrams(s: str) -> Set[str]:
    """生成字符 bigram 集合。"""
    s = (s or "").lower()
    return set(s[i:i + 2] for i in range(len(s) - 1)) if len(s) > 1 else set()


_ROLE_BIGRAM_CACHE: Dict[str, Set[str]] = {
    role: _bigrams(anchor) for role, anchor in _ROLE_ANCHORS.items()
}

_CLASSIFY_CACHE: Dict[str, str] = {}
_CLASSIFY_CACHE_MAX = 1024


def _get_role_vecs() -> Dict[str, Optional[List[float]]]:
    """计算并缓存四个角色锚点的 embedding 向量。不可用时返回空。"""
    if _ROLE_VEC_CACHE:
        return _ROLE_VEC_CACHE
    try:
        from src.ximu.core.local_bge_embedder import (
            is_local_embedding_available, embed_text_local)
        if not is_local_embedding_available():
            return _ROLE_VEC_CACHE
        for role, text in _ROLE_ANCHORS.items():
            _ROLE_VEC_CACHE[role] = embed_text_local(text, as_query=False)
    except Exception:
        pass
    return _ROLE_VEC_CACHE


def classify_role(name: str, description: str = "") -> str:
    """按子任务名+描述与四角色语义锚点的 embedding 余弦相似度分类。"""
    text = f"{name} {description}".strip()
    if not text:
        return "developer"

    ck = f"{name}|{description}"
    hit = _CLASSIFY_CACHE.get(ck)
    if hit is not None:
        return hit

    result = None
    try:
        from src.ximu.core.local_bge_embedder import (
            is_local_embedding_available, embed_text_local)
        if is_local_embedding_available():
            qvec = embed_text_local(text, as_query=True)
            if qvec:
                role_vecs = _get_role_vecs()
                best_role = "developer"
                best_sim = -1.0
                for role in _ROLE_ORDER:
                    rvec = role_vecs.get(role)
                    if not rvec:
                        continue
                    sim = sum(a * b for a, b in zip(qvec, rvec))
                    if sim > best_sim:
                        best_sim = sim
                        best_role = role
                result = best_role
    except Exception:
        result = None

    if result is None:
        qset = _bigrams(text)
        if not qset:
            result = "developer"
        else:
            best_role = "developer"
            best_sim = 0.0
            for role in _ROLE_ORDER:
                rset = _ROLE_BIGRAM_CACHE.get(role) or set()
                if not rset:
                    continue
                inter = len(qset & rset)
                union = len(qset | rset)
                sim = inter / union if union else 0.0
                if sim > best_sim:
                    best_sim = sim
                    best_role = role
            result = best_role

    if len(_CLASSIFY_CACHE) < _CLASSIFY_CACHE_MAX:
        _CLASSIFY_CACHE[ck] = result
    return result


def _safe_key(name: str) -> str:
    """子任务名 → assignment 文件名安全 key。"""
    k = re.sub(r"[\\/\s]+", "_", (name or "").strip())
    return k[:80] or "subtask"


def assign_roles_to_subtasks(subtasks: List[Dict[str, Any]],
                             team_preset: str = "dev_team") -> Dict[str, Dict[str, Any]]:
    """把团队角色分配到子任务，并落盘 assign_to_subtask 绑定。"""
    from src.ximu.core.personality_team import get_personality_team
    team = get_personality_team()

    result: Dict[str, Dict[str, Any]] = {}
    n = len(subtasks)
    for i, st in enumerate(subtasks):
        name = str(st.get("name") or f"子任务_{i+1}")
        desc = str(st.get("description") or "")
        role = classify_role(name, desc)
        result[name] = {"role": role, "personality_id": role}

    if not any(v["role"] == "reviewer" for v in result.values()):
        all_names = [str(st.get("name") or f"子任务_{i+1}")
                     for i, st in enumerate(subtasks)]
        review_name = "最终代码审查与质量把关"
        subtasks.append({
            "name": review_name,
            "description": "对全部开发与测试产出做交付前代码审查、设计审查与质量把关，"
                           "列出问题并给出可交付结论",
            "depends_on": all_names,
            "skill_domain": "审查",
            "priority": "high",
        })
        result[review_name] = {"role": "reviewer", "personality_id": "reviewer"}

    if not any(v["role"] == "tester" for v in result.values()):
        for i, st in enumerate(subtasks):
            nm = str(st.get("name") or "")
            if any(k in nm for k in ("测试", "用例", "验证", "验收")):
                result[nm]["role"] = "tester"
                result[nm]["personality_id"] = "tester"
                break

    for name, info in result.items():
        pid = info["personality_id"]
        try:
            team.assign_to_subtask(_safe_key(name), pid, model=None)
        except Exception:
            pass
        pers = team.get_personality(pid) or {}
        info["model"] = pers.get("model_hint", "auto")
        info["system_prompt"] = pers.get("system_prompt", "")
    return result


def build_injection(personality_id: str) -> Dict[str, Any]:
    """按 personality_id 构建执行注入：system_prompt 前缀 + 绑定模型。"""
    from src.ximu.core.personality_team import get_personality_team
    team = get_personality_team()
    pers = team.get_personality(personality_id) or {}
    return {
        "personality_id": personality_id,
        "personality_name": pers.get("name", personality_id),
        "system_prompt": pers.get("system_prompt", ""),
        "model": pers.get("model_hint", "auto"),
    }


def injection_for_subtask(subtask_name: str,
                          mapping: Dict[str, Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """查子任务名对应的注入。无绑定返回 None。"""
    info = mapping.get(subtask_name)
    if not info:
        return None
    return {
        "personality_id": info.get("personality_id"),
        "personality_name": info.get("role"),
        "role": info.get("role"),
        "system_prompt": info.get("system_prompt", ""),
        "model": info.get("model", "auto"),
    }


def make_inject_prefix(inj: Dict[str, Any]) -> str:
    """把人格 system_prompt 包装成 prompt 前缀。"""
    sp = (inj or {}).get("system_prompt") or ""
    if not sp.strip():
        return ""
    return f"【角色设定】{sp.strip()}\n\n"
