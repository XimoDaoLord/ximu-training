# -*- coding: utf-8 -*-
"""角色卡 ↔ 模板绑定与注入组合模块（多人格调度核心）。

职责：
  1. 从 resources/ecosystem/prompt_descriptions/<name>/manifest.json 读取模板内容；
  2. 把角色卡（personality/scenario/...）与绑定模板组合成完整 system prompt；
  3. 关键词冲突检测：角色卡与模板指令矛盾时报警（如角色卡"不说中文" vs 模板"用中文回答"）；
  4. 团队预设（项目经理/程序员/测试）可保存为团队模板；
  5. 角色卡/模板均不写死模型（model_preference 仅为路由偏好，可空）。

所有函数均为纯函数/无副作用 IO，可在任何线程安全调用。
"""
from __future__ import annotations

import json
import os
import re
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

# ============================================================
# 路径
# ============================================================
_HERE = os.path.dirname(os.path.abspath(__file__))
# src/ximu/core/personality_team/binding.py -> 项目根上溯4层
_PROJECT_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", "..", ".."))
_TEMPLATE_DIR = os.path.join(_PROJECT_ROOT, "resources", "ecosystem",
                              "prompt_descriptions")
# 数据根统一：团队配置归位 用户数据/人格与角色卡/团队配置/
try:
    from src.ximu.core.data_root import personality_team_dir
    _DATA_DIR = personality_team_dir()
except Exception:
    _DATA_DIR = os.path.join(_PROJECT_ROOT, "data", "personality_team")
os.makedirs(_DATA_DIR, exist_ok=True)
_TEAM_PRESETS_FILE = os.path.join(_DATA_DIR, "team_presets.json")


# ============================================================
# 模板读取（真实文件 IO，非 mock）
# ============================================================
# P-OPT9: mtime-based 缓存。list_templates/get_template 是高频调用，
# 每次都 open+json.load 所有 manifest.json 是主要磁盘瓶颈。
# 模板目录结构稳定（仅在安装/卸载模板时变化），按目录 mtime + 各 manifest mtime 缓存。
_tpl_cache: Dict[str, Any] = {
    "dir_mtime": 0.0,
    "list": None,
    "by_id": {},   # template_id -> (mtime, dict|None)
}


def _dir_mtime() -> float:
    """获取模板目录的 mtime。"""
    try:
        return os.stat(_TEMPLATE_DIR).st_mtime
    except OSError:
        return 0.0


def list_templates() -> List[Dict[str, Any]]:
    """列出本地所有已安装模板（读取 manifest.json）。带 mtime 缓存。"""
    if not os.path.isdir(_TEMPLATE_DIR):
        return []
    dm = _dir_mtime()
    if _tpl_cache["list"] is not None and _tpl_cache["dir_mtime"] == dm:
        return list(_tpl_cache["list"])

    out: List[Dict[str, Any]] = []
    for name in sorted(os.listdir(_TEMPLATE_DIR)):
        man = os.path.join(_TEMPLATE_DIR, name, "manifest.json")
        if not os.path.isfile(man):
            continue
        try:
            with open(man, "r", encoding="utf-8") as f:
                meta = json.load(f)
        except Exception:
            continue
        out.append({
            "id": meta.get("name") or name,
            "name": meta.get("name") or name,
            "description": meta.get("description", ""),
            "category": meta.get("category", ""),
            "content": meta.get("content", ""),
            "compatible_personalities": meta.get("compatible_personalities")
                or meta.get("bound_character_cards") or [],
            "enabled": bool(meta.get("enabled", True)),
            "source": meta.get("source", "builtin"),
        })
    _tpl_cache["list"] = out
    _tpl_cache["dir_mtime"] = dm
    return list(out)


def get_template(template_id: str) -> Optional[Dict[str, Any]]:
    """按 ID 读取单个模板（含 content 全文）。带 mtime 缓存。"""
    if not template_id:
        return None
    man = os.path.join(_TEMPLATE_DIR, template_id, "manifest.json")
    hit = _tpl_cache["by_id"].get(template_id)
    if hit is not None:
        cached_mt, cached_result = hit
        if cached_result is not None:
            try:
                mt = os.stat(man).st_mtime
            except OSError:
                mt = 0.0
            if mt == cached_mt:
                return cached_result
        else:
            dm = _dir_mtime()
            if dm == cached_mt:
                return None
            if not os.path.isfile(man):
                _tpl_cache["by_id"][template_id] = (dm, None)
                return None
    else:
        if not os.path.isfile(man):
            _tpl_cache["by_id"][template_id] = (_dir_mtime(), None)
            return None
    try:
        mt = os.stat(man).st_mtime
    except OSError:
        mt = 0.0
    try:
        with open(man, "r", encoding="utf-8") as f:
            meta = json.load(f)
    except Exception:
        _tpl_cache["by_id"][template_id] = (mt, None)
        return None
    result = {
        "id": meta.get("name") or template_id,
        "name": meta.get("name") or template_id,
        "description": meta.get("description", ""),
        "content": meta.get("content", ""),
        "compatible_personalities": meta.get("compatible_personalities")
            or meta.get("bound_character_cards") or [],
    }
    _tpl_cache["by_id"][template_id] = (mt, result)
    return result


def save_template_compatible(template_id: str,
                              compatible: List[str]) -> bool:
    """把 compatible_personalities 写回模板 manifest（真实落盘）。"""
    man = os.path.join(_TEMPLATE_DIR, template_id, "manifest.json")
    if not os.path.isfile(man):
        return False
    try:
        with open(man, "r", encoding="utf-8") as f:
            meta = json.load(f)
    except Exception:
        return False
    meta["compatible_personalities"] = list(compatible or [])
    meta["updated_at"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    tmp = man + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    os.replace(tmp, man)
    return True


# ============================================================
# 冲突检测（关键词对撞）
# ============================================================
_CONFLICT_RULES: List[Tuple[List[str], List[str], str]] = [
    (["不说中文", "禁止中文", "不允许中文", "只说英文", "必须用英文", "必须说英文",
      "只用英文", "只能用英文", "用英文回答", "用英文回复", "说英文",
      "speak only english", "no chinese", "in english", "respond in english"],
     ["用中文", "说中文", "中文回答", "中文回复", "必须用中文", "必须说中文",
      "只用中文", "只能用中文", "in chinese", "respond in chinese"],
     "语言策略冲突：角色卡要求用英文/不用中文，但模板要求用中文回答"),
    (["只说中文", "必须中文", "必须用中文", "必须说中文", "只用中文", "只能用中文",
      "用中文回答", "用中文回复", "说中文", "中文回答", "中文回复",
      "no english", "不说英文", "禁止英文", "不允许英文"],
     ["英文回答", "英文回复", "用英文", "必须用英文", "必须说英文",
      "只用英文", "只能用英文", "in english", "respond in english", "no chinese"],
     "语言策略冲突：角色卡要求只用中文/不用英文，但模板要求用英文回答"),
    (["严肃", "严谨", "专业", "正式", "不幽默"],
     ["幽默", "搞笑", "轻松", "活泼", "吐槽", "玩梗"],
     "风格冲突：角色卡要求严肃专业，但模板要求幽默轻松"),
    (["幽默", "搞笑", "活泼", "玩梗"],
     ["严肃", "严谨", "正式", "专业", "不幽默"],
     "风格冲突：角色卡要求幽默，但模板要求严肃正式"),
    (["你是助手", "作为AI", "我是AI", "人工智能"],
     ["你是人类", "你是用户", "扮演人类", "你是人"],
     "身份冲突：角色卡自我定位为AI，但模板要求扮演人类"),
    (["你是人类", "扮演人类", "你是人"],
     ["你是AI", "作为AI", "人工智能助手", "你是助手"],
     "身份冲突：角色卡要求扮演人类，但模板定位为AI助手"),
]

_CONFLICT_RULES_LOWER: List[Tuple[List[str], List[str], str]] = [
    ([k.lower() for k in left], [k.lower() for k in right], msg)
    for left, right, msg in _CONFLICT_RULES
]


def detect_conflicts(card: Dict[str, Any],
                     template: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """检测角色卡与绑定模板之间的关键词冲突。"""
    if not card or not template:
        return []
    card_text = str(card.get("content") or card.get("instructions") or "").lower()
    template_text = str(template.get("content") or template.get("instructions") or "").lower()
    
    conflicts: List[Dict[str, Any]] = []
    for left_kws, right_kws, desc in _CONFLICT_RULES_LOWER:
        card_hit = any(kw in card_text for kw in left_kws)
        tpl_hit = any(kw in template_text for kw in right_kws)
        if card_hit and tpl_hit:
            conflicts.append({"type": "keyword", "description": desc})
            
    return conflicts
