"""
汐沫AI 人格团队协作系统
- 多人格独立记忆（scope 隔离，不互相污染）
- 人格绑定子任务，不同子任务挂不同人格
- 人格间消息走中转池
- 不同人格路由不同模型
"""
import json
import os
import shutil
import time
import uuid
from typing import Dict, List, Optional

# P137：数据目录归位 data_root（与 binding.py 同一权威目录 personality_team_dir()），
# 不再硬编码 ~/.ximu/personality_team。隔离 XIMU_DATA_ROOT 时，自定义人格/绑定
# 全部落到数据根下；同时对旧 ~/.ximu 存量做一次性迁移（不覆盖、不删除旧目录）。
_OLD_DATA_DIR = os.path.expanduser("~/.ximu/personality_team")
try:
    from src.ximu.core.data_root import personality_team_dir as _pt_dir
    _DATA_DIR = _pt_dir()
except Exception:
    _HERE = os.path.dirname(os.path.abspath(__file__))
    _PROJECT_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", "..", ".."))
    _DATA_DIR = os.path.join(_PROJECT_ROOT, "data", "personality_team")
os.makedirs(_DATA_DIR, exist_ok=True)


def _migrate_legacy_data() -> None:
    """一次性迁移旧 ~/.ximu/personality_team 存量到新数据根。

    迁移范围：custom_personalities.json 与 assignment_*.json。
    - 仅当新位置缺该文件时复制（不覆盖新位置已更新的数据）；
    - 不删除旧目录，保留存量以便回滚；
    - 幂等：进程内调用一次即可，重复运行不会反复覆盖。
    """
    try:
        if not os.path.isdir(_OLD_DATA_DIR):
            return
        if os.path.abspath(_OLD_DATA_DIR) == os.path.abspath(_DATA_DIR):
            return
        for name in os.listdir(_OLD_DATA_DIR):
            src = os.path.join(_OLD_DATA_DIR, name)
            if not os.path.isfile(src):
                continue
            if name == "custom_personalities.json" or name.startswith("assignment_"):
                dst = os.path.join(_DATA_DIR, name)
                if not os.path.exists(dst):
                    shutil.copy2(src, dst)
    except Exception:
        pass


_migrate_legacy_data()

# 默认人格（3个真实人格，不是摆设）
DEFAULT_PERSONALITIES = [
    {
        "id": "writer",
        "name": "汐沫·文案写手",
        "role": "writing",
        "description": "擅长写作、文案、润色，文笔流畅自然",
        "model_hint": "auto",
        "scope": "character:writer",
        "system_prompt": "你是汐沫AI的文案写手人格，擅长写清晰流畅的中文文章、文案、邮件、报告。回答风格自然、有文采、结构清晰。",
    },
    {
        "id": "reviewer",
        "name": "汐沫·审查官",
        "role": "review",
        "description": "擅长审查、挑毛病、找问题，严谨细致",
        "model_hint": "auto",
        "scope": "character:reviewer",
        "system_prompt": "你是汐沫AI的审查官人格，擅长从严谨角度审查内容，找逻辑漏洞、事实错误、表达问题。回答直接指出问题，给出改进建议。",
    },
    {
        "id": "analyst",
        "name": "汐沫·分析师",
        "role": "analysis",
        "description": "擅长数据分析、逻辑推理、拆解问题",
        "model_hint": "auto",
        "scope": "character:analyst",
        "system_prompt": "你是汐沫AI的分析师人格，擅长数据分析、逻辑推理、问题拆解。回答条理清晰、有理有据、用数据说话。",
    },
    # ===== P54 多人格团队执行层：dev_team 四角色（pm/developer/tester/reviewer）=====
    # reviewer 已在上文内置；这里补齐 pm/developer/tester 三个内置人格。
    # model_hint 仅为路由偏好，单 API 模式下由网关自动降级到当前健康可用模型。
    {
        "id": "pm",
        "name": "汐沫·项目经理",
        "role": "pm",
        "description": "负责需求分析、任务拆解、进度跟踪、跨成员协调与最终汇总交付",
        "model_hint": "auto",
        "scope": "character:pm",
        "system_prompt": (
            "你是汐沫AI的项目经理(PM)人格。你的职责是：\n"
            "1. 把模糊需求梳理成清晰、可验收的目标，明确边界与优先级；\n"
            "2. 拆解任务、分配给对应角色、跟踪进度、识别阻塞与风险；\n"
            "3. 协调 developer(开发)/tester(测试)/reviewer(审查) 之间的工作，不直接写代码；\n"
            "4. 在所有成员完成后，汇总各方产出，形成结构清晰、可直接交付的最终方案。\n"
            "回答风格：有条理、抓重点、用列表/阶段标题组织；先给结论再给依据。"
        ),
    },
    {
        "id": "developer",
        "name": "汐沫·开发者",
        "role": "developer",
        "description": "负责代码实现、数据库设计、接口开发、错误处理",
        "model_hint": "auto",
        "scope": "character:developer",
        "system_prompt": (
            "你是汐沫AI的资深开发者人格。你的职责是：\n"
            "1. 根据需求与设计，写出真实、可运行、结构清晰的代码；\n"
            "2. 做数据库表结构设计、接口契约、异常与边界处理；\n"
            "3. 关注安全性（密码哈希/SQL 注入/输入校验）与可维护性；\n"
            "4. 产出包含必要代码片段与说明，不空谈。\n"
            "回答风格：技术准确、给可落地的代码与理由，避免伪代码占位。"
        ),
    },
    {
        "id": "tester",
        "name": "汐沫·测试工程师",
        "role": "tester",
        "description": "负责测试用例编写、测试执行、bug 报告、验收把关",
        "model_hint": "auto",
        "scope": "character:tester",
        "system_prompt": (
            "你是汐沫AI的测试工程师(QA)人格。你的职责是：\n"
            "1. 为被测功能设计覆盖正常路径与异常路径的测试用例；\n"
            "2. 明确前置条件、步骤、预期结果；\n"
            "3. 指出潜在 bug、边界缺失、校验不充分之处；\n"
            "4. 给出可执行的验收结论。\n"
            "回答风格：严谨、用例化、列点清晰，关注边界与容错。"
        ),
    },
]


class PersonalityTeam:
    """人格团队管理器（不限数量，用户可增删）"""

    def __init__(self):
        """初始化人格团队管理器。"""
        self.personalities: Dict[str, dict] = {}
        self._name_to_id: Dict[str, str] = {}  # P170: name -> id 索引
        self._subtask_cache: Dict[str, tuple] = {}  # subtask_id -> (mtime, personality|None)
        self._load_defaults()
        self._load_custom()
        self._rebuild_name_index()

    def _rebuild_name_index(self) -> None:
        """重建 name -> id 索引（id 直查优先；重名时先登记者保留）。"""
        self._name_to_id = {}
        for pid, p in self.personalities.items():
            nm = str(p.get("name") or "").strip()
            if nm and nm not in self._name_to_id:
                self._name_to_id[nm] = pid

    def _load_defaults(self) -> None:
        """加载默认人格。"""
        for p in DEFAULT_PERSONALITIES:
            self.personalities[p["id"]] = p

    def _load_custom(self) -> None:
        """从数据目录加载用户自定义人格"""
        custom_path = os.path.join(_DATA_DIR, "custom_personalities.json")
        if os.path.exists(custom_path):
            try:
                with open(custom_path, "r", encoding="utf-8") as f:
                    customs = json.load(f)
                for p in customs:
                    self.personalities[p["id"]] = p
            except Exception:
                pass

    def _save_custom(self) -> None:
        """保存用户自定义人格"""
        customs = [p for p in self.personalities.values() if p.get("custom")]
        custom_path = os.path.join(_DATA_DIR, "custom_personalities.json")
        with open(custom_path, "w", encoding="utf-8") as f:
            json.dump(customs, f, ensure_ascii=False, indent=2)

    def list_personalities(self) -> List[dict]:
        """列出所有可用人格"""
        return list(self.personalities.values())

    def get_personality(self, personality_id: str) -> Optional[dict]:
        """获取单个人格。支持 id 直查；id 未命中时按 name 索引回退查找（P170）。"""
        if not personality_id:
            return None
        p = self.personalities.get(personality_id)
        if p is not None:
            return p
        nid = self._name_to_id.get(str(personality_id).strip())
        if nid:
            return self.personalities.get(nid)
        return None

    def add_personality(self, name: str, description: str, system_prompt: str,
                        model_hint: str = "auto", personality_id: str = "") -> dict:
        """添加自定义人格（从模板市场选提示描述创建）"""
        if not personality_id:
            # P170：秒级时间戳同秒冲突，改用 uuid4 保证唯一
            personality_id = f"custom_{uuid.uuid4().hex[:12]}"
        if personality_id in self.personalities:
            return {"success": False, "error": f"人格 {personality_id} 已存在"}

        p = {
            "id": personality_id,
            "name": name,
            "role": "custom",
            "description": description,
            "model_hint": model_hint,
            "scope": f"character:{personality_id}",
            "system_prompt": system_prompt,
            "custom": True,
        }
        self.personalities[personality_id] = p
        # P170：登记 name -> id 索引（重名不覆盖已有 id 直查）
        nm = str(name or "").strip()
        if nm:
            self._name_to_id.setdefault(nm, personality_id)
        self._save_custom()

        return {"success": True, "personality": p}

    def remove_personality(self, personality_id: str) -> dict:
        """删除自定义人格（内置人格不可删）"""
        p = self.personalities.get(personality_id)
        if not p:
            return {"success": False, "error": f"人格 {personality_id} 不存在"}
        if not p.get("custom"):
            return {"success": False, "error": "内置人格不可删除"}

        del self.personalities[personality_id]
        # P170：清除 name -> id 索引中指向该 id 的条目
        for nm, nid in list(self._name_to_id.items()):
            if nid == personality_id:
                del self._name_to_id[nm]
        self._save_custom()
        return {"success": True, "removed": personality_id}
