"""端侧 VLM runner（配置驱动）。

提供多模态大模型的懒加载与推理入口。
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

class _VlmState:
    """VLM 模块全局状态容器。"""

    def __init__(self) -> None:
        """初始化状态为未就绪。"""
        self.ready: bool = False
        self.tried: bool = False
        self.llm: Optional[Any] = None
        self.error: Optional[str] = None

_state = _VlmState()

def is_local_vlm_available() -> bool:
    """模型文件是否齐全（不实际加载）。

    Returns:
        如果模型已加载则返回 True，否则返回 False。
    """
    return _state.ready

def load_vlm() -> Optional[Any]:
    """按需加载 VLM（懒加载单例）。

    Returns:
        加载成功的 Llama 实例，失败返回 None。
    """
    if _state.ready and _state.llm is not None:
        return _state.llm
    if _state.tried and _state.error:
        return None
    _state.tried = True
    # TODO: 实际加载 llama_cpp / ONNX VLM 模型
    _state.error = "vlm_unavailable"
    logger.warning("本地 VLM 不可用: %s", _state.error)
    _state.ready = False
    return None

def run_image_caption(image: Any, question: Optional[str] = None) -> Dict[str, Any]:
    """图像描述或 VQA。

    Args:
        image: 图像输入。
        question: 可选的问题（VQA 模式）。

    Returns:
        包含描述结果、置信度、延迟的字典。
    """
    llm = load_vlm()
    if llm is None:
        return {
            "success": False,
            "error": _state.error or "vlm_unavailable",
            "result": None,
            "confidence": 0.0,
            "latency_ms": 0.0,
        }

    start = time.perf_counter()
    try:
        # TODO: 调用 llm.generate(image, question) 获取真实结果
        caption: str = ""
        response: str = ""
        latency_ms: float = round((time.perf_counter() - start) * 1000, 1)
        return {
            "success": True,
            "result": {"caption": caption, "text": response},
            "confidence": 0.9,
            "latency_ms": latency_ms,
            "error": None,
        }
    except Exception as exc:
        latency_ms = round((time.perf_counter() - start) * 1000, 1)
        logger.error("VLM 推理失败: %s", exc, exc_info=True)
        return {
            "success": False,
            "error": str(exc),
            "result": None,
            "confidence": 0.0,
            "latency_ms": latency_ms,
        }
