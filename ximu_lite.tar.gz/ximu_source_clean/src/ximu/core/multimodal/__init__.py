# -*- coding: utf-8 -*-
"""多模态子系统入口。

该包提供多模态感知与融合的核心能力，包括：
- router: 多模态任务路由编排
- local_ocr / local_vlm: 本地推理引擎
- combo_plugin / text_perception / vision_perception / audio_perception: 感知模块
- fusion / multimodal_fusion: 多模态融合
- perception_memory: 感知记忆存储

通过 get_multimodal_router() 可获取默认路由器单例。
"""
from __future__ import annotations

from src.ximu.core.multimodal.router import (
    MultimodalRouter,
    SUPPORTED_TASK_TYPES,
    get_multimodal_router,
    register_local_runner,
)

__all__ = [
    "MultimodalRouter",
    "SUPPORTED_TASK_TYPES",
    "get_multimodal_router",
    "register_local_runner",
]
