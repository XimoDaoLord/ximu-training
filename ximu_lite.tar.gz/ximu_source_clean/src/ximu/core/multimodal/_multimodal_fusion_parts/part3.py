"""
模态融合器核心模块。

提供数据项管理、LRU 缓存、指标统计、配置同步及事件分发功能，
支持异步操作与线程安全。
"""

import asyncio
import json
import logging
import statistics
import threading
import time
from collections import OrderedDict
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from src.ximu.common.utils import generate_id
from src.ximu.core.multimodal._multimodal_fusion_parts.part1 import _setup_logger


# =============================================================================
# 缓存组件
# =============================================================================


@dataclass
class CacheEntry:
    """缓存条目，包含值、时间戳和 TTL（生存时间）。"""

    value: Any
    timestamp: float
    ttl: float = 300.0

    def is_expired(self) -> bool:
        """检查缓存条目是否过期。

        Returns:
            bool: 若当前单调时间减去时间戳大于等于 TTL，则返回 True。
        """
        return (time.monotonic() - self.timestamp) >= self.ttl


class LruCache:
    """线程安全的 LRU（最近最少使用）缓存。

    支持基于 TTL 的自动过期、容量限制及统计信息。
    """

    def __init__(self, max_size: int = 10_000) -> None:
        """初始化 LRU 缓存。

        Args:
            max_size: 缓存最大容量。
        """
        if max_size <= 0:
            raise ValueError("max_size must be positive")
        self._max_size: int = max_size
        self._cache: "OrderedDict[str, CacheEntry]" = OrderedDict()
        self._lock = threading.RLock()
        self._logger = _setup_logger(f"{LruCache.__module__}.{LruCache.__qualname__}")
        self._hits: int = 0
        self._misses: int = 0

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值。若不存在或已过期，返回 None 并更新命中/未命中计数。

        Args:
            key: 缓存键。

        Returns:
            Optional[Any]: 缓存值或 None。
        """
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                self._misses += 1
                return None

            if entry.is_expired():
                del self._cache[key]
                self._logger.debug("缓存项 '%s' 已过期并移除", key)
                self._misses += 1
                return None

            self._cache.move_to_end(key)
            self._hits += 1
            self._logger.debug("缓存命中 '%s'", key)
            return deepcopy(entry.value)

    def set(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """设置缓存值。若超出容量，移除最旧项。

        Args:
            key: 缓存键。
            value: 要缓存的值（将被深拷贝）。
            ttl: 生存时间（秒）。
        """
        if ttl <= 0:
            raise ValueError("ttl must be positive")
        with self._lock:
            entry = CacheEntry(value=deepcopy(value), timestamp=time.monotonic(), ttl=ttl)
            self._cache[key] = entry
            self._cache.move_to_end(key)

            while len(self._cache) > self._max_size:
                oldest_key, _ = self._cache.popitem(last=False)
                self._logger.debug("缓存已满，移除最旧项 '%s'", oldest_key)

    def invalidate(self, key: str) -> bool:
        """失效指定缓存项。

        Args:
            key: 缓存键。

        Returns:
            bool: 若该项存在并已被删除，返回 True。
        """
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                self._logger.debug("缓存项 '%s' 已失效", key)
                return True
            return False

    def clear(self) -> int:
        """清空所有缓存项。

        Returns:
            int: 被清除的缓存项数量。
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
            self._logger.debug("缓存已清空，共 %d 项", count)
            return count

    def size(self) -> int:
        """获取当前缓存项数量。

        Returns:
            int: 缓存大小。
        """
        with self._lock:
            return len(self._cache)

    def stats(self) -> Dict[str, Any]:
        """获取缓存统计信息。

        Returns:
            dict: 包含大小、容量、命中/未命中计数及命中率。
        """
        with self._lock:
            total = self._hits + self._misses
            hit_rate = (self._hits / total) if total > 0 else 0.0
            return {
                "size": len(self._cache),
                "max_size": self._max_size,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": round(hit_rate, 4),
            }


# =============================================================================
# 指标统计组件
# =============================================================================


@dataclass
class MetricsData:
    """单个指标数据点。"""

    value: float
    timestamp: float
    labels: Dict[str, Any] = field(default_factory=dict)


class MetricsManager:
    """线程安全的指标统计管理器。

    支持带标签的指标记录、流式统计（均值、分位数）及历史查询。
    """

    def __init__(self, max_history: int = 10_000) -> None:
        """初始化指标管理器。

        Args:
            max_history: 每个标签组保留的最大历史记录数。
        """
        if max_history <= 0:
            raise ValueError("max_history must be positive")
        self._max_history: int = max_history
        self._metrics: Dict[str, List[MetricsData]] = {}
        self._lock = threading.RLock()
        self._logger = _setup_logger(f"{MetricsManager.__module__}.{MetricsManager.__qualname__}")

    def _make_key(self, labels: Optional[Dict[str, Any]]) -> str:
        """生成用于内部存储的标签键。

        Args:
            labels: 标签字典，可为 None。

        Returns:
            str: JSON 序列化的标签键。
        """
        if not labels:
            return "__default__"
        return json.dumps(labels, sort_keys=True, ensure_ascii=False)

    def record(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录一条指标数据。

        Args:
            value: 指标数值。
            labels: 附加标签，用于分组统计。
        """
        if not isinstance(value, (int, float)):
            raise TypeError(f"metric value must be numeric, got {type(value).__name__}")
        key = self._make_key(labels)
        with self._lock:
            if key not in self._metrics:
                self._metrics[key] = []

            entry = MetricsData(value=float(value), timestamp=time.time(), labels=labels or {})
            self._metrics[key].append(entry)

            if len(self._metrics[key]) > self._max_history:
                keep = max(self._max_history // 2, 1)
                self._metrics[key] = self._metrics[key][-keep:]
                self._logger.debug("指标 '%s' 超出最大历史，截断至 %d 条", key, keep)

    def get_stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """获取指定标签组的统计信息。

        Args:
            labels: 标签字典，可为 None。

        Returns:
            dict: 包含 count, mean, min, max, p50, p95, p99。
        """
        key = self._make_key(labels)
        with self._lock:
            entries = self._metrics.get(key, [])
            values = [e.value for e in entries]

        if not values:
            return {
                "count": 0,
                "mean": 0.0,
                "min": 0.0,
                "max": 0.0,
                "p50": 0.0,
                "p95": 0.0,
                "p99": 0.0,
            }

        sorted_vals = sorted(values)
        n = len(sorted_vals)

        def percentile(p: float) -> float:
            idx = min(int(n * p), n - 1)
            return sorted_vals[idx]

        return {
            "count": n,
            "mean": statistics.mean(values),
            "min": min(values),
            "max": max(values),
            "p50": percentile(0.50),
            "p95": percentile(0.95),
            "p99": percentile(0.99),
        }

    def get_history(
        self, labels: Optional[Dict[str, Any]] = None, limit: int = 100
    ) -> List[float]:
        """获取指定标签组最近 N 条指标值。

        Args:
            labels: 标签字典。
            limit: 最多返回条数。

        Returns:
            list: 指标值列表（时间顺序）。
        """
        if limit <= 0:
            return []
        key = self._make_key(labels)
        with self._lock:
            entries = self._metrics.get(key, [])
            return [e.value for e in entries[-limit:]]

    def reset(self) -> None:
        """清空所有指标数据。"""
        with self._lock:
            count = sum(len(v) for v in self._metrics.values())
            self._metrics.clear()
            self._logger.info("指标已重置，共清除 %d 条记录", count)


# =============================================================================
# 配置管理组件
# =============================================================================


class ConfigManager:
    """线程安全的配置管理器，支持版本控制与 JSON 持久化。"""

    def __init__(self, default_config: Optional[Dict[str, Any]] = None) -> None:
        """初始化配置管理器。

        Args:
            default_config: 默认配置字典。
        """
        self._default_config: Dict[str, Any] = deepcopy(default_config) if default_config else {}
        self._config: Dict[str, Any] = deepcopy(self._default_config)
        self._version: int = 1
        self._lock = threading.RLock()
        self._logger = _setup_logger(f"{ConfigManager.__module__}.{ConfigManager.__qualname__}")

    def get(self, key: str, default: Any = None) -> Any:
        """获取配置项。

        Args:
            key: 配置键。
            default: 键不存在时的默认值。

        Returns:
            Any: 配置值。
        """
        with self._lock:
            return self._config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """设置单个配置项并递增版本。

        Args:
            key: 配置键。
            value: 配置值。
        """
        with self._lock:
            self._config[key] = deepcopy(value)
            self._version += 1
            self._logger.debug("配置 '%s' 已更新，版本号 %d", key, self._version)

    def update(self, updates: Dict[str, Any]) -> None:
        """批量更新配置项并递增一次版本。

        Args:
            updates: 要合并的配置字典。
        """
        if not updates:
            return
        with self._lock:
            for k, v in updates.items():
                self._config[k] = deepcopy(v)
            self._version += 1
            self._logger.debug("配置批量更新 %d 项，版本号 %d", len(updates), self._version)

    def reset(self) -> None:
        """重置为默认配置。"""
        with self._lock:
            self._config = deepcopy(self._default_config)
            self._version += 1
            self._logger.info("配置已重置为默认值，版本号 %d", self._version)

    def all(self) -> Dict[str, Any]:
        """获取全部配置的副本。

        Returns:
            dict: 配置字典副本。
        """
        with self._lock:
            return deepcopy(self._config)

    def version(self) -> int:
        """获取当前配置版本号。

        Returns:
            int: 版本号。
        """
        with self._lock:
            return self._version

    def export(self, path: str) -> str:
        """导出配置到 JSON 文件。

        Args:
            path: 目标文件路径。

        Returns:
            str: 导出的文件路径。

        Raises:
            OSError: 文件写入失败时抛出。
        """
        with self._lock:
            config_data = deepcopy(self._config)

        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(config_data, f, ensure_ascii=False, indent=2, default=str)
            self._logger.info("配置已导出到 '%s'", path)
            return path
        except OSError as e:
            self._logger.error("配置导出失败: %s", e)
            raise

    def import_config(self, path: str) -> bool:
        """从 JSON 文件导入配置。

        Args:
            path: 源文件路径。

        Returns:
            bool: 导入成功返回 True，失败返回 False。
        """
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                self._logger.warning("导入文件内容不是字典，已忽略")
                return False
            self.update(data)
            self._logger.info("配置已从 '%s' 导入", path)
            return True
        except (OSError, json.JSONDecodeError) as e:
            self._logger.error("配置导入失败: %s", e)
            return False


# =============================================================================
# 事件管理组件
# =============================================================================


class EventManager:
    """线程安全的事件处理器管理器。"""

    def __init__(self) -> None:
        """初始化事件管理器。"""
        self._handlers: Dict[str, Callable[[Any], None]] = {}
        self._lock = threading.RLock()
        self._logger = _setup_logger(f"{EventManager.__module__}.{EventManager.__qualname__}")

    def register(self, handler: Callable[[Any], None]) -> str:
        """注册事件处理器。

        Args:
            handler: 接受一个参数的可调用对象。

        Returns:
            str: 处理器唯一标识。
        """
        if not callable(handler):
            raise TypeError("handler must be callable")
        handler_id = generate_id("handler")
        with self._lock:
            self._handlers[handler_id] = handler
            self._logger.debug("注册事件处理器 '%s'", handler_id)
        return handler_id

    def unregister(self, handler_id: str) -> bool:
        """注销事件处理器。

        Args:
            handler_id: 处理器标识。

        Returns:
            bool: 注销成功返回 True。
        """
        with self._lock:
            if handler_id in self._handlers:
                del self._handlers[handler_id]
                self._logger.debug("注销事件处理器 '%s'", handler_id)
                return True
            return False

    def emit(self, data: Any = None) -> int:
        """触发事件，依次调用所有已注册处理器。

        Args:
            data: 传递给处理器的事件数据。

        Returns:
            int: 成功调用的处理器数量。
        """
        with self._lock:
            handlers = list(self._handlers.values())

        count = 0
        for handler in handlers:
            try:
                handler(data)
                count += 1
            except Exception as e:
                self._logger.warning("事件处理器执行异常: %s", e)
        return count

    def count(self) -> int:
        """获取已注册处理器数量。

        Returns:
            int: 处理器数量。
        """
        with self._lock:
            return len(self._handlers)

    def clear(self) -> None:
        """清空所有事件处理器。"""
        with self._lock:
            count = len(self._handlers)
            self._handlers.clear()
            if count:
                self._logger.info("已清空 %d 个事件处理器", count)


# =============================================================================
# 模态转换器（核心聚合类）
# =============================================================================


class ModalityConverter:
    """模态转换器核心类。

    集成数据项 CRUD、缓存、指标、配置与事件子系统，
    提供同步与异步接口及生命周期管理。
    """

    VALID_STATES: Tuple[str, ...] = ("idle", "running", "paused", "stopped", "error")

    def __init__(self) -> None:
        """初始化转换器及其子组件。"""
        self._item_store: Dict[str, Dict[str, Any]] = {}
        self._item_stats: Dict[str, int] = {
            "created": 0,
            "updated": 0,
            "deleted": 0,
        }
        self._lock = threading.RLock()
        self._logger = _setup_logger(f"{ModalityConverter.__module__}.{ModalityConverter.__qualname__}")

        # 子组件
        self._cache: LruCache = LruCache(max_size=10_000)
        self._metrics: MetricsManager = MetricsManager(max_history=10_000)
        self._config: ConfigManager = ConfigManager()
        self._events: EventManager = EventManager()

        # 生命周期状态
        self._initialized: bool = False
        self._status: str = "idle"
        self._current_state: str = "idle"
        self._state_history: List[str] = []
        self._start_time: float = 0.0
        self._shutdown: bool = False

    # ------------------------------------------------------------------
    # 数据项 CRUD
    # ------------------------------------------------------------------

    def create_item(self, data: Dict[str, Any]) -> str:
        """创建数据项。

        Args:
            data: 数据字典。

        Returns:
            str: 新数据项的唯一 ID。
        """
        if data is None:
            raise ValueError("data must not be None")
        item_id = generate_id("mc_item")
        now = time.time()
        record = {
            "id": item_id,
            "data": deepcopy(data),
            "created_at": now,
            "updated_at": now,
            "version": 1,
        }
        with self._lock:
            self._item_store[item_id] = record
            self._item_stats["created"] += 1
        self._logger.debug("创建数据项 '%s'", item_id)
        return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取数据项。

        Args:
            item_id: 数据项 ID。

        Returns:
            Optional[dict]: 数据内容，不存在则返回 None。
        """
        with self._lock:
            record = self._item_store.get(item_id)
            if record:
                return deepcopy(record["data"])
        return None

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新数据项（合并更新）。

        Args:
            item_id: 数据项 ID。
            data: 要合并的数据字典。

        Returns:
            bool: 更新成功返回 True。
        """
        if not data:
            return False
        with self._lock:
            record = self._item_store.get(item_id)
            if not record:
                return False
            record["data"].update(deepcopy(data))
            record["updated_at"] = time.time()
            record["version"] += 1
            self._item_stats["updated"] += 1
        self._logger.debug("更新数据项 '%s'，版本 %d", item_id, record["version"])
        return True

    def delete_item(self, item_id: str) -> bool:
        """删除数据项。

        Args:
            item_id: 数据项 ID。

        Returns:
            bool: 删除成功返回 True。
        """
        with self._lock:
            if item_id in self._item_store:
                del self._item_store[item_id]
                self._item_stats["deleted"] += 1
                self._logger.debug("删除数据项 '%s'", item_id)
                return True
        return False

    def list_items(
        self,
        page: int = 1,
        page_size: int = 20,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """分页列出数据项。

        Args:
            page: 页码（从 1 开始）。
            page_size: 每页条数。
            filters: 按字段值精确过滤。

        Returns:
            dict: 包含 items、total、page、page_size。
        """
        if page < 1:
            raise ValueError("page must be >= 1")
        if page_size < 1:
            raise ValueError("page_size must be >= 1")

        with self._lock:
            items = list(self._item_store.values())

        if filters:
            filtered = [
                rec for rec in items if all(rec["data"].get(k) == v for k, v in filters.items())
            ]
        else:
            filtered = items

        total = len(filtered)
        start = (page - 1) * page_size
        end = start + page_size
        page_items = [deepcopy(rec["data"]) for rec in filtered[start:end]]

        return {"items": page_items, "total": total, "page": page, "page_size": page_size}

    def count_items(self) -> int:
        """统计数据项总数。

        Returns:
            int: 数据项数量。
        """
        with self._lock:
            return len(self._item_store)

    def search_items(
        self, query: str, fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """在数据项中执行子串搜索。

        Args:
            query: 搜索关键词（不区分大小写）。
            fields: 限定搜索的字段列表，None 表示全部字段。

        Returns:
            list: 匹配的数据项列表。
        """
        if not query:
            return []
        query_lower = query.lower()
        results: List[Dict[str, Any]] = []

        with self._lock:
            for record in self._item_store.values():
                data = record["data"]
                target_fields = fields if fields is not None else list(data.keys())
                matched = False
                for fld in target_fields:
                    val = data.get(fld, "")
                    if query_lower in str(val).lower():
                        matched = True
                        break
                if matched:
                    results.append(deepcopy(data))
        return results

    def batch_create_items(self, batch: List[Dict[str, Any]]) -> List[str]:
        """批量创建数据项。

        Args:
            batch: 数据字典列表。

        Returns:
            list: 创建的数据项 ID 列表。
        """
        return [self.create_item(item) for item in batch]

    def batch_delete_items(self, ids: List[str]) -> int:
        """批量删除数据项。

        Args:
            ids: 要删除的数据项 ID 列表。

        Returns:
            int: 成功删除的数量。
        """
        count = 0
        for item_id in ids:
            if self.delete_item(item_id):
                count += 1
        return count

    def export_items(self, path: str) -> str:
        """导出全部数据项到 JSON 文件。

        Args:
            path: 目标文件路径。

        Returns:
            str: 导出的文件路径。

        Raises:
            OSError: 文件写入失败时抛出。
        """
        with self._lock:
            data = [deepcopy(rec) for rec in self._item_store.values()]

        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2, default=str)
            self._logger.info("导出 %d 条数据项到 '%s'", len(data), path)
            return path
        except OSError as e:
            self._logger.error("数据项导出失败: %s", e)
            raise

    def import_items(self, path: str) -> int:
        """从 JSON 文件导入数据项。

        Args:
            path: 源文件路径。

        Returns:
            int: 成功导入的数量。

        Raises:
            OSError: 文件读取失败时抛出。
        """
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except OSError as e:
            self._logger.error("数据项导入读取失败: %s", e)
            raise

        if not isinstance(data, list):
            self._logger.warning("导入文件内容不是列表，已忽略")
            return 0

        count = 0
        for record in data:
            if not isinstance(record, dict) or "data" not in record:
                self._logger.warning("跳过无效记录: %r", record)
                continue
            item_id = record.get("id") or generate_id("mc_item")
            with self._lock:
                self._item_store[item_id] = deepcopy(record)
                self._item_stats["created"] += 1
            count += 1

        self._logger.info("从 '%s' 导入 %d 条数据项", path, count)
        return count

    def get_item_stats(self) -> Dict[str, Any]:
        """获取数据项操作统计。

        Returns:
            dict: 包含 total、created、updated、deleted。
        """
        with self._lock:
            return {
                "total": len(self._item_store),
                "created": self._item_stats["created"],
                "updated": self._item_stats["updated"],
                "deleted": self._item_stats["deleted"],
            }

    # ------------------------------------------------------------------
    # 缓存代理
    # ------------------------------------------------------------------

    def get_cache(self, key: str) -> Optional[Any]:
        """获取缓存值。"""
        return self._cache.get(key)

    def set_cache(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """设置缓存值。"""
        self._cache.set(key, value, ttl)

    def invalidate_cache(self, key: str) -> bool:
        """失效指定缓存项。"""
        return self._cache.invalidate(key)

    def clear_cache(self) -> int:
        """清空缓存。"""
        return self._cache.clear()

    def get_cache_stats(self) -> Dict[str, Any]:
        """获取缓存统计。"""
        return self._cache.stats()

    # ------------------------------------------------------------------
    # 指标代理
    # ------------------------------------------------------------------

    def record_metric(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录指标数据。"""
        self._metrics.record(value, labels)

    def get_stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """获取指标统计。"""
        return self._metrics.get_stats(labels)

    def get_history(
        self, labels: Optional[Dict[str, Any]] = None, limit: int = 100
    ) -> List[float]:
        """获取指标历史值。"""
        return self._metrics.get_history(labels, limit)

    def reset_metrics(self) -> None:
        """重置全部指标。"""
        self._metrics.reset()

    # ------------------------------------------------------------------
    # 配置代理
    # ------------------------------------------------------------------

    def get_config(self, key: str, default: Any = None) -> Any:
        """获取配置项。"""
        return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """设置配置项。"""
        self._config.set(key, value)

    def get_all_config(self) -> Dict[str, Any]:
        """获取全部配置。"""
        return self._config.all()

    def update_config(self, updates: Dict[str, Any]) -> None:
        """批量更新配置。"""
        self._config.update(updates)

    def reset_config(self) -> None:
        """重置配置为默认值。"""
        self._config.reset()

    def get_config_version(self) -> int:
        """获取配置版本号。"""
        return self._config.version()

    def export_config(self, path: str) -> str:
        """导出配置到文件。"""
        return self._config.export(path)

    def import_config(self, path: str) -> bool:
        """从文件导入配置。"""
        return self._config.import_config(path)

    # ------------------------------------------------------------------
    # 事件代理
    # ------------------------------------------------------------------

    def on_event(self, handler: Callable[[Any], None]) -> str:
        """注册事件处理器。"""
        return self._events.register(handler)

    def off_event(self, handler_id: str) -> bool:
        """注销事件处理器。"""
        return self._events.unregister(handler_id)

    def emit_event(self, data: Any = None) -> int:
        """触发事件。"""
        return self._events.emit(data)

    def get_event_handler_count(self) -> int:
        """获取已注册事件处理器数量。"""
        return self._events.count()

    def clear_event_handlers(self) -> None:
        """清空所有事件处理器。"""
        self._events.clear()

    # ------------------------------------------------------------------
    # 生命周期管理
    # ------------------------------------------------------------------

    def _transition_state(self, new_state: str) -> None:
        """内部方法：切换状态并记录历史。

        Args:
            new_state: 目标状态，必须是 VALID_STATES 之一。
        """
        if new_state not in self.VALID_STATES:
            raise ValueError(f"invalid state: {new_state}")
        self._current_state = new_state
        self._state_history.append(new_state)
        self._logger.debug("状态切换为 '%s'", new_state)

    def _init_resources(self) -> None:
        """初始化内部资源（启动时间等）。"""
        self._start_time = time.monotonic()
        self._shutdown = False

    def _cleanup_resources(self) -> None:
        """清理内部资源。"""
        self._cache.clear()
        self._metrics.reset()
        self._events.clear()
        self._shutdown = True

    def _health_check(self) -> bool:
        """执行健康检查。

        Returns:
            bool: 健康返回 True。
        """
        if self._shutdown:
            return False
        if self._status in ("error", "stopped"):
            return False
        return True

    def initialize(self) -> bool:
        """初始化转换器。

        Returns:
            bool: 初始化成功返回 True。
        """
        if self._initialized:
            self._logger.warning("ModalityConverter 已初始化，跳过")
            return True

        try:
            self._init_resources()
            self._transition_state("running")
            self._status = "running"
            self._initialized = True
            self._logger.info("ModalityConverter 初始化成功")
            return True
        except Exception as e:
            self._logger.error("ModalityConverter 初始化失败: %s", e, exc_info=True)
            self._transition_state("error")
            self._status = "error"
            return False

    def shutdown(self) -> bool:
        """关闭转换器。

        Returns:
            bool: 关闭成功返回 True。
        """
        if not self._initialized:
            self._logger.debug("ModalityConverter 未初始化，跳过关闭")
            return True

        try:
            self._cleanup_resources()
            self._transition_state("stopped")
            self._status = "stopped"
            self._initialized = False
            self._logger.info("ModalityConverter 关闭成功")
            return True
        except Exception as e:
            self._logger.error("ModalityConverter 关闭失败: %s", e, exc_info=True)
            self._transition_state("error")
            self._status = "error"
            return False

    def restart(self) -> bool:
        """重启转换器（关闭后重新初始化）。

        Returns:
            bool: 重启成功返回 True。
        """
        self.shutdown()
        time.sleep(0.1)
        self._state_history.clear()
        return self.initialize()

    def get_status(self) -> str:
        """获取当前状态。

        Returns:
            str: 状态字符串。
        """
        return self._status

    def is_healthy(self) -> bool:
        """检查转换器健康状态。

        Returns:
            bool: 健康返回 True。
        """
        if not self._initialized:
            return False
        if self._status in ("error", "stopped"):
            return False
        return self._health_check()

    def get_uptime(self) -> float:
        """获取运行时长（秒）。

        Returns:
            float: 单调时间差，未初始化返回 0.0。
        """
        if not self._initialized:
            return 0.0
        return time.monotonic() - self._start_time

    def get_state_history(self) -> List[str]:
        """获取状态历史。

        Returns:
            list: 状态切换历史列表。
        """
        return list(self._state_history)

    # ------------------------------------------------------------------
    # 数据处理
    # ------------------------------------------------------------------

    def process(self, data: Any) -> Any:
        """处理数据（同步占位实现）。

        Args:
            data: 要处理的数据。

        Returns:
            Any: 处理结果（默认原样返回）。
        """
        self._logger.debug("处理数据，类型: %s", type(data).__name__)
        return data

    def batch_process(self, items: List[Any]) -> List[Any]:
        """批量处理数据（同步）。

        Args:
            items: 要处理的数据列表。

        Returns:
            list: 处理结果列表。
        """
        return [self.process(item) for item in items]

    # ------------------------------------------------------------------
    # 异步接口
    # ------------------------------------------------------------------

    async def async_initialize(self) -> bool:
        """异步初始化。

        Returns:
            bool: 初始化成功返回 True。
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.initialize)

    async def async_shutdown(self) -> bool:
        """异步关闭。

        Returns:
            bool: 关闭成功返回 True。
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.shutdown)

    async def async_process(self, data: Any) -> Any:
        """异步处理数据。

        Args:
            data: 要处理的数据。

        Returns:
            Any: 处理结果。
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.process, data)

    async def async_batch_process(
        self, items: List[Any], concurrency: int = 4
    ) -> List[Any]:
        """异步批量处理数据，支持并发控制。

        Args:
            items: 要处理的数据列表。
            concurrency: 最大并发数。

        Returns:
            list: 处理结果列表（顺序与输入一致）。
        """
        if concurrency < 1:
            raise ValueError("concurrency must be >= 1")
        semaphore = asyncio.Semaphore(concurrency)

        async def _process_one(item: Any) -> Any:
            async with semaphore:
                return await self.async_process(item)

        tasks = [_process_one(item) for item in items]
        return await asyncio.gather(*tasks)

    # ------------------------------------------------------------------
    # 序列化
    # ------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """将转换器可序列化状态转换为字典。

        Returns:
            dict: 包含状态、统计及配置等信息的字典。
        """
        return {
            "status": self._status,
            "initialized": self._initialized,
            "item_count": self.count_items(),
            "item_stats": self.get_item_stats(),
            "cache_stats": self._cache.stats(),
            "config_version": self._config.version(),
            "event_handler_count": self._events.count(),
            "state_history": list(self._state_history),
            "uptime": self.get_uptime(),
        }

    def __repr__(self) -> str:
        """返回可读的实例表示。"""
        return (
            f"ModalityConverter(status={self._status!r}, "
            f"initialized={self._initialized}, "
            f"items={self.count_items()})"
        )
