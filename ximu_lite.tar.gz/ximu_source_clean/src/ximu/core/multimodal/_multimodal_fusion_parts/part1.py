"""Part 1 of multimodal_fusion - 多模态融合策略管理、状态控制、缓存机制及基础CRUD操作。

本模块实现P5多模态感知层的核心融合逻辑框架，支持多种融合策略，
提供线程安全的缓存管理、指标统计、配置管理及事件处理机制。
"""
from __future__ import annotations

import json
import logging
import statistics
import threading
import time
from collections import OrderedDict, defaultdict
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from src.ximu.common.utils import generate_id


def _setup_logger(name: str) -> logging.Logger:
    """设置并返回一个配置好的Logger实例，避免重复添加handler。

    Args:
        name: 日志记录器名称，通常传入类名

    Returns:
        配置好的logging.Logger实例
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


class FusionStrategy(Enum):
    """多模态数据融合策略枚举类，支持早期/晚期/混合/注意力/交叉模态等多种策略。"""

    EARLY = "EARLY"
    LATE = "LATE"
    HYBRID = "HYBRID"
    ATTENTION = "ATTENTION"
    CROSS_MODAL = "CROSS_MODAL"
    MODALITY_SPECIFIC = "MODALITY_SPECIFIC"
    DYNAMIC = "DYNAMIC"

    @classmethod
    def all_values(cls) -> List[str]:
        """获取所有策略的字符串值列表。

        Returns:
            包含所有策略值字符串的列表
        """
        return [e.value for e in cls]

    @classmethod
    def from_str(cls, text: str) -> Optional["FusionStrategy"]:
        """从字符串解析融合策略，支持按值或名称匹配。

        Args:
            text: 要解析的策略字符串

        Returns:
            解析成功的FusionStrategy枚举成员，未找到返回None
        """
        if not isinstance(text, str):
            return None
        for strategy in cls:
            if strategy.value == text or strategy.name == text:
                return strategy
        return None


@dataclass
class FusionResult:
    """多模态融合结果数据类，封装策略、置信度、输出模态及权重信息。"""

    strategy: str = ""
    confidence: float = 0.0
    output: Any = None
    modalities: List[str] = field(default_factory=list)
    weights: Dict[str, float] = field(default_factory=dict)
    features: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """将融合结果序列化为字典。

        Returns:
            包含融合结果所有字段的字典
        """
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FusionResult":
        """从字典反序列化为融合结果实例。

        Args:
            data: 包含融合结果字段的字典

        Returns:
            构建的FusionResult实例，忽略不在字段定义中的键
        """
        valid_keys = set(cls.__dataclass_fields__)
        filtered = {k: v for k, v in data.items() if k in valid_keys}
        return cls(**filtered)


class MultimodalFusion:
    """多模态融合器核心类，提供数据项管理、缓存、指标统计、配置及事件处理。

    支持多种融合策略，通过线程安全的接口管理数据项、缓存、指标和配置，
    实现模态融合的核心逻辑框架。采用LRU缓存优化性能，使用统计模块计算指标。
    """

    def __init__(self) -> None:
        """初始化多模态融合器的所有内部状态和管理结构。"""
        self._item_store: Dict[str, Dict[str, Any]] = {}
        self._stats: Dict[str, int] = defaultdict(int)

        self._cache: OrderedDict[str, Dict[str, Any]] = OrderedDict()
        self._max_cache_size: int = 10000

        self._metrics: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._metrics_max_len: int = 5000

        self._config: Dict[str, Any] = {}
        self._default_config: Dict[str, Any] = {}
        self._config_version: int = 1

        self._evt_handlers: Dict[str, callable] = {}

        self._initialized: bool = False
        self._status: str = "idle"
        self._start_time: float = 0.0
        self._stages: List[str] = []
        self._queue: List[Any] = []
        self._total_enqueued: int = 0
        self._total_dequeued: int = 0
        self._registry: Dict[str, Any] = {}
        self._states: List[str] = ["idle", "running", "paused", "stopped", "error"]
        self._current_state: str = "idle"
        self._initial_state: str = "idle"
        self._state_history: List[str] = []
        self._transitions: List[Tuple[str, str, float]] = []
        self._tasks: Dict[str, Any] = {}
        self._workers: Dict[str, Any] = {}

        self._strategies: Dict[str, Any] = {}
        self._weights: Dict[str, float] = {}

        self._lock = threading.RLock()
        self._logger = _setup_logger(self.__class__.__name__)

    # ------------------------------------------------------------------
    # CRUD 操作
    # ------------------------------------------------------------------

    def create_item(self, data: Dict[str, Any]) -> str:
        """创建并存储一个新的多模态融合数据项。

        Args:
            data: 数据项的内容字典

        Returns:
            新创建数据项的唯一标识符
        """
        item_id = generate_id("multimodalfusion_item")
        now = time.time()
        record = {"id": item_id, "data": data, "created_at": now, "updated_at": now, "version": 1}
        with self._lock:
            self._item_store[item_id] = record
            self._stats["item_created"] += 1
        self._logger.debug(f"创建多模态融合项: {item_id}")
        return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """根据ID获取多模态融合数据项的内容。

        Args:
            item_id: 数据项的唯一标识符

        Returns:
            数据项的内容字典，不存在时返回None
        """
        with self._lock:
            record = self._item_store.get(item_id)
        if record:
            return record["data"]
        return None

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新已存在的多模态融合数据项。

        Args:
            item_id: 要更新的数据项标识符
            data: 更新的内容字典，将合并到原有数据中

        Returns:
            更新成功返回True，数据项不存在返回False
        """
        with self._lock:
            if item_id not in self._item_store:
                return False
            record = self._item_store[item_id]
            record["data"].update(data)
            record["updated_at"] = time.time()
            record["version"] += 1
            self._stats["item_updated"] += 1
        self._logger.debug(f"更新多模态融合项: {item_id}")
        return True

    def delete_item(self, item_id: str) -> bool:
        """删除指定的多模态融合数据项。

        Args:
            item_id: 要删除的数据项标识符

        Returns:
            删除成功返回True，数据项不存在返回False
        """
        with self._lock:
            if item_id not in self._item_store:
                return False
            del self._item_store[item_id]
            self._stats["item_deleted"] += 1
        self._logger.debug(f"删除多模态融合项: {item_id}")
        return True

    def list_items(
        self, page: int = 1, page_size: int = 20, filters: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """分页列出多模态融合数据项，支持过滤条件。

        Args:
            page: 页码，从1开始
            page_size: 每页显示的条目数量
            filters: 过滤条件字典，键值对将匹配数据项中的字段

        Returns:
            包含items(当前页数据)、total(总数)、page(页码)、page_size(每页数量)的字典
        """
        with self._lock:
            items = list(self._item_store.values())
        if filters:
            filtered_items = [
                item for item in items if all(item["data"].get(k) == v for k, v in filters.items())
            ]
            items = filtered_items
        total = len(items)
        start_idx = (page - 1) * page_size
        end_idx = start_idx + page_size
        return {
            "items": [it["data"] for it in items[start_idx:end_idx]],
            "total": total,
            "page": page,
            "page_size": page_size,
        }

    def count_items(self) -> int:
        """统计当前存储的多模态融合数据项总数。

        Returns:
            数据项的总数
        """
        with self._lock:
            return len(self._item_store)

    def search_items(
        self, query: str, fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """在数据项中执行模糊搜索，支持指定搜索字段。

        Args:
            query: 搜索关键字，不区分大小写
            fields: 指定搜索的字段名列表，为None时搜索所有字段

        Returns:
            匹配搜索条件的所有数据项内容列表
        """
        if not isinstance(query, str):
            raise TypeError("query 必须为字符串类型")
        results: List[Dict[str, Any]] = []
        query_lower = query.lower()
        with self._lock:
            for record in self._item_store.values():
                data = record["data"]
                search_fields = fields if fields else list(data.keys())
                if any(query_lower in str(data.get(f, "")).lower() for f in search_fields):
                    results.append(data)
        return results

    def batch_create_items(self, batch: List[Dict[str, Any]]) -> List[str]:
        """批量创建多模态融合数据项。

        Args:
            batch: 要创建的数据项内容列表

        Returns:
            创建成功的数据项ID列表
        """
        if not isinstance(batch, list):
            raise TypeError("batch 必须为列表类型")
        ids: List[str] = []
        now = time.time()
        with self._lock:
            for item in batch:
                item_id = generate_id("multimodalfusion_item")
                record = {"id": item_id, "data": item, "created_at": now, "updated_at": now, "version": 1}
                self._item_store[item_id] = record
                self._stats["item_created"] += 1
                ids.append(item_id)
        self._logger.debug(f"批量创建多模态融合项: {len(ids)}个")
        return ids

    def batch_delete_items(self, ids: List[str]) -> int:
        """批量删除多模态融合数据项。

        Args:
            ids: 要删除的数据项ID列表

        Returns:
            成功删除的数据项数量
        """
        if not isinstance(ids, list):
            raise TypeError("ids 必须为列表类型")
        deleted_count = 0
        with self._lock:
            for item_id in ids:
                if item_id in self._item_store:
                    del self._item_store[item_id]
                    self._stats["item_deleted"] += 1
                    deleted_count += 1
        self._logger.debug(f"批量删除多模态融合项: {deleted_count}个")
        return deleted_count

    def export_items(self, path: str) -> str:
        """将当前所有多模态融合数据项导出到指定路径的JSON文件。

        Args:
            path: 导出文件的完整路径

        Returns:
            导出成功后的文件路径

        Raises:
            IOError: 文件写入失败时抛出
        """
        with self._lock:
            data = list(self._item_store.values())
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        self._logger.info(f"导出多模态融合项到: {path}")
        return path

    def import_items(self, path: str) -> int:
        """从JSON文件导入多模态融合数据项到存储中。

        Args:
            path: 导入文件的完整路径

        Returns:
            成功导入的数据项数量

        Raises:
            FileNotFoundError: 文件不存在时抛出
            json.JSONDecodeError: 文件格式错误时抛出
            ValueError: 数据格式不合法时抛出
        """
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise ValueError("导入数据必须为JSON列表格式")
        imported = 0
        with self._lock:
            for record in data:
                if not isinstance(record, dict):
                    raise ValueError("每个记录必须为字典格式")
                item_id = record.get("id", generate_id("multimodalfusion_item"))
                if "data" not in record or not isinstance(record["data"], dict):
                    raise ValueError("记录缺少'data'字段或字段类型不正确")
                self._item_store[item_id] = record
                self._stats["item_created"] += 1
                imported += 1
        self._logger.info(f"从{path}导入{imported}个多模态融合项")
        return imported

    def get_item_stats(self) -> Dict[str, int]:
        """获取多模态融合数据项的创建、更新、删除统计信息。

        Returns:
            包含total、created、updated、deleted字段的统计字典
        """
        with self._lock:
            return {
                "total": len(self._item_store),
                "created": self._stats.get("item_created", 0),
                "updated": self._stats.get("item_updated", 0),
                "deleted": self._stats.get("item_deleted", 0),
            }

    # ------------------------------------------------------------------
    # 缓存管理 (LRU)
    # ------------------------------------------------------------------

    def get_cache(self, key: str) -> Optional[Any]:
        """获取缓存值，若未过期则命中并移动到最近使用位置。

        Args:
            key: 缓存键

        Returns:
            未过期的缓存值，过期或不存在时返回None
        """
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            elapsed = time.monotonic() - entry["time"]
            if elapsed < entry["ttl"]:
                self._cache.move_to_end(key)
                return entry["value"]
            del self._cache[key]
        return None

    def set_cache(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """设置缓存值，支持LRU淘汰策略。

        Args:
            key: 缓存键
            value: 要缓存的值
            ttl: 缓存生存时间（秒），默认300秒

        Raises:
            ValueError: ttl必须为非负数
        """
        if ttl < 0:
            raise ValueError("ttl 必须为非负数")
        with self._lock:
            self._cache[key] = {"value": value, "time": time.monotonic(), "ttl": ttl}
            self._cache.move_to_end(key)
            if len(self._cache) > self._max_cache_size:
                oldest_key, _ = self._cache.popitem(last=False)
                self._logger.debug(f"LRU缓存淘汰: {oldest_key}")

    def invalidate_cache(self, key: str) -> bool:
        """使指定键的缓存失效。

        Args:
            key: 要失效的缓存键

        Returns:
            失效成功返回True，键不存在返回False
        """
        with self._lock:
            existed = key in self._cache
            if existed:
                del self._cache[key]
        return existed

    def clear_cache(self) -> int:
        """清空所有缓存条目。

        Returns:
            被清除的缓存条目数量
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
        return count

    def get_cache_stats(self) -> Dict[str, int]:
        """获取缓存的当前大小和最大容量统计。

        Returns:
            包含size和max_size字段的缓存统计字典
        """
        with self._lock:
            return {"size": len(self._cache), "max_size": self._max_cache_size}

    # ------------------------------------------------------------------
    # 指标统计
    # ------------------------------------------------------------------

    def record_metric(self, value: float, labels: Optional[Dict[str, str]] = None) -> None:
        """记录一个多模态融合指标值，支持标签分组，自动裁剪历史。

        Args:
            value: 要记录的指标数值
            labels: 指标标签字典，用于分组，可为None
        """
        if not isinstance(value, (int, float)):
            raise TypeError("value 必须为数值类型")
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True)
            self._metrics[key].append(
                {"value": float(value), "time": time.time(), "labels": labels or {}}
            )
            if len(self._metrics[key]) > self._metrics_max_len:
                self._metrics[key] = self._metrics[key][-self._metrics_max_len:]

    def get_metrics_stats(self, labels: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """获取指定标签分组的指标统计摘要。

        Args:
            labels: 指标标签字典，用于指定分组，可为None

        Returns:
            包含count、mean、min、max、p50、p95、p99的统计字典
        """
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True)
            values = [entry["value"] for entry in self._metrics.get(key, [])]
        if not values:
            return {"count": 0, "mean": 0, "min": 0, "max": 0, "p50": 0, "p95": 0, "p99": 0}
        sorted_vals = sorted(values)
        count = len(sorted_vals)
        p50_idx = int(count * 0.5)
        p95_idx = int(count * 0.95)
        p99_idx = int(count * 0.99)
        return {
            "count": count,
            "mean": statistics.mean(values),
            "min": min(values),
            "max": max(values),
            "p50": sorted_vals[p50_idx] if p50_idx < count else sorted_vals[-1],
            "p95": sorted_vals[p95_idx] if p95_idx < count else sorted_vals[-1],
            "p99": sorted_vals[p99_idx] if p99_idx < count else sorted_vals[-1],
        }

    def get_metrics_history(
        self, labels: Optional[Dict[str, str]] = None, limit: int = 100
    ) -> List[Dict[str, Any]]:
        """获取指定标签分组的指标历史记录。

        Args:
            labels: 指标标签字典，用于指定分组，可为None
            limit: 返回的历史记录最大条数

        Returns:
            指标记录列表，每条包含value、time、labels字段
        """
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True)
            return list(self._metrics.get(key, []))[-limit:]

    def reset_metrics(self) -> None:
        """重置所有多模态融合指标统计数据。"""
        with self._lock:
            self._metrics.clear()
        self._logger.debug("指标统计已重置")

    # ------------------------------------------------------------------
    # 配置管理
    # ------------------------------------------------------------------

    def get_config(self, key: str, default: Any = None) -> Any:
        """获取指定键的配置值。

        Args:
            key: 配置键名
            default: 键不存在时返回的默认值

        Returns:
            配置值或默认值
        """
        with self._lock:
            return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """设置指定键的配置值并递增配置版本。

        Args:
            key: 配置键名
            value: 要设置的配置值
        """
        with self._lock:
            self._config[key] = value
            self._config_version += 1

    def get_all_config(self) -> Dict[str, Any]:
        """获取全部配置的深拷贝。

        Returns:
            包含所有配置项的字典副本
        """
        with self._lock:
            return dict(self._config)

    def update_config(self, updates: Dict[str, Any]) -> None:
        """批量更新配置并递增配置版本。

        Args:
            updates: 要更新的配置项字典

        Raises:
            TypeError: updates不是字典时抛出
        """
        if not isinstance(updates, dict):
            raise TypeError("updates 必须为字典类型")
        with self._lock:
            self._config.update(updates)
            self._config_version += 1

    def reset_config(self) -> None:
        """重置配置为默认值并递增配置版本。"""
        with self._lock:
            self._config = dict(self._default_config)
            self._config_version += 1

    def get_config_version(self) -> int:
        """获取当前配置版本号。

        Returns:
            配置版本号
        """
        return self._config_version

    def export_config(self, path: str) -> str:
        """导出当前配置到JSON文件。

        Args:
            path: 导出文件的完整路径

        Returns:
            导出成功后的文件路径

        Raises:
            IOError: 文件写入失败时抛出
        """
        config_data = self.get_all_config()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(config_data, f, ensure_ascii=False, indent=2)
        self._logger.info(f"导出配置到: {path}")
        return path

    def import_config(self, path: str) -> bool:
        """从JSON文件导入配置，导入失败时抛出异常。

        Args:
            path: 导入文件的完整路径

        Returns:
            导入成功返回True

        Raises:
            FileNotFoundError: 文件不存在时抛出
            json.JSONDecodeError: 文件格式错误时抛出
            ValueError: 数据格式不合法时抛出
        """
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError("导入配置必须为JSON字典格式")
        self.update_config(data)
        self._logger.info(f"从{path}导入配置成功")
        return True

    # ------------------------------------------------------------------
    # 事件处理
    # ------------------------------------------------------------------

    def register_event_handler(self, event_name: str, handler: callable) -> None:
        """注册事件处理器。

        Args:
            event_name: 事件名称
            handler: 事件处理函数

        Raises:
            TypeError: handler不是可调用对象时抛出
        """
        if not callable(handler):
            raise TypeError("handler 必须为可调用对象")
        with self._lock:
            self._evt_handlers[event_name] = handler

    def trigger_event(self, event_name: str, payload: Any) -> None:
        """触发指定事件，调用已注册的处理函数。

        Args:
            event_name: 事件名称
            payload: 事件数据

        Raises:
            ValueError: 事件名称无效时抛出
        """
        with self._lock:
            handler = self._evt_handlers.get(event_name)
        if handler:
            handler(payload)

    def unregister_event_handler(self, event_name: str) -> bool:
        """注销事件处理器。

        Args:
            event_name: 事件名称

        Returns:
            注销成功返回True，处理器不存在返回False
        """
        with self._lock:
            existed = event_name in self._evt_handlers
            if existed:
                del self._evt_handlers[event_name]
        return existed

    def get_event_handlers(self) -> List[str]:
        """获取所有已注册的事件名称列表。

        Returns:
            事件名称列表
        """
        with self._lock:
            return list(self._evt_handlers.keys())
