# -*- coding: utf-8 -*-
"""多模态融合拆分模块包初始化。

本包包含 multimodal_fusion 的功能实现，按职责拆分为：
- part1: 核心数据结构（FusionResult, FusionStrategy, 枚举等）
- part2: 融合算法实现（FeatureFusion, AttentionFusion, DecisionFusion, CrossModalAligner）
- part3: 高级封装与便捷接口（MultimodalFusion 主类等）

导入时仅声明包结构，实际符号由上层 multimodal_fusion.py 负责聚合导出。
"""
from __future__ import annotations

__all__: list[str] = []
