# -*- coding: utf-8 -*-
"""
多模态融合模块 - 基础日志组件
版本: 0.5
"""

import logging
from typing import Optional

__version__ = "0.5"


class _BaseLogger:
    """
    基础日志记录器类。
    
    该类封装了日志器的初始化、格式化设置以及常用日志级别的方法。
    确保日志输出的一致性和可追溯性，避免重复添加处理器。
    """

    def __init__(self, name: str) -> None:
        """
        初始化日志记录器实例。
        
        Args:
            name (str): 日志记录器的名称，通常使用 __name__。
        """
        self.logger = logging.getLogger(name)
        
        # 防止重复添加 Handler
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)

    def info(self, msg: str) -> None:
        """
        记录信息级别日志。
        
        Args:
            msg (str): 日志消息内容。
        """
        self.logger.info(msg)

    def debug(self, msg: str) -> None:
        """
        记录调试级别日志。
        
        Args:
            msg (str): 日志消息内容。
        """
        self.logger.debug(msg)

    def warning(self, msg: str) -> None:
        """
        记录警告级别日志。
        
        Args:
            msg (str): 日志消息内容。
        """
        self.logger.warning(msg)

    def error(self, msg: str) -> None:
        """
        记录错误级别日志。
        
        Args:
            msg (str): 日志消息内容。
        """
        self.logger.error(msg)
