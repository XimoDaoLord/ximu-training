"""视觉感知核心模块（Part 1）。

提供视觉任务定义、结果封装、本地TTL缓存、性能指标记录、状态机管理及
项目CRUD操作，支持事件处理与配置管理。
"""

import json
import time
import uuid
import logging
import threading
import statistics
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Callable, Union
from dataclasses import dataclass, field, asdict
from collections import defaultdict


def _generate_id(prefix: str) -> str:
    """生成带前缀的唯一标识符。

    Args:
        prefix: 标识符前缀。

    Returns:
        唯一字符串标识。
    """
    return f"{prefix}_{uuid.uuid4().hex}"


def _setup_logger(name: str) -> logging.Logger:
    """配置并返回指定名称的日志记录器。

    Args:
        name: 日志记录器名称。

    Returns:
        配置好的 Logger 实例。
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    return logger


class VisionTask(Enum):
    """视觉任务类型枚举。

    支持分类、检测、分割、OCR、描述、视觉问答、场景理解、
    人脸检测、情感分析、姿态估计等标准视觉任务。
    """

    CLASSIFICATION = "CLASSIFICATION"
    DETECTION = "DETECTION"
    SEGMENTATION = "SEGMENTATION"
    OCR = "OCR"
    CAPTION = "CAPTION"
    VQA = "VQA"
    SCENE = "SCENE"
    FACE = "FACE"
    EMOTION = "EMOTION"
    POSE = "POSE"

    @classmethod
    def all_values(cls) -> List[str]:
        """返回所有任务类型的字符串值列表。

        Returns:
            所有枚举值的列表。
        """
        return [e.value for e in cls]

    @classmethod
    def from_str(cls, text: str) -> Optional["VisionTask"]:
        """从字符串查找对应的枚举值。

        支持按枚举名或枚举值匹配（大小写不敏感）。

        Args:
            text: 输入字符串。

        Returns:
            匹配的枚举成员，未找到则返回 None。
        """
        upper_text = text.upper()
        for e in cls:
            if e.value.upper() == upper_text or e.name == upper_text:
                return e
        return None


@dataclass
class VisionResult:
    """视觉感知结果数据类。

    Attributes:
        task: 执行的任务类型。
        confidence: 整体置信度 [0.0, 1.0]。
        labels: 标签列表。
        boxes: 边界框列表。
        description: 文本描述。
        features: 额外特征字典。
    """

    task: str = ""
    confidence: float = 0.0
    labels: List[Any] = field(default_factory=list)
    boxes: List[Any] = field(default_factory=list)
    description: str = ""
    features: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """转换为普通字典。

        Returns:
            包含所有字段的字典。
        """
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "VisionResult":
        """从字典构建实例，忽略未知字段。

        Args:
            data: 源字典。

        Returns:
            VisionResult 实例。
        """
        valid_keys = set(cls.__dataclass_fields__.keys())
        filtered = {k: v for k, v in data.items() if k in valid_keys}
        return cls(**filtered)


@dataclass
class DetectedObject:
    """检测到的单个对象数据类。

    Attributes:
        label: 对象类别标签。
        confidence: 检测置信度。
        bbox: 边界框 [x, y, w, h]。
        area: 边界框面积。
    """

    label: str = ""
    confidence: float = 0.0
    bbox: List[float] = field(default_factory=list)
    area: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """转换为普通字典。

        Returns:
            包含所有字段的字典。
        """
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DetectedObject":
        """从字典构建实例，忽略未知字段。

        Args:
            data: 源字典。

        Returns:
            DetectedObject 实例。
        """
        valid_keys = set(cls.__dataclass_fields__.keys())
        filtered = {k: v for k, v in data.items() if k in valid_keys}
        return cls(**filtered)


@dataclass
class _CacheEntry:
    """内部缓存条目。

    Attributes:
        value: 缓存值。
        created_at: 创建时间戳（monotonic）。
        ttl: 存活时间（秒）。
    """

    value: Any
    created_at: float
    ttl: float

    def is_expired(self, now: Optional[float] = None) -> bool:
        """判断是否已过期。

        Args:
            now: 当前时间戳，默认使用 time.monotonic()。

        Returns:
            是否过期。
        """
        if now is None:
            now = time.monotonic()
        return (now - self.created_at) >= self.ttl


def _metric_key(labels: Optional[Dict[str, Any]]) -> str:
    """将标签字典转换为稳定的指标键字符串。

    使用排序后的键值对拼接，避免 json.dumps 对不可序列化对象的依赖。

    Args:
        labels: 标签字典，可为 None。

    Returns:
        稳定的字符串键。
    """
    if not labels:
        return "__default__"
    pairs = sorted(labels.items(), key=lambda x: str(x[0]))
    return "|".join(f"{k}={v}" for k, v in pairs)


class VisionPerception:
    """视觉感知器。

    提供可配置的视觉感知组件，支持多种视觉任务（分类、检测、OCR 等），
    具备本地缓存、性能监控、事件处理及状态机管理功能。
    """

    _MAX_CACHE_SIZE: int = 10_000
    _MAX_METRIC_POINTS: int = 10_000
    _KEEP_METRIC_POINTS: int = 5_000

    def __init__(self) -> None:
        """初始化视觉感知器。"""
        self._logger: logging.Logger = _setup_logger(self.__class__.__name__)

        # 状态与生命周期
        self._initialized: bool = False
        self._status: str = "idle"
        self._start_time: float = 0.0

        # 项目存储
        self._item_store: Dict[str, Dict[str, Any]] = {}

        # 缓存
        self._cache: Dict[str, _CacheEntry] = {}

        # 指标
        self._metrics: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

        # 配置
        self._config: Dict[str, Any] = {}
        self._default_config: Dict[str, Any] = {}
        self._config_version: int = 1

        # 事件
        self._event_handlers: Dict[str, Callable[[Any], None]] = {}

        # 统计
        self._stats: Dict[str, int] = defaultdict(int)

        # 状态机
        self._states: List[str] = ["idle", "running", "paused", "stopped", "error"]
        self._current_state: str = "idle"
        self._initial_state: str = "idle"
        self._state_history: List[Tuple[str, str, float]] = []
        self._transitions: List[Tuple[str, str, float]] = []

        # 任务与工作者
        self._tasks: Dict[str, Dict[str, Any]] = {}
        self._workers: Dict[str, Dict[str, Any]] = {}

        # 模型注册
        self._registry: Dict[str, Any] = {}

        # 并发锁
        self._lock: threading.RLock = threading.RLock()

    # ------------------------------------------------------------------
    # 项目 CRUD
    # ------------------------------------------------------------------

    def create_item(self, data: Dict[str, Any]) -> str:
        """创建视觉感知项目。

        Args:
            data: 项目数据。

        Returns:
            新项目的唯一 ID。
        """
        item_id = _generate_id("vision_item")
        record = {
            "id": item_id,
            "data": data,
            "created_at": time.time(),
            "updated_at": time.time(),
            "version": 1,
        }
        with self._lock:
            self._item_store[item_id] = record
            self._stats["item_created"] += 1
        self._logger.debug("Created vision item %s", item_id)
        return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取指定项目。

        Args:
            item_id: 项目 ID。

        Returns:
            项目数据字典，不存在则返回 None。
        """
        with self._lock:
            record = self._item_store.get(item_id)
        if record:
            return dict(record["data"])
        return None

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新指定项目。

        Args:
            item_id: 项目 ID。
            data: 更新字段。

        Returns:
            是否成功。
        """
        with self._lock:
            if item_id in self._item_store:
                record = self._item_store[item_id]
                record["data"].update(data)
                record["updated_at"] = time.time()
                record["version"] += 1
                self._stats["item_updated"] += 1
                self._logger.debug("Updated vision item %s (v%d)", item_id, record["version"])
                return True
        return False

    def delete_item(self, item_id: str) -> bool:
        """删除指定项目。

        Args:
            item_id: 项目 ID。

        Returns:
            是否成功。
        """
        with self._lock:
            if item_id in self._item_store:
                del self._item_store[item_id]
                self._stats["item_deleted"] += 1
                self._logger.debug("Deleted vision item %s", item_id)
                return True
        return False

    def list_items(
        self,
        page: int = 1,
        page_size: int = 20,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """分页列出项目。

        Args:
            page: 页码（从 1 开始）。
            page_size: 每页数量。
            filters: 过滤条件字典，键为数据字段名。

        Returns:
            包含 items、total、page、page_size 的字典。
        """
        with self._lock:
            items = list(self._item_store.values())

        if filters:
            items = [
                it for it in items
                if all(it["data"].get(k) == v for k, v in filters.items())
            ]

        total = len(items)
        start = max(0, (page - 1) * page_size)
        end = start + page_size
        return {
            "items": [dict(it["data"]) for it in items[start:end]],
            "total": total,
            "page": page,
            "page_size": page_size,
        }

    def count_items(self) -> int:
        """统计项目总数。

        Returns:
            项目数量。
        """
        with self._lock:
            return len(self._item_store)

    def search_items(
        self,
        query: str,
        fields: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """按关键词搜索项目。

        Args:
            query: 搜索关键词（不区分大小写）。
            fields: 限定搜索的字段列表，None 表示搜索所有字段。

        Returns:
            匹配的项目数据列表。
        """
        results: List[Dict[str, Any]] = []
        q = query.lower()
        with self._lock:
            for record in self._item_store.values():
                data = record["data"]
                search_fields = fields if fields is not None else list(data.keys())
                for f in search_fields:
                    val = str(data.get(f, "")).lower()
                    if q in val:
                        results.append(dict(data))
                        break
        return results

    def batch_create_items(self, batch: List[Dict[str, Any]]) -> List[str]:
        """批量创建项目。

        Args:
            batch: 项目数据列表。

        Returns:
            创建的项目 ID 列表。
        """
        ids: List[str] = []
        for item_data in batch:
            ids.append(self.create_item(item_data))
        self._logger.info("Batch created %d items", len(ids))
        return ids

    def batch_delete_items(self, ids: List[str]) -> int:
        """批量删除项目。

        Args:
            ids: 项目 ID 列表。

        Returns:
            成功删除的数量。
        """
        count = 0
        for item_id in ids:
            if self.delete_item(item_id):
                count += 1
        self._logger.info("Batch deleted %d items", count)
        return count

    def export_items(self, path: str) -> str:
        """导出所有项目到 JSON 文件。

        Args:
            path: 目标文件路径。

        Returns:
            实际写入的文件路径。
        """
        with self._lock:
            data = [dict(rec) for rec in self._item_store.values()]
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        except IOError as e:
            self._logger.error("Failed to export items to %s: %s", path, e)
            raise
        self._logger.info("Exported %d items to %s", len(data), path)
        return path

    def import_items(self, path: str) -> int:
        """从 JSON 文件导入项目。

        Args:
            path: 源文件路径。

        Returns:
            导入的项目数量。
        """
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (IOError, json.JSONDecodeError) as e:
            self._logger.error("Failed to read file %s: %s", path, e)
            raise

        count = 0
        with self._lock:
            for record in data:
                item_id = record.get("id") or _generate_id("vision_item")
                self._item_store[item_id] = record
                count += 1
        self._logger.info("Imported %d items from %s", count, path)
        return count

    def get_item_stats(self) -> Dict[str, int]:
        """获取项目统计信息。

        Returns:
            包含 total、created、updated、deleted 的字典。
        """
        with self._lock:
            total = len(self._item_store)
        return {
            "total": total,
            "created": self._stats.get("item_created", 0),
            "updated": self._stats.get("item_updated", 0),
            "deleted": self._stats.get("item_deleted", 0),
        }

    # ------------------------------------------------------------------
    # 缓存管理
    # ------------------------------------------------------------------

    def get_cache(self, key: str) -> Optional[Any]:
        """获取缓存值，自动清除过期项。

        Args:
            key: 缓存键。

        Returns:
            缓存值，未命中或过期返回 None。
        """
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            if entry.is_expired():
                del self._cache[key]
                return None
            return entry.value

    def set_cache(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """设置缓存值。

        Args:
            key: 缓存键。
            value: 缓存值。
            ttl: 存活时间（秒），默认 300 秒。
        """
        with self._lock:
            self._cache[key] = _CacheEntry(value=value, created_at=time.monotonic(), ttl=ttl)
            if len(self._cache) > self._MAX_CACHE_SIZE:
                self._evict_oldest()

    def invalidate_cache(self, key: str) -> bool:
        """使指定缓存键失效。

        Args:
            key: 缓存键。

        Returns:
            是否成功移除。
        """
        with self._lock:
            removed = self._cache.pop(key, None) is not None
        if removed:
            self._logger.debug("Invalidated cache key: %s", key)
        return removed

    def clear_cache(self) -> int:
        """清空所有缓存。

        Returns:
            被清除的缓存条目数。
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
        self._logger.info("Cleared %d cache entries", count)
        return count

    def get_cache_stats(self) -> Dict[str, Any]:
        """获取缓存统计信息。

        Returns:
            包含 size、max_size 的字典。
        """
        with self._lock:
            return {"size": len(self._cache), "max_size": self._MAX_CACHE_SIZE}

    def _evict_oldest(self) -> None:
        """驱逐最旧的缓存条目（调用方需持有锁）。"""
        if not self._cache:
            return
        oldest_key = min(self._cache, key=lambda k: self._cache[k].created_at)
        del self._cache[oldest_key]
        self._logger.debug("Evicted oldest cache entry: %s", oldest_key)

    # ------------------------------------------------------------------
    # 指标记录与统计
    # ------------------------------------------------------------------

    def record_metric(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录一个指标值。

        当同一标签组下的数据点超过阈值时，自动截断保留最近的数据。

        Args:
            value: 指标数值。
            labels: 标签字典，用于分组。
        """
        key = _metric_key(labels)
        with self._lock:
            series = self._metrics[key]
            series.append({
                "value": value,
                "time": time.time(),
                "labels": dict(labels) if labels else {},
            })
            if len(series) > self._MAX_METRIC_POINTS:
                self._metrics[key] = series[-self._KEEP_METRIC_POINTS:]

    def get_metric_stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, float]:
        """获取指标统计数据。

        Args:
            labels: 标签字典。

        Returns:
            包含 count、mean、min、max、p50、p95、p99 的字典。
        """
        key = _metric_key(labels)
        with self._lock:
            values = [e["value"] for e in self._metrics.get(key, [])]

        if not values:
            return {
                "count": 0,
                "mean": 0.0,
                "min": 0.0,
                "max": 0.0,
                "p50": 0.0,
                "p95": 0.0,
                "p99": 0.0,
            }

        sorted_vals = sorted(values)
        n = len(sorted_vals)

        def _percentile(p: float) -> float:
            idx = min(int(n * p), n - 1)
            return sorted_vals[idx]

        return {
            "count": n,
            "mean": statistics.mean(values),
            "min": sorted_vals[0],
            "max": sorted_vals[-1],
            "p50": _percentile(0.50),
            "p95": _percentile(0.95),
            "p99": _percentile(0.99),
        }

    def get_metric_history(
        self,
        labels: Optional[Dict[str, Any]] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """获取指标历史数据。

        Args:
            labels: 标签字典。
            limit: 返回最近 N 条。

        Returns:
            指标数据列表。
        """
        key = _metric_key(labels)
        with self._lock:
            return list(self._metrics.get(key, []))[-limit:]

    def reset_metrics(self) -> None:
        """重置所有指标数据。"""
        with self._lock:
            self._metrics.clear()
        self._logger.info("All metrics reset")

    # ------------------------------------------------------------------
    # 配置管理
    # ------------------------------------------------------------------

    def get_config(self, key: str, default: Any = None) -> Any:
        """获取配置项。

        Args:
            key: 配置键。
            default: 不存在时的默认值。

        Returns:
            配置值或默认值。
        """
        with self._lock:
            return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """设置配置项。

        Args:
            key: 配置键。
            value: 配置值。
        """
        with self._lock:
            self._config[key] = value
            self._config_version += 1
        self._logger.debug("Config set: %s", key)

    def get_all_config(self) -> Dict[str, Any]:
        """获取全部配置的副本。

        Returns:
            配置字典。
        """
        with self._lock:
            return dict(self._config)

    def update_config(self, updates: Dict[str, Any]) -> None:
        """批量更新配置。

        Args:
            updates: 要更新的键值对。
        """
        with self._lock:
            self._config.update(updates)
            self._config_version += 1
        self._logger.info("Config updated with %d keys", len(updates))

    def reset_config(self) -> None:
        """重置配置为默认值。"""
        with self._lock:
            self._config = dict(self._default_config)
            self._config_version += 1
        self._logger.info("Config reset to defaults")

    def get_config_version(self) -> int:
        """获取当前配置版本号。

        Returns:
            版本号。
        """
        return self._config_version
