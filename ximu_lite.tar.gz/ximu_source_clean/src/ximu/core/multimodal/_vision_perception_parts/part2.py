"""
Part 2 of vision_perception: SceneRecognizer 核心模块重写。
提供场景识别器功能，实现数据管理、性能监控、配置管理和事件通知。
"""

import json
import time
import asyncio
import logging
import threading
import statistics
from typing import Any, Dict, List, Optional, Callable
from collections import OrderedDict, deque
from pathlib import Path
from src.ximu.common.utils import generate_id

def _setup_logger(name: str) -> logging.Logger:
    """
    创建并返回配置好的日志记录器。

    Args:
    name: 日志记录器名称

    Returns:
    配置好的日志记录器实例
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)
    return logger


class _KVCache:
    """
    基于 LRU 策略的键值缓存，支持 TTL 过期机制。
    """

    def __init__(self, max_size: int = 10000, default_ttl: float = 300.0) -> None:
        """
        初始化缓存。

        Args:
        max_size: 缓存最大容量
        default_ttl: 默认过期时间（秒）
        """
        self._max_size = max(1, max_size)
        self._default_ttl = default_ttl
        self._store: "OrderedDict[str, Dict[str, Any]]" = OrderedDict()
        self._lock = threading.RLock()
        self._hits = 0
        self._misses = 0

    def get(self, key: str) -> Optional[Any]:
        """
        获取键值，若过期或不存在则返回 None。

        Args:
        key: 缓存键

        Returns:
        缓存值，不存在或已过期返回 None
        """
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                self._misses += 1
                return None
            now = time.monotonic()
            if now - entry["ts"] >= entry["ttl"]:
                del self._store[key]
                self._misses += 1
                return None
            self._store.move_to_end(key)
            self._hits += 1
            return entry["value"]

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """
        设置键值，ttl 为 None 时采用默认值。

        Args:
        key: 缓存键
        value: 缓存值
        ttl: 过期时间（秒），None 使用默认值
        """
        with self._lock:
            actual_ttl = self._default_ttl if ttl is None else max(0.0, ttl)
            if key in self._store:
                self._store.move_to_end(key)
            else:
                if len(self._store) >= self._max_size:
                    self._store.popitem(last=False)
                self._store[key] = {"value": value, "ts": time.monotonic(), "ttl": actual_ttl}

    def invalidate(self, key: str) -> bool:
        """
        移除指定键，若存在则返回 True。

        Args:
        key: 要移除的缓存键

        Returns:
        是否成功移除
        """
        with self._lock:
            return self._store.pop(key, None) is not None

    def clear(self) -> int:
        """
        清空缓存，返回清除条数。

        Returns:
        清除的缓存条目数
        """
        with self._lock:
            count = len(self._store)
            self._store.clear()
            return count

    def stats(self) -> Dict[str, Any]:
        """
        返回缓存统计信息。

        Returns:
        包含大小、命中率的统计字典
        """
        with self._lock:
            total = self._hits + self._misses
            return {
                "size": len(self._store),
                "max_size": self._max_size,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": self._hits / total if total > 0 else 0.0,
            }


class _MetricsRegistry:
    """
    带滑动窗口上限的指标统计。
    """

    def __init__(self, max_window: int = 5000) -> None:
        """
        初始化指标注册表。

        Args:
        max_window: 滑动窗口最大样本数
        """
        self._max_window = max(1, max_window)
        self._store: Dict[str, deque] = {}
        self._lock = threading.RLock()

    def record(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """
        记录一个指标样本。

        Args:
        value: 指标值
        labels: 标签字典，用于区分不同维度的指标
        """
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True, default=str)
            if key not in self._store:
                self._store[key] = deque(maxlen=self._max_window)
            self._store[key].append({"value": value, "ts": time.time()})

    def stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        计算均值、百分位等统计量。

        Args:
        labels: 标签字典，None 表示所有标签合并统计

        Returns:
        包含 count、mean、min、max、p50、p95、p99 的统计字典
        """
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True, default=str)
            samples = list(self._store.get(key, []))
            if not samples:
                return {
                    "count": 0,
                    "mean": 0.0,
                    "min": 0.0,
                    "max": 0.0,
                    "p50": 0.0,
                    "p95": 0.0,
                    "p99": 0.0,
                }
            values = [s["value"] for s in samples]
            sv = sorted(values)
            n = len(sv)

            def _pct(p: float) -> float:
                if n <= 1:
                    return float(sv[0])
                idx = int(n * p)
                idx = min(max(idx, 0), n - 1)
                return float(sv[idx])

            return {
                "count": n,
                "mean": statistics.mean(values),
                "min": min(values),
                "max": max(values),
                "p50": _pct(0.5),
                "p95": _pct(0.95),
                "p99": _pct(0.99),
            }

    def history(self, labels: Optional[Dict[str, Any]] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """
        返回最近 limit 条历史。

        Args:
        labels: 标签字典
        limit: 返回的最大历史记录数

        Returns:
        最近的历史记录列表
        """
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True, default=str)
            return list(self._store.get(key, []))[-max(1, limit):]

    def reset(self) -> None:
        """
        清空所有指标。
        """
        with self._lock:
            self._store.clear()


class _ConfigManager:
    """
    配置版本管理与批量操作。
    """

    def __init__(self) -> None:
        """
        初始化配置管理器。
        """
        self._config: Dict[str, Any] = {}
        self._defaults: Dict[str, Any] = {}
        self._version: int = 1
        self._lock = threading.RLock()

    def set_default(self, key: str, value: Any) -> None:
        """
        设置配置默认值。

        Args:
        key: 配置键
        value: 配置默认值
        """
        with self._lock:
            self._defaults[key] = value

    def get(self, key: str, default: Optional[Any] = None) -> Any:
        """
        获取配置值。

        Args:
        key: 配置键
        default: 默认返回值

        Returns:
        配置值或默认值
        """
        with self._lock:
            return self._config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """
        设置配置值。

        Args:
        key: 配置键
        value: 配置值
        """
        with self._lock:
            self._config[key] = value
            self._version += 1

    def update(self, updates: Dict[str, Any]) -> None:
        """
        批量更新配置。

        Args:
        updates: 配置更新字典
        """
        with self._lock:
            self._config.update(updates)
            self._version += 1

    def all(self) -> Dict[str, Any]:
        """
        获取全部配置。

        Returns:
        配置字典副本
        """
        with self._lock:
            return dict(self._config)

    def reset(self) -> None:
        """
        重置配置为默认值。
        """
        with self._lock:
            self._config = dict(self._defaults)
            self._version += 1

    def version(self) -> int:
        """
        获取当前配置版本号。

        Returns:
        配置版本号
        """
        return self._version


class _EventBus:
    """
    轻量级事件分发。
    """

    def __init__(self) -> None:
        """
        初始化事件总线。
        """
        self._handlers: Dict[str, Callable[[Any], None]] = {}
        self._logger = logging.getLogger(__name__)
        self._lock = threading.RLock()

    def on(self, handler: Callable[[Any], None]) -> str:
        """
        注册事件处理器。

        Args:
        handler: 事件处理函数

        Returns:
        处理器唯一标识符
        """
        handler_id = generate_id("evt_handler")
        with self._lock:
            self._handlers[handler_id] = handler
        return handler_id

    def off(self, handler_id: str) -> bool:
        """
        移除事件处理器。

        Args:
        handler_id: 处理器标识符

        Returns:
        是否成功移除
        """
        with self._lock:
            return self._handlers.pop(handler_id, None) is not None

    def emit(self, data: Any = None) -> int:
        """
        触发事件，调用所有注册的处理函数。

        Args:
        data: 事件数据

        Returns:
        成功执行的处理函数数量
        """
        with self._lock:
            handlers = list(self._handlers.values())
            count = 0
            for h in handlers:
                try:
                    h(data)
                    count += 1
                except Exception:
                    self._logger.exception("Event handler raised exception")
                    return count
            return count

    def handler_count(self) -> int:
        """
        获取注册的处理函数数量。

        Returns:
        处理函数数量
        """
        with self._lock:
            return len(self._handlers)

    def clear(self) -> None:
        """
        清空所有事件处理器。
        """
        with self._lock:
            self._handlers.clear()


class SceneRecognizer:
    """
    场景识别器：封装数据 CRUD、缓存、指标、配置、事件分发与生命周期管理。
    提供完整的场景识别功能，支持数据的增删改查、性能指标统计、配置管理以及事件驱动的通知机制。
    """

    def __init__(
        self,
        cache_max_size: int = 10000,
        cache_default_ttl: float = 300.0,
        metrics_max_window: int = 5000,
    ) -> None:
        """
        初始化场景识别器。

        Args:
        cache_max_size: 缓存最大容量
        cache_default_ttl: 缓存默认过期时间（秒）
        metrics_max_window: 指标滑动窗口大小
        """
        self._logger = _setup_logger(self.__class__.__name__)
        self._lock = threading.RLock()
        self._item_store: Dict[str, Dict[str, Any]] = {}
        self._stats: Dict[str, int] = {
            "scenerecognizer_item_created": 0,
            "scenerecognizer_item_updated": 0,
            "scenerecognizer_item_deleted": 0,
        }
        self._cache = _KVCache(max_size=cache_max_size, default_ttl=cache_default_ttl)
        self._metrics = _MetricsRegistry(max_window=metrics_max_window)
        self._config = _ConfigManager()
        self._events = _EventBus()
        self._initialized = False
        self._status: str = "idle"
        self._start_time = 0.0
        self._states: List[str] = ["idle", "running", "paused", "stopped", "error"]
        self._current_state: str = "idle"
        self._initial_state: str = "idle"
        self._state_history: List[Dict[str, Any]] = []
        self._transitions: List[Dict[str, Any]] = []

    # ------------------------------------------------------------------
    # CRUD 操作
    # ------------------------------------------------------------------

    def create_item(self, data: Dict[str, Any]) -> str:
        """
        创建场景识别条目。

        Args:
        data: 条目数据字典

        Returns:
        生成的条目唯一标识符
        """
        item_id = generate_id("scenerecognizer_item")
        now = time.time()
        record = {
            "id": item_id,
            "data": data,
            "created_at": now,
            "updated_at": now,
            "version": 1,
        }
        with self._lock:
            self._item_store[item_id] = record
            self._stats["scenerecognizer_item_created"] += 1
            self._logger.debug("Created item %s", item_id)
        return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """
        获取条目数据。

        Args:
        item_id: 条目标识符

        Returns:
        条目数据字典，不存在返回 None
        """
        with self._lock:
            record = self._item_store.get(item_id)
            return record["data"] if record else None

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """
        更新条目，成功返回 True。

        Args:
        item_id: 条目标识符
        data: 条目数据字典

        Returns:
        是否成功更新
        """
        with self._lock:
            record = self._item_store.get(item_id)
            if record:
                record["data"] = data
                record["updated_at"] = time.time()
                record["version"] += 1
                self._stats["scenerecognizer_item_updated"] += 1
                self._logger.debug("Updated item %s", item_id)
                return True
            return False

    def delete_item(self, item_id: str) -> bool:
        """
        删除条目，成功返回 True。

        Args:
        item_id: 条目标识符

        Returns:
        是否成功删除
        """
        with self._lock:
            if item_id in self._item_store:
                del self._item_store[item_id]
                self._stats["scenerecognizer_item_deleted"] += 1
                self._logger.debug("Deleted item %s", item_id)
                return True
            return False

    def is_healthy(self) -> bool:
        """
        健康检查。

        Returns:
        是否健康
        """
        if not self._initialized or self._status == "error":
            return False
        return True

    def uptime(self) -> float:
        """
        返回运行时长（秒）。

        Returns:
        运行时长
        """
        if not self._initialized:
            return 0.0
        return time.monotonic() - self._start_time

    # ------------------------------------------------------------------
    # 数据处理
    # ------------------------------------------------------------------

    def process(self, data: Any) -> Any:
        """
        处理数据（子类可重写）。

        Args:
        data: 输入数据

        Returns:
        处理结果
        """
        return data

    async def async_initialize(self) -> bool:
        """
        异步初始化。

        Returns:
        是否初始化成功
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.initialize)

    async def async_shutdown(self) -> bool:
        """
        异步关闭。

        Returns:
        是否关闭成功
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.shutdown)

    async def async_process(self, data: Any) -> Any:
        """
        异步处理。

        Args:
        data: 输入数据

        Returns:
        处理结果
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.process, data)

    async def async_batch_process(self, items: List[Any], concurrency: int = 4) -> List[Any]:
        """
        异步并发批量处理。

        Args:
        items: 待处理数据列表
        concurrency: 并发数

        Returns:
        处理结果列表
        """
        semaphore = asyncio.Semaphore(max(1, concurrency))

        async def _one(item: Any) -> Any:
            async with semaphore:
                return await self.async_process(item)

        return await asyncio.gather(*[_one(i) for i in items])
