"""Part 3 of vision_perception: 图像描述生成器核心功能实现。

提供图像描述生成器的状态管理、缓存、指标统计及配置处理功能。
采用 LRU 缓存策略优化性能，设置指标上限防止内存泄漏，
并完善事件系统以支持完整的生命周期管理。
"""

import json
import time
import threading
from typing import Any, Dict, List, Optional, Tuple, Callable, Union, Protocol
from collections import OrderedDict, defaultdict
from pathlib import Path
from copy import deepcopy
import logging

from src.ximu.common.utils import generate_id

# 获取或创建模块日志记录器
_logger = logging.getLogger(__name__)

# ------------------------------ 缓存模块 ------------------------------ #

class LRU_Cache:
    """基于 LRU 策略的线程安全缓存管理器。

    支持 TTL 过期机制和容量限制，防止内存泄漏。
    """

    def __init__(self, max_size: int = 10000, default_ttl: float = 300.0) -> None:
        """初始化 LRU 缓存。

        Args:
            max_size: 缓存最大容量。
            default_ttl: 默认缓存过期时间（秒）。
        """
        self._cache: OrderedDict[str, Dict[str, Any]] = OrderedDict()
        self._max_size = max(1, int(max_size))  # 确保容量至少为1
        self._default_ttl = max(0.0, float(default_ttl))  # 确保TTL非负
        self._lock = threading.RLock()

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值，自动淘汰过期或超出容量的条目。

        Args:
            key: 缓存键。

        Returns:
            缓存值，若不存在或过期则返回 None。
        """
        with self._lock:
            entry = self._cache.get(key)
            if not entry:
                return None

            now = time.monotonic()
            if now - entry["time"] > entry["ttl"]:
                self._cache.pop(key, None)
                _logger.debug(f"缓存过期: {key}")
                return None

            self._cache.move_to_end(key)
            return entry["value"]

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """设置缓存值。

        Args:
            key: 缓存键。
            value: 缓存值。
            ttl: 过期时间（秒），None 表示使用默认值。
        """
        effective_ttl = self._default_ttl if ttl is None else max(0.0, float(ttl))
        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)

            self._cache[key] = {
                "value": value,
                "time": time.monotonic(),
                "ttl": effective_ttl
            }

            # 维护容量限制
            while len(self._cache) > self._max_size:
                oldest_key, _ = self._cache.popitem(last=False)
                _logger.debug(f"缓存淘汰: {oldest_key}")

    def invalidate(self, key: str) -> bool:
        """使指定缓存键失效。

        Args:
            key: 缓存键。

        Returns:
            是否成功失效。
        """
        with self._lock:
            return self._cache.pop(key, None) is not None

    def clear(self) -> int:
        """清空所有缓存。

        Returns:
            被清空的条目数。
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
            return count

    def stats(self) -> Dict[str, Any]:
        """获取缓存统计信息。

        Returns:
            包含 size 和 max_size 的字典。
        """
        with self._lock:
            return {"size": len(self._cache), "max_size": self._max_size}


# ------------------------------ 指标模块 ------------------------------ #

class Metrics_Recorder:
    """带内存上限保护的指标记录器。

    使用滑动窗口策略防止内存无限增长，支持百分位数统计。
    """

    MAX_ENTRIES_PER_KEY = 5000
    PRUNE_THRESHOLD = 10000

    def __init__(self) -> None:
        """初始化指标存储。"""
        self._data: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._lock = threading.RLock()

    @staticmethod
    def _generate_key(labels: Optional[Dict[str, Any]]) -> str:
        """生成基于标签的唯一键。

        Args:
            labels: 标签字典。

        Returns:
            JSON字符串键。
        """
        return json.dumps(labels or {}, sort_keys=True, separators=(',', ':'))

    def record(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录指标值。

        Args:
            value: 指标数值。
            labels: 标签。
        """
        key = self._generate_key(labels)
        with self._lock:
            bucket = self._data[key]
            bucket.append({
                "value": float(value),
                "time": time.time(),
                "labels": deepcopy(labels) if labels else {}
            })
            # 内存保护：超过阈值时裁剪
            if len(bucket) > self.PRUNE_THRESHOLD:
                self._data[key] = bucket[-self.MAX_ENTRIES_PER_KEY:]

    def get_stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """获取指标统计。

        Args:
            labels: 标签。

        Returns:
            统计字典。
        """
        key = self._generate_key(labels)
        with self._lock:
            values = [e["value"] for e in self._data.get(key, [])]

        if not values:
            return {"count": 0, "mean": 0.0, "min": 0.0, "max": 0.0, "p50": 0.0, "p95": 0.0, "p99": 0.0}

        sorted_vals = sorted(values)
        n = len(sorted_vals)
        
        def _percentile(data: List[float], p: float) -> float:
            """计算指定百分位值。"""
            if not data:
                return 0.0
            index = int(p * len(data))
            index = min(index, len(data) - 1)
            return data[index]

        return {
            "count": n,
            "mean": sum(sorted_vals) / n,
            "min": sorted_vals[0],
            "max": sorted_vals[-1],
            "p50": _percentile(sorted_vals, 0.5),
            "p95": _percentile(sorted_vals, 0.95),
            "p99": _percentile(sorted_vals, 0.99),
        }

    def get_history(self, labels: Optional[Dict[str, Any]] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """获取指标历史。

        Args:
            labels: 标签。
            limit: 最大条数。

        Returns:
            历史记录列表。
        """
        key = self._generate_key(labels)
        limit = max(1, int(limit))
        with self._lock:
            return [dict(item) for item in self._data.get(key, [])[-limit:]]

    def reset(self) -> None:
        """重置所有指标。"""
        with self._lock:
            self._data.clear()


# ------------------------------ 配置模块 ------------------------------ #

class Config_Manager:
    """线程安全的配置管理器，支持版本控制和导出导入。"""

    def __init__(self) -> None:
        """初始化配置。"""
        self._config: Dict[str, Any] = {}
        self._version: int = 1
        self._lock = threading.RLock()

    def get(self, key: str, default: Any = None) -> Any:
        """获取配置项。

        Args:
            key: 配置键。
            default: 默认值。

        Returns:
            配置值或默认值。
        """
        with self._lock:
            return self._config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """设置单个配置项。

        Args:
            key: 配置键。
            value: 配置值。
        """
        with self._lock:
            self._config[key] = value
            self._version += 1

    def get_all(self) -> Dict[str, Any]:
        """获取全部配置的副本。

        Returns:
            配置字典副本。
        """
        with self._lock:
            return deepcopy(self._config)

    def update(self, updates: Dict[str, Any]) -> None:
        """批量更新配置。

        Args:
            updates: 待更新的键值对。
        """
        with self._lock:
            for k, v in updates.items():
                self._config[k] = v
            self._version += 1

    def reset(self, defaults: Optional[Dict[str, Any]] = None) -> None:
        """重置配置。

        Args:
            defaults: 重置后的默认值。
        """
        with self._lock:
            self._config = deepcopy(defaults) if defaults else {}
            self._version += 1

    def version(self) -> int:
        """获取配置版本号。

        Returns:
            当前版本。
        """
        return self._version

    def export(self, path: Union[str, Path]) -> str:
        """导出配置到 JSON 文件。

        Args:
            path: 目标路径。

        Returns:
            实际路径字符串。

        Raises:
            OSError: 当文件写入失败时。
        """
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("w", encoding="utf-8") as f:
            json.dump(self.get_all(), f, ensure_ascii=False, indent=2, default=str)
        _logger.info(f"配置已导出到: {p}")
        return str(p)

    def import_config(self, path: Union[str, Path]) -> bool:
        """从 JSON 文件导入配置。

        Args:
            path: 源路径。

        Returns:
            是否导入成功。
        """
        p = Path(path)
        try:
            with p.open("r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                _logger.error(f"配置导入失败: 根元素必须是字典, 实际为 {type(data).__name__}")
                return False
            self.update(data)
            _logger.info(f"配置已从 {p} 导入成功")
            return True
        except (json.JSONDecodeError, OSError) as e:
            _logger.error(f"配置导入失败: {e}")
            return False


# ------------------------------ 事件总线 ------------------------------ #

class Event_Bus:
    """轻量级线程安全事件总线。"""

    def __init__(self) -> None:
        """初始化事件总线。"""
        self._handlers: Dict[str, Callable[[Any], None]] = {}
        self._lock = threading.RLock()

    def on(self, handler: Callable[[Any], None]) -> str:
        """注册事件处理器。

        Args:
            handler: 处理函数。

        Returns:
            处理器 ID。
        """
        handler_id = generate_id("event_handler")
        with self._lock:
            self._handlers[handler_id] = handler
        return handler_id

    def off(self, handler_id: str) -> bool:
        """移除事件处理器。

        Args:
            handler_id: 处理器 ID。

        Returns:
            是否移除成功。
        """
        with self._lock:
            return self._handlers.pop(handler_id, None) is not None

    def emit(self, data: Any = None) -> int:
        """触发事件，调用所有处理器。

        Args:
            data: 事件数据。

        Returns:
            成功调用的处理器数量。
        """
        with self._lock:
            handlers = list(self._handlers.values())
        
        count = 0
        for handler in handlers:
            try:
                handler(data)
                count += 1
            except Exception as e:
                _logger.warning(f"事件处理器执行异常: {e}")
        return count

    def clear(self) -> None:
        """清空所有处理器。"""
        with self._lock:
            self._handlers.clear()

    def __len__(self) -> int:
        """获取处理器数量。"""
        with self._lock:
            return len(self._handlers)


# ------------------------------ 核心模块 ------------------------------ #

class ImageCaptioner:
    """图像描述生成器核心类，封装资源管理、缓存、指标、配置与事件。

    提供完整的项管理、缓存代理、指标代理、配置代理和事件系统。
    """

    VALID_STATES = ("idle", "running", "paused", "stopped", "error")

    def __init__(
        self,
        max_cache_size: int = 10000,
        default_ttl: float = 300.0,
        max_length: int = 100,
        caption_model: Optional[Any] = None,
    ) -> None:
        """初始化 ImageCaptioner。

        Args:
            max_cache_size: 缓存最大容量。
            default_ttl: 默认缓存 TTL。
            max_length: 生成描述的最大长度。
            caption_model: 可选的描述模型实例。
        """
        self._cache = LRU_Cache(max_cache_size, default_ttl)
        self._metrics = Metrics_Recorder()
        self._config = Config_Manager()
        self._event_bus = Event_Bus()
        
        self._status = "idle"
        self._state_history: List[Tuple[str, float]] = []
        self._transitions: List[Tuple[str, str, float]] = []
        self._initialized = False
        self._start_time = 0.0
        self._items: Dict[str, Dict[str, Any]] = {}
        self._stats: Dict[str, int] = defaultdict(int)
        self._lock = threading.RLock()
        
        self._max_length = max(1, int(max_length))
        self._caption_model = caption_model

    # ------------------------------ 项管理 ------------------------------ #

    def create_item(self, data: Dict[str, Any]) -> str:
        """创建图像描述项。

        Args:
            data: 项数据。

        Returns:
            新项的 ID。

        Raises:
            ValueError: 当数据不是字典时。
        """
        if not isinstance(data, dict):
            raise ValueError(f"项数据必须是字典, 实际为 {type(data).__name__}")
        
        with self._lock:
            item_id = generate_id("imagecaptioner_item")
            record = {
                "id": item_id,
                "data": deepcopy(data),
                "created_at": time.time(),
                "updated_at": time.time(),
                "version": 1
            }
            self._items[item_id] = record
            self._stats["item_created"] += 1
            self._event_bus.emit({"type": "item_created", "id": item_id})
        
        _logger.info(f"创建项: {item_id}")
        return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取指定项。

        Args:
            item_id: 项 ID。

        Returns:
            项数据副本或 None。
        """
        with self._lock:
            record = self._items.get(item_id)
            if record:
                return deepcopy(record["data"])
        return None

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新指定项。

        Args:
            item_id: 项 ID。
            data: 更新数据。

        Returns:
            是否更新成功。
        """
        if not isinstance(data, dict):
            _logger.warning(f"更新项数据必须是字典, 实际为 {type(data).__name__}")
            return False
            
        with self._lock:
            if item_id not in self._items:
                _logger.warning(f"项不存在: {item_id}")
                return False
            record = self._items[item_id]
            record["data"].update(deepcopy(data))
            record["updated_at"] = time.time()
            record["version"] += 1
            self._stats["item_updated"] += 1
            self._event_bus.emit({"type": "item_updated", "id": item_id})
        
        _logger.info(f"更新项: {item_id}")
        return True

    def delete_item(self, item_id: str) -> bool:
        """删除指定项。

        Args:
            item_id: 项 ID。

        Returns:
            是否删除成功。
        """
        with self._lock:
            if item_id not in self._items:
                _logger.warning(f"删除失败, 项不存在: {item_id}")
                return False
            del self._items[item_id]
            self._stats["item_deleted"] += 1
            self._event_bus.emit({"type": "item_deleted", "id": item_id})
        
        _logger.info(f"删除项: {item_id}")
        return True

    def list_items(
        self,
        page: int = 1,
        page_size: int = 20,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """分页列出项。

        Args:
            page: 页码（从 1 开始）。
            page_size: 每页数量。
            filters: 过滤条件。

        Returns:
            包含 items, total, page, page_size 的字典。
        """
        page = max(1, int(page))
        page_size = max(1, int(page_size))
        
        with self._lock:
            items = [deepcopy(r["data"]) for r in self._items.values()]

        if filters:
            items = [it for it in items if all(it.get(k) == v for k, v in filters.items())]

        total = len(items)
        start = (page - 1) * page_size
        end = start + page_size
        return {
            "items": items[start:end],
            "total": total,
            "page": page,
            "page_size": page_size,
        }

    def count_items(self) -> int:
        """统计项总数。

        Returns:
            项数量。
        """
        with self._lock:
            return len(self._items)

    def search_items(self, query: str, fields: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """在指定字段中搜索项。

        Args:
            query: 搜索关键词（不区分大小写）。
            fields: 搜索字段列表，None 表示全部字段。

        Returns:
            匹配的项数据列表。
        """
        if not query:
            return []
            
        q = query.lower()
        results: List[Dict[str, Any]] = []
        with self._lock:
            for record in self._items.values():
                data = record["data"]
                search_fields = fields if fields is not None else list(data.keys())
                for f in search_fields:
                    if f in data and q in str(data.get(f, "")).lower():
                        results.append(deepcopy(data))
                        break
        return results

    def batch_create(self, batch: List[Dict[str, Any]]) -> List[str]:
        """批量创建项。

        Args:
            batch: 数据列表。

        Returns:
            创建的项 ID 列表。
        """
        if not batch:
            return []
        return [self.create_item(item) for item in batch]

    def batch_delete(self, ids: List[str]) -> int:
        """批量删除项。

        Args:
            ids: 项 ID 列表。

        Returns:
            成功删除的数量。
        """
        if not ids:
            return 0
        count = 0
        for item_id in ids:
            if self.delete_item(item_id):
                count += 1
        return count

    def export_items(self, path: Union[str, Path]) -> str:
        """导出所有项到 JSON 文件。

        Args:
            path: 目标路径。

        Returns:
            实际路径字符串。
        """
        with self._lock:
            data = [deepcopy(r) for r in self._items.values()]
        
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        _logger.info(f"已导出 {len(data)} 个项到 {p}")
        return str(p)

    def import_items(self, path: Union[str, Path]) -> int:
        """从 JSON 文件导入项。

        Args:
            path: 源路径。

        Returns:
            导入的项数。
        """
        p = Path(path)
        try:
            with p.open("r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            _logger.error(f"项导入失败: {e}")
            return 0
        
        if not isinstance(data, list):
            _logger.error(f"项导入失败: 根元素必须是列表, 实际为 {type(data).__name__}")
            return 0
            
        count = 0
        with self._lock:
            for record in data:
                if not isinstance(record, dict):
                    continue
                item_id = record.get("id") or generate_id("imagecaptioner_item")
                self._items[item_id] = record
                count += 1
        
        _logger.info(f"已导入 {count} 个项")
        return count

    def get_item_stats(self) -> Dict[str, Any]:
        """获取项操作统计。

        Returns:
            包含 total, created, updated, deleted 的字典。
        """
        with self._lock:
            return {
                "total": len(self._items),
                "created": self._stats.get("item_created", 0),
                "updated": self._stats.get("item_updated", 0),
                "deleted": self._stats.get("item_deleted", 0),
            }

    # ------------------------------ 缓存代理 ------------------------------ #

    def get_cache(self, key: str) -> Optional[Any]:
        """获取缓存值。

        Args:
            key: 缓存键。

        Returns:
            缓存值或 None。
        """
        return self._cache.get(key)

    def set_cache(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """设置缓存值。

        Args:
            key: 缓存键。
            value: 缓存值。
            ttl: 过期时间。
        """
        self._cache.set(key, value, ttl)

    def invalidate_cache(self, key: str) -> bool:
        """使缓存键失效。

        Args:
            key: 缓存键。

        Returns:
            是否成功失效。
        """
        return self._cache.invalidate(key)

    def clear_cache(self) -> int:
        """清空缓存。

        Returns:
            被清空的条目数。
        """
        return self._cache.clear()

    def get_cache_stats(self) -> Dict[str, Any]:
        """获取缓存统计。

        Returns:
            缓存统计字典。
        """
        return self._cache.stats()

    # ------------------------------ 指标代理 ------------------------------ #

    def record_metric(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录指标值。

        Args:
            value: 指标数值。
            labels: 标签。
        """
        self._metrics.record(value, labels)

    def get_metric_stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """获取指标统计。

        Args:
            labels: 标签。

        Returns:
            统计字典。
        """
        return self._metrics.get_stats(labels)

    def get_metric_history(self, labels: Optional[Dict[str, Any]] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """获取指标历史。

        Args:
            labels: 标签。
            limit: 最大条数。

        Returns:
            历史记录列表。
        """
        return self._metrics.get_history(labels, limit)

    def reset_metrics(self) -> None:
        """重置指标。"""
        self._metrics.reset()

    # ------------------------------ 配置代理 ------------------------------ #

    def get_config(self, key: str, default: Any = None) -> Any:
        """获取配置。

        Args:
            key: 配置键。
            default: 默认值。

        Returns:
            配置值。
        """
        return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """设置配置。

        Args:
            key: 配置键。
            value: 配置值。
        """
        self._config.set(key, value)

    def get_all_config(self) -> Dict[str, Any]:
        """获取全部配置。

        Returns:
            配置字典。
        """
        return self._config.get_all()

    def update_config(self, updates: Dict[str, Any]) -> None:
        """批量更新配置。

        Args:
            updates: 更新数据。
        """
        self._config.update(updates)

    def reset_config(self, defaults: Optional[Dict[str, Any]] = None) -> None:
        """重置配置。

        Args:
            defaults: 默认配置。
        """
        self._config.reset(defaults)

    def get_config_version(self) -> int:
        """获取配置版本。

        Returns:
            版本号。
        """
        return self._config.version()

    def export_config(self, path: Union[str, Path]) -> str:
        """导出配置。

        Args:
            path: 目标路径。

        Returns:
            实际路径。
        """
        return self._config.export(path)

    def import_config(self, path: Union[str, Path]) -> bool:
        """导入配置。

        Args:
            path: 源路径。

        Returns:
            是否成功。
        """
        return self._config.import_config(path)

    # ------------------------------ 事件系统代理 ------------------------------ #

    def on_event(self, handler: Callable[[Any], None]) -> str:
        """注册事件处理器。

        Args:
            handler: 处理函数。

        Returns:
            处理器 ID。
        """
        return self._event_bus.on(handler)

    def off_event(self, handler_id: str) -> bool:
        """移除事件处理器。

        Args:
            handler_id: 处理器 ID。

        Returns:
            是否移除成功。
        """
        return self._event_bus.off(handler_id)

    def emit_event(self, data: Any = None) -> int:
        """触发事件，调用所有处理器。

        Args:
            data: 事件数据。

        Returns:
            成功调用的处理器数量。
        """
        return self._event_bus.emit(data)

    def get_event_handler_count(self) -> int:
        """获取处理器数量。

        Returns:
            处理器数量。
        """
        return len(self._event_bus)

    def clear_event_handlers(self) -> None:
        """清空所有处理器。"""
        self._event_bus.clear()

    # ------------------------------ 状态管理 ------------------------------ #

    def get_status(self) -> str:
        """获取当前状态。

        Returns:
            当前状态字符串。
        """
        with self._lock:
            return self._status

    def set_status(self, status: str) -> None:
        """设置状态。

        Args:
            status: 新状态。

        Raises:
            ValueError: 当状态无效时。
        """
        if status not in self.VALID_STATES:
            raise ValueError(f"无效状态: {status}, 有效状态: {self.VALID_STATES}")
        with self._lock:
            old_status = self._status
            self._status = status
            timestamp = time.time()
            self._state_history.append((status, timestamp))
            if old_status != status:
                self._transitions.append((old_status, status, timestamp))
                self._event_bus.emit({"type": "state_changed", "from": old_status, "to": status})
            _logger.info(f"状态变更: {old_status} -> {status}")

    def get_state_history(self, limit: int = 100) -> List[Tuple[str, float]]:
        """获取状态历史。

        Args:
            limit: 最大条数。

        Returns:
            状态历史列表。
        """
        with self._lock:
            return self._state_history[-limit:]

    def get_transitions(self, limit: int = 100) -> List[Tuple[str, str, float]]:
        """获取状态转换记录。

        Args:
            limit: 最大条数。

        Returns:
            转换记录列表。
        """
        with self._lock:
            return self._transitions[-limit:]

    def start(self) -> None:
        """启动生成器。"""
        with self._lock:
            if self._status in ("running", "paused"):
                _logger.warning(f"生成器已在 {self._status} 状态, 无需启动")
                return
            self._start_time = time.time()
            self._initialized = True
        self.set_status("running")

    def stop(self) -> None:
        """停止生成器。"""
        self.set_status("stopped")

    def pause(self) -> None:
        """暂停生成器。"""
        with self._lock:
            if self._status != "running":
                _logger.warning(f"无法暂停, 当前状态: {self._status}")
                return
        self.set_status("paused")

    def resume(self) -> None:
        """恢复生成器。"""
        with self._lock:
            if self._status != "paused":
                _logger.warning(f"无法恢复, 当前状态: {self._status}")
                return
        self.set_status("running")

    def is_running(self) -> bool:
        """检查是否正在运行。

        Returns:
            是否运行中。
        """
        return self.get_status() == "running"

    def is_initialization_complete(self) -> bool:
        """检查初始化是否完成。

        Returns:
            是否已初始化。
        """
        with self._lock:
            return self._initialized

    def get_uptime(self) -> float:
        """获取运行时长。

        Returns:
            从启动到现在的秒数。
        """
        with self._lock:
            if not self._initialized:
                return 0.0
            return time.time() - self._start_time
