"""多模态感知记忆模块（第二部分）：内存存储、CRUD、缓存、指标与配置管理。

本模块通过组合多个单一职责组件（TTL 缓存、指标存储、配置管理器、事件总线），
对外提供线程安全的记忆检索核心类 :class:`MemoryRetrieval`。
"""

from __future__ import annotations

import json
import logging
import math
import statistics
import threading
import time
from collections import OrderedDict, defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from src.ximu.common.utils import generate_id
from .part1 import _setup_logger

# ----------------------------------------------------------------------
# 模块级常量
# ----------------------------------------------------------------------

_DEFAULT_CACHE_SIZE: int = 10000
_DEFAULT_TTL_SECONDS: float = 300.0
_METRIC_MAX_POINTS: int = 10000
_METRIC_TRIM_TO: int = 5000
_ITEM_ID_PREFIX: str = "memoryretrieval_item"
_HANDLER_ID_PREFIX: str = "handler"
_VERSION: str = "0.5"

logger = _setup_logger(__name__)


# ----------------------------------------------------------------------
# 通用工具
# ----------------------------------------------------------------------

def _stable_labels_key(labels: Optional[Dict[str, Any]]) -> Tuple[Tuple[str, str], ...]:
    """将标签字典转换为稳定、可哈希的键。

    对每个值进行 JSON 序列化以区分类型，避免直接使用 JSON 字符串作为整体键。

    Args:
        labels: 标签字典，允许为 None 或空字典。

    Returns:
        排序后的 (键, 值序列化) 元组；无标签时返回空元组。
    """
    if not labels:
        return ()
    return tuple(
        sorted((str(k), json.dumps(v, sort_keys=True, default=str)) for k, v in labels.items())
    )


# ----------------------------------------------------------------------
# TTL + LRU 缓存
# ----------------------------------------------------------------------

@dataclass
class _CacheEntry:
    """缓存条目：保存值及其绝对过期时间（单调时钟）。"""

    value: Any
    expires_at: float


class TTLCache:
    """线程安全的 TTL + LRU 缓存。

    使用 OrderedDict 维护访问顺序，命中时移至末尾；容量超限时从头部淘汰。
    """

    def __init__(self, max_size: int = _DEFAULT_CACHE_SIZE) -> None:
        """初始化缓存。

        Args:
            max_size: 最大条目数，必须为正整数。

        Raises:
            ValueError: 当 max_size 非正数时抛出。
        """
        if max_size <= 0:
            raise ValueError("max_size 必须为正整数")
        self._max_size = max_size
        self._data: OrderedDict[str, _CacheEntry] = OrderedDict()
        self._lock = threading.RLock()
        self._hits: int = 0
        self._misses: int = 0
        self._evictions: int = 0

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值，过期视为未命中。

        Args:
            key: 缓存键。

        Returns:
            缓存值；未命中或已过期返回 None。
        """
        now = time.monotonic()
        with self._lock:
            entry = self._data.get(key)
            if entry is None:
                self._misses += 1
                return None
            if entry.expires_at <= now:
                self._data.pop(key, None)
                self._misses += 1
                return None
            self._data.move_to_end(key)
            self._hits += 1
            return entry.value

    def set(self, key: str, value: Any, ttl: float = _DEFAULT_TTL_SECONDS) -> None:
        """写入缓存条目，容量超限时淘汰最久未使用的条目。

        Args:
            key: 缓存键。
            value: 缓存值。
            ttl: 生存时间（秒），必须为正数。

        Raises:
            ValueError: 当 ttl 非正数时抛出。
        """
        if ttl <= 0:
            raise ValueError("ttl 必须为正数")
        expires_at = time.monotonic() + ttl
        with self._lock:
            self._data[key] = _CacheEntry(value=value, expires_at=expires_at)
            self._data.move_to_end(key)
            while len(self._data) > self._max_size:
                self._data.popitem(last=False)
                self._evictions += 1
            logger.debug("缓存写入 key=%s ttl=%.1f 当前大小=%d", key, ttl, len(self._data))

    def invalidate(self, key: str) -> bool:
        """删除指定缓存键。

        Args:
            key: 缓存键。

        Returns:
            键存在并被删除返回 True，否则 False。
        """
        with self._lock:
            existed = key in self._data
            self._data.pop(key, None)
            return existed

    def clear(self) -> int:
        """清空全部缓存条目。

        Returns:
            被清除的条目数量。
        """
        with self._lock:
            count = len(self._data)
            self._data.clear()
            return count

    def stats(self) -> Dict[str, Any]:
        """返回缓存统计快照。

        Returns:
            包含 size、max_size、hits、misses、evictions 的字典。
        """
        with self._lock:
            return {
                "size": len(self._data),
                "max_size": self._max_size,
                "hits": self._hits,
                "misses": self._misses,
                "evictions": self._evictions,
            }


# ----------------------------------------------------------------------
# 指标存储
# ----------------------------------------------------------------------

@dataclass
class _MetricPoint:
    """单条指标采样点。"""

    value: float
    timestamp: float
    labels: Dict[str, Any] = field(default_factory=dict)


class MetricStore:
    """线程安全的指标采集与统计组件。

    以排序标签元组作为键规避 JSON 序列化顺序差异。
    每个序列采用环形裁剪策略控制内存占用。
    """

    def __init__(self, max_points: int = _METRIC_MAX_POINTS, trim_to: int = _METRIC_TRIM_TO) -> None:
        """初始化指标存储。

        Args:
            max_points: 单序列最大采样点数。
            trim_to: 裁剪后保留的最近采样点数。

        Raises:
            ValueError: 当 0 < trim_to < max_points 不满足时抛出。
        """
        if trim_to <= 0 or max_points <= trim_to:
            raise ValueError("需要满足 0 < trim_to < max_points")
        self._max_points = max_points
        self._trim_to = trim_to
        self._series: Dict[Tuple[Tuple[str, str], ...], List[_MetricPoint]] = defaultdict(list)
        self._lock = threading.RLock()

    def record(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录一条指标采样。

        Args:
            value: 指标数值。
            labels: 用于分组统计的标签字典，可为 None。
        """
        key = _stable_labels_key(labels)
        point = _MetricPoint(value=float(value), timestamp=time.time(), labels=dict(labels) if labels else {})
        with self._lock:
            series = self._series[key]
            series.append(point)
            if len(series) > self._max_points:
                del series[: len(series) - self._trim_to]

    def _percentile(self, sorted_values: List[float], pct: float) -> float:
        """计算有序列表的第 pct 百分位。

        Args:
            sorted_values: 已排序的数值列表。
            pct: 百分位（0-100）。

        Returns:
            对应百分位的值。
        """
        if not sorted_values:
            return 0.0
        n = len(sorted_values)
        idx = max(0, min(n - 1, math.ceil(n * pct / 100.0) - 1))
        return sorted_values[idx]

    def stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, float]:
        """计算指定标签序列的统计量。

        Args:
            labels: 标签字典，None 表示无标签序列。

        Returns:
            包含 count、mean、min、max、p50、p95、p99 的字典。
        """
        key = _stable_labels_key(labels)
        with self._lock:
            values = [p.value for p in self._series.get(key, ())]

        if not values:
            return {"count": 0, "mean": 0.0, "min": 0.0, "max": 0.0, "p50": 0.0, "p95": 0.0, "p99": 0.0}

        sorted_values = sorted(values)
        return {
            "count": len(values),
            "mean": statistics.mean(values),
            "min": sorted_values[0],
            "max": sorted_values[-1],
            "p50": self._percentile(sorted_values, 50),
            "p95": self._percentile(sorted_values, 95),
            "p99": self._percentile(sorted_values, 99),
        }

    def history(self, labels: Optional[Dict[str, Any]] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """返回最近 limit 条指标记录。

        Args:
            labels: 标签字典。
            limit: 返回条数上限，非正数时返回空列表。

        Returns:
            指标记录列表，每条包含 value、time、labels。
        """
        if limit <= 0:
            return []
        key = _stable_labels_key(labels)
        with self._lock:
            points = list(self._series.get(key, ()))
        result = []
        for p in points[-limit:]:
            result.append({"value": p.value, "time": p.timestamp, "labels": dict(p.labels)})
        return result

    def reset(self) -> None:
        """清空所有指标序列。"""
        with self._lock:
            self._series.clear()


# ----------------------------------------------------------------------
# 配置管理
# ----------------------------------------------------------------------

class ConfigManager:
    """线程安全的版本化配置管理器。

    所有写操作都会递增版本号，便于外部感知配置变更。
    """

    def __init__(self, defaults: Optional[Dict[str, Any]] = None) -> None:
        """初始化配置管理器。

        Args:
            defaults: 默认配置字典，reset 时使用，不会被原地修改。
        """
        self._defaults: Dict[str, Any] = dict(defaults) if defaults else {}
        self._config: Dict[str, Any] = dict(self._defaults)
        self._version: int = 1
        self._lock = threading.RLock()

    def get(self, key: str, default: Any = None) -> Any:
        """获取单个配置项。

        Args:
            key: 配置键。
            default: 键不存在时的返回值。

        Returns:
            配置值或默认值。
        """
        with self._lock:
            return self._config.get(key, default)

    def set(self, key: str, value: Any) -> int:
        """设置单个配置项。

        Args:
            key: 配置键。
            value: 配置值。

        Returns:
            更新后的配置版本号。
        """
        with self._lock:
            self._config[key] = value
            self._version += 1
            new_ver = self._version
        logger.debug("配置更新 key=%s version=%d", key, new_ver)
        return new_ver

    def update(self, updates: Dict[str, Any]) -> int:
        """批量更新配置。

        Args:
            updates: 待合并的键值对。

        Returns:
            更新后的配置版本号。
        """
        with self._lock:
            self._config.update(updates)
            self._version += 1
            new_ver = self._version
        logger.debug("配置批量更新 version=%d keys=%s", new_ver, list(updates.keys()))
        return new_ver

    def snapshot(self) -> Dict[str, Any]:
        """返回当前配置的浅拷贝。

        Returns:
            配置字典副本。
        """
        with self._lock:
            return dict(self._config)

    def reset(self) -> int:
        """将配置重置为默认值。

        Returns:
            重置后的配置版本号。
        """
        with self._lock:
            self._config = dict(self._defaults)
            self._version += 1
            new_ver = self._version
        logger.debug("配置重置 version=%d", new_ver)
        return new_ver

    @property
    def version(self) -> int:
        """当前配置版本号。"""
        with self._lock:
            return self._version

    def export(self, path: str) -> str:
        """将配置导出为 JSON 文件。

        Args:
            path: 目标文件路径。

        Returns:
            导出文件路径。
        """
        with self._lock:
            data = dict(self._config)
        with open(path, "w", encoding="utf-8") as fp:
            json.dump(data, fp, ensure_ascii=False, indent=2, default=str)
        logger.info("配置已导出到 %s", path)
        return path

    def import_from(self, path: str) -> bool:
        """从 JSON 文件导入配置并合并。

        Args:
            path: 源文件路径。

        Returns:
            导入成功返回 True。

        Raises:
            OSError: 文件无法读取。
            json.JSONDecodeError: 文件内容非法 JSON。
            ValueError: 文件顶层不是 JSON 对象。
        """
        with open(path, "r", encoding="utf-8") as fp:
            data = json.load(fp)
        if not isinstance(data, dict):
            raise ValueError("配置文件顶层必须是 JSON 对象")
        self.update(data)
        logger.info("配置已从 %s 导入", path)
        return True


# ----------------------------------------------------------------------
# 事件总线
# ----------------------------------------------------------------------

class EventBus:
    """线程安全的事件处理器注册与分发组件。

    单个处理器异常不会中断其余处理器执行，异常会记录到日志。
    """

    def __init__(self, logger_instance: Optional[logging.Logger] = None) -> None:
        """初始化事件总线。

        Args:
            logger_instance: 用于记录处理器异常的可选日志器。
        """
        self._handlers: Dict[str, Callable[[Any], None]] = {}
        self._lock = threading.RLock()
        self._next_handler_id: int = 0
        self._logger = logger_instance or logger

    def register(self, handler: Callable[[Any], None]) -> str:
        """注册事件处理器。

        Args:
            handler: 处理器函数。

        Returns:
            处理器 ID。
        """
        handler_id = f"{_HANDLER_ID_PREFIX}_{self._next_handler_id}"
        self._next_handler_id += 1
        with self._lock:
            self._handlers[handler_id] = handler
        self._logger.debug("注册事件处理器 handler_id=%s", handler_id)
        return handler_id

    def unregister(self, handler_id: str) -> bool:
        """注销事件处理器。

        Args:
            handler_id: 处理器 ID。

        Returns:
            是否成功注销。
        """
        with self._lock:
            existed = self._handlers.pop(handler_id, None) is not None
        if existed:
            self._logger.debug("注销事件处理器 handler_id=%s", handler_id)
        return existed

    def emit(self, data: Any = None) -> int:
        """分发事件到所有注册的处理器。

        Args:
            data: 事件数据。

        Returns:
            成功执行的处理器数量。
        """
        with self._lock:
            handlers = list(self._handlers.values())
        success_count = 0
        for handler in handlers:
            try:
                handler(data)
                success_count += 1
            except Exception as e:
                self._logger.warning("事件处理器执行异常: %s", e, exc_info=True)
        return success_count


# ----------------------------------------------------------------------
# 核心类：MemoryRetrieval
# ----------------------------------------------------------------------

class MemoryRetrieval:
    """线程安全的记忆检索核心类。

    组合 TTLCache、MetricStore、ConfigManager、EventBus 四个组件，
    提供内存存储、CRUD、缓存、指标与配置管理功能。
    """

    def __init__(
        self,
        cache_size: int = _DEFAULT_CACHE_SIZE,
        cache_ttl: float = _DEFAULT_TTL_SECONDS,
        metric_max_points: int = _METRIC_MAX_POINTS,
        metric_trim_to: int = _METRIC_TRIM_TO,
        defaults: Optional[Dict[str, Any]] = None,
    ) -> None:
        """初始化记忆检索核心类。

        Args:
            cache_size: 缓存最大条目数。
            cache_ttl: 缓存默认生存时间（秒）。
            metric_max_points: 指标单序列最大采样点数。
            metric_trim_to: 指标裁剪后保留的最近采样点数。
            defaults: 配置默认值字典。
        """
        self._cache = TTLCache(max_size=cache_size)
        self._metrics = MetricStore(max_points=metric_max_points, trim_to=metric_trim_to)
        self._config = ConfigManager(defaults=defaults)
        self._events = EventBus()
        self._store: Dict[str, Dict[str, Any]] = {}
        self._store_lock = threading.RLock()
        self._stats: Dict[str, int] = {
            "inserts": 0,
            "updates": 0,
            "deletes": 0,
            "gets": 0,
        }
        self._version = _VERSION

    # ------------------------------------------------------------------
    # 记忆项 CRUD
    # ------------------------------------------------------------------

    def insert(self, item_data: Dict[str, Any]) -> str:
        """插入一条记忆项。

        Args:
            item_data: 记忆项数据字典，不含 "id" 字段；若包含则覆盖。

        Returns:
            生成的记忆项 ID。
        """
        item_id = f"{_ITEM_ID_PREFIX}_{generate_id()}"
        item = dict(item_data)
        item["id"] = item_id
        with self._store_lock:
            self._store[item_id] = item
            self._stats["inserts"] += 1
        self._cache.set(item_id, item)
        self._metrics.record(1.0, labels={"op": "insert"})
        self._events.emit({"type": "insert", "id": item_id, "data": item})
        self._logger.debug("插入记忆项 id=%s", item_id)
        return item_id

    def get(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取单条记忆项。

        Args:
            item_id: 记忆项 ID。

        Returns:
            记忆项数据字典；不存在返回 None。
        """
        with self._store_lock:
            self._stats["gets"] += 1
            item = self._store.get(item_id)
            if item is not None:
                return dict(item)
        return self._cache.get(item_id)

    def update(self, item_id: str, updates: Dict[str, Any]) -> bool:
        """更新记忆项字段。

        Args:
            item_id: 记忆项 ID。
            updates: 待更新的字段字典。

        Returns:
            更新成功返回 True；记忆项不存在返回 False。
        """
        with self._store_lock:
            item = self._store.get(item_id)
            if item is None:
                return False
            item.update(updates)
            self._stats["updates"] += 1
            new_item = dict(item)
        self._cache.invalidate(item_id)
        self._cache.set(item_id, new_item)
        self._metrics.record(1.0, labels={"op": "update"})
        self._events.emit({"type": "update", "id": item_id, "data": new_item})
        self._logger.debug("更新记忆项 id=%s fields=%s", item_id, list(updates.keys()))
        return True

    def delete(self, item_id: str) -> bool:
        """删除记忆项。

        Args:
            item_id: 记忆项 ID。

        Returns:
            删除成功返回 True；记忆项不存在返回 False。
        """
        with self._store_lock:
            item = self._store.pop(item_id, None)
            if item is None:
                return False
            self._stats["deletes"] += 1
        self._cache.invalidate(item_id)
        self._metrics.record(1.0, labels={"op": "delete"})
        self._events.emit({"type": "delete", "id": item_id})
        self._logger.debug("删除记忆项 id=%s", item_id)
        return True

    def list_items(
        self,
        labels: Optional[Dict[str, Any]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """列出记忆项，支持标签过滤和分页。

        Args:
            labels: 标签过滤字典，键值需全部匹配。
            limit: 返回条数上限，非正数时返回空列表。
            offset: 跳过前 N 条，负数视为 0。

        Returns:
            匹配的记忆项列表。
        """
        if limit <= 0:
            return []
        offset = max(0, offset)
        with self._store_lock:
            items = list(self._store.values())
        if labels:
            items = [item for item in items if all(item.get(k) == v for k, v in labels.items())]
        return [dict(item) for item in items[offset: offset + limit]]

    # ------------------------------------------------------------------
    # 配置操作
    # ------------------------------------------------------------------

    def get_config(self, key: str, default: Any = None) -> Any:
        """获取配置项。

        Args:
            key: 配置键。
            default: 键不存在时的返回值。

        Returns:
            配置值或默认值。
        """
        return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> int:
        """设置配置项。

        Args:
            key: 配置键。
            value: 配置值。

        Returns:
            版本号。
        """
        return self._config.set(key, value)

    # ------------------------------------------------------------------
    # 事件操作
    # ------------------------------------------------------------------

    def register_event_handler(self, handler: Callable[[Any], None]) -> str:
        """注册事件处理器。

        Args:
            handler: 处理器函数。

        Returns:
            处理器 ID。
        """
        return self._events.register(handler)

    def unregister_event_handler(self, handler_id: str) -> bool:
        """注销事件处理器。

        Args:
            handler_id: 处理器 ID。

        Returns:
            是否成功注销。
        """
        return self._events.unregister(handler_id)

    def emit_event(self, data: Any = None) -> int:
        """分发事件。

        Args:
            data: 事件数据。

        Returns:
            成功执行的处理器数量。
        """
        return self._events.emit(data)

    # ------------------------------------------------------------------
    # 统计信息
    # ------------------------------------------------------------------

    def get_stats(self) -> Dict[str, Any]:
        """获取综合统计信息。

        Returns:
            包含缓存统计、指标统计、CRUD 统计的字典。
        """
        with self._store_lock:
            crud_stats = dict(self._stats)
        return {
            "cache": self._cache.stats(),
            "metrics": self._metrics.stats(),
            "crud": crud_stats,
        }

    def reset_metrics(self) -> None:
        """重置指标存储。"""
        self._metrics.reset()

    def clear_cache(self) -> int:
        """清空缓存。

        Returns:
            被清除的条目数。
        """
        return self._cache.clear()

    def clear_store(self) -> int:
        """清空内存存储。

        Returns:
            被清除的条目数。
        """
        with self._store_lock:
            count = len(self._store)
            self._store.clear()
        self._logger.debug("清空内存存储 移除数=%d", count)
        return count
