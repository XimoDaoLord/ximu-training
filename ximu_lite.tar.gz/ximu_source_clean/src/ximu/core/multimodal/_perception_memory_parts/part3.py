"""多模态感知内存回放模块：提供线程安全的内存存储、LRU缓存、指标统计、配置管理和事件机制。"""

import json
import logging
import time
import threading
from collections import OrderedDict, defaultdict
from typing import Any, Callable, Dict, List, Optional, Tuple, TypeVar

T = TypeVar('T')

class MemoryReplay:
    """线程安全的内存回放管理器，支持数据存储、LRU缓存、指标统计、配置管理和事件监听。"""

    MAX_METRIC_HISTORY = 10000
    METRIC_RETENTION_SIZE = 5000
    DEFAULT_CACHE_TTL = 300.0
    VALID_STATES = ("idle", "running", "paused", "stopped", "error")

    def __init__(self, max_cache_size: int = 10000) -> None:
        """初始化内存回放模块。

        Args:
            max_cache_size: 缓存最大容量，超出时触发LRU淘汰。
        """
        self._lock = threading.RLock()
        self._logger = logging.getLogger(f"{__name__}.MemoryReplay")

        # 数据存储
        self._item_store: Dict[str, Dict[str, Any]] = {}
        self._index: Dict[str, List[str]] = defaultdict(list)
        self._max_cache_size: int = max_cache_size

        # LRU缓存: key -> (value, timestamp, ttl)
        self._cache: OrderedDict[str, Tuple[Any, float, float]] = OrderedDict()
        self._cacheTTL: Dict[str, float] = {}

        # 指标统计
        self._metrics: Dict[frozenset, List[Dict[str, Any]]] = {}
        self._stats: Dict[str, int] = {
            "item_created": 0,
            "item_updated": 0,
            "item_deleted": 0,
        }

        # 配置管理
        self._config: Dict[str, Any] = {}
        self._default_config: Dict[str, Any] = {}
        self._config_version: int = 1

        # 事件处理器
        self._event_handlers: Dict[str, List[Callable[[Any], None]]] = {}

        # 生命周期状态
        self._initialized: bool = False
        self._start_time: float = 0.0
        self._state_history: List[Dict[str, Any]] = []
        self._current_state: str = "idle"

        # 扩展存储
        self._association_strengths: Dict[str, float] = {}
        self._registry: Dict[str, Any] = {}
        self._tasks: Dict[str, Any] = {}
        self._workers: Dict[str, Any] = {}
        self._memory: Dict[str, Any] = {}

    # ------------------------------------------------------------------
    # 生命周期管理
    # ------------------------------------------------------------------

    def initialize(self) -> bool:
        """初始化模块资源并设置状态为running。

        Returns:
            初始化成功返回True，失败返回False。
        """
        if self._initialized:
            return True
        try:
            with self._lock:
                self._start_time = time.monotonic()
                self._set_state("running")
                self._initialized = True
            self._logger.info("MemoryReplay initialized successfully")
            return True
        except Exception as exc:
            self._logger.error("MemoryReplay initialization failed: %s", exc)
            try:
                self._set_state("error")
            except Exception:
                pass
            return False

    def shutdown(self) -> bool:
        """关闭模块并清理资源。

        Returns:
            关闭成功返回True，失败返回False。
        """
        if not self._initialized:
            return True
        try:
            with self._lock:
                self.clear_cache()
                self._set_state("stopped")
                self._initialized = False
            self._logger.info("MemoryReplay shutdown completed")
            return True
        except Exception as exc:
            self._logger.error("MemoryReplay shutdown failed: %s", exc)
            try:
                self._set_state("error")
            except Exception:
                pass
            return False

    def restart(self) -> bool:
        """重启模块：先关闭再初始化。

        Returns:
            重启成功返回True，失败返回False。
        """
        if not self.shutdown():
            return False
        time.sleep(0.1)
        return self.initialize()

    def get_status(self) -> str:
        """获取当前状态字符串。

        Returns:
            当前状态值。
        """
        with self._lock:
            return self._current_state

    def is_healthy(self) -> bool:
        """检查模块是否健康。

        Returns:
            健康返回True，否则返回False。
        """
        with self._lock:
            return self._initialized and self._current_state != "error"

    def get_uptime(self) -> float:
        """获取模块运行时间（秒）。

        Returns:
            运行时间，未初始化时返回0.0。
        """
        with self._lock:
            if not self._initialized:
                return 0.0
            return time.monotonic() - self._start_time

    def _set_state(self, new_state: str) -> None:
        """内部状态变更，记录历史并校验合法性。

        Args:
            new_state: 目标状态。

        Raises:
            ValueError: 当状态不合法时抛出。
        """
        if new_state not in self.VALID_STATES:
            raise ValueError(f"Invalid state: {new_state}")
        old_state = self._current_state
        self._current_state = new_state
        self._state_history.append({
            "from": old_state,
            "to": new_state,
            "timestamp": time.time(),
        })

    def get_state_history(self) -> List[Dict[str, Any]]:
        """获取状态变更历史。

        Returns:
            状态历史记录列表。
        """
        with self._lock:
            return list(self._state_history)

    # ------------------------------------------------------------------
    # 数据存储 CRUD
    # ------------------------------------------------------------------

    def create_memoryreplay_item(self, data: Dict[str, Any]) -> str:
        """创建一个新的内存回放数据项。

        Args:
            data: 数据内容。

        Returns:
            新创建的数据项ID。
        """
        item_id = generate_id("memoryreplay_item")
        now = time.time()
        record: Dict[str, Any] = {
            "id": item_id,
            "data": data.copy() if isinstance(data, dict) else data,
            "created_at": now,
            "updated_at": now,
            "version": 1,
        }
        with self._lock:
            self._item_store[item_id] = record
            self._stats["item_created"] += 1
            self._update_index(item_id, record)
        self._logger.debug("Created memoryreplay item: %s", item_id)
        return item_id

    def get_memoryreplay_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取指定ID的数据项。

        Args:
            item_id: 数据项ID。

        Returns:
            数据项内容副本，不存在时返回None。
        """
        with self._lock:
            record = self._item_store.get(item_id)
        if record:
            data = record["data"]
            return data.copy() if isinstance(data, dict) else data
        return None

    def update_memoryreplay_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新指定ID的数据项。

        Args:
            item_id: 数据项ID。
            data: 要合并更新的数据。

        Returns:
            更新成功返回True，数据项不存在返回False。
        """
        with self._lock:
            record = self._item_store.get(item_id)
            if record is None:
                return False
            record["data"].update(data)
            record["updated_at"] = time.time()
            record["version"] += 1
            self._stats["item_updated"] += 1
            self._update_index(item_id, record)
        self._logger.debug("Updated memoryreplay item: %s", item_id)
        return True

    def delete_memoryreplay_item(self, item_id: str) -> bool:
        """删除指定ID的数据项。

        Args:
            item_id: 数据项ID。

        Returns:
            删除成功返回True，数据项不存在返回False。
        """
        with self._lock:
            if item_id not in self._item_store:
                return False
            del self._item_store[item_id]
            self._stats["item_deleted"] += 1
            self._delete_index(item_id)
        self._logger.debug("Deleted memoryreplay item: %s", item_id)
        return True

    def list_memoryreplay_items(
        self,
        page: int = 1,
        page_size: int = 20,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """分页列出数据项，支持按字段过滤。

        Args:
            page: 页码，从1开始。
            page_size: 每页大小。
            filters: 过滤条件字典。

        Returns:
            包含items、total、page、page_size的字典。
        """
        with self._lock:
            all_items = list(self._item_store.values())
            total = len(all_items)
            start = (page - 1) * page_size
            end = start + page_size

        if filters:
            keys = list(filters.keys())
            values = list(filters.values())
            filtered = []
            for item in all_items[start:end]:
                match = True
                for i, (k, v) in enumerate(zip(keys, values)):
                    if item["data"].get(k) != v:
                        match = False
                        break
                if match:
                    filtered.append(item)
            all_items = filtered

        return {
            "items": all_items[start:end],
            "total": total,
            "page": page,
            "page_size": page_size,
        }

    def count_memoryreplay_items(self) -> int:
        """统计数据项总数。

        Returns:
            数据项数量。
        """
        with self._lock:
            return len(self._item_store)

    def search_memoryreplay_items(
        self,
        query: str,
        fields: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """在数据项中搜索包含query的项。

        Args:
            query: 搜索关键词。
            fields: 限定搜索的字段列表。

        Returns:
            匹配的数据项列表。
        """
        with self._lock:
            if fields:
                search_values = [self._index.get(f, []) for f in fields]
                indices = zip(*search_values)
                matches = [item for item, *vs in zip(all_items, *indices) if vs[0] == query]
            else:
                matches = []
            return matches

    def batch_create_memoryreplay_items(self, batch: List[Dict[str, Any]]) -> List[str]:
        """批量创建数据项。

        Args:
            batch: 数据项列表。

        Returns:
            创建成功的ID列表。
        """
        ids: List[str] = []
        now = time.time()
        with self._lock:
            for item in batch:
                item_id = generate_id("memoryreplay_item")
                record: Dict[str, Any] = {
                    "id": item_id,
                    "data": item.copy() if isinstance(item, dict) else item,
                    "created_at": now,
                    "updated_at": now,
                    "version": 1,
                }
                self._item_store[item_id] = record
                ids.append(item_id)
                self._update_index(item_id, record)
            self._stats["item_created"] += len(batch)
        self._logger.debug("Batch created %d memoryreplay items", len(batch))
        return ids

    def batch_delete_memoryreplay_items(self, ids: List[str]) -> int:
        """批量删除数据项。

        Args:
            ids: 数据项ID列表。

        Returns:
            实际删除的数量。
        """
        count = 0
        with self._lock:
            for item_id in ids:
                if item_id in self._item_store:
                    del self._item_store[item_id]
                    self._delete_index(item_id)
                    count += 1
        self._stats["item_deleted"] += count
        self._logger.debug("Batch deleted %d memoryreplay items", count)
        return count

    def export_memoryreplay_items(self, path: str) -> str:
        """导出数据项到JSON文件。

        Args:
            path: 导出文件路径。

        Returns:
            导出文件路径。
        """
        with self._lock:
            data = [item["data"] for item in self._item_store.values()]
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        self._logger.info("Exported %d items to %s", len(data), path)
        return path

    def import_memoryreplay_items(self, path: str) -> int:
        """从JSON文件导入数据项。

        Args:
            path: 导入文件路径。

        Returns:
            导入的数据项数量。
        """
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, FileNotFoundError) as exc:
            self._logger.error("Failed to import items from %s: %s", path, exc)
            return 0

        count = 0
        with self._lock:
            for record in data:
                if not isinstance(record, dict):
                    continue
                item_id = record.get("id", generate_id("memoryreplay_item"))
                self._item_store[item_id] = record
                self._update_index(item_id, record)
                count += 1
        self._logger.info("Imported %d items from %s", count, path)
        return count

    def get_memoryreplay_item_stats(self) -> Dict[str, int]:
        """获取数据项统计信息。

        Returns:
            包含total、created、updated、deleted的字典。
        """
        with self._lock:
            return {
                "total": len(self._item_store),
                "created": self._stats["item_created"],
                "updated": self._stats["item_updated"],
                "deleted": self._stats["item_deleted"],
            }

    # ------------------------------------------------------------------
    # LRU 缓存管理
    # ------------------------------------------------------------------

    def get_memoryreplay_cache(self, key: str) -> Optional[Any]:
        """获取缓存值，自动处理TTL过期和LRU访问顺序。

        Args:
            key: 缓存键。

        Returns:
            缓存值，过期或不存在时返回None。
        """
        with self._lock:
            if key not in self._cache:
                return None
            value, timestamp, ttl = self._cache[key]
            if time.monotonic() - timestamp >= ttl:
                self._cache.pop(key, None)
                return None
            self._cache.move_to_end(key)
            return value

    def set_memoryreplay_cache(self, key: str, value: Any, ttl: float = DEFAULT_CACHE_TTL) -> None:
        """设置缓存，超出容量时淘汰最久未使用的项。

        Args:
            key: 缓存键。
            value: 缓存值。
            ttl: 存活时间（秒）。
        """
        with self._lock:
            now = time.monotonic()
            if key in self._cache:
                self._cache.move_to_end(key)
            self._cache[key] = (value, now, ttl)
            while len(self._cache) > self._max_cache_size:
                evicted_key, _ = self._cache.popitem(last=False)
                self._logger.debug("Evicted cache key: %s", evicted_key)

    def invalidate_memoryreplay_cache(self, key: str) -> bool:
        """使指定缓存失效。

        Args:
            key: 缓存键。

        Returns:
            删除成功返回True，不存在返回False。
        """
        with self._lock:
            return self._cache.pop(key, None) is not None

    def clear_cache(self) -> int:
        """清空全部缓存。

        Returns:
            清除的缓存条目数量。
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
        return count

    def get_memoryreplay_cache_stats(self) -> Dict[str, int]:
        """获取缓存统计信息。

        Returns:
            包含size和max_size的字典。
        """
        with self._lock:
            return {"size": len(self._cache), "max_size": self._max_cache_size}

    # ------------------------------------------------------------------
    # 指标统计
    # ------------------------------------------------------------------

    def _make_metric_key(self, labels: Optional[Dict[str, Any]]) -> frozenset:
        """生成指标键。

        Args:
            labels: 标签字典。

        Returns:
            frozenset形式的指标键。
        """
        if not labels:
            return frozenset()
        return frozenset(labels.items())

    def record_memoryreplay(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录一个指标值。

        Args:
            value: 指标数值。
            labels: 标签字典。
        """
        key = self._make_metric_key(labels)
        entry: Dict[str, Any] = {
            "value": value,
            "time": time.time(),
            "labels": labels or {},
        }
        with self._lock:
            if key not in self._metrics:
                self._metrics[key] = []
            self._metrics[key].append(entry)
            if len(self._metrics[key]) > self.MAX_METRIC_HISTORY:
                self._metrics[key] = self._metrics[key][-self.METRIC_RETENTION_SIZE:]

    def get_memoryreplay_stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, float]:
        """获取指标统计摘要。

        Args:
            labels: 标签字典。

        Returns:
            包含count、mean、min、max、p50、p95、p99的字典。
        """
        key = self._make_metric_key(labels)
        with self._lock:
            entries = self._metrics.get(key, [])
            values = [e["value"] for e in entries]

        if not values:
            return {"count": 0, "mean": 0.0, "min": 0.0, "max": 0.0, "p50": 0.0, "p95": 0.0, "p99": 0.0}
        sorted_vals = sorted(values)
        n = len(sorted_vals)
        return {
            "count": n,
            "mean": statistics.mean(values),
            "min": sorted_vals[0],
            "max": sorted_vals[-1],
            "p50": sorted_vals[int(n * 0.5)],
            "p95": sorted_vals[min(int(n * 0.95), n - 1)],
            "p99": sorted_vals[min(int(n * 0.99), n - 1)],
        }

    def get_memoryreplay_history(
        self,
        labels: Optional[Dict[str, Any]] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """获取指标历史记录。

        Args:
            labels: 标签字典。
            limit: 返回最近条数。

        Returns:
            指标条目列表。
        """
        key = self._make_metric_key(labels)
        with self._lock:
            entries = self._metrics.get(key, [])
            return list(entries[-limit:])

    def reset_memoryreplay_metrics(self) -> None:
        """重置所有指标数据。"""
        with self._lock:
            self._metrics.clear()
        self._logger.info("Metrics reset completed")

    # ------------------------------------------------------------------
    # 配置管理
    # ------------------------------------------------------------------

    def get_memoryreplay_config(self, key: str, default: Any = None) -> Any:
        """获取配置项。

        Args:
            key: 配置键。
            default: 默认值。

        Returns:
            配置值或默认值。
        """
        with self._lock:
            return self._config.get(key, default)

    def set_memoryreplay_config(self, key: str, value: Any) -> None:
        """设置单个配置项并递增版本号。

        Args:
            key: 配置键。
            value: 配置值。
        """
        with self._lock:
            self._config[key] = value
            self._config_version += 1
        self._logger.debug("Config set: %s", key)

    def get_all_memoryreplay_config(self) -> Dict[str, Any]:
        """获取全部配置的副本。

        Returns:
            配置字典副本。
        """
        with self._lock:
            return dict(self._config)

    def update_memoryreplay_config(self, updates: Dict[str, Any]) -> None:
        """批量更新配置并递增版本号。

        Args:
            updates: 要更新的配置字典。
        """
        with self._lock:
            self._config.update(updates)
            self._config_version += 1
        self._logger.debug("Config updated with %d keys", len(updates))

    def reset_memoryreplay_config(self) -> None:
        """重置配置为默认值。"""
        with self._lock:
            self._config = dict(self._default_config)
            self._config_version += 1
        self._logger.info("Config reset to defaults")

    def get_memoryreplay_config_version(self) -> int:
        """获取当前配置版本号。

        Returns:
            版本号。
        """
        with self._lock:
            return self._config_version

    def export_memoryreplay_config(self, path: str) -> str:
        """导出配置到JSON文件。

        Args:
            path: 导出文件路径。

        Returns:
            导出文件路径。
        """
        config = self.get_all_memoryreplay_config()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        self._logger.info("Config exported to %s", path)
        return path

    def import_memoryreplay_config(self, path: str):
        """从JSON文件导入配置。

        Args:
            path: 导入文件路径。

        Returns:
            导入成功的配置字典。
        """
        try:
            with open(path, "r", encoding="utf-8") as f:
                config = json.load(f)
        except (json.JSONDecodeError, FileNotFoundError) as exc:
            self._logger.error("Failed to import config from %s: %s", path, exc)
            return None

        with self._lock:
            self._config = config
            self._config_version += 1
        self._logger.info("Config imported from %s", path)
        return config
