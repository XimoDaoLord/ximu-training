"""感知记忆模块第一部分：核心模型、缓存、指标与事件系统。

本模块提供线程安全的多模态感知记忆存储、检索、缓存及指标记录能力，
支持多种记忆类型与感觉模态，通过 LRU-TTL 缓存优化高频访问性能，
并提供完整的数据持久化（导出/导入）与监控指标。

模块结构：
    - MemoryType / SensoryModality：标准分类枚举
    - MemoryItem：记忆项数据模型
    - LRUWithTTL：线程安全的 LRU-TTL 缓存
    - PerceptionMemory：核心记忆管理类（由多个 Mixin 组合）

设计说明：
    - 核心存储与缓存层解耦，便于替换后端存储（如 Redis）。
    - 跨子系统的共享状态由单一 RLock 保护，缓存内部使用独立锁，
      避免高频读路径阻塞主存储。
    - search_items 已重构为索引驱动查询，性能优化至 O(K) 级（K为索引条目数）
"""

from __future__ import annotations
import json
import logging
import os
import time
import uuid
from collections import OrderedDict, defaultdict
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple, Type, TypeVar
import threading
import copy

# ---------------------------------------------------------------------------
# 模块级常量
# ---------------------------------------------------------------------------
DEFAULT_CACHE_SIZE: int = 10000
DEFAULT_CACHE_TTL: float = 300.0
DEFAULT_METRICS_LIMIT: int = 10000
METRICS_TRIM_RATIO: float = 0.5
JSON_INDENT: int = 2

# ---------------------------------------------------------------------------
# 模块级工具函数
# ---------------------------------------------------------------------------
def setup_logger(name: str) -> logging.Logger:
    """创建并返回带标准 StreamHandler 的 Logger。

    参数:
        name: 日志记录器名称
    返回:
        配置好的 Logger 实例
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger

def resolve_writable_path(path: str) -> str:
    """校验并规范化一个可写的文件路径。

    参数:
        path: 用户提供的文件路径
    返回:
        规范化后的绝对路径
    异常:
        ValueError: 路径为空或非绝对路径
        PermissionError: 目标文件已存在但不可写
    """
    if not path:
        raise ValueError("文件路径不能为空")
    if not os.path.isabs(path):
        raise ValueError(f"文件路径必须为绝对路径: {path}")
    normalized = os.path.normpath(path)
    if os.path.exists(normalized) and not os.access(normalized, os.W_OK):
        raise PermissionError(f"文件不可写: {normalized}")
    return normalized

def generate_id(prefix: str) -> str:
    """生成带前缀的短UUID。

    参数:
        prefix: ID 前缀
    返回:
        格式为 {prefix}_{uuid} 的字符串
    """
    return f"{prefix}_{uuid.uuid4().hex[:12]}"

# ---------------------------------------------------------------------------
# 枚举类型
# ---------------------------------------------------------------------------
class _EnumLookupMixin:
    """为字符串枚举提供通用的 all_values / from_str 辅助方法。"""

    @classmethod
    def all_values(cls) -> List[str]:
        """返回枚举所有值组成的字符串列表"""
        return [member.value for member in cls]

    @classmethod
    def from_str(cls: Type[_EnumT], text: str) -> Optional[_EnumT]:
        """从字符串（枚举值或成员名）解析出枚举成员"""
        if not text:
            return None
        for member in cls:
            if member.value == text or member.name == text:
                return member
        return None

@dataclass(frozen=True)
class MemoryType(_EnumLookupMixin, Enum):
    """记忆类型枚举"""
    SENSORY: str = "SENSORY"
    SHORT_TERM: str = "SHORT_TERM"
    LONG_TERM: str = "LONG_TERM"
    WORKING: str = "WORKING"
    EPISODIC: str = "EPISODIC"
    SEMANTIC: str = "SEMANTIC"
    PROCEDURAL: str = "PROCEDURAL"
    EMOTIONAL: str = "EMOTIONAL"

@dataclass(frozen=True)
class SensoryModality(_EnumLookupMixin, Enum):
    """感觉模态枚举"""
    VISION: str = "VISION"
    AUDITION: str = "AUDITION"
    OLFACTION: str = "OLFACTION"
    GUSTATION: str = "GUSTATION"
    TACTILE: str = "TACTILE"
    PROPRIOCEPTION: str = "PROPRIOCEPTION"
    VESTIBULAR: str = "VESTIBULAR"
    THERMOCEPTION: str = "THERMOCEPTION"
    NOCICEPTION: str = "NOCICEPTION"
    TEMPORAL: str = "TEMPORAL"
    SPATIAL: str = "SPATIAL"

# ---------------------------------------------------------------------------
# 数据模型
# ---------------------------------------------------------------------------
@dataclass
class MemoryItem:
    """记忆项数据模型"""
    memory_id: str = field(default_factory=lambda: f"item_{uuid.uuid4().hex[:12]}")
    content: Any = None
    modality: SensoryModality = field(default_factory=lambda: SensoryModality.VISION)
    memory_type: MemoryType = field(default_factory=lambda: MemoryType.SHORT_TERM)
    timestamp: float = time.time()
    importance: float = 0.5
    access_count: int = 0
    last_access: float = 0.0
    associations: List[Any] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MemoryItem":
        """从字典恢复实例，忽略未知字段"""
        valid_fields = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        return cls(**valid_fields)

# ---------------------------------------------------------------------------
# 缓存实现
# ---------------------------------------------------------------------------
class LRUWithTTL:
    """线程安全的 LRU-TTL 缓存"""
    def __init__(self, max_size: int = DEFAULT_CACHE_SIZE) -> None:
        if max_size <= 0:
            raise ValueError(f"max_size必须为正整数：{max_size}")
        self._max_size = max_size
        self._data: OrderedDict[str, Tuple[Any, float, float]] = OrderedDict()
        self._lock = threading.RLock()
        self._hits = 0
        self._misses = 0
        self._overdue = 0

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值并更新访问时间"""
        with self._lock:
            entry = self._data.get(key)
            if not entry:
                self._misses += 1
                return None
            value, timestamp, ttl = entry
            if time.time() - timestamp < ttl:
                self._hits += 1
                self._data.move_to_end(key)
                return value
            self._overdue += 1
            self._data.pop(key)
            self._misses += 1
            return None

    def set(self, key: str, value: Any, ttl: float = DEFAULT_CACHE_TTL) -> None:
        """设置缓存值并维护LRU顺序"""
        with self._lock:
            self._data[key] = (value, time.time(), ttl)
            self._data.move_to_end(key)
            if len(self._data) > self._max_size:
                self._data.popitem(last=False)

    def invalidate(self, key: str) -> bool:
        """使缓存项失效"""
        with self._lock:
            return self._data.pop(key, None) is not None

    def clear(self) -> int:
        """清空缓存"""
        with self._lock:
            count = len(self._data)
            self._data.clear()
            return count

    def stats(self) -> Dict[str, Any]:
        """获取缓存统计信息"""
        with self._lock:
            total_requests = self._hits + self._misses + self._overdue
            hit_rate = self._hits / total_requests if total_requests > 0 else 0.0
            return {
                "size": len(self._data),
                "max_size": self._max_size,
                "hits": self._hits,
                "misses": self._misses,
                "overdue": self._overdue,
                "hit_rate": hit_rate
            }

# ---------------------------------------------------------------------------
# 存储与索引
# ---------------------------------------------------------------------------
class ItemStoreMixin:
    """存储与索引 Mixin"""
    _lock: threading.RLock
    _item_store: Dict[str, Dict[str, Any]]
    _index_by_modality: Dict[str, Set[str]]
    _index_by_type: Dict[str, Set[str]]
    _stats: Dict[str, int]
    _logger: logging.Logger

    def __init__(self, logger: logging.Logger) -> None:
        self._lock = threading.RLock()
        self._item_store = {}
        self._index_by_modality = defaultdict(set)
        self._index_by_type = defaultdict(set)
        self._stats = {"item_created": 0, "item_updated": 0, "item_deleted": 0}
        self._logger = logger

    def _index_record(self, item_id: str, data: Dict[str, Any]) -> None:
        """维护模态与类型索引"""
        if "modality" in data:
            self._index_by_modality[data["modality"].value].add(item_id)
        if "memory_type" in data:
            self._index_by_type[data["memory_type"].value].add(item_id)

    def _unindex_record(self, item_id: str, data: Dict[str, Any]) -> None:
        """移除索引记录"""
        if "modality" in data:
            self._index_by_modality[data["modality"].value].discard(item_id)
        if "memory_type" in data:
            self._index_by_type[data["memory_type"].value].discard(item_id)

    def create_item(self, data: Dict[str, Any]) -> str:
        """创建记忆项并更新索引"""
        item_id = generate_id("perception_memory_item")
        now = time.time()
        record = {
            "id": item_id,
            "data": copy.deepcopy(data),
            "created_at": now,
            "updated_at": now,
            "version": 1
        }
        with self._lock:
            self._item_store[item_id] = record
            self._index_record(item_id, record["data"])
            self._stats["item_created"] += 1
        self._logger.info(f"Created item {item_id}")
        return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取记忆项"""
        with self._lock:
            record = self._item_store.get(item_id)
            if record:
                self._stats["item_accessed"] = self._stats.get("item_accessed", 0) + 1
        return record["data"] if record else None

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新记忆项并维护索引"""
        with self._lock:
            record = self._item_store.get(item_id)
            if not record:
                return False

            old_data = record["data"]
            old_modality = old_data.get("modality")
            old_type = old_data.get("memory_type")

            record["data"].update(copy.deepcopy(data))
            new_modality = record["data"].get("modality")
            new_type = record["data"].get("memory_type")

            if old_modality != new_modality or old_type != new_type:
                self._unindex_record(item_id, {"modality": old_modality, "memory_type": old_type})
                self._index_record(item_id, record["data"])
            
            record["updated_at"] = time.time()
            record["version"] += 1
            self._stats["item_updated"] += 1
        self._logger.info(f"Updated item {item_id}")
        return True

    def delete_item(self, item_id: str) -> bool:
        """删除记忆项并清理索引"""
        with self._lock:
            record = self._item_store.pop(item_id, None)
            if record:
                self._unindex_record(item_id, record["data"])
                self._stats["item_deleted"] += 1
        self._logger.info(f"Deleted item {item_id}")
        return record is not None

    def list_items(
        self,
        page: int = 1,
        page_size: int = 20,
        filters: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """分页列出记忆项"""
        with self._lock:
            records = list(self._item_store.values())
            if filters:
                records = [r for r in records if all(r["data"].get(k) == v for k, v in filters.items())]
            
            total = len(records)
            start = (page - 1) * page_size
            end = start + page_size
            return {
                "items": [r["data"] for r in records[start:end]],
                "total": total,
                "page": page,
                "page_size": page_size
            }

    def count_items(self) -> int:
        """统计记忆项数量"""
        with self._lock:
            return len(self._item_store)

    def search_items(
        self,
        query: str,
        fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """索引驱动的多字段搜索
        
        优化策略：
        1. 如果查询匹配特定的模态或类型，直接从对应索引返回。
        2. 否则，遍历索引查找候选ID，再校验内容。
        """
        if not query:
            return []
        
        query_lower = query.lower()
        results: Set[str] = set()
        
        # 优化路径 1: 查询是否匹配特定的模态或类型
        modality_match = SensoryModality.from_str(query)
        type_match = MemoryType.from_str(query)
        
        if modality_match:
            item_ids = self._index_by_modality.get(modality_match.value, set())
            for item_id in item_ids:
                record = self._item_store.get(item_id)
                if record and query_lower in str(record["data"].get("content", "")).lower():
                    results.add(item_id)
            return [self._item_store[item_id]["data"] for item_id in results]
            
        if type_match:
            item_ids = self._index_by_type.get(type_match.value, set())
            for item_id in item_ids:
                record = self._item_store.get(item_id)
                if record and query_lower in str(record["data"].get("content", "")).lower():
                    results.add(item_id)
            return [self._item_store[item_id]["data"] for item_id in results]

        # 优化路径 2: 遍历索引查找候选
        # 合并所有索引以减少遍历次数
        all_indices = {**self._index_by_modality, **self._index_by_type}
        
        for item_ids in all_indices.values():
            for item_id in item_ids:
                record = self._item_store.get(item_id)
                if record and query_lower in str(record["data"].get("content", "")).lower():
                    results.add(item_id)
                    
        return [self._item_store[item_id]["data"] for item_id in results]

    def batch_create_items(self, batch: List[Dict[str, Any]]) -> List[str]:
        """批量创建记忆项"""
        with self._lock:
            return [self.create_item(item) for item in batch]

    def batch_delete_items(self, ids: List[str]) -> int:
        """批量删除记忆项"""
        deleted = 0
        with self._lock:
            for item_id in ids:
                if self.delete_item(item_id):
                    deleted += 1
        return deleted

    def get_item_stats(self) -> Dict[str, Any]:
        """获取操作统计"""
        with self._lock:
            return {
                "total": len(self._item_store),
                "created": self._stats["item_created"],
                "updated": self._stats["item_updated"],
                "deleted": self._stats["item_deleted"]
            }

    def export_items(self, path: str) -> str:
        """导出记忆项为JSON"""
        target = resolve_writable_path(path)
        with self._lock:
            snapshot = list(self._item_store.values())
        
        with open(target, "w", encoding="utf-8") as f:
            json.dump(
                snapshot,
                f,
                ensure_ascii=False,
                indent=JSON_INDENT,
                default=str
            )
        self._logger.info(f"Exported {len(snapshot)} items to {target}")
        return target

    def import_items(self, path: str) -> int:
        """导入记忆项并重建索引"""
        if not os.path.exists(path):
            raise FileNotFoundError(f"导入文件不存在: {path}")

        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)
        
        if not isinstance(payload, list):
            raise ValueError("导入内容必须为JSON数组")

        imported = 0
        with self._lock:
            for record in payload:
                item_id = record.get("id") or generate_id("perception_memory_item")
                record["id"] = item_id
                self._item_store[item_id] = copy.deepcopy(record)
                self._index_record(item_id, record.get("data", {}))
                imported += 1
        self._logger.info(f"Imported {imported} items from {path}")
        return imported

# ---------------------------------------------------------------------------
# 指标记录
# ---------------------------------------------------------------------------
class MetricsMixin:
    """指标记录 Mixin"""
    _lock: threading.RLock
    _metrics: Dict[str, Any]
    _logger: logging.Logger

    def __init__(self, logger: logging.Logger) -> None:
        self._lock = threading.RLock()
        self._metrics = {
            "cache": {"size": 0, "hit_rate": 0, "miss_rate": 0, "overdue": 0},
            "items": {"total": 0, "created": 0, "updated": 0, "deleted": 0}
        }
        self._logger = logger

    def update_cache_stats(self, cache_stats: Dict[str, Any]) -> None:
        """更新缓存指标"""
        with self._lock:
            self._metrics["cache"].update(cache_stats)

    def get_metrics(self) -> Dict[str, Any]:
        """获取所有指标"""
        with self._lock:
            return self._metrics

# ---------------------------------------------------------------------------
# 核心内存管理类
# ---------------------------------------------------------------------------
class PerceptionMemory:
    """感知记忆核心管理类"""
    def __init__(self, logger: logging.Logger) -> None:
        self._item_store = ItemStoreMixin(logger)
        self._metrics_mixin = MetricsMixin(logger)
        self._cache = LRUWithTTL(DEFAULT_CACHE_SIZE)
        self._logger = logger

    @property
    def item_stats(self) -> Dict[str, Any]:
        """获取内存项统计"""
        return self._item_store.get_item_stats()

    @property
    def cache_stats(self) -> Dict[str, Any]:
        """获取缓存统计"""
        return self._cache.stats()

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取记忆项（带缓存）"""
        cached_value = self._cache.get(item_id)
        if cached_value is not None:
            return cached_value
        return self._item_store.get_item(item_id)

    def create_item(self, data: Dict[str, Any]) -> str:
        """创建记忆项（带缓存）"""
        item_id = self._item_store.create_item(data)
        self._cache.set(item_id, data)
        return item_id

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新记忆项（带缓存）"""
        if self._item_store.update_item(item_id, data):
            self._cache.set(item_id, data)
            return True
        return False

    def delete_item(self, item_id: str) -> bool:
        """删除记忆项（带缓存）"""
        if self._item_store.delete_item(item_id):
            self._cache.invalidate(item_id)
            return True
        return False

    def search_items(self, query: str, fields: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """搜索记忆项（带缓存）"""
        return self._item_store.search_items(query, fields)

    def export_items(self, path: str) -> str:
        """导出记忆项（带缓存）"""
        return self._item_store.export_items(path)

    def import_items(self, path: str) -> int:
        """导入记忆项（带缓存）"""
        return self._item_store.import_items(path)

    def get_all_items(self) -> List[Dict[str, Any]]:
        """获取所有记忆项（带缓存）"""
        return [item for item in self._item_store.list_items(page=1, page_size=100000)]

    def get_all_metrics(self) -> Dict[str, Any]:
        """获取所有指标"""
        return {
            "items": self._item_store.get_item_stats(),
            "cache": self._cache.stats(),
            "global": self._metrics_mixin.get_metrics()
        }

# ---------------------------------------------------------------------------
# 模块导出
# ---------------------------------------------------------------------------
logger = setup_logger(__name__)
perception_memory = PerceptionMemory(logger)


def _setup_logger(name):
    """设置日志器。"""
    import logging
    return logging.getLogger(name)
