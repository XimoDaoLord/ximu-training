import logging
import os
import re
import time
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# 纯 base64 字符集（含少量空白）。_normalize_image_input 用它判断"长串是不是裸 base64"。
# 第二轮性能：原实现 set(s) <= _b64_chars 对一张 500KB 照片(66万字符)要建 66万元素集合，
# 实测 ~3.1ms；改为 C 级正则 fullmatch，~0.77ms（4x）。模块级预编译一次。
_BARE_B64_RE = re.compile(r"[A-Za-z0-9+/=\s]+")

# ===== 阈值与常量（集中管理）=====

_LOCAL_CONFIDENCE_THRESHOLD = 0.7  # 本地结果置信度低于此值 → 升级云
_LOCAL_TIMEOUT_S = 30.0  # 本地推理超时（阶段B接入真实模型后生效）
_CLOUD_TIMEOUT_S = 60.0  # 云多模态调用超时
_LOCAL_MODEL_SUBDIR = "multimodal"  # 本地多模态模型根目录子名（data/用户数据/本地模型/multimodal/<task_type>/）
# task_type → 模态归属
_TASK_MODALITY: Dict[str, str] = {
    "ocr": "vision",
    "image_caption": "vision",
    "vqa": "vision",
    "face_detect": "vision",
    "scene_detect": "vision",
    "emotion": "vision",  # 图像情绪
    "video_caption": "vision",  # 视频理解（抽帧→VLM）
    "asr": "audio",
    "speaker_verify": "audio",
}

# 各视觉任务发给云视觉模型的提示词（模板）
_TASK_PROMPTS: Dict[str, str] = {
    "ocr": "请识别并输出这张图片中的全部文字，尽量保持原有排版。只输出识别到的文字，不要解释。",
    "image_caption": "请用一句简洁的中文描述这张图片的内容。",
    "vqa": "请根据这张图片回答用户的问题。",
    "face_detect": "请检测图片中出现的人脸数量，并描述每张人脸的位置。",
    "scene_detect": "请判断这张图片的场景类型（如室内/室外/自然/街道/办公等）并简要说明依据。",
    "emotion": "请根据图片中人物的面部表情判断情绪类别。",
    "video_caption": "请逐帧理解这段视频并生成内容摘要。",
}

SUPPORTED_TASK_TYPES = tuple(sorted(_TASK_MODALITY.keys()))

def _local_model_root() -> str:
    """定位本地多模态模型根目录：<data_root>/用户数据/本地模型/multimodal/。"""
    try:
        from src.ximu.core.data_root import local_models_dir

        return os.path.join(local_models_dir(), _LOCAL_MODEL_SUBDIR)
    except Exception:
        here = os.path.dirname(os.path.abspath(__file__))
        # src/ximu/core/multimodal/router.py -> 上溯四级到源码根
        root = os.path.abspath(os.path.join(here, "..", "..", "..", ".."))
        return os.path.join(root, "data", "用户数据", "本地模型", _LOCAL_MODEL_SUBDIR)


class MultimodalRouter:
    """多模态任务路由编排器。

    依赖注入点（便于 mock 验证；生产默认接真实实现）：
        - local_runner(task_type, input_data, **kwargs) -> dict
            签名：{"success": bool, "result": Any, "confidence": float, "error": str|None}
        - cloud_vision(image_data, prompt, **kwargs) -> dict
            签名：与 live_model_gateway.chat_vision 同构 {"ok": bool, "content":..., ...}
        - cloud_audio(image_data, prompt, **kwargs) -> dict
            签名：与 live_model_gateway.chat_audio 同构 {"ok": bool, "content":..., ...}
        - transit_purify(text: str) -> Dict[str, Any]
            签名：{"action": str, ...}
        - transit_collect(kind: str, data: Any) -> None
    """

    def __init__(
        self,
        local_runner: Optional[Callable[..., Dict[str, Any]]] = None,
        cloud_vision: Optional[Callable[..., Dict[str, Any]]] = None,
        cloud_audio: Optional[Callable[..., Dict[str, Any]]] = None,
        transit_purify: Optional[Callable[..., Dict[str, Any]]] = None,
        transit_collect: Optional[Callable[..., None]] = None,
    ):
        # 生产默认实现（延迟导入，避免循环依赖）
        self._local_runner = local_runner
        self._cloud_vision = cloud_vision
        self._cloud_audio = cloud_audio
        self._transit_purify = transit_purify
        self._transit_collect = transit_collect
        self._route_logs: List[Dict[str, Any]] = []
        # 云通路可用性 TTL 缓存：list_vision_models() 每次都 load_providers()+get_model_health()，
        # 在 process() 热路径里反复调用是主要开销。可用性是低频变化状态，5s TTL 足够。
        self._cloud_avail_ttl_s: float = 5.0
        self._cloud_avail_cache: Dict[str, bool] = {}
        self._cloud_avail_ts: Dict[str, float] = {}
        # 第二轮性能：缓存 transit_hub.collect 的解析结果，避免每次 _audit 都重新跑
        # `from src.ximu.core.transit_hub import collect` 的 importlib fromlist 开销
        # （cProfile：process() 里 3 次 _audit，占内部耗时 ~39%）。
        self._th_collect: Optional[Callable[..., None]] = None

    def _default_cloud_vision(self, image_data: str, prompt: str, **kw) -> Dict[str, Any]:
        from src.ximu.core.live_model_gateway import chat_vision as _cv

        return _cv(image_data, prompt, **kw)

    def _default_purify(self, text: str) -> Dict[str, Any]:
        from src.ximu.core.transit_hub import purify_for_upload as _pf

        return _pf(text, level="clean")

    def _default_collect(self, kind: str, data: Any) -> None:
        try:
            fn = self._th_collect
            if fn is None:
                from src.ximu.core.transit_hub import collect as _c

                self._th_collect = fn = _c
            fn(kind, data)
        except Exception:
            pass

    def _local_model_dir(self, task_type: str) -> str:
        return os.path.join(_local_model_root(), task_type)

    def local_model_available(self, task_type: str) -> bool:
        """本地多模态模型是否已下载（任务感知：VLM→vlm目录，OCR→ocr目录）。"""
        # VLM 任务（MiniCPM-V）文件落在 multimodal/vlm/
        if task_type in ("image_caption", "vqa", "video_caption"):
            try:
                from src.ximu.core.multimodal import local_vlm as _vlm

                return _vlm.is_local_vlm_available()
            except Exception:
                return False
        # OCR 任务（PP-OCR）文件落在 multimodal/ocr/
        if task_type == "ocr":
            try:
                from src.ximu.core.multimodal import local_ocr as _ocr

                return _ocr.is_local_ocr_available()
            except Exception:
                return False
        # 其余任务：通用目录探测
        d = self._local_model_dir(task_type)
        if not os.path.isdir(d):
            return False
        exts = (".onnx", ".pt", ".pth", ".bin", ".gguf", ".safetensors", ".engine", ".torchscript", ".plan")
        for _, _, files in os.walk(d):
            for f in files:
                if f.lower().endswith(exts):
                    return True
        return False

    def local_runner_ready(self, task_type: str) -> bool:
        """本地推理 runner 是否已装配（阶段B/C 注册真实 runner；测试用 mock）。"""
        if isinstance(self._local_runner, dict):
            return callable(self._local_runner.get(task_type))
        return callable(self._local_runner)

    def combo_available(self, task_type: str) -> bool:
        """P110++ 联合判定：插件(感官)可用 + 老文本模型(大脑)可用。
        VLM 都不可用时走"插件当感官+老模型当大脑"组合，而非直接 need_setup。
        """
        try:
            from src.ximu.core.multimodal import combo_plugin

            return combo_plugin.combo_available(task_type)
        except Exception:
            return False

    def _call_combo(self, task_type: str, input_data: Any, prompt: str, **kw) -> Dict[str, Any]:
        try:
            from src.ximu.core.multimodal import combo_plugin

            return combo_plugin.combo_runner(task_type, input_data, prompt=prompt, **kw)
        except Exception as e:
            return {"success": False, "error": f"combo_exception:{e}", "result": None, "confidence": 0.0}

    def cloud_available(self, modality: str) -> bool:
        """云多模态通路是否可用：视觉走 chat_vision 候选枚举；音频阶段A未实现。
        结果按 modality 做 5s TTL 缓存（见 __init__ 中 _cloud_avail_ttl_s），避免在 process() 热路径里每次都 load_providers()+get_model_health()。
        """
        now = time.time()
        cached = self._cloud_avail_cache.get(modality)
        if cached is not None and (now - self._cloud_avail_ts.get(modality, 0.0)) < self._cloud_avail_ttl_s:
            return cached
        result = self._probe_cloud_available(modality)
        self._cloud_avail_cache[modality] = result
        self._cloud_avail_ts[modality] = now
        return result

    def _probe_cloud_available(self, modality: str) -> bool:
        if modality == "vision":
            try:
                from src.ximu.core.live_model_gateway import list_vision_models

                return len(list_vision_models()) > 0
            except Exception:
                return False
        if modality == "audio":
            # 阶段A：云音频（ASR/声纹）尚未接入 chat_audio，诚实标记不可用
            return self._cloud_audio is not None
        return False

    def ensure_local_model(self, task_type: str) -> Dict[str, Any]:
        """检查本地模型是否已下载；未下载时返回 need_setup + 下载指引。
        阶段A 不自动下载大模型，只接入下载入口（复用 P90 bge-small-zh onnx 模式：
        模型落盘到 data/用户数据/本地模型/multimodal/<task_type>/，带进度/校验/断点
        在阶段B接入真实下载器后启用）。
        """
        if task_type not in _TASK_MODALITY:
            return {"status": "error", "message": f"不支持的 task_type: {task_type}"}
        if self.local_model_available(task_type):
            return {"status": "ready", "task_type": task_type, "path": self._local_model_dir(task_type), "message": "本地模型已下载"}
        return {
            "status": "need_setup",
            "task_type": task_type,
            "missing_local": {
                "task_type": task_type,
                "expected_path": self._local_model_dir(task_type),
                "message": (
                    f"本地 {task_type} 模型尚未下载。请将模型文件（onnx/pt/safetensors 等）放入 "
                    f"data/用户数据/本地模型/multimodal/{task_type}/ "
                    f"后重试。"
                ),
            },
        }

    def _audit(self, rec: Dict[str, Any]) -> None:
        rec = dict(rec)
        rec["ts"] = time.time()
        self._route_logs.append(rec)
        try:
            collect = self._transit_collect or self._default_collect
            collect("multimodal_route", rec)
        except Exception:
            pass

    @property
    def route_logs(self) -> List[Dict[str, Any]]:
        return list(self._route_logs)

    def process(self, task_type: str, input_data: Any, **kwargs) -> Dict[str, Any]:
        """多模态任务统一入口。
        参数：
            task_type: ocr/image_caption/vqa/face_detect/scene_detect/emotion/asr/speaker_verify
            input_data: 图像(base64/URL/路径) 或 音频；VQA 另传 question=...
            kwargs: prompt 覆盖、question、timeout、force_source 等
        返回：
            {status, result, source, confidence, latency_ms, error?, missing?}
            status: success | need_setup | error
            source: local | cloud | None
        """
        if task_type not in _TASK_MODALITY:
            return {
                "status": "error",
                "source": None,
                "message": f"不支持的 task_type: {task_type}",
                "supported": list(SUPPORTED_TASK_TYPES),
            }
        modality = _TASK_MODALITY[task_type]
        prompt_override = kwargs.get("prompt")
        force_source = kwargs.get("force_source")
        # 测试/调试用：强制 local/cloud
        t0 = time.perf_counter()
        # ===== P142 输入适配：base64/dataURL/路径 → ndarray =====
        # 视觉任务（非视频）统一解码；视频路径保持 str；音频保持 bytes。
        if modality == "vision" and task_type != "video_caption":
            input_data, _kind = self._normalize_image_input(input_data)
            self._audit({"task_type": task_type, "stage": "input_adapt", "kind": _kind})
        # ===== 数据经唯一通道：transit_hub 过滤 + 审计 =====
        # P132 修复：系统内置 prompt 视为可信，不被 empty/dropped_junk/dedup_5min 误杀；
        # 真正需要真安全过滤的是【用户输入】（vqa 的 question / 用户文本数据）。
        # 仅 blocked_injection/blocked_risk 这类真安全拦截才阻断；
        # dropped_junk/empty/dedup_5min 对内置 prompt 或用户 question 都不阻断，继续流程。
        user_question = ""
        if task_type == "vqa":
            user_question = str(kwargs.get("question", "") or "")
        # 只对【用户输入 question】做真安全过滤；ASR 空 prompt / 系统内置 prompt 不被误杀
        if user_question:
            try:
                purify = self._transit_purify or self._default_purify
                pf = purify(user_question)
                action = (pf or {}).get("action", "")
                # ...[中间省略]...
            except Exception:
                pass
        # ===== 本地模型下载接入点 =====
        # ===== 路由审计 =====
        # ===== 主入口 =====
        latency_ms = round((time.perf_counter() - t0) * 1000, 1)
        out: Dict[str, Any] = {
            "status": status,
            "task_type": task_type,
            "source": kw.get("source"),
            "result": kw.get("result"),
            "confidence": kw.get("confidence"),
            "latency_ms": latency_ms,
        }
        for k in (
            "provider",
            "model",
            "error",
            "missing_local",
            "missing_cloud",
            "local_error",
            "cloud_error",
            "message",
        ):
            if k in kw and kw[k] is not None:
                out[k] = kw[k]
        return out
        need_setup = "need_setup"
        # ===== 模块级单例（供应用层直接取用） =====
        _default_router: Optional[MultimodalRouter] = None

        def get_multimodal_router() -> MultimodalRouter:
            nonlocal _default_router
            if _default_router is None:
                r = MultimodalRouter()
                runners: Dict[str, Any] = {}
                # 阶段B：真实本地 OCR（PP-OCRv4 ONNX）
                try:
                    from src.ximu.core.multimodal import local_ocr as _ocr

                    if _ocr.is_local_ocr_available():
                        runners["ocr"] = _ocr.local_runner
                except Exception:
                    pass
                # 阶段B+：端侧 VLM（MiniCPM-V 4.6 GGUF）——按需加载，文件在即注册
                try:
                    from src.ximu.core.multimodal import local_vlm as _vlm

                    if _vlm.is_local_vlm_available():
                        runners["image_caption"] = _vlm.local_runner
                        runners["vqa"] = _vlm.local_runner
                        runners["video_caption"] = _vlm.local_runner
                except Exception:
                    pass
                r._local_runner = runners or None
                _default_router = r
            return _default_router

        def register_local_runner(task_type: str, runner: Callable[..., Dict[str, Any]]) -> None:
            """阶段B/C 注册真实本地推理 runner 的入口（按 task_type 分发）。"""
            r = get_multimodal_router()
            if not isinstance(r._local_runner, dict):
                r._local_runner = {}
            if r._local_runner is None:
                r._local_runner = {"_default": r._local_runner}
            r._local_runner[task_type] = runner


# ===== 模块级单例（供应用层直接取用） =====
_default_router: Optional[MultimodalRouter] = None


def get_multimodal_router() -> MultimodalRouter:
    """获取全局默认多模态路由器单例。"""
    global _default_router
    if _default_router is None:
        r = MultimodalRouter()
        runners: Dict[str, Any] = {}
        # 阶段B：真实本地 OCR（PP-OCRv4 ONNX）
        try:
            from src.ximu.core.multimodal import local_ocr as _ocr
            if _ocr.is_local_ocr_available():
                runners["ocr"] = _ocr.local_runner
        except Exception:
            pass
        # 阶段B+：端侧 VLM（MiniCPM-V 4.6 GGUF）
        try:
            from src.ximu.core.multimodal import local_vlm as _vlm
            if _vlm.is_local_vlm_available():
                runners["image_caption"] = _vlm.local_runner
                runners["vqa"] = _vlm.local_runner
                runners["video_caption"] = _vlm.local_runner
        except Exception:
            pass
        r._local_runner = runners or None
        _default_router = r
    return _default_router


def register_local_runner(task_type: str, runner: Callable[..., Dict[str, Any]]) -> None:
    """注册真实本地推理 runner 的入口（按 task_type 分发）。"""
    r = get_multimodal_router()
    if not isinstance(r._local_runner, dict):
        r._local_runner = {}
    r._local_runner[task_type] = runner
