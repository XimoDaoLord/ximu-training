"""文本感知层（Text Perception）。

提供关键词抽取、分类、实体识别等轻量级文本处理入口。
"""
from __future__ import annotations

import importlib as _importlib
import logging as _logging
import re
from collections import Counter
from typing import Any, Dict, List, Optional, Union

_logger = _logging.getLogger(__name__)

def _load_parts(parts: tuple[str, ...], package: str) -> List[str]:
    """通用子模块重导出函数。

    Args:
        parts: part 名称元组。
        package: 子包名。

    Returns:
        成功导出的公开名称列表。
    """
    public_names: List[str] = []
    for part_name in parts:
        module_name = f".{package}.{part_name}"
        try:
            module = _importlib.import_module(module_name, package=__package__)
            for attr in dir(module):
                if not attr.startswith("_") and attr not in globals():
                    globals()[attr] = getattr(module, attr)
                    public_names.append(attr)
        except Exception as exc:
            _logger.warning("text_perception re-export %s failed: %s", module_name, exc)
    return public_names

_PUBLIC_NAMES: List[str] = _load_parts(('part1', 'part2', 'part3'), '_text_perception_parts')
__all__: List[str] = sorted(set(_PUBLIC_NAMES))

class TextPerceptionEngine:
    """简洁文本感知入口。

    支持 KEYWORDS / CLASSIFY / NER 等任务的规则基线实现。
    """

    def __init__(self) -> None:
        """初始化文本感知引擎。"""
        self._core: Any = None

    def perceive(self, text: str, task: str = "CLASSIFY") -> Dict[str, Any]:
        """对文本执行感知任务。

        Args:
            text: 输入文本。
            task: 任务类型，支持 KEYWORDS / CLASSIFY / NER。

        Returns:
            包含任务类型、结果和置信度的字典。

        Raises:
            ValueError: 当 text 为空字符串时抛出。
        """
        if not text or not text.strip():
            raise ValueError("text must be a non-empty string")

        clean: str = text.strip()
        if task == "KEYWORDS":
            words: List[str] = re.findall(r"[\u4e00-\u9fa5]{2,}|[a-zA-Z]{3,}", clean)
            top: List[tuple] = Counter(words).most_common(10)
            return {
                "task": task,
                "result": {"keywords": [w for w, _ in top]},
                "confidence": 0.7,
                "error": None,
            }

        if task == "NER":
            # 规则基线：匹配中文人名模式（暂占位）
            entities: List[Dict[str, Any]] = []
            return {
                "task": task,
                "result": {"entities": entities},
                "confidence": 0.5,
                "error": None,
            }

        return {
            "task": task,
            "result": {"raw_text": clean[:200]},
            "confidence": 0.5,
            "error": None,
        }
