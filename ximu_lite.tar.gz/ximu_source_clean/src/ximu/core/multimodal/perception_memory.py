"""感知记忆层（Perception Memory）。

存储和检索感知结果，支持内存缓存 + 文件持久化，线程安全。
"""
from __future__ import annotations

import importlib as _importlib
import json as _json
import logging as _logging
import os as _os
import queue as _queue
import threading as _threading
import time as _time
from typing import Any, Dict, List, Optional

_logger = _logging.getLogger(__name__)

def _load_parts(parts: tuple[str, ...], package: str) -> List[str]:
    """通用子模块重导出函数。

    Args:
        parts: part 名称元组。
        package: 子包名。

    Returns:
        成功导出的公开名称列表。
    """
    public_names: List[str] = []
    for part_name in parts:
        module_name = f".{package}.{part_name}"
        try:
            module = _importlib.import_module(module_name, package=__package__)
            for attr in dir(module):
                if not attr.startswith("_") and attr not in globals():
                    globals()[attr] = getattr(module, attr)
                    public_names.append(attr)
        except Exception as exc:
            _logger.warning("re-export %s failed: %s", module_name, exc)
    return public_names

_PUBLIC_NAMES: List[str] = _load_parts(('part1', 'part2', 'part3'), '_perception_memory_parts')
__all__: List[str] = sorted(set(_PUBLIC_NAMES))

class PerceptionMemoryStore:
    """感知记忆存储：内存字典 + JSON 文件持久化。

    线程安全，自动落盘到指定目录，支持后台刷盘。
    """

    def __init__(self, persist_dir: str = "") -> None:
        """初始化感知记忆存储。

        Args:
            persist_dir: 持久化目录路径，为空则使用默认路径。
        """
        self._lock = _threading.RLock()
        self._mem: Dict[str, Dict[str, Any]] = {}
        self._persist_dir: str = persist_dir or self._default_dir()
        self._dirty: _queue.Queue[str] = _queue.Queue()
        self._stop: _threading.Event = _threading.Event()
        self._flush_thread: Optional[_threading.Thread] = None
        _os.makedirs(self._persist_dir, exist_ok=True)

    def _default_dir(self) -> str:
        """计算默认持久化目录。

        Returns:
            默认目录绝对路径。
        """
        here = _os.path.dirname(_os.path.abspath(__file__))
        root = _os.path.abspath(_os.path.join(here, "..", "..", "..", ".."))
        return _os.path.join(root, "data", "用户数据", "感知记忆")

    def remember(self, key: str, perception: Any, modality: str = "text", metadata: Optional[Dict[str, Any]] = None) -> str:
        """存储一条感知结果。

        Args:
            key: 记忆键。
            perception: 感知内容。
            modality: 感官模态。
            metadata: 附加元数据。

        Returns:
            唯一记忆项 ID。

        Raises:
            ValueError: 当 key 为空时。
        """
        if not key or not key.strip():
            raise ValueError("key must be a non-empty string")
        item_id = f"pm_{int(_time.time() * 1000)}"
        record: Dict[str, Any] = {
            "id": item_id,
            "key": key,
            "modality": modality,
            "perception": perception,
            "metadata": metadata or {},
            "timestamp": _time.time(),
        }
        with self._lock:
            self._mem[key] = record
            self._dirty.put(key)
        return item_id

    def recall(self, key: str) -> Optional[Dict[str, Any]]:
        """按 key 召回感知结果。

        Args:
            key: 要召回的记忆键。

        Returns:
            记忆记录字典，若不存在则返回 None。
        """
        with self._lock:
            return self._mem.get(key)

    def flush(self) -> int:
        """将所有脏记录写入磁盘。

        Returns:
            实际写入的记录数量。
        """
        written: int = 0
        while True:
            try:
                key: str = self._dirty.get_nowait()
            except _queue.Empty:
                break
            with self._lock:
                record = self._mem.get(key)
            if record is None:
                continue
            filepath = _os.path.join(self._persist_dir, f"{key}.json")
            try:
                with open(filepath, "w", encoding="utf-8") as fh:
                    _json.dump(record, fh, ensure_ascii=False, indent=2)
                written += 1
            except OSError as exc:
                _logger.error("写感知记忆失败 key=%s: %s", key, exc)
        return written

    def start_flush_loop(self) -> None:
        """启动后台刷盘线程。"""
        if self._flush_thread is not None and self._flush_thread.is_alive():
            return

        def _loop() -> None:
            while not self._stop.wait(timeout=5.0):
                try:
                    self.flush()
                except Exception as exc:
                    _logger.error("后台刷盘异常: %s", exc, exc_info=True)

        self._stop.clear()
        thread = _threading.Thread(target=_loop, daemon=True, name="PerceptionMemoryFlush")
        self._flush_thread = thread
        thread.start()

    def stop_flush_loop(self) -> None:
        """停止后台刷盘线程并做最后一次刷盘。"""
        self._stop.set()
        if self._flush_thread is not None:
            self._flush_thread.join(timeout=5.0)
            self._flush_thread = None
        self.flush()
