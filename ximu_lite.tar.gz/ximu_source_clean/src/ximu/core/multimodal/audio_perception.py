# -*- coding: utf-8 -*-
"""音频感知模块再导出层。

原音频感知实现已拆分为 _audio_perception_parts 下的三个子模块，
本模块负责聚合并重新导出所有公开接口，保持向后兼容。
"""
from __future__ import annotations

import importlib as _il
import logging as _logging
from typing import List

logger = _logging.getLogger(__name__)

# 模块级公开名称注册表
_PUBLIC_NAMES: List[str] = []


def _load_audio_perception_parts() -> List[str]:
    """加载音频感知拆分模块并导出公开名称。

    遍历 part1~part3 子模块，将非下划线开头的公开符号
    提升到当前命名空间。

    Returns:
        成功导出的公开名称列表。
    """
    public_names: List[str] = []
    for part_name in ("part1", "part2", "part3"):
        module_name = f"._audio_perception_parts.{part_name}"
        try:
            module = _il.import_module(module_name, package=__package__)
            for attr in dir(module):
                if not attr.startswith("_") and attr not in globals():
                    globals()[attr] = getattr(module, attr)
                    public_names.append(attr)
        except Exception as exc:
            logger.warning(
                "加载音频感知模块 %s 失败: %s", module_name, exc, exc_info=True
            )
    return public_names


# 在模块加载时执行聚合
_PUBLIC_NAMES.extend(_load_audio_perception_parts())
__all__ = sorted(set(_PUBLIC_NAMES))
