"""文本嵌入模块缓存管理、指标记录、配置管理、事件处理和数据存储组件。

本模块提供文本嵌入系统的底层基础设施，包括缓存后端、指标记录器、
配置管理器、事件总线和数据存储层，支持并发访问和版本控制。
"""
from __future__ import annotations

import json
import logging
import statistics
import threading
import time
import uuid
from collections import OrderedDict, defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Protocol, Tuple

logger = logging.getLogger(__name__)


class CacheBackend(Protocol):
    """缓存后端协议接口，定义缓存操作标准方法。"""

    def get(self, key: str) -> Optional[Any]: ...
    def set(self, key: str, value: Any, ttl: float) -> None: ...
    def invalidate(self, key: str) -> bool: ...
    def clear(self) -> int: ...
    def size(self) -> int: ...


class TTLCacheBackend:
    """基于TTL的LRU缓存实现，支持线程安全访问和自动过期清理。"""

    def __init__(self, max_size: int = 10000) -> None:
        self._max_size = max_size
        self._cache: OrderedDict[str, Tuple[Any, float, float]] = OrderedDict()
        self._lock = threading.RLock()
        self._eviction_handlers: List[Callable[[str], None]] = []

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值，检查TTL过期并移至最近使用位置。

        Args:
            key: 缓存键

        Returns:
            缓存值，若不存在或已过期则返回None
        """
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            value, timestamp, ttl = entry
            if time.monotonic() - timestamp > ttl:
                del self._cache[key]
                self._notify_eviction(key)
                return None
            self._cache.move_to_end(key)
            return value

    def set(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """设置缓存值，超过最大容量时自动淘汰最旧条目。

        Args:
            key: 缓存键
            value: 缓存值
            ttl: 生存时间（秒）
        """
        with self._lock:
            self._cache[key] = (value, time.monotonic(), ttl)
            self._cache.move_to_end(key)
            while len(self._cache) > self._max_size:
                evicted_key, _ = self._cache.popitem(last=False)
                self._notify_eviction(evicted_key)

    def invalidate(self, key: str) -> bool:
        """使指定键的缓存失效。

        Args:
            key: 缓存键

        Returns:
            是否成功失效
        """
        with self._lock:
            removed = self._cache.pop(key, None) is not None
            if removed:
                self._notify_eviction(key)
            return removed

    def clear(self) -> int:
        """清空所有缓存条目。

        Returns:
            清空的条目数
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
            return count

    def size(self) -> int:
        """获取当前缓存条目数。

        Returns:
            缓存大小
        """
        with self._lock:
            return len(self._cache)

    def stats(self) -> Dict[str, Any]:
        """获取缓存统计信息。

        Returns:
            包含size和max_size的字典
        """
        with self._lock:
            return {"size": len(self._cache), "max_size": self._max_size}

    def on_eviction(self, handler: Callable[[str], None]) -> None:
        """注册缓存淘汰回调处理器。

        Args:
            handler: 回调函数，接收被淘汰的键
        """
        self._eviction_handlers.append(handler)

    def _notify_eviction(self, key: str) -> None:
        """通知所有注册的淘汰处理器。

        Args:
            key: 被淘汰的键
        """
        for handler in self._eviction_handlers:
            try:
                handler(key)
            except Exception as exc:
                logger.warning("缓存淘汰回调异常: %s", exc)


class MetricsRecorder:
    """指标记录器，支持标签聚合和时间序列数据，自动压缩历史点。"""

    def __init__(self, max_points: int = 10000, retention_points: int = 5000) -> None:
        self._metrics: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._max_points = max_points
        self._retention_points = retention_points
        self._lock = threading.RLock()

    def record(self, value: float, labels: Optional[Dict[str, str]] = None) -> None:
        """记录指标值，按标签组合键存储时间序列数据。

        Args:
            value: 指标数值
            labels: 可选标签字典
        """
        key = json.dumps(labels or {}, sort_keys=True)
        entry = {"value": value, "time": time.time(), "labels": labels or {}}
        with self._lock:
            series = self._metrics[key]
            series.append(entry)
            if len(series) > self._max_points:
                self._metrics[key] = series[-self._retention_points:]

    def get_stats(self, labels: Optional[Dict[str, str]] = None) -> Dict[str, float]:
        """获取指标统计信息，包括均值、分位数等。

        Args:
            labels: 标签字典，None表示所有数据

        Returns:
            包含count/mean/min/max/p50/p95/p99的统计字典
        """
        key = json.dumps(labels or {}, sort_keys=True)
        with self._lock:
            values = [e["value"] for e in self._metrics.get(key, [])]
        if not values:
            return {"count": 0, "mean": 0.0, "min": 0.0, "max": 0.0,
                    "p50": 0.0, "p95": 0.0, "p99": 0.0}
        sorted_vals = sorted(values)
        n = len(sorted_vals)
        return {
            "count": n,
            "mean": statistics.mean(values),
            "min": sorted_vals[0],
            "max": sorted_vals[-1],
            "p50": sorted_vals[int(n * 0.5)],
            "p95": sorted_vals[int(n * 0.95)],
            "p99": sorted_vals[int(n * 0.99)],
        }

    def get_history(self, labels: Optional[Dict[str, str]] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """获取指标历史记录。

        Args:
            labels: 标签字典
            limit: 最多返回条目数

        Returns:
            历史记录列表
        """
        key = json.dumps(labels or {}, sort_keys=True)
        with self._lock:
            series = self._metrics.get(key, [])
            return list(series)[-limit:]

    def reset(self) -> None:
        """重置所有指标数据。"""
        with self._lock:
            self._metrics.clear()


class ConfigManager:
    """配置管理器，支持版本控制和JSON持久化，具备基础兼容性检查。"""

    def __init__(self) -> None:
        self._config: Dict[str, Any] = {}
        self._default_config: Dict[str, Any] = {}
        self._version = 1
        self._lock = threading.RLock()

    def get(self, key: str, default: Any = None) -> Any:
        """获取配置项值。

        Args:
            key: 配置键
            default: 键不存在时的默认值

        Returns:
            配置值或默认值
        """
        with self._lock:
            return self._config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """设置单个配置项，版本号自增。

        Args:
            key: 配置键
            value: 配置值
        """
        with self._lock:
            self._config[key] = value
            self._version += 1

    def get_all(self) -> Dict[str, Any]:
        """获取所有配置项的浅拷贝。

        Returns:
            配置字典
        """
        with self._lock:
            return dict(self._config)

    def update(self, updates: Dict[str, Any]) -> None:
        """批量更新配置项，版本号自增。

        Args:
            updates: 待更新的键值对
        """
        with self._lock:
            self._config.update(updates)
            self._version += 1

    def reset(self) -> None:
        """重置为默认配置，版本号自增。"""
        with self._lock:
            self._config = dict(self._default_config)
            self._version += 1

    def set_default(self, config: Dict[str, Any]) -> None:
        """设置并应用默认配置，版本号自增。

        Args:
            config: 默认配置字典
        """
        with self._lock:
            self._default_config = config
            self._config = config.copy()
            self._version += 1
            logger.info("默认配置已设置，版本=%d", self._version)

    def get_version(self) -> int:
        """获取当前配置版本号。

        Returns:
            版本号整数
        """
        with self._lock:
            return self._version

    def export(self, path: str) -> str:
        """将配置导出到JSON文件。

        Args:
            path: 输出文件路径

        Returns:
            实际写入的文件路径
        """
        data = self.get_all()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        logger.info("配置已导出至: %s", path)
        return path

    def import_config(self, path: str) -> bool:
        """从JSON文件导入配置，含基础版本兼容性处理。

        Args:
            path: 输入文件路径

        Returns:
            导入是否成功
        """
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                logger.error("配置文件格式错误: 期望dict，实际为%s", type(data).__name__)
                return False
            self.update(data)
            logger.info("配置导入成功，版本=%d", self.get_version())
            return True
        except json.JSONDecodeError as exc:
            logger.error("JSON解析失败: %s", exc)
            return False
        except OSError as exc:
            logger.error("文件读取失败: %s", exc)
            return False


class EventBus:
    """事件总线，支持处理器注册注销和异步事件分发，异常隔离。"""

    def __init__(self) -> None:
        self._handlers: Dict[str, Callable[[Any], None]] = {}
        self._lock = threading.RLock()

    def on(self, handler: Callable[[Any], None]) -> str:
        """注册事件处理器并返回唯一ID。

        Args:
            handler: 接收任意参数的回调函数

        Returns:
            处理器唯一标识符
        """
        handler_id = self._generate_unique_id()
        with self._lock:
            self._handlers[handler_id] = handler
        logger.debug("事件处理器已注册: %s", handler_id)
        return handler_id

    def off(self, handler_id: str) -> bool:
        """注销指定处理器。

        Args:
            handler_id: 处理器ID

        Returns:
            是否成功注销
        """
        with self._lock:
            removed = self._handlers.pop(handler_id, None) is not None
        if removed:
            logger.debug("事件处理器已注销: %s", handler_id)
        return removed

    def emit(self, data: Any = None) -> int:
        """触发事件，调用所有已注册处理器，逐个隔离异常。

        Args:
            data: 事件数据

        Returns:
            成功执行的处理器数量
        """
        with self._lock:
            handlers = list(self._handlers.values())
        success_count = 0
        for handler in handlers:
            try:
                handler(data)
                success_count += 1
            except Exception as exc:
                logger.warning("事件处理器异常: %s", exc)
        return success_count

    def get_handler_count(self) -> int:
        """获取当前注册处理器数量。

        Returns:
            处理器数量
        """
        with self._lock:
            return len(self._handlers)

    def clear(self) -> None:
        """清空所有处理器。"""
        with self._lock:
            self._handlers.clear()

    def _generate_unique_id(self) -> str:
        """生成唯一处理器ID。

        Returns:
            唯一字符串ID
        """
        base_id = str(len(self._handlers))
        with self._lock:
            candidate = base_id
            counter = 0
            while candidate in self._handlers:
                candidate = f"{base_id}_{counter}"
                counter += 1
            return candidate


class DataStore:
    """数据存储层，支持CRUD、分页和基于过滤器的内存搜索，含乐观锁版本控制。"""

    def __init__(self) -> None:
        self._store: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.RLock()
        self._stats: Dict[str, int] = {"created": 0, "updated": 0, "deleted": 0}

    def create(self, data: Dict[str, Any], item_id: Optional[str] = None) -> str:
        """创建数据项并返回其ID。

        Args:
            data: 数据内容字典
            item_id: 可选自定义ID，随机生成当未提供

        Returns:
            新创建的项ID
        """
        new_id = item_id or str(uuid.uuid4())
        record: Dict[str, Any] = {
            "id": new_id,
            "data": dict(data),
            "created_at": time.time(),
            "updated_at": time.time(),
            "version": 1,
        }
        with self._lock:
            self._store[new_id] = record
            self._stats["created"] += 1
        logger.debug("创建数据项: %s", new_id)
        return new_id

    def get(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取数据项内容。

        Args:
            item_id: 项ID

        Returns:
            数据内容字典或None
        """
        with self._lock:
            record = self._store.get(item_id)
        return record["data"].copy() if record else None

    def update(self, item_id: str, data: Dict[str, Any], expected_version: Optional[int] = None) -> bool:
        """更新数据项，支持可选乐观锁版本检查。

        Args:
            item_id: 项ID
            data: 更新字段
            expected_version: 期望的版本号，None则不校验

        Returns:
            更新是否成功
        """
        with self._lock:
            record = self._store.get(item_id)
            if record is None:
                return False
            if expected_version is not None and record["version"] != expected_version:
                logger.warning("乐观锁冲突: item=%s expected=%d actual=%d",
                               item_id, expected_version, record["version"])
                return False
            record["data"].update(data)
            record["updated_at"] = time.time()
            record["version"] += 1
            self._stats["updated"] += 1
            return True

    def delete(self, item_id: str) -> bool:
        """删除数据项。

        Args:
            item_id: 项ID

        Returns:
            是否成功删除
        """
        with self._lock:
            if item_id in self._store:
                del self._store[item_id]
                self._stats["deleted"] += 1
                return True
        return False

    def list_items(self, page: int = 1, page_size: int = 20,
                   filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """分页列出数据项，支持键值过滤器。

        Args:
            page: 页码（从1开始）
            page_size: 每页数量
            filters: 过滤条件字典

        Returns:
            包含items/total/page/page_size的分页结果
        """
        with self._lock:
            all_records = list(self._store.values())
        filtered = all_records
        if filters:
            filtered = [r for r in all_records if all(
                r["data"].get(k) == v for k, v in filters.items()
            )]
        total = len(filtered)
        start = max(0, (page - 1) * page_size)
        end = start + page_size
        page_items = [{"id": r["id"], **r["data"]} for r in filtered[start:end]]
        return {
            "items": page_items,
            "total": total,
            "page": page,
            "page_size": page_size,
            "pages": max(1, (total + page_size - 1) // page_size),
        }

    def count(self) -> int:
        """统计数据项总数。

        Returns:
            总条数
        """
        with self._lock:
            return len(self._store)

    def search(self, query: str, fields: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """基于子串匹配的搜索功能。

        Args:
            query: 搜索关键词
            fields: 搜索字段列表，None则搜索所有字符串字段

        Returns:
            匹配的数据项列表
        """
        query_lower = query.lower()
        results: List[Dict[str, Any]] = []
        with self._lock:
            for record in self._store.values():
                data = record["data"]
                search_fields = fields or [k for k, v in data.items() if isinstance(v, (str, int, float))]
                for field_name in search_fields:
                    val = data.get(field_name)
                    if val is None:
                        continue
                    if query_lower in str(val).lower():
                        results.append({"id": record["id"], **data})
                        break
        return results

    def batch_create(self, items: List[Dict[str, Any]]) -> List[str]:
        """批量创建数据项。

        Args:
            items: 数据项字典列表

        Returns:
            生成的ID列表
        """
        return [self.create(item) for item in items]

    def batch_delete(self, ids: List[str]) -> int:
        """批量删除数据项。

        Args:
            ids: 项ID列表

        Returns:
            成功删除的数量
        """
        count = sum(1 for item_id in ids if self.delete(item_id))
        logger.info("批量删除完成: %d/%d", count, len(ids))
        return count

    def export(self, path: str) -> str:
        """导出数据项到JSON文件。

        Args:
            path: 输出路径

        Returns:
            实际写入路径
        """
        with self._lock:
            data = list(self._store.values())
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        logger.info("数据导出至: %s，共%d条", path, len(data))
        return path

    def import_data(self, path: str) -> int:
        """从JSON文件导入数据项。

        Args:
            path: 输入文件路径

        Returns:
            成功导入的数量
        """
        count = 0
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, list):
                logger.error("数据文件格式错误: 期望list")
                return 0
            for record in data:
                if not isinstance(record, dict) or "id" not in record:
                    logger.warning("跳过无效记录: %s", record)
                    continue
                item_id = record.get("id")
                with self._lock:
                    self._store[item_id] = record
                    self._stats["created"] += 1
                count += 1
            logger.info("导入%d条数据", count)
        except (json.JSONDecodeError, OSError, KeyError) as exc:
            logger.error("导入失败: %s", exc)
        return count

    def get_stats(self) -> Dict[str, int]:
        """获取数据统计信息。

        Returns:
            包含total/created/updated/deleted的统计字典
        """
        with self._lock:
            return {
                "total": len(self._store),
                **self._stats,
            }


@dataclass
class EmbeddingConfig:
    """嵌入模型配置参数。

    Attributes:
        model_name: 模型名称
        dimension: 向量维度
        max_length: 最大输入长度
        batch_size: 批量大小
    """
    model_name: str = "default"
    dimension: int = 768
    max_length: int = 512
    batch_size: int = 32


class TextEmbedder:
    """文本嵌入器，整合缓存、指标、配置、事件和数据存储核心组件。

    提供文本嵌入转换的完整基础设施，包括缓存管理、指标监控、
    配置持久化、事件通知和数据CRUD操作。
    """

    def __init__(self, cache_max_size: int = 10000,
                 metrics_max_points: int = 10000) -> None:
        """初始化TextEmbedder及其子组件。

        Args:
            cache_max_size: 缓存最大容量
            metrics_max_points: 指标最大记录点数
        """
        self._store = DataStore()
        self._cache = TTLCacheBackend(max_size=cache_max_size)
        self._metrics = MetricsRecorder(max_points=metrics_max_points)
        self._config_mgr = ConfigManager()
        self._event_bus = EventBus()
        self._initialized = False
        self._state_history: List[Tuple[str, float]] = []
        self._transitions: List[Tuple[str, str, float]] = []
        self._lock = threading.RLock()
        self._states = ("idle", "running", "paused", "stopped", "error")
        self._current_state = "idle"
        self._start_time = 0.0
        self._config_mgr.set_default({
            "model_name": "default",
            "dimension": 768,
            "max_length": 512,
            "batch_size": 32,
        })
        logger.info("TextEmbedder初始化完成")

    # ==================== 数据操作 ====================

    def create_item(self, data: Dict[str, Any], item_id: Optional[str] = None) -> str:
        """创建数据项并发射创建事件。

        Args:
            data: 数据内容
            item_id: 可选自定义ID

        Returns:
            创建的项ID
        """
        new_id = self._store.create(data, item_id)
        self._event_bus.emit({"event": "item_created", "id": new_id})
        return new_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取数据项。

        Args:
            item_id: 项ID

        Returns:
            数据内容或None
        """
        return self._store.get(item_id)

    def update_item(self, item_id: str, data: Dict[str, Any],
                    expected_version: Optional[int] = None) -> bool:
        """更新数据项，支持乐观锁版本校验。

        Args:
            item_id: 项ID
            data: 更新字段
            expected_version: 期望版本，None则不校验

        Returns:
            是否成功
        """
        success = self._store.update(item_id, data, expected_version)
        if success:
            self._event_bus.emit({"event": "item_updated", "id": item_id})
        return success

    def delete_item(self, item_id: str) -> bool:
        """删除数据项并发射删除事件。

        Args:
            item_id: 项ID

        Returns:
            是否成功
        """
        success = self._store.delete(item_id)
        if success:
            self._event_bus.emit({"event": "item_deleted", "id": item_id})
        return success

    def list_items(self, page: int = 1, page_size: int = 20,
                   filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """分页列出数据项。

        Args:
            page: 页码
            page_size: 每页大小
            filters: 过滤条件

        Returns:
            分页结果字典
        """
        return self._store.list_items(page, page_size, filters)

    def count_items(self) -> int:
        """统计数据项总数。

        Returns:
            总条数
        """
        return self._store.count()

    def search_items(self, query: str, fields: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """搜索数据项。

        Args:
            query: 搜索关键词
            fields: 搜索字段列表

        Returns:
            匹配项列表
        """
        return self._store.search(query, fields)

    def batch_create_items(self, items: List[Dict[str, Any]]) -> List[str]:
        """批量创建数据项并发射批量创建事件。

        Args:
            items: 数据项列表

        Returns:
            ID列表
        """
        ids = self._store.batch_create(items)
        self._event_bus.emit({"event": "batch_created", "count": len(ids)})
        return ids

    def batch_delete_items(self, ids: List[str]) -> int:
        """批量删除数据项并发射批量删除事件。

        Args:
            ids: 项ID列表

        Returns:
            成功删除数量
        """
        count = self._store.batch_delete(ids)
        if count > 0:
            self._event_bus.emit({"event": "batch_deleted", "count": count})
        return count

    def export_items(self, path: str) -> str:
        """导出数据项到JSON文件。

        Args:
            path: 输出路径

        Returns:
            实际路径
        """
        result = self._store.export(path)
        return result

    def import_items(self, path: str) -> int:
        """从JSON文件导入数据项。

        Args:
            path: 输入路径

        Returns:
            导入数量
        """
        return self._store.import_data(path)

    def get_item_stats(self) -> Dict[str, int]:
        """获取数据统计信息。

        Returns:
            统计字典
        """
        return self._store.get_stats()

    # ==================== 缓存操作 ====================

    def get_cache(self, key: str) -> Optional[Any]:
        """获取缓存值。

        Args:
            key: 缓存键

        Returns:
            缓存值或None
        """
        return self._cache.get(key)

    def set_cache(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """设置缓存值。

        Args:
            key: 缓存键
            value: 缓存值
            ttl: 生存时间（秒）
        """
        self._cache.set(key, value, ttl)

    def invalidate_cache(self, key: str) -> bool:
        """使缓存失效。

        Args:
            key: 缓存键

        Returns:
            是否成功
        """
        return self._cache.invalidate(key)

    def clear_cache(self) -> int:
        """清空所有缓存。

        Returns:
            清空条目数
        """
        return self._cache.clear()

    def get_cache_stats(self) -> Dict[str, Any]:
        """获取缓存统计。

        Returns:
            统计字典
        """
        return self._cache.stats()

    # ==================== 指标操作 ====================

    def record_metric(self, value: float, labels: Optional[Dict[str, str]] = None) -> None:
        """记录指标值。

        Args:
            value: 指标值
            labels: 标签字典
        """
        self._metrics.record(value, labels)

    def get_metric_stats(self, labels: Optional[Dict[str, str]] = None) -> Dict[str, float]:
        """获取指标统计。

        Args:
            labels: 标签字典

        Returns:
            统计字典
        """
        return self._metrics.get_stats(labels)

    def get_metric_history(self, labels: Optional[Dict[str, str]] = None,
                           limit: int = 100) -> List[Dict[str, Any]]:
        """获取指标历史。

        Args:
            labels: 标签字典
            limit: 限制数量

        Returns:
            历史记录列表
        """
        return self._metrics.get_history(labels, limit)

    def reset_metrics(self) -> None:
        """重置所有指标。"""
        self._metrics.reset()

    # ==================== 配置操作 ====================

    def get_config(self, key: str, default: Any = None) -> Any:
        """获取配置项。

        Args:
            key: 配置键
            default: 默认值

        Returns:
            配置值
        """
        return self._config_mgr.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """设置配置项。

        Args:
            key: 配置键
            value: 配置值
        """
        self._config_mgr.set(key, value)

    def get_all_config(self) -> Dict[str, Any]:
        """获取所有配置。

        Returns:
            配置字典
        """
        return self._config_mgr.get_all()

    def reset_config(self) -> None:
        """重置为默认配置。"""
        self._config_mgr.reset()

    def get_config_version(self) -> int:
        """获取配置版本。

        Returns:
            版本号
        """
        return self._config_mgr.get_version()

    def export_config(self, path: str) -> str:
        """导出配置到文件。

        Args:
            path: 输出路径

        Returns:
            实际路径
        """
        return self._config_mgr.export(path)

    def import_config(self, path: str) -> bool:
        """从文件导入配置。

        Args:
            path: 输入路径

        Returns:
            是否成功
        """
        return self._config_mgr.import_config(path)

    # ==================== 事件操作 ====================

    def on_event(self, handler: Callable[[Any], None]) -> str:
        """注册事件处理器。

        Args:
            handler: 回调函数

        Returns:
            处理器ID
        """
        return self._event_bus.on(handler)

    def off_event(self, handler_id: str) -> bool:
        """注销事件处理器。

        Args:
            handler_id: 处理器ID

        Returns:
            是否成功
        """
        return self._event_bus.off(handler_id)

    def emit_event(self, data: Any = None) -> int:
        """触发事件。

        Args:
            data: 事件数据

        Returns:
            成功执行的处理器数量
        """
        return self._event_bus.emit(data)

    def get_handler_count(self) -> int:
        """获取处理器数量。

        Returns:
            数量
        """
        return self._event_bus.get_handler_count()

    def clear_events(self) -> None:
        """清空所有处理器。"""
        self._event_bus.clear()

    # ==================== 状态管理 ====================

    def set_state(self, state: str) -> None:
        """设置当前状态并记录状态转换历史。

        Args:
            state: 目标状态
        """
        if state not in self._states:
            raise ValueError(f"无效状态: {state}，可选值: {self._states}")
        with self._lock:
            previous = self._current_state
            now = time.time()
            self._state_history.append((state, now))
            self._transitions.append((previous, state, now))
            self._current_state = state
            if self._start_time == 0.0:
                self._start_time = now
        logger.info("状态转换: %s -> %s", previous, state)

    def get_state(self) -> str:
        """获取当前状态。

        Returns:
            当前状态字符串
        """
        with self._lock:
            return self._current_state

    def get_state_history(self, limit: int = 50) -> List[Tuple[str, float]]:
        """获取状态历史。

        Args:
            limit: 最多返回条数

        Returns:
            (状态, 时间戳)列表
        """
        with self._lock:
            return list(self._state_history)[-limit:]

    def get_transitions(self, limit: int = 50) -> List[Tuple[str, str, float]]:
        """获取状态转换历史。

        Args:
            limit: 最多返回条数

        Returns:
            (原状态, 新状态, 时间戳)列表
        """
        with self._lock:
            return list(self._transitions)[-limit:]

    def initialize(self) -> None:
        """初始化嵌入器，设置为运行状态。"""
        self.set_state("running")
        self._initialized = True
        logger.info("嵌入器初始化完成")

    def shutdown(self) -> None:
        """关闭嵌入器，清空缓存并停止状态。"""
        self.set_state("stopped")
        self._initialized = False
        self.clear_cache()
        logger.info("嵌入器已关闭")
