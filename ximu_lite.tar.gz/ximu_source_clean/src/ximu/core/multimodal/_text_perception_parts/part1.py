# -*- coding: utf-8 -*-
"""文本感知统计计算模块。

本模块提供文本感知结果的统计分析能力，
支持计数、均值、分位数等基础统计指标的计算。
"""
from __future__ import annotations

import statistics as _statistics
from typing import Any, Dict, List


class TextPerceptionStats:
    """文本感知统计计算器。

    用于计算和缓存文本感知结果的统计指标，
    包括计数、均值、最小值、最大值及百分位数。
    """

    # 默认统计结果的零值模板
    _EMPTY_STATS: Dict[str, float] = {
        "count": 0.0,
        "mean": 0.0,
        "min": 0.0,
        "max": 0.0,
        "p50": 0.0,
        "p95": 0.0,
        "p99": 0.0,
    }

    def __init__(self) -> None:
        """初始化统计器。

        创建一个空的度量数据存储字典。
        """
        self._metrics: Dict[str, List[float]] = {}

    def record(self, label: str, value: float) -> None:
        """记录单个统计数据点。

        Args:
            label: 指标标签，用于分组存储。
            value: 要记录的浮点数值。
        """
        if label not in self._metrics:
            self._metrics[label] = []
        self._metrics[label].append(value)

    def get_stats(self, label: str = "default") -> Dict[str, float]:
        """获取指定标签的统计数据。

        Args:
            label: 指标标签，默认为 'default'。

        Returns:
            包含计数、均值、最小值、最大值及百分位数的字典。
        """
        values: List[float] = self._metrics.get(label, [])
        if not values:
            return dict(self._EMPTY_STATS)

        n: int = len(values)
        sorted_values: List[float] = sorted(values)

        return {
            "count": float(n),
            "mean": _statistics.mean(values),
            "min": sorted_values[0],
            "max": sorted_values[-1],
            "p50": sorted_values[n // 2],
            "p95": sorted_values[int(n * 0.95)] if n > 1 else sorted_values[-1],
            "p99": sorted_values[int(n * 0.99)] if n > 1 else sorted_values[-1],
        }

    def clear(self, label: str | None = None) -> None:
        """清空统计数据。

        Args:
            label: 要清空的标签，为 None 时清空所有数据。
        """
        if label is None:
            self._metrics.clear()
        elif label in self._metrics:
            del self._metrics[label]

    def get_labels(self) -> List[str]:
        """获取所有已记录的标签列表。

        Returns:
            当前存在的标签名称列表。
        """
        return list(self._metrics.keys())
