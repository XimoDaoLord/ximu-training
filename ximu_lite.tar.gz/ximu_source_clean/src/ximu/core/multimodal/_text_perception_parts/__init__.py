# -*- coding: utf-8 -*-
"""文本感知拆分模块包初始化。

本包包含 text_perception 的功能实现，按职责拆分为：
- part1: 核心数据结构与配置（枚举、数据类）
- part2: 基础文本感知能力（分类、意图、情感、实体识别）
- part3: 高级封装与便捷接口（TextPerception 主类等）

导入时仅声明包结构，实际符号由上层 text_perception.py 负责聚合导出。
"""
from __future__ import annotations

__all__: list[str] = []
