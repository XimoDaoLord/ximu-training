"""实体抽取器核心模块：状态管理、数据存取、缓存与指标监控。

提供线程安全的实体数据仓库、带TTL与容量限制的LRU缓存、指标记录与统计、配置管理、事件发布/订阅、
生命周期状态机以及异步批处理能力。
"""

import asyncio
import json
import logging
import time
import traceback
import threading
from collections import OrderedDict, defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
from functools import lru_cache

logging.basicConfig(level=logging.DEBUG)

# ─── 状态枚举 ───────────────────────────────────────────────────────
class ExtractorState(str, Enum):
    """实体抽取器生命周期状态。

    Attributes:
        IDLE: 空闲状态
        RUNNING: 运行中状态
        PAUSED: 暂停状态
        STOPPED: 已停止状态
        ERROR: 错误状态
    """
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPED = "stopped"
    ERROR = "error"

# ─── 内部数据结构 ───────────────────────────────────────────────────
@dataclass(frozen=True)
class CacheEntry:
    """带TTL的缓存条目。

    Attributes:
        value: 缓存的值
        timestamp: 缓存时间戳（单调时钟）
        ttl: 生存时间（秒）
    """
    value: Any
    timestamp: float
    ttl: float

    @lru_cache(maxsize=None)
    def is_expired(self) -> bool:
        """判断缓存条目是否已过期。

        Returns:
            已过期返回True，否则返回False。
        """
        return (time.monotonic() - self.timestamp) >= self.ttl

@dataclass(frozen=True)
class ItemRecord:
    """实体数据仓库中的单条记录。

    Attributes:
        id: 唯一标识符
        data: 实体数据字典
        created_at: 创建时间戳
        updated_at: 最后更新时间戳
        version: 版本号，从1开始递增
    """
    id: str
    data: Dict[str, Any]
    created_at: float
    updated_at: float
    version: int = 1

@dataclass(frozen=True)
class MetricsPoint:
    """单条指标数据点。

    Attributes:
        value: 指标数值
        timestamp: 记录时间戳
        labels: 指标标签字典
    """
    value: float
    timestamp: float
    labels: Dict[str, Any] = field(default_factory=dict)

class EntityExtractor:
    """线程安全的实体抽取器。

    Attributes:
        _state: 当前生命周期状态
        _items: 实体数据仓库
        _cache: LRU缓存（使用LRU算法）
        _metrics: 指标数据存储
        _config: 配置项字典
        _event_handlers: 事件处理器字典
        _inverted_index: 倒排索引（批量更新优化）
        _config_version: 配置版本号
        _async_tasks: 异步任务字典
        _lock: 线程锁
        _logger: 日志记录器
    """

    def __init__(self, logger: Optional[logging.Logger] = None,
                 max_cache_size: int = 10_000) -> None:
        """初始化实体抽取器。

        Args:
            logger: 可选的日志记录器，为None时使用默认。
            max_cache_size: 缓存最大容量。
        """
        self._logger = logger or logging.getLogger(self.__class__.__name__)
        self._lock = threading.RLock()
        self._state = ExtractorState.IDLE
        self._items: Dict[str, ItemRecord] = {}
        self._item_stats: Dict[str, int] = {"created": 0, "updated": 0, "deleted": 0}
        self._inverted_index: Dict[str, Dict[str, Set[str]]] = {}
        self._cache = lru_cache(maxsize=max_cache_size)(OrderedDict)
        self._max_cache_size = max_cache_size
        self._metrics: Dict[str, List[MetricsPoint]] = defaultdict(list)
        self._metrics_max_size = 10_000
        self._metrics_trim_size = 5_000
        self._config: Dict[str, Any] = {}
        self._default_config = {}
        self._config_version = 1
        self._event_handlers = {}
        self._async_tasks = {}
        self._initialized = False
        self._start_time = 0.0
        self._cache_purge_interval = 60  # 秒
        self._cache_purge_task = None

    # ── 状态机 ──────────────────────────────────────────────────────
    def _record_state_transition(self) -> None:
        """记录当前状态变更历史。"""
        self._state_history.append(
            (self._state.value, self._state.value, time.monotonic())
        )

    def _transition_to(self, new_state: ExtractorState) -> None:
        """将状态迁移到指定新状态。

        Args:
            new_state: 目标状态。
        """
        old_state = self._state
        self._state = new_state
        self._state_history.append(
            (old_state.value, new_state.value, time.monotonic())
        )
        self._logger.debug(
            "状态迁移: %s → %s", old_state.value, new_state.value
        )

    @property
    def state(self) -> str:
        """返回当前状态字符串。"""
        return self._state.value

    def get_status(self) -> str:
        """获取实体抽取器当前状态。

        Returns:
            当前状态字符串。
        """
        return self.state

    def is_healthy(self) -> bool:
        """检查实体抽取器是否处于健康状态。

        Returns:
            健康返回True，否则返回False。
        """
        if not self._initialized:
            return False
        if self._state == ExtractorState.ERROR:
            return False
        return self._health_check()

    def get_uptime(self) -> float:
        """获取实体抽取器运行时长（秒）。

        Returns:
            运行时长，未初始化时返回0.0。
        """
        if not self._initialized:
            return 0.0
        return time.monotonic() - self._start_time

    # ── 生命周期 ────────────────────────────────────────────────────
    def initialize(self) -> bool:
        """初始化实体抽取器资源。

        Returns:
            初始化成功返回True，否则返回False。
        """
        if self._initialized:
            return True
        try:
            self._start_time = time.monotonic()
            self._transition_to(ExtractorState.RUNNING)
            self._initialized = True
            self._logger.info("EntityExtractor 初始化完成")
            self._setup_cache_purge()
            return True
        except Exception:
            self._transition_to(ExtractorState.ERROR)
            self._logger.error("EntityExtractor 初始化失败", exc_info=True)
            return False

    def shutdown(self) -> bool:
        """关闭实体抽取器，释放资源。

        Returns:
            关闭成功返回True，否则返回False。
        """
        if not self._initialized:
            return True
        try:
            self._cleanup_resources()
            self._transition_to(ExtractorState.STOPPED)
            self._initialized = False
            self._logger.info("EntityExtractor 已关闭")
            return True
        except Exception:
            self._transition_to(ExtractorState.ERROR)
            self._logger.error("EntityExtractor 关闭失败", exc_info=True)
            return False

    async def async_restart(self) -> bool:
        """异步重启实体抽取器。

        Returns:
            重启成功返回True，否则返回False。
        """
        self.shutdown()
        await asyncio.sleep(0.1)
        return self.initialize()

    def _cleanup_resources(self) -> None:
        """释放内部资源，供子类覆写。"""
        for task in self._async_tasks.values():
            if not task.done():
                task.cancel()
        self._async_tasks.clear()
        self._cache.purge()

    def _health_check(self) -> bool:
        """执行健康检查，供子类覆写。

        Returns:
            健康返回True。
        """
        return True

    # ── 倒排索引管理 ───────────────────────────────────────────────
    def _update_inverted_index(self, item_id: str, data: Dict[str, Any],
                               operation: str) -> None:
        """更新倒排索引（批量事务式操作）。

        Args:
            item_id: 实体ID。
            data: 实体数据。
            operation: 操作类型（'add'或'remove'）。
        """
        with self._lock:
            for field_name, value in data.items():
                if not isinstance(value, str):
                    continue
                value_lower = value.lower()
                if field_name not in self._inverted_index:
                    self._inverted_index[field_name] = defaultdict(set)
                if operation == "add":
                    self._inverted_index[field_name][value_lower].add(item_id)
                elif operation == "remove":
                    self._inverted_index[field_name][value_lower].discard(item_id)
                    # 清理空集合
                    if not self._inverted_index[field_name][value_lower]:
                        del self._inverted_index[field_name][value_lower]
                    # 清理空字段
                    if not self._inverted_index[field_name]:
                        del self._inverted_index[field_name]

    # ── 数据仓库 CRUD ───────────────────────────────────────────────
    def create_item(self, data: Dict[str, Any]) -> str:
        """创建实体数据记录。

        Args:
            data: 实体数据。

        Returns:
            新记录的唯一标识符。

        Raises:
            ValueError: 当data为空时抛出。
        """
        if not data:
            raise ValueError("数据不能为空")

        from src.ximu.common.utils import generate_id
        item_id = generate_id("item")
        record = ItemRecord(
            id=item_id,
            data=data,
            created_at=time.time(),
            updated_at=time.time(),
        )
        with self._lock:
            self._items[item_id] = record
            self._item_stats["created"] += 1
            self._update_inverted_index(item_id, data, "add")
        self._logger.debug("创建实体 %s, 版本=1", item_id)
        return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取指定ID的实体数据。

        Args:
            item_id: 实体记录ID。

        Returns:
            实体数据，不存在时返回None。
        """
        with self._lock:
            record = self._items.get(item_id)
        return record.data if record else None

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新指定ID的实体数据。

        Args:
            item_id: 实体记录ID。
            data: 更新的数据字段。

        Returns:
            更新成功返回True，否则False。
        """
        with self._lock:
            record = self._items.get(item_id)
            if record is None:
                return False
            old_data = dict(record.data)
            record.data.update(data)
            record.updated_at = time.time()
            record.version += 1
            self._item_stats["updated"] += 1
            self._update_inverted_index(item_id, old_data, "remove")
            self._update_inverted_index(item_id, data, "add")
        self._logger.debug("更新实体 %s, 版本=%d", item_id, record.version)
        return True

    def delete_item(self, item_id: str) -> bool:
        """删除指定ID的实体数据。

        Args:
            item_id: 实体记录ID。

        Returns:
            删除成功返回True，否则False。
        """
        with self._lock:
            if item_id not in self._items:
                return False
            record = self._items[item_id]
            self._update_inverted_index(item_id, record.data, "remove")
            del self._items[item_id]
            self._item_stats["deleted"] += 1
        self._logger.debug("删除实体 %s", item_id)
        return True

    def list_items(self, page: int = 1, page_size: int = 20,
                   filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """分页列出实体数据。

        Args:
            page: 页码，从1开始。
            page_size: 每页数量。
            filters: 可选的字段过滤字典，支持一级键值相等过滤。

        Returns:
            包含 items、total、page、page_size 的字典。

        Raises:
            ValueError: 当page或page_size无效时抛出。
        """
        if page < 1 or page_size < 1:
            raise ValueError("页码和每页数量必须大于0")

        with self._lock:
            records = list(self._items.values())

        if filters:
            filtered = []
            for r in records:
                match = True
                for k, v in filters.items():
                    if r.data.get(k) != v:
                        match = False
                        break
                if match:
                    filtered.append(r)
            records = filtered

        total = len(records)
        start = (page - 1) * page_size
        end = start + page_size
        return {
            "items": [r.data for r in records[start:end]],
            "total": total,
            "page": page,
            "page_size": page_size,
        }

    def count_items(self) -> int:
        """获取实体数据总数。

        Returns:
            实体总数。
        """
        with self._lock:
            return len(self._items)

    def search_items(self, query: str,
                     fields: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """在实体数据中搜索匹配项。

        使用倒排索引加速搜索，避免全表扫描。

        Args:
            query: 搜索词（不区分大小写）。
            fields: 限定搜索的字段列表，为None时搜索所有字段。

        Returns:
            匹配的实体数据列表。
        """
        if not query:
            return []

        query_lower = query.lower()
        matched_ids: Set[str] = set()

        with self._lock:
            if fields:
                for field_name in fields:
                    if field_name in self._inverted_index:
                        field_index = self._inverted_index[field_name]
                        if query_lower in field_index:
                            matched_ids.update(field_index[query_lower])
            else:
                for field_name, term_index in self._inverted_index.items():
                    if query_lower in term_index:
                        matched_ids.update(term_index[query_lower])

        results: List[Dict[str, Any]] = []
        with self._lock:
            for item_id in matched_ids:
                record = self._items.get(item_id)
                if record:
                    results.append(record.data)

        return results

    def batch_create_items(self, batch: List[Dict[str, Any]]) -> List[str]:
        """批量创建实体数据。

        Args:
            batch: 实体数据列表。

        Returns:
            创建的ID列表。
        """
        return [self.create_item(item) for item in batch]

    def batch_delete_items(self, ids: List[str]) -> int:
        """批量删除实体数据。

        Args:
            ids: 要删除的ID列表。

        Returns:
            实际删除的数量。
        """
        count = 0
        for item_id in ids:
            if self.delete_item(item_id):
                count += 1
        return count

    def export_items(self, path: str) -> str:
        """导出实体数据到JSON文件。

        Args:
            path: 目标文件路径。

        Returns:
            导出文件路径。
        """
        with self._lock:
            data = [
                {"id": r.id, "data": r.data, "created_at": r.created_at,
                 "updated_at": r.updated_at, "version": r.version}
                for r in self._items.values()
            ]
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        self._logger.info("导出 %d 条实体到 %s", len(data), path)
        return path

    def import_items(self, path: str) -> int:
        """从JSON文件导入实体数据。

        Args:
            path: 源文件路径。

        Returns:
            导入的记录数量。

        Raises:
            FileNotFoundError: 当文件不存在时抛出。
            json.JSONDecodeError: 当JSON格式错误时抛出。
        """
        try:
            with open(path, "r", encoding="utf-8") as f:
                raw_data = json.load(f)
        except FileNotFoundError:
            self._logger.error("导入文件不存在: %s", path)
            raise
        except json.JSONDecodeError as e:
            self._logger.error("JSON格式错误: %s", e)
            raise

        if not isinstance(raw_data, list):
            raise ValueError("导入数据必须是列表格式")

        count = 0
        for record_dict in raw_data:
            # 数据校验
            if not isinstance(record_dict, dict):
                self._logger.warning("跳过非字典记录: %s", record_dict)
                continue

            # 检查必需字段
            required_fields = ["id", "data"]
            missing_fields = [f for f in required_fields if f not in record_dict]
            if missing_fields:
                self._logger.warning(
                    "记录缺少必需字段 %s，跳过: %s", missing_fields, record_dict
                )
                continue

            # 校验data字段类型
            if not isinstance(record_dict["data"], dict):
                self._logger.warning("data字段必须是字典，跳过: %s", record_dict)
                continue

            item_id = record_dict.get("id")
            normalized = self._normalize_import_record(record_dict, item_id)

            with self._lock:
                self._items[item_id] = normalized
                # 重建索引
                self._update_inverted_index(item_id, normalized.data, "add")
            count += 1

        self._logger.info("导入 %d 条实体从 %s", count, path)
        return count

    @staticmethod
    def _normalize_import_record(record: Dict[str, Any],
                                 item_id: str) -> ItemRecord:
        """将导入的字典记录标准化为ItemRecord。

        Args:
            record: 原始记录字典。
            item_id: 实体ID。

        Returns:
            标准化的ItemRecord对象。
        """
        return ItemRecord(
            id=item_id,
            data=record.get("data", {}),
            created_at=record.get("created_at", time.time()),
            updated_at=record.get("updated_at", time.time()),
            version=record.get("version", 1),
        )

    def get_item_stats(self) -> Dict[str, int]:
        """获取实体数据仓库统计信息。

        Returns:
            包含total、created、updated、deleted的字典。
        """
        with self._lock:
            return {
                "total": len(self._items),
                **self._item_stats,
            }

    # ── 缓存 ────────────────────────────────────────────────────────
    def get_cache(self, key: str) -> Optional[Any]:
        """获取缓存值。

        Args:
            key: 缓存键。

        Returns:
            缓存值，未命中或过期时返回None。
        """
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            if entry.isexpired():
                del self._cache[key]
                self._logger.debug("缓存过期，移除键: %s", key)
                return None
            # LRU: 标记为最近使用
            self._cache.move_to_end(key)
            return entry.value

    def set_cache(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """设置缓存值。

        Args:
            key: 缓存键。
            value: 缓存值。
            ttl: 生存时间（秒）。
        """
        with self._lock:
            self._cache[key] = CacheEntry(
                value=value, timestamp=time.monotonic(), ttl=ttl
            )
            self._cache.move_to_end(key)
            if len(self._cache) > self._max_cache_size:
                # 驱逐最旧的条目
                evicted_key, evicted_entry = self._cache.popitem(last=False)
                self._logger.debug("缓存溢出，驱逐条目: %s", evicted_key)

    def invalidate_cache(self, key: str) -> bool:
        """使指定缓存键失效。

        Args:
            key: 缓存键。

        Returns:
            移除成功返回True，否则False。
        """
        with self._lock:
            return self._cache.pop(key, None) is not None

    def clear_cache(self) -> int:
        """清空所有缓存。

        Returns:
            清空的条目数量。
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
        self._logger.debug("清空 %d 条缓存", count)
        return count

    def get_cache_stats(self) -> Dict[str, Any]:
        """获取缓存统计信息。

        Returns:
            包含size和max_size的字典。
        """
        with self._lock:
            return {"size": len(self._cache), "max_size": self._max_cache_size}

    # ── 指标 ────────────────────────────────────────────────────────
    def record_metric(self, value: float,
                      labels: Optional[Dict[str, Any]] = None) -> None:
        """记录一条指标数据。

        Args:
            value: 指标数值。
            labels: 指标标签。
        """
        labels = labels or {}
        with self._lock:
            key = json.dumps(labels, sort_keys=True, default=str)
            bucket = self._metrics.setdefault(key, [])
            bucket.append(MetricsPoint(value=value, timestamp=time.time(), labels=labels))
            if len(bucket) > self._metrics_max_size:
                self._metrics[key] = bucket[-self._metrics_trim_size:]

    def get_metrics(self, labels: Optional[Dict[str, Any]] = None,
                   start: Optional[float] = None,
                   end: Optional[float] = None) -> List[MetricsPoint]:
        """获取指标数据。

        Args:
            labels: 指标标签。
            start: 开始时间戳。
            end: 结束时间戳。

        Returns:
            指标数据列表。
        """
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True, default=str)
            return self._metrics.get(key, [])

    # ── 异步任务 ────────────────────────────────────────────────────
    def add_async_task(self, task: asyncio.Task) -> str:
        """添加异步任务。

        Args:
            task: 异步任务。

        Returns:
            任务唯一标识符。
        """
        task_id = id(task)
        self._async_tasks[task_id] = task
        return task_id

    def cancel_async_task(self, task_id: str) -> bool:
        """取消异步任务。

        Args:
            task_id: 任务唯一标识符。

        Returns:
            取消成功返回True，否则False。
        """
        with self._lock:
            task = self._async_tasks.pop(task_id, None)
            if task and not task.done():
                task.cancel()
                return True
            return False

    # ── 配置管理 ────────────────────────────────────────────────────
    def update_config(self, config: Dict[str, Any]) -> bool:
        """更新配置。

        Args:
            config: 新配置字典。

        Returns:
            更新成功返回True，否则False。
        """
        with self._lock:
            self._config_version += 1
            self._config.update(config)
            self._default_config = dict(self._config)
        return True

    def get_config(self) -> Dict[str, Any]:
        """获取当前配置。

        Returns:
            配置字典。
        """
        with self._lock:
            return self._config

    # ── 事件系统 ────────────────────────────────────────────────────
    def subscribe(self, event_type: str, handler: Callable[[Any], None]) -> None:
        """订阅事件。

        Args:
            event_type: 事件类型。
            handler: 事件处理函数。
        """
        self._event_handlers[event_type] = self._event_handlers.get(event_type, []) + [handler]

    def publish(self, event_type: str, data: Any) -> None:
        """发布事件。

        Args:
            event_type: 事件类型。
            data: 事件数据。
        """
        with self._lock:
            handlers = self._event_handlers.get(event_type, [])
            for handler in handlers:
                try:
                    handler(data)
                except Exception as e:
                    self._logger.error("事件处理异常: %s", e)

    # ── 缓存清理任务 ────────────────────────────────────────────────
    def _setup_cache_purge(self) -> None:
        """设置缓存定期清理任务。"""
        self._cache_purge_task = asyncio.create_task(
            self._cache_purge_loop()
        )

    async def _cache_purge_loop(self) -> None:
        """缓存定期清理循环。"""
        while True:
            await asyncio.sleep(self._cache_purge_interval)
            self._cache.clear()
            self._logger.debug("执行缓存清理，剩余条目: %d", len(self._cache))
