"""本地 OCR 推理封装模块。

提供本地 ONNX/ORT 模型的懒加载与推理接口，未就绪时返回降级结果。
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

class _OcrState:
    """OCR 模块全局状态容器。"""

    def __init__(self) -> None:
        """初始化状态为未就绪。"""
        self.ready: bool = False
        self.tried: bool = False
        self.error: Optional[str] = None
        self.model: Optional[Any] = None

_state = _OcrState()

def is_local_ocr_available() -> bool:
    """检查本地 OCR 是否可用。

    Returns:
        如果模型已加载则返回 True，否则返回 False。
    """
    return _state.ready

def load_ocr() -> Optional[Any]:
    """按需加载 OCR 模型（懒加载单例）。

    Returns:
        加载成功的 OCR 实例，失败返回 None。
    """
    if _state.ready:
        return _state.model
    if _state.tried:
        return None
    _state.tried = True
    # TODO: 实际加载 ONNX/ORT 模型并赋值 _state.model
    _state.error = "ocr_model_not_found"
    logger.warning("本地 OCR 模型加载失败: %s", _state.error)
    _state.ready = False
    return None

def run_ocr(image: Any) -> Dict[str, Any]:
    """对图像跑本地 OCR。

    Args:
        image: numpy BGR 数组或图像路径。

    Returns:
        包含识别结果、置信度、延迟等信息的字典；不可用时返回降级响应。
    """
    if not is_local_ocr_available():
        return {
            "success": False,
            "error": _state.error or "local_ocr_not_available",
            "result": None,
            "confidence": 0.0,
            "latency_ms": 0.0,
        }

    ocr_model = _state.model
    start = time.perf_counter()
    try:
        # TODO: 调用 ocr_model.predict(image) 获取真实识别结果
        result_text: str = ""
        lines: List[Dict[str, Any]] = []
        latency_ms: float = round((time.perf_counter() - start) * 1000, 1)
        return {
            "success": True,
            "result": {"text": result_text, "lines": lines, "num_lines": len(lines)},
            "confidence": 0.0,
            "latency_ms": latency_ms,
            "error": None,
        }
    except Exception as exc:
        latency_ms = round((time.perf_counter() - start) * 1000, 1)
        logger.error("OCR 推理失败: %s", exc, exc_info=True)
        return {
            "success": False,
            "error": str(exc),
            "result": None,
            "confidence": 0.0,
            "latency_ms": latency_ms,
        }
