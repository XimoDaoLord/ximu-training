# -*- coding: utf-8 -*-
"""多模态融合层（Multimodal Fusion）。

本模块作为干净的再导出层，将实际实现从 _multimodal_fusion_parts 拆分模块中聚合，
同时提供别名 fusion.py 支持。核心功能包括特征级、注意力级和决策级融合，
以及跨模态对齐。
"""
from __future__ import annotations

import importlib as _il
import logging as _logging
from typing import Any, List

logger = _logging.getLogger(__name__)

# 模块级公开名称注册表
_PUBLIC_NAMES: List[str] = []


def _load_fusion_parts() -> List[str]:
    """从子模块加载并导出所有公开名称。

    遍历 _multimodal_fusion_parts 下的 part1~part3 模块，
    将非下划线开头的公开符号提升到当前命名空间。

    Returns:
        成功导出的公开名称列表。
    """
    public_names: List[str] = []
    for part_name in ("part1", "part2", "part3"):
        module_name = f"._multimodal_fusion_parts.{part_name}"
        try:
            module = _il.import_module(module_name, package=__package__)
            for attr in dir(module):
                if not attr.startswith("_") and attr not in globals():
                    globals()[attr] = getattr(module, attr)
                    public_names.append(attr)
        except Exception as exc:
            logger.warning(
                "加载融合模块 %s 失败: %s", module_name, exc, exc_info=True
            )
    return public_names


# 在模块加载时执行聚合
_PUBLIC_NAMES.extend(_load_fusion_parts())
__all__ = sorted(set(_PUBLIC_NAMES))
