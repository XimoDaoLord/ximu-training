"""保底插件组合：插件作为感官 + 老文本模型作为大脑。

当多模态模型不可用时，通过 OCR 插件提取文本，再交给文本模型回答。
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

def combo_image(image_input: Any, question: str = "") -> Dict[str, Any]:
    """看图：插件 OCR → 老文本模型回答。

    Args:
        image_input: 图像路径或 numpy 数组。
        question: 针对图像的问题。

    Returns:
        包含中间产物、最终回答、模型信息的字典。
    """
    start = time.perf_counter()
    # 简化实现：调用 local_ocr 和 brain_chat，目前返回未就绪状态
    return {
        "success": False,
        "error": "plugin_ocr_no_text",
        "plugin_artifact": {},
        "answer": "",
        "latency_ms": 0.0,
    }

def combo_available(task_type: str) -> bool:
    """联合判定：插件可用 + 老文本模型可用。

    Args:
        task_type: 任务类型。

    Returns:
        如果组合可用则返回 True，否则 False。
    """
    # 检查依赖和模型可用性，当前占位返回 False
    return False
