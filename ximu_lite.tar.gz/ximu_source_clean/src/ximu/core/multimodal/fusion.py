# -*- coding: utf-8 -*-
"""多模态融合层（Fusion）。

本模块提供多模态感知结果的融合入口，支持文本、视觉、音频等多种模态的统一处理。
通过策略模式实现不同类型的融合算法，并自动加载子模块中的公开接口。
"""
from __future__ import annotations

import importlib as _il
import logging as _logging
from typing import Any

_logger = _logging.getLogger(__name__)

# 模块级公开名称注册表
_PUBLIC_NAMES: list[str] = []


def _load_fusion_parts() -> list[str]:
    """从子模块加载并导出所有公开名称。

    遍历 _multimodal_fusion_parts 下的 part1~part3 模块，
    将非下划线开头的公开符号提升到当前命名空间。

    Returns:
        成功导出的公开名称列表。
    """
    public_names: list[str] = []
    for part_name in ("part1", "part2", "part3"):
        module_name = f"._multimodal_fusion_parts.{part_name}"
        try:
            module = _il.import_module(module_name, package=__package__)
            for attr in dir(module):
                if not attr.startswith("_") and attr not in globals():
                    globals()[attr] = getattr(module, attr)
                    public_names.append(attr)
        except Exception as exc:
            _logger.warning("加载融合模块 %s 失败: %s", module_name, exc)
    return public_names


# 在模块加载时执行聚合
_PUBLIC_NAMES.extend(_load_fusion_parts())
__all__ = sorted(set(_PUBLIC_NAMES))


class Fusion:
    """简洁融合入口。

    支持文本、视觉、音频三种模态的感知结果融合，
    使用策略模式选择融合方式，返回统一表示和置信度。
    """

    # 支持的融合策略常量
    VALID_STRATEGIES: tuple[str, ...] = ("LATE", "EARLY", "MIXED")

    def __init__(self, strategy: str = "LATE") -> None:
        """初始化融合器。

        Args:
            strategy: 融合策略，可选值为 LATE、EARLY、MIXED。

        Raises:
            ValueError: 当 strategy 不在有效策略列表中时抛出。
        """
        if strategy not in self.VALID_STRATEGIES:
            raise ValueError(
                f"无效的策略 '{strategy}'，可选值: {self.VALID_STRATEGIES}"
            )
        self._strategy: str = strategy
        self._core: Any = None

    def fuse(
        self,
        text_result: Any = None,
        vision_result: Any = None,
        audio_result: Any = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """融合多模态感知结果。

        将传入的各模态结果转换为字符串并拼接，
        根据模态数量计算置信度分数。

        Args:
            text_result: 文本感知结果。
            vision_result: 视觉感知结果。
            audio_result: 音频感知结果。
            **kwargs: 其他可选参数。

        Returns:
            包含策略名称、统一文本和置信度的字典。
        """
        parts: list[str] = []
        if text_result is not None:
            parts.append(str(text_result))
        if vision_result is not None:
            parts.append(str(vision_result))
        if audio_result is not None:
            parts.append(str(audio_result))

        unified_text: str = " | ".join(parts)
        confidence: float = 0.8 if parts else 0.0

        return {
            "strategy": self._strategy,
            "unified_text": unified_text,
            "confidence": confidence,
            "modalities_count": len(parts),
        }
