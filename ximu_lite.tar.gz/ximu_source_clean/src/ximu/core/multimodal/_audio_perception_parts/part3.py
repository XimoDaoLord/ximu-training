"""Part 3 of audio_perception.

本模块提供 AudioFeatureExtractorStore，用于管理音频特征提取过程中的
数据项存储、缓存、配置、指标统计及事件处理。
"""

import json
import logging
import math
import statistics
import threading
import time
from collections import defaultdict, deque
from typing import Any, Dict, List, Optional, Callable

from src.ximu.common.utils import generate_id
from .part1 import _setup_logger


class AudioFeatureExtractorStore:
    """音频特征提取器状态管理组件。

    提供集中式的存储与管理功能，包括数据项 CRUD、带 TTL 的缓存、
    配置管理、指标统计、事件处理及生命周期管理，支持高并发读写。
    """

    __slots__ = (
        "_item_store",
        "_cache",
        "_max_cache_size",
        "_metrics",
        "_max_metric_history",
        "_config",
        "_default_config",
        "_config_version",
        "_evt_handlers",
        "_initialized",
        "_status",
        "_start_time",
        "_lock",
        "_logger",
        "_stats",
    )

    def __init__(self, max_cache_size: int = 10_000, max_metric_history: int = 10_000) -> None:
        """初始化 AudioFeatureExtractorStore。

        Args:
            max_cache_size: 缓存最大条目数，默认 10000。
            max_metric_history: 每个指标键保留的最大历史条目数，默认 10000。
        """
        self._item_store: Dict[str, Dict[str, Any]] = {}
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._max_cache_size: int = max_cache_size
        self._metrics: Dict[str, deque] = defaultdict(lambda: deque(maxlen=max_metric_history))
        self._config: Dict[str, Any] = {}
        self._default_config: Dict[str, Any] = {}
        self._config_version: int = 1
        self._evt_handlers: Dict[str, Callable[[Any], None]] = {}
        self._initialized: bool = False
        self._status: str = "idle"
        self._start_time: float = 0.0
        self._lock: threading.RLock = threading.RLock()
        self._logger: logging.Logger = _setup_logger(self.__class__.__name__)
        self._stats: Dict[str, int] = defaultdict(int)
        self._max_metric_history: int = max_metric_history

    # ------------------------------------------------------------------
    # 数据项 CRUD
    # ------------------------------------------------------------------

    def create_item(self, data: Dict[str, Any]) -> str:
        """创建数据项。

        Args:
            data: 数据内容。

        Returns:
            新创建数据项的唯一标识。
        """
        item_id = generate_id("audiofeatureextractor_item")
        record = {
            "id": item_id,
            "data": data,
            "created_at": time.time(),
            "updated_at": time.time(),
            "version": 1,
        }
        with self._lock:
            self._item_store[item_id] = record
            self._stats["item_created"] += 1
        self._logger.debug("Created item %s", item_id)
        return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取数据项。

        Args:
            item_id: 数据项标识。

        Returns:
            数据项内容，若不存在返回 None。
        """
        with self._lock:
            record = self._item_store.get(item_id)
        if record is None:
            return None
        return dict(record["data"])

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新数据项。

        Args:
            item_id: 数据项标识。
            data: 要合并的更新数据。

        Returns:
            更新成功返回 True，否则 False。
        """
        with self._lock:
            if item_id not in self._item_store:
                return False
            record = self._item_store[item_id]
            record["data"].update(data)
            record["updated_at"] = time.time()
            record["version"] += 1
            self._stats["item_updated"] += 1
            self._logger.debug("Updated item %s (v%s)", item_id, record["version"])
            return True

    def delete_item(self, item_id: str) -> bool:
        """删除数据项。

        Args:
            item_id: 数据项标识。

        Returns:
            删除成功返回 True，否则 False。
        """
        with self._lock:
            if item_id not in self._item_store:
                return False
            del self._item_store[item_id]
            self._stats["item_deleted"] += 1
            self._logger.debug("Deleted item %s", item_id)
            return True

    def list_items(
        self,
        page: int = 1,
        page_size: int = 20,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """分页列出数据项。

        Args:
            page: 页码，从 1 开始。
            page_size: 每页大小。
            filters: 可选的字段-值过滤条件。

        Returns:
            包含 items、total、page、page_size 的字典。
        """
        with self._lock:
            items = [dict(record["data"]) for record in self._item_store.values()]

        if filters:
            filtered_items = []
            for item in items:
                match = all(item.get(key) == value for key, value in filters.items())
                if match:
                    filtered_items.append(item)
            items = filtered_items

        total = len(items)
        start = max(0, (page - 1) * page_size)
        end = start + page_size
        return {
            "items": items[start:end],
            "total": total,
            "page": page,
            "page_size": page_size,
        }

    def count_items(self) -> int:
        """统计数据项数量。

        Returns:
            当前数据项总数。
        """
        with self._lock:
            return len(self._item_store)

    def search_items(
        self,
        query: str,
        fields: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """搜索数据项。

        Args:
            query: 搜索字符串（不区分大小写）。
            fields: 限定搜索的字段列表，None 表示搜索所有字段。

        Returns:
            匹配的数据项列表。
        """
        results: List[Dict[str, Any]] = []
        query_lower = query.lower()
        with self._lock:
            for record in self._item_store.values():
                data = record["data"]
                search_fields = fields if fields else list(data.keys())
                for field in search_fields:
                    val = str(data.get(field, "")).lower()
                    if query_lower in val:
                        results.append(dict(data))
                        break
        return results

    def batch_create_items(self, batch: List[Dict[str, Any]]) -> List[str]:
        """批量创建数据项。

        Args:
            batch: 数据项列表。

        Returns:
            创建的数据项 ID 列表。
        """
        if not batch:
            return []

        ids: List[str] = []
        with self._lock:
            for item_data in batch:
                item_id = generate_id("audiofeatureextractor_item")
                record = {
                    "id": item_id,
                    "data": dict(item_data),
                    "created_at": time.time(),
                    "updated_at": time.time(),
                    "version": 1,
                }
                self._item_store[item_id] = record
                ids.append(item_id)
            self._stats["item_created"] += len(batch)

        self._logger.debug("Batch created %d items", len(batch))
        return ids

    def batch_delete_items(self, ids: List[str]) -> int:
        """批量删除数据项。

        Args:
            ids: 要删除的数据项 ID 列表。

        Returns:
            成功删除的数量。
        """
        if not ids:
            return 0

        count = 0
        with self._lock:
            for item_id in ids:
                if item_id in self._item_store:
                    del self._item_store[item_id]
                    count += 1
            self._stats["item_deleted"] += count

        self._logger.debug("Batch deleted %d items", count)
        return count

    def export_items(self, path: str) -> str:
        """导出数据项到 JSON 文件。

        Args:
            path: 输出文件路径。

        Returns:
            文件路径。

        Raises:
            OSError: 文件写入失败时抛出。
        """
        with self._lock:
            data = [dict(record) for record in self._item_store.values()]

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        self._logger.info("Exported %d items to %s", len(data), path)
        return path

    def import_items(self, path: str) -> int:
        """从 JSON 文件导入数据项。

        Args:
            path: 输入文件路径。

        Returns:
            导入的数据项数量。

        Raises:
            OSError: 文件读取失败时抛出。
            json.JSONDecodeError: JSON 解析失败时抛出。
        """
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        count = 0
        with self._lock:
            for record in data:
                item_id = record.get("id", generate_id("audiofeatureextractor_item"))
                self._item_store[item_id] = dict(record)
                count += 1

        self._logger.info("Imported %d items from %s", count, path)
        return count

    def get_item_stats(self) -> Dict[str, int]:
        """获取数据项统计信息。

        Returns:
            包含 total、created、updated、deleted 的字典。
        """
        with self._lock:
            return {
                "total": len(self._item_store),
                "created": self._stats.get("item_created", 0),
                "updated": self._stats.get("item_updated", 0),
                "deleted": self._stats.get("item_deleted", 0),
            }

    # ------------------------------------------------------------------
    # 缓存管理
    # ------------------------------------------------------------------

    def get_cached(self, key: str) -> Optional[Any]:
        """获取缓存值。

        Args:
            key: 缓存键。

        Returns:
            缓存值，若过期或不存在返回 None。
        """
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            elapsed = time.monotonic() - entry["time"]
            if elapsed < entry["ttl"]:
                return entry["value"]
            del self._cache[key]
        return None

    def set_cached(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """设置缓存值。

        Args:
            key: 缓存键。
            value: 缓存值。
            ttl: 生存时间（秒），默认 300。
        """
        with self._lock:
            self._cache[key] = {"value": value, "time": time.monotonic(), "ttl": ttl}
            if len(self._cache) > self._max_cache_size:
                self._evict_oldest_cache_entry()
        self._logger.debug("Set cache key %s (ttl=%s)", key, ttl)

    def invalidate_cache(self, key: str) -> bool:
        """使指定缓存键失效。

        Args:
            key: 缓存键。

        Returns:
            若键存在并移除返回 True，否则 False。
        """
        with self._lock:
            removed = self._cache.pop(key, None) is not None
        if removed:
            self._logger.debug("Invalidated cache key %s", key)
        return removed

    def clear_cache(self) -> int:
        """清空所有缓存。

        Returns:
            清空的缓存条目数。
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
        self._logger.info("Cleared %d cache entries", count)
        return count

    def get_cache_stats(self) -> Dict[str, int]:
        """获取缓存统计信息。

        Returns:
            包含 size 和 max_size 的字典。
        """
        with self._lock:
            return {"size": len(self._cache), "max_size": self._max_cache_size}

    def _evict_oldest_cache_entry(self) -> None:
        """淘汰最旧的缓存条目。

        必须在锁内调用。
        """
        assert self._lock._is_owned(), "_evict_oldest_cache_entry must be called within lock"
        if not self._cache:
            return
        oldest_key = min(self._cache.items(), key=lambda x: x[1]["time"])[0]
        del self._cache[oldest_key]

    # ------------------------------------------------------------------
    # 指标统计
    # ------------------------------------------------------------------

    def record_metric(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录指标值。

        Args:
            value: 指标数值。
            labels: 可选的标签字典，用于区分不同维度的指标。
        """
        if labels:
            key = json.dumps(labels, sort_keys=True, default=str)
        else:
            key = "default"
        with self._lock:
            self._metrics[key].append(value)
        self._logger.debug("Recorded metric %s: %s", key, value)

    def get_metric_summary(self, key: Optional[str] = None) -> Dict[str, Any]:
        """获取指标摘要统计。

        Args:
            key: 指标键，None 表示获取默认指标。

        Returns:
            包含 count, min, max, mean, median, std_dev, percentile_50, percentile_95, percentile_99 的字典。
        """
        metric_key = key if key else "default"
        with self._lock:
            if metric_key not in self._metrics:
                return {"count": 0, "min": 0.0, "max": 0.0, "mean": 0.0,
                        "median": 0.0, "std_dev": 0.0, "percentile_50": 0.0,
                        "percentile_95": 0.0, "percentile_99": 0.0}
            values = list(self._metrics[metric_key])
        
        if not values:
            return {"count": 0, "min": 0.0, "max": 0.0, "mean": 0.0,
                    "median": 0.0, "std_dev": 0.0, "percentile_50": 0.0,
                    "percentile_95": 0.0, "percentile_99": 0.0}

        sorted_vals = sorted(values)
        mean = statistics.mean(values)
        median = statistics.median(values)
        std_dev = statistics.stdev(values) if len(values) > 1 else 0.0
        p50 = _percentile_linear(sorted_vals, 0.5)
        p95 = _percentile_linear(sorted_vals, 0.95)
        p99 = _percentile_linear(sorted_vals, 0.99)

        return {
            "count": len(values),
            "min": min(values),
            "max": max(values),
            "mean": mean,
            "median": median,
            "std_dev": std_dev,
            "percentile_50": p50,
            "percentile_95": p95,
            "percentile_99": p99,
        }

    def get_metric_history(self, key: Optional[str] = None, limit: int = 100) -> List[float]:
        """获取指标历史数据。

        Args:
            key: 指标键，None 表示获取默认指标。
            limit: 返回的最大条目数。

        Returns:
            指标值列表。
        """
        metric_key = key if key else "default"
        with self._lock:
            if metric_key not in self._metrics:
                return []
            values = list(self._metrics[metric_key])
        return values[-limit:]

    # ------------------------------------------------------------------
    # 配置管理
    # ------------------------------------------------------------------

    def get_config(self, key: str, default: Any = None) -> Any:
        """获取配置值。

        Args:
            key: 配置键。
            default: 默认值。

        Returns:
            配置值或默认值。
        """
        with self._lock:
            if key in self._config:
                return self._config[key]
            if key in self._default_config:
                return self._default_config[key]
            return default

    def set_config(self, key: str, value: Any) -> None:
        """设置配置值。

        Args:
            key: 配置键。
            value: 配置值。
        """
        with self._lock:
            self._config[key] = value
            self._config_version += 1
        self._logger.debug("Set config %s = %s", key, value)

    def get_config_version(self) -> int:
        """获取配置版本号。

        Returns:
            当前配置版本号。
        """
        with self._lock:
            return self._config_version

    def reset_config(self) -> None:
        """重置配置为默认值。

        清除自定义配置，保留默认配置，版本号递增。
        """
        with self._lock:
            self._config = {}
            self._config_version += 1
        self._logger.info("Config reset to defaults, version %d", self._config_version)

    # ------------------------------------------------------------------
    # 事件处理
    # ------------------------------------------------------------------

    def register_event_handler(self, event_type: str, handler: Callable[[Any], None]) -> None:
        """注册事件处理器。

        Args:
            event_type: 事件类型标识。
            handler: 处理函数。
        """
        with self._lock:
            self._evt_handlers[event_type] = handler
        self._logger.debug("Registered event handler for %s", event_type)

    def emit_event(self, event_type: str, payload: Any = None) -> None:
        """发出事件。

        Args:
            event_type: 事件类型标识。
            payload: 事件负载数据。
        """
        with self._lock:
            handler = self._evt_handlers.get(event_type)
        
        if handler:
            try:
                handler(payload)
            except Exception as e:
                self._logger.error("Error in event handler for %s: %s", event_type, e)
        else:
            self._logger.debug("No handler registered for event %s", event_type)

    def clear_event_handlers(self) -> int:
        """清除所有事件处理器。

        Returns:
            清除的处理器数量。
        """
        with self._lock:
            count = len(self._evt_handlers)
            self._evt_handlers = {}
        self._logger.info("Cleared %d event handlers", count)
        return count

    # ------------------------------------------------------------------
    # 生命周期管理
    # ------------------------------------------------------------------

    def initialize(self) -> bool:
        """初始化组件。

        Returns:
            初始化成功返回 True，失败返回 False。
        """
        with self._lock:
            if self._initialized:
                self._logger.warning("Component already initialized")
                return False
            try:
                self._initialized = True
                self._status = "running"
                self._start_time = time.monotonic()
                self._logger.info("AudioFeatureExtractorStore initialized")
                return True
            except Exception as e:
                self._logger.error("Initialization failed: %s", e)
                self._status = "error"
                return False

    def shutdown(self) -> bool:
        """关闭组件。

        Returns:
            关闭成功返回 True，失败返回 False。
        """
        with self._lock:
            if not self._initialized:
                self._logger.debug("Component not initialized, nothing to shutdown")
                return True
            try:
                self._initialized = False
                self._status = "stopped"
                self._logger.info("AudioFeatureExtractorStore shutdown")
                return True
            except Exception as e:
                self._logger.error("Shutdown failed: %s", e)
                return False

    def restart(self) -> bool:
        """重启组件。

        Returns:
            重启成功返回 True，失败返回 False。
        """
        self.shutdown()
        time.sleep(0.1)
        return self.initialize()

    def get_status(self) -> str:
        """获取当前状态。

        Returns:
            状态字符串（idle/running/stopped/error）。
        """
        with self._lock:
            return self._status

    def is_healthy(self) -> bool:
        """检查组件是否健康。

        Returns:
            健康返回 True，否则 False。
        """
        with self._lock:
            return self._initialized and self._status != "error"

    def get_uptime(self) -> float:
        """获取运行时间（秒）。

        Returns:
            自初始化以来的运行秒数，未初始化返回 0.0。
        """
        with self._lock:
            if not self._initialized:
                return 0.0
            return time.monotonic() - self._start_time


def _percentile_linear(sorted_data: List[float], percentile: float) -> float:
    """使用线性插值计算百分位数。

    Args:
        sorted_data: 已排序的数值列表。
        percentile: 目标百分位（0.0–1.0）。

    Returns:
        线性插值后的百分位数值。
    """
    if not sorted_data:
        return 0.0
    n = len(sorted_data)
    if n == 1:
        return sorted_data[0]
    index = (n - 1) * percentile
    lower = int(math.floor(index))
    upper = int(math.ceil(index))
    if lower == upper:
        return sorted_data[lower]
    weight = index - lower
    return sorted_data[lower] * (1 - weight) + sorted_data[upper] * weight
