"""
音频感知模块基础设施工具类。

提供线程安全的状态管理、LRU缓存、指标统计及数据项CRUD操作的基础设施。
"""

import json
import time
import threading
import asyncio
import logging
from enum import Enum
from typing import Any, Dict, List, Optional, Callable, Set, Tuple, Union
from dataclasses import dataclass, field, asdict
from collections import defaultdict, OrderedDict
from copy import deepcopy


def _setup_logger(name: str) -> logging.Logger:
    """
    设置日志记录器。

    Args:
        name: 日志记录器名称。

    Returns:
        配置好的日志记录器。
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


class AudioTask(Enum):
    """
    音频任务类型枚举。

    支持转写、说话人、情绪、环境、声源定位、增强、分类、分割等任务。
    """

    TRANSCRIBE = "TRANSCRIBE"
    SPEAKER = "SPEAKER"
    EMOTION = "EMOTION"
    ENVIRONMENT = "ENVIRONMENT"
    SOURCE_LOCALIZATION = "SOURCE_LOCALIZATION"
    ENHANCE = "ENHANCE"
    CLASSIFY = "CLASSIFY"
    SEGMENT = "SEGMENT"

    @classmethod
    def all_values(cls) -> List[str]:
        """
        获取所有任务类型的值。

        Returns:
            所有任务类型值的列表。
        """
        return [e.value for e in cls]

    @classmethod
    def from_str(cls, text: str) -> Optional["AudioTask"]:
        """
        从字符串创建任务类型。

        Args:
            text: 任务类型名称或值。

        Returns:
            对应的任务类型或None。
        """
        for e in cls:
            if e.value == text or e.name == text:
                return e
        return None


@dataclass
class AudioResult:
    """
    音频结果数据类。

    用于存储音频处理任务的结果。
    """

    task: str = ""
    confidence: float = 0.0
    text: str = ""
    speaker: str = ""
    emotion: str = ""
    features: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典。

        Returns:
            字典形式的结果。
        """
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AudioResult":
        """
        从字典创建实例。

        Args:
            data: 字典数据。

        Returns:
            音频结果实例。
        """
        filtered = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        return cls(**filtered)


class SimpleCache:
    """
    简单的内存缓存实现，支持TTL和LRU驱逐策略。

    使用线程安全的LRU缓存，记录完整的统计信息包括插入、命中、未命中和驱逐。
    """

    def __init__(self, max_size: int = 10000) -> None:
        """
        初始化缓存。

        Args:
            max_size: 最大缓存容量。
        """
        self._max_size: int = max_size
        self._cache: OrderedDict[str, Dict[str, Any]] = OrderedDict()
        self._lock: threading.RLock = threading.RLock()
        self._stats: Dict[str, int] = {
            "cache_hits": 0,
            "cache_misses": 0,
            "cache_evictions": 0,
            "cache_insertions": 0,
        }
        self._logger: logging.Logger = logging.getLogger(self.__class__.__name__)

    def get(self, key: str) -> Optional[Any]:
        """
        获取缓存值。

        Args:
            key: 缓存键。

        Returns:
            缓存值或None。
        """
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                self._stats["cache_misses"] += 1
                return None

            # 防御性编程：检查必需键是否存在
            if "time" not in entry or "ttl" not in entry or "value" not in entry:
                # 记录异常数据，删除该条目
                del self._cache[key]
                self._stats["cache_evictions"] += 1
                self._logger.warning(f"Invalid cache entry for key: {key}, evicted")
                return None

            now = time.monotonic()
            if now - entry["time"] >= entry["ttl"]:
                del self._cache[key]
                self._stats["cache_evictions"] += 1
                return None

            self._cache.move_to_end(key)
            self._stats["cache_hits"] += 1
            return entry["value"]

    def set(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """
        设置缓存值。

        Args:
            key: 缓存键。
            value: 缓存值。
            ttl: 存活时间（秒）。
        """
        with self._lock:
            is_new_key = key not in self._cache
            if is_new_key:
                self._stats["cache_insertions"] += 1

            if key in self._cache:
                del self._cache[key]

            self._cache[key] = {
                "value": value,
                "time": time.monotonic(),
                "ttl": ttl,
            }
            self._cache.move_to_end(key)

            # LRU驱逐
            while len(self._cache) > self._max_size:
                self._cache.popitem(last=False)
                self._stats["cache_evictions"] += 1

    def invalidate(self, key: str) -> bool:
        """
        失效缓存。

        Args:
            key: 缓存键。

        Returns:
            是否成功失效。
        """
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                return True
            return False

    def clear(self) -> int:
        """
        清空缓存。

        Returns:
            清空的缓存数量。
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
            return count

    def expire_expired(self) -> int:
        """
        清理所有过期条目。

        Returns:
            清理的条目数。
        """
        with self._lock:
            now = time.monotonic()
            expired_keys = []
            for k, v in self._cache.items():
                # 防御性检查
                if "time" not in v or "ttl" not in v:
                    continue
                if now - v["time"] >= v["ttl"]:
                    expired_keys.append(k)

            for key in expired_keys:
                del self._cache[key]
                self._stats["cache_evictions"] += 1

            return len(expired_keys)

    def stats(self) -> Dict[str, Any]:
        """
        获取缓存统计。

        Returns:
            包含完整统计信息的字典，包括命中率计算。
        """
        with self._lock:
            hits = self._stats["cache_hits"]
            misses = self._stats["cache_misses"]
            total = hits + misses
            hit_rate = (hits / total) if total > 0 else 0.0

            return {
                "size": len(self._cache),
                "max_size": self._max_size,
                "hits": hits,
                "misses": misses,
                "evictions": self._stats["cache_evictions"],
                "insertions": self._stats["cache_insertions"],
                "hit_rate": round(hit_rate, 4),
            }


class StateMachine:
    """
    状态机实现，支持状态转换规则和验证。

    使用可重入锁（RLock）解决自死锁风险，支持线程安全的状态转换。
    """

    def __init__(
        self,
        states: List[str],
        initial_state: str,
        transitions: Optional[Dict[str, Set[str]]] = None,
    ) -> None:
        """
        初始化状态机。

        Args:
            states: 所有可能状态列表。
            initial_state: 初始状态。
            transitions: 状态转换规则，key为当前状态，value为可转换到的状态集合。
        """
        if initial_state not in states:
            raise ValueError(f"Initial state '{initial_state}' must be in states list")

        self._states: List[str] = states
        self._initial_state: str = initial_state
        self._transitions: Dict[str, Set[str]] = transitions or {}
        self._current_state: str = initial_state
        self._history: List[str] = [initial_state]
        # 使用RLock解决嵌套锁问题
        self._lock: threading.RLock = threading.RLock()
        self._logger: logging.Logger = logging.getLogger(self.__class__.__name__)

        # 验证转换规则
        for state in states:
            if state in self._transitions:
                for target in self._transitions[state]:
                    if target not in states:
                        raise ValueError(
                            f"Transition target '{target}' not in states list"
                        )

    @property
    def current_state(self) -> str:
        """
        获取当前状态。

        Returns:
            当前状态字符串。
        """
        with self._lock:
            return self._current_state

    @property
    def history(self) -> List[str]:
        """
        获取状态历史。

        Returns:
            状态历史列表的副本。
        """
        with self._lock:
            return list(self._history)

    def can_transition(self, target_state: str) -> bool:
        """
        检查是否可以转换到目标状态。

        Args:
            target_state: 目标状态。

        Returns:
            是否可转换。
        """
        with self._lock:
            if target_state not in self._states:
                return False
            allowed = self._transitions.get(self._current_state, set(self._states))
            return target_state in allowed

    def transition(self, target_state: str) -> bool:
        """
        执行状态转换。

        Args:
            target_state: 目标状态。

        Returns:
            转换是否成功。
        """
        with self._lock:
            if not self.can_transition(target_state):
                self._logger.warning(
                    f"Invalid state transition from '{self._current_state}' to '{target_state}'"
                )
                return False

            self._history.append(target_state)
            self._current_state = target_state
            self._logger.debug(f"State transition: '{self._current_state}'")
            return True

    def reset(self) -> None:
        """
        重置到初始状态。
        """
        with self._lock:
            self._current_state = self._initial_state
            self._history = [self._initial_state]
            self._logger.debug("State machine reset to initial state")


class AudioPerception:
    """
    听觉感知器。

    提供音频数据处理的基础设施，包括线程安全的状态管理、缓存、指标统计、
    配置管理及数据项CRUD操作。支持可选的浅拷贝以减少大体积数据的性能开销。
    """

    def __init__(self, use_deepcopy: bool = True) -> None:
        """
        初始化听觉感知器。

        Args:
            use_deepcopy: 是否使用深拷贝。设为False时使用浅拷贝以提高性能。
        """
        self._use_deepcopy: bool = use_deepcopy
        self._item_store: Dict[str, Dict[str, Any]] = {}
        self._cache: SimpleCache = SimpleCache(max_size=10000)
        self._metrics: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._config: Dict[str, Any] = {}
        self._default_config: Dict[str, Any] = {}
        self._config_version: int = 1
        self._evt_handlers: Dict[str, Callable] = {}
        self._initialized: bool = False
        self._status: str = "idle"
        self._start_time: float = 0.0
        self._tasks: Dict[str, Any] = {}
        self._workers: Dict[str, Any] = {}
        self._models: Dict[str, Any] = {}
        self._stats: Dict[str, int] = defaultdict(int)
        self._lock: threading.RLock = threading.RLock()
        self._logger: logging.Logger = _setup_logger(self.__class__.__name__)

        state_transitions: Dict[str, Set[str]] = {
            "idle": {"running", "stopped", "error"},
            "running": {"paused", "stopped", "error"},
            "paused": {"running", "stopped", "error"},
            "stopped": {"idle", "error"},
            "error": {"idle", "stopped"},
        }
        self._state_machine: StateMachine = StateMachine(
            states=["idle", "running", "paused", "stopped", "error"],
            initial_state="idle",
            transitions=state_transitions,
        )

    def _copy_data(self, data: Any) -> Any:
        """
        根据配置复制数据。

        Args:
            data: 要复制的数据。

        Returns:
            复制后的数据。
        """
        if self._use_deepcopy:
            return deepcopy(data)
        # 浅拷贝策略：对字典和列表进行浅层复制
        if isinstance(data, dict):
            return {k: v for k, v in data.items()}
        elif isinstance(data, list):
            return list(data)
        else:
            return data

    def _generate_item_id(self) -> str:
        """
        生成数据项ID。

        Returns:
            生成的唯一ID。
        """
        try:
            from src.ximu.common.utils import generate_id
            return generate_id("audioperception_item")
        except ImportError:
            # 降级方案：使用时间戳和随机数
            import uuid
            return f"audioperception_item_{uuid.uuid4().hex}"

    def create_item(self, data: Dict[str, Any]) -> str:
        """
        创建数据项。

        Args:
            data: 数据项内容。

        Returns:
            数据项ID。
        """
        item_id = self._generate_item_id()
        record: Dict[str, Any] = {
            "id": item_id,
            "data": self._copy_data(data),
            "created_at": time.time(),
            "updated_at": time.time(),
            "version": 1,
        }
        with self._lock:
            self._item_store[item_id] = record
            self._stats["item_created"] += 1
        self._logger.debug(f"Created item: {item_id}")
        return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """
        获取数据项。

        Args:
            item_id: 数据项ID。

        Returns:
            数据项内容或None。
        """
        with self._lock:
            record = self._item_store.get(item_id)
            if record:
                return self._copy_data(record["data"])
        return None

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """
        更新数据项。

        Args:
            item_id: 数据项ID。
            data: 更新的数据。

        Returns:
            是否成功。
        """
        with self._lock:
            if item_id in self._item_store:
                record = self._item_store[item_id]
                record["data"].update(self._copy_data(data))
                record["updated_at"] = time.time()
                record["version"] += 1
                self._stats["item_updated"] += 1
                self._logger.debug(f"Updated item: {item_id}")
                return True
            return False

    def delete_item(self, item_id: str) -> bool:
        """
        删除数据项。

        Args:
            item_id: 数据项ID。

        Returns:
            是否成功。
        """
        with self._lock:
            if item_id in self._item_store:
                del self._item_store[item_id]
                self._stats["item_deleted"] += 1
                self._logger.debug(f"Deleted item: {item_id}")
                return True
            return False

    def list_items(
        self,
        page: int = 1,
        page_size: int = 20,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        列出数据项。

        Args:
            page: 页码。
            page_size: 每页大小。
            filters: 过滤器。

        Returns:
            数据项列表和分页信息。
        """
        with self._lock:
            items = list(self._item_store.values())

        if filters:
            items = [
                it for it in items
                if all(it["data"].get(k) == v for k, v in filters.items())
            ]

        total = len(items)
        start = (page - 1) * page_size
        end = start + page_size
        return {
            "items": [self._copy_data(it["data"]) for it in items[start:end]],
            "total": total,
            "page": page,
            "page_size": page_size,
        }

    def count_items(self) -> int:
        """
        统计数据项数量。

        Returns:
            数据项总数。
        """
        with self._lock:
            return len(self._item_store)

    def search_items(
        self, query: str, fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        搜索数据项。

        Args:
            query: 搜索查询。
            fields: 搜索字段列表，None表示搜索所有字段。

        Returns:
            搜索结果列表。
        """
        results: List[Dict[str, Any]] = []
        query_lower = query.lower()
        with self._lock:
            for record in self._item_store.values():
                data = record["data"]
                search_fields = fields or list(data.keys())
                for f in search_fields:
                    val = str(data.get(f, "")).lower()
                    if query_lower in val:
                        results.append(self._copy_data(data))
                        break
        return results

    def batch_create_items(self, batch: List[Dict[str, Any]]) -> List[str]:
        """
        批量创建数据项。

        Args:
            batch: 数据项列表。

        Returns:
            数据项ID列表。
        """
        return [self.create_item(item) for item in batch]

    def batch_delete_items(self, ids: List[str]) -> int:
        """
        批量删除数据项。

        Args:
            ids: 数据项ID列表。

        Returns:
            删除数量。
        """
        count = 0
        for item_id in ids:
            if self.delete_item(item_id):
                count += 1
        self._logger.debug(f"Batch deleted {count} items")
        return count

    def export_items(self, path: str) -> str:
        """
        导出数据项到JSON文件。

        Args:
            path: 导出路径。

        Returns:
            导出路径。

        Raises:
            OSError: 当文件写入失败时。
        """
        with self._lock:
            data = [self._copy_data(r) for r in self._item_store.values()]

        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2, default=str)
            self._logger.info(f"Exported {len(data)} items to {path}")
        except OSError as e:
            self._logger.error(f"Failed to export items: {e}")
            raise
        return path

    def import_items(self, path: str) -> int:
        """
        从JSON文件导入数据项。

        Args:
            path: 导入路径。

        Returns:
            导入数量。

        Raises:
            OSError: 当文件读取失败时。
            json.JSONDecodeError: 当JSON格式无效时。
        """
        count = 0
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            self._logger.error(f"Failed to import items: {e}")
            raise

        for record in data:
            if not isinstance(record, dict):
                continue
            item_id = record.get("id", self._generate_item_id())
            with self._lock:
                self._item_store[item_id] = record
            count += 1

        self._logger.info(f"Imported {count} items from {path}")
        return count

    def get_item_stats(self) -> Dict[str, Any]:
        """
        获取数据项统计。

        Returns:
            统计数据。
        """
        with self._lock:
            return {
                "total": len(self._item_store),
                "created": self._stats.get("item_created", 0),
                "updated": self._stats.get("item_updated", 0),
                "deleted": self._stats.get("item_deleted", 0),
            }

    def get_cache(self, key: str) -> Optional[Any]:
        """
        获取缓存。

        Args:
            key: 缓存键。

        Returns:
            缓存值或None。
        """
        return self._cache.get(key)

    def set_cache(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """
        设置缓存。

        Args:
            key: 缓存键。
            value: 缓存值。
            ttl: 存活时间（秒）。
        """
        self._cache.set(key, value, ttl)

    def invalidate_cache(self, key: str) -> bool:
        """
        失效缓存。

        Args:
            key: 缓存键。

        Returns:
            是否成功。
        """
        return self._cache.invalidate(key)

    def clear_cache(self) -> int:
        """
        清空缓存。

        Returns:
            清空的缓存数量。
        """
        return self._cache.clear()

    def expire_cache(self) -> int:
        """
        清理过期缓存。

        Returns:
            清理的条目数。
        """
        return self._cache.expire_expired()

    def get_cache_stats(self) -> Dict[str, Any]:
        """
        获取缓存统计。

        Returns:
            缓存统计信息。
        """
        return self._cache.stats()

    def record_metric(
        self, value: float, labels: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        记录指标。

        Args:
            value: 指标值。
            labels: 标签。
        """
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True)
            self._metrics[key].append(
                {"value": value, "time": time.time(), "labels": labels or {}}
            )
            # 限制单个指标的历史长度
            if len(self._metrics[key]) > 10000:
                self._metrics[key] = self._metrics[key][-5000:]

    def get_stats(
        self, labels: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        获取统计。

        Args:
            labels: 标签。

        Returns:
            统计信息。
        """
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True)
            values = [e["value"] for e in self._metrics.get(key, [])]

        if not values:
            return {
                "count": 0,
                "mean": 0.0,
                "min": 0.0,
                "max": 0.0,
                "p50": 0.0,
                "p95": 0.0,
                "p99": 0.0,
            }

        sorted_vals = sorted(values)
        n = len(sorted_vals)
        return {
            "count": n,
            "mean": sum(values) / n,
            "min": sorted_vals[0],
            "max": sorted_vals[-1],
            "p50": sorted_vals[int(n * 0.5)],
            "p95": sorted_vals[min(int(n * 0.95), n - 1)],
            "p99": sorted_vals[min(int(n * 0.99), n - 1)],
        }

    def get_history(
        self,
        labels: Optional[Dict[str, Any]] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """
        获取历史。

        Args:
            labels: 标签。
            limit: 限制数量。

        Returns:
            历史数据列表。
        """
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True)
            return list(self._metrics.get(key, []))[-limit:]

    def reset_metrics(self) -> None:
        """
        重置指标。
        """
        with self._lock:
            self._metrics.clear()
            self._logger.debug("Metrics reset")

    def get_config(self, key: str, default: Any = None) -> Any:
        """
        获取配置。

        Args:
            key: 配置键。
            default: 默认值。

        Returns:
            配置值。
        """
        with self._lock:
            return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """
        设置配置。

        Args:
            key: 配置键。
            value: 配置值。
        """
        with self._lock:
            self._config[key] = value
            self._config_version += 1
            self._logger.debug(f"Config set: {key} = {value}")

    def get_all_config(self) -> Dict[str, Any]:
        """
        获取全部配置。

        Returns:
            配置字典。
        """
        with self._lock:
            return dict(self._config)

    def update_config(self, updates: Dict[str, Any]) -> None:
        """
        批量更新配置。

        Args:
            updates: 更新内容。
        """
        with self._lock:
            self._config.update(updates)
            self._config_version += 1
            self._logger.debug(f"Config updated: {list(updates.keys())}")

    def get_state(self) -> str:
        """
        获取当前状态。

        Returns:
            当前状态字符串。
        """
        return self._state_machine.current_state

    def transition_state(self, target: str) -> bool:
        """
        转换状态。

        Args:
            target: 目标状态。

        Returns:
            是否成功转换。
        """
        return self._state_machine.transition(target)

    def reset_state(self) -> None:
        """
        重置状态机。
        """
        self._state_machine.reset()

    def add_event_handler(self, event: str, handler: Callable) -> None:
        """
        添加事件处理器。

        Args:
            event: 事件名称。
            handler: 处理函数。
        """
        with self._lock:
            self._evt_handlers[event] = handler

    def emit_event(self, event: str, data: Optional[Dict[str, Any]] = None) -> None:
        """
        发出事件。

        Args:
            event: 事件名称。
            data: 事件数据。
        """
        handler = self._evt_handlers.get(event)
        if handler:
            try:
                handler(data)
            except Exception as e:
                self._logger.error(f"Event handler error for {event}: {e}")
        else:
            self._logger.debug(f"No handler for event: {event}")

    async def async_create_item(self, data: Dict[str, Any]) -> str:
        """
        异步创建数据项。

        Args:
            data: 数据项内容。

        Returns:
            数据项ID。
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.create_item, data)

    async def async_get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """
        异步获取数据项。

        Args:
            item_id: 数据项ID。

        Returns:
            数据项内容或None。
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get_item, item_id)
