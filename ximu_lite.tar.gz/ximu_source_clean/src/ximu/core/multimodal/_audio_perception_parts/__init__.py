# -*- coding: utf-8 -*-
"""音频感知拆分模块包初始化。

本包包含 audio_perception 的功能实现，按职责拆分为：
- part1: 核心数据结构与配置（枚举、数据类）
- part2: 基础音频感知能力（ASR、声纹、事件检测等）
- part3: 高级封装与便捷接口（AudioPerception 主类等）

导入时仅声明包结构，实际符号由上层 audio_perception.py 负责聚合导出。
"""
from __future__ import annotations

__all__: list[str] = []
