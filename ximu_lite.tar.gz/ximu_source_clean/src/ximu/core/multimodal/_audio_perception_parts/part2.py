"""Part 2 of audio_perception - 环境音识别数据管理核心（优化版）"""

from typing import Any, Dict, List, Optional, Tuple, Callable, Union, Pattern
from datetime import datetime
from collections import defaultdict, OrderedDict
from copy import deepcopy
import json
import time
import threading
import asyncio
import pickle
import statistics
import re
import os
import logging
import tempfile
from src.ximu.common.utils import generate_id
from .part1 import _setup_logger

class EnvironmentSoundClassifier:
    """环境音识别数据管理中间层（线程安全/内存持久化）"""
    
    # 内部常量
    _METRIC_WINDOW_SIZE: int = 10000
    _METRIC_RETAIN_SIZE: int = 5000
    _CONFIG_FILE: str = "default_config.json"
    _DEFAULT_MAX_CACHE_SIZE: int = 10000
    _DEFAULT_CACHE_TTL: float = 300.0
    _INDEXFields: Pattern = re.compile(r'^index_(\w+)$')
    _MAX_HISTORY: int = 100

    def __init__(self) -> None:
        """初始化环境音识别数据管理器"""
        self._logger: logging.Logger = _setup_logger(self.__class__.__name__)
        self._lock = threading.RLock()
        self._cache: OrderedDict[str, Dict[str, Any]] = OrderedDict()
        self._max_cache_size = self._DEFAULT_MAX_CACHE_SIZE
        self._default_ttl = self._DEFAULT_CACHE_TTL
        self._item_store: Dict[str, Dict[str, Any]] = {}
        self._metrics: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._stats = defaultdict(int)
        self._config: Dict[str, Any] = {}
        self._default_config = self._import_default_config()
        self._config_version = 1
        self._initialized = False
        self._status = "idle"
        self._start_time = time.time()
        self._state_history: List[Dict[str, Any]] = []
        self._event_handlers: Dict[str, Callable] = {}
        self._index_cache: Dict[str, List[str]] = defaultdict(list)
        self._clean_thread = threading.Thread(target=self._background_cleaner, daemon=True)

    def _background_cleaner(self) -> None:
        """后台清理线程（缓存/指标/状态）"""
        while True:
            time.sleep(60)
            self.clear_cache()
            self.clear_metrics()
            self._state_history = self._state_history[-self._MAX_HISTORY:]

    def _import_default_config(self) -> Dict[str, Any]:
        """加载数据库默认配置"""
        try:
            with open(self._CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError):
            self._logger.warning("Failed to load default config")
            return {}

    # ==================== 项管理CRUD ====================

    def create_item(self, data: Dict[str, Any]) -> str:
        """创建环境音识别数据项（带版本控制）"""
        if not isinstance(data, dict):
            raise TypeError("data must be a dictionary")
        
        with self._lock:
            item_id = generate_id("environmentsoundclassifier_item")
            record = {
                "id": item_id,
                "data": deepcopy(data),
                "created_at": time.time(),
                "updated_at": time.time(),
                "version": 1
            }
            self._item_store[item_id] = record
            self._stats["created"] += 1
            self._update_index(item_id, record["data"])
        self._trigger_event("item_created", {"id": item_id})
        return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取指定环境音识别数据项（带版本校验）"""
        with self._lock:
            record = self._item_store.get(item_id)
            if record:
                return deepcopy(record["data"])
        return None

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新指定环境音识别数据项（乐观锁）"""
        if not isinstance(data, dict):
            raise TypeError("data must be a dictionary")
        
        with self._lock:
            record = self._item_store.get(item_id)
            if not record:
                return False
            
            if record["version"] != self._config_version:
                return False
            
            record["data"].update(deepcopy(data))
            record["updated_at"] = time.time()
            record["version"] += 1
            self._stats["updated"] += 1
            self._update_index(item_id, record["data"])
            self._trigger_event("item_updated", {"id": item_id})
            return True

    def delete_item(self, item_id: str) -> bool:
        """删除指定环境音识别数据项（原子操作）"""
        with self._lock:
            if item_id in self._item_store:
                del self._item_store[item_id]
                self._stats["deleted"] += 1
                self._trigger_event("item_deleted", {"id": item_id})
                return True
        return False

    def list_items(
        self,
        page: int = 1,
        page_size: int = 20,
        filters: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """分页查询环境音识别数据项（索引加速）"""
        with self._lock:
            total = len(self._item_store)
            start = (page-1)*page_size
            end = start + page_size
            items = self._item_store.values()[start:end]
        
        if filters:
            items = [item for item in items if all(item["data"].get(k) == v for k, v in filters.items())]
        
        return {
            "items": [deepcopy(item["data"]) for item in items],
            "total": total,
            "page": page,
            "page_size": page_size
        }

    def search_items(
        self,
        query: str,
        fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """智能搜索环境音识别数据项（倒排索引）"""
        if not query:
            return []
        
        with self._lock:
            indexes = self._index_cache.get(query, {})
            candidates = indexes.get("candidates", [])
            if not candidates:
                return []
            
            matches = []
            for item_id in candidates:
                record = self._item_store[item_id]
                if all(query.lower() in str(record["data"][k]).lower() for k in fields):
                    matches.append(record["data"])
            return matches

    # ==================== 缓存管理 ====================

    def get_cache(self, key: str) -> Optional[Any]:
        """获取缓存值（带TTL校验）"""
        with self._lock:
            entry = self._cache.get(key)
            if entry and time.time() - entry["time"] < entry["ttl"]:
                return entry["value"]
        return None

    def set_cache(self, key: str, value: Any, ttl: Optional[float] = 300.0) -> None:
        """设置缓存值（自动淘汰）"""
        with self._lock:
            if len(self._cache) > self._max_cache_size:
                self._cache.popitem(last=False)
            self._cache[key] = {"value": deepcopy(value), "time": time.time(), "ttl": ttl}

    def _update_index(self, item_id: str, data: Dict[str, Any]) -> None:
        """更新倒排索引（异步非阻塞）"""
        asyncio.create_task(self._update_index协程(item_id, data))

    async def _update_index协程(self, item_id: str, data: Dict[str, Any]) -> None:
        """索引更新协程（减少锁竞争）"""
        with self._lock:
            self._index_cache = defaultdict(lambda: {"candidates": set()})

        for field, value in data.items():
            if match := self._INDEXFields.match(field):
                index_type = match.group(1)
                self._index_cache[index_type]["candidates"].add(item_id)
                self._index_cache[index_type]["values"].add(value)

    # ==================== 指标统计 ====================

    def record_metric(self, value: Union[int, float], labels: Optional[Dict[str, Any]] = None) -> None:
        """记录指标（带标签和窗口控制）"""
        if not isinstance(value, (int, float)):
            raise TypeError("value must be numeric")
        
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True)
            self._metrics[key].append({"value": float(value), "time": time.time()})
            if len(self._metrics[key]) > self._METRIC_WINDOW_SIZE:
                self._metrics[key] = self._metrics[key][-self._METRIC_RETAIN_SIZE:]

    def get_stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """获取指标统计（带百分位计算）"""
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True)
            values = self._metrics.get(key, [])
        
        if not values:
            return {"count": 0, "mean": 0.0, "min": 0.0, "max": 0.0, "p50": 0.0, "p95": 0.0, "p99": 0.0}
        
        sorted_vals = sorted(v["value"] for v in values)
        n = len(sorted_vals)
        return {
            "count": n,
            "mean": sum(sorted_vals) / n,
            "min": sorted_vals[0] if n else 0,
            "max": sorted_vals[-1] if n else 0,
            "p50": sorted_vals[n//2],
            "p95": sorted_vals[int(0.95*n)],
            "p99": sorted_vals[int(0.99*n)]
        }

    # ==================== 配置管理 ====================

    def get_config(self) -> Dict[str, Any]:
        """获取配置（带版本校验）"""
        with self._lock:
            return deepcopy(self._config)

    def set_config(self, config: Dict[str, Any]) -> int:
        """更新配置（原子操作）"""
        if not isinstance(config, dict):
            raise TypeError("config must be a dictionary")
        
        with self._lock:
            self._config.update(deepcopy(config))
            self._config_version += 1
        return self._config_version

    # ==================== 状态管理 ====================

    def initialize(self) -> None:
        """初始化组件状态（原子操作）"""
        with self._lock:
            if self._initialized:
                return
            self._initialized = True
            self._status = "initialized"
            self._state_history.append({
                "timestamp": time.time(),
                "status": self._status,
                "action": "initialize"
            })
            self._clean_thread.start()

    def shutdown(self) -> None:
        """关闭组件（原子操作）"""
        with self._lock:
            if not self._initialized:
                return
            self._initialized = False
            self._status = "shutdown"
            self._state_history.append({
                "timestamp": time.time(),
                "status": self._status,
                "action": "shutdown"
            })
            self._clean_thread.join()

    # ==================== 事件处理 ====================

    def register_event_handler(self, event_type: str, handler: Callable) -> None:
        """注册事件处理器（原子操作）"""
        with self._lock:
            self._event_handlers[event_type] = handler

    def trigger_event(self, event_type: str, data: Optional[Dict[str, Any]] = None) -> List[Any]:
        """触发事件（原子操作）"""
        with self._lock:
            handlers = list(self._event_handlers.get(event_type, []))
            results = []
            for handler in handlers:
                try:
                    results.append(handler(data))
                except Exception as e:
                    self._logger.error("Event handler failed: %s", str(e))
            return results

    # ==================== 其他方法 ====================

    def _get_index(self, query: str) -> List[str]:
        """获取索引项（内部方法）"""
        return self._index_cache.get(query, {}).get("candidates", [])

    def _clean_cache(self) -> None:
        """手动清理缓存（内部方法）"""
        with self._lock:
            self._cache = OrderedDict()
