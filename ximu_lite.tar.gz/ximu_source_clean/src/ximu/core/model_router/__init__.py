# -*- coding: utf-8 -*-
"""模型路由模块初始化，导出核心类和便捷函数。"""
from .router import (
    ModelRouter,
    RouteConfig,
    RouteDecision,
    ModelCandidate,
    TaskType,
    PriorityLevel,
    CostTier,
    get_router,
    reset_router,
    route_to_model,
    add_model,
)

__all__ = [
    # 核心类
    "ModelRouter",
    "RouteConfig",
    "RouteDecision",
    "ModelCandidate",
    # 枚举
    "TaskType",
    "PriorityLevel",
    "CostTier",
    # 便捷函数
    "get_router",
    "reset_router",
    "route_to_model",
    "add_model",
]

__version__ = "1.0.0"
