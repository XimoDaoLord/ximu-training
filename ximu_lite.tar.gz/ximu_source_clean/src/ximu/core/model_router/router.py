# -*- coding: utf-8 -*-
"""模型路由模块：根据任务类型、优先级、成本等维度智能选择最优模型。"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class TaskType(Enum):
    """任务类型枚举。"""
    GENERAL_CHAT = "general_chat"
    CODE_GENERATION = "code_generation"
    ANALYSIS = "analysis"
    CREATIVE = "creative"
    EMBEDDING = "embedding"
    CLASSIFICATION = "classification"
    SUMMARY = "summary"
    TRANSLATION = "translation"
    MULTIMODAL = "multimodal"


class PriorityLevel(Enum):
    """优先级等级。"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    BACKGROUND = "background"


class CostTier(Enum):
    """成本等级。"""
    FREE = "free"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    PREMIUM = "premium"


@dataclass
class ModelCandidate:
    """模型候选者数据类。"""
    model_id: str
    provider: str
    priority: int = 100
    cost_per_million: float = 0.0
    is_free: bool = True
    success_rate: float = 1.0
    avg_latency_ms: float = 500.0
    max_retries: int = 3
    circuit_open: bool = False
    health_status: str = "healthy"


@dataclass
class RouteDecision:
    """路由决策结果。"""
    selected_model: str
    provider: str
    task_type: TaskType
    priority: PriorityLevel
    cost_tier: CostTier
    confidence: float
    reason: str
    alternatives: List[str] = field(default_factory=list)


@dataclass
class RouteConfig:
    """路由配置。"""
    task_type_preferences: Dict[TaskType, List[str]] = field(default_factory=dict)
    priority_weights: Dict[PriorityLevel, float] = field(default_factory=dict)
    cost_sensitive_threshold: float = 10.0
    latency_tolerance_ms: float = 3000.0
    min_success_rate: float = 0.7
    enable_circuit_breaker: bool = True
    enable_cost_optimization: bool = True


class ModelRouter:
    """智能模型路由器，支持多级决策和自适应权重调整。"""

    def __init__(self, config: Optional[RouteConfig] = None) -> None:
        self.config = config or RouteConfig()
        self._candidates: Dict[str, ModelCandidate] = {}
        self._lock = threading.RLock()
        self._route_history: List[Dict[str, Any]] = []
        self._history_lock = threading.Lock()
        self._init_default_config()

    def _init_default_config(self) -> None:
        """初始化默认路由配置。"""
        self.config.task_type_preferences = {
            TaskType.GENERAL_CHAT: ["glm-4-flash", "qwen-turbo", "agnes-2.5-flash"],
            TaskType.CODE_GENERATION: ["claude-3-sonnet", "gpt-4", "qwen-plus"],
            TaskType.ANALYSIS: ["claude-3-opus", "gpt-4", "glm-4-plus"],
            TaskType.CREATIVE: ["claude-3-sonnet", "gpt-4", "qwen-max"],
            TaskType.EMBEDDING: ["text-embedding-3-small", "bge-large", "text2vec"],
            TaskType.CLASSIFICATION: ["glm-4-flash", "qwen-turbo", "bge-large"],
            TaskType.SUMMARY: ["glm-4-flash", "qwen-turbo", "agnes-2.5-flash"],
            TaskType.TRANSLATION: ["claude-3-sonnet", "gpt-4", "qwen-max"],
            TaskType.MULTIMODAL: ["gpt-4-vision", "claude-3-opus", "glm-4v"],
        }
        self.config.priority_weights = {
            PriorityLevel.CRITICAL: 1.5,
            PriorityLevel.HIGH: 1.2,
            PriorityLevel.MEDIUM: 1.0,
            PriorityLevel.LOW: 0.8,
            PriorityLevel.BACKGROUND: 0.5,
        }

    def add_candidate(self, candidate: ModelCandidate) -> None:
        """添加模型候选者到路由器。"""
        with self._lock:
            self._candidates[candidate.model_id] = candidate
            logger.debug("添加模型候选: %s", candidate.model_id)

    def remove_candidate(self, model_id: str) -> None:
        """移除指定模型候选者。"""
        with self._lock:
            self._candidates.pop(model_id, None)

    def _filter_available(self, model_ids: List[str]) -> List[str]:
        """过滤出可用且未熔断的模型 ID 列表。"""
        available: List[str] = []
        with self._lock:
            for mid in model_ids:
                cand = self._candidates.get(mid)
                if cand and not cand.circuit_open and cand.health_status != "unhealthy":
                    available.append(mid)
        return available

    def _score_candidates(self,
                          available: List[str],
                          task_type: TaskType,
                          priority: PriorityLevel,
                          cost_sensitive: bool) -> Dict[str, float]:
        """计算每个候选模型的综合得分。"""
        weights = self.config.priority_weights.get(priority, 1.0)
        scored: Dict[str, float] = {}
        threshold = self.config.cost_sensitive_threshold if cost_sensitive else float('inf')

        for mid in available:
            cand = self._candidates.get(mid)
            if not cand:
                continue
            score = 0.0
            score += cand.success_rate * 40
            score += (1 - min(cand.avg_latency_ms / self.config.latency_tolerance_ms, 1.0)) * 30
            if cand.is_free or cand.cost_per_million <= threshold:
                score += 20
            score += weights * 10
            scored[mid] = score
        return scored

    def _determine_cost_tier(self, cost: float, is_free: bool) -> CostTier:
        """根据成本和免费状态确定成本等级。"""
        if is_free:
            return CostTier.FREE
        if cost <= 1.0:
            return CostTier.LOW
        if cost <= 5.0:
            return CostTier.MEDIUM
        if cost <= 10.0:
            return CostTier.HIGH
        return CostTier.PREMIUM

    def _calculate_confidence(self,
                              scores: Dict[str, float],
                              best_id: str) -> float:
        """计算路由决策的置信度。"""
        if not scores:
            return 0.0
        total = sum(scores.values())
        return scores.get(best_id, 0) / total if total > 0 else 0.0

    def _get_alternatives(self,
                          scores: Dict[str, float],
                          best_id: str,
                          limit: int = 3) -> List[str]:
        """获取备选模型列表。"""
        sorted_models = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [m for m, _ in sorted_models if m != best_id][:limit]

    def _record_route(self,
                      task_type: TaskType,
                      priority: PriorityLevel,
                      model_id: str,
                      confidence: float,
                      scores: Dict[str, float]) -> None:
        """记录路由历史用于后续分析。"""
        entry = {
            "task_type": task_type.value,
            "priority": priority.value,
            "model_id": model_id,
            "confidence": confidence,
            "scores": scores,
            "timestamp": time.time(),
        }
        with self._history_lock:
            self._route_history.append(entry)

    def _generate_reason(self,
                         task_type: TaskType,
                         priority: PriorityLevel,
                         model_id: str,
                         scores: Dict[str, float]) -> str:
        """生成路由决策的解释说明。"""
        return f"基于任务类型{task_type.value}和优先级{priority.value}选择{model_id}"

    def route(self,
              task_type: TaskType,
              priority: PriorityLevel,
              requirement: Optional[Dict[str, Any]] = None,
              cost_sensitive: bool = False) -> RouteDecision:
        """执行模型路由决策。

        Args:
            task_type: 任务类型
            priority: 优先级等级
            requirement: 额外要求
            cost_sensitive: 是否对成本敏感

        Returns:
            RouteDecision: 路由决策结果
        """
        requirement = requirement or {}
        preferred_models = self.config.task_type_preferences.get(task_type, [])
        available = self._filter_available(preferred_models)

        if not available:
            available = self._filter_available(list(self._candidates.keys()))

        if not available:
            return RouteDecision(
                selected_model="fallback-model",
                provider="unknown",
                task_type=task_type,
                priority=priority,
                cost_tier=CostTier.HIGH,
                confidence=0.0,
                reason="No available models"
            )

        scored = self._score_candidates(available, task_type, priority, cost_sensitive)
        best_model_id = max(scored, key=scored.get)
        candidate = self._candidates[best_model_id]
        cost_tier = self._determine_cost_tier(candidate.cost_per_million, candidate.is_free)
        confidence = self._calculate_confidence(scored, best_model_id)
        alternatives = self._get_alternatives(scored, best_model_id, limit=3)
        self._record_route(task_type, priority, best_model_id, confidence, scored)

        return RouteDecision(
            selected_model=best_model_id,
            provider=candidate.provider,
            task_type=task_type,
            priority=priority,
            cost_tier=cost_tier,
            confidence=confidence,
            reason=self._generate_reason(task_type, priority, best_model_id, scored),
            alternatives=alternatives
        )


_global_router: Optional[ModelRouter] = None
_router_lock = threading.Lock()


def get_router() -> ModelRouter:
    """获取全局单例路由器实例。"""
    global _global_router
    with _router_lock:
        if _global_router is None:
            _global_router = ModelRouter()
        return _global_router


def reset_router() -> None:
    """重置全局路由器实例。"""
    global _global_router
    with _router_lock:
        _global_router = None


def route_to_model(task_type: TaskType,
                   priority: PriorityLevel,
                   cost_sensitive: bool = False) -> RouteDecision:
    """便捷函数：使用全局路由器执行路由。"""
    router = get_router()
    return router.route(task_type, priority, cost_sensitive=cost_sensitive)


def add_model(candidate: ModelCandidate) -> None:
    """便捷函数：向全局路由器添加模型候选。"""
    router = get_router()
    router.add_candidate(candidate)
