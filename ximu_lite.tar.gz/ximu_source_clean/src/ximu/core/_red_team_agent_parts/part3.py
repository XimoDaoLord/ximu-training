"""Red Team Agent Part 3: 扩展处理器组件。

提供具有统计、缓存、历史记录功能的通用处理器类，用于数据处理流水线中的各步骤。
版本: 0.5
"""

import logging
import hashlib
import math
import random
import threading
from collections import defaultdict, deque, OrderedDict
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.common.utils import Stopwatch
from src.ximu.common.utils import now_timestamp
from src.ximu.common.utils import safe_json_dumps
from src.ximu.common.utils import safe_json_loads

logger = logging.getLogger("src.ximu.core._red_team_agent_parts.part3")


class BaseRedTeamProcessor:
    """
    Red Team 处理器基类，提供通用的数据处理、统计、缓存和验证功能。
    
    封装了处理器核心逻辑，包括：
    - 数据转换与批量处理
    - 统计信息记录（处理数、成功/失败、耗时）
    - 历史记录维护（带容量限制）
    - 数据验证与序列化
    - 线程安全的状态管理
    
    参数:
        name: 处理器实例名称。
        **kwargs: 额外配置参数。
    """
    
    _VERSION = "1.0.0"
    
    def __init__(self, name: str = "base_processor", **kwargs: Any) -> None:
        """
        初始化处理器实例。
        
        参数:
            name: 处理器名称，用于标识和日志记录。
            **kwargs: 额外配置参数，存储于内部配置字典中。
        """
        self.name: str = name
        self._config: Dict[str, Any] = kwargs
        self._lock: threading.RLock = threading.RLock()
        self._cache: OrderedDict[str, Any] = OrderedDict()
        self._stats: Dict[str, Union[int, float]] = {
            'processed': 0, 
            'success': 0, 
            'failed': 0, 
            'total_time': 0.0
        }
        self._history: deque = deque(maxlen=5000)
        self._state: str = 'idle'
        self._initialized: bool = False
        self._version: str = self._VERSION
        self._initialized = True
    
    def process_step(self, data: Any, step: int, **kwargs: Any) -> Optional[Any]:
        """
        处理单个数据步骤，记录统计信息和历史。
        
        参数:
            data: 待处理的数据，可以是任何类型。
            step: 步骤索引，用于标识当前处理阶段。
            **kwargs: 额外参数，透传给内部转换方法。
        
        返回:
            处理后的数据；若处理失败则返回 None。
        """
        with self._lock:
            self._state = 'processing'
            sw = Stopwatch().start()
            try:
                result = self._transform(data, step)
            except Exception as e:
                logger.exception("转换失败，step=%s, data_type=%s", step, type(data).__name__, exc_info=True)
                result = None
            
            elapsed = sw.stop().elapsed
            self._stats['processed'] += 1
            self._stats['total_time'] += elapsed
            
            if result is not None:
                self._stats['success'] += 1
            else:
                self._stats['failed'] += 1
            
            self._history.append((now_timestamp(), f'process_step_{step}', result is not None, elapsed))
            self._state = 'idle'
            return result
    
    def __getattr__(self, name: str) -> Any:
        """
        动态属性访问：支持 process_step_N 形式的便捷方法。
        
        参数:
            name: 属性名称。
        
        返回:
            对应的闭包函数或抛出 AttributeError。
        """
        if name.startswith('process_step_') and name[13:].isdigit():
            step = int(name[13:])
            return lambda data, **kw: self.process_step(data, step, **kw)
        raise AttributeError(name)
    
    def _transform(self, data: Any, step: int) -> Any:
        """
        内部数据转换逻辑，根据数据类型执行不同转换。
        
        参数:
            data: 原始数据。
            step: 当前步骤索引，用于变换系数计算。
        
        返回:
            转换后的数据。
        """
        if data is None:
            return None
        
        if isinstance(data, dict):
            result = dict(data)
            result['_processed_by'] = self.name
            result['_step'] = step
            result['_ts'] = now_timestamp()
            try:
                hash_input = str(result).encode('utf-8')
                result['_hash'] = hashlib.md5(hash_input, usedforsecurity=False).hexdigest()[:16]
            except Exception as e:
                logger.warning("哈希计算失败: %s", str(e))
                result['_hash'] = "unknown"
            return result
        
        if isinstance(data, (list, tuple)):
            return [self._transform(item, step) for item in data]
        
        if isinstance(data, (int, float)):
            return data * (1.0 + step * 0.01)
        
        if isinstance(data, str):
            return f"{data}_processed_{step}"
        
        return data
    
    def batch_process(self, items: List[Any], **kwargs: Any) -> List[Any]:
        """
        批量处理多个数据项，每个项经过12步转换。
        
        参数:
            items: 数据项列表。
            **kwargs: 额外参数。
        
        返回:
            处理后的数据项列表。
        """
        results: List[Any] = []
        for item in items:
            r = item
            for j in range(12):
                try:
                    r = self._transform(r, j)
                except Exception as e:
                    logger.exception("批量处理转换失败，item_index=%s, step=%s", len(results), j, exc_info=True)
                    r = None
            results.append(r)
        return results
    
    def get_stats(self) -> Dict[str, Union[int, float]]:
        """
        获取处理统计信息。
        
        返回:
            包含 processed, success, failed, total_time 的字典。
        """
        with self._lock:
            return dict(self._stats)
    
    def get_history(self, limit: int = 100) -> List[Tuple[float, str, bool, float]]:
        """
        获取最近的历史记录。
        
        参数:
            limit: 返回的最大记录数，默认100条。
        
        返回:
            历史记录元组列表，每条记录为 (时间戳, 操作名, 成功标志, 耗时)。
        """
        with self._lock:
            return list(self._history)[-limit:]
    
    def reset(self) -> None:
        """
        重置统计信息和历史记录。
        """
        with self._lock:
            self._stats = {'processed': 0, 'success': 0, 'failed': 0, 'total_time': 0.0}
            self._history.clear()
    
    def validate(self, data: Any) -> Tuple[bool, str]:
        """
        验证数据是否有效。
        
        参数:
            data: 待验证的数据。
        
        返回:
            (是否有效, 验证结果描述) 元组。
        """
        if data is None:
            return False, 'data_is_none'
        if isinstance(data, dict) and not data:
            return False, 'empty_dict'
        if isinstance(data, (list, tuple)) and len(data) == 0:
            return False, 'empty_collection'
        return True, 'valid'
    
    def serialize(self, data: Any) -> str:
        """
        将数据序列化为 JSON 字符串。
        
        参数:
            data: 待序列化的数据。
        
        返回:
            序列化后的字符串，失败时返回原始字符串表示。
        """
        try:
            return safe_json_dumps(data)
        except Exception as e:
            logger.debug("序列化失败，回退到 str()，错误: %s", str(e))
            return str(data)
    
    def deserialize(self, text: str) -> Optional[Dict[str, Any]]:
        """
        将 JSON 字符串反序列化为字典。
        
        参数:
            text: JSON 字符串。
        
        返回:
            反序列化后的字典，失败时返回 None。
        """
        try:
            return safe_json_loads(text)
        except Exception as e:
            logger.warning("反序列化失败: %s", str(e))
            return None
    
    def get_config(self, key: str, default: Any = None) -> Any:
        """
        获取配置项。
        
        参数:
            key: 配置键。
            default: 默认值。
        
        返回:
            配置值或默认值。
        """
        return self._config.get(key, default)
    
    def set_config(self, key: str, value: Any) -> None:
        """
        设置配置项。
        
        参数:
            key: 配置键。
            value: 配置值。
        """
        self._config[key] = value
    
    def to_dict(self) -> Dict[str, Any]:
        """
        导出处理器的完整状态为字典。
        
        返回:
            包含 name, version, state, stats, config 的字典。
        """
        return {
            'name': self.name,
            'version': self._version,
            'state': self._state,
            'stats': self.get_stats(),
            'config': dict(self._config)
        }


class RedTeamAgentExtProcessor_1(BaseRedTeamProcessor):
    """Red Team 扩展处理器 1，版本 1.0.1。"""
    _VERSION = "1.0.1"
    
    def __init__(self, name: str = 'redteamagentextprocessor_1', **kwargs: Any) -> None:
        """初始化 RedTeamAgentExtProcessor_1 实例。"""
        super().__init__(name, **kwargs)
        self._version = self._VERSION


class RedTeamAgentExtProcessor_2(BaseRedTeamProcessor):
    """Red Team 扩展处理器 2，版本 1.0.2。"""
    _VERSION = "1.0.2"
    
    def __init__(self, name: str = 'redteamagentextprocessor_2', **kwargs: Any) -> None:
        """初始化 RedTeamAgentExtProcessor_2 实例。"""
        super().__init__(name, **kwargs)
        self._version = self._VERSION


class RedTeamAgentExtProcessor_3(BaseRedTeamProcessor):
    """Red Team 扩展处理器 3，版本 1.0.3。"""
    _VERSION = "1.0.3"
    
    def __init__(self, name: str = 'redteamagentextprocessor_3', **kwargs: Any) -> None:
        """初始化 RedTeamAgentExtProcessor_3 实例。"""
        super().__init__(name, **kwargs)
        self._version = self._VERSION
