import logging
import time
from collections import OrderedDict
from threading import RLock, Timer
from typing import (
    Any,
    Dict,
    Generic,
    List,
    Optional,
    Tuple,
    TypeVar,
    FrozenSet,
    Iterator
)

T = TypeVar('T')

class BaseTTLStore(Generic[T]):
    """线程安全、支持TTL过期和LRU淘汰的通用有序字典存储基类。

    采用异步后台清理机制，通过细粒度锁实现并发安全，统计指标基于原子操作计算。
    支持动态调整清理间隔，提供细粒度过期管理。
    """

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        """初始化线程安全存储。

        Args:
            max_size: 最大容量，超过时触发LRU淘汰（必须>0）
            ttl: 数据过期时间（秒），超过时自动清理（必须>0）
        """
        if max_size <= 0:
            raise ValueError("max_size必须大于0")
        if ttl <= 0:
            raise ValueError("ttl必须大于0")

        self._store: OrderedDict[str, Tuple[T, float]] = OrderedDict()
        self._max_size = max_size
        self._ttl = ttl
        self._lock = RLock()
        self._cleanup_interval = ttl / 2.0
        self._stop_event = False
        self._cleanup_timer: Optional[Timer] = None
        self._hits = 0
        self._misses = 0
        self._evictions = 0
        self._total_writes = 0

        logger.info("BaseTTLStore初始化：max_size=%d, ttl=%.2f", max_size, ttl)
        self._start_background_cleanup()

    def _start_background_cleanup(self) -> None:
        """启动后台清理定时器，支持动态调整间隔"""
        def _cleanup_loop() -> None:
            if self._stop_event:
                return
            try:
                with self._lock:
                    removed = self._cleanupexpired()
                    if removed > 0:
                        logger.debug("后台清理移除%d过期条目", removed)
            except Exception as e:
                logger.error("清理异常: %s", e, exc_info=True)
            
            if not self._stop_event:
                self._cleanup_timer = Timer(self._cleanup_interval, _cleanup_loop)
                self._cleanup_timer.daemon = True
                self._cleanup_timer.start()

        self._stop_event = False
        self._cleanup_timer = Timer(self._cleanup_interval, _cleanup_loop)
        self._cleanup_timer.daemon = True
        self._cleanup_timer.start()

    def _cleanupexpired(self) -> int:
        """安全过期清理（需持有锁）"""
        now = time.time()
        expired = []
        for key, (_, ts) in self._store.items():
            if now - ts > self._ttl:
                expired.append(key)
        
        for key in expired:
            del self._store[key]
        return len(expired)

    def put(self, key: str, value: T) -> None:
        """安全写入数据，自动处理LRU淘汰"""
        with self._lock:
            self._store[key] = (value, time.time())
            self._store.move_to_end(key)
            self._total_writes += 1
            if len(self._store) > self._max_size:
                self._evictions += 1
                del self._store[next(iter(self._store.keys()))]
                logger.debug("LRU淘汰条目，当前淘汰总数：%d", self._evictions)

    def get(self, key: str, default: Optional[T] = None) -> T:
        """安全获取数据，自动更新访问状态"""
        with self._lock:
            if key not in self._store:
                self._misses += 1
                return default
            value, ts = self._store[key]
            if time.time() - ts > self._ttl:
                self._misses += 1
                return default
            self._hits += 1
            self._store.move_to_end(key)
            return value

    def remove(self, key: str) -> bool:
        """安全移除指定键"""
        with self._lock:
            if key in self._store:
                del self._store[key]
                return True
            return False

    def contains(self, key: str) -> bool:
        """安全检查键有效性"""
        with self._lock:
            if key not in self._store:
                return False
            _, ts = self._store[key]
            return time.time() - ts <= self._ttl

    def snapshot(self) -> Dict[str, T]:
        """获取当前有效数据快照"""
        with self._lock:
            now = time.time()
            return {
                k: v for k, (v, ts) in self._store.items() 
                if now - ts <= self._ttl
            }

    def keys(self) -> FrozenSet[str]:
        """获取当前有效键集合"""
        with self._lock:
            now = time.time()
            return frozenset(
                k for k, (_, ts) in self._store.items() 
                if now - ts <= self._ttl
            )

    def cleanup(self) -> int:
        """手动触发清理"""
        with self._lock:
            return self._cleanupexpired()

    def clear(self) -> None:
        """安全清空存储"""
        with self._lock:
            self._store.clear()
            self._hits = 0
            self._misses = 0
            self._evictions = 0
            self._total_writes = 0
            logger.info("存储已清空")

    def __len__(self) -> int:
        """返回当前存储条目数（含过期）"""
        with self._lock:
            return len(self._store)

    @property
    def stats(self) -> Dict[str, int]:
        """获取详细统计信息"""
        with self._lock:
            return {
                'hit_count': self._hits,
                'miss_count': self._misses,
                'eviction_count': self._evictions,
                'write_count': self._total_writes
            }

    @property
    def hit_rate(self) -> float:
        """计算命中率（原子安全）"""
        with self._lock:
            total = self._hits + self._misses
            return self._hits / total if total else 0.0

    def close(self) -> None:
        """安全关闭存储"""
        with self._lock:
            self._stop_event = True
            if self._cleanup_timer:
                self._cleanup_timer.cancel()
                self._cleanup_timer = None
            logger.info("存储已关闭")

    def __del__(self) -> None:
        """自动资源释放"""
        try:
            self.close()
        except Exception:
            logger.error("资源释放失败")

class MetricStore(BaseTTLStore[float]):
    """浮点型指标存储服务"""
    pass

class LogStore(BaseTTLStore[str]):
    """字符串型日志存储服务"""
    pass

class StateStore(BaseTTLStore[Dict[str, Any]]):
    """结构化状态存储服务"""
    pass

class QueueStore(BaseTTLStore[List[Any]]):
    """列表型队列存储服务"""
    pass

class TaskStore(BaseTTLStore[Any]):
    """通用任务存储服务"""
    pass
