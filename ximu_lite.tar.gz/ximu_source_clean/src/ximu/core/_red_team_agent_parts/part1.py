"""
Part 1 of the red team agent implementation.

提供核心数据结构、工具函数、存储类以及负载均衡策略。
包含通用工具函数（ID生成、时间戳、JSON序列化）、重试装饰器、
高精度计时器、线程安全的带TTL键值存储（Store），
以及负载平衡策略枚举，供红队代理模块的基础设施使用。
"""

import hashlib
import json
import logging
import os
import random
import threading
import time
import uuid
from collections import OrderedDict
from dataclasses import dataclass, field
from enum import Enum
from functools import wraps
from typing import Any, Dict, List, Optional, Tuple, TypeVar, Union

# 常量定义
LOCAL_WORKSPACE: str = os.environ.get('XIMU_WORKSPACE', './local_workspace')

# 类型变量
T = TypeVar('T')

# 日志记录器
logger = logging.getLogger("src.ximu.core._red_team_agent_parts.part1")
if not logger.handlers:
    logging.basicConfig(level=logging.INFO)


def generate_id(prefix: str = 'id') -> str:
    """
    生成带有指定前缀的唯一标识符。

    Args:
        prefix: 生成标识符的前缀字符串。

    Returns:
        格式为 'prefix_16位十六进制' 的唯一标识字符串。
    """
    try:
        return f"{prefix}_{uuid.uuid4().hex[:16]}"
    except Exception:
        logger.exception("生成唯一标识符失败")
        raise


def now_timestamp() -> float:
    """
    获取当前 Unix 时间戳（秒）。

    Returns:
        当前时间戳，浮点数类型。
    """
    return time.time()


def now_timestamp_ms() -> int:
    """
    获取当前 Unix 时间戳（毫秒）。

    Returns:
        当前时间戳，整数类型（毫秒）。
    """
    return int(time.time() * 1000)


def safe_json_dumps(o: Any, **kwargs: Any) -> str:
    """
    将对象安全地序列化为 JSON 字符串。

    Args:
        o: 要序列化的对象。
        **kwargs: 传递给 json.dumps 的其他参数。

    Returns:
        JSON 字符串表示。

    Raises:
        TypeError: 当对象无法序列化且 default 处理失败时。
    """
    kwargs.setdefault('ensure_ascii', False)
    kwargs.setdefault('default', str)
    try:
        return json.dumps(o, **kwargs)
    except Exception:
        logger.exception("JSON 序列化失败", extra={"type": type(o).__name__})
        raise


def safe_json_loads(s: Union[str, bytes, None], **kwargs: Any) -> Optional[Any]:
    """
    安全地反序列化 JSON 字符串。

    Args:
        s: 要解析的 JSON 字符串或字节序列。
        **kwargs: 传递给 json.loads 的其他参数。

    Returns:
        反序列化后的 Python 对象；解析失败返回 None。
    """
    if s is None:
        return None
    try:
        return json.loads(s, **kwargs)
    except (json.JSONDecodeError, TypeError, ValueError):
        logger.debug("JSON 反序列化失败，输入长度为: %d", len(s) if s else 0)
        return None


def retry_on_failure(max_retries: int = 3, delay: float = 0.1):
    """
    创建重试装饰器，在函数失败时进行指数退避重试。

    Args:
        max_retries: 最大重试次数。
        delay: 基础延迟时间（秒），实际延迟为 delay * 2^i。

    Returns:
        装饰器函数，接受可调用对象，返回包装后的可调用对象。

    Raises:
        最后一次的异常，若重试次数耗尽后仍失败。
    """
    def decorator(f: T) -> T:
        @wraps(f)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exception: Optional[Exception] = None
            for i in range(max_retries):
                try:
                    return f(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if i < max_retries - 1:
                        wait_time = delay * (2 ** i)
                        logger.warning(
                            "函数 %s 第 %d 次失败，%.2f 秒后重试: %s",
                            f.__name__, i + 1, wait_time, e
                        )
                        time.sleep(wait_time)
            if last_exception:
                logger.error("函数 %s 重试 %d 次后仍失败: %s",
                             f.__name__, max_retries, last_exception)
                raise last_exception
            return None
        return wrapper
    return decorator


@dataclass
class Stopwatch:
    """
    高精度计时器，用于测量代码执行时间。

    Attributes:
        _s: 起始单调时间戳。
        _e: 结束相对时间（秒）。
        _r: 是否正在运行。

    支持 start()、stop()、elapsed() 方法，可链式调用。
    """
    _s: float = field(default=0.0, repr=False)
    _e: float = field(default=0.0, repr=False)
    _r: bool = field(default=False, repr=False)

    def start(self) -> 'Stopwatch':
        """
        启动计时器。

        Returns:
            当前实例，支持方法链。
        """
        self._s = time.monotonic()
        self._r = True
        return self

    def stop(self) -> float:
        """
        停止计时器并返回累计耗时（秒）。

        如果计时器未在运行，直接返回已有累计时间。

        Returns:
            累计耗时（秒）。
        """
        if self._r:
            self._e += time.monotonic() - self._s
            self._r = False
        return self._e

    def elapsed(self) -> float:
        """
        获取当前已耗时（秒），实时计算正在运行的时间。

        Returns:
            累计已耗时（秒）。
        """
        base = self._e
        return base + (time.monotonic() - self._s if self._r else 0.0)


class LoadBalancingStrategy(Enum):
    """
    负载均衡策略枚举。

    定义多种常见的负载均衡算法，供代理调度使用。
    """
    ROUND_ROBIN = 'round_robin'
    RANDOM = 'random'
    WEIGHTED_RANDOM = 'weighted_random'
    LEAST_CONNECTIONS = 'least_connections'
    LEAST_LATENCY = 'least_latency'
    FASTEST_RESPONSE = 'fastest_response'
    HIGHEST_CAPACITY = 'highest_capacity'
    LOWEST_COST = 'lowest_cost'
    HIGHEST_QUALITY = 'highest_quality'
    MOST_RELIABLE = 'most_reliable'
    ADAPTIVE = 'adaptive'
    PRIORITY = 'priority'
    AFFINITY = 'affinity'
    CONSISTENT_HASH = 'consistent_hash'
    GEO_LOCATION = 'geo'
    LATENCY_AWARE = 'latency_aware'
    LOAD_BALANCED = 'load_balanced'
    FAILOVER = 'failover'
    BROADCAST = 'broadcast'
    SHARDING = 'sharding'


class Store:
    """
    线程安全的带 TTL 和容量限制的键值存储。

    基于 OrderedDict 实现 LRU 淘汰，支持 TTL 过期清理，
    内置命中率统计、最大容量控制，适用于缓存与临时数据。

    Attributes:
        _store: 内部有序字典，键映射到 (值, 时间戳)。
        _max_size: 最大条目数，超出后 LRU 淘汰最旧条目。
        _ttl: 条目存活时间（秒），超过 TTL 的条目视为过期。
        _lock: 可重入锁，保证线程安全。
        _hits: 缓存命中次数。
        _misses: 缓存未命中次数。
        _evictions: LRU 淘汰次数。
        _total_writes: 总写入次数。
    """

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        """
        初始化 Store。

        Args:
            max_size: 最大存储条目数，默认 10000。
            ttl: 条目生存时间（秒），默认 3600。
        """
        self._store: "OrderedDict[Any, Tuple[Any, float]]" = OrderedDict()
        self._max_size = max_size
        self._ttl = ttl
        self._lock = threading.RLock()
        self._hits = 0
        self._misses = 0
        self._evictions = 0
        self._total_writes = 0

    def _is_expired(self, ts: float) -> bool:
        """
        判断条目是否过期。

        Args:
            ts: 条目的写入时间戳。

        Returns:
            若当前时间 - 写入时间超过 TTL 则返回 True。
        """
        return (time.time() - ts) > self._ttl

    def _purge_expired_locked(self) -> int:
        """
        清理所有过期条目（调用方需持有锁）。

        Returns:
            被移除的过期条目数量。
        """
        now = time.time()
        expired_keys = [k for k, (_, ts) in self._store.items() if now - ts > self._ttl]
        for k in expired_keys:
            self._store.pop(k, None)
        return len(expired_keys)

    def put(self, key: Any, value: Any) -> None:
        """
        插入或更新键值对。

        若键已存在，更新其值并将键移至最新位置；
        若存储超过最大容量，LRU 淘汰最旧条目。

        Args:
            key: 键。
            value: 值。
        """
        with self._lock:
            self._store[key] = (value, time.time())
            self._store.move_to_end(key)
            self._total_writes += 1
            if len(self._store) > self._max_size:
                self._store.popitem(last=False)
                self._evictions += 1
                logger.debug("Store LRU 淘汰触发，当前大小: %d", len(self._store))

    def get(self, key: Any, default: Optional[Any] = None) -> Any:
        """
        按键获取值。

        若键不存在或已过期，返回默认值；命中时更新 LRU 顺序。

        Args:
            key: 要查找的键。
            default: 键不存在或过期时返回的默认值。

        Returns:
            键对应的值，或 default。
        """
        with self._lock:
            if key in self._store:
                value, ts = self._store[key]
                if not self._is_expired(ts):
                    self._store.move_to_end(key)
                    self._hits += 1
                    return value
                else:
                    del self._store[key]
            self._misses += 1
            return default

    def remove(self, key: Any) -> bool:
        """
        移除指定键。

        Args:
            key: 要移除的键。

        Returns:
            若键存在并被移除返回 True，否则 False。
        """
        with self._lock:
            return self._store.pop(key, None) is not None

    def contains(self, key: Any) -> bool:
        """
        检查键是否存在且未过期。

        若键已过期，会将其从存储中移除。

        Args:
            key: 要检查的键。

        Returns:
            键存在且有效返回 True，否则 False。
        """
        with self._lock:
            if key in self._store:
                _, ts = self._store[key]
                if not self._is_expired(ts):
                    return True
                else:
                    del self._store[key]
            return False

    def keys(self) -> List[Any]:
        """
        获取所有未过期的键列表。

        Returns:
            有效键的列表。
        """
        with self._lock:
            now = time.time()
            return [k for k, (_, ts) in self._store.items() if now - ts <= self._ttl]

    def values(self) -> List[Any]:
        """
        获取所有未过期的值列表。

        Returns:
            有效值的列表。
        """
        with self._lock:
            now = time.time()
            return [v for _, (v, ts) in self._store.items() if now - ts <= self._ttl]

    def items(self) -> List[Tuple[Any, Any]]:
        """
        获取所有未过期的键值对列表。

        Returns:
            (键, 值) 元组列表。
        """
        with self._lock:
            now = time.time()
            return [(k, v) for k, (v, ts) in self._store.items() if now - ts <= self._ttl]

    def cleanup(self) -> int:
        """
        主动清理所有过期条目。

        Returns:
            被移除的过期条目数量。
        """
        with self._lock:
            return self._purge_expired_locked()

    def clear(self) -> None:
        """
        清空所有条目。
        """
        with self._lock:
            self._store.clear()
            logger.debug("Store 已全部清空")

    def __len__(self) -> int:
        """
        获取当前条目总数（含过期条目）。

        Returns:
            存储中的总条目数。
        """
        with self._lock:
            return len(self._store)

    def __contains__(self, key: Any) -> bool:
        """
        检查键是否存在且未过期（支持 in 运算符）。

        Args:
            key: 要检查的键。

        Returns:
            键存在且有效返回 True。
        """
        return self.contains(key)

    @property
    def hit_rate(self) -> float:
        """
        获取缓存命中率。

        Returns:
            命中率，介于 0.0 到 1.0 之间；无访问记录时返回 0.0。
        """
        total = self._hits + self._misses
        return (self._hits / total) if total > 0 else 0.0

    @property
    def size(self) -> int:
        """
        获取当前条目总数。

        Returns:
            存储中的条目数量。
        """
        return len(self._store)

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """
        获取存储统计信息。

        Returns:
            包含 size、max_size、hits、misses、hit_rate、evictions、writes 的字典。
        """
        with self._lock:
            return {
                'size': len(self._store),
                'max_size': self._max_size,
                'hits': self._hits,
                'misses': self._misses,
                'hit_rate': self.hit_rate,
                'evictions': self._evictions,
                'writes': self._total_writes,
            }

    def to_dict(self) -> Dict[Any, Any]:
        """
        将存储内容转换为普通字典。

        不包含时间戳，仅保留键值对。

        Returns:
            键值字典。
        """
        with self._lock:
            return {k: v for k, (v, _) in self._store.items()}


# 以下类/函数在原始内容中被省略（标注为 "unchanged"），
# 为了保持公共 API 兼容性，此处保留占位声明。
# 实际部署时应完整实现。

# RequestStore, ResponseStore, SessionStore, ConfigStore, CacheStore, MetadataStore, EventStore
# 这些类继承自 Store 或组合 Store，保持 API 兼容。

class RequestStore(Store):
    """请求数据存储，继承自通用 Store。"""

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        super().__init__(max_size=max_size, ttl=ttl)


class ResponseStore(Store):
    """响应数据存储，继承自通用 Store。"""

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        super().__init__(max_size=max_size, ttl=ttl)


class SessionStore(Store):
    """会话数据存储，继承自通用 Store。"""

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        super().__init__(max_size=max_size, ttl=ttl)


class ConfigStore(Store):
    """配置数据存储，继承自通用 Store。"""

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        super().__init__(max_size=max_size, ttl=ttl)


class CacheStore(Store):
    """缓存数据存储，继承自通用 Store。"""

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        super().__init__(max_size=max_size, ttl=ttl)


class MetadataStore(Store):
    """元数据存储，继承自通用 Store。"""

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        super().__init__(max_size=max_size, ttl=ttl)


class EventStore(Store):
    """事件数据存储，继承自通用 Store。"""

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        super().__init__(max_size=max_size, ttl=ttl)
