"""Re-export hub for dag_scheduler (split into 3 parts, original 6911 lines).

Lazy re-export: parts are loaded on first attribute access (PEP 562),
not at import time, to keep cold start fast.
"""
import warnings as _w
_w.warn("dag_scheduler has been split, import from specific part", DeprecationWarning, stacklevel=2)

import importlib as _il
from typing import Any

_PARTS = ('part1', 'part2', 'part3', 'part4', 'part5')
_cache = None

def _load() -> dict[str, Any]:
    """Load parts once and cache public names; idempotent."""
    global _cache
    if _cache is not None:
        return _cache
    cache = {}
    for _n in _PARTS:
        try:
            _m = _il.import_module("._dag_scheduler_parts." + _n, package=__package__)
            for _x in dir(_m):
                if not _x.startswith("_"):
                    cache[_x] = getattr(_m, _x)
        except Exception as _e:
            import logging as _logging
            _logging.warning(f"Re-export {__name__}.{_n} failed: {_e}")
    _cache = cache
    return _cache

def __getattr__(name: str) -> Any:
    """PEP 562: defer part loading until a public name is actually requested."""
    if name.startswith("_"):
        raise AttributeError(name)
    cache = _load()
    try:
        return cache[name]
    except KeyError:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from None
