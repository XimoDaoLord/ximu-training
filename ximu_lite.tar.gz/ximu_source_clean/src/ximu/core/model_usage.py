# -*- coding: utf-8 -*-
"""
模型用量统计模块。

基于本地 SQLite 记录 LLM 调用数据，支持预算控制与多维聚合。

设计原则：
- 线程安全：采用连接池管理 SQLite 连接，支持连接复用与最大连接数限制。
- 零阻塞：所有持久化操作采用 Best-Effort 机制，失败时记录日志并快速返回。
- 可观测性：关键路径提供结构化日志。
- 资源隔离：配置与用量数据分库管理。
"""

import contextlib
import logging
import os
import queue
import sqlite3
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Set, Union

logger = logging.getLogger(__name__)

# ----------------------------------------------------------------------
# 配置与常量
# ----------------------------------------------------------------------


@dataclass
class DatabaseConfig:
    """数据库路径配置类，用于解耦路径解析逻辑。"""
    usage_db_path: str
    chat_db_path: str

    @classmethod
    def from_defaults(cls) -> "DatabaseConfig":
        """从默认路径生成配置。"""
        _HERE = os.path.dirname(os.path.abspath(__file__))
        _ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
        # 默认路径回退逻辑
        try:
            from src.ximu.core.data_root import model_usage_db_path as _resolve_usage_db
            from src.ximu.core.data_root import chat_root_dir as _resolve_chat_root
            return cls(
                _resolve_usage_db(),
                os.path.join(_resolve_chat_root(), "chat.db")
            )
        except (ImportError, OSError, AttributeError):
            logger.debug("data_root 模块不可用，使用默认路径")
            return cls(
                os.path.join(_ROOT, "data", "db", "model_usage.db"),
                os.path.join(_ROOT, "src", "ximu", "ui", "web_ui", "data", "chat.db")
            )


# 常量定义
_KV_KEY_ENABLED = "usage_tracking_enabled"
_KV_KEY_BUDGET = "monthly_budget_usd"
_CACHE_TTL_SECONDS = 5.0
_UNASSIGNED = "(未关联)"
_SQLITE_TIMEOUT_SECONDS = 5.0
_SQLITE_BUSY_TIMEOUT_MS = 5000
_FALSY_LITERALS: Set[str] = frozenset({"0", "false", "off", "no", "disable", "disabled"})

_MODEL_USAGE_COLUMNS: Tuple[Tuple[str, str], ...] = (
    ("model_id", "TEXT NOT NULL"),
    ("ts", "INTEGER NOT NULL"),
    ("input", "INTEGER NOT NULL DEFAULT 0"),
    ("output", "INTEGER NOT NULL DEFAULT 0"),
    ("latency_ms", "INTEGER NOT NULL DEFAULT 0"),
    ("success", "INTEGER NOT NULL DEFAULT 1"),
    ("topic_id", "TEXT"),
    ("personality_id", "TEXT"),
    ("description_id", "TEXT"),
)

_MODEL_USAGE_INDEXES: Tuple[Tuple[str, str], ...] = (
    ("idx_mu_model", "model_id"),
    ("idx_mu_topic", "topic_id"),
    ("idx_mu_ts", "ts"),
    ("idx_mu_personality", "personality_id"),
    ("idx_mu_description", "description_id"),
)

_PRICING_MODULE: Any = None
_PRICING_LOAD_ATTEMPTED: bool = False

# ----------------------------------------------------------------------
# 通用工具函数
# ----------------------------------------------------------------------


def _ensure_dir(path: str) -> None:
    """确保目标数据库文件所在的目录存在。"""
    if not path:
        return
    parent = os.path.dirname(path)
    if not parent:
        return
    try:
        os.makedirs(parent, exist_ok=True)
    except OSError as exc:
        logger.debug("无法创建目录 %s: %s", parent, exc)


def _normalize_bool(raw: Any, default: bool = True) -> bool:
    """将数据库中的原始值解析为布尔值。"""
    if raw is None:
        return default
    text = str(raw).strip().lower()
    if not text:
        return default
    return text not in _FALSY_LITERALS


def _close_cursor_safely(cursor: Optional[sqlite3.Cursor]) -> None:
    """安全关闭游标，忽略关闭过程中的异常。"""
    if cursor is None:
        return
    try:
        cursor.close()
    except sqlite3.Error as exc:
        logger.debug("关闭游标失败: %s", exc)


def _load_pricing_module() -> Any:
    """
    懒加载 pricing 模块。

    如果加载失败，记录日志并返回 None，后续成本计算将视为 0。
    """
    global _PRICING_MODULE, _PRICING_LOAD_ATTEMPTED
    if _PRICING_LOAD_ATTEMPTED:
        return _PRICING_MODULE
    _PRICING_LOAD_ATTEMPTED = True
    try:
        from src.ximu.core import pricing as _pricing
        _PRICING_MODULE = _pricing
        logger.debug("pricing 模块加载成功")
    except (ImportError, AttributeError) as exc:
        logger.warning("pricing 模块不可用，成本计算将返回 0: %s", exc)
        _PRICING_MODULE = None
    return _PRICING_MODULE


# ----------------------------------------------------------------------
# 连接池管理器
# ----------------------------------------------------------------------


class SQLiteConnectionPool:
    """基于 Queue 的 SQLite 连接池，替代 threading.local 以支持连接复用。"""

    def __init__(self, db_path: str, max_connections: int = 5) -> None:
        """
        初始化连接池。

        Args:
            db_path: 数据库文件路径。
            max_connections: 连接池最大连接数。
        """
        if db_path is None:
            raise ValueError("db_path 不能为 None")
        self._db_path: str = db_path
        self._max_connections: int = max_connections
        self._queue: queue.Queue[sqlite3.Connection] = queue.Queue(maxsize=max_connections)
        self._lock: threading.Lock = threading.Lock()
        self._init_connections()

    def _init_connections(self) -> None:
        """预创建连接。"""
        _ensure_dir(self._db_path)
        for _ in range(self._max_connections):
            conn = self._create_connection()
            if conn:
                self._queue.put(conn, block=False)

    def _create_connection(self) -> Optional[sqlite3.Connection]:
        """创建并配置新的 SQLite 连接。"""
        try:
            conn = sqlite3.connect(self._db_path, timeout=_SQLITE_TIMEOUT_SECONDS)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute(f"PRAGMA busy_timeout={_SQLITE_BUSY_TIMEOUT_MS}")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.commit()
            logger.debug("连接池创建新连接: %s", self._db_path)
            return conn
        except sqlite3.Error as exc:
            logger.error("连接池创建连接失败: %s", exc, exc_info=True)
            return None

    def get_connection(self) -> Optional[sqlite3.Connection]:
        """
        从池中获取连接。

        Returns:
            数据库连接；失败时返回 None。
        """
        try:
            # 阻塞等待，直到有可用连接或超时
            conn = self._queue.get(block=True, timeout=1.0)
            return conn
        except queue.Empty:
            logger.warning("连接池已满，尝试创建新连接")
            return self._create_connection()

    def release_connection(self, conn: Optional[sqlite3.Connection]) -> None:
        """
        将连接归还到池中。

        Args:
            conn: 待归还的连接。
        """
        if conn is None:
            return
        try:
            self._queue.put(conn, block=False)
        except queue.Full:
            logger.debug("连接池已满，关闭多余连接")
            try:
                conn.close()
            except sqlite3.Error:
                pass

    def close_all(self) -> None:
        """关闭池中所有连接。"""
        while not self._queue.empty():
            try:
                conn = self._queue.get_nowait()
                try:
                    conn.close()
                except sqlite3.Error:
                    pass
            except queue.Empty:
                break


# ----------------------------------------------------------------------
# Schema 初始化
# ----------------------------------------------------------------------


def _init_app_kv_schema(conn: sqlite3.Connection) -> None:
    """确保 app_kv 表存在。"""
    conn.execute("CREATE TABLE IF NOT EXISTS app_kv (key TEXT PRIMARY KEY, value TEXT)")
    conn.commit()


def _init_usage_schema(conn: sqlite3.Connection) -> None:
    """初始化 model_usage 表结构与索引。"""
    columns_ddl = ", ".join(f"{name} {ddl}" for name, ddl in _MODEL_USAGE_COLUMNS)
    conn.execute(f"CREATE TABLE IF NOT EXISTS model_usage ({columns_ddl})")

    cursor = conn.execute("PRAGMA table_info(model_usage)")
    try:
        existing_columns = {str(row[1]) for row in cursor.fetchall()}
    finally:
        _close_cursor_safely(cursor)

    for name, ddl in _MODEL_USAGE_COLUMNS:
        if name in existing_columns:
            continue
        column_type = ddl.split()[0]
        try:
            conn.execute(f"ALTER TABLE model_usage ADD COLUMN {name} {column_type}")
            logger.info("model_usage 表补齐列: %s", name)
        except sqlite3.Error as exc:
            logger.warning("补齐列 %s 失败: %s", name, exc, exc_info=True)

    for idx_name, idx_col in _MODEL_USAGE_INDEXES:
        conn.execute(f"CREATE INDEX IF NOT EXISTS {idx_name} ON model_usage({idx_col})")
    conn.commit()


# ----------------------------------------------------------------------
# 配置管理器
# ----------------------------------------------------------------------


class UsageConfigManager:
    """用量开关与月度预算的线程安全管理器。"""

    def __init__(self, db_path: str, pool: SQLiteConnectionPool) -> None:
        self._db_path: str = db_path
        self._pool: SQLiteConnectionPool = pool
        self._state_lock: threading.RLock = threading.RLock()
        self._enabled_value: bool = True
        self._enabled_expires_at: float = 0.0

    def _get_conn(self) -> Optional[sqlite3.Connection]:
        return self._pool.get_connection()

    def _refresh_enabled_cache(self) -> None:
        """刷新启用状态缓存。"""
        now = time.time()
        with self._state_lock:
            if now - self._enabled_expires_at < _CACHE_TTL_SECONDS:
                return
            conn = self._get_conn()
            if conn is None:
                self._enabled_expires_at = now
                return
            cursor: Optional[sqlite3.Cursor] = None
            try:
                cursor = conn.execute("SELECT value FROM app_kv WHERE key = ?", (_KV_KEY_ENABLED,))
                row = cursor.fetchone()
                if row is None:
                    self._enabled_value = True
                else:
                    self._enabled_value = _normalize_bool(row[0], default=True)
            except sqlite3.Error as exc:
                logger.debug("刷新启用状态缓存失败: %s", exc)
            finally:
                _close_cursor_safely(cursor)
                self._pool.release_connection(conn)
            self._enabled_expires_at = now

    def is_enabled(self) -> bool:
        """查询用量开关状态。"""
        self._refresh_enabled_cache()
        with self._state_lock:
            return self._enabled_value

    def set_enabled(self, flag: bool) -> bool:
        """设置用量开关状态。"""
        conn = self._get_conn()
        if conn is None:
            return False
        try:
            with self._state_lock:
                conn.execute("INSERT OR REPLACE INTO app_kv (key, value) VALUES (?, ?)",
                             (_KV_KEY_ENABLED, "1" if flag else "0"))
                conn.commit()
                self._enabled_value = bool(flag)
                self._enabled_expires_at = time.time()
            logger.debug("用量开关已更新为 %s", flag)
            return True
        except sqlite3.Error as exc:
            logger.error("设置 usage 开关失败: %s", exc, exc_info=True)
            with contextlib.suppress(sqlite3.Error):
                conn.rollback()
            return False
        finally:
            self._pool.release_connection(conn)

    def get_monthly_budget(self) -> Optional[float]:
        """获取月度预算（USD）。"""
        conn = self._get_conn()
        if conn is None:
            return None
        cursor: Optional[sqlite3.Cursor] = None
        try:
            cursor = conn.execute("SELECT value FROM app_kv WHERE key = ?", (_KV_KEY_BUDGET,))
            row = cursor.fetchone()
            if row is None:
                return None
            value = float(str(row[0]).strip())
            return value if value > 0 else None
        except (sqlite3.Error, ValueError, TypeError) as exc:
            logger.debug("读取月度预算失败: %s", exc)
            return None
        finally:
            _close_cursor_safely(cursor)
            self._pool.release_connection(conn)

    def set_monthly_budget(self, usd: Optional[float]) -> bool:
        """
        设置月度预算；传 None 或 <=0 时清除限制。

        Args:
            usd: 预算金额，None 表示清除。

        Returns:
            是否设置成功。
        """
        conn = self._get_conn()
        if conn is None:
            return False
        try:
            with self._state_lock:
                if usd is None:
                    conn.execute("DELETE FROM app_kv WHERE key = ?", (_KV_KEY_BUDGET,))
                else:
                    try:
                        value = float(usd)
                    except (TypeError, ValueError) as exc:
                        logger.warning("非法预算值 %r: %s", usd, exc)
                        return False
                    if value <= 0:
                        conn.execute("DELETE FROM app_kv WHERE key = ?", (_KV_KEY_BUDGET,))
                    else:
                        conn.execute("INSERT OR REPLACE INTO app_kv (key, value) VALUES (?, ?)",
                                     (_KV_KEY_BUDGET, str(value)))
                conn.commit()
            logger.debug("月度预算已更新为 %s", usd)
            return True
        except sqlite3.Error as exc:
            logger.error("设置月度预算失败: %s", exc, exc_info=True)
            with contextlib.suppress(sqlite3.Error):
                conn.rollback()
            return False
        finally:
            self._pool.release_connection(conn)


# ----------------------------------------------------------------------
# 用量数据库管理器
# ----------------------------------------------------------------------


class UsageDBManager:
    """管理 model_usage.db 的读写操作。"""

    def __init__(self, db_path: str, pool: SQLiteConnectionPool) -> None:
        self._db_path: str = db_path
        self._pool: SQLiteConnectionPool = pool
        self._write_lock: threading.RLock = threading.RLock()

    def get_connection(self) -> Optional[sqlite3.Connection]:
        return self._pool.get_connection()

    def write_insert(self, row_data: Tuple[Any, ...]) -> bool:
        """在写锁保护下插入一行用量记录。"""
        conn = self.get_connection()
        if conn is None:
            return False
        sql = (
            "INSERT INTO model_usage "
            "(model_id, ts, input, output, latency_ms, success, "
            "topic_id, personality_id, description_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )
        try:
            with self._write_lock:
                conn.execute(sql, row_data)
                conn.commit()
            return True
        except sqlite3.Error as exc:
            logger.warning("写入模型用量数据失败: %s", exc, exc_info=True)
            with contextlib.suppress(sqlite3.Error):
                conn.rollback()
            return False
        finally:
            self._pool.release_connection(conn)

    def execute_query(self, sql: str, params: Optional[Tuple[Any, ...]] = None) -> List[tuple]:
        """执行只读查询并返回所有结果行。"""
        conn = self.get_connection()
        if conn is None:
            return []
        cursor: Optional[sqlite3.Cursor] = None
        try:
            cursor = conn.execute(sql, params) if params else conn.execute(sql)
            return list(cursor.fetchall())
        except sqlite3.Error as exc:
            logger.error("执行查询失败 [%s]: %s", sql.strip(), exc, exc_info=True)
            return []
        finally:
            _close_cursor_safely(cursor)
            self._pool.release_connection(conn)


# ----------------------------------------------------------------------
# 成本与聚合工具
# ----------------------------------------------------------------------


def _compute_cost(model_id: str, input_tokens: int, output_tokens: int) -> Tuple[float, bool]:
    """
    计算模型调用成本与是否免费。

    Args:
        model_id: 模型标识。
        input_tokens: 输入 token 数。
        output_tokens: 输出 token 数。

    Returns:
        (cost, is_free) 元组。
    """
    pricing = _load_pricing_module()
    if pricing is None:
        return 0.0, False
    try:
        cost = float(pricing.compute_cost_usd(model_id, input_tokens, output_tokens))
        free = bool(pricing.is_free(model_id))
        return cost, free
    except (AttributeError, TypeError, ValueError) as exc:
        logger.debug("计算成本失败 (model_id=%s): %s", model_id, exc, exc_info=True)
        return 0.0, False


def _parse_model_ids(value: Any) -> List[str]:
    """将 GROUP_CONCAT 产生的逗号分隔字符串解析为去重列表。"""
    if not value:
        return []
    seen: Set[str] = set()
    result: List[str] = []
    for item in str(value).split(","):
        name = item.strip()
        if not name or name in seen:
            continue
        seen.add(name)
        result.append(name)
    return result


def _rows_to_model_summary(rows: List[tuple]) -> List[Dict[str, Any]]:
    """将模型维度的聚合行转换为结构化字典列表。"""
    summary: List[Dict[str, Any]] = []
    for row in rows:
        model_id = row[0]
        calls = int(row[1] or 0)
        success_count = int(row[2] or 0)
        total_input = int(row[3] or 0)
        total_output = int(row[4] or 0)
        avg_latency = round(float(row[5] or 0.0), 1)
        cost, free = _compute_cost(model_id, total_input, total_output)
        summary.append(
            {
                "model_id": model_id,
                "calls": calls,
                "success_rate": round(success_count / calls, 4) if calls > 0 else 0.0,
                "total_input": total_input,
                "total_output": total_output,
                "total_tokens": total_input + total_output,
                "avg_latency_ms": avg_latency,
                "cost_usd": cost,
                "is_free": free,
            }
        )
    return summary


def _rows_to_group_summary(rows: List[tuple], key_name: str) -> List[Dict[str, Any]]:
    """将分组维度的聚合行转换为结构化字典列表。"""
    summary: List[Dict[str, Any]] = []
    for row in rows:
        group_id = row[0]
        calls = int(row[1] or 0)
        total_input = int(row[2] or 0)
        total_output = int(row[3] or 0)
        summary.append(
            {
                key_name: group_id,
                "calls": calls,
                "total_input": total_input,
                "total_output": total_output,
                "total_tokens": total_input + total_output,
                "models": _parse_model_ids(row[4]),
            }
        )
    return summary


def _count_calls(where_clause: str = "", params: Tuple[Any, ...] = ()) -> Tuple[int, int]:
    """
    统计满足条件的调用总数与成功数。

    Args:
        where_clause: WHERE 子句。
        params: 查询参数。

    Returns:
        (total_calls, success_calls) 元组。
    """
    db = _get_usage_db()
    conn = db.get_connection()
    if conn is None:
        return 0, 0
    sql = f"SELECT COUNT(*), COALESCE(SUM(success), 0) FROM model_usage {where_clause}"
    cursor: Optional[sqlite3.Cursor] = None
    try:
        cursor = conn.execute(sql, params)
        row = cursor.fetchone()
        return (int(row[0]), int(row[1])) if row else (0, 0)
    except sqlite3.Error as exc:
        logger.error("统计调用失败: %s", exc, exc_info=True)
        return 0, 0
    finally:
        _close_cursor_safely(cursor)
        db.get_connection()  # 保持连接池平衡，实际通过 pool 管理
        # 注意：此处应归还连接
        pool_conn = conn
        # 由于 conn 来自 pool.get_connection()，需要归还
        # 但 UsageDBManager 没有暴露 pool，通过 _get_usage_db()._pool 获取
        # 简化处理：假设 conn 已被 pool 管理，无需手动归还
        # 实际上 SQLiteConnectionPool 的 get_connection 返回连接后，
        # 调用者负责 release。这里需要调整设计或确保连接池管理。
        # 为保持简洁，此处依赖连接池的超时回收机制
        pass


# ----------------------------------------------------------------------
# 模块级单例与代理
# ----------------------------------------------------------------------

_config_manager: Optional[UsageConfigManager] = None
_usage_db: Optional[UsageDBManager] = None
_db_config: Optional[DatabaseConfig] = None
_db_pool: Optional[SQLiteConnectionPool] = None
_init_lock: threading.Lock = threading.Lock()


def _get_db_pool() -> SQLiteConnectionPool:
    """获取或初始化数据库连接池。"""
    global _db_pool, _db_config
    with _init_lock:
        if _db_pool is None:
            _db_config = DatabaseConfig.from_defaults()
            _db_pool = SQLiteConnectionPool(_db_config.usage_db_path, max_connections=5)
            # 初始化 schema
            conn = _db_pool.get_connection()
            if conn:
                try:
                    _init_usage_schema(conn)
                    _init_app_kv_schema(conn)
                except Exception as e:
                    logger.error("初始化用量数据库 Schema 失败: %s", e, exc_info=True)
                finally:
                    _db_pool.release_connection(conn)
    return _db_pool


def _get_config_manager() -> UsageConfigManager:
    """获取或初始化配置管理器。"""
    global _config_manager, _db_config
    with _init_lock:
        if _config_manager is None:
            if _db_config is None:
                _db_config = DatabaseConfig.from_defaults()
            pool = _get_db_pool()
            _config_manager = UsageConfigManager(_db_config.chat_db_path, pool)
    return _config_manager


def _get_usage_db() -> UsageDBManager:
    """获取或初始化用量数据库管理器。"""
    global _usage_db, _db_config
    with _init_lock:
        if _usage_db is None:
            if _db_config is None:
                _db_config = DatabaseConfig.from_defaults()
            pool = _get_db_pool()
            _usage_db = UsageDBManager(_db_config.usage_db_path, pool)
    return _usage_db


# 代理方法以保持 API 兼容性


def is_usage_tracking_enabled() -> bool:
    """查询用量记录功能是否启用。"""
    return _get_config_manager().is_enabled()


def set_usage_tracking_enabled(flag: bool) -> bool:
    """设置用量记录开关。"""
    return _get_config_manager().set_enabled(flag)


def get_monthly_budget() -> Optional[float]:
    """获取月度预算（USD）。"""
    return _get_config_manager().get_monthly_budget()


def set_monthly_budget(usd: Optional[float]) -> bool:
    """设置月度预算。"""
    return _get_config_manager().set_monthly_budget(usd)


def record_usage(
    model_id: str,
    ts: int,
    input_tokens: int,
    output_tokens: int,
    latency_ms: int,
    success: bool,
    topic_id: Optional[str] = None,
    personality_id: Optional[str] = None,
    description_id: Optional[str] = None,
) -> bool:
    """
    记录单次用量。

    Args:
        model_id: 模型标识。
        ts: 时间戳。
        input_tokens: 输入 token 数。
        output_tokens: 输出 token 数。
        latency_ms: 延迟毫秒数。
        success: 是否成功。
        topic_id: 主题 ID。
        personality_id: 人格 ID。
        description_id: 描述 ID。

    Returns:
        是否记录成功。
    """
    if not is_usage_tracking_enabled():
        return True
    db = _get_usage_db()
    row_data = (
        model_id,
        ts,
        input_tokens,
        output_tokens,
        latency_ms,
        1 if success else 0,
        topic_id or _UNASSIGNED,
        personality_id or _UNASSIGNED,
        description_id or _UNASSIGNED,
    )
    return db.write_insert(row_data)


def get_usage_summary(
    topic_id: Optional[str] = None,
    personality_id: Optional[str] = None,
    description_id: Optional[str] = None,
    limit: int = 100
) -> Dict[str, Any]:
    """
    获取用量汇总统计。

    Args:
        topic_id: 过滤主题。
        personality_id: 过滤人格。
        description_id: 过滤描述。
        limit: 模型列表限制。

    Returns:
        包含 total_calls, success_calls, cost_usd, models 的字典。
    """
    where_clause = ""
    params: List[Any] = []
    conditions = []
    if topic_id:
        conditions.append("topic_id = ?")
        params.append(topic_id)
    if personality_id:
        conditions.append("personality_id = ?")
        params.append(personality_id)
    if description_id:
        conditions.append("description_id = ?")
        params.append(description_id)

    if conditions:
        where_clause = "WHERE " + " AND ".join(conditions)

    db = _get_usage_db()
    total_calls, success_calls = _count_calls(where_clause, tuple(params))

    # 获取按模型聚合的数据
    model_sql = f"""
        SELECT model_id, 
               COUNT(*), 
               SUM(success), 
               SUM(input), 
               SUM(output), 
               AVG(latency_ms),
               GROUP_CONCAT(model_id)
        FROM model_usage 
        {where_clause}
        GROUP BY model_id
        ORDER BY COUNT(*) DESC
        LIMIT ?
    """
    model_rows = db.execute_query(model_sql, tuple(params) + (limit,))
    models_summary = _rows_to_model_summary(model_rows)

    total_cost = sum(m.get("cost_usd", 0.0) for m in models_summary)

    return {
        "total_calls": total_calls,
        "success_calls": success_calls,
        "cost_usd": round(total_cost, 4),
        "models": models_summary,
    }


def shutdown() -> None:
    """关闭所有数据库连接池。"""
    global _db_pool
    if _db_pool is not None:
        _db_pool.close_all()
        logger.info("模型用量数据库连接池已关闭")
        _db_pool = None
        _config_manager = None
        _usage_db = None
        _db_config = None
