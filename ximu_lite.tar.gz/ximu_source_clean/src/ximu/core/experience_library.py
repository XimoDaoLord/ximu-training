"""
汐沫AI · 经验库 (Experience Library) - 阶段19
模块定位: 存储和管理任务执行经验，支持经验检索、复用、更新。
设计意图: 通过白名单校验、相似度去重和严格门槛过滤，确保经验库中只包含高质量、可复用的结构化教训。
核心功能: 基于标签相似度的任务经验存储、去重合并与结构化教训入库功能。
"""

import json
import logging
import os
import re
import time
import threading
import uuid
from typing import Optional, Dict, List, Any, Tuple, Set, Union
from enum import Enum
from dataclasses import dataclass, field, asdict
from collections import defaultdict

class ExperienceType(Enum):
    """经验类型枚举"""
    TASK_SUCCESS = "task_success"
    TASK_FAILURE = "task_failure"
    PATTERN_RECOGNIZED = "pattern_recognized"
    OPTIMIZATION_FOUND = "optimization_found"
    BEST_PRACTICE = "best_practice"

class ExperienceSource(Enum):
    """经验来源枚举"""
    SELF_EXPERIENCE = "self_experience"
    CORPUS = "corpus"  # G-07: 个人语料库
    FEEDBACK = "feedback"
    ANALYSIS = "analysis"

@dataclass
class Experience:
    """
    经验条目数据类。
    
    包含基础信息、状态指标以及 P57 引入的结构化教训字段。
    所有结构化字段均有默认值，确保旧数据兼容性。
    """
    experience_id: str
    experience_type: ExperienceType
    source: ExperienceSource
    content: Any
    context: Dict[str, Any]
    success_score: float = 1.0  # 0-1
    usage_count: int = 0
    last_used: Optional[float] = None
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    is_active: bool = True
    
    # P57：结构化教训字段
    outcome: Optional[str] = None       # "success" / "failure"
    root_cause: str = ""                # 根因分析
    avoid_hint: str = ""                # 下次如何避免
    lesson_type: str = ""               # coding/debug/design/communication/test/deploy/general
    verified: bool = False              # 人工确认或满足质量门槛

    def to_dict(self) -> Dict[str, Any]:
        """将 Experience 对象转换为字典，用于序列化"""
        data = asdict(self)
        data["experience_type"] = self.experience_type.value
        data["source"] = self.source.value
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Experience":
        """从字典恢复 Experience 对象，处理枚举反序列化"""
        exp_data = dict(data)
        if "experience_type" in exp_data:
            exp_data["experience_type"] = ExperienceType(exp_data["experience_type"])
        if "source" in exp_data:
            exp_data["source"] = ExperienceSource(exp_data["source"])
        
        # 过滤掉不存在的字段，保持兼容性
        valid_keys = {k: v for k, v in exp_data.items() if k in cls.__dataclass_fields__}
        return cls(**valid_keys)

class ExperienceQuery:
    """经验查询条件数据类"""
    experience_type: Optional[ExperienceType] = None
    source: Optional[ExperienceSource] = None
    tags: List[str] = field(default_factory=list)
    min_score: float = 0.0
    max_age_seconds: int = -1  # 统一为秒
    limit: int = 10

    def __post_init__(self):
        self.tags = list(set(self.tags))  # 去重优化

class ExperienceRepository:
    """
    经验持久化仓库。
    负责将经验库状态保存至本地文件系统，并从文件加载状态。
    封装 JSON 序列化/反序列化逻辑，提高模块内聚性。
    """

    def __init__(self, file_path: str):
        self._file_path = file_path
        self._logger = logging.getLogger(__name__)
        self._lock = threading.RLock()

    def save(self, experiences: Dict[str, Experience]) -> bool:
        """
        保存经验字典到本地文件。
        
        Args:
            experiences: 经验 ID 到 Experience 对象的映射
            
        Returns:
            bool: 是否保存成功
        """
        if not self._file_path:
            return True  # 未配置路径时跳过持久化

        try:
            # 准备目录
            dir_name = os.path.dirname(self._file_path)
            if dir_name and not os.path.exists(dir_name):
                os.makedirs(dir_name, exist_ok=True)

            serializable_data: Dict[str, Any] = {}
            for exp_id, exp_obj in experiences.items():
                serializable_data[exp_id] = exp_obj.to_dict()

            # 优化IO操作
            with open(self._file_path, 'w', encoding='utf-8') as f:
                json.dump(serializable_data, f, ensure_ascii=False, indent=2)

            self._logger.debug(f"Experience repository saved to {self._file_path}")
            return True

        except (OSError, TypeError, json.JSONDecodeError) as e:
            self._logger.error(f"Failed to save experience repository: {e}")
            return False

    def load(self) -> Dict[str, Experience]:
        """
        从本地文件加载经验。
        
        Returns:
            Dict[str, Experience]: 加载的经验数据
        """
        if not self._file_path or not os.path.exists(self._file_path):
            return {}

        try:
            with self._lock:
                data = json.load(open(self._file_path, 'r', encoding='utf-8'))

            experiences = {}
            for exp_id, exp_dict in data.items():
                try:
                    experiences[exp_id] = Experience.from_dict(exp_dict)
                except (ValueError, KeyError, AttributeError) as e:
                    self._logger.warning(f"Skipping invalid experience entry {exp_id}: {e}")

            self._logger.debug(f"Loaded {len(experiences)} experiences from repository")
            return experiences

        except (OSError, json.JSONDecodeError) as e:
            self._logger.error(f"Failed to load experience repository: {e}")
            return {}

class ExperienceLibrary:
    """
    经验库核心类。
    
    提供基于标签相似度的任务经验存储、去重合并、结构化教训入库功能。
    支持本地持久化与并发安全访问。
    """

    # P57: 允许的 outcome / lesson_type 白名单
    _ALLOWED_OUTCOMES = ("success", "failure")
    _ALLOWED_LESSON_TYPES = ("coding", "debug", "design", "communication", "test", "deploy", "general")
    _SIMILARITY_THRESHOLD = 0.8
    _MIN_LESSON_TEXT_LEN = 5
    _MAX_CONTENT_LEN = 500

    def __init__(self, config: Optional[Dict] = None):
        self._config = config or {}
        self._logger = logging.getLogger(__name__)
        
        # 并发控制
        self._lock = threading.RLock()
        
        # 核心存储
        self._experiences: Dict[str, Experience] = {}
        
        # 索引结构
        self._type_index: Dict[ExperienceType, List[str]] = {}
        self._source_index: Dict[ExperienceSource, List[str]] = {}
        self._tag_index: Dict[str, List[str]] = {}  # 使用有序列表保持顺序
        
        # 统计信息
        self._stats = {
            "experiences_stored": 0,
            "experiences_used": 0,
            "query_count": 0,
            "query_hits": 0,
            "corpus_experiences": 0
        }
        
        # G-07: 语料库白名单
        self._corpus_whitelist: Set[str] = set()
        self._load_corpus_whitelist()
        
        # 持久化仓库
        data_file = self._config.get("data_file", "")
        self._repository = ExperienceRepository(data_file)
        
        # 加载本地数据
        self._load_local_data()
        
        self._logger.info("ExperienceLibrary initialized")

    def _load_corpus_whitelist(self) -> None:
        """加载语料库白名单配置（若存在）"""
        whitelist_config = self._config.get("corpus_whitelist", [])
        if isinstance(whitelist_config, list):
            self._corpus_whitelist.update(whitelist_config)

    def _load_local_data(self) -> None:
        """从本地仓库加载历史经验数据并重建索引"""
        data = self._repository.load()
        with self._lock:
            for exp_id, exp in data.items():
                self._experiences[exp_id] = exp
                self._update_indices(exp_id, exp, new_entry=True)
            # 重建语料库白名单
            for exp in self._experiences.values():
                if exp.source == ExperienceSource.CORPUS:
                    self._corpus_whitelist.add(exp.experience_id)
                    self._stats["corpus_experiences"] += 1

    def _update_indices(self, exp_id: str, exp: Experience, new_entry: bool = False) -> None:
        """更新类型、来源和标签索引"""
        # 类型索引
        if new_entry:
            if exp.experience_type not in self._type_index:
                self._type_index[exp.experience_type] = []
            if exp_id not in self._type_index[exp.experience_type]:
                self._type_index[exp.experience_type].append(exp_id)
        
        # 来源索引
        if new_entry:
            if exp.source not in self._source_index:
                self._source_index[exp.source] = []
            if exp_id not in self._source_index[exp.source]:
                self._source_index[exp.source].append(exp_id)
        
        # 标签索引 (有序列表)
        for tag in exp.tags:
            if tag not in self._tag_index:
                self._tag_index[tag] = []
            if exp_id not in self._tag_index[tag]:
                self._tag_index[tag].append(exp_id)

    def _remove_from_indices(self, exp_id: str, exp: Experience) -> None:
        """从所有索引中移除指定经验 ID"""
        # 类型索引
        if exp.experience_type in self._type_index:
            self._type_index[exp.experience_type].remove(exp_id)
        
        # 来源索引
        if exp.source in self._source_index:
            self._source_index[exp.source].remove(exp_id)
        
        # 标签索引
        for tag in exp.tags:
            if exp_id in self._tag_index[tag]:
                self._tag_index[tag].remove(exp_id)
                if not self._tag_index[tag]:
                    del self._tag_index[tag]

    def persist_local(self) -> None:
        """触发本地持久化保存"""
        with self._lock:
            self._repository.save(self._experiences)

    def _generate_id(self) -> str:
        """生成唯一经验 ID"""
        return f"exp_{int(time.time() * 1000000)}_{uuid.uuid4().hex[:6]}"

    @staticmethod
    def _calculate_jaccard_similarity(tags_a: List[str], tags_b: List[str]) -> float:
        """
        计算两个标签列表的 Jaccard 相似度。
        
        Args:
            tags_a: 标签列表 A
            tags_b: 标签列表 B
            
        Returns:
            float: 相似度 (0.0 - 1.0)
        """
        if not tags_a or not tags_b:
            return 0.0
        set_a = set(tags_a)
        set_b = set(tags_b)
        intersection = set_a & set_b
        union = set_a | set_b
        return len(intersection) / len(union) if union else 0.0

    def _find_similar_experience(self, new_exp: Experience) -> Optional[str]:
        """
        查找相似经验用于去重合并。
        
        Args:
            new_exp: 新经验对象
            
        Returns:
            Optional[str]: 相似经验的 ID，若未找到则返回 None
        """
        candidates = self._type_index.get(new_exp.experience_type, [])
        best_id = None
        best_sim = 0.0
        
        for old_id in candidates:
            old_exp = self._experiences.get(old_id)
            if not old_exp or not old_exp.is_active:
                continue
            
            sim = self._calculate_jaccard_similarity(old_exp.tags, new_exp.tags)
            if sim > best_sim:
                best_sim = sim
                best_id = old_id
        
        return best_id if (best_id and best_sim >= self._SIMILARITY_THRESHOLD) else None

    def _merge_experiences(self, old_exp: Experience, new_exp: Experience) -> None:
        """合并新经验到旧经验中"""
        old_exp.usage_count += new_exp.usage_count
        old_exp.content = new_exp.content
        old_exp.updated_at = time.time()
        
        # 合并标签 (有序去重)
        merged_tags = sorted(set(old_exp.tags + new_exp.tags))
        
        # 同步标签索引差量
        old_tag_list = list(old_exp.tags)
        new_tag_list = merged_tags
        
        # 移除不再存在的标签索引项
        for tag in old_tag_list:
            if tag not in new_tag_list:
                self._tag_index[tag].remove(old_exp.experience_id)
                if not self._tag_index[tag]:
                    del self._tag_index[tag]
        
        # 添加新标签索引项
        for tag in new_tag_list:
            if tag not in self._tag_index:
                self._tag_index[tag] = []
            if old_exp.experience_id not in self._tag_index[tag]:
                self._tag_index[tag].append(old_exp.experience_id)
        
        old_exp.tags = merged_tags

    def store_experience(self, experience: Experience) -> str:
        """
        存储单个经验。
        
        Args:
            experience: 经验对象
            
        Returns:
            str: 存储后的经验 ID
        """
        if not experience.experience_id:
            experience.experience_id = self._generate_id()
        
        with self._lock:
            # 查重与合并
            similar_id = self._find_similar_experience(experience)
            if similar_id:
                old_exp = self._experiences[similar_id]
                # 校验关键字段一致性
                if (old_exp.outcome != experience.outcome or
                    old_exp.lesson_type != experience.lesson_type or
                    old_exp.root_cause != experience.root_cause or
                    old_exp.avoid_hint != experience.avoid_hint):
                    self._logger.error(f"Reject merge: inconsistent fields in {similar_id}")
                    return similar_id
                self._merge_experiences(old_exp, experience)
                self._stats["experiences_stored"] += 1
                self.persist_local()
                self._logger.debug(f"Merged experience into {similar_id}")
                return similar_id
            
            # 新增
            self._experiences[experience.experience_id] = experience
            self._update_indices(experience.experience_id, experience, new_entry=True)
            
            # G-07: 语料库来源特殊处理
            if experience.source == ExperienceSource.CORPUS:
                self._corpus_whitelist.add(experience.experience_id)
                self._stats["corpus_experiences"] += 1
            
            self._stats["experiences_stored"] += 1
            
        self.persist_local()
        self._logger.debug(f"Stored new experience: {experience.experience_id}")
        return experience.experience_id

    def store_batch(self, experiences: List[Experience]) -> List[str]:
        """
        批量存储经验。
        
        Args:
            experiences: 经验列表
            
        Returns:
            List[str]: 对应的经验 ID 列表
        """
        return [self.store_experience(exp) for exp in experiences]

    @staticmethod
    def _is_valid_structured_lesson(exp: Experience) -> bool:
        """
        校验是否为合格的结构化教训。
        
        Args:
            exp: 经验对象
            
        Returns:
            bool: 是否合格
        """
        if not exp:
            return False
        
        # 必填字段检查
        if exp.outcome not in ExperienceLibrary._ALLOWED_OUTCOMES:
            return False
        if len(exp.root_cause.strip()) < ExperienceLibrary._MIN_LESSON_TEXT_LEN:
            return False
        if len(exp.avoid_hint.strip()) < ExperienceLibrary._MIN_LESSON_TEXT_LEN:
            return False
        if exp.lesson_type.strip().lower() not in ExperienceLibrary._ALLOWED_LESSON_TYPES:
            return False
            
        return True

    def record_lesson(self, lesson: str, outcome: str, root_cause: str, 
                      avoid_hint: str, lesson_type: str,
                      source: Optional[ExperienceSource] = None,
                      tags: Optional[List[str]] = None) -> Optional[str]:
        """
        结构化教训入库入口。
        
        Args:
            lesson: 教训摘要文本
            outcome: 结果 ("success" 或 "failure")
            root_cause: 根因分析
            avoid_hint: 避免建议
            lesson_type: 教训类型
            source: 来源
            tags: 额外标签
            
        Returns:
            Optional[str]: 入库成功返回 ID，拒绝则返回 None
        """
        # 1. 参数标准化
        lesson = (lesson or "").strip()
        outcome = (outcome or "").strip().lower()
        root_cause = (root_cause or "").strip()
        avoid_hint = (avoid_hint or "").strip()
        lesson_type = (lesson_type or "").strip().lower()

        # 2. 严格门槛校验
        if not lesson:
            self._logger.debug("Reject lesson: empty content")
            return None
        if outcome not in self._ALLOWED_OUTCOMES:
            self._logger.debug(f"Reject lesson: invalid outcome {outcome}")
            return None
        if len(root_cause) < self._MIN_LESSON_TEXT_LEN:
            self._logger.debug("Reject lesson: root_cause too short")
            return None
        if len(avoid_hint) < self._MIN_LESSON_TEXT_LEN:
            self._logger.debug("Reject lesson: avoid_hint too short")
            return None
        if lesson_type not in self._ALLOWED_LESSON_TYPES:
            self._logger.debug(f"Reject lesson: invalid lesson_type {lesson_type}")
            return None

        # 3. 构建经验对象
        exp_type = ExperienceType.TASK_SUCCESS if outcome == "success" else ExperienceType.TASK_FAILURE
        exp_source = source or ExperienceSource.ANALYSIS
        final_tags = list(tags or [])
        if lesson_type not in final_tags:
            final_tags.append(lesson_type)

        exp = Experience(
            experience_id="",
            experience_type=exp_type,
            source=exp_source,
            content=lesson[:self._MAX_CONTENT_LEN],
            context={
                "outcome": outcome,
                "lesson_type": lesson_type,
                "root_cause": root_cause,
                "avoid_hint": avoid_hint
            },
            success_score=1.0 if outcome == "success" else 0.5,
            tags=final_tags,
            outcome=outcome,
            root_cause=root_cause,
            avoid_hint=avoid_hint,
            lesson_type=lesson_type,
            verified=False
        )

        # 4. 入库
        return self.store_experience(exp)

    def query_experiences(self, query: ExperienceQuery) -> List[Experience]:
        """
        根据条件查询经验。
        
        Args:
            query: 查询条件对象
            
        Returns:
            List[Experience]: 匹配的经验列表
        """
        with self._lock:
            self._stats["query_count"] += 1
            
            # 获取候选集
            if query.experience_type:
                candidate_ids = self._type_index.get(query.experience_type, [])
            else:
                candidate_ids = list(self._experiences.keys())

            results = []
            current_time = time.time()

            for exp_id in candidate_ids:
                exp = self._experiences.get(exp_id)
                if not exp or not exp.is_active:
                    continue

                # 过滤条件
                if query.source and exp.source != query.source:
                    continue
                if query.tags and not any(t in exp.tags for t in query.tags):
                    continue
                if exp.success_score < query.min_score:
                    continue
                if query.max_age_seconds != -1 and (current_time - exp.created_at) > query.max_age_seconds:
                    continue

                results.append(exp)

            # 排序: usage_count 降序, last_used 降序
            results.sort(key=lambda e: (-e.usage_count, -e.last_used or 0.0))
            
            limited_results = results[:query.limit]
            self._stats["query_hits"] += len(limited_results)

        self._logger.debug(f"Query executed, returned {len(limited_results)} items")
        return limited_results

    def get_experience(self, experience_id: str) -> Optional[Experience]:
        """
        获取单个经验。
        
        Args:
            experience_id: 经验 ID
            
        Returns:
            Optional[Experience]: 经验对象或 None
        """
        with self._lock:
            return self._experiences.get(experience_id)

    def search_by_tag(self, tag: str, limit: int = 20) -> List[Experience]:
        """
        按标签搜索经验。
        
        Args:
            tag: 标签名
            limit: 最大返回数量
            
        Returns:
            List[Experience]: 匹配的经验列表
        """
        with self._lock:
            exp_ids = self._tag_index.get(tag, [])
            results = []
            for exp_id in exp_ids:
                exp = self._experiences.get(exp_id)
                if exp and exp.is_active:
                    results.append(exp)
                    if len(results) >= limit:
                        break
            return results

    @staticmethod
    def _tokenize_text(text: str) -> Set[str]:
        """
        粗分词：提取英文单词和中文二元组。
        
        Args:
            text: 输入文本
            
        Returns:
            Set[str]: 分词结果
        """
        if not text:
            return set()
        words = re.findall(r'\b\w+\b|\b[\u4e00-\u9fa5]+\b', text)
        return {word.lower() if word.isalpha() else word for word in words}
