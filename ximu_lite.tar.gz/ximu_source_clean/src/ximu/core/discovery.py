"""发现模块。"""

def get_discovery_agent():
    """获取发现代理。"""
    return None
