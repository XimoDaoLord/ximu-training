# -*- coding: utf-8 -*-
"""拉满模式（full_power / 闪电开关）后端状态读取与同步。

背景
----
前端模型选择弹窗标题旁的闪电图标（⚡）即「拉满模式」开关，另一编排已实现 UI 并
把状态写入浏览器 localStorage：

    localStorage key = "ximu_full_power"   值 "1"=拉满 / "0"或缺省=普通

后端调度层（反思轮次 / 子任务拆解粒度 / 模型路由）需要读到这个状态才能两档真
不同。但 localStorage 后端读不到，且前端切换时不主动通知后端。因此本模块提供
一个最小后端通道：

  1. 后端权威来源 = data/task_exec_config.json 的 `full_power` 布尔字段（持久化）。
  2. 聊天 SSE 入口若 body 带 `full_power` 字段（"1"/true），则实时同步进配置文件，
     本次即生效；前端另一编排将来只要在聊天 body 带上该字段即可零延迟同步。
  3. 提供 set_full_power() 供 API 端点写。

默认 False（普通档）：正常反思轮次、正常拆解深度、正常模型——不降质量前提下
靠调度效率省 token。True（拉满档）：反思更多轮、子任务拆更细、优先更大模型。
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

__version__ = "0.5"

_lock = threading.Lock()

# 模块级缓存：避免每条消息都磁盘读配置
_cache: Optional[bool] = None
_cache_ts: float = 0.0
_CACHE_TTL: float = 5.0  # 秒：切换后最多 5s 全进程生效（聊天高频读，短 TTL 兼顾新鲜度）

# 拉满模式常量定义
_FULL_POWER_ON = True
_FULL_POWER_OFF = False

# 激进参数默认值
_NORMAL_PARAMS = {
    "reflection_min": 3,
    "reflection_max": 5,
    "reflection_rounds": 5,
    "decomposition_depth": 2,
    "prefer_bigger_model": False,
    "verify_passes": 1,
}

_AGGRESSIVE_PARAMS = {
    "reflection_min": 5,
    "reflection_max": 10,
    "reflection_rounds": 10,
    "decomposition_depth": 4,
    "prefer_bigger_model": True,
    "verify_passes": 2,
}


def _config_path() -> str:
    """
    获取 task_exec_config.json 的文件路径。

    优先使用 src.ximu.core.data_root 中的 task_exec_config_path 函数，
    若不可用则回退到相对当前文件的路径。

    Returns:
        str: 配置文件绝对路径。

    Raises:
        FileNotFoundError: 如果配置文件路径无法确定或文件不存在。
    """
    try:
        from src.ximu.core.data_root import task_exec_config_path
        return task_exec_config_path()
    except (ImportError, AttributeError):
        here = os.path.dirname(os.path.abspath(__file__))
        return os.path.abspath(os.path.join(
            here, "..", "ui", "web_ui", "data", "task_exec_config.json"))


def _read_raw() -> Dict[str, Any]:
    """
    读取原始配置文件内容。

    尝试从配置文件路径加载 JSON 数据，如果文件不存在或格式错误，则返回空字典。

    Returns:
        Dict[str, Any]: 解析后的配置字典，读取失败时返回空字典。
    """
    p = _config_path()
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError) as e:
        logger.debug("读取配置文件 %s 失败: %s", p, e)
        return {}


def is_full_power() -> bool:
    """
    判断当前是否处于拉满模式。

    使用 5 秒进程内缓存以减少 I/O 开销；任何读取失败保守返回 False。

    Returns:
        bool: 拉满模式开启返回 True，否则返回 False。
    """
    global _cache, _cache_ts

    now = time.time()
    if _cache is not None and (now - _cache_ts) < _CACHE_TTL:
        return bool(_cache)

    with _lock:
        # 双重检查，防止竞争条件下重复读取
        if _cache is not None and (now - _cache_ts) < _CACHE_TTL:
            return bool(_cache)

        try:
            cfg = _read_raw()
            _cache = bool(cfg.get("full_power", _FULL_POWER_OFF))
        except Exception as e:
            logger.warning("读取 full_power 状态失败，使用默认 False: %s", e)
            _cache = _FULL_POWER_OFF

        _cache_ts = time.time()
        return bool(_cache)


def set_full_power(on: bool) -> bool:
    """
    设置拉满模式开关并持久化到配置文件。

    执行原子写入（先写临时文件再替换），并立即更新进程缓存。

    Args:
        on: 目标状态，True 表示拉满模式，False 表示普通模式。

    Returns:
        bool: 如果状态实际发生了变化返回 True，否则返回 False。
              写入失败时也返回 False。
    """
    global _cache, _cache_ts

    try:
        p = _config_path()
        cfg = _read_raw()
        old = bool(cfg.get("full_power", _FULL_POWER_OFF))
        new_state = bool(on)

        cfg["full_power"] = new_state

        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)

        os.replace(tmp, p)

        with _lock:
            _cache = new_state
            _cache_ts = time.time()

        changed = old != new_state
        if changed:
            logger.info("拉满模式已切换为: %s", new_state)
        return changed

    except OSError as e:
        logger.error("写入配置文件失败: %s", e)
        return False
    except Exception as e:
        logger.error("设置 full_power 时发生未知错误: %s", e)
        return False


def sync_from_chat_body(value: Any) -> bool:
    """
    从聊天请求体中解析 full_power 字段并同步到后端配置。

    接受多种格式：布尔值、数字、字符串（如 "1", "true", "on", "拉满" 等）。

    Args:
        value: 聊天请求体中 full_power 字段的值，可以是 None、布尔、数字或字符串。

    Returns:
        bool: 如果成功同步（状态可能改变或确认未变）返回 True；
              如果 value 为 None 或无法识别则返回 False。
    """
    if value is None:
        return False

    if isinstance(value, bool):
        return set_full_power(value)

    if isinstance(value, (int, float)):
        try:
            return set_full_power(value != 0)
        except Exception:
            return False

    if isinstance(value, str):
        s = value.strip().lower()
        if s in ("1", "true", "on", "yes", "拉满"):
            return set_full_power(_FULL_POWER_ON)
        if s in ("0", "false", "off", "no", "普通", ""):
            return set_full_power(_FULL_POWER_OFF)

    return False


def describe_mode() -> Dict[str, Any]:
    """
    获取当前拉满模式的调试信息。

    Returns:
        Dict[str, Any]: 包含以下键的字典：
            - full_power: 当前是否拉满（bool）
            - config_path: 配置文件路径（str）
            - localStorage_key_hint: 前端 localStorage 键名提示（str）
    """
    return {
        "full_power": is_full_power(),
        "config_path": _config_path(),
        "localStorage_key_hint": "ximu_full_power",
    }


def get_aggressive_params() -> Dict[str, Any]:
    """
    获取拉满模式下核心调度层使用的激进参数。

    根据当前是否拉满，返回不同的反思轮次、拆解深度、模型偏好等参数。
    任何异常保守返回普通档参数。

    Returns:
        Dict[str, Any]: 包含以下键的字典：
            - aggressive: 总开关（bool），与 is_full_power 一致
            - reflection_min: 最小反思轮次（int）
            - reflection_max: 最大反思轮次（int）
            - reflection_rounds: 兼容旧字段的反思轮次（int，等于 reflection_max）
            - decomposition_depth: 子任务拆解深度（int）
            - prefer_bigger_model: 是否优先使用更大模型（bool）
            - verify_passes: 结果自校验轮次（int）
    """
    try:
        on = is_full_power()
        # 普通模式 min=3/max=5，拉满/闪电模式 min=5/max=10
        params = dict(_AGGRESSIVE_PARAMS if on else _NORMAL_PARAMS)
        params["aggressive"] = bool(on)
        return params
    except Exception as e:
        logger.warning("获取激进参数失败，返回默认普通档参数: %s", e)
        fallback = dict(_NORMAL_PARAMS)
        fallback["aggressive"] = _FULL_POWER_OFF
        return fallback
