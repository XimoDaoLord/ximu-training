# -*- coding: utf-8 -*-
"""
汐沫AI · 统一组件接口契约（阶段零点五 · 执行令 3.4/3.5/3.6）
所有五类组件（tools/skills/connectors/plugins/mcp）必须实现本契约：
  - run(**kwargs) -> dict   统一调用入口（成功/失败/部分成功三种返回）
  - load() -> bool          加载（常驻启动时/临时子任务开始时）
  - unload() -> bool        卸载（仅临时组件，父任务检查通过后）
  - health() -> dict        健康检查 {"healthy": bool, "detail": str}

性能/效率/质量增强（低风险，向后兼容）：
  1. 调用结果缓存：相同 (component, kwargs) 在 TTL 内不重复调 impl
     —— 通过 kwargs 传 `__cache_ttl=<秒>` 显式开启，默认关闭（避免误缓存写操作）
  2. 超时/网络错误自动重试：error.code 以 net_ 开头时按指数退避重试
     —— 通过 kwargs 传 `__retry=<次数>` 覆盖，默认 2 次；传 0 关闭
  3. 输出校验：返回 dict 必须含 success/data/error/meta 四键，缺失则补全（错误降级）
"""
from __future__ import annotations

import logging
import re
import threading
import time
from collections import OrderedDict
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

# 版本号
VERSION: str = "0.5"

# 控制参数前缀：从传给 impl 的 kwargs 中剔除，避免污染组件签名
_CTRL_KEYS: Tuple[str, ...] = ("__cache_ttl", "__retry")

# 重试相关常量
_RETRYABLE_CATEGORIES: Tuple[str, ...] = (
    "net_timeout",
    "net_connection",
    "net_unreachable",
    "net_reset",
)
_DEFAULT_MAX_RETRY: int = 2
_DEFAULT_BACKOFF: float = 0.2

# 缓存相关常量
_CALL_CACHE_MAX: int = 1024


# ---------------------------------------------------------------------------
# 内部工具函数
# ---------------------------------------------------------------------------

def _hashable(v: Any) -> Any:
    """将值递归转换为可哈希形式。"""
    if isinstance(v, dict):
        try:
            return frozenset((k, _hashable(val)) for k, val in v.items())
        except TypeError:
            return None
    if isinstance(v, (list, tuple)):
        try:
            return tuple(_hashable(x) for x in v)
        except TypeError:
            return None
    return v


def _make_cache_key(component: str, kwargs: Dict[str, Any]) -> Optional[Tuple[str, Any]]:
    """构造可哈希的缓存 key。"""
    filtered_kwargs = {k: v for k, v in kwargs.items() if k not in _CTRL_KEYS}
    if not filtered_kwargs:
        return (component, None)
    
    try:
        items = []
        for k, v in sorted(filtered_kwargs.items()):
            hv = _hashable(v)
            if hv is None:
                return None
            items.append((k, hv))
        frozen = tuple(items)
        return (component, frozen)
    except Exception:
        return None


class _LRUCache:
    """线程安全的 LRU + TTL 缓存。"""

    def __init__(self, max_size: int = 1024):
        self._max_size = max_size
        self._cache: OrderedDict[Tuple, Tuple[Optional[float], Any]] = OrderedDict()
        self._lock = threading.Lock()
        self._stats = {"hits": 0, "misses": 0, "evictions": 0}

    def get(self, key: Tuple, now: float) -> Optional[Any]:
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                self._stats["misses"] += 1
                return None
            expire_at, value = entry
            if expire_at is not None and expire_at < now:
                del self._cache[key]
                self._stats["misses"] += 1
                return None
            self._cache.move_to_end(key)
            self._stats["hits"] += 1
            return value

    def put(self, key: Tuple, value: Any, ttl: Optional[float], now: float) -> None:
        expire_at = None if ttl is None else now + ttl
        with self._lock:
            self._cache[key] = (expire_at, value)
            self._cache.move_to_end(key)
            while len(self._cache) > self._max_size:
                self._cache.popitem(last=False)
                self._stats["evictions"] += 1

    def invalidate(self, component: Optional[str] = None) -> int:
        with self._lock:
            if component is None:
                count = len(self._cache)
                self._cache.clear()
                return count
            doomed_keys = [k for k in self._cache if k[0] == component]
            for k in doomed_keys:
                del self._cache[k]
            return len(doomed_keys)

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            total = self._stats["hits"] + self._stats["misses"]
            hit_rate = round(self._stats["hits"] / total, 4) if total else 0.0
            return {
                "size": len(self._cache),
                "max_size": self._max_size,
                "hits": self._stats["hits"],
                "misses": self._stats["misses"],
                "evictions": self._stats["evictions"],
                "hit_rate": hit_rate,
            }


_call_cache_instance = _LRUCache(_CALL_CACHE_MAX)


def invalidate_run_cache(component: Optional[str] = None) -> int:
    """使调用缓存失效。component=None 清空全部；否则只清该组件的缓存项。"""
    count = _call_cache_instance.invalidate(component)
    logger.debug("Cache invalidated for component '%s', removed %d entries", component, count)
    return count


def get_run_cache_stats() -> Dict[str, Any]:
    """获取缓存统计信息。"""
    return _call_cache_instance.stats()


# ---------------------------------------------------------------------------
# 错误与结果构建
# ---------------------------------------------------------------------------

class ComponentError(Exception):
    """统一组件错误基类。code 遵循 <type>_<category>_<detail> 格式。"""

    def __init__(self, code: str, message: str, detail: Optional[str] = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.detail = detail or ""


def ok(
    data: Any = None,
    component: str = "unknown",
    version: str = VERSION,
    elapsed_ms: Optional[float] = None,
    warnings: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """成功返回：success=True, data 放结果, error=None。"""
    if elapsed_ms is None:
        elapsed_ms = 0.0
    if warnings:
        payload: Dict[str, Any] = {"data": data, "warnings": warnings}
    else:
        payload = data
    return {
        "success": True,
        "data": payload,
        "error": None,
        "meta": {
            "elapsed_ms": round(elapsed_ms, 3),
            "component": component,
            "version": version,
        },
    }


def fail(
    code: str,
    message: str,
    component: str = "unknown",
    version: str = VERSION,
    detail: Optional[str] = None,
    elapsed_ms: Optional[float] = None,
) -> Dict[str, Any]:
    """失败返回：success=False, data=None, error 放错误。"""
    if elapsed_ms is None:
        elapsed_ms = 0.0
    return {
        "success": False,
        "data": None,
        "error": {"code": code, "message": message, "detail": detail or ""},
        "meta": {
            "elapsed_ms": round(elapsed_ms, 3),
            "component": component,
            "version": version,
        },
    }


def _infer_code(component: str, e: Exception) -> str:
    """按执行令 3.6 错误类别映射异常 → <type>_<category>_<detail>。"""
    ctype = component.split("_")[0] if component else "component"
    detail = re.sub(r"[^a-z0-9_]", "_", type(e).__name__.lower())[:40]

    if isinstance(e, (ValueError, TypeError)):
        return f"{ctype}_param_invalid"
    if isinstance(e, FileNotFoundError):
        return f"{ctype}_io_file_not_found"
    if isinstance(e, PermissionError):
        return f"{ctype}_io_permission_denied"
    if isinstance(e, TimeoutError):
        return f"{ctype}_net_timeout"
    if isinstance(e, ConnectionError):
        return f"{ctype}_net_connection_refused"
    if isinstance(e, OSError):
        return f"{ctype}_io_error"
    if isinstance(e, (RuntimeError, ImportError, ModuleNotFoundError)):
        return f"{ctype}_external_error"
    if isinstance(e, (KeyError, IndexError, AttributeError)):
        return f"{ctype}_state_error"
    return f"{ctype}_internal_{detail}"


def _validate_result(result: Any, component: str, version: str) -> Dict[str, Any]:
    """输出校验：确保返回 dict 且含 success/data/error/meta 四键。"""
    if not isinstance(result, dict):
        logger.warning("Component '%s' returned non-dict type: %s", component, type(result).__name__)
        return fail(
            f"{component}_internal_bad_shape",
            f"组件返回非 dict 类型: {type(result).__name__}",
            component=component,
            version=version,
            detail=repr(result)[:200],
        )

    fixed = dict(result)
    fixed.setdefault("success", True)
    fixed.setdefault("data", None)
    fixed.setdefault("error", None)
    fixed.setdefault("meta", {})

    if not isinstance(fixed["meta"], dict):
        logger.warning("Component '%s' meta is not a dict, resetting to empty", component)
        fixed["meta"] = {}

    fixed["meta"].setdefault("component", component)
    fixed["meta"].setdefault("version", version)
    fixed["meta"].setdefault("elapsed_ms", 0.0)
    return fixed


def _sanitize_kwargs(kwargs: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[float], int]:
    """分离控制参数与业务参数。"""
    biz_kwargs = {k: v for k, v in kwargs.items() if k not in _CTRL_KEYS}
    cache_ttl_raw = kwargs.get("__cache_ttl")
    retry_raw = kwargs.get("__retry", _DEFAULT_MAX_RETRY)

    try:
        cache_ttl = float(cache_ttl_raw) if cache_ttl_raw else None
    except (TypeError, ValueError):
        logger.debug("Invalid __cache_ttl value: %s, ignoring", cache_ttl_raw)
        cache_ttl = None

    try:
        retry = int(retry_raw)
    except (TypeError, ValueError):
        logger.debug("Invalid __retry value: %s, using default", retry_raw)
        retry = _DEFAULT_MAX_RETRY
    retry = max(0, min(10, retry))

    return biz_kwargs, cache_ttl, retry


def _is_retryable(result: Dict[str, Any]) -> bool:
    """判断结果是否为可重试的网络错误。"""
    if not isinstance(result, dict) or result.get("success"):
        return False
    err = result.get("error") or {}
    if not isinstance(err, dict):
        return False
    code = err.get("code") or ""
    if not code:
        return False
    parts = code.split("_")
    if len(parts) < 2:
        return False
    category = "_".join(parts[1:3]) if len(parts) >= 3 else "_".join(parts[1:])
    return category in _RETRYABLE_CATEGORIES


# ---------------------------------------------------------------------------
# 核心包装函数
# ---------------------------------------------------------------------------

def run_wrapped(
    component: str,
    impl: Callable[..., Any],
    *args: Any,
    **kwargs: Any,
) -> Dict[str, Any]:
    """
    把任意函数包装成统一返回格式：捕获异常转错误码、计时写 meta。
    
    支持缓存（__cache_ttl）和重试（__retry）机制。
    """
    biz_kwargs, cache_ttl, max_retry = _sanitize_kwargs(kwargs)
    now = time.monotonic()

    # 1) 缓存检查
    cache_key = _make_cache_key(component, kwargs) if cache_ttl is not None else None
    if cache_key is not None:
        cached = _call_cache_instance.get(cache_key, now)
        if cached is not None:
            logger.debug("Cache hit for component '%s'", component)
            return cached
        logger.debug("Cache miss for component '%s'", component)

    # 2) 执行与重试
    result: Optional[Dict[str, Any]] = None
    last_attempt: Optional[Dict[str, Any]] = None

    for attempt in range(max_retry + 1):
        t0 = time.perf_counter()
        try:
            raw = impl(*args, **biz_kwargs)
            elapsed = (time.perf_counter() - t0) * 1000.0
            if isinstance(raw, dict) and "success" in raw and "meta" in raw:
                result = raw
            else:
                result = ok(raw, component=component, elapsed_ms=elapsed)
        except ComponentError as e:
            elapsed = (time.perf_counter() - t0) * 1000.0
            result = fail(
                e.code,
                e.message,
                component=component,
                detail=e.detail,
                elapsed_ms=elapsed,
            )
        except Exception as e:  # noqa: BLE001
            elapsed = (time.perf_counter() - t0) * 1000.0
            code = _infer_code(component, e)
            result = fail(
                code,
                str(e) or type(e).__name__,
                component=component,
                detail=repr(e)[:500],
                elapsed_ms=elapsed,
            )
            logger.debug("Exception in component '%s': %s", component, e)

        last_attempt = result

        # 如果成功或不可重试，则退出
        if not _is_retryable(result) or attempt >= max_retry:
            break

        backoff = _DEFAULT_BACKOFF * (2 ** attempt)
        logger.debug("Retrying component '%s' in %.2f s (attempt %d)", component, backoff, attempt + 1)
        time.sleep(backoff)

    if result is None:
        result = last_attempt if last_attempt is not None else fail(
            f"{component}_internal_no_attempt",
            "No attempt executed",
            component=component,
        )

    # 3) 输出校验
    _meta = result.get("meta") if isinstance(result, dict) else None
    _ver = _meta.get("version", VERSION) if isinstance(_meta, dict) else VERSION
    result = _validate_result(result, component=component, version=str(_ver))

    # 4) 写入缓存（仅成功结果）
    if cache_key is not None and result.get("success"):
        _call_cache_instance.put(cache_key, result, cache_ttl, time.monotonic())
        logger.debug("Cached result for component '%s'", component)

    return result


def health(component: str, healthy: bool = True, detail: str = "") -> Dict[str, Any]:
    """统一健康检查返回。"""
    return {
        "healthy": healthy,
        "detail": detail or f"{component} 正常",
    }


__all__ = [
    "ComponentError",
    "ok",
    "fail",
    "run_wrapped",
    "health",
    "invalidate_run_cache",
    "get_run_cache_stats",
    "VERSION",
]
