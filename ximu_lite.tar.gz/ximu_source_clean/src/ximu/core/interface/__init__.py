# -*- coding: utf-8 -*-
import logging
from typing import Any, Callable, Optional
from .contract import (  # noqa: F401
    ComponentError,
    fail,
    get_run_cache_stats,
    health,
    invalidate_run_cache,
    ok,
    run_wrapped,
)

logger = logging.getLogger(__name__)

class ComponentError(Exception):
    """组件执行过程中发生的错误。"""

def fail(error: Optional[str] = None) -> ComponentError:
    """失败响应，记录日志后返回组件错误。"""
    logger.info("Component operation failed with message: %s", error or "未知错误")
    raise ComponentError(error or "组件操作失败")

def ok(result: Any) -> None:
    """成功响应，记录日志后返回结果。"""
    logger.info("Component operation completed successfully")
    return result

def health() -> None:
    """健康检查，记录日志后返回状态。"""
    logger.info("Component health check completed")
    return None

def get_run_cache_stats() -> dict[str, int]:
    """获取运行缓存统计信息，记录日志后返回结果。"""
    logger.info("Component cache stats requested")
    return {}

def invalidate_run_cache() -> None:
    """清除运行缓存，记录日志后执行。"""
    logger.info("Component cache invalidated")
    return None

def run_wrapped(func: Callable, *args: Any, **kwargs: Any) -> Any:
    """记录日志后执行包装函数。"""
    logger.info("Starting wrapped function execution")
    try:
        return func(*args, **kwargs)
    finally:
        logger.info("Wrapped function execution completed")

__all__ = [
    "ComponentError",
    "fail",
    "get_run_cache_stats",
    "health",
    "invalidate_run_cache",
    "ok",
    "run_wrapped",
]

__version__ = "0.5"
