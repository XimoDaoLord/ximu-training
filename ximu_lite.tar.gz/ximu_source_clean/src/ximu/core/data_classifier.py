# -*- coding: utf-8 -*-
"""汐沫AI 数据分类器（Data Classifier）。

核心概念：
    向量数据 = 干净数据（所有干净数据经向量嵌入模型向量化，1024 维）。

分类维度（两层）：
    1. 按用途分两大类、共 5 小类：
       - 可训练：
           * train_vector  向量训练数据（训练需向量输入的模型：过滤分类/提纯压缩）
           * train_normal  正常干净数据（训练其他模型：意图分析/任务拆解/路由等）
       - 不可训练：
           * low_quality   低质量数据（quality_score 低，作反例参考，不训练）
           * reference     参考数据（用于检索对比，不训练）
           * pending_review 待审核数据（未最终审核，暂不训练）
    2. 按任务类型分 16 大类、共 113 个原子任务类型（与任务生成器一致）。

联上的系统（全部 try/except 降级，绝不因外部系统不可用而崩溃）：
    - 向量系统（云端智谱embedding-3优先，1024 维）：干净数据向量化；未配置时用 hash_fallback 生成伪向量。
    - 质量判断工具（五重判断作参考）：仅作参考，真正打分交给模型。
    - 干净数据器（data_clean_capture）：作为数据源拉取候选记录。
    - 记忆系统：把分类结果写入记忆。

技术兜底（不依赖模型，只做确定性检查）：去重、过滤垃圾、JSON 检查、安全检查、语法检查。
"""
from __future__ import annotations

import ast
import base64
import hashlib
import json
import logging
import os
import re
import struct
import sys
import threading
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("src.ximu.core.data_classifier")

# --------------------------------------------------------------------------- #
# 项目根定位（与 data_root.py 保持一致的推导方式）
# --------------------------------------------------------------------------- #
_HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# 向量维度（BGE-m3 / 云端截断后统一1024维）与训练数据目录
VECTOR_DIM: int = 1024
TRAINING_DATA_DIR: str = os.path.join(PROJECT_ROOT, "data", "training_data")

# 低质量阈值（quality_score 低于此值视为低质量反例；真正质量分由模型给出）
# 质量分统一为 0-100 分制；低于 60 分视为低质量反例（错误学习），不进入训练集
LOW_QUALITY_THRESHOLD: float = 60.0
# 干净数据 >=80；训练数据再精筛（现阶段先 >=80 攒基础微调数据，后续打分官模型成熟后再收紧到90）
TRAINING_QUALITY_THRESHOLD: float = 80.0


# --------------------------------------------------------------------------- #
# 多语言检测（纯 Unicode 字符范围，不安装外部库）
# --------------------------------------------------------------------------- #
def detect_language(text: str) -> str:
    """基于 Unicode 字符范围轻量检测文本主语言。

    Returns: 语言代码（zh/en/ja/ko/es/fr/de/ru/ar/pt/unknown）
    """
    if not text:
        return "unknown"
    counts = {"zh": 0, "ja": 0, "ko": 0, "ru": 0, "ar": 0, "latin": 0}
    for ch in text:
        cp = ord(ch)
        if 0x4E00 <= cp <= 0x9FFF or 0x3400 <= cp <= 0x4DBF:
            counts["zh"] += 1
        elif 0x3040 <= cp <= 0x30FF:  # 平假名/片假名
            counts["ja"] += 1
        elif 0xAC00 <= cp <= 0xD7AF or 0x1100 <= cp <= 0x11FF:  # 韩文音节
            counts["ko"] += 1
        elif 0x0400 <= cp <= 0x04FF:  # 西里尔字母（俄文）
            counts["ru"] += 1
        elif 0x0600 <= cp <= 0x06FF:  # 阿拉伯文
            counts["ar"] += 1
        elif (0x0041 <= cp <= 0x005A) or (0x0061 <= cp <= 0x007A) \
                or 0x00C0 <= cp <= 0x024F:  # 拉丁扩展（en/es/fr/de/pt）
            counts["latin"] += 1
    if max(counts.values()) == 0:
        return "unknown"
    top = max(counts, key=counts.get)
    if top == "latin":
        return "en"  # 拉丁语种细分需词典，此处归为 en（可训练时再筛）
    return top


# =========================================================================== #
# 维度一：按用途分 5 小类
# =========================================================================== #
@dataclass(frozen=True)
class PurposeCategory:
    """用途分类定义。"""
    key: str
    label: str
    trainable: bool          # 是否可进入训练集
    description: str


# 5 小类（两大类：可训练 2 种 / 不可训练 3 种）
PURPOSE_CATEGORIES: Dict[str, PurposeCategory] = {
    "train_vector": PurposeCategory(
        "train_vector", "向量训练数据", True,
        "训练需要向量输入的模型：过滤分类、提纯压缩"),
    "train_normal": PurposeCategory(
        "train_normal", "正常干净数据", True,
        "训练其他模型：意图分析、任务拆解、路由等"),
    "low_quality": PurposeCategory(
        "low_quality", "低质量数据", False,
        "quality_score 低，作反例参考，不进入训练"),
    "reference": PurposeCategory(
        "reference", "参考数据", False,
        "用于检索对比，不进入训练"),
    "pending_review": PurposeCategory(
        "pending_review", "待审核数据", False,
        "尚未最终审核，暂不训练"),
}

# 可训练用途集合（两大类中的可训练分支）
TRAINABLE_PURPOSES: Tuple[str, ...] = ("train_vector", "train_normal")


# =========================================================================== #
# 维度二：按任务类型分 16 大类 / 113 个原子类型（与任务生成器一致）
# =========================================================================== #
# 16 大类：key -> (中文名, 子类型数量)
TASK_GROUPS: Dict[str, str] = {
    "code": "代码",              # 10
    "text": "文本",             # 12
    "creative_writing": "创意写作",  # 10
    "daily_chat": "日常聊天",        # 10
    "role_play": "角色扮演",         # 10
    "data_processing": "数据处理",    # 8
    "tool_call": "工具调用",          # 8
    "math": "数学计算",             # 6
    "decision": "决策推理",          # 6
    "planning": "规划调度",          # 5
    "error_handling": "错误处理",     # 5
    "security": "安全相关",          # 5
    "performance": "性能优化",        # 5
    "doc_generation": "文档生成",     # 5
    "learning_edu": "学习教育",       # 5
    "other": "其他",               # 3
}

# 113 个原子任务类型：(group, key, 中文标签, 触发关键词)
_TASK_DEFS: List[Tuple[str, str, str, Tuple[str, ...]]] = [
    # ---- 代码 code (10) ----
    ("code", "code_review", "代码审查", ("代码审查", "code review", "review代码")),
    ("code", "code_debug", "代码调试", ("调试", "debug", "报错排查", "为什么报错")),
    ("code", "code_refactor", "代码重构", ("重构", "refactor", "优化结构")),
    ("code", "code_generate", "代码生成", ("写代码", "实现一个", "生成函数", "write code", "python", "函数")),
    ("code", "code_explain", "代码解释", ("代码解释", "解释一下代码", "code explain")),
    ("code", "code_unittest", "单元测试编写", ("单元测试", "写测试", "pytest", "test case")),
    ("code", "code_migration", "代码迁移", ("迁移", "migration", "移植到")),
    ("code", "code_profiling", "性能剖析", ("profile", "剖析", "热点函数")),
    ("code", "code_document", "代码注释", ("加注释", "注释代码", "comment")),
    ("code", "code_architecture", "架构设计", ("架构", "architecture", "模块设计")),
    # ---- 文本 text (12) ----
    ("text", "text_summarize", "文本摘要", ("总结", "摘要", "summarize", "概括")),
    ("text", "text_translate", "文本翻译", ("翻译", "translate", "译成")),
    ("text", "text_extract", "信息抽取", ("抽取", "提取", "extract", "关键信息")),
    ("text", "text_paraphrase", "文本改写", ("改写", "paraphrase", "换种说法")),
    ("text", "text_correct", "文本校对", ("校对", "纠错", "correct", "语病")),
    ("text", "text_rewrite", "文本重写", ("重写", "rewrite", "润色")),
    ("text", "text_classify", "文本分类", ("分类", "classify", "打标签")),
    ("text", "text_sentiment", "情感分析", ("情感", "sentiment", "情绪")),
    ("text", "text_keyword", "关键词提取", ("关键词", "keyword", "主题词")),
    ("text", "text_compare", "文本对比", ("对比", "比较两段", "compare")),
    ("text", "text_format", "文本格式化", ("格式化", "排版", "format text")),
    ("text", "text_segment", "分句分段", ("分句", "分段", "segment", "切分句子")),
    # ---- 创意写作 creative_writing (10) ----
    ("creative_writing", "cw_story", "故事创作", ("写故事", "story", "编个故事")),
    ("creative_writing", "cw_poem", "诗歌创作", ("写诗", "poem", "一首诗")),
    ("creative_writing", "cw_script", "剧本创作", ("剧本", "script", "分镜脚本")),
    ("creative_writing", "cw_slogan", "口号标语", ("标语", "slogan", "口号")),
    ("creative_writing", "cw_copywriting", "文案撰写", ("文案", "copywriting", "广告文案")),
    ("creative_writing", "cw_dialogue", "对话创作", ("写对话", "dialogue", "对白")),
    ("creative_writing", "cw_essay", "散文随笔", ("散文", "essay", "随笔")),
    ("creative_writing", "cw_character", "人物设定", ("人物设定", "角色设定", "character")),
    ("creative_writing", "cw_worldbuilding", "世界观构建", ("世界观", "worldbuilding", "设定集")),
    ("creative_writing", "cw_plot", "情节设计", ("情节", "plot", "剧情走向")),
    # ---- 日常聊天 daily_chat (10) ----
    ("daily_chat", "chat_greeting", "问候寒暄", ("你好", "hi", "在吗", "早上好")),
    ("daily_chat", "chat_smalltalk", "闲聊", ("聊聊", "随便说", "small talk", "今天怎么样")),
    ("daily_chat", "chat_advice", "生活建议", ("怎么办", "建议", "advice", "我该怎么")),
    ("daily_chat", "chat_comfort", "情绪安慰", ("难过", "安慰", "心情不好", "压力大")),
    ("daily_chat", "chat_question", "常识问答", ("为什么", "是什么", "问一下", "请问")),
    ("daily_chat", "chat_fact", "事实查询", ("事实", "查一下", "事实是", "帮我确认")),
    ("daily_chat", "chat_opinion", "观点交流", ("你觉得", "怎么看", "opinion", "你认为")),
    ("daily_chat", "chat_plan_life", "生活安排", ("周末", "明天安排", "生活计划", "日程")),
    ("daily_chat", "chat_weather", "天气查询", ("天气", "weather", "气温", "下雨吗")),
    ("daily_chat", "chat_help", "求助协助", ("帮帮我", "help", "搞不定", "求助")),
    # ---- 角色扮演 role_play (10) ----
    ("role_play", "rp_character", "角色扮演", ("扮演", "roleplay", "你现在是", "扮演成")),
    ("role_play", "rp_dialogue", "角色对话", ("以角色身份", "角色对话", "用ta的语气")),
    ("role_play", "rp_story_continue", "剧情续写", ("继续剧情", "续写故事", "接着写")),
    ("role_play", "rp_emotion", "情绪演绎", ("用生气的语气", "带感情", "情绪表达")),
    ("role_play", "rp_scene", "场景模拟", ("模拟场景", "场景设定", "情境演练")),
    ("role_play", "rp_quizmaster", "主持问答", ("你来出题", "quizmaster", "当主持")),
    ("role_play", "rp_mentor", "导师角色", ("当我的导师", "mentor", "带带我")),
    ("role_play", "rp_friend", "朋友角色", ("像朋友一样", "friend", "当我朋友")),
    ("role_play", "rp_expert", "专家角色", ("以专家身份", "expert", "资深专家")),
    ("role_play", "rp_narrator", "旁白叙事", ("旁白", "narrator", "解说这段")),
    # ---- 数据处理 data_processing (8) ----
    ("data_processing", "dp_clean", "数据清洗", ("清洗数据", "clean data", "脏数据处理")),
    ("data_processing", "dp_dedup", "数据去重", ("去重", "dedup", "重复数据")),
    ("data_processing", "dp_aggregate", "数据聚合", ("聚合", "aggregate", "分组统计")),
    ("data_processing", "dp_filter", "数据过滤", ("过滤", "filter data", "筛选数据")),
    ("data_processing", "dp_transform", "数据转换", ("转换格式", "transform", "数据映射")),
    ("data_processing", "dp_statistics", "数据统计", ("统计", "statistics", "均值方差")),
    ("data_processing", "dp_parse", "数据解析", ("解析", "parse", "解析日志", "解析json")),
    ("data_processing", "dp_normalize", "数据归一化", ("归一化", "normalize", "标准化数据")),
    # ---- 工具调用 tool_call (8) ----
    ("tool_call", "tc_search", "联网搜索", ("搜索网页", "search web", "联网查", "google")),
    ("tool_call", "tc_browser", "浏览器操作", ("打开网页", "browser", "浏览页面", "爬取")),
    ("tool_call", "tc_file_io", "文件读写", ("读文件", "写文件", "file io", "保存到文件")),
    ("tool_call", "tc_shell", "命令执行", ("执行命令", "shell", "terminal", "跑脚本")),
    ("tool_call", "tc_http", "HTTP请求", ("发请求", "http请求", "curl", "api调用")),
    ("tool_call", "tc_calculator", "计算器工具", ("用计算器", "calculate", "算一下")),
    ("tool_call", "tc_calendar", "日历日程", ("加日程", "calendar", "创建提醒", "日历")),
    ("tool_call", "tc_db_query", "数据库查询", ("查数据库", "sql查询", "query db", "select")),
    # ---- 数学计算 math (6) ----
    ("math", "math_arithmetic", "算术运算", ("算", "加减乘除", "arithmetic", "等于多少")),
    ("math", "math_algebra", "代数求解", ("解方程", "algebra", "求x", "因式分解")),
    ("math", "math_geometry", "几何计算", ("几何", "geometry", "面积周长", "三角形")),
    ("math", "math_calculus", "微积分", ("微积分", "导数", "积分", "calculus")),
    ("math", "math_statistics_calc", "统计计算", ("概率", "分布", "回归", "统计计算")),
    ("math", "math_word_problem", "数学应用题", ("应用题", "math word", "多少个", "一共多少")),
    # ---- 决策推理 decision (6) ----
    ("decision", "dde_risk", "风险评估", ("风险", "risk", "隐患", "会不会出问题")),
    ("decision", "dde_compare", "方案对比", ("对比方案", "比较哪个好", "compare options")),
    ("decision", "dde_tradeoff", "权衡取舍", ("权衡", "tradeoff", "利弊", "取舍")),
    ("decision", "dde_cause", "因果分析", ("为什么会", "原因", "root cause", "归因")),
    ("decision", "dde_logic", "逻辑推理", ("推理", "logic", "由此可知", "三段论")),
    ("decision", "dde_evidence", "证据评估", ("证据", "evidence", "依据是什么", "论证")),
    # ---- 规划调度 planning (5) ----
    ("planning", "plan_task", "任务规划", ("规划任务", "plan task", "任务计划")),
    ("planning", "plan_schedule", "时间调度", ("排期", "schedule", "时间安排", "调度")),
    ("planning", "plan_resource", "资源分配", ("分配资源", "resource", "人力分配", "预算")),
    ("planning", "plan_workflow", "工作流设计", ("工作流", "workflow", "流程设计", "流水线")),
    ("planning", "plan_decompose", "任务拆解", ("拆解任务", "decompose", "子任务", "分步")),
    # ---- 错误处理 error_handling (5) ----
    ("error_handling", "eh_diagnose", "错误诊断", ("诊断错误", "error diagnose", "定位问题")),
    ("error_handling", "eh_retry", "重试策略", ("重试", "retry", "再试一次", "退避")),
    ("error_handling", "eh_fallback", "降级兜底", ("降级", "fallback", "兜底方案", "备用")),
    ("error_handling", "eh_recover", "故障恢复", ("恢复", "recover", "故障恢复", "回滚")),
    ("error_handling", "eh_report", "错误上报", ("上报错误", "error report", "写故障报告")),
    # ---- 安全相关 security (5) ----
    ("security", "sec_audit", "安全审计", ("安全审计", "security audit", "渗透测试")),
    ("security", "sec_filter_pii", "隐私脱敏", ("脱敏", "pii", "隐私过滤", "去掉敏感")),
    ("security", "sec_check_injection", "注入检测", ("sql注入", "xss", "注入检测", "injection")),
    ("security", "sec_auth", "认证鉴权", ("鉴权", "认证", "auth", "权限校验", "登录态")),
    ("security", "sec_policy", "合规策略", ("合规", "policy", "安全策略", "越权")),
    # ---- 性能优化 performance (5) ----
    ("performance", "perf_profile", "性能剖析", ("性能剖析", "latency", "耗时分析", "慢")),
    ("performance", "perf_cache", "缓存优化", ("加缓存", "cache", "缓存命中率", "缓存策略")),
    ("performance", "perf_parallel", "并行加速", ("并行", "并发", "parallel", "多线程加速")),
    ("performance", "perf_memory", "内存优化", ("内存", "memory leak", "占用过高", "内存泄漏")),
    ("performance", "perf_latency", "延迟优化", ("延迟", "latency", "响应太慢", "提速")),
    # ---- 文档生成 doc_generation (5) ----
    ("doc_generation", "doc_api", "接口文档", ("接口文档", "api文档", "openapi")),
    ("doc_generation", "doc_readme", "说明文档", ("readme", "使用说明", "项目介绍")),
    ("doc_generation", "doc_report", "报告生成", ("写报告", "report", "总结报告", "日报")),
    ("doc_generation", "doc_comment", "注释文档", ("文档注释", "docstring", "函数说明")),
    ("doc_generation", "doc_spec", "规格说明书", ("规格", "spec", "需求文档", "设计文档")),
    # ---- 学习教育 learning_edu (5) ----
    ("learning_edu", "le_explain", "知识讲解", ("讲解", "explain", "教我", "科普")),
    ("learning_edu", "le_quiz", "出题测验", ("出题", "quiz", "测验", "考考我")),
    ("learning_edu", "le_notes", "笔记整理", ("笔记", "整理知识点", "notes", "学习要点")),
    ("learning_edu", "le_tutor", "辅导答疑", ("辅导", "tutor", "答疑", "搞不懂这题")),
    ("learning_edu", "le_curriculum", "学习路径", ("学习路径", "curriculum", "怎么学", "学习计划")),
    # ---- 其他 other (3) ----
    ("other", "other_general", "通用其他", ("其他", "general", "杂项")),
    ("other", "other_unknown", "未识别", ("未知", "unknown", "无法分类")),
    ("other", "other_meta", "元任务", ("元任务", "meta", "关于系统本身", "你自己")),
]


# 原子类型索引：key -> (group, label, keywords)
TASK_TYPES: Dict[str, Dict[str, Any]] = {
    key: {"group": group, "label": label, "keywords": kws}
    for (group, key, label, kws) in _TASK_DEFS
}

# 任务类型总数（应为 113）
TASK_TYPE_COUNT: int = len(TASK_TYPES)

# 关键词 -> task_type 映射（小写匹配，按定义顺序即优先级）
_KEYWORD_INDEX: List[Tuple[str, str]] = [
    (kw.lower(), key) for (_, key, _, kws) in _TASK_DEFS for kw in kws
]


# =========================================================================== #
# 向量编码：云端智谱优先（1024维）→ 本地BGE-m3备用 → hash_fallback兜底
# =========================================================================== #
class VectorEncoder:
    """干净数据向量化编码器。

    - 优先调用云端API（vector_integration.vectorize_text_ex，智谱embedding-3截断1024维）；
    - 云端不可用时降级到本地BGE-m3（1024维）；
    - 都不可用时降级用 ``hash_fallback`` 生成确定性伪向量，
      保证分类与训练流水线在无外网 / 无 API Key 环境下仍可运行；
    - 向量用 ``struct.pack`` 紧凑序列化为 float32（1024 维 = 4096 字节/条），
      入库时再 base64 编码成可写入 jsonl 的文本。
    """

    def __init__(self, dim: int = VECTOR_DIM) -> None:
        self.dim: int = dim
        self._backend: str = "unset"
        self._remote = None  # 延迟持有向量系统句柄

    # ------------------------------------------------------------------ #
    # 远程向量系统（Jina v5），整体包在 try/except 里
    # ------------------------------------------------------------------ #
    def _load_remote(self) -> Optional[Any]:
        if self._remote is not None:
            return self._remote
        try:
            from src.ximu.core.vector_integration import vectorize_text_ex  # type: ignore
            self._remote = vectorize_text_ex
        except Exception as e:  # 包链 / API 未配置等
            logger.debug("向量系统不可用，使用 hash_fallback: %s", e)
            self._remote = None
        return self._remote

    def encode(self, text: str) -> Tuple[List[float], str]:
        """把文本编码为 1024 维向量。

        Returns:
            (向量列表, 后端名)；后端名为
            "cloud_embedding" / "local_bge_m3" / "hash_fallback"。
        """
        if not text or not text.strip():
            return self.hash_fallback(text), "hash_fallback"
        remote = self._load_remote()
        if remote is not None:
            try:
                vec, backend_name = remote(text)
                if vec and len(vec) == self.dim:
                    self._backend = backend_name
                    return [float(x) for x in vec], backend_name
                logger.debug("远程向量维度不符(%s)，降级 hash_fallback",
                             None if vec is None else len(vec))
            except Exception as e:
                logger.debug("远程向量化异常，降级 hash_fallback: %s", e)
        self._backend = "hash_fallback"
        return self.hash_fallback(text), "hash_fallback"

    def hash_fallback(self, text: str) -> List[float]:
        """确定性伪向量：用 blake2b 派生种子，L2 归一化到单位球。

        同一文本永远得到同一向量，不同文本近似正交；仅用于本地无 API 时的
        占位与可复现流水线，不具备真实语义相似度。
        """
        seed = int.from_bytes(
            hashlib.blake2b((text or "").encode("utf-8"), digest_size=32).digest()[:8],
            "little",
        ) or 1
        import random
        rng = random.Random(seed)
        vec = [rng.uniform(-1.0, 1.0) for _ in range(self.dim)]
        norm = sum(x * x for x in vec) ** 0.5 or 1.0
        return [x / norm for x in vec]

    # ------------------------------------------------------------------ #
    # 紧凑序列化：float32，1024 维 = 4096 字节
    # ------------------------------------------------------------------ #
    def serialize(self, vec: List[float]) -> bytes:
        """把 float 向量紧凑打包为 float32 字节串。"""
        if len(vec) != self.dim:
            raise ValueError(f"向量维度不符: 期望 {self.dim}, 实际 {len(vec)}")
        return struct.pack(f"<{self.dim}f", *vec)

    def deserialize(self, data: bytes) -> List[float]:
        """把 float32 字节串还原为 float 向量列表。"""
        if len(data) != self.dim * 4:
            raise ValueError(f"序列化长度不符: 期望 {self.dim*4}, 实际 {len(data)}")
        return list(struct.unpack(f"<{self.dim}f", data))

    def encode_to_text(self, text: str) -> Tuple[str, str]:
        """向量化 + 序列化为 base64 文本（可直接写入 jsonl）。"""
        vec, backend = self.encode(text)
        raw = self.serialize(vec)
        return base64.b64encode(raw).decode("ascii"), backend


# =========================================================================== #
# 技术兜底检查：不依赖模型，只做确定性检查
#   去重 / 过滤垃圾 / JSON 检查 / 安全检查 / 语法检查
# =========================================================================== #
# 危险模式（安全兜底：命令注入 / eval / 硬编码密钥等）
_DANGEROUS_PATTERNS: List[Tuple[str, str]] = [
    (r"\bos\.(system|popen|execv|spawn)\b", "command_injection"),
    (r"\b(subprocess|os\.system)\.", "subprocess_call"),
    (r"\beval\s*\(", "eval_usage"),
    (r"\bexec\s*\(", "exec_usage"),
    (r"(?i)(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*['\"][^'\"]{8,}['\"]",
     "hardcoded_secret"),
    (r"(?i)(DROP\s+TABLE|DELETE\s+FROM|UNION\s+SELECT).*(--|#|\s)", "sql_injection"),
    (r"<script[^>]*>", "xss_script"),
]

# 垃圾文本特征（重复字符 / 过短 / 无意义）
_MIN_TEXT_LEN: int = 2


class TechnicalCheckResult:
    """技术兜底检查结果集合。"""

    def __init__(self) -> None:
        self.flags: List[str] = []          # 命中的问题标签
        self.duplicate: bool = False         # 是否重复
        self.garbage: bool = False           # 是否垃圾文本
        self.json_ok: Optional[bool] = None  # JSON 校验结果（非 JSON 内容为 None）
        self.syntax_ok: Optional[bool] = None  # 语法校验结果（非代码为 None）
        self.security_issues: List[str] = []

    def to_dict(self) -> Dict[str, Any]:
        return {
            "flags": self.flags,
            "duplicate": self.duplicate,
            "garbage": self.garbage,
            "json_ok": self.json_ok,
            "syntax_ok": self.syntax_ok,
            "security_issues": self.security_issues,
        }


class TechnicalFallbackChecker:
    """确定性技术兜底检查器（质量判断交给模型，这里只做硬检查）。"""

    def __init__(self) -> None:
        self._seen: Dict[str, str] = {}  # content_hash -> 首次出现标识

    def content_hash(self, text: str) -> str:
        """内容短哈希（去重键），用 blake2b 16 字节。"""
        return hashlib.blake2b(
            (text or "").encode("utf-8"), digest_size=16
        ).hexdigest()

    def check(self, record: Dict[str, Any]) -> TechnicalCheckResult:
        """对一条记录做全套确定性检查。"""
        res = TechnicalCheckResult()
        text = str(record.get("text", "") or "")

        # 1) 去重
        h = self.content_hash(text)
        if h in self._seen:
            res.duplicate = True
            res.flags.append("duplicate")
        else:
            self._seen[h] = record.get("id", h)

        # 2) 垃圾过滤：空 / 过短 / 高度重复字符
        if not text.strip():
            res.garbage = True
            res.flags.append("empty")
        elif len(text.strip()) < _MIN_TEXT_LEN:
            res.garbage = True
            res.flags.append("too_short")
        elif self._is_repetitive(text):
            res.garbage = True
            res.flags.append("repetitive")

        # 3) JSON 检查（仅当记录声明为 JSON 或 text 像 JSON）
        if record.get("claims_json") or text.lstrip()[:1] in "{[":
            try:
                json.loads(text)
                res.json_ok = True
            except (ValueError, TypeError):
                res.json_ok = False
                res.flags.append("invalid_json")

        # 4) 语法检查（仅当记录声明为代码）
        if record.get("is_code"):
            try:
                ast.parse(text)
                res.syntax_ok = True
            except (SyntaxError, ValueError):
                res.syntax_ok = False
                res.flags.append("bad_syntax")

        # 5) 安全检查
        for pattern, label in _DANGEROUS_PATTERNS:
            if re.search(pattern, text):
                res.security_issues.append(label)
                res.flags.append("sec:" + label)
        return res

    @staticmethod
    def _is_repetitive(text: str) -> bool:
        """判定是否为高度重复的无意义文本（如 '啊啊啊啊啊啊'）。"""
        stripped = text.strip()
        if len(stripped) < 8:
            return False
        # 单字符重复占比 > 60% 视为垃圾
        head = stripped[0]
        same = sum(1 for ch in stripped if ch == head)
        return same / len(stripped) > 0.6


# =========================================================================== #
# 维度一：用途判定（5 小类）
# =========================================================================== #
class PurposeClassifier:
    """按用途把数据划入 5 小类。

    判定优先级（自上而下，命中即停）：
        1. review_status == "pending"            -> pending_review（待审核，不训练）
        2. usage_hint   == "reference"           -> reference（参考，不训练）
        3. quality_score < LOW_QUALITY_THRESHOLD -> low_quality（低质量反例，不训练）
        4. usage_hint   == "vector_train"        -> train_vector（向量训练数据）
        5. 其余                                   -> train_normal（正常干净数据）
    """

    def __init__(self, low_quality_threshold: float = LOW_QUALITY_THRESHOLD) -> None:
        self.low_quality_threshold = low_quality_threshold

    def classify(self, record: Dict[str, Any]) -> str:
        """返回用途 key（见 PURPOSE_CATEGORIES）。"""
        review = str(record.get("review_status", "approved")).lower()
        hint = str(record.get("usage_hint", "")).lower()
        qscore = record.get("quality_score", 1.0)
        try:
            qscore = float(qscore)
        except (TypeError, ValueError):
            qscore = 1.0

        if review == "pending":
            return "pending_review"
        if hint == "reference":
            return "reference"
        if qscore < self.low_quality_threshold:
            return "low_quality"
        if hint == "vector_train":
            return "train_vector"
        return "train_normal"


# =========================================================================== #
# 维度二：任务类型判定（113 类）
# =========================================================================== #
class TaskTypeClassifier:
    """按任务类型把数据划入 16 大类 / 113 原子类型。

    - 若 record 显式给出合法 task_type，直接采用并校验；
    - 否则对文本小写后按关键词索引顺序匹配（先命中优先）；
    - 都不命中 -> other_general。
    """

    def classify(self, record: Dict[str, Any]) -> Tuple[str, str]:
        """返回 (task_group, task_type)。"""
        explicit = record.get("task_type")
        if explicit and explicit in TASK_TYPES:
            meta = TASK_TYPES[explicit]
            return meta["group"], explicit

        text = str(record.get("text", "") or "").lower()
        if record.get("task_type_hint"):
            text = f"{text} {record['task_type_hint']}".lower()

        # 最长关键词优先（更特异的信号优先），长度并列时按分类体系先后顺序。
        best: Optional[Tuple[int, int, str]] = None
        for order, (kw, ttype) in enumerate(_KEYWORD_INDEX):
            if kw and kw in text:
                score = (len(kw), -order)
                if best is None or score > best[0]:
                    best = (score, ttype)
        if best is not None:
            ttype = best[1]
            return TASK_TYPES[ttype]["group"], ttype
        return "other", "other_general"

    @staticmethod
    def label(task_type: str) -> str:
        """返回原子类型中文名。"""
        return TASK_TYPES.get(task_type, {}).get("label", task_type)

    @staticmethod
    def group_label(task_group: str) -> str:
        """返回大类中文名。"""
        return TASK_GROUPS.get(task_group, task_group)


# =========================================================================== #
# 分类结果
# =========================================================================== #
@dataclass
class ClassificationResult:
    """一条数据的完整分类结果。"""
    record_id: str
    purpose: str                      # 用途 key（5 小类之一）
    purpose_label: str
    trainable: bool                   # 是否可进训练集
    task_group: str                   # 16 大类
    task_group_label: str
    task_type: str                    # 113 原子类型
    task_type_label: str
    quality_score: float
    vector_dim: int
    vector_backend: str               # cloud_embedding / local_bge_m3 / hash_fallback
    content_hash: str
    technical: Dict[str, Any] = field(default_factory=dict)
    language: str = "unknown"           # 文本主语言（zh/en/ja/ko/...）
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# =========================================================================== #
# 主门面：数据分类器
# =========================================================================== #
class DataClassifier:
    """汐沫AI 数据分类器主入口。

    流程（对一条干净数据）：
        1. 技术兜底检查（去重/垃圾/JSON/安全/语法）；
        2. 用途判定（5 小类）；
        3. 任务类型判定（113 类）；
        4. 向量化（Jina v5，失败降级 hash_fallback）；
        5. 可选：调用五重判断作质量参考、写入记忆；
        6. 返回 ClassificationResult。

    四大外部系统全部延迟导入 + try/except，任一不可用都不影响主流程。
    """

    def __init__(
        self,
        training_dir: str = TRAINING_DATA_DIR,
        low_quality_threshold: float = LOW_QUALITY_THRESHOLD,
        enable_quality_judge: bool = True,
        enable_memory: bool = True,
    ) -> None:
        self.training_dir = training_dir
        self.purpose_clf = PurposeClassifier(low_quality_threshold)
        self.task_clf = TaskTypeClassifier()
        self.vector_encoder = VectorEncoder()
        self.checker = TechnicalFallbackChecker()
        self.enable_quality_judge = enable_quality_judge
        self.enable_memory = enable_memory
        self._memory_backend: Optional[Any] = None
        self._write_lock = threading.Lock()  # 防止60并发写同一文件导致行交错损坏
        self._training_seen: set = set()  # 训练数据input去重集合
        self._load_training_hashes()

    def _load_training_hashes(self) -> None:
        """启动时从磁盘加载已有训练数据的input hash，避免重启后重复写入。"""
        try:
            if not os.path.isdir(self.training_dir):
                return
            count = 0
            for fname in os.listdir(self.training_dir):
                if not fname.endswith('.jsonl'):
                    continue
                fpath = os.path.join(self.training_dir, fname)
                try:
                    with open(fpath, 'r', encoding='utf-8') as f:
                        for line in f:
                            line = line.strip()
                            if not line:
                                continue
                            try:
                                d = json.loads(line)
                                inp = str(d.get('input', ''))
                                if inp:
                                    h = hashlib.blake2b(inp.encode('utf-8'), digest_size=16).hexdigest()
                                    self._training_seen.add(h)
                                    count += 1
                            except Exception:
                                continue
                except Exception:
                    continue
            logger.info(f"[去重] 已加载 {count} 条训练数据input hash")
        except Exception as e:
            logger.debug(f"加载训练数据hash失败: {e}")

    # ------------------------------------------------------------------ #
    # 质量判断工具（五重判断，仅作参考，打分交给模型）
    # ------------------------------------------------------------------ #
    def _reference_quality(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """用五重判断做参考性校验（失败则返回空参考）。"""
        if not self.enable_quality_judge:
            return {}
        try:
            from src.ximu.core.data_judge import DataValidator  # type: ignore
            dv = DataValidator({"text": record.get("text", "")})
            comp = dv.completeness(required=["text"])
            return {"completeness_score": getattr(comp, "score", None)}
        except Exception as e:  # 五重判断不可用 -> 不阻塞
            logger.debug("五重判断参考不可用: %s", e)
            return {}

    # ------------------------------------------------------------------ #
    # 记忆系统：写入分类结果
    # ------------------------------------------------------------------ #
    def _write_memory(self, result: ClassificationResult) -> None:
        """把分类结果写入记忆（失败静默降级）。"""
        if not self.enable_memory:
            return
        try:
            if self._memory_backend is None:
                from src.ximu.core.memory.memory_system import LongTermMemory  # type: ignore
                self._memory_backend = LongTermMemory()
            store = getattr(self._memory_backend, "store", None)
            if callable(store):
                store(
                    f"datacls_{result.record_id}",
                    result.to_dict(),
                    tags=["data_classifier", result.purpose, result.task_type],
                )
        except Exception as e:  # 记忆系统不可用 -> 不阻塞
            logger.debug("记忆写入不可用: %s", e)

    # ------------------------------------------------------------------ #
    # 主分类
    # ------------------------------------------------------------------ #
    def classify(self, record: Dict[str, Any]) -> ClassificationResult:
        """对一条干净数据做完整分类。"""
        rid = str(record.get("id") or hashlib.blake2b(
            str(record.get("text", "")).encode("utf-8"), digest_size=8
        ).hexdigest())

        # 1) 技术兜底
        tcheck = self.checker.check(record)

        # 2) 用途
        purpose = self.purpose_clf.classify(record)
        pc = PURPOSE_CATEGORIES[purpose]

        # 3) 任务类型
        group, ttype = self.task_clf.classify(record)

        # 4) 向量化（cloud_embedding / local_bge_m3 / hash_fallback）
        _, backend = self.vector_encoder.encode(str(record.get("text", "")))

        # 5) 质量参考（不覆盖模型给出的 quality_score）
        self._reference_quality(record)

        # 5.5) 语言检测（纯 Unicode 范围，失败不阻塞）
        try:
            language = detect_language(str(record.get("text", "")))
        except Exception:
            language = "unknown"

        try:
            qscore = float(record.get("quality_score", 1.0))
        except (TypeError, ValueError):
            qscore = 1.0

        result = ClassificationResult(
            record_id=rid,
            purpose=purpose,
            purpose_label=pc.label,
            trainable=pc.trainable,
            task_group=group,
            task_group_label=TaskTypeClassifier.group_label(group),
            task_type=ttype,
            task_type_label=TaskTypeClassifier.label(ttype),
            quality_score=qscore,
            vector_dim=VECTOR_DIM,
            vector_backend=backend,
            content_hash=self.checker.content_hash(str(record.get("text", ""))),
            technical=tcheck.to_dict(),
            language=language,
        )
        # 6) 写记忆（异步语义，此处同步尽力而为）
        self._write_memory(result)
        return result

    def classify_batch(self, records: List[Dict[str, Any]]) -> List[ClassificationResult]:
        """批量分类。"""
        return [self.classify(r) for r in records]

    # ------------------------------------------------------------------ #
    # 训练数据文件落盘
    # ------------------------------------------------------------------ #
    # 7 个特殊训练文件：父任务 3 + 中转 3 + 审计 1
    SPECIAL_TRAIN_FILES: Dict[str, str] = {
        "train_parent_intent.jsonl": "父任务-意图分析",
        "train_parent_routing.jsonl": "父任务-路由分发",
        "train_parent_decompose.jsonl": "父任务-任务拆解",
        "train_transit_filter.jsonl": "中转-过滤",
        "train_transit_purify.jsonl": "中转-提纯压缩",
        "train_transit_classify.jsonl": "中转-学习分类",
        "train_audit.jsonl": "审计-质量审核",
    }

    def _sample_row(self, task_type: str, text: str) -> Dict[str, Any]:
        """生成一条真实样例行（含向量后端标记，非 assert True 假数据）。"""
        vec_b64, backend = self.vector_encoder.encode_to_text(text)
        return {
            "task_type": task_type,
            "text": text,
            "quality_score": 0.9,
            "vector_b64": vec_b64,
            "vector_dim": VECTOR_DIM,
            "vector_backend": backend,
        }

    def build_training_skeleton(self) -> Dict[str, Any]:
        """在 data/training_data/ 下生成训练文件骨架。

        共 120 份以上：
            - 7 个特殊文件（父任务3 + 中转3 + 审计1）
            - 113 个原子任务文件 train_{task_type}.jsonl
            - 1 个向量汇总文件 vector_data.jsonl

        Returns:
            生成统计信息字典。
        """
        os.makedirs(self.training_dir, exist_ok=True)
        written: List[str] = []

        # 特殊文件（7 份）
        for fname, desc in self.SPECIAL_TRAIN_FILES.items():
            path = os.path.join(self.training_dir, fname)
            row = self._sample_row(fname.replace("train_", "").replace(".jsonl", ""),
                                    f"[{desc}] 样例输入：请分析并处理这条任务。")
            with open(path, "w", encoding="utf-8") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
            written.append(fname)

        # 113 个原子任务文件
        vector_rows: List[Dict[str, Any]] = []
        for ttype, meta in TASK_TYPES.items():
            fname = f"train_{ttype}.jsonl"
            path = os.path.join(self.training_dir, fname)
            sample_text = f"[{meta['label']}] 样例：{meta['label']}任务的输入示例。"
            row = self._sample_row(ttype, sample_text)
            with open(path, "w", encoding="utf-8") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
            written.append(fname)
            # 向量训练数据汇总（train_vector 用途）
            vector_rows.append({"task_type": ttype, "group": meta["group"],
                                "vector_b64": row["vector_b64"]})

        # vector_data.jsonl：所有向量数据紧凑存储
        vpath = os.path.join(self.training_dir, "vector_data.jsonl")
        with open(vpath, "w", encoding="utf-8") as f:
            for vr in vector_rows:
                f.write(json.dumps(vr, ensure_ascii=False) + "\n")
        written.append("vector_data.jsonl")

        return {
            "training_dir": self.training_dir,
            "special_files": len(self.SPECIAL_TRAIN_FILES),
            "atomic_task_files": TASK_TYPE_COUNT,
            "vector_file": "vector_data.jsonl",
            "total_files": len(written),
        }

    def export_record_to_training(
        self, result: ClassificationResult, text: str,
        record: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """把一条已分类且可训练的数据追加写入对应任务文件。

        训练数据从干净数据继承完整 input/output/metadata（不只是 text 摘要）。
        每条干净记录最多在此产生 1 条训练数据；不可训练（train_vector/train_normal
        之外）直接返回 None，从而保证 训练数据 <= 干净数据。

        Args:
            result: 分类结果。
            text:   提纯后的摘要文本（用于向量化/展示）。
            record: 原始干净记录，应含 input/output/task_type/meta 等字段。

        Returns:
            写入的文件路径；不可训练返回 None。
        """
        if not result.trainable:
            return None
        record = record or {}
        # 训练数据去重：相同input+output组合不重复写入（input相同但LLM输出不同算新数据）
        inp_text = str(record.get("input", ""))
        out_text = str(record.get("output", ""))
        if inp_text:
            dedup_text = inp_text + "|||" + out_text
            dedup_hash = hashlib.blake2b(dedup_text.encode("utf-8"), digest_size=16).hexdigest()
            if dedup_hash in self._training_seen:
                return None
            self._training_seen.add(dedup_hash)
        # 训练数据精筛门槛：仅 >=90 分的精华才写入
        if result.quality_score < TRAINING_QUALITY_THRESHOLD:
            return None
        # 训练数据必须来自五重质量判断真实打分；技术兜底分即使>=90也不进训练集
        if not record.get("quality_verified", False):
            return None
        os.makedirs(self.training_dir, exist_ok=True)
        # 用原始记录的 task_type（与干净数据一致），避免分类器关键词重归类导致类型坍缩
        orig_type = record.get("task_type") or result.task_type
        # 映射到原子模型类型（第一批50个：40代码+10数据）
        try:
            from src.ximu.core.atomic_model_registry import map_task_to_atomic
            atomic_candidates = map_task_to_atomic(orig_type)
            atomic_primary = atomic_candidates[0] if atomic_candidates else "unknown"
        except Exception:
            atomic_candidates = []
            atomic_primary = "unknown"
        fname = f"train_{orig_type}.jsonl"
        path = os.path.join(self.training_dir, fname)
        vec_b64, backend = self.vector_encoder.encode_to_text(text)
        row = {
            "task_type": orig_type,
            "atomic_model_type": atomic_primary,
            "atomic_model_candidates": atomic_candidates,
            "purpose": result.purpose,
            "input": record.get("input", ""),
            "output": record.get("output", ""),
            "text": text,
            "quality_score": result.quality_score,  # 0-100 分制
            "quality_verified": record.get("quality_verified", False),  # 必须为 True
            "language": result.language,
            "metadata": record.get("meta", {}),
            "vector_b64": vec_b64,
            "vector_backend": backend,
            "content_hash": result.content_hash,
            # 完整任务链数据（v2：复数字段 + 最终交付 + 格式版本）
            "original_request": record.get("original_request", ""),
            "father_analysis": record.get("father_analysis", {}),
            "task_decomposition": record.get("task_decomposition", []),
            "atomic_tasks": record.get("atomic_tasks", []),
            "atomic_task": record.get("atomic_task", {}),  # 向后兼容：指向第一个
            "transit_chain": record.get("transit_chain", {}),
            "quality_check": record.get("quality_check", {}),
            "final_delivery": record.get("final_delivery", {}),
            "format_version": record.get("format_version", "v1"),
        }
        line = json.dumps(row, ensure_ascii=False)
        json.loads(line)  # 防御：确保写入的是合法 JSON 行
        with self._write_lock:  # 串行化写入，防止并发行交错损坏
            with open(path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        return path


# =========================================================================== #
# 干净数据器对接：从 data_clean_capture 拉取候选记录（可选）
# =========================================================================== #
def pull_from_clean_capture(limit: int = 50) -> List[Dict[str, Any]]:
    """从干净数据器（data_clean_capture）获取数据源。

    干净数据器模块在环境中可能未装配；任何异常都返回空列表，由调用方决定。
    """
    try:
        from src.ximu.agents.tools.data_processing.data_cleaner import (  # type: ignore
            DataCleanerTool,
        )
        # 仅探测可导入；真实数据源由上层注入，这里返回空骨架
        _ = DataCleanerTool
    except Exception as e:
        logger.debug("干净数据器不可用: %s", e)
    return []


# --------------------------------------------------------------------------- #
# 模块自测：python -m src.ximu.core.data_classifier
# --------------------------------------------------------------------------- #
if __name__ == "__main__":  # pragma: no cover
    logging.basicConfig(level=logging.INFO)
    clf = DataClassifier()
    demo = {
        "id": "demo_001",
        "text": "请帮我写一个快速排序的 Python 函数，并加上单元测试。",
        "quality_score": 0.92,
        "review_status": "approved",
        "usage_hint": "normal",
    }
    r = clf.classify(demo)
    print(json.dumps(r.to_dict(), ensure_ascii=False, indent=2))
    stats = clf.build_training_skeleton()
    print("训练文件生成:", json.dumps(stats, ensure_ascii=False))
