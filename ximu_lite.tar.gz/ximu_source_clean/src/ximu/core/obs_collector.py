from __future__ import annotations
import os
import shutil
import subprocess
import threading
import time
import logging
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

class ObsAlert:
    """
    一条阈值告警事件。
    
    Attributes:
        metric (str): 指标名称。
        value (float): 告警值。
        threshold (float): 阈值。
        op (str): 比较运算符，必须是 '>' 或 '<'。
        at (float, optional): 告警时间戳。 Defaults to None.
    """

    def __init__(self, metric: str, value: float, threshold: float, op: str, at: float = None):
        self.metric = metric
        self.value = value
        self.threshold = threshold
        self.op = op
        self.at = at or time.time()

    def to_dict(self) -> Dict[str, Any]:
        """
        将告警事件转换为可序列化的字典。
        
        Returns:
            包含指标名、运算符、数值、阈值和时间戳的字典。
        """
        return {
            "metric": self.metric,
            "op": self.op,
            "value": round(self.value, 4),
            "threshold": self.threshold,
            "at": round(self.at, 3),
        }

class ObsCollector:
    """
    后台非阻塞指标采集器。
    
    Attributes:
        _proc (psutil.Process, optional): 进程对象。 Defaults to None.
        _ring (Deque[Dict[str, float]]): 环形缓冲，用于存储采样数据。
        _alerts (Deque[ObsAlert]): 环形缓冲，用于存储告警事件。
        _costs (Deque[float]): 环形缓冲，用于存储采样成本。
        _thresholds (Dict[str, Tuple[str, float]]): 阈值字典。
        _lock (threading.RLock): 锁对象，用于保护公共状态。
        _stop (threading.Event): 停止事件，用于停止采集线程。
        _thread (Optional[threading.Thread]): 采集线程。
        _sys_io_every (int): 系统级 IO 采样间隔倍数。
        _sys_io_cnt (int): 系统级 IO 采样计数器。
        _cached_disk_rate (Tuple[float, float]): 缓存的磁盘 IO 增量速率。
        _cached_net_rate (Tuple[float, float]): 缓存的网络 IO 增量速率。
        _cached_disk_abs (Tuple[float, float]): 缓存的磁盘 IO 绝对值。
        _cached_net_abs (Tuple[float, float]): 缓存的网络 IO 绝对值。
        _alert_state (Dict[str, Tuple[bool, float]]): 告警状态字典。
        _alert_cooldown_s (float): 告警去抖时间。
        _sample_errors (int): 采样错误计数。
        _last_error (str): 最近一次采样错误信息。
        _dropped_samples (int): 丢弃的采样计数。
        _last_cpu_ticks (Optional[int]): 最近一次 CPU 滴答数。
        _last_cpu_wall (float): 最近一次 CPU 挂钟时间。
        _last_cpu_pct (float): 最近一次 CPU 使用率。
        _clk_tck (int): 时钟滴答数。
        _gpu (Dict[str, Any]): GPU 信息字典。
    """

    RING_SIZE = 4096
    ALERT_RING = 512
    COST_RING = 4096

    def __init__(self, sys_io_every: int = 5):
        """
        初始化采集器。
        
        Args:
            sys_io_every (int, optional): 系统级 IO 采样间隔倍数。 Defaults to 5.
        """
        self._proc = psutil.Process() if _HAS_PSUTIL else None
        self._ring = deque(maxlen=self.RING_SIZE)
        self._alerts = deque(maxlen=self.ALERT_RING)
        self._costs = deque(maxlen=self.COST_RING)
        self._thresholds = {}
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread = None
        self._sys_io_every = max(1, int(sys_io_every))
        self._sys_io_cnt = 0
        self._cached_disk_rate = (0.0, 0.0)
        self._cached_net_rate = (0.0, 0.0)
        self._cached_disk_abs = (0.0, 0.0)
        self._cached_net_abs = (0.0, 0.0)
        self._alert_state = {}
        self._alert_cooldown_s = 30.0
        self._sample_errors = 0
        self._last_error = ""
        self._dropped_samples = 0
        self._last_cpu_ticks = None
        self._last_cpu_wall = 0.0
        self._last_cpu_pct = 0.0
        self._clk_tck = os.sysconf(os.sysconf_names["SC_CLK_TCK"])
        self._prime_cpu()
        self._gpu = self._probe_gpu()

    def _read_cpu_ticks(self) -> int:
        """
        读 /proc/self/stat 的 utime+stime（用户态+内核态时钟滴答）。
        
        Returns:
            当前进程的总 CPU 时间（以时钟滴答为单位）。
        """
        try:
            with open("/proc/self/stat") as f:
                line = f.read()
        except Exception:
            logger.warning("Failed to read /proc/self/stat", exc_info=True)
            return 0
        after = line[line.rfind(")") + 2:].split()
        try:
            return int(after[11]) + int(after[12])
        except Exception:
            logger.warning("Failed to parse /proc/self/stat", exc_info=True)
            return 0

    def _prime_cpu(self) -> None:
        """
        预热 CPU 采样基线。
        
        记录当前的 CPU 时钟滴答和挂钟时间，作为后续采样的参考点。
        """
        self._last_cpu_ticks = self._read_cpu_ticks()
        self._last_cpu_wall = time.perf_counter()

    def _cpu_percent_safe(self) -> float:
        """
        线程安全的 CPU%：自算 /proc/self/stat 滴答增量 / wall 时间。
        
        Returns:
            当前进程 CPU 使用率（百分比），钳位在 [0, cpu_count*100] 范围内。
        """
        try:
            now_ticks = self._read_cpu_ticks()
        except Exception:
            now_ticks = self._last_cpu_ticks or 0
        now_wall = time.perf_counter()
        if self._last_cpu_ticks is None or self._last_cpu_wall <= 0:
            self._last_cpu_ticks = now_ticks
            self._last_cpu_wall = now_wall
            self._last_cpu_pct = 0.0
            return 0.0
        dt_wall = now_wall - self._last_cpu_wall
        if dt_wall < 0.1:
            return getattr(self, "_last_cpu_pct", 0.0)
        dt_ticks = now_ticks - self._last_cpu_ticks
        self._last_cpu_ticks = now_ticks
        self._last_cpu_wall = now_wall
        pct = max(0.0, (dt_ticks / self._clk_tck) / dt_wall * 100.0)
        hard_max = 100.0 * (os.cpu_count() or 1)
        pct = min(pct, hard_max)
        self._last_cpu_pct = round(pct, 2)
        return self._last_cpu_pct

    @staticmethod
    def _probe_gpu() -> Dict[str, Any]:
        """
        一次性探测 GPU。
        
        无 nvidia-smi / 无 /dev/nvidia* 时优雅降级。
        
        Returns:
            GPU 信息字典，包含 available, name, mem_total_mb 或 reason。
        """
        info = {"available": False, "reason": ""}
        if shutil.which("nvidia-smi") is None:
            info["reason"] = "nvidia-smi not found; GPU monitoring degraded"
            return info
        try:
            out = subprocess.check_output(
                ["nvidia-smi", "--query-gpu=name,memory.total,memory.used,utilization.gpu", "--format=csv,noheader,nounits"],
                timeout=2,
                stderr=subprocess.DEVNULL,
            ).decode("utf-8", "ignore").strip()
            if out:
                parts = [p.strip() for p in out.splitlines()[0].split(",")]
                info["available"] = True
                info["name"] = parts[0] if len(parts) > 0 else "unknown"
                info["mem_total_mb"] = float(parts[1]) if len(parts) > 1 else 0.0
        except Exception as e:
            info["reason"] = f"nvidia-smi failed: {e}"
            logger.debug("GPU probe failed: %s", e)
        return info

    def set_threshold(self, metric: str, op: str, value: float) -> None:
        """
        注册阈值：op in {'>', '<'}。
        
        命中后产生 ObsAlert。
        
        Args:
            metric (str): 指标名称。
            op (str): 比较运算符，必须是 '>' 或 '<'。
            value (float): 阈值数值。
        """
        if op not in (">", "<"):
            raise ValueError(f"op must be '>' or '<', got {op!r}")
        with self._lock:
            self._alert_state.pop(metric, None)
            self._thresholds[metric] = (op, float(value))

    def clear_thresholds(self) -> None:
        """
        清空所有阈值和告警状态。
        """
        with self._lock:
            self._thresholds.clear()
            self._alert_state.clear()

    def recent_alerts(self) -> List[Dict[str, Any]]:
        """
        获取最近的告警事件列表。
        
        Returns:
            告警事件的字典列表。
        """
        with self._lock:
            return [a.to_dict() for a in list(self._alerts)]

    def sample_once(self) -> Dict[str, Any]:
        """
        一次非阻塞采样。
        
        返回 dict，含全部指标 + 本次采样耗时 _sample_cost_ms。
        
        Returns:
            包含各项指标采样的字典。
        """
        t0 = time.perf_counter()
        snap = {"ts": time.time()}
        if self._proc is None:
            snap["error"] = "psutil_unavailable"
        self._record(snap, t0)
        return snap

    def _record(self, snap: Dict[str, Any], t0: float) -> None:
        """
        记录采样数据。
        
        Args:
            snap (Dict[str, Any]): 采样数据。
            t0 (float): 采样开始时间。
        """
        try:
            # 进程 CPU（线程安全自算，避免 psutil 跨线程污染）
            snap["cpu_percent"] = round(self._cpu_percent_safe(), 2)
            # 进程内存
            mi = self._proc.memory_info()
            snap["mem_rss_mb"] = round(mi.rss / 1048576.0, 3)
            snap["mem_vms_mb"] = round(mi.vms / 1048576.0, 3)
            # 进程 IO 计数
            try:
                pio = self._proc.io_counters()
                snap["proc_disk_read_mb"] = round(
                    getattr(pio, "read_bytes", 0) / 1048576.0, 3
                )
                snap["proc_disk_write_mb"] = round(
                    getattr(pio, "write_bytes", 0) / 1048576.0, 3
                )
            except Exception:
                snap["proc_disk_read_mb"] = -1.0
                snap["proc_disk_write_mb"] = -1.0
            # 线程 / 句柄
            snap["num_threads"] = int(self._proc.num_threads())
            try:
                snap["num_fds"] = int(self._proc.num_fds())
            except Exception:
                snap["num_fds"] = -1
            # 非 Linux 平台
            # 系统磁盘 IO（增量速率 MB/s）— 优化：每 N 次读一次，中间帧用缓存
            self._sys_io_cnt += 1
            fresh = (self._sys_io_cnt % self._sys_io_every == 1)
            try:
                if fresh:
                    dio = psutil.disk_io_counters()
                    now = time.time()
                    if dio is not None:
                        self._cached_disk_abs = (
                            round(dio.read_bytes / 1048576.0, 3),
                            round(dio.write_bytes / 1048576.0, 3),
                        )
                        # 计数器回绕/重置（容器重启/换盘）：new < old 时不产生负速率
                        if (
                            self._last_disk is not None
                            and dio.read_bytes >= self._last_disk[0]
                            and dio.write_bytes >= self._last_disk[1]
                        ):
                            dt = max(1e-6, now - self._last_disk[2])
                            self._cached_disk_rate = (
                                round((dio.read_bytes - self._last_disk[0]) / 1048576.0 / dt, 4),
                                round((dio.write_bytes - self._last_disk[1]) / 1048576.0 / dt, 4),
                            )
                        else:
                            # 计数器重置：速率归零，仅更新基线
                            self._cached_disk_rate = (0.0, 0.0)
                            self._last_disk = (
                                int(dio.read_bytes),
                                int(dio.write_bytes),
                                now,
                            )
            except Exception:
                logger.debug("System disk IO sampling failed", exc_info=True)
                snap["sys_disk_read_mb"], snap["sys_disk_write_mb"] = self._cached_disk_abs
                snap["sys_disk_read_mbps"], snap["sys_disk_write_mbps"] = self._cached_disk_rate
            # 系统网络 IO（增量速率 MB/s）— 同样节流
            try:
                if fresh:
                    nio = psutil.net_io_counters()
                    now = time.time()
                    if nio is not None:
                        self._cached_net_abs = (
                            round(nio.bytes_sent / 1048576.0, 3),
                            round(nio.bytes_recv / 1048576.0, 3),
                        )
                        # 计数器回绕：new < old 时不产生负速率
                        if (
                            self._last_net is not None
                            and nio.bytes_sent >= self._last_net[0]
                            and nio.bytes_recv >= self._last_net[1]
                        ):
                            dt = max(1e-6, now - self._last_net[2])
                            self._cached_net_rate = (
                                round((nio.bytes_sent - self._last_net[0]) / 1048576.0 / dt, 4),
                                round((nio.bytes_recv - self._last_net[1]) / 1048576.0 / dt, 4),
                            )
                        else:
                            # 计数器重置：速率归零，仅更新基线
                            self._cached_net_rate = (0.0, 0.0)
                            self._last_net = (
                                int(nio.bytes_sent),
                                int(nio.bytes_recv),
                                now,
                            )
            except Exception:
                logger.debug("System network IO sampling failed", exc_info=True)
                snap["sys_net_sent_mb"], snap["sys_net_recv_mb"] = self._cached_net_abs
                snap["sys_net_sent_mbps"], snap["sys_net_recv_mbps"] = self._cached_net_rate
        except Exception as e:
            self._sample_errors += 1
            try:
                self._last_error = f"{type(e).__name__}: {e}"
            except Exception:
                pass
            logger.debug("Sample loop error: %s", e, exc_info=True)
        self._ring.append(snap)
        self._costs.append(time.perf_counter() - t0)

    def _loop(self) -> None:
        """
        进入循环前再 priming 一次 CPU 基线，避免首帧 cpu=0
        """
        self._prime_cpu()
        while not self._stop.is_set():
            try:
                self.sample_once()
            except Exception as e:
                # 单帧异常不打死采集线程；计数+继续
                self._sample_errors += 1
                try:
                    self._last_error = f"{type(e).__name__}: {e}"
                except Exception:
                    pass
                logger.debug("Sample loop error: %s", e, exc_info=True)
            # Event.wait 可被 stop() 立即中断，不用 time.sleep 卡死
            self._stop.wait(interval=0.1)

    def start(self, interval: float = 1.0) -> None:
        """
        开始采集线程。
        
        Args:
            interval (float, optional): 采样间隔。 Defaults to 1.0.
        """
        self._thread = threading.Thread(target=self._loop, name="obs-collector", daemon=True)
        self._thread.start()

    def stop(self, join_timeout: float = 3.0) -> bool:
        """
        停止后台线程。
        
        返回是否在 timeout 内 join 成功。
        
        Args:
            join_timeout (float, optional): 等待线程结束的最长时间（秒）。 Defaults to 3.0.
        
        Returns:
            线程是否成功终止。
        """
        self._stop.set()
        t = self._thread
        self._thread = None
        if t is not None:
            t.join(timeout=join_timeout)
            return not t.is_alive()
        return True

    def gpu_info(self) -> Dict[str, Any]:
        """
        获取 GPU 探测信息。
        
        Returns:
            GPU 信息字典副本。
        """
        return dict(self._gpu)

def get_obs_collector() -> ObsCollector:
    """
    进程级单例：多个模块共享同一采集器，避免重复采样。
    
    Returns:
        全局唯一的 ObsCollector 实例。
    """
    _singleton = None
    _singleton_lock = threading.Lock()
    if _singleton is None:
        with _singleton_lock:
            if _singleton is None:
                _singleton = ObsCollector()
    return _singleton
