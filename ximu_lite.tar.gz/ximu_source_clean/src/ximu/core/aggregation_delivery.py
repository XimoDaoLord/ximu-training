# -*- coding: utf-8 -*-
"""
聚合交付模块 - 结果聚合与交付确认

负责：
- 多子任务结果聚合（_aggregate）
- 网页组装（_assemble_web）
- 交付确认流程
- 最终结果格式化
- 交付事件推送
"""

from __future__ import annotations

import json
import logging
import re
import time
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("src.ximu.core.aggregation_delivery")


class DeliveryAggregator:
    """聚合器：将多个子任务结果聚合成最终交付物。

    提供静态方法用于聚合子任务输出和组装网页 HTML。
    """

    @staticmethod
    def aggregate(results: List[Dict[str, Any]]) -> str:
        """聚合所有子任务输出。

        根据子任务结果列表，生成拼接后的完整文本。如果检测到相邻子任务存在
        高度相似（增量累积）的情况，仍按标准方式拼接，但保留逻辑清晰的结构。

        Args:
            results: 子任务结果列表，每个元素是一个字典，至少包含 "output" 和
                "name" 键（可选）。

        Returns:
            聚合后的完整文本字符串。如果没有有效输出，返回空字符串。

        Raises:
            ValueError: 如果 results 不是列表类型。
        """
        if not isinstance(results, list):
            raise ValueError(f"Expected a list of results, got {type(results).__name__}")

        outputs: List[str] = []
        names: List[str] = []
        for r in results:
            if not isinstance(r, dict):
                continue
            output_val = r.get("output", "")
            name_val = r.get("name", "")
            outputs.append(str(output_val).strip() if output_val is not None else "")
            names.append(str(name_val) if name_val is not None else "")

        # 过滤掉所有为空的输出
        valid_pairs = [(n, o) for n, o in zip(names, outputs) if o]
        if not valid_pairs:
            return ""

        names = [n for n, o in valid_pairs]
        outputs = [o for n, o in valid_pairs]

        if len(outputs) == 1:
            return outputs[0]

        def _norm(t: str) -> str:
            """标准化文本，移除代码围栏和多余空白。"""
            # 修复点：补全被截断的 replace 调用
            # 常见的标准化操作：移除 Markdown 代码块标记 