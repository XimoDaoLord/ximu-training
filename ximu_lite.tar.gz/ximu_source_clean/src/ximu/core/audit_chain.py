import glob
import hashlib
import json
import logging
import os
import threading
import time
import uuid
from typing import Any, Dict, List, Optional

logger = logging.getLogger("ximu.audit")
_LOCK = threading.RLock()
_AUDIT_DIR_NAME = "干净数据/审计"
_PRIMARY_AUDIT_FILE = "audit.jsonl"
_HASH_BLOCK_SIZE = 65536

def _get_audit_root() -> str:
    """解析审计数据根目录"""
    root = (
        os.environ.get("XIMU_DATA_DIR", "").strip()
        or os.environ.get("XIMU_DATA_ROOT", "").strip()
    )
    if not root:
        try:
            from src.ximu.core.data_root import get_data_root
            root = get_data_root()
        except ImportError:
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            root = os.path.join(project_root, "data")
    
    audit_dir = os.path.join(root, _AUDIT_DIR_NAME)
    os.makedirs(audit_dir, exist_ok=True)
    return audit_dir

def _unified_audit_path() -> str:
    """获取主审计文件路径"""
    return os.path.join(_get_audit_root(), _PRIMARY_AUDIT_FILE)

def _compute_sha256(content: str) -> str:
    """计算SHA256哈希"""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()

def _load_chain_state(path: str) -> Dict[str, Any]:
    """读取链状态"""
    default_state = {"seq": 0, "hash": ""}
    if not os.path.exists(path):
        return default_state

    try:
        file_size = os.path.getsize(path)
        if file_size == 0:
            return default_state

        with open(path, "rb") as f:
            offset = max(0, file_size - _HASH_BLOCK_SIZE)
            f.seek(offset)
            tail_bytes = f.read()
            tail_text = tail_bytes.decode("utf-8", errors="ignore")

        lines = [ln.strip() for ln in tail_text.splitlines() if ln.strip()]
        
        for line in reversed(lines):
            try:
                record = json.loads(line)
                if isinstance(record, dict) and "seq" in record:
                    return {
                        "seq": int(record.get("seq", 0)),
                        "hash": str(record.get("hash", ""))
                    }
            except (json.JSONDecodeError, ValueError, TypeError):
                continue
        
        return default_state

    except OSError as e:
        logger.warning("读取链状态失败: %s", e)
        return default_state

def _generate_chain_hash(seq: int, record: Dict[str, Any], prev_hash: str) -> str:
    """生成链式哈希"""
    payload = {
        "seq": seq,
        "event": record.get("event", ""),
        "action": record.get("action", ""),
        "source": record.get("source", ""),
        "result": record.get("result", ""),
        "ts": record.get("ts", ""),
        "prev_hash": prev_hash,
    }
    canonical_json = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    return _compute_sha256(canonical_json)

def record(
    event: str,
    *,
    action: str = "",
    source: str = "system",
    user: str = "system",
    result: str = "success",
    level: str = "info",
    detail: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """写入审计事件"""
    entry: Dict[str, Any] = {
        "id": f"aud_{uuid.uuid4().hex[:12]}",
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime()),
        "timestamp": round(time.time(), 3),
        "event": event,
        "action": action or event,
        "source": source,
        "user": user,
        "level": level,
        "result": result,
    }
    if detail:
        entry["detail"] = detail

    try:
        path = _unified_audit_path()
        with _LOCK:
            state = _load_chain_state(path)
            new_seq = state["seq"] + 1
            prev_hash = state["hash"]
            
            entry["seq"] = new_seq
            entry["prev_hash"] = prev_hash
            entry["hash"] = _generate_chain_hash(new_seq, entry, prev_hash)

            line = json.dumps(entry, ensure_ascii=False) + "\n"
            
            with open(path, "a", encoding="utf-8") as f:
                f.write(line)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except OSError:
                    logger.debug("fsync failed")

    except Exception as e:
        logger.error("写入审计记录失败: %s", e)
    
    return entry

def verify_chain_integrity(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """验证链完整性"""
    expected_prev_hash = ""
    expected_seq = 1
    valid_records = []

    for rec in records:
        rec_seq = int(rec.get("seq", 0))
        rec_prev_hash = str(rec.get("prev_hash", ""))
        rec_hash = str(rec.get("hash", ""))
        
        seq_ok = (rec_seq == expected_seq)
        prev_ok = (rec_prev_hash == expected_prev_hash)
        calculated_hash = _generate_chain_hash(rec_seq, rec, rec_prev_hash)
        hash_ok = (rec_hash == calculated_hash)
        
        is_valid = seq_ok and prev_ok and hash_ok
        rec["_chain_valid"] = is_valid
        valid_records.append(rec)
        
        expected_prev_hash = rec_hash
        expected_seq = rec_seq + 1

    return valid_records

def read(
    limit: int = 200,
    source: Optional[str] = None,
    event: Optional[str] = None
) -> List[Dict[str, Any]]:
    """读取审计链"""
    root_dir = _get_audit_root()
    rows: List[Dict[str, Any]] = []
    
    try:
        jsonl_files = sorted(glob.glob(os.path.join(root_dir, "*.jsonl")))
    except OSError:
        jsonl_files = []

    chain_entries: List[Dict[str, Any]] = []
    other_entries: List[Dict[str, Any]] = []

    for file_path in jsonl_files:
        filename = os.path.basename(file_path)
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                        if isinstance(rec, dict):
                            if "seq" in rec:
                                chain_entries.append(rec)
                            else:
                                other_entries.append(rec)
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            logger.debug("读取审计文件失败: %s", e)

    if chain_entries:
        chain_entries = verify_chain_integrity(chain_entries)
        rows.extend(chain_entries)
    
    rows.extend(other_entries)
    
    # 过滤
    if source:
        rows = [r for r in rows if r.get("source") == source]
    if event:
        rows = [r for r in rows if event in str(r.get("event", ""))]
    
    # 按时间倒序
    rows.sort(key=lambda x: x.get("timestamp", 0), reverse=True)
    
    return rows[:limit]
