"""Re-export hub for memory_store (split into parts, original 6911 lines).

Lazy re-export: parts are loaded on first attribute access (PEP 562),
not at import time, to keep cold start fast and keep behavior consistent
with the model_pool / circuit_breaker hubs.
"""
from __future__ import annotations
import importlib as _il
import logging as _logging
import warnings as _w

_PARTS: tuple[str, ...] = ("part1", "part2", "part3", "part4", "part5")
_cache: dict[str, object] | None = None

def _load() -> dict[str, object]:
    """Load parts once and cache public names; idempotent.

    Returns:
        dict[str, object]: A dictionary mapping public names to their respective objects.
    """
    global _cache
    if _cache is not None:
        return _cache
    _w.warn("memory_store has been split, import from specific part",
            DeprecationWarning, stacklevel=3)
    cache: dict[str, object] = {}
    for _n in _PARTS:
        try:
            _m = _il.import_module("._memory_store_parts." + _n, package=__package__)
            for _x in dir(_m):
                if not _x.startswith("_"):
                    cache[_x] = getattr(_m, _x)
        except Exception as _e:
            _logging.warning(f"Re-export {__name__}.{_n} failed: {_e}")
    _cache = cache
    return cache

def __getattr__(name: str) -> object:
    """Lazy load parts on first attribute access.

    Args:
        name (str): The name of the attribute to retrieve.

    Returns:
        object: The requested attribute.

    Raises:
        AttributeError: If the attribute does not exist.
    """
    if name.startswith("_"):
        raise AttributeError(name)
    cache = _load()
    try:
        return cache[name]
    except KeyError:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from None
