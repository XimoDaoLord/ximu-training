"""Accelerated multi-threaded segmented downloader for Ximu core."""
import glob
import json
import logging
import os
import re
import threading
import time
import urllib.request
import urllib.error
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

MAX_PART_RETRIES = 3
RETRY_BASE_DELAY = 2.0
ORPHAN_CLEANUP_DAYS = 7


class AcceleratedDownloader:
    """ADMM 式多线程分段下载器。"""

    DEFAULT_CHUNKS = 8
    MIN_CHUNK_SIZE = 1024 * 1024
    MAX_CHUNKS = 32
    _ALLOWED_SCHEMES = ('http', 'https')

    def __init__(self, download_dir: Optional[str] = None) -> None:
        """初始化下载器。"""
        self.download_dir = download_dir or os.path.join(
            os.environ.get("XIMU_DATA_ROOT", os.getcwd()), "downloads"
        )
        os.makedirs(self.download_dir, exist_ok=True)
        self._tasks: Dict[str, dict] = {}
        self._lock = threading.Lock()
        self._last_state_save = 0.0
        self._state_file = os.path.join(self.download_dir, ".state.json")
        self._load_state()
        self._cleanup_orphan_files()

    def start(self, url: str, filename: Optional[str] = None, chunks: Optional[int] = None, headers: Optional[Dict[str, str]] = None) -> Dict[str, any]:
        """开始一个加速下载任务。"""
        if not self._valid_url(url):
            raise ValueError(f"仅支持 http/https 下载地址: {url[:80]}")
        if chunks is None:
            chunks = self.DEFAULT_CHUNKS
        chunks = max(1, min(int(chunks), self.MAX_CHUNKS))
        task_id = f"dl_{int(time.time() * 1000)}_{os.getpid()}"
        fname = filename or self._guess_filename(url)
        safe_name = re.sub(r'[\\/:*?"<>|]', "_", os.path.basename(fname)) or "download.bin"
        dest = os.path.join(self.download_dir, safe_name)

        with self._lock:
            for ex in self._tasks.values():
                if ex.get("dest") != dest:
                    continue
                complete = ex.get("total", 0) > 0 and os.path.exists(dest) and os.path.getsize(dest) == ex.get("total")
                if complete:
                    ex["status"] = "finished"
                    return self.status(ex["task_id"])
                if ex.get("status") in ("running", "paused", "error", "pending"):
                    return self._handle_existing_task(ex)

            probe_result = self._probe(url, headers or {})
            state = {
                "task_id": task_id, "url": url, "filename": safe_name, "dest": dest,
                "total": probe_result[0], "downloaded": 0, "chunks": chunks if probe_result[1] else 1,
                "status": "running", "speed_bps": 0.0, "eta_sec": None, "started_at": time.time(),
                "finished_at": None, "error": None, "parts": []
            }
            self._tasks[task_id] = state

        threading.Thread(target=self._run, args=(task_id, headers or {}), daemon=True).start()
        return self.status(task_id)

    def _handle_existing_task(self, ex: Dict[str, any]) -> Dict[str, any]:
        """处理已存在的相同目标任务。"""
        with self._lock:
            if ex.get("status") == "paused":
                return self.resume(ex["task_id"])
            return self.status(ex["task_id"])

    def status(self, task_id: str) -> Dict[str, any]:
        """查询任务状态。"""
        with self._lock:
            st = self._tasks.get(task_id)
            if not st:
                return {"task_id": task_id, "status": "not_found"}
            return dict(st)

    def list(self) -> List[Dict[str, any]]:
        """列出全部任务。"""
        with self._lock:
            return [dict(v) for v in sorted(self._tasks.values(), key=lambda x: x.get("started_at", 0), reverse=True)]

    def cancel(self, task_id: str) -> Dict[str, any]:
        """取消任务。"""
        with self._lock:
            st = self._tasks.get(task_id)
            if not st:
                return {"task_id": task_id, "status": "not_found"}
            if st.get("status") in ("running", "pending", "paused"):
                st["status"] = "cancelled"
                st["finished_at"] = time.time()
                self._save_state()
                return dict(st)
            return {"task_id": task_id, "status": "not_found"}

    def pause(self, task_id: str) -> Dict[str, any]:
        """暂停任务。"""
        with self._lock:
            st = self._tasks.get(task_id)
            if not st:
                return {"task_id": task_id, "status": "not_found"}
            if st.get("status") == "running":
                st["status"] = "paused"
                self._save_state()
                return dict(st)
            return {"task_id": task_id, "status": "not_found"}

    def resume(self, task_id: str) -> Dict[str, any]:
        """继续 / 断点续传任务。"""
        with self._lock:
            st = self._tasks.get(task_id)
            if not st:
                return {"task_id": task_id, "status": "not_found"}
            if st.get("total", 0) > 0 and os.path.exists(st["dest"]) and os.path.getsize(st["dest"]) == st["total"]:
                st["status"] = "finished"
                self._save_state()
                return dict(st)
            if st.get("status") in ("paused", "error", "running", "pending"):
                st["status"] = "running"
                st["error"] = None
                threading.Thread(target=self._run, args=(task_id, {}), daemon=True).start()
                return dict(st)
            return {"task_id": task_id, "status": "not_found"}

    def resume_all(self) -> List[Dict[str, any]]:
        """启动时把所有未完成任务重新入队续传。"""
        with self._lock:
            ids = [
                tid for tid, st in list(self._tasks.items())
                if st.get("status") in ("paused", "error", "running", "pending")
                and not (st.get("total", 0) > 0 and os.path.exists(st.get("dest", "")) and os.path.getsize(st["dest"]) == st["total"])
            ]
        return [self.resume(tid) for tid in ids]

    def _valid_url(self, url: str) -> bool:
        """校验 URL 是否合法。"""
        try:
            scheme = url.split("://", 1)[0].lower()
            return scheme in self._ALLOWED_SCHEMES
        except Exception:
            return False

    def _probe(self, url: str, headers: Dict[str, str]) -> Tuple[int, bool, str]:
        """探测文件信息与Range支持。"""
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                total = int(resp.headers.get('Content-Length', 0))
                accept_ranges = resp.headers.get('Accept-Ranges', 'none').lower() == 'bytes'
                return total, accept_ranges, resp.headers.get('Content-Type', '')
        except Exception as e:
            raise RuntimeError(f"Probe failed: {e}")

    def _guess_filename(self, url: str) -> str:
        """从URL猜测文件名。"""
        path = url.split('?')[0].split('/')[-1]
        return path or f"download_{int(time.time())}.bin"

    def _load_state(self) -> None:
        """加载任务状态。"""
        if not os.path.exists(self._state_file):
            return
        try:
            with open(self._state_file, 'r') as f:
                self._tasks.update(json.load(f))
        except Exception:
            pass

    def _save_state(self) -> None:
        """保存任务状态。"""
        with open(self._state_file, 'w') as f:
            json.dump(self._tasks, f)

    def _cleanup_orphan_files(self) -> None:
        """清理孤儿文件。"""
        for f in glob.glob(os.path.join(self.download_dir, '*.part')):
            if time.time() - os.path.getmtime(f) > ORPHAN_CLEANUP_DAYS * 86400:
                os.remove(f)

    def _run(self, task_id: str, headers: Dict[str, str]) -> None:
        """执行下载任务。"""
        # 简化实现，实际应分段并发下载
        pass
