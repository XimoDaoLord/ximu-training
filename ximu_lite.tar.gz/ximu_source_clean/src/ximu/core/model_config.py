# -*- coding: utf-8 -*-
"""统一模型配置加载器（ModelConfig）。

所有模型名称、类型、路径、维度等信息从此处读取，禁止在业务代码中写死。
配置文件：<project_root>/config/model_config.yaml
"""
from __future__ import annotations

import copy
import logging
import os
import threading
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger("src.ximu.core.model_config")
_CONFIG_TTL_SECONDS = 60.0

_DEFAULTS: Dict[str, Any] = {
    "model_dir": "本地模型",
    "required_models": [
        {"key": "embedding.primary", "name": "jina-v5-text-small", "type": "embedding",
         "file": "jina-embeddings-v5-text-small", "dim": 1024,
         "required": True, "call_trigger": "用户输入需要向量化时自动触发"},
        {"key": "vlm", "name": "minicpm-v4.6", "type": "vlm",
         "file": "minicpm-v4.6.gguf",
         "required": True, "call_trigger": "用户上传图像或需要视觉理解时触发"},
        {"key": "asr", "name": "sensevoice-small", "type": "asr",
         "file": "sensevoice-small.onnx",
         "required": True, "call_trigger": "用户输入语音时自动触发"},
        {"key": "tts", "name": "cosyvoice-300m", "type": "tts",
         "file": "cosyvoice-300m.pt",
         "required": True, "call_trigger": "需要生成语音回复时触发"},
        {"key": "ocr", "name": "glm-ocr", "type": "ocr",
         "file": "glm-ocr.onnx",
         "required": True, "call_trigger": "用户上传文档或图片需要识别文字时触发"},
        {"key": "object_detection", "name": "yolov8n", "type": "object_detection",
         "file": "yolov8n.pt",
         "required": True, "call_trigger": "实时视频流或图像需要检测目标时触发"},
    ],
    "optional_models": [
        {"key": "llm.primary", "name": "qwen2.5-3b", "type": "llm",
         "file": "qwen2.5-3b.gguf", "ram_required_gb": 6.0,
         "required": False, "call_trigger": "云端模型不可用且内存≥6GB时触发"},
        {"key": "llm.fallback", "name": "qwen2.5-1.5b", "type": "llm",
         "file": "qwen2.5-1.5b.gguf", "ram_required_gb": 4.0,
         "required": False, "call_trigger": "云端模型不可用且4GB≤内存<6GB时触发"},
        {"key": "llm.tiny", "name": "qwen2.5-0.5b", "type": "llm",
         "file": "qwen2.5-0.5b.gguf", "ram_required_gb": 2.0,
         "required": False, "call_trigger": "云端模型不可用且内存<4GB时触发"},
    ],
    "cloud_models": [],
    "type_index": {
        "embedding": ["embedding.primary"],
        "llm": ["llm.primary", "llm.fallback", "llm.tiny"],
        "vlm": ["vlm"],
        "asr": ["asr"],
        "tts": ["tts"],
        "ocr": ["ocr"],
        "object_detection": ["object_detection"],
    },
    "extensions": {"auto_discovery": False, "validation_mode": "strict"},
    "device_thresholds": {
        "low_memory_gb": 4.0,
        "high_cpu_percent": 90.0,
        "low_disk_gb": 5.0,
        "resource_check_cache_seconds": 60,
    },
}

_REQUIRED_FIELDS = ("name", "type", "call_trigger")
_VALIDATED_KEYS = frozenset({
    "embedding.primary", "embedding.fallback",
    "llm.primary", "llm.fallback", "llm.tiny",
    "vlm", "ocr", "asr", "tts", "object_detection",
})


class ModelConfig:
    """统一模型配置加载器，支持懒加载和缓存。"""

    def __init__(self, config_path: Optional[str] = None) -> None:
        self._config_path = config_path or os.environ.get(
            "XIMU_MODEL_CONFIG", self._resolve_default_path()
        )
        self._data: Dict[str, Any] = dict(_DEFAULTS)
        self._index: Dict[str, Dict[str, Any]] = {}
        self._mtime: float = 0.0
        self._cache_expires: float = 0.0
        self._lock = threading.RLock()

    @staticmethod
    def _resolve_default_path() -> str:
        """定位默认配置文件路径。"""
        here = os.path.dirname(os.path.abspath(__file__))
        root = os.path.abspath(os.path.join(here, "..", "..", ".."))
        return os.path.join(root, "config", "model_config.yaml")

    @staticmethod
    def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
        """递归合并两个字典，override 覆盖 base。"""
        result = dict(base)
        for k, v in override.items():
            if k in result and isinstance(result[k], dict) and isinstance(v, dict):
                result[k] = ModelConfig._deep_merge(result[k], v)
            else:
                result[k] = copy.deepcopy(v)
        return result

    @staticmethod
    def _build_index(raw: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
        """将 YAML 中的列表结构构建为以 key 为索引的字典。"""
        index: Dict[str, Dict[str, Any]] = {}
        for section in ("required_models", "optional_models", "cloud_models"):
            for entry in raw.get(section, []):
                if isinstance(entry, dict) and entry.get("key"):
                    index[entry["key"]] = entry
        return index

    @staticmethod
    def _validate_raw(raw: Dict[str, Any], path: str) -> None:
        """校验用户显式提供的条目是否含必填字段。"""
        for section in ("required_models", "optional_models"):
            entries = raw.get(section, [])
            if not isinstance(entries, list):
                continue
            for entry in entries:
                if not isinstance(entry, dict):
                    continue
                key = entry.get("key")
                if key not in _VALIDATED_KEYS:
                    continue
                for field_name in _REQUIRED_FIELDS:
                    if not entry.get(field_name):
                        raise ValueError(
                            f"ModelConfig 配置校验失败: '{key}' 缺少必填字段 '{field_name}'"
                            f"（路径: {path}）"
                        )

    def _load(self) -> Dict[str, Any]:
        """加载配置文件，支持 TTL 缓存和 mtime 检测。"""
        now = time.time()
        with self._lock:
            if now < self._cache_expires:
                return self._data
            try:
                import yaml
            except ImportError:
                logger.warning("PyYAML 未安装，使用内置默认模型配置")
                return self._data

            try:
                stat = os.stat(self._config_path)
                if stat.st_mtime == self._mtime and self._data:
                    self._cache_expires = now + _CONFIG_TTL_SECONDS
                    return self._data
            except OSError:
                return self._data

            with open(self._config_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            if not isinstance(data, dict):
                raise ValueError(f"ModelConfig YAML 顶层必须是映射: {self._config_path}")

            self._validate_raw(data, self._config_path)
            self._data = self._deep_merge(dict(_DEFAULTS), data)
            self._index = self._build_index(self._data)
            try:
                self._mtime = os.stat(self._config_path).st_mtime
            except OSError:
                pass
            self._cache_expires = now + _CONFIG_TTL_SECONDS
            return self._data

    def get_model_dir(self) -> str:
        """获取本地模型存储目录路径。"""
        return self._load().get("model_dir", "本地模型")

    def resolve_model_path(self, key: str) -> str:
        """解析指定模型 key 的本地文件路径。"""
        entry = self.get_model_by_key(key)
        if not entry:
            raise KeyError(f"未找到模型配置: {key}")
        model_dir = self.get_model_dir()
        filename = entry.get("file", "")
        return os.path.join(model_dir, filename) if filename else model_dir

    def get_model_by_key(self, key: str) -> Optional[Dict[str, Any]]:
        """按 key 查询模型配置条目。"""
        data = self._load()
        return data.get("index", {}).get(key) or self._index.get(key)

    def get_embedding_primary(self) -> Dict[str, Any]:
        """获取主嵌入模型配置。"""
        return self.get_model_by_key("embedding.primary") or {}

    def get_llm_primary(self) -> Dict[str, Any]:
        """获取主 LLM 模型配置。"""
        return self.get_model_by_key("llm.primary") or {}

    def get_llm_fallback(self) -> Dict[str, Any]:
        """获取 LLM 备用模型配置。"""
        return self.get_model_by_key("llm.fallback") or {}

    def get_llm_tiny(self) -> Dict[str, Any]:
        """获取 LLM 轻量模型配置。"""
        return self.get_model_by_key("llm.tiny") or {}

    def get_vlm(self) -> Dict[str, Any]:
        """获取视觉语言模型配置。"""
        return self.get_model_by_key("vlm") or {}

    def get_asr(self) -> Dict[str, Any]:
        """获取语音识别模型配置。"""
        return self.get_model_by_key("asr") or {}

    def get_tts(self) -> Dict[str, Any]:
        """获取语音合成模型配置。"""
        return self.get_model_by_key("tts") or {}

    def get_ocr(self) -> Dict[str, Any]:
        """获取 OCR 模型配置。"""
        return self.get_model_by_key("ocr") or {}

    def get_object_detection(self) -> Dict[str, Any]:
        """获取目标检测模型配置。"""
        return self.get_model_by_key("object_detection") or {}

    def get_dim(self, model_type: str = "embedding") -> int:
        """获取指定模型类型的向量维度。"""
        entries = self._load().get("type_index", {}).get(model_type, [])
        for key in entries:
            model = self.get_model_by_key(key)
            if model and model.get("dim"):
                return int(model["dim"])
        return 0

    def get_cloud_free_models(self) -> List[str]:
        """获取免费云端模型列表。"""
        return [m.get("model_id", "") for m in self._load().get("cloud_models", []) if m.get("free")]

    def get_device_thresholds(self) -> Dict[str, Any]:
        """获取设备资源阈值配置。"""
        return self._load().get("device_thresholds", {})

    def get_required_models(self) -> List[Dict[str, Any]]:
        """获取必需模型列表。"""
        return self._load().get("required_models", [])

    def get_optional_models(self) -> List[Dict[str, Any]]:
        """获取可选模型列表。"""
        return self._load().get("optional_models", [])

    def get_cloud_models(self) -> List[Dict[str, Any]]:
        """获取云端模型列表。"""
        return self._load().get("cloud_models", [])

    def should_download_optional_llm(self) -> Optional[str]:
        """判断是否应下载可选 LLM 模型。"""
        llm_keys = ["llm.primary", "llm.fallback", "llm.tiny"]
        for key in llm_keys:
            entry = self.get_model_by_key(key)
            if entry and not entry.get("required") and entry.get("download_url"):
                return key
        return None

    def get_type_index(self) -> Dict[str, List[str]]:
        """获取模型类型索引。"""
        return self._load().get("type_index", {})

    def get_extensions(self) -> Dict[str, Any]:
        """获取扩展配置。"""
        return self._load().get("extensions", {})

    def is_model_extendable(self, key: str) -> bool:
        """判断模型是否支持扩展。"""
        entry = self.get_model_by_key(key)
        return bool(entry and entry.get("extendable", False))

    @classmethod
    def instance(cls) -> "ModelConfig":
        """获取全局单例配置实例。"""
        if not hasattr(cls, "_instance"):
            cls._instance = cls()
        return cls._instance

    @classmethod
    def get_model_config(cls) -> "ModelConfig":
        """获取全局模型配置实例的别名方法。"""
        return cls.instance()


def get_model_config() -> ModelConfig:
    """获取全局模型配置实例。"""
    return ModelConfig.instance()
