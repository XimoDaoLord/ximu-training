"""核心数据根目录管理与路径访问模块。"""
import os
import logging
from typing import List, Dict, Any, Tuple

logger = logging.getLogger(__name__)

_HERE = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
_ANDROID_ROOT = "/data/user/0/com.ximu.imperium/files"
_ENV_KEY = "XIMU_DATA_ROOT"

USER_DIR = "用户数据"
CLEAN_DIR = "干净数据"
CLIENT_DIR = "客户端数据"
WASTE_DIR = "废弃数据"

USER_SUBDIRS: Dict[str, str] = {
    "uploads": "上传的文件",
    "chat_root": "聊天与记忆",
    "memory_layers": "聊天与记忆/各层记忆",
    "vector_index": "聊天与记忆/向量索引",
    "knowledge_graph": "聊天与记忆/知识图谱",
    "error_learning": "错误与学习/错误学习",
    "experience": "错误与学习/经验库",
    "config_secrets": "配置与密钥",
    "tasks": "任务与编排",
    "artifacts": "产物与快照/任务产物",
    "snapshots": "产物与快照/快照",
    "cache_sandbox": "缓存/沙箱",
    "cache_pool": "缓存/上下文池",
    "cache_runtime": "缓存/运行时",
    "cache_backups": "缓存/备份",
    "cache_market": "缓存/市场缓存",
    "cache_workflows": "缓存/工作流",
    "logs": "日志",
    "audit": "审计",
    "model_usage": "模型与用量",
    "personality": "人格与角色卡",
    "templates": "模板",
    "connectors": "连接器与工具",
    "local_models": "本地模型",
    "local_model_market": "本地模型/市场缓存",
    "telemetry": "遥测与事件",
    "asset_meta": "资产元数据",
    "compressed_records": "压缩记录",
    "transit": "中转池",
}

CLEAN_SUBDIRS: Dict[str, str] = {
    "memory_purified": "记忆提纯",
    "error_purified": "错误学习提纯",
    "knowledge_conclusion": "知识结论",
}


def _normalize(path: str) -> str:
    """路径归一化。"""
    return os.path.normpath(os.path.abspath(path))


def _ensure(path: str) -> str:
    """确保目录存在。"""
    p = _normalize(path)
    try:
        os.makedirs(p, exist_ok=True)
    except OSError as e:
        logger.warning("无法创建目录 %s: %s", p, e)
        raise
    return p


def project_root() -> str:
    """返回项目根目录。"""
    return _PROJECT_ROOT


def get_data_root() -> str:
    """集中返回数据根目录。"""
    env = os.environ.get(_ENV_KEY, "").strip()
    if env:
        root = env
    elif os.path.isdir(_ANDROID_ROOT):
        root = _ANDROID_ROOT
    else:
        root = os.path.join(_PROJECT_ROOT, "data")
    return _ensure(root)


def get_user_data_dir() -> str:
    """用户数据层。"""
    return _ensure(os.path.join(get_data_root(), USER_DIR))


def get_clean_data_dir() -> str:
    """干净数据层。"""
    return _ensure(os.path.join(get_data_root(), CLEAN_DIR))


def get_client_data_dir() -> str:
    """客户端层。"""
    return _ensure(os.path.join(get_data_root(), CLIENT_DIR))


def get_waste_data_dir() -> str:
    """废弃数据层。"""
    return _ensure(os.path.join(get_data_root(), WASTE_DIR))


def user_data_dir() -> str:
    """用户数据层根目录别名。"""
    return get_user_data_dir()


def clean_data_dir() -> str:
    """干净数据层根目录别名。"""
    return get_clean_data_dir()


def client_data_dir() -> str:
    """客户端层根目录别名。"""
    return get_client_data_dir()


def user_dir(key: str, *parts: str) -> str:
    """返回 用户数据/ 下某逻辑分类的路径。"""
    if key not in USER_SUBDIRS:
        raise KeyError(f"未知用户数据分类: {key!r}；可选: {sorted(USER_SUBDIRS)}")
    return _ensure(os.path.join(get_user_data_dir(), USER_SUBDIRS[key], *parts))


def clean_dir(key: str, *parts: str) -> str:
    """返回 干净数据/ 下某提纯分类路径。"""
    if key not in CLEAN_SUBDIRS:
        raise KeyError(f"未知干净数据分类: {key!r}；可选: {sorted(CLEAN_SUBDIRS)}")
    return _ensure(os.path.join(get_clean_data_dir(), CLEAN_SUBDIRS[key], *parts))


def clean_audit_path() -> str:
    """返回干净数据审计日志路径。"""
    return os.path.join(get_clean_data_dir(), "audit.jsonl")


def waste_audit_path() -> str:
    """返回废弃数据审计日志路径。"""
    return os.path.join(get_waste_data_dir(), "audit.jsonl")


def waste_record_dir() -> str:
    """废弃数据/记录/。"""
    return _ensure(os.path.join(get_waste_data_dir(), "记录"))


def chat_root_dir() -> str:
    """聊天与记忆/。"""
    return user_dir("chat_root")


def chat_db_path(filename: str = "chat.db") -> str:
    """聊天与记忆/<filename>。"""
    return os.path.join(chat_root_dir(), filename)


def ximu_db_path() -> str:
    """聊天与记忆/ximu.db。"""
    return os.path.join(chat_root_dir(), "ximu.db")


def vector_index_dir() -> str:
    """向量索引目录。"""
    return user_dir("vector_index")


def knowledge_graph_dir() -> str:
    """知识图谱目录。"""
    return user_dir("knowledge_graph")


def memory_layers_dir() -> str:
    """各层记忆目录。"""
    return user_dir("memory_layers")


def memory_dir() -> str:
    """记忆目录。"""
    return memory_layers_dir()


def error_learning_root() -> str:
    """错误与学习/ 根。"""
    return _ensure(os.path.join(get_user_data_dir(), "错误与学习"))


def learning_dir() -> str:
    """学习目录。"""
    return error_learning_root()
