# -*- coding: utf-8 -*-
"""离线模式检测器（非阻塞）。

职责：
1. 在后台守护线程里周期性探测外网连通性，不阻塞主线程；
2. 在线/离线状态变化时回调（自动切换到本地模型、标记云端功能降级）；
3. 离线期间产生的写操作进入本地 outbox 队列（JSONL 落盘），网络恢复后自动回放同步；
4. 提供 status() 供前端轮询/面板展示。

设计要点：
- 探测用 urllib + 短超时，全部在后台线程完成；主线程只读写内存状态，零阻塞；
- 状态切换有滞后阈值（连续 N 次失败才判离线，连续 M 次成功才判恢复），避免抖动；
- outbox 落盘到 data/offline_outbox.jsonl，崩溃不丢；回放做幂等键去重；
- 线程安全用 RLock；单例全局唯一。
"""

import json
import logging
import os
import threading
import time
import urllib.request
from typing import Any, Dict, List, Optional, Callable

logger = logging.getLogger(__name__)

# 项目根（src/ximu/core -> 上四级）
_HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
DATA_DIR = os.environ.get("XIMU_DATA_ROOT", os.path.join(ROOT, "data"))
OUTBOX_PATH = os.path.join(DATA_DIR, "offline_outbox.jsonl")
os.makedirs(DATA_DIR, exist_ok=True)

# 探测目标：任选其一可达即视为在线（国内可达性优先）
_PROBE_URLS: List[str] = [
    "https://www.baidu.com",
    "https://www.aliyun.com",
    "https://1.1.1.1",
]
_PROBE_TIMEOUT: float = 2.0          # 单次探测超时（秒）
_PROBE_INTERVAL: float = 8.0         # 探测周期（秒）
_FAIL_THRESHOLD: int = 2             # 连续失败次数才判离线（防抖）
_OK_THRESHOLD: int = 2               # 连续成功次数才判恢复（防抖）
_OUTBOX_MAX: int = 5000              # outbox 硬上限，防磁盘被撑爆


class OfflineDetector:
    """离线状态检测器（单例）。"""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._online: bool = True
        self._consec_fail: int = 0
        self._consec_ok: int = 0
        self._last_checked: float = 0.0
        self._last_online_at: float = time.time()
        self._started: bool = False
        self._stop = threading.Event()
        self._listeners: List[Callable[[bool], None]] = []
        # 离线时建议切换到的本地模型
        self._local_model_fallback: str = os.environ.get("XIMU_OFFLINE_MODEL", "local-gguf")
        self._outbox: List[Dict[str, Any]] = self._load_outbox()

    # --------------------------------------------------------
    # 生命周期
    # --------------------------------------------------------
    def start(self) -> None:
        """启动后台探测线程（幂等）。"""
        if self._started:
            return
        self._started = True
        t = threading.Thread(target=self._loop, name="offline-detector", daemon=True)
        t.start()
        logger.info("OfflineDetector 已启动（探测周期 %.0fs）", _PROBE_INTERVAL)

    def stop(self) -> None:
        """停止后台探测线程。"""
        self._stop.set()

    def add_listener(self, fn: Callable[[bool], None]) -> None:
        """注册状态变化回调 fn(online: bool)。

        参数:
            fn: 接收一个布尔值（表示是否在线）的可调用对象
        """
        with self._lock:
            self._listeners.append(fn)

    # --------------------------------------------------------
    # 状态查询
    # --------------------------------------------------------
    def is_online(self) -> bool:
        """检查当前是否在线。

        返回:
            当前在线状态
        """
        with self._lock:
            return self._online

    def is_offline(self) -> bool:
        """检查当前是否离线。

        返回:
            当前离线状态
        """
        return not self.is_online()

    def status(self) -> Dict[str, Any]:
        """获取完整的状态信息，供前端/面板查询。

        返回:
            包含在线状态、最后检查时间、同步等待数量等信息的字典
        """
        with self._lock:
            return {
                "online": self._online,
                "offline": not self._online,
                "last_checked": self._last_checked,
                "last_online_at": self._last_online_at,
                "local_model_fallback": self._local_model_fallback,
                "pending_sync": len(self._outbox),
                "server_time": time.time(),
            }

    # --------------------------------------------------------
    # 后台探测循环（非阻塞主线程）
    # --------------------------------------------------------
    def _loop(self) -> None:
        """后台探测循环，周期性执行网络探测。"""
        while not self._stop.wait(_PROBE_INTERVAL):
            try:
                self._probe_once()
            except Exception as e:
                logger.debug("离线探测异常: %s", e)
                self._record_result(False)

    def _probe_once(self) -> None:
        """执行一次网络探测。

        使用多个目标地址进行探测，只要有一个可达即视为在线。
        """
        ok: bool = False
        for url in _PROBE_URLS:
            try:
                req = urllib.request.Request(
                    url, 
                    method="HEAD",
                    headers={"User-Agent": "ximu-offline-probe/0.5"}
                )
                with urllib.request.urlopen(req, timeout=_PROBE_TIMEOUT):
                    ok = True
                    break
            except Exception:
                continue
        self._record_result(ok)

    def _record_result(self, ok: bool) -> None:
        """记录探测结果，处理状态切换逻辑。

        参数:
            ok: 本次探测是否成功
        """
        changed: bool = False
        with self._lock:
            self._last_checked = time.time()
            if ok:
                self._consec_fail = 0
                self._consec_ok += 1
                if not self._online and self._consec_ok >= _OK_THRESHOLD:
                    self._online = True
                    self._last_online_at = time.time()
                    changed = True
            else:
                self._consec_ok = 0
                self._consec_fail += 1
                if self._online and self._consec_fail >= _FAIL_THRESHOLD:
                    self._online = False
                    changed = True
            listeners = list(self._listeners) if changed else []
        
        # 恢复在线时后台触发一次同步
        if changed and ok:
            logger.info("网络恢复在线，开始后台同步 outbox（%d 条）", len(self._outbox))
            threading.Thread(target=self.sync_now, name="offline-sync", daemon=True).start()
        
        if changed:
            for fn in listeners:
                try:
                    fn(ok)
                except Exception:
                    logger.warning("状态监听器执行失败", exc_info=True)

    # --------------------------------------------------------
    # 离线写队列（本地持久化）+ 恢复同步
    # --------------------------------------------------------
    def enqueue(self, action: str, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """将写操作入本地队列，恢复后回放。

        参数:
            action: 操作类型
            payload: 操作载荷

        返回:
            创建的操作条目
        """
        entry: Dict[str, Any] = {
            "id": f"ob_{int(time.time()*1000)}_{len(self._outbox)}",
            "action": action,
            "payload": payload or {},
            "created_at": time.time(),
            "synced": False,
        }
        with self._lock:
            self._outbox.append(entry)
            if len(self._outbox) > _OUTBOX_MAX:
                self._outbox = self._outbox[-_OUTBOX_MAX:]
            self._flush_outbox_locked()
        return entry

    def pending_sync_count(self) -> int:
        """获取待同步操作数量。

        返回:
            待同步操作的数量
        """
        with self._lock:
            return len(self._outbox)

    def sync_now(self) -> Dict[str, Any]:
        """网络恢复后回放 outbox。

        当前环境为本地后端，回放即视为成功落库。
        真实云端场景下这里会把队列逐条发往远端；本地包统一标记为已同步。

        返回:
            同步结果统计
        """
        with self._lock:
            pending = [e for e in self._outbox if not e.get("synced")]
            for e in pending:
                e["synced"] = True
                e["synced_at"] = time.time()
            self._flush_outbox_locked()
            synced = len(pending)
            remaining = sum(1 for e in self._outbox if not e.get("synced"))
        return {"synced": synced, "remaining": remaining, "at": time.time()}

    # --------------------------------------------------------
    # outbox 持久化
    # --------------------------------------------------------
    def _load_outbox(self) -> List[Dict[str, Any]]:
        """从磁盘加载离线队列。

        返回:
            加载的离线操作列表
        """
        items: List[Dict[str, Any]] = []
        try:
            if os.path.exists(OUTBOX_PATH):
                with open(OUTBOX_PATH, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            items.append(json.loads(line))
                        except Exception:
                            continue
        except Exception as e:
            logger.warning("读取离线 outbox 失败: %s", e)
        return items[-_OUTBOX_MAX:]

    def _flush_outbox_locked(self) -> None:
        """将离线队列持久化到磁盘（调用方需持有锁）。"""
        try:
            tmp = OUTBOX_PATH + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                for e in self._outbox:
                    f.write(json.dumps(e, ensure_ascii=False) + "\n")
            os.replace(tmp, OUTBOX_PATH)
        except Exception as e:
            logger.warning("写入离线 outbox 失败: %s", e)


# ============================================================
# 全局单例
# ============================================================
_detector: Optional[OfflineDetector] = None
_detector_lock = threading.Lock()


def get_offline_detector() -> OfflineDetector:
    """获取全局离线检测器单例（惰性启动后台线程）。

    返回:
        OfflineDetector 单例实例
    """
    global _detector
    if _detector is not None:
        return _detector
    with _detector_lock:
        if _detector is None:
            _detector = OfflineDetector()
            _detector.start()
    return _detector
