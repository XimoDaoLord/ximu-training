# -*- coding: utf-8 -*-
"""
ASR 语音转文字服务（云 ↔ 本地兜底链）

优先级：
  1. 本地 sherpa-onnx（离线，轻量）
  2. 本地 openai-whisper（离线，需模型已下载）
  3. 云 OpenAI Whisper API（需 OPENAI_KEY）
  4. 云 Gemini Audio（需 GOOGLE_GEMINI_KEY）
  5. 都不可用 → 诚实返回 need_setup + 指引

绝不编造转写结果。转写文本经 transit_hub sanitize_text 审计后返回。

版本: 0.5
"""

import os
import json
import logging
import tempfile
import subprocess
import urllib.request
import base64
import uuid
import wave
from typing import Optional, Dict, Any, List, Tuple

logger = logging.getLogger(__name__)

# MIME 类型映射表
_MIME_TYPES: Dict[str, str] = {
    "webm": "audio/webm",
    "ogg": "audio/ogg",
    "wav": "audio/wav",
    "mp3": "audio/mpeg",
    "m4a": "audio/mp4",
}


def _ensure_wav16k(audio_bytes: bytes, src_ext: str) -> Tuple[str, str]:
    """
    将任意音频格式转换为 16kHz 单声道 WAV。
    
    Args:
        audio_bytes: 原始音频二进制数据。
        src_ext: 源文件扩展名（不含点）。
    
    Returns:
        元组 (输入临时文件路径, 输出临时文件路径)。
        若转换失败，返回 (输入路径, 输入路径)。
    """
    tmp_in = tempfile.NamedTemporaryFile(suffix=f".{src_ext}", delete=False)
    tmp_out = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
    
    try:
        tmp_in.write(audio_bytes)
        tmp_in.flush()
        tmp_in.close()
        
        try:
            subprocess.run(
                ["ffmpeg", "-y", "-i", tmp_in.name,
                 "-ar", "16000", "-ac", "1", "-f", "wav", tmp_out.name],
                capture_output=True, timeout=30, check=True
            )
            if os.path.getsize(tmp_out.name) > 100:
                return tmp_in.name, tmp_out.name
            else:
                logger.warning("ffmpeg 转换后文件大小异常，回退使用原始文件")
                return tmp_in.name, tmp_in.name
        except (subprocess.SubprocessError, OSError) as e:
            logger.warning("ffmpeg 转换失败: %s", e)
            return tmp_in.name, tmp_in.name
            
    except Exception as e:
        logger.error("处理临时文件异常: %s", e)
        return tmp_in.name, tmp_in.name


def _cleanup(*paths: str) -> None:
    """
    清理指定的临时文件路径。
    
    Args:
        *paths: 待清理的文件路径。
    """
    for p in paths:
        if p and os.path.exists(p):
            try:
                os.unlink(p)
            except OSError as e:
                logger.debug("清理临时文件失败 %s: %s", p, e)


def _sanitize(text: str) -> str:
    """
    通过 transit_hub 统一脱敏审计通道。
    
    Args:
        text: 待脱敏的文本。
    
    Returns:
        脱敏后的文本。
    """
    try:
        from src.ximu.core.transit_hub import sanitize_text
        return sanitize_text(text or "")
    except Exception:
        # 审计模块缺失时，保证核心功能可用，记录警告
        logger.warning("无法加载 transit_hub 审计模块，跳过脱敏")
        return text or ""


def _try_local_sherpa(wav_path: str, language: str = "zh") -> Optional[Dict[str, Any]]:
    """
    尝试使用本地 sherpa-onnx 引擎进行识别。
    
    Args:
        wav_path: 16kHz 单声道 WAV 文件路径。
        language: 识别语言代码。
    
    Returns:
        识别结果字典，或 None（若引擎不可用或识别失败）。
    """
    try:
        import sherpa_onnx
        import numpy as np
    except ImportError:
        return None

    try:
        model_path = os.environ.get("XIMU_SHERPA_MODEL", "")
        tokens_path = os.environ.get("XIMU_SHERPA_TOKENS", "")
        
        if not model_path or not tokens_path:
            return None

        recognizer = sherpa_onnx.OfflineRecognizer.from_sense_voice(
            model=model_path,
            tokens=tokens_path,
            use_itn=True
        )
        stream = recognizer.create_stream()
        
        with wave.open(wav_path, "rb") as wf:
            frames = wf.readframes(wf.getnframes())
            samples = np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0
        
        stream.accept_waveform(16000, samples)
        recognizer.decode_stream(stream)
        
        text = stream.result.text.strip()
        if text:
            return {"text": text, "engine": "local_sherpa", "language": language}
        
    except Exception as e:
        logger.debug("sherpa-onnx 识别失败: %s", e)
        
    return None


def _try_local_whisper(wav_path: str, language: str = "zh") -> Optional[Dict[str, Any]]:
    """
    尝试使用本地 openai-whisper 引擎进行识别。
    
    Args:
        wav_path: WAV 文件路径。
        language: 识别语言代码。
    
    Returns:
        识别结果字典，或 None。
    """
    try:
        import whisper
    except ImportError:
        return None

    try:
        model_name = os.environ.get("XIMU_WHISPER_MODEL", "base")
        model = whisper.load_model(model_name)
        result = model.transcribe(wav_path, language=language)
        text = (result.get("text") or "").strip()
        
        if text:
            return {"text": text, "engine": "local_whisper", "language": language}
            
    except Exception as e:
        logger.debug("本地 whisper 识别失败: %s", e)
        
    return None


def _build_multipart_body(audio_bytes: bytes, filename: str, language: str) -> Tuple[bytes, str, str]:
    """
    构建 OpenAI Whisper API 的 multipart/form-data 请求体。
    
    Args:
        audio_bytes: 音频二进制数据。
        filename: 文件名。
        language: 语言代码。
    
    Returns:
        元组 (请求体字节, Content-Type, 边界字符串)。
    """
    boundary = "----ximu" + uuid.uuid4().hex
    ext = filename.rsplit(".", 1)[-1] if "." in filename else "webm"
    mime = _MIME_TYPES.get(ext, "application/octet-stream")
    
    content_disposition_file = f'Content-Disposition: form-data; name="file"; filename="audio.{ext}"'
    content_disposition_model = 'Content-Disposition: form-data; name="model"'
    content_disposition_lang = 'Content-Disposition: form-data; name="language"'
    
    body_start = (
        f"--{boundary}\r\n"
        f"{content_disposition_file}\r\n"
        f"Content-Type: {mime}\r\n\r\n"
    ).encode()
    
    body_end = (
        f"\r\n--{boundary}\r\n"
        f"{content_disposition_model}\r\n\r\n"
        f"whisper-1\r\n"
        f"--{boundary}\r\n"
        f"{content_disposition_lang}\r\n\r\n"
        f"{language}\r\n"
        f"--{boundary}--\r\n"
    ).encode()
    
    full_body = body_start + audio_bytes + body_end
    content_type = f"multipart/form-data; boundary={boundary}"
    
    return full_body, content_type, boundary


def _try_cloud_openai(audio_bytes: bytes, filename: str, language: str = "zh") -> Optional[Dict[str, Any]]:
    """
    尝试使用云 OpenAI Whisper API 进行识别。
    
    Args:
        audio_bytes: 音频二进制数据。
        filename: 文件名（用于确定 MIME 类型）。
        language: 语言代码。
    
    Returns:
        识别结果字典，或 None。
    """
    api_key = os.environ.get("OPENAI_KEY", "").strip()
    if not api_key:
        return None

    base_url = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    body, content_type, _ = _build_multipart_body(audio_bytes, filename, language)
    
    try:
        req = urllib.request.Request(
            f"{base_url}/audio/transcriptions",
            data=body,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": content_type
            },
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            
        text = (data.get("text") or "").strip()
        if text:
            return {"text": text, "engine": "cloud_openai", "language": language}
            
    except Exception as e:
        logger.debug("云 OpenAI ASR 调用失败: %s", e)
        
    return None


def _try_cloud_gemini(audio_bytes: bytes, filename: str, language: str = "zh") -> Optional[Dict[str, Any]]:
    """
    尝试使用云 Gemini Audio API 进行识别。
    
    Args:
        audio_bytes: 音频二进制数据。
        filename: 文件名。
        language: 语言代码。
    
    Returns:
        识别结果字典，或 None。
    """
    api_key = os.environ.get("GOOGLE_GEMINI_KEY", "").strip()
    if not api_key:
        return None

    try:
        ext = filename.rsplit(".", 1)[-1] if "." in filename else "webm"
        mime = _MIME_TYPES.get(ext, "audio/mp4")
        b64_data = base64.b64encode(audio_bytes).decode("ascii")
        
        prompt = f"请将这段{language}语音转写为纯文字，只输出转写结果，不要解释。"
        payload = {
            "contents": [{
                "parts": [
                    {"text": prompt},
                    {"inline_data": {"mime_type": mime, "data": b64_data}}
                ]
            }]
        }
        
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={api_key}"
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            
        text = data["candidates"][0]["content"]["parts"][0]["text"].strip()
        if text:
            return {"text": text, "engine": "cloud_gemini", "language": language}
            
    except Exception as e:
        logger.debug("云 Gemini ASR 调用失败: %s", e)
        
    return None


def _get_setup_suggestions() -> List[str]:
    """
    获取当所有引擎不可用时的配置建议。
    
    Returns:
        建议列表。
    """
    return [
        "方案A（本地离线）: pip install openai-whisper && 设置 XIMU_WHISPER_MODEL=base",
        "方案B（本地离线）: pip install sherpa-onnx 并下载 SenseVoice 模型",
        "方案C（云端）: 在 .env 配置 OPENAI_KEY（Whisper API）或 GOOGLE_GEMINI_KEY",
        "配置后无需重启，下次录音自动走对应引擎",
    ]


def transcribe(audio_bytes: bytes, filename: str = "audio.webm",
               language: str = "zh") -> Dict[str, Any]:
    """
    主入口：接收音频字节，通过引擎链返回转写结果。
    
    优先级：本地 sherpa > 本地 whisper > 云 OpenAI > 云 Gemini。
    
    Args:
        audio_bytes: 音频二进制数据。
        filename: 文件名（用于提取扩展名）。
        language: 目标语言代码。
    
    Returns:
        结果字典:
        - 成功: {"success": True, "text": "...", "engine": "..."}
        - 失败: {"success": False, "status": "bad_audio" | "need_setup", ...}
    """
    if not audio_bytes or len(audio_bytes) < 100:
        return {
            "success": False,
            "status": "bad_audio",
            "message": "音频数据为空或过短",
            "text": ""
        }

    ext = filename.rsplit(".", 1)[-1] if "." in filename else "webm"
    wav_in_path, wav_out_path = _ensure_wav16k(audio_bytes, ext)
    
    try:
        # 1. 本地 sherpa
        result = _try_local_sherpa(wav_out_path, language)
        if result:
            result["text"] = _sanitize(result["text"])
            result["success"] = True
            logger.info("ASR 成功 (local_sherpa): %s 字", len(result["text"]))
            return result

        # 2. 本地 whisper
        result = _try_local_whisper(wav_out_path, language)
        if result:
            result["text"] = _sanitize(result["text"])
            result["success"] = True
            logger.info("ASR 成功 (local_whisper): %s 字", len(result["text"]))
            return result

        # 3. 云 OpenAI
        result = _try_cloud_openai(audio_bytes, filename, language)
        if result:
            result["text"] = _sanitize(result["text"])
            result["success"] = True
            logger.info("ASR 成功 (cloud_openai): %s 字", len(result["text"]))
            return result

        # 4. 云 Gemini
        result = _try_cloud_gemini(audio_bytes, filename, language)
        if result:
            result["text"] = _sanitize(result["text"])
            result["success"] = True
            logger.info("ASR 成功 (cloud_gemini): %s 字", len(result["text"]))
            return result

        # 全部不可用
        return {
            "success": False,
            "status": "need_setup",
            "message": "未检测到可用的 ASR（语音转文字）引擎",
            "text": "",
            "suggestions": _get_setup_suggestions()
        }
        
    finally:
        _cleanup(wav_in_path, wav_out_path)


def health_check() -> Dict[str, Any]:
    """
    检查各 ASR 引擎的可用性状态。
    
    Returns:
        字典，包含各引擎的布尔状态及 'any_available' 汇总。
    """
    status: Dict[str, bool] = {}
    
    try:
        import sherpa_onnx  # noqa: F401
        status["local_sherpa"] = True
    except ImportError:
        status["local_sherpa"] = False
        
    try:
        import whisper  # noqa: F401
        status["local_whisper"] = True
    except ImportError:
        status["local_whisper"] = False
        
    status["cloud_openai"] = bool(os.environ.get("OPENAI_KEY", "").strip())
    status["cloud_gemini"] = bool(os.environ.get("GOOGLE_GEMINI_KEY", "").strip())
    status["any_available"] = any(status.values())
    
    return status
