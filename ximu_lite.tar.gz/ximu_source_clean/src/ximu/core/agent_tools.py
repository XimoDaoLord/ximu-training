"""子任务模型的真实工具调用回路（function-calling agent loop）。

把"查看/修改项目文件"的能力以 OpenAI tools 形式注入子任务模型：
模型返回 tool_calls -> 本模块在项目根内真实执行 -> 结果回灌 -> 多轮直到给出最终答复。
全程经 ModelEgressGate（唯一通道），文件操作限定在项目根安全沙箱内，越界路径拒绝。

版本: 0.5
"""

import json
import logging
import os
import re
import time
import urllib.request
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

__version__ = "0.5"


def default_project_root() -> Path:
    """项目根：本文件位于 <root>/src/ximu/core/agent_tools.py，上溯 4 级即 <root>。"""
    return Path(__file__).resolve().parents[3]


_SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", ".idea",
              ".skills", ".doubao", "dist", "build", ".pytest_cache"}
_TEXT_EXT = {".py", ".js", ".md", ".json", ".txt", ".html", ".css", ".yaml",
             ".yml", ".toml", ".ini", ".cfg", ".sh", ".ts", ".csv"}
_MAX_READ_BYTES = 60000
_MAX_LIST = 200

_PROTECTED_NAMES = {
    "package.json", "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
    "pyproject.toml", "setup.py", "setup.cfg", "pipfile", "pipfile.lock",
    "poetry.lock", "changelog.md", "readme.md", "license", "licence",
    "manifest.in", "dockerfile", "docker-compose.yml", "docker-compose.yaml"}
_PROTECTED_SUFFIX = (".pem", ".key", ".keystore")
_CURRENT_PROMPT = ""

TOOL_SCHEMAS: List[Dict[str, Any]] = [
    {"type": "function", "function": {
        "name": "list_dir",
        "description": "列出项目内某个目录的文件与子目录；不传 path 则列出项目根。用于了解真实项目结构。",
        "parameters": {"type": "object", "properties": {
            "path": {"type": "string", "description": "相对项目根的目录路径，留空为根"}},
        "required": []}}},
    {"type": "function", "function": {
        "name": "read_file",
        "description": "读取项目内某个文本文件的内容（带行号，超长自动截断）。",
        "parameters": {"type": "object", "properties": {
            "path": {"type": "string", "description": "相对项目根的文件路径"},
            "start_line": {"type": "integer", "description": "起始行(从1开始)，默认1"},
            "max_lines": {"type": "integer", "description": "最多读取行数，默认400"}},
        "required": ["path"]}}},
    {"type": "function", "function": {
        "name": "write_file",
        "description": "写入/覆盖项目内的文本文件（修复代码、更新文档）。写入前自动生成 .bak_agent 备份。",
        "parameters": {"type": "object", "properties": {
            "path": {"type": "string", "description": "相对项目根的文件路径"},
            "content": {"type": "string", "description": "完整的新文件内容"}},
        "required": ["path", "content"]}}},
    {"type": "function", "function": {
        "name": "search_files",
        "description": "按文件名关键字搜索项目内文件；content 非空时改为按文件内容关键字检索。",
        "parameters": {"type": "object", "properties": {
            "query": {"type": "string", "description": "文件名关键字"},
            "content": {"type": "string", "description": "文件内容关键字（可选）"},
            "path": {"type": "string", "description": "搜索起始目录，默认整个项目"}},
        "required": ["query"]}}},
    {"type": "function", "function": {
        "name": "browser_navigate",
        "description": "用浏览器打开指定URL，返回页面标题和文本内容。备选方案：API不稳定时用此工具访问网页。",
        "parameters": {"type": "object", "properties": {
            "url": {"type": "string", "description": "要访问的完整URL，如 http://127.0.0.1:5001"}},
        "required": ["url"]}}},
    {"type": "function", "function": {
        "name": "browser_snapshot",
        "description": "获取当前浏览器页面的无障碍快照（可交互元素列表），用于定位可点击/可输入的元素。",
        "parameters": {"type": "object", "properties": {}},
        "required": []}},
    {"type": "function", "function": {
        "name": "browser_click",
        "description": "点击页面上指定元素。需先调用browser_snapshot获取元素ref。",
        "parameters": {"type": "object", "properties": {
            "element": {"type": "string", "description": "元素描述"},
            "ref": {"type": "string", "description": "从snapshot获取的元素引用ID"}},
        "required": ["element"]}}},
    {"type": "function", "function": {
        "name": "browser_type",
        "description": "在指定输入框中输入文本。需先调用browser_snapshot获取元素ref。",
        "parameters": {"type": "object", "properties": {
            "element": {"type": "string", "description": "输入框描述"},
            "text": {"type": "string", "description": "要输入的文本"},
            "ref": {"type": "string", "description": "从snapshot获取的元素引用ID"}},
        "required": ["element", "text"]}}},
]
_TOOL_NAMES: List[str] = [t["function"]["name"] for t in TOOL_SCHEMAS]


def _safe_resolve(root: Path, rel: str) -> Path:
    """把用户提供的路径解析为绝对路径，并确保不越出项目根。

    P179 修复：用户传入绝对路径（如 /home/user/.../app.py）时直接采用该路径，
    不再 lstrip('/') 后拼到项目根——否则会把绝对路径错误嵌套成
    <root>/home/user/...（出现 源码/home/user/... 这类垃圾目录与 .bak_agent）。
    相对路径仍拼接到项目根。两种情况都统一做项目根沙箱越界校验，越界直接拒绝。
    """
    rel = (rel or "").strip()
    if os.path.isabs(rel):
        p = Path(rel).resolve()
    else:
        p = (root / rel.lstrip("/")).resolve()
    if p != root and root not in p.parents:
        raise ValueError(f"路径越界（超出项目根）: {rel}")
    return p


def _t_list_dir(root: Path, args: Dict[str, Any]) -> Dict[str, str]:
    """执行 list_dir 工具调用，返回目录内容列表。"""
    p = _safe_resolve(root, args.get("path", ""))
    if not p.exists():
        return {"ok": False, "output": f"目录不存在: {args.get('path','')}"}
    if not p.is_dir():
        return {"ok": False, "output": f"不是目录: {args.get('path','')}"}
    rows: List[str] = []
    for e in sorted(p.iterdir(), key=lambda x: (x.is_file(), x.name.lower())):
        if e.name in _SKIP_DIRS:
            continue
        try:
            size = f" ({e.stat().st_size}B)" if e.is_file() else "/"
        except OSError:
            size = " (unknown)"
        rows.append(e.name + size)
        if len(rows) >= _MAX_LIST:
            rows.append("...(截断)")
            break
    head = (args.get("path", "") or ".") + "/"
    return {"ok": True, "output": head + "\n" + "\n".join(rows)}


def _t_read_file(root: Path, args: Dict[str, Any]) -> Dict[str, str]:
    """执行 read_file 工具调用，读取指定文件内容。"""
    p = _safe_resolve(root, args.get("path", ""))
    if not p.is_file():
        return {"ok": False, "output": f"文件不存在: {args.get('path','')}"}
    if p.suffix.lower() not in _TEXT_EXT:
        return {"ok": False, "output": f"非文本文件，拒绝读取: {args.get('path','')}"}
    start = max(1, int(args.get("start_line", 1) or 1))
    maxlines = int(args.get("max_lines", 400) or 400)
    with open(p, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()
    seg = lines[start - 1:start - 1 + maxlines]
    body = "".join(f"{start + i}: {ln}" for i, ln in enumerate(seg))
    if len(body) > _MAX_READ_BYTES:
        body = body[:_MAX_READ_BYTES] + "\n...(截断)"
    return {"ok": True, "output": f"{args.get('path')} 共{len(lines)}行\n" + body}


def _t_write_file(root: Path, args: Dict[str, Any]) -> Dict[str, str]:
    """执行 write_file 工具调用，写入或覆盖指定文件。"""
    rel = args.get("path", "")
    content = args.get("content", "")
    p = _safe_resolve(root, rel)
    if p.suffix.lower() not in _TEXT_EXT:
        return {"ok": False, "output": f"非文本扩展名，拒绝写入: {rel}"}
    name = p.name.lower()
    _protected = (name in _PROTECTED_NAMES
                  or name.startswith("requirements")
                  or name.startswith(".env")
                  or p.suffix.lower() in _PROTECTED_SUFFIX)
    if _protected and name not in _CURRENT_PROMPT.lower():
        return {"ok": False,
                "output": f"{rel} 是关键依赖/配置/元数据文件，自主任务不得修改；"
                          f"如确需修改，请在指令中明确点名该文件。"}
    p.parent.mkdir(parents=True, exist_ok=True)
    backup = ""
    if p.exists():
        bk = p.with_name(p.name + ".bak_agent")
        try:
            bk.write_bytes(p.read_bytes())
            backup = f"，已备份 {bk.name}"
        except OSError as e:
            logger.warning("备份文件 %s 失败: %s", bk, e)
            backup = "，备份失败"
    p.write_text(content, encoding="utf-8")
    return {"ok": True, "output": f"已写入 {rel}（{len(content)}字符{backup}）"}


def _t_search(root: Path, args: Dict[str, Any]) -> Dict[str, str]:
    """执行 search_files 工具调用，按文件名或内容关键字搜索项目内文件。"""
    query = (args.get("query", "") or "").strip()
    if not query:
        return {"ok": False, "output": "查询关键字不能为空"}
    content_kw = (args.get("content", "") or "").strip()
    start_dir = args.get("path", "") or ""
    start = _safe_resolve(root, start_dir)
    if not start.is_dir():
        return {"ok": False, "output": f"搜索目录不存在: {start_dir}"}
    results: List[str] = []
    query_lower = query.lower()
    for f in start.rglob("*"):
        if f.name in _SKIP_DIRS or f.name.endswith(".bak_agent"):
            continue
        if not f.is_file():
            continue
        if f.suffix.lower() not in _TEXT_EXT and not content_kw:
            continue
        if query_lower in f.name.lower():
            results.append(f"{f.relative_to(root)}")
        if len(results) >= _MAX_LIST:
            break
    if content_kw and results:
        filtered: List[str] = []
        for rel_path in results:
            try:
                fp = _safe_resolve(root, rel_path)
                with open(fp, "r", encoding="utf-8", errors="replace") as fh:
                    text = fh.read()
                if content_kw.lower() in text.lower():
                    filtered.append(rel_path)
            except (OSError, ValueError):
                continue
        results = filtered
    if not results:
        return {"ok": True, "output": "未找到匹配文件"}
    return {"ok": True, "output": "\n".join(results)}


def execute_tool_call(tool_name: str, args: Dict[str, Any], root: Optional[Path] = None) -> Dict[str, Any]:
    """执行单个工具调用并返回结果。

    Args:
        tool_name: 工具名称
        args: 工具参数
        root: 项目根目录，默认为 default_project_root()

    Returns:
        包含 ok 和 output 字段的结果字典
    """
    if root is None:
        root = default_project_root()
    handlers: Dict[str, Callable[[Path, Dict[str, Any]], Dict[str, str]]] = {
        "list_dir": _t_list_dir,
        "read_file": _t_read_file,
        "write_file": _t_write_file,
        "search_files": _t_search,
    }
    handler = handlers.get(tool_name)
    if handler is None:
        return {"ok": False, "output": f"未知工具: {tool_name}"}
    return handler(root, args)
