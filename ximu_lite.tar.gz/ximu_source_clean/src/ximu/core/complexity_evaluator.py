#!/usr/bin/env python3
"""
汐沫AI · 复杂度评估器 (Complexity Evaluator) - 阶段3
模块定位: 七维复杂度评估,输出0-100分和等级,直接影响拆分策略（L-05）、超时（F-05）、模型选择（C-02）。

融入修改项:
- L-05: 复杂度>85且PARENT时强制split_by_dimension
- F-05: 复杂度档位决定超时值
- C-02: 复杂度影响模型选择

版本: 0.5
"""

import logging
import hashlib
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Any, Union
from enum import Enum

# 常量定义
PARENT = "PARENT"
CHILD = "CHILD"
LEAF = "LEAF"


class ComplexityLevel(Enum):
    """复杂度等级枚举"""
    SIMPLE = "simple"      # 0-25
    NORMAL = "normal"      # 26-55
    COMPLEX = "complex"    # 56-85
    EXTREME = "extreme"    # 86-100


@dataclass
class DimensionScores:
    """七维评分结果数据结构"""
    goals_score: float = 0.0            # 目标数量
    skill_domains_score: float = 0.0    # 技能域数量
    dependencies_score: float = 0.0     # 依赖关系
    output_types_score: float = 0.0     # 输出类型
    context_depth_score: float = 0.0    # 上下文深度
    fault_tolerance_score: float = 0.0  # 容错要求
    boundary_exceptions_score: float = 0.0  # 边界异常


@dataclass
class ComplexityResult:
    """复杂度评估结果数据结构"""
    score: float  # 0-100
    level: ComplexityLevel
    dimension_scores: DimensionScores
    recommendations: List[str] = field(default_factory=list)
    split_strategy: str = "split_by_deliverable"  # 默认策略


class ComplexityEvaluator:
    """
    七维复杂度评估器。

    评估任务复杂度，为拆分策略、超时设置、模型选择提供依据。
    支持结果缓存以提升性能。
    """

    # 权重配置（与文档一致）
    WEIGHTS: Dict[str, float] = {
        "goals": 0.20,
        "skill_domains": 0.20,
        "dependencies": 0.15,
        "output_types": 0.10,
        "context_depth": 0.10,
        "fault_tolerance": 0.05,
        "boundary_exceptions": 0.20
    }

    # 等级阈值
    THRESHOLDS: Dict[ComplexityLevel, tuple] = {
        ComplexityLevel.SIMPLE: (0, 25),
        ComplexityLevel.NORMAL: (26, 55),
        ComplexityLevel.COMPLEX: (56, 85),
        ComplexityLevel.EXTREME: (86, 100)
    }

    #: 评估结果缓存上限，超过后清空缓存。
    MAX_CACHE_SIZE: int = 1000

    # R27-R20: 上下文深度分档字符阈值
    _CTX_MULTIMODAL_MIN_CHARS: int = 1000
    _CTX_LONG_CHARS: int = 5000
    _CTX_MEDIUM_CHARS: int = 500

    # R27-R20: 边界异常数量分档阈值
    _BOUNDARY_FEW_MAX: int = 2
    _BOUNDARY_MEDIUM_MAX: int = 5
    _BOUNDARY_MANY_MAX: int = 10

    # 超时推荐映射 (F-05)
    _TIMEOUT_MAP: Dict[ComplexityLevel, int] = {
        ComplexityLevel.SIMPLE: 30,
        ComplexityLevel.NORMAL: 60,
        ComplexityLevel.COMPLEX: 120,
        ComplexityLevel.EXTREME: 300
    }

    # 模型推荐映射 (C-02)
    _MODEL_MAP: Dict[ComplexityLevel, str] = {
        ComplexityLevel.SIMPLE: "lightweight",
        ComplexityLevel.NORMAL: "standard",
        ComplexityLevel.COMPLEX: "advanced",
        ComplexityLevel.EXTREME: "expert"
    }

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        """
        初始化复杂度评估器。

        Args:
            config: 配置字典，可选。
        """
        self._config = config or {}
        self._logger = logging.getLogger(__name__)
        self._cache: Dict[str, ComplexityResult] = {}

    # ==========
    # 核心方法: evaluate（七维评分）
    # ==========

    def evaluate(self, parsed_request: Dict[str, Any]) -> ComplexityResult:
        """
        七维复杂度评估（L-05/F-05/C-02）。

        Args:
            parsed_request: 解析后的请求,包含目标/技能域/依赖/输出类型/上下文/容错/边界

        Returns:
            ComplexityResult: 评估结果
        """
        cache_key = self._generate_cache_key(parsed_request)

        # 检查缓存
        if cache_key in self._cache:
            self._logger.debug(f"Using cached complexity result for {cache_key[:16]}...")
            return self._cache[cache_key]

        # 计算维度得分
        dim_scores = self._compute_dimension_scores(parsed_request)
        total_score = self._compute_weighted_score(dim_scores)
        level = self._determine_level(total_score)

        # 确定拆分策略和建议
        task_level = parsed_request.get("task_level", PARENT)
        split_strategy = self._determine_split_strategy(level, task_level)
        recommendations = self._generate_recommendations(total_score, level, dim_scores)

        # 构建结果
        result = ComplexityResult(
            score=total_score,
            level=level,
            dimension_scores=dim_scores,
            recommendations=recommendations,
            split_strategy=split_strategy
        )

        # 缓存结果
        self._cache_result(cache_key, result)

        self._logger.info(
            f"Complexity evaluated: score={total_score:.2f}, "
            f"level={level.value}, strategy={split_strategy}"
        )
        return result

    def _compute_dimension_scores(self, parsed_request: Dict[str, Any]) -> DimensionScores:
        """
        计算七维评分。

        Args:
            parsed_request: 解析后的请求数据

        Returns:
            DimensionScores: 各维度得分
        """
        return DimensionScores(
            goals_score=self._score_goals(parsed_request.get("goals", [])),
            skill_domains_score=self._score_skill_domains(parsed_request.get("skill_domains", [])),
            dependencies_score=self._score_dependencies(parsed_request.get("dependencies", [])),
            output_types_score=self._score_output_types(parsed_request.get("output_types", [])),
            context_depth_score=self._score_context_depth(parsed_request.get("context", {})),
            fault_tolerance_score=self._score_fault_tolerance(parsed_request.get("fault_tolerance", "normal")),
            boundary_exceptions_score=self._score_boundary_exceptions(parsed_request.get("boundary_exceptions", []))
        )

    def _compute_weighted_score(self, dim_scores: DimensionScores) -> float:
        """
        加权汇总七维评分。

        Args:
            dim_scores: 各维度得分

        Returns:
            float: 加权后的总分 (0-100)
        """
        score = 0.0
        for key, weight in self.WEIGHTS.items():
            if key == "goals":
                score += dim_scores.goals_score * weight
            elif key == "skill_domains":
                score += dim_scores.skill_domains_score * weight
            elif key == "dependencies":
                score += dim_scores.dependencies_score * weight
            elif key == "output_types":
                score += dim_scores.output_types_score * weight
            elif key == "context_depth":
                score += dim_scores.context_depth_score * weight
            elif key == "fault_tolerance":
                score += dim_scores.fault_tolerance_score * weight
            elif key == "boundary_exceptions":
                score += dim_scores.boundary_exceptions_score * weight
        return min(score, 100.0)

    def _cache_result(self, cache_key: str, result: ComplexityResult) -> None:
        """
        缓存评估结果，超限时清空缓存。

        Args:
            cache_key: 缓存键
            result: 评估结果
        """
        if len(self._cache) >= self.MAX_CACHE_SIZE:
            self._logger.warning("Cache limit reached, clearing cache")
            self._cache.clear()
        self._cache[cache_key] = result

    # ==========
    # 七维评分方法
    # ==========

    def _score_goals(self, goals: List[Dict[str, Any]]) -> float:
        """
        维度1: 目标数量评分（20%权重）。

        公式: (n-1)*15, 封顶100。

        Args:
            goals: 目标列表

        Returns:
            float: 得分 (0-100)
        """
        n = len(goals)
        if n <= 1:
            return 0.0
        return min((n - 1) * 15.0, 100.0)

    def _score_skill_domains(self, domains: List[str]) -> float:
        """
        维度2: 技能域数量评分（20%权重）。

        公式: (n-1)*20, 封顶100。去重计算。

        Args:
            domains: 技能域列表

        Returns:
            float: 得分 (0-100)
        """
        n = len(set(domains))
        if n <= 1:
            return 0.0
        return min((n - 1) * 20.0, 100.0)

    def _score_dependencies(self, dependencies: Union[List[Dict[str, Any]], List[str], Any]) -> float:
        """
        维度3: 依赖关系评分（15%权重）。

        加权依赖评分。

        Args:
            dependencies: 依赖关系列表

        Returns:
            float: 得分 (0-100)
        """
        if not dependencies:
            return 0.0
        # 简化计算：每个依赖加5分，封顶100
        return min(len(dependencies) * 5.0, 100.0)

    def _score_output_types(self, output_types: List[str]) -> float:
        """
        维度4: 输出类型评分（10%权重）。

        Args:
            output_types: 输出类型列表

        Returns:
            float: 得分 (0-100)
        """
        if not output_types:
            return 0.0
        # 每种输出类型加10分，封顶100
        return min(len(output_types) * 10.0, 100.0)

    def _score_context_depth(self, context: Dict[str, Any]) -> float:
        """
        维度5: 上下文深度评分（10%权重）。

        Args:
            context: 上下文字典

        Returns:
            float: 得分 (0-100)
        """
        total_chars = sum(len(str(v)) for v in context.values() if v)
        if total_chars >= self._CTX_LONG_CHARS:
            return 100.0
        elif total_chars >= self._CTX_MEDIUM_CHARS:
            return 50.0
        elif total_chars >= self._CTX_MULTIMODAL_MIN_CHARS:
            return 25.0
        else:
            return 0.0

    def _score_fault_tolerance(self, fault_tolerance: str) -> float:
        """
        维度6: 容错要求评分（5%权重）。

        Args:
            fault_tolerance: 容错要求字符串

        Returns:
            float: 得分 (0-100)
        """
        if fault_tolerance == "high":
            return 100.0
        elif fault_tolerance == "medium":
            return 50.0
        else:
            return 0.0

    def _score_boundary_exceptions(self, boundary_exceptions: List[Any]) -> float:
        """
        维度7: 边界异常评分（20%权重）。

        Args:
            boundary_exceptions: 边界异常列表

        Returns:
            float: 得分 (0-100)
        """
        n = len(boundary_exceptions)
        if n >= self._BOUNDARY_MANY_MAX:
            return 100.0
        elif n >= self._BOUNDARY_MEDIUM_MAX:
            return 60.0
        elif n >= self._BOUNDARY_FEW_MAX:
            return 30.0
        else:
            return 0.0

    def _determine_level(self, score: float) -> ComplexityLevel:
        """
        确定复杂度等级。

        Args:
            score: 复杂度分数

        Returns:
            ComplexityLevel: 复杂度等级
        """
        for level, (min_score, max_score) in self.THRESHOLDS.items():
            if min_score <= score <= max_score:
                return level
        return ComplexityLevel.EXTREME

    def _determine_split_strategy(self, level: ComplexityLevel, task_level: str) -> str:
        """
        确定拆分策略。

        Args:
            level: 复杂度等级
            task_level: 任务级别

        Returns:
            str: 拆分策略
        """
        if level == ComplexityLevel.EXTREME and task_level == PARENT:
            return "split_by_dimension"
        elif level == ComplexityLevel.COMPLEX:
            return "split_by_deliverable"
        else:
            return "no_split"

    def _generate_recommendations(self, total_score: float, level: ComplexityLevel, dim_scores: DimensionScores) -> List[str]:
        """
        生成优化建议。

        Args:
            total_score: 总复杂度分数
            level: 复杂度等级
            dim_scores: 各维度得分

        Returns:
            List[str]: 优化建议列表
        """
        recommendations: List[str] = []
        if level == ComplexityLevel.EXTREME:
            recommendations.append("Consider splitting into smaller tasks")
        if dim_scores.goals_score > 50:
            recommendations.append("Simplify goals or split into subtasks")
        if dim_scores.skill_domains_score > 50:
            recommendations.append("Reduce skill domains or use specialized models")
        if dim_scores.dependencies_score > 50:
            recommendations.append("Reduce dependencies or use decoupled architecture")
        return recommendations

    def _generate_cache_key(self, parsed_request: Dict[str, Any]) -> str:
        """
        生成缓存键。

        Args:
            parsed_request: 解析后的请求数据

        Returns:
            str: 缓存键
        """
        # 使用请求的关键字段生成缓存键
        key_fields = [parsed_request.get(k, "") for k in ["goals", "skill_domains", "dependencies"]]
        return hashlib.md5(str(key_fields).encode()).hexdigest()
