import logging
import math
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any, Tuple

from ..common.constants import DefaultValues

logger = logging.getLogger("src.ximu.core.complexity_evaluator_extended")


class ComplexityType(Enum):
    """复杂度类型枚举"""
    TIME = "time"
    SPACE = "space"
    CYCLOMATIC = "cyclomatic"
    COUPLING = "coupling"
    COHESION = "cohesion"
    MAINTAINABILITY = "maintainability"
    TESTABILITY = "testability"
    SECURITY = "security"


@dataclass
class ComplexityMetrics:
    """复杂度指标数据类，包含多维度的代码复杂度度量。"""
    time_complexity: str = "O(1)"
    space_complexity: str = "O(1)"
    cyclomatic_complexity: int = 1
    coupling_score: float = 0.0
    cohesion_score: float = 1.0
    maintainability_index: float = 100.0
    testability_score: float = 1.0
    security_risk: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """将复杂度指标序列化为字典。"""
        return {
            'time_complexity': self.time_complexity,
            'space_complexity': self.space_complexity,
            'cyclomatic_complexity': self.cyclomatic_complexity,
            'coupling_score': self.coupling_score,
            'cohesion_score': self.cohesion_score,
            'maintainability_index': self.maintainability_index,
            'testability_score': self.testability_score,
            'security_risk': self.security_risk,
        }


@dataclass
class ComplexityPrediction:
    """复杂度预测数据类，包含基于历史数据的预测结果和建议。"""
    expected_time: float = 0.0
    expected_space: float = 0.0
    risk_score: float = 0.0
    recommendations: List[str] = field(default_factory=list)
    confidence: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """将复杂度预测结果序列化为字典。"""
        return {
            'expected_time': self.expected_time,
            'expected_space': self.expected_space,
            'risk_score': self.risk_score,
            'recommendations': self.recommendations,
            'confidence': self.confidence,
        }


class ComplexityClassifier:
    """复杂度分类器，用于对各项指标进行等级和颜色分类。"""

    @staticmethod
    def classify_cyclomatic(cc: int) -> Tuple[str, str]:
        """根据圈复杂度值分类其等级和颜色。

        Args:
            cc: 圈复杂度值

        Returns:
            包含等级名称和颜色的元组
        """
        if cc <= DefaultValues.CC_SIMPLE_MAX:
            return "simple", "green"
        elif cc <= DefaultValues.CC_MODERATE_MAX:
            return "moderate", "yellow"
        elif cc <= DefaultValues.CC_COMPLEX_MAX:
            return "complex", "orange"
        else:
            return "very_complex", "red"

    @staticmethod
    def classify_maintainability(mi: float) -> Tuple[str, str]:
        """根据可维护性指数分类其等级和颜色。

        Args:
            mi: 可维护性指数值 (0-100)

        Returns:
            包含等级名称和颜色的元组
        """
        if mi >= DefaultValues.MI_HIGH_MIN:
            return "high", "green"
        elif mi >= DefaultValues.MI_MEDIUM_MIN:
            return "medium", "yellow"
        elif mi >= DefaultValues.MI_LOW_MIN:
            return "low", "orange"
        else:
            return "very_low", "red"

    @staticmethod
    def classify_coupling(coupling: float) -> Tuple[str, str]:
        """根据耦合度分数分类其等级和颜色。

        Args:
            coupling: 耦合度分数 (0-1)

        Returns:
            包含等级名称和颜色的元组
        """
        if coupling <= DefaultValues.COUPLING_LOW_MAX:
            return "low", "green"
        elif coupling <= DefaultValues.COUPLING_MODERATE_MAX:
            return "moderate", "yellow"
        elif coupling <= DefaultValues.COUPLING_HIGH_MAX:
            return "high", "orange"
        else:
            return "very_high", "red"


class ComplexityAnalyzer:
    """复杂度分析器，负责计算各项复杂度指标并记录历史。"""

    def __init__(self) -> None:
        """初始化复杂度分析器。"""
        self._history: List[Dict[str, Any]] = []
        self._lock = threading.RLock()
        self._classifier = ComplexityClassifier()

    def analyze_function(
        self,
        func_name: str,
        code_lines: int,
        nesting_depth: int = 0,
        branch_count: int = 0,
        dependency_count: int = 0,
        parameter_count: int = 0
    ) -> ComplexityMetrics:
        """分析指定函数的多维复杂度指标。

        Args:
            func_name: 函数名称
            code_lines: 代码行数
            nesting_depth: 嵌套深度
            branch_count: 分支数量
            dependency_count: 依赖数量
            parameter_count: 参数数量

        Returns:
            包含所有复杂度指标的 ComplexityMetrics 对象
        """
        cyclomatic = 1 + branch_count + nesting_depth
        time_complexity = self._estimate_time_complexity(code_lines, nesting_depth)
        space_complexity = self._estimate_space_complexity(code_lines, parameter_count)
        coupling = min(1.0, dependency_count / 10.0)
        cohesion = max(0.0, 1.0 - (branch_count * 0.05 + nesting_depth * 0.03))
        mi = self._calculate_mi(code_lines, cyclomatic, coupling)
        testability = self._calculate_testability(cyclomatic, coupling, parameter_count)
        security_risk = self._calculate_security_risk(coupling, branch_count)

        metrics = ComplexityMetrics(
            time_complexity=time_complexity,
            space_complexity=space_complexity,
            cyclomatic_complexity=cyclomatic,
            coupling_score=coupling,
            cohesion_score=cohesion,
            maintainability_index=mi,
            testability_score=testability,
            security_risk=security_risk,
        )

        self._record_analysis(func_name, metrics)
        return metrics

    def _estimate_time_complexity(self, lines: int, depth: int) -> str:
        """根据代码行数和嵌套深度估算时间复杂度。

        Args:
            lines: 代码行数
            depth: 嵌套深度

        Returns:
            时间复杂度字符串表示
        """
        if lines <= 10 and depth <= 1:
            return "O(1)"
        elif lines <= 50 and depth <= 2:
            return "O(n)"
        elif lines <= 100 and depth <= 3:
            return "O(n log n)"
        elif lines <= 200:
            return "O(n²)"
        else:
            return "O(n³) or worse"

    def _estimate_space_complexity(self, lines: int, params: int) -> str:
        """根据代码行数和参数数量估算空间复杂度。

        Args:
            lines: 代码行数
            params: 参数数量

        Returns:
            空间复杂度字符串表示
        """
        if lines <= 20 and params <= 3:
            return "O(1)"
        elif lines <= 100 and params <= 10:
            return "O(n)"
        else:
            return "O(n²) or more"

    def _calculate_mi(self, lines: int, cc: int, coupling: float) -> float:
        """基于SNAKE模型计算可维护性指数。

        Args:
            lines: 代码行数
            cc: 圈复杂度
            coupling: 耦合度

        Returns:
            标准化到0-100的可维护性指数
        """
        v = max(1, lines / 100)
        e = max(1, cc)
        i = max(0.0, 1.0 - coupling)

        mi_raw = max(0.0, (33.0 - 16.0 * math.log10(v) - 12.0 * math.log10(e)) * i)
        return min(100.0, max(0.0, mi_raw * 100.0 / 33.0))

    def _calculate_testability(self, cc: int, coupling: float, params: int) -> float:
        """计算可测试性评分。

        Args:
            cc: 圈复杂度
            coupling: 耦合度
            params: 参数数量

        Returns:
            0.0到1.0之间的可测试性评分
        """
        cc_score = max(0, 10 - cc) / 10
        coupling_score = 1 - coupling
        param_score = max(0, 5 - params) / 5
        return (cc_score * 0.4 + coupling_score * 0.4 + param_score * 0.2)

    def _calculate_security_risk(self, coupling: float, branches: int) -> float:
        """估算安全风险等级。

        Args:
            coupling: 耦合度
            branches: 分支数量

        Returns:
            0.0到1.0之间的安全风险分数
        """
        coupling_risk = coupling * 0.5
        branch_risk = min(0.3, branches * 0.02)
        validation_risk = 0.2
        return min(1.0, coupling_risk + branch_risk + validation_risk)

    def _record_analysis(self, func_name: str, metrics: ComplexityMetrics) -> None:
        """记录分析结果到历史。

        Args:
            func_name: 函数名称
            metrics: 分析结果
        """
        with self._lock:
            self._history.append({
                "func_name": func_name,
                "timestamp": time.time(),
                "metrics": metrics.to_dict()
            })
