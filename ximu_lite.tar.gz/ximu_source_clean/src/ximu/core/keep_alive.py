import logging
import os
import subprocess

from src.ximu.core import permission_gate


def _detect_package() -> str:
    """
    运行时探测当前包名，不写死 imperium(#11)。
    """
    try:
        env_pkg = os.environ.get("XIMU_APP_PACKAGE", "").strip()
        if env_pkg.startswith("com.ximu."):
            return env_pkg
    except Exception:
        pass

    try:
        with open("/proc/self/cmdline", "rb") as f:
            first = f.read().split(b"\x00", 1)[0].decode("utf-8", "ignore").strip()
            if first.startswith("com.ximu."):
                return first
    except Exception:
        pass

    return "com.ximu.imperium"


logger = logging.getLogger(__name__)

_PKG = _detect_package()


def apply_keepalive() -> dict:
    """
    应用保活策略。
    """
    mode = permission_gate.get_mode()
    result = {"ok": True, "mode": mode}

    if mode == "standard":
        result["level"] = "基础保活"
        result["note"] = "已启用最小前台保活。长时间后台任务建议升级 Shizuku/Root 以抗系统回收。"
    elif mode == "shizuku":
        try:
            # 加入电池白名单
            subprocess.run(
                f"dumpsys deviceidle whitelist +{_PKG}",
                shell=True,
                check=True,
                timeout=8,
            )
            # 拉活后台服务
            subprocess.run(
                f"am set-standby-bucket {_PKG} active",
                shell=True,
                check=True,
                timeout=8,
            )
            result["level"] = "调试级保活"
            result["note"] = "已静默加入电池白名单并拉活后台服务，后台任务更不容易被回收。"
        except subprocess.CalledProcessError as e:
            logger.error(f"apply_keepalive: {e}")
            result["ok"] = False
    elif mode == "root":
        try:
            # 加入电池白名单
            subprocess.run(
                f"dumpsys deviceidle whitelist +{_PKG}",
                shell=True,
                check=True,
                timeout=8,
            )
            # 拉活后台服务
            subprocess.run(
                f"am set-standby-bucket {_PKG} active",
                shell=True,
                check=True,
                timeout=8,
            )
            # 启动常驻服务
            subprocess.run(
                f"am startservice -n {_PKG}/.KeepAliveService",
                shell=True,
                check=True,
                timeout=10,
            )
            result["level"] = "Root 级保活"
            result["note"] = "已启用最强静默保活：常驻服务 + 电池白名单 + 活跃待机，后台任务最稳。"
        except subprocess.CalledProcessError as e:
            logger.error(f"apply_keepalive: {e}")
            result["ok"] = False

    return result
