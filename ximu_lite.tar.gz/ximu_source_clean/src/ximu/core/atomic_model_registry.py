#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
汐沫AI 原子任务模型注册表（第一批50个）
总共规划150个原子模型，第一批50个验证接单闭环。
80%代码类（40个）+ 20%数据类（10个）。
底座：Qwen2.5-0.5B-instruct，LoRA微调，分步骤设计，懒加载。
"""

# 第一批50个原子模型定义
ATOMIC_MODELS = [
    # === 代码分析类（8个）- 分步骤，每个只做一个小步骤 ===
    {"id": "code_parse_ast", "name": "代码AST解析", "category": "代码分析", "lang": "通用",
     "input": "代码片段", "output": "AST结构/语法树", "step": "分析-1"},
    {"id": "syntax_check", "name": "语法检查", "category": "代码分析", "lang": "通用",
     "input": "代码片段", "output": "语法错误列表+行号", "step": "分析-2"},
    {"id": "error_type_classify", "name": "错误类型判断", "category": "代码分析", "lang": "通用",
     "input": "报错信息+代码", "output": "错误类型分类(语法/逻辑/运行时/类型/依赖)", "step": "分析-3"},
    {"id": "error_location", "name": "错误行定位", "category": "代码分析", "lang": "通用",
     "input": "报错栈+代码", "output": "错误所在文件/行号/函数", "step": "分析-4"},
    {"id": "dependency_analyze", "name": "依赖分析", "category": "代码分析", "lang": "通用",
     "input": "代码/项目", "output": "依赖关系图+导入列表", "step": "分析-5"},
    {"id": "complexity_analyze", "name": "复杂度分析", "category": "代码分析", "lang": "通用",
     "input": "代码片段", "output": "圈复杂度/认知复杂度评分", "step": "分析-6"},
    {"id": "code_smell_detect", "name": "代码异味检测", "category": "代码分析", "lang": "通用",
     "input": "代码片段", "output": "异味列表(重复/过长函数/过大类等)", "step": "分析-7"},
    {"id": "flow_analyze", "name": "控制流分析", "category": "代码分析", "lang": "通用",
     "input": "代码片段", "output": "控制流图+执行路径", "step": "分析-8"},

    # === 代码调试类（6个）- 分步骤 ===
    {"id": "bug_root_cause", "name": "Bug根因分析", "category": "代码调试", "lang": "通用",
     "input": "Bug描述+代码+报错", "output": "根因分析+触发条件", "step": "调试-1"},
    {"id": "fix_plan_generate", "name": "修复方案生成", "category": "代码调试", "lang": "通用",
     "input": "根因分析+代码", "output": "修复方案(不改代码，只说思路)", "step": "调试-2"},
    {"id": "fix_code_apply", "name": "修复代码生成", "category": "代码调试", "lang": "通用",
     "input": "修复方案+原代码", "output": "修复后的完整代码", "step": "调试-3"},
    {"id": "regression_check", "name": "回归检查", "category": "代码调试", "lang": "通用",
     "input": "修复前后代码", "output": "回归风险评估+测试建议", "step": "调试-4"},
    {"id": "log_error_analyze", "name": "日志错误分析", "category": "代码调试", "lang": "通用",
     "input": "日志片段", "output": "错误模式+根因推测", "step": "调试-5"},
    {"id": "stack_trace_parse", "name": "堆栈解析", "category": "代码调试", "lang": "通用",
     "input": "异常堆栈", "output": "调用链+最可能出错位置", "step": "调试-6"},

    # === 代码生成类（8个）- 按语言细分 ===
    {"id": "gen_python", "name": "Python代码生成", "category": "代码生成", "lang": "Python",
     "input": "需求描述", "output": "可运行Python代码", "step": "生成"},
    {"id": "gen_javascript", "name": "JavaScript代码生成", "category": "代码生成", "lang": "JavaScript",
     "input": "需求描述", "output": "可运行JS代码", "step": "生成"},
    {"id": "gen_java", "name": "Java代码生成", "category": "代码生成", "lang": "Java",
     "input": "需求描述", "output": "可运行Java代码", "step": "生成"},
    {"id": "gen_go", "name": "Go代码生成", "category": "代码生成", "lang": "Go",
     "input": "需求描述", "output": "可运行Go代码", "step": "生成"},
    {"id": "gen_rust", "name": "Rust代码生成", "category": "代码生成", "lang": "Rust",
     "input": "需求描述", "output": "可运行Rust代码", "step": "生成"},
    {"id": "gen_cpp", "name": "C++代码生成", "category": "代码生成", "lang": "C++",
     "input": "需求描述", "output": "可运行C++代码", "step": "生成"},
    {"id": "gen_shell", "name": "Shell脚本生成", "category": "代码生成", "lang": "Shell",
     "input": "需求描述", "output": "可运行Shell脚本", "step": "生成"},
    {"id": "gen_sql", "name": "SQL生成优化", "category": "代码生成", "lang": "SQL",
     "input": "需求/慢SQL+表结构", "output": "优化后的SQL+索引建议", "step": "生成"},

    # === 代码质量类（6个）===
    {"id": "code_review_general", "name": "通用代码审查", "category": "代码质量", "lang": "通用",
     "input": "代码片段", "output": "审查意见+改进建议", "step": "质量-1"},
    {"id": "code_refactor", "name": "重构建议", "category": "代码质量", "lang": "通用",
     "input": "代码片段", "output": "重构方案+重构后代码", "step": "质量-2"},
    {"id": "perf_optimize", "name": "性能优化", "category": "代码质量", "lang": "通用",
     "input": "代码+性能数据", "output": "瓶颈分析+优化代码", "step": "质量-3"},
    {"id": "security_audit", "name": "安全审计", "category": "代码质量", "lang": "通用",
     "input": "代码片段", "output": "漏洞列表+修复方案", "step": "质量-4"},
    {"id": "style_check", "name": "代码风格检查", "category": "代码质量", "lang": "通用",
     "input": "代码片段", "output": "风格问题+规范建议", "step": "质量-5"},
    {"id": "dead_code_detect", "name": "死代码检测", "category": "代码质量", "lang": "通用",
     "input": "代码/项目", "output": "未使用函数/变量/导入列表", "step": "质量-6"},

    # === 专用代码类（6个）===
    {"id": "regex_generate", "name": "正则表达式生成", "category": "专用代码", "lang": "正则",
     "input": "文本匹配需求", "output": "正则表达式+测试用例", "step": "专用"},
    {"id": "api_design", "name": "API设计", "category": "专用代码", "lang": "通用",
     "input": "接口需求", "output": "RESTful API设计+请求响应示例", "step": "专用"},
    {"id": "unit_test_gen", "name": "单元测试生成", "category": "专用代码", "lang": "通用",
     "input": "代码+函数签名", "output": "单元测试代码(pytest/jest等)", "step": "专用"},
    {"id": "mock_generate", "name": "Mock代码生成", "category": "专用代码", "lang": "通用",
     "input": "依赖接口", "output": "Mock对象+测试桩", "step": "专用"},
    {"id": "doc_generate", "name": "代码文档生成", "category": "专用代码", "lang": "通用",
     "input": "代码片段", "output": "API文档+注释+使用示例", "step": "专用"},
    {"id": "code_translate", "name": "代码翻译转换", "category": "专用代码", "lang": "多语言",
     "input": "源代码+目标语言", "output": "目标语言等价代码", "step": "专用"},

    # === 算法数据结构类（6个）===
    {"id": "algo_sort_search", "name": "排序搜索算法", "category": "算法", "lang": "通用",
     "input": "算法需求", "output": "排序/搜索算法实现+复杂度分析", "step": "算法-1"},
    {"id": "algo_dp", "name": "动态规划", "category": "算法", "lang": "通用",
     "input": "问题描述", "output": "DP状态定义+转移方程+代码", "step": "算法-2"},
    {"id": "algo_graph", "name": "图算法", "category": "算法", "lang": "通用",
     "input": "图问题描述", "output": "图算法实现(BFS/DFS/最短路等)", "step": "算法-3"},
    {"id": "algo_tree", "name": "树操作", "category": "算法", "lang": "通用",
     "input": "树问题描述", "output": "树遍历/操作实现", "step": "算法-4"},
    {"id": "data_structure_impl", "name": "数据结构实现", "category": "算法", "lang": "通用",
     "input": "数据结构需求", "output": "链表/栈/队列/堆等实现", "step": "算法-5"},
    {"id": "design_pattern", "name": "设计模式实现", "category": "算法", "lang": "通用",
     "input": "场景需求", "output": "设计模式代码实现+适用场景", "step": "算法-6"},

    # === 数据类（10个）===
    {"id": "data_clean", "name": "数据清洗", "category": "数据处理", "lang": "Python",
     "input": "脏数据+清洗规则", "output": "清洗脚本+清洗后数据", "step": "数据-1"},
    {"id": "data_transform_json", "name": "JSON格式转换", "category": "数据处理", "lang": "Python",
     "input": "源数据+目标JSON结构", "output": "转换脚本+结果", "step": "数据-2"},
    {"id": "data_transform_csv", "name": "CSV格式转换", "category": "数据处理", "lang": "Python",
     "input": "源数据+CSV结构", "output": "转换脚本+CSV文件", "step": "数据-3"},
    {"id": "data_transform_xml", "name": "XML格式转换", "category": "数据处理", "lang": "Python",
     "input": "源数据+XML结构", "output": "转换脚本+XML文件", "step": "数据-4"},
    {"id": "data_analyze", "name": "数据分析", "category": "数据处理", "lang": "Python",
     "input": "数据集+分析目标", "output": "分析脚本+统计结果+洞察", "step": "数据-5"},
    {"id": "data_visualize", "name": "数据可视化", "category": "数据处理", "lang": "Python",
     "input": "数据+图表需求", "output": "绘图脚本+图表", "step": "数据-6"},
    {"id": "data_extract", "name": "数据提取", "category": "数据处理", "lang": "Python",
     "input": "非结构化文本+提取目标", "output": "提取脚本+结构化数据", "step": "数据-7"},
    {"id": "data_validate", "name": "数据验证", "category": "数据处理", "lang": "Python",
     "input": "数据+验证规则", "output": "验证脚本+校验报告", "step": "数据-8"},
    {"id": "etl_script", "name": "ETL脚本", "category": "数据处理", "lang": "Python",
     "input": "数据源+目标+转换规则", "output": "完整ETL脚本", "step": "数据-9"},
    {"id": "report_generate", "name": "报表生成", "category": "数据处理", "lang": "Python",
     "input": "数据+报表需求", "output": "报表生成脚本+报表文件", "step": "数据-10"},
]

# 现有任务类型到原子模型的映射（用于数据分类和重标签）
TASK_TYPE_TO_ATOMIC = {
    "code_generation": ["gen_python", "gen_javascript", "code_parse_ast", "syntax_check"],
    "code_review": ["code_review_general", "code_smell_detect", "style_check", "complexity_analyze"],
    "code_refactor": ["code_refactor", "dead_code_detect", "dependency_analyze"],
    "code_explain": ["flow_analyze", "code_parse_ast", "doc_generate"],
    "code_debug": ["error_type_classify", "error_location", "bug_root_cause", "fix_plan_generate",
                   "fix_code_apply", "stack_trace_parse", "log_error_analyze"],
    "unit_test_gen": ["unit_test_gen", "mock_generate", "regression_check"],
    "api_design": ["api_design", "doc_generate"],
    "algorithm_impl": ["algo_sort_search", "algo_dp", "algo_graph", "algo_tree",
                       "data_structure_impl", "design_pattern"],
    "code_optimize": ["perf_optimize", "complexity_analyze"],
    "code_translate": ["code_translate"],
    "log_analyze": ["log_error_analyze", "stack_trace_parse"],
    "exception_handle": ["error_type_classify", "fix_plan_generate"],
    "vuln_scan": ["security_audit"],
    "penetration_test": ["security_audit"],
    "perf_analyze": ["perf_optimize", "complexity_analyze"],
    "regex_generate": ["regex_generate"],
    "data_transform": ["data_transform_json", "data_transform_csv", "data_transform_xml"],
    "sql_optimize": ["gen_sql"],
    "test_generate": ["unit_test_gen", "mock_generate"],
}

def get_atomic_model(model_id):
    """根据ID获取原子模型定义"""
    for m in ATOMIC_MODELS:
        if m["id"] == model_id:
            return m
    return None

def get_atomic_models_by_category(category):
    """按大类获取原子模型列表"""
    return [m for m in ATOMIC_MODELS if m["category"] == category]

def get_all_atomic_ids():
    """获取所有原子模型ID"""
    return [m["id"] for m in ATOMIC_MODELS]

def map_task_to_atomic(task_type, lang_hint=None):
    """将任务类型映射到原子模型ID列表"""
    candidates = TASK_TYPE_TO_ATOMIC.get(task_type, [])
    if lang_hint and task_type == "code_generation":
        lang_map = {
            "python": "gen_python", "javascript": "gen_javascript", "js": "gen_javascript",
            "java": "gen_java", "go": "gen_go", "rust": "gen_rust", "cpp": "gen_cpp",
            "c++": "gen_cpp", "shell": "gen_shell", "bash": "gen_shell", "sql": "gen_sql"
        }
        specific = lang_map.get(lang_hint.lower())
        if specific and specific in candidates:
            return [specific] + [c for c in candidates if c != specific]
    return candidates

if __name__ == "__main__":
    print(f"原子模型总数: {len(ATOMIC_MODELS)}")
    cats = {}
    for m in ATOMIC_MODELS:
        cats[m["category"]] = cats.get(m["category"], 0) + 1
    print("分类分布:")
    for cat, count in sorted(cats.items(), key=lambda x:-x[1]):
        print(f"  {cat}: {count}个")
    code_count = sum(1 for m in ATOMIC_MODELS if m["category"] != "数据处理")
    data_count = sum(1 for m in ATOMIC_MODELS if m["category"] == "数据处理")
    print(f"\n代码类: {code_count}个 ({code_count/len(ATOMIC_MODELS)*100:.0f}%)")
    print(f"数据类: {data_count}个 ({data_count/len(ATOMIC_MODELS)*100:.0f}%)")
