# -*- coding: utf-8 -*-
"""免费模型实时核价器（P33 机会式压缩专用）。

判定“调用该模型做自然语言压缩是否 0 成本”。与环境解耦、不写死模型清单。
结论来自权威源实时核价，带 TTL 缓存。保守原则：来源不一致 / 查不到 / 不确定 → 判「不免费」。
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
import urllib.request
from typing import Any, Dict, List, Optional, Tuple

_lock = threading.Lock()
TTL_HOURS = 72.0
_HTTP_TIMEOUT = 8.0

_VENDOR_PRICING_PAGES: Dict[str, Dict[str, Any]] = {
    "zhipu": {
        "urls": [
            "https://docs.bigmodel.cn/cn/guide/start/model-overview",
            "https://docs.bigmodel.cn/cn/guide/models/text/glm-4",
        ],
        "free_markers": ["免费文本模型", "免费语言模型", "（免费）", "(免费)", "免费使用", "现已完全免费", "免费版"],
        "paid_markers": ["元/百万", "元/千", "$", "高速低价", "低价"],
    },
    "bigmodel": {
        "urls": ["https://docs.bigmodel.cn/cn/guide/start/model-overview"],
        "free_markers": ["免费文本模型", "免费语言模型", "（免费）", "免费使用", "免费版"],
        "paid_markers": ["元/百万", "元/千", "$", "高速低价"],
    },
}

_OPENROUTER_MODELS_API = "https://openrouter.ai/api/v1/models"


def _user_data_root() -> str:
    """获取用户数据根目录。"""
    try:
        from src.ximu.core.data_root import get_user_data_dir
        return get_user_data_dir()
    except Exception:
        here = os.path.dirname(os.path.abspath(__file__))
        root = os.path.abspath(os.path.join(here, "..", "..", ".."))
        return os.path.join(root, "data", "用户数据")


def _cache_path() -> str:
    """生成缓存文件路径并确保目录存在。"""
    d = os.path.join(_user_data_root(), "模型核价")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "free_model_pricing.json")


def _load_cache() -> Dict[str, Any]:
    """加载缓存 JSON，失败返回空字典。"""
    p = _cache_path()
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_cache(cache: Dict[str, Any]) -> None:
    """保存缓存 JSON 到磁盘。"""
    p = _cache_path()
    try:
        with open(p, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def _fresh(entry: Dict[str, Any]) -> bool:
    """判断缓存条目是否在 TTL 有效期内。"""
    try:
        age_h = (time.time() - float(entry.get("checked_at", 0))) / 3600.0
        return age_h < float(entry.get("ttl_hours", TTL_HOURS))
    except Exception:
        return False


def _http_get(url: str, timeout: float = _HTTP_TIMEOUT) -> Optional[str]:
    """执行 HTTP GET 请求，失败返回 None。"""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "ximu-free-pricing-checker/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
        return raw.decode("utf-8", errors="replace")
    except Exception:
        return None


def _is_openrouter(base_url: Optional[str], provider: Optional[str]) -> bool:
    """判断是否属于 OpenRouter 环境。"""
    b = (base_url or "").lower()
    p = (provider or "").lower()
    return "openrouter" in b or "openrouter" in p


def _num(v: Any) -> Optional[float]:
    """安全转换为浮点数，失败返回 None。"""
    try:
        return float(str(v).strip())
    except Exception:
        return None


def _check_openrouter(model_id: str) -> Tuple[Optional[bool], List[Dict[str, str]]]:
    """通过 OpenRouter API 检查模型是否免费。"""
    body = _http_get(_OPENROUTER_MODELS_API)
    if not body:
        return None, []
    try:
        data = json.loads(body).get("data", [])
    except Exception:
        return None, []
    mid = (model_id or "").strip()
    for m in data:
        if m.get("id") != mid:
            continue
        pricing = m.get("pricing") or {}
        prompt_p = _num(pricing.get("prompt"))
        compl_p = _num(pricing.get("completion"))
        src = {"kind": "openrouter_api", "ref": _OPENROUTER_MODELS_API,
               "evidence": f"pricing.prompt={pricing.get('prompt')!r}, pricing.completion={pricing.get('completion')!r}"}
        if prompt_p is None or compl_p is None:
            return None, [src]
        if prompt_p == 0.0 and compl_p == 0.0:
            return True, [src]
        return False, [src]
    return None, []


def _check_registry_annotation(model_id: str) -> Tuple[Optional[bool], List[Dict[str, str]]]:
    """检查本地配置中的显式免费标注。"""
    try:
        from src.ximu.core.data_root import project_root
        reg = os.path.join(project_root(), "config", "api_registry.json")
        with open(reg, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return None, []
    mid = (model_id or "").strip().lower()
    for _pname, cfg in (data.get("api_keys") or {}).items():
        if not isinstance(cfg, dict):
            continue
        for m in cfg.get("models", []):
            if not isinstance(m, dict) or str(m.get("id", "")).lower() != mid:
                continue
            src = {"kind": "registry_config", "ref": "config/api_registry.json", "evidence": json.dumps(m, ensure_ascii=False)[:200]}
            if m.get("free") is True:
                return True, [src]
            pr = m.get("pricing") or {}
            pp, cp = _num(pr.get("prompt")), _num(pr.get("completion"))
            if pp is not None and cp is not None and pp == 0.0 and cp == 0.0:
                return True, [src]
            if m.get("free") is False or (pp is not None and pp > 0):
                return False, [src]
    return None, []


def _check_vendor_page(model_id: str, provider: Optional[str]) -> Tuple[Optional[bool], List[Dict[str, str]]]:
    """通过厂商官方页面 best-effort 检查免费状态。"""
    key = (provider or "").lower()
    seed = next((v for k, v in _VENDOR_PRICING_PAGES.items() if k in key), None)
    if not seed:
        return None, []
    mid = (model_id or "").strip().lower()

    def _find_pos(text_lower: str, needle: str) -> int:
        pat = re.escape(needle) + r"(?![A-Za-z0-9.\-])"
        m = re.search(pat, text_lower)
        return m.start() if m else -1

    for url in seed["urls"]:
        html = _http_get(url)
        if not html:
            continue
        text = re.sub(r"<[^>]+>", " ", html)
        text = re.sub(r"\s+", " ", text)
        low = text.lower()
        idx = _find_pos(low, mid)
        if idx < 0:
            base = re.split(r"[-_]\d{6,}$", mid)[0]
            if base != mid:
                idx = _find_pos(low, base)
        if idx < 0:
            continue
        window = text[max(0, idx - 60):idx + 120]
        src = {"kind": "official_page", "ref": url, "evidence": window.strip()[:160]}
        if any(mk in window for mk in seed["free_markers"]):
            return True, [src]
        if any(mk in window for mk in seed["paid_markers"]):
            return False, [src]
    return None, []


def is_model_free(model_id: str, base_url: Optional[str] = None, provider: Optional[str] = None) -> bool:
    """核心判断函数：该模型是否免费。
    
    Args:
        model_id: 模型 ID。
        base_url: 基础 URL（可选）。
        provider: 提供商名称（可选）。
        
    Returns:
        若确定免费返回 True，否则返回 False（保守原则）。
    """
    with _lock:
        cache = _load_cache()
        key = f"{base_url or ''}:{model_id}"
        entry = cache.get(key)
        if entry and _fresh(entry):
            return bool(entry.get("is_free", False))

        result: Optional[bool] = None
        sources: List[Dict[str, str]] = []

        # 优先级 1: OpenRouter
        if _is_openrouter(base_url, provider):
            result, sources = _check_openrouter(model_id)
            if result is not None:
                pass

        # 优先级 2: Registry
        if result is None:
            r2, s2 = _check_registry_annotation(model_id)
            if r2 is not None:
                result = r2
                sources = s2

        # 优先级 3: Vendor Page
        if result is None:
            r3, s3 = _check_vendor_page(model_id, provider)
            if r3 is not None:
                result = r3
                sources = s3

        final_free = result if result is not None else False
        cache[key] = {
            "model_id": model_id,
            "is_free": final_free,
            "sources": sources,
            "checked_at": time.time(),
            "ttl_hours": TTL_HOURS,
            "confidence": "high" if result is not None else "low"
        }
        _save_cache(cache)
        return final_free
    