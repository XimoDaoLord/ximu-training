# -*- coding: utf-8 -*-
"""设备检测器 - 检测设备配置用于端侧模型推荐。

手机端重点：可用/总内存、可用/总存储、NPU(NNAPI/厂商)、可用量化格式，
并在推荐前做硬性空间/内存校验——跑不动的模型绝不推荐，自动降档。
"""
from __future__ import annotations

import logging
import os
import platform
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import psutil

logger = logging.getLogger(__name__)

# 检测结果缓存 TTL（秒）：避免每次调用都 fork getprop / 读内存
_DETECT_CACHE_TTL = 60.0

# 下载分段会临时占用约 1 倍额外空间，合并期需要余量；这里取 1.5 倍系数
DISK_SAFETY_FACTOR = 1.5

# 候选对话模型档位：文件体积(GB) / 运行期峰值内存(GB, 含上下文与运行时)
MODEL_TIERS: List[Dict[str, Any]] = [
    {"size": "7b",   "file_gb": 4.1, "ram_gb": 6.5, "quant": "Q4_K_M"},
    {"size": "3b",   "file_gb": 1.9, "ram_gb": 3.5, "quant": "Q4_K_M"},
    {"size": "1.5b", "file_gb": 1.0, "ram_gb": 2.0, "quant": "Q4_K_M"},
    {"size": "0.5b", "file_gb": 0.5, "ram_gb": 1.0, "quant": "Q4_K_M"},
]
EMBED_FILE_GB = 0.1  # 嵌入模型(nomic-embed q4)约 81MB，留 0.1GB

# 版本号
__version__ = "0.5"


@dataclass
class DeviceConfig:
    """设备配置数据类，存储检测到的硬件与软件环境信息"""
    cpu_model: str = ""
    cpu_cores: int = 0
    cpu_percent: float = 0.0     # CPU 使用率（%，采样区间均值）
    memory_gb: float = 0.0       # 可用内存（GB）
    memory_total_gb: float = 0.0 # 总内存（GB）
    gpu_model: str = ""
    gpu_memory_gb: float = 0.0
    disk_available_gb: float = 0.0
    disk_total_gb: float = 0.0   # 磁盘总容量（GB）
    has_npu: bool = False        # Android NNAPI / 厂商 NPU
    npu_vendor: str = ""
    nnapi: bool = False
    vulkan: bool = False
    is_android: bool = False
    supported_quant: List[str] = field(default_factory=list)
    os_name: str = ""
    os_version: str = ""


class DeviceDetector:
    """设备检测器单例类，负责探测硬件资源并生成模型推荐计划"""

    _instance: Optional["DeviceDetector"] = None

    def __new__(cls) -> "DeviceDetector":
        """实现单例模式，确保全局只有一个 DeviceDetector 实例"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        """初始化检测器内部状态"""
        if self._instance is not self:
            return
        self._config: Optional[DeviceConfig] = None
        self._detected_at: float = 0.0  # 上次 detect() 完成的墙钟时间（秒）

    # ---------- 私有辅助方法 ----------

    def _getprop_batch(self, names: List[str]) -> Dict[str, str]:
        """批量读取 Android getprop 属性，减少子进程调用开销。

        通过单次执行 'getprop' 命令获取全量属性，然后解析出指定 key 的值。
        
        Args:
            names: 需要读取的属性名称列表
            
        Returns:
            字典，键为属性名，值为属性字符串（未命中则为空串）
        """
        result: Dict[str, str] = {}
        try:
            out = subprocess.run(
                ["getprop"],
                capture_output=True,
                text=True,
                timeout=3,
            )
            # getprop 无参数输出格式: [key]: [value]
            for line in (out.stdout or "").splitlines():
                line = line.strip()
                if line.startswith("[") and "]:" in line:
                    k, _, v = line.partition("]:")
                    k = k.strip().lstrip("[")
                    v = v.strip().lstrip("[").rstrip("]")
                    result[k] = v
        except Exception as e:
            logger.debug("getprop batch failed: %s", e)
        
        # 补齐请求的 key（未命中的返回空串）
        for name in names:
            result.setdefault(name, "")
        return result

    def _detect_npu(self, config: DeviceConfig) -> None:
        """探测 NPU / NNAPI / Vulkan / 厂商加速库，更新 config 对象。

        Args:
            config: 待填充的设备配置对象
        """
        props_map = self._getprop_batch([
            "ro.board.platform",
            "ro.hardware",
            "ro.boot.hardware",
            "ro.hardware.chipname",
            "ro.soc.model",
            "ro.build.version.release",
        ])
        
        # 检查是否为 Android 设备
        config.is_android = (
            "android" in platform.system().lower()
            or bool(props_map.get("ro.build.version.release", ""))
        )

        # 拼接所有硬件标识用于厂商匹配
        props_str = " ".join([
            props_map.get("ro.board.platform", ""),
            props_map.get("ro.hardware", ""),
            props_map.get("ro.boot.hardware", ""),
            props_map.get("ro.hardware.chipname", ""),
            props_map.get("ro.soc.model", ""),
        ]).lower()

        # 扫描系统库目录，收集现有 so 文件集合
        lib_dirs = [
            "/system/lib64",
            "/system/lib",
            "/vendor/lib64",
            "/vendor/lib",
            "/apex/com.android.runtime/lib64",
        ]
        existing_libs: set[str] = set()
        for d in lib_dirs:
            if os.path.isdir(d):
                try:
                    existing_libs.update(os.listdir(d))
                except OSError as e:
                    logger.debug("Failed to list dir %s: %s", d, e)

        def _has_any(names: List[str]) -> bool:
            """判断是否存在任一指定名称的库文件"""
            return any(any(name in fn for fn in existing_libs) for name in names)

        # NNAPI 检测
        config.nnapi = (
            _has_any(["libneuralnetworks.so"])
            or (config.is_android and bool(props_str))
        )
        # Vulkan 检测
        config.vulkan = _has_any(["libvulkan.so"])

        # 厂商识别
        vendor = ""
        qcom_keys = ("qcom", "sdm", "msm", "sm8", "sm7", "sm6", "sm4")
        mt_keys = ("mt", "mtk", "mediatek", "helio", "dimensity")
        
        if any(k in props_str for k in qcom_keys) or _has_any(
            ["libGLES_adreno", "libOpenCL", "adreno"]
        ):
            vendor = "Qualcomm Adreno / Hexagon"
        elif any(k in props_str for k in mt_keys) or _has_any(
            ["libGLES_mali", "libmali", "libneuronusdk"]
        ):
            vendor = "MediaTek APU / Mali"
        elif "exynos" in props_str or _has_any(["libGLES_mali", "mali"]):
            vendor = "Samsung Exynos / Mali"
        elif "unisoc" in props_str or "sprd" in props_str:
            vendor = "Unisoc"

        config.npu_vendor = vendor
        config.has_npu = bool(vendor) or config.nnapi

    def _model_data_dir(self) -> str:
        """获取模型实际落盘目录，用于准确计算可用存储。

        Returns:
            模型数据目录路径
        """
        env_models = os.environ.get("XIMU_MODELS_DIR")
        if env_models:
            return env_models
        
        env_root = os.environ.get("XIMU_DATA_ROOT")
        if env_root:
            return os.path.join(env_root, "models")
        
        cwd = os.getcwd()
        if os.access(cwd, os.W_OK):
            return cwd
        return os.path.abspath(os.sep)

    @staticmethod
    def _sanitize_disk_gb(value: float) -> float:
        """将磁盘 GB 值钳制到合理范围，防止异常值。

        Args:
            value: 原始磁盘容量值（GB）
            
        Returns:
            钳制后的有效值（0 ~ 1,000,000 GB）
        """
        if value < 0:
            return 0.0
        if value > 1_000_000.0:
            logger.warning(
                "Disk size %f GB is unreasonably large, clamping to 1 PB", value
            )
            return 1_000_000.0
        return value

    def _fits(self, tier: Dict[str, Any], config: DeviceConfig) -> Tuple[bool, str]:
        """检查模型档位是否适合当前设备配置。

        Args:
            tier: 模型档位字典，包含 file_gb, ram_gb 等字段
            config: 当前设备配置
            
        Returns:
            元组 (是否适合, 原因描述字符串)
        """
        required_disk = tier["file_gb"] + EMBED_FILE_GB
        required_disk_with_safety = required_disk * DISK_SAFETY_FACTOR

        if required_disk_with_safety > config.disk_available_gb:
            return False, (
                f"磁盘空间不足: 需要 {required_disk_with_safety:.2f}GB, "
                f"可用 {config.disk_available_gb:.2f}GB"
            )

        if tier["ram_gb"] > config.memory_gb:
            return False, (
                f"内存不足: 需要 {tier['ram_gb']:.1f}GB, "
                f"可用 {config.memory_gb:.1f}GB"
            )

        return True, "资源充足"

    def _pick_pair(self, config: DeviceConfig) -> Dict[str, Any]:
        """选择本地模型组合（主模型+嵌入模型），返回推荐计划。

        从大到小尝试各档位，返回第一个能运行的组合；若全部不可用，
        返回降级日志记录每个档位被阻止的原因。

        Args:
            config: 当前设备配置
            
        Returns:
            包含 model_size, quantization, embed_size, total_file_gb, 
            可选 blocked_log 字段的字典
        """
        for tier in MODEL_TIERS:
            fits, reason = self._fits(tier, config)
            if fits:
                return {
                    "model_size": tier["size"],
                    "quantization": tier["quant"],
                    "embed_size": "nomic-embed-q4",
                    "total_file_gb": round(tier["file_gb"] + EMBED_FILE_GB, 2),
                    "reason": reason,
                }

        # 无可用档位，收集阻塞原因
        blocked_log: List[str] = []
        for tier in MODEL_TIERS:
            _, reason = self._fits(tier, config)
            if not reason.startswith("资源充足"):
                blocked_log.append(f"{tier['size']}: {reason}")

        return {
            "model_size": None,
            "quantization": None,
            "embed_size": None,
            "total_file_gb": 0.0,
            "blocked_log": blocked_log,
        }

    # ---------- 公共 API ----------

    def detect(self) -> DeviceConfig:
        """检测设备配置（60 秒 TTL 缓存，避免频繁 fork getprop/读硬件）。

        TTL 内直接返回缓存结果；超过 TTL 自动重新检测。
        CPU 使用率通过约 0.1 秒的短区间采样获得有意义的均值。

        Returns:
            填充完整的 DeviceConfig 对象
        """
        if self._config is not None and (time.time() - self._detected_at) < _DETECT_CACHE_TTL:
            logger.debug("Using cached device detection result")
            return self._config

        config = DeviceConfig()

        # CPU（型号/核心数/使用率）
        try:
            config.cpu_model = platform.processor() or "Unknown CPU"
            config.cpu_cores = os.cpu_count() or 4
            config.cpu_percent = float(psutil.cpu_percent(interval=0.1))
        except Exception as e:
            logger.debug("CPU detection failed: %s", e)
            config.cpu_model = "Unknown"
            config.cpu_cores = 4
            config.cpu_percent = 0.0

        # 内存（总量与可用量分开）
        try:
            mem = psutil.virtual_memory()
            config.memory_gb = round(mem.available / (1024 ** 3), 1)
            config.memory_total_gb = round(mem.total / (1024 ** 3), 1)
        except Exception as e:
            logger.debug("Memory detection failed: %s", e)
            config.memory_gb = 0.0
            config.memory_total_gb = 0.0

        # GPU（桌面 torch/CUDA；手机上通常无）
        try:
            import torch

            if torch.cuda.is_available():
                config.gpu_model = torch.cuda.get_device_name(0)
                gpu_props = torch.cuda.get_device_properties(0)
                config.gpu_memory_gb = round(
                    gpu_props.total_mem / (1024 ** 3), 1
                )
        except Exception as e:
            logger.debug("GPU detection failed: %s", e)

        # 存储（按模型真实落盘目录，总量/可用分开）
        try:
            usage = shutil.disk_usage(self._model_data_dir())
            config.disk_available_gb = self._sanitize_disk_gb(
                usage.free / (1024 ** 3)
            )
            config.disk_total_gb = self._sanitize_disk_gb(usage.total / (1024 ** 3))
        except Exception as e:
            logger.debug("Disk detection failed: %s", e)
            config.disk_available_gb = 0.0
            config.disk_total_gb = 0.0

        # NPU / 加速运行时
        try:
            self._detect_npu(config)
        except Exception as e:
            logger.debug("NPU detection failed: %s", e)

        # 量化格式：llama.cpp CPU 基线始终支持 4bit；NNAPI 额外支持 int8/int4
        base_quant = ["Q4_0", "Q4_K_M", "Q5_K_M", "Q8_0"]
        config.supported_quant = list(base_quant)
        if config.nnapi:
            config.supported_quant = ["NNAPI_INT8", "NNAPI_INT4"] + base_quant

        config.os_name = platform.system()
        config.os_version = platform.release()

        self._config = config
        self._detected_at = time.time()
        logger.info(
            "Device detection completed: cpu=%s cores=%d mem=%.1fGB disk=%.1fGB npu=%s",
            config.cpu_model,
            config.cpu_cores,
            config.memory_gb,
            config.disk_available_gb,
            config.has_npu,
        )
        return config

    def list_compute_backends(self) -> List[Dict[str, Any]]:
        """返回本机真实计算接口（npu/gpu/cpu），供 EPSelector 与异构并行判断。

        不修改既有 detect() 行为，每项包含 name, kind, available 及可选详情字段。

        Returns:
            计算后端列表，每项为字典
        """
        cfg = self.detect()
        out: List[Dict[str, Any]] = []

        npu_available = cfg.has_npu or cfg.nnapi
        if npu_available:
            out.append({
                "name": "npu",
                "kind": "npu",
                "available": bool(cfg.nnapi),
                "vendor": cfg.npu_vendor,
            })

        if cfg.gpu_memory_gb >= 1.0:
            out.append({
                "name": "gpu",
                "kind": "gpu",
                "available": True,
                "gpu_memory_gb": cfg.gpu_memory_gb,
            })

        out.append({
            "name": "cpu",
            "kind": "cpu",
            "available": True,
            "cores": cfg.cpu_cores,
        })

        logger.debug("Listed %d compute backends", len(out))
        return out

    def get_recommendation(self) -> Dict[str, Any]:
        """获取经内存/存储硬校验的模型推荐（绝不推荐跑不动的模型）。

        结合 GPU 内存、端侧内存与磁盘空间，生成多档推荐及本地模型计划。

        Returns:
            包含 device_config, recommendations, local_model_plan 的字典
        """
        config = self.detect()

        recommendations: List[Dict[str, str]] = []

        # 桌面独显场景：GPU 内存 ≥ 8GB 可跑较大模型
        if config.gpu_memory_gb >= 8.0:
            recommendations.append({
                "model_size": "7-14B",
                "quantization": "Q5_K_M",
                "reason": "桌面独显，可运行较大模型",
            })

        # 端侧按可用内存给单档上限（从大到小找第一个能跑的）
        single: Optional[Dict[str, Any]] = None
        for tier in MODEL_TIERS:
            ok, _ = self._fits(tier, config)
            if ok:
                single = tier
                break

        if single and config.gpu_memory_gb == 0.0:
            recommendations.append({
                "model_size": single["size"].upper(),
                "quantization": single["quant"],
                "reason": (
                    f"按可用内存{config.memory_gb:.1f}GB/"
                    f"存储{config.disk_available_gb:.1f}GB校验可运行"
                ),
            })

        if not recommendations:
            recommendations.append({
                "model_size": "云端",
                "quantization": "-",
                "reason": "本地内存/存储不足以稳定运行端侧模型，建议仅用云端 API",
            })

        plan = self._pick_pair(config)

        result = {
            "device_config": {
                "cpu": config.cpu_model,
                "cores": config.cpu_cores,
                "gpu": config.gpu_model,
                "gpu_memory_gb": config.gpu_memory_gb,
                "memory_gb": config.memory_gb,
                "memory_total_gb": config.memory_total_gb,
                "disk_gb": config.disk_available_gb,
                "disk_total_gb": config.disk_total_gb,
                "is_android": config.is_android,
                "has_npu": config.has_npu,
                "npu_vendor": config.npu_vendor,
                "nnapi": config.nnapi,
                "vulkan": config.vulkan,
                "supported_quant": config.supported_quant,
            },
            "recommendations": recommendations,
            "local_model_plan": plan,
        }

        logger.info(
            "Model recommendation generated: %d recs, plan size=%s",
            len(recommendations),
            plan.get("model_size") or "none",
        )
        return result
