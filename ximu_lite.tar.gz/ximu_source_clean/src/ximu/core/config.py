"""
汐沫AI 核心配置模块。
提供基础 Config 类，供各核心模块使用。
"""
from __future__ import annotations

import os
from typing import Any, Dict, Optional


class Config:
    """核心配置类，承载系统运行所需的基础配置项。"""

    def __init__(self, **kwargs: Any) -> None:
        self._data: Dict[str, Any] = {}
        # 默认配置
        self._data["debug"] = os.getenv("XIMU_DEBUG", "false").lower() == "true"
        self._data["log_level"] = os.getenv("XIMU_LOG_LEVEL", "INFO")
        self._data["data_dir"] = os.getenv(
            "XIMU_DATA_DIR",
            os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data"),
        )
        # 覆盖默认值
        for key, value in kwargs.items():
            self._data[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self._data[key] = value

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[key] = value

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def as_dict(self) -> Dict[str, Any]:
        return dict(self._data)
