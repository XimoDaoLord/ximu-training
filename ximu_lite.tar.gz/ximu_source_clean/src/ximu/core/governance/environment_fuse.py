# -*- coding: utf-8 -*-
"""环境熔断器与全局状态稳定锁。"""
from __future__ import annotations

import time
from enum import Enum
from typing import Dict, List, Optional


class EnvLabel(Enum):
    CLEAN = "clean"
    SUSPECT = "suspect"
    CONTAMINATED = "contaminated"
    ISOLATED = "isolated"


class EnvironmentFuse:
    """环境隔离熔断器。"""

    def __init__(self) -> None:
        self.labels: Dict[str, EnvLabel] = {}
        self.events: List[dict] = []

    def label_of(self, env: str) -> EnvLabel:
        """获取环境当前标签。"""
        return self.labels.get(env, EnvLabel.CLEAN)

    def mark(self, env: str, label: EnvLabel) -> None:
        """标记环境标签。"""
        prev = self.label_of(env)
        self.labels[env] = label
        self.events.append({"env": env, "from": prev.value, "to": label.value, "ts": time.time()})

    def trip(self, env: str) -> dict:
        """触发熔断并隔离。"""
        self.mark(env, EnvLabel.CONTAMINATED)
        self.mark(env, EnvLabel.ISOLATED)
        return {"env": env, "fused": True, "isolated": True}

    def allow(self, env: str) -> bool:
        """判断环境是否允许操作。"""
        return self.label_of(env) != EnvLabel.ISOLATED


class GlobalStabilityLock:
    """全局状态机锁定。"""

    LEGAL = {
        "idle": {"running"},
        "running": {"paused", "frozen", "done", "error"},
        "paused": {"running", "frozen"},
        "frozen": {"idle", "running"},
        "error": {"idle", "frozen"},
        "done": {"idle"},
    }

    def __init__(self, state: str = "idle") -> None:
        self.state = state
        self.frozen = False
        self.freeze_reason: Optional[str] = None

    def can_transit(self, to: str) -> bool:
        """判断状态转换是否合法。"""
        return to in self.LEGAL.get(self.state, set())

    def transit(self, to: str) -> dict:
        """执行状态转换。"""
        if not self.can_transit(to):
            raise ValueError(f"非法状态转换: {self.state} -> {to}")
        self.state = to
        return {"state": self.state, "ok": True}

    def freeze(self, reason: str = "metacognitive_freeze") -> dict:
        """冻结全局状态。"""
        self.frozen = True
        self.freeze_reason = reason
        if self.can_transit("frozen"):
            self.state = "frozen"
        return {"frozen": True, "reason": reason}

    def require_unfrozen(self) -> None:
        """检查是否处于冻结状态。"""
        if self.frozen:
            raise RuntimeError(f"全局已冻结，拒绝变更: {self.freeze_reason}")

    def mutate(self, key: str, value: any) -> dict:
        """执行受保护的变更。"""
        self.require_unfrozen()
        return {key: value, "applied": True}

    def unfreeze(self, to: str = "running") -> dict:
        """解冻全局状态。"""
        self.frozen = False
        self.freeze_reason = None
        self.state = to
        return {"frozen": False, "state": self.state}

    def snapshot(self) -> dict:
        """获取状态快照。"""
        return {"state": self.state, "frozen": self.frozen, "reason": self.freeze_reason}

    def restore(self, snap: dict) -> None:
        """恢复状态快照。"""
        self.state, self.frozen, self.freeze_reason = snap["state"], snap["frozen"], snap.get("reason")
    