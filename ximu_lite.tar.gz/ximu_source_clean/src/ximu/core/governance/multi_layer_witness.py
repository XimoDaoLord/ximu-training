# -*- coding: utf-8 -*-
"""多层见证架构。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

LAYERS = ["L0", "L1", "L2", "L3", "L4"]


@dataclass
class Opinion:
    """见证意见。"""
    layer: str
    verdict: str
    confidence: float
    reason: str = ""


@dataclass
class WitnessReport:
    """见证报告。"""
    opinions: List[Opinion] = field(default_factory=list)
    discrepancy: bool = False
    discrepancy_layers: List[str] = field(default_factory=list)
    consensus: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典。"""
        return {
            "opinions": [o.__dict__ for o in self.opinions],
            "discrepancy": self.discrepancy,
            "discrepancy_layers": self.discrepancy_layers,
            "consensus": self.consensus,
        }


class MultiLayerWitness:
    """多层见证管理器。"""

    def __init__(self) -> None:
        self._layers: Dict[str, Callable[[Any], Opinion]] = {}

    def add_layer(self, layer: str, judge: Callable[[Any], Opinion]) -> None:
        """添加见证层。"""
        if layer not in LAYERS:
            raise ValueError(f"见证层必须是 {LAYERS} 之一")
        self._layers[layer] = judge

    def evaluate(self, payload: Any) -> WitnessReport:
        """评估 payload。"""
        rep = WitnessReport()
        for layer in LAYERS:
            judge = self._layers.get(layer)
            if judge is None:
                continue
            op = judge(payload)
            op.layer = layer
            rep.opinions.append(op)
        verdicts = [o.verdict for o in rep.opinions if o.verdict != "abstain"]
        rep.consensus = max(set(verdicts), key=verdicts.count) if verdicts else "abstain"
        distinct = set(verdicts)
        if len(distinct) > 1:
            rep.discrepancy = True
            rep.discrepancy_layers = [o.layer for o in rep.opinions if o.verdict != rep.consensus]
        return rep

    @staticmethod
    def mark_disagreement(model_a: str, model_b: str) -> Dict[str, Any]:
        """标记模型间分歧。"""
        return {"disagreement": True, "between": [model_a, model_b], "marker": "multi_model_witness_discrepancy"}
    