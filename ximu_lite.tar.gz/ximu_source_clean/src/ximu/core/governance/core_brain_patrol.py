# -*- coding: utf-8 -*-
"""核心大脑巡查。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


@dataclass
class PatrolVerdict:
    """巡查裁决。"""
    passed: bool
    reasons: List[str] = field(default_factory=list)
    rerun: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典。

        Returns:
            Dict[str, Any]: 巡查裁决的字典表示。
        """
        return {"passed": self.passed, "reasons": self.reasons, "rerun": self.rerun}


class CoreBrainPatrol:
    """核心大脑巡查器。"""

    def __init__(self, rules: Optional[List[Callable[[Any], Optional[str]]]] = None) -> None:
        """初始化核心大脑巡查器。

        Args:
            rules: 巡查规则列表，默认为内置规则。
        """
        self.rules: List[Callable[[Any], Optional[str]]] = rules or [
            self._rule_nonempty,
            self._rule_schema,
            self._rule_confidence,
            self._rule_placeholder,
        ]

    @staticmethod
    def _rule_nonempty(out: Any) -> Optional[str]:
        """检查产出是否为空。

        Args:
            out: 产出内容。

        Returns:
            Optional[str]: 如果产出为空则返回原因，否则返回 None。
        """
        if out is None or (hasattr(out, "__len__") and len(out) == 0):
            return "产出为空"
        return None

    @staticmethod
    def _rule_schema(out: Any) -> Optional[str]:
        """检查产出是否缺少必要字段。

        Args:
            out: 产出内容。

        Returns:
            Optional[str]: 如果缺少 answer 字段则返回原因，否则返回 None。
        """
        if isinstance(out, dict) and "answer" not in out:
            return "产出缺少 answer 字段"
        return None

    @staticmethod
    def _rule_confidence(out: Any) -> Optional[str]:
        """检查置信度是否在有效范围内。

        Args:
            out: 产出内容。

        Returns:
            Optional[str]: 如果置信度越界则返回原因，否则返回 None。
        """
        if isinstance(out, dict) and isinstance(out.get("confidence"), (int, float)):
            if not 0.0 <= out["confidence"] <= 1.0:
                return "置信度越界"
        return None

    @staticmethod
    def _rule_placeholder(out: Any) -> Optional[str]:
        """检查产出是否为占位内容。

        Args:
            out: 产出内容。

        Returns:
            Optional[str]: 如果是占位内容则返回原因，否则返回 None。
        """
        if isinstance(out, dict) and isinstance(out.get("answer"), str):
            if out["answer"].strip() in ("", "TODO", "占位", "..."):
                return "产出为占位内容"
        return None

    def inspect(self, output: Any) -> PatrolVerdict:
        """执行巡查检查。

        Args:
            output: 待检查的产出。

        Returns:
            PatrolVerdict: 巡查裁决结果。
        """
        reasons: List[str] = [msg for rule in self.rules for msg in [rule(output)] if msg is not None]
        if reasons:
            return PatrolVerdict(passed=False, reasons=reasons, rerun=True)
        return PatrolVerdict(passed=True, reasons=[], rerun=False)

    def patrol_or_rerun(self, output: Any, producer: Callable[[], Any], max_rerun: int = 2) -> Dict[str, Any]:
        """不合格则重跑。

        Args:
            output: 初始产出。
            producer: 生成新产出的函数。
            max_rerun: 最大重跑次数。

        Returns:
            Dict[str, Any]: 包含最终裁决、重跑次数和最终产出的字典。
        """
        attempts: int = 0
        verdict: PatrolVerdict = self.inspect(output)
        while verdict.rerun and attempts < max_rerun:
            attempts += 1
            output = producer()
            verdict = self.inspect(output)
        return {"verdict": verdict.to_dict(), "attempts": attempts, "final": output}
