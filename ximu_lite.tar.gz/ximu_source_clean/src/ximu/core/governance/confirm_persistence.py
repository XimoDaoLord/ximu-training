# -*- coding: utf-8 -*-
"""人类确认点的宿主层持久化与审计（P159）。

提供 SQLite 持久化与 JSONL 审计，支持重启恢复与全局查询。
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger("src.ximu.core.governance.confirm_persistence")

EXTREME_RISK_KW = (
    "格式化", "format", "恢复出厂", "factory reset", "清除全部", "清空全部", "清空所有", "wipe",
    "erase all", "全清", "卸载", "uninstall", "rm -rf", "rm -fr", "系统目录", "system dir",
    "/system", "/root", "su ", "chmod", "chown", "root", "刷机", "刷入", "bootloader",
    "权限变更", "改权限", "permission change", "grant root", "授予root", "全盘", "磁盘",
    "disk", "partition", "分区", "批量删除", "删除全部", "delete all", "delete system", "删除系统",
    "清空数据库", "drop table", "truncate",
)


def is_extreme_risk(kind: str, question: str) -> bool:
    """判断确认点是否属于「极度高危」。"""
    text = ((kind or "") + " " + (question or "")).lower()
    return any(kw in text for kw in EXTREME_RISK_KW)


_lock = threading.RLock()
_db_path: str = ""
_jsonl_path: str = ""
_initialized = False


def init(db_dir: str) -> str:
    """初始化持久化目录，返回 db 文件路径。"""
    global _db_path, _jsonl_path, _initialized
    with _lock:
        try:
            os.makedirs(db_dir, exist_ok=True)
            _db_path = os.path.join(db_dir, "confirm_pending.db")
            _jsonl_path = os.path.join(db_dir, "confirm_audit.jsonl")
            _ensure_schema()
            _initialized = True
        except Exception as e:
            logger.warning("confirm_persistence init 失败: %s", e)
        return _db_path


def _conn() -> sqlite3.Connection:
    """创建 SQLite 连接。"""
    c = sqlite3.connect(_db_path, timeout=5.0, check_same_thread=False)
    c.row_factory = sqlite3.Row
    return c


def _ensure_schema() -> None:
    """确保数据库表结构存在。"""
    with _conn() as c:
        c.execute("CREATE TABLE IF NOT EXISTS pending (...)")
        c.execute("CREATE TABLE IF NOT EXISTS audit (...)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_audit_confirm ON audit(confirm_id)")


def rebuild_pending(suspended: List[Dict[str, Any]]) -> int:
    """全量重建 pending 表。"""
    if not _initialized:
        return 0
    with _lock:
        try:
            rows = [_row_from_suspended(i) for i in (suspended or []) if i.get("confirm_id")]
            with _conn() as c:
                c.execute("DELETE FROM pending")
                for r in rows:
                    c.execute("INSERT OR REPLACE INTO pending (...) VALUES (:confirm_id,:loop_id,:topic_id,:kind,:question,:source,:created_at)", r)
            return len(rows)
        except Exception as e:
            logger.warning("rebuild_pending 失败: %s", e)
            return 0


def _row_from_suspended(item: Dict[str, Any]) -> Dict[str, Any]:
    """将悬停项转换为数据库行。"""
    return {
        "confirm_id": str(item.get("confirm_id") or ""),
        "loop_id": str(item.get("loop_id") or ""),
        "topic_id": str(item.get("topic_id") or ""),
        "kind": str(item.get("kind") or ""),
        "question": str(item.get("question") or ""),
        "source": str(item.get("source") or "live"),
        "created_at": float(item.get("created_at") or time.time()),
    }


def list_pending() -> List[Dict[str, Any]]:
    """获取所有待确认点。"""
    if not _initialized:
        return []
    with _lock:
        try:
            with _conn() as c:
                cur = c.execute("SELECT ... FROM pending ORDER BY created_at ASC")
                return [dict(r) for r in cur.fetchall()]
        except Exception as e:
            logger.warning("list_pending 失败: %s", e)
            return []


def record_decision(confirm_id: str, loop_id: str, decision: str, note: str = "", by: str = "user") -> Dict[str, Any]:
    """记录决策并写入审计日志。"""
    rec: Dict[str, Any] = {"confirm_id": confirm_id, "loop_id": loop_id, "action": "respond",
                           "decision": decision, "note": note, "by": by, "timestamp": time.time()}
    with _lock:
        if _initialized:
            try:
                with _conn() as c:
                    c.execute("INSERT INTO audit (...) VALUES (?,?,?,?,?,?,?)", (...))
                    c.execute("DELETE FROM pending WHERE confirm_id=?", (rec["confirm_id"],))
            except Exception as e:
                logger.warning("audit 写 SQLite 失败: %s", e)
        try:
            if _jsonl_path:
                with open(_jsonl_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception as e:
            logger.warning("audit 写 jsonl 失败: %s", e)
    return rec


def list_audit(limit: int = 100) -> List[Dict[str, Any]]:
    """获取最近的审计记录。"""
    if not _initialized:
        return []
    with _lock:
        try:
            with _conn() as c:
                cur = c.execute("SELECT ... FROM audit ORDER BY id DESC LIMIT ?", (int(limit),))
                return [dict(r) for r in cur.fetchall()]
        except Exception as e:
            logger.warning("list_audit 失败: %s", e)
            return []
    