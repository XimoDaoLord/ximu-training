# -*- coding: utf-8 -*-
"""传感器-决策分离。"""
from __future__ import annotations

from typing import Any, Dict

_DECISION_WORDS = ("decide", "choose", "plan", "act", "commit", "approve", "select_action")


class DecisionForbiddenError(RuntimeError):
    """决策禁止错误。"""
    pass


class TransitSensor:
    """中转传感器：仅做 parse-only 工作。"""

    def parse(self, raw: bytes) -> Dict[str, Any]:
        """解析原始字节流。"""
        if not isinstance(raw, (bytes, bytearray)):
            raise TypeError("中转只接收字节流")
        return {"size": len(raw), "normalized": True, "sha_input": True}

    def validate_shape(self, parsed: Dict[str, Any]) -> bool:
        """验证解析结果结构。"""
        return bool(parsed.get("normalized")) and parsed.get("size", 0) >= 0

    def decide(self, *a: Any, **k: Any) -> None:
        """禁止决策方法。"""
        raise DecisionForbiddenError("中转/传感器层禁止决策：解析与决策必须分离")

    # 任何决策类别名都指向同一拒绝路径
    choose = plan = act = commit = select_action = decide


def assert_parse_only(method_name: str) -> None:
    """断言方法名属于解析类，否则抛出异常。"""
    if method_name.lower() in _DECISION_WORDS:
        raise DecisionForbiddenError(f"传感器层禁止调用决策方法: {method_name}")
    