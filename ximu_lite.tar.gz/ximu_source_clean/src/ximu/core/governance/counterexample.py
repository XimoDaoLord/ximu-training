# -*- coding: utf-8 -*-
"""错误驱动进化 - 反例生成器。"""
from __future__ import annotations

from typing import Any, Dict, List

# 特殊测试输入列表
SPECIAL: List[str] = ["", " ", "<script>", "' OR '1'='1", "../", "\x00", "[X]" * 3]


class CounterexampleGenerator:
    """确定性反例生成器。"""

    def _mutations(self, sample: Any) -> List[Dict[str, Any]]:
        """生成变异反例列表。

        Args:
            sample: 示例输入。

        Returns:
            List[Dict[str, Any]]: 变异反例列表。
        """
        results: List[Dict[str, Any]] = []
        results.append({"input": "", "rationale": "空输入", "expected": "graceful_handled"})
        if isinstance(sample, (int, float)):
            numeric_mutations: List[tuple] = [
                (0, "零值"),
                (-1, "负边界"),
                (2**31 - 1, "int32 上界"),
                (float("inf"), "无穷"),
            ]
            for value, reason in numeric_mutations:
                results.append({"input": value, "rationale": reason, "expected": "graceful_handled"})
            results.append({"input": str(sample), "rationale": "数值被字符串替换", "expected": "type_guarded"})
        elif isinstance(sample, str):
            results.append({"input": sample * 1000, "rationale": "超长输入", "expected": "truncated_or_guarded"})
            for special_input in SPECIAL[1:]:
                results.append({"input": special_input, "rationale": "特殊字符", "expected": "sanitized_or_guarded"})
            results.append({"input": 12345, "rationale": "字符串被数值替换", "expected": "type_guarded"})
        elif isinstance(sample, (list, dict)):
            results.append({"input": type(sample)(), "rationale": "空容器", "expected": "graceful_handled"})
            results.append({"input": None, "rationale": "容器被 None 替换", "expected": "type_guarded"})
        else:
            results.append({"input": None, "rationale": "None 输入", "expected": "graceful_handled"})
        return results

    def generate(self, error_type: str, sample: Any, context: Any = None) -> List[Dict[str, Any]]:
        """生成去重后的反例列表。

        Args:
            error_type: 错误类型。
            sample: 示例输入。
            context: 上下文信息（可选）。

        Returns:
            List[Dict[str, Any]]: 去重后的反例列表。
        """
        out: List[Dict[str, Any]] = []
        seen: set = set()
        for mutation in self._mutations(sample):
            key = repr(mutation["input"])
            if key in seen:
                continue
            seen.add(key)
            mutation["error_type"] = error_type
            out.append(mutation)
        return out

    def is_true_counterexample(self, runner: Any, error_type: str, sample: Any) -> Dict[str, int]:
        """验证反例是否真能复现错误。

        Args:
            runner: 执行函数。
            error_type: 错误类型。
            sample: 示例输入。

        Returns:
            Dict[str, int]: 包含命中数、总数和命中率的字典。
        """
        hit: int = 0
        total: int = 0
        for counterexample in self.generate(error_type, sample):
            total += 1
            try:
                runner(counterexample["input"])
            except Exception as e:
                if error_type.lower() in type(e).__name__.lower():
                    hit += 1
        return {"hit": hit, "total": total, "rate": round(hit / total, 3) if total else 0.0}
