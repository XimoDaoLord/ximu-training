# -*- coding: utf-8 -*-
"""统一可切换组件管理器。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

NON_ORIGINAL_WARNING = "当前非原装配置，请注意风险"
CORE_BRAIN = "核心大脑"


@dataclass
class Slot:
    """组件插槽。"""
    kind: str
    original: Any
    current: Any = None
    non_original: bool = False
    history: List[Any] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.current is None:
            self.current = self.original


class ComponentSwitchManager:
    """组件切换与回滚管理器。"""

    def __init__(self) -> None:
        self._slots: Dict[str, Slot] = {}

    def register_original(self, kind: str, component: Any) -> None:
        """登记原装组件。"""
        self._slots[kind] = Slot(kind=kind, original=component)

    def _slot(self, kind: str) -> Slot:
        """获取插槽。"""
        if kind not in self._slots:
            raise KeyError(f"未登记的组件类型: {kind}")
        return self._slots[kind]

    def replace(self, kind: str, component: Any, *, acknowledge_core: bool = False) -> Dict[str, Any]:
        """替换组件。"""
        slot = self._slot(kind)
        if kind == CORE_BRAIN and not acknowledge_core:
            raise PermissionError("核心大脑默认为不可替换组件")
        slot.history.append(slot.current)
        slot.current = component
        slot.non_original = True
        return {"kind": kind, "replaced": True, "non_original": True, "warning": NON_ORIGINAL_WARNING}

    def current(self, kind: str) -> Any:
        """获取当前组件。"""
        return self._slot(kind).current

    def is_non_original(self, kind: str) -> bool:
        """检查是否非原装。"""
        return self._slot(kind).non_original

    def marker(self, kind: str) -> Optional[Dict[str, str]]:
        """获取非原装标识。"""
        return {"kind": kind, "warning": NON_ORIGINAL_WARNING} if self.is_non_original(kind) else None

    def all_markers(self) -> List[Dict[str, str]]:
        """获取所有非原装标识。"""
        return [m for m in (self.marker(k) for k in self._slots) if m]

    def rollback(self, kind: str) -> Dict[str, Any]:
        """回滚到原装。"""
        slot = self._slot(kind)
        slot.current = slot.original
        slot.non_original = False
        slot.history.clear()
        return {"kind": kind, "rolled_back": True, "non_original": False}

    def snapshot(self) -> Dict[str, bool]:
        """获取快照。"""
        return {k: v.non_original for k, v in self._slots.items()}

    def restore(self, snap: Dict[str, bool]) -> None:
        """恢复快照。"""
        for k, nonorig in snap.items():
            if k in self._slots and not nonorig:
                self.rollback(k)
    