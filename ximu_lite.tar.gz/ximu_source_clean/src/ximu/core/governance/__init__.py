# -*- coding: utf-8 -*-
"""核心治理组件导出。"""

from .component_switch import CORE_BRAIN, NON_ORIGINAL_WARNING, ComponentSwitchManager
from .core_brain_patrol import CoreBrainPatrol, PatrolVerdict
from .counterexample import CounterexampleGenerator
from .environment_fuse import EnvironmentFuse, EnvLabel, GlobalStabilityLock
from .multi_layer_witness import LAYERS, MultiLayerWitness, Opinion, WitnessReport
from .sensor_decision_separation import DecisionForbiddenError, TransitSensor, assert_parse_only

__all__ = [
    "NON_ORIGINAL_WARNING", "CORE_BRAIN", "ComponentSwitchManager", "CounterexampleGenerator",
    "LAYERS", "Opinion", "WitnessReport", "MultiLayerWitness", "DecisionForbiddenError",
    "TransitSensor", "assert_parse_only", "EnvLabel", "EnvironmentFuse", "GlobalStabilityLock",
    "PatrolVerdict", "CoreBrainPatrol",
]
    