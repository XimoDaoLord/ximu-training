import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Union

logger = logging.getLogger("src.ximu.core.paradigm.state_machine")

# 版本号
__version__ = "0.5"


class SystemState(Enum):
    """系统全局状态枚举"""
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"
    DEGRADED = "degraded"
    ERROR = "error"
    SHUTTING_DOWN = "shutting_down"


# 合法状态转换映射
VALID_TRANSITIONS: Dict[SystemState, Set[SystemState]] = {
    SystemState.INITIALIZING: {SystemState.RUNNING, SystemState.ERROR, SystemState.SHUTTING_DOWN},
    SystemState.RUNNING: {SystemState.PAUSED, SystemState.DEGRADED, SystemState.ERROR, SystemState.SHUTTING_DOWN},
    SystemState.PAUSED: {SystemState.RUNNING, SystemState.DEGRADED, SystemState.ERROR, SystemState.SHUTTING_DOWN},
    SystemState.DEGRADED: {SystemState.RUNNING, SystemState.PAUSED, SystemState.ERROR, SystemState.SHUTTING_DOWN},
    SystemState.ERROR: {SystemState.RUNNING, SystemState.INITIALIZING, SystemState.SHUTTING_DOWN},
    SystemState.SHUTTING_DOWN: set(),  # 终态
}


@dataclass
class StateTransition:
    """状态转换记录"""
    transition_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    from_state: SystemState = SystemState.INITIALIZING
    to_state: SystemState = SystemState.RUNNING
    reason: str = ""
    triggered_by: str = ""
    timestamp: float = field(default_factory=time.time)
    duration_ms: float = 0.0


@dataclass
class StateStats:
    """状态统计信息"""
    current_state: SystemState = SystemState.INITIALIZING
    state_durations: Dict[str, float] = field(default_factory=dict)
    transition_count: int = 0
    error_count: int = 0
    last_transition_at: float = field(default_factory=time.time)
    uptime_seconds: float = 0.0


class GlobalStateMachine:
    """
    全局状态机：管理系统全局状态，校验合法转换，触发联动回调，持久化状态。

    该状态机实现了系统核心生命周期的管理，支持六种主要状态：
    - INITIALIZING: 初始化阶段
    - RUNNING: 正常运行
    - PAUSED: 暂停
    - DEGRADED: 降级运行
    - ERROR: 错误状态
    - SHUTTING_DOWN: 关机过程

    状态机通过VALID_TRANSITIONS定义合法转换路径，确保系统状态变化的确定性。
    支持模块级状态联动，当模块状态变化时可触发全局状态降级。
    """

    def __init__(self, initial_state: SystemState = SystemState.INITIALIZING) -> None:
        """
        初始化全局状态机。

        Args:
            initial_state: 初始系统状态，默认为INITIALIZING
        """
        self._current_state: SystemState = initial_state
        self._transition_history: List[StateTransition] = []
        self._state_entered_at: Dict[SystemState, float] = {initial_state: time.monotonic()}
        self._state_durations: Dict[str, float] = {}
        self._callbacks: Dict[str, List[Callable[[StateTransition], None]]] = {}
        self._stats: StateStats = StateStats(current_state=initial_state)
        self._module_states: Dict[str, SystemState] = {}
        
        logger.info("GlobalStateMachine initialized with state: %s", initial_state.value)

    @property
    def current_state(self) -> SystemState:
        """获取当前系统状态"""
        return self._current_state

    def can_transition(self, to_state: SystemState) -> bool:
        """
        检查是否可以转换到目标状态。

        Args:
            to_state: 目标状态

        Returns:
            如果转换合法则返回True，否则返回False
        """
        return to_state in VALID_TRANSITIONS.get(self._current_state, set())

    def transition(self, to_state: SystemState, reason: str = "",
                   triggered_by: str = "system") -> bool:
        """
        执行状态转换。

        只有当前状态到目标状态的转换在VALID_TRANSITIONS中定义时才能成功。
        转换成功后会记录转换历史、更新统计信息、触发相关回调并同步模块状态。

        Args:
            to_state: 目标状态
            reason: 转换原因描述
            triggered_by: 触发者标识，默认为"system"

        Returns:
            转换成功返回True，失败返回False
        """
        if not self.can_transition(to_state):
            logger.warning("Invalid state transition requested: %s -> %s (reason: %s, triggered_by: %s)",
                          self._current_state.value, to_state.value, reason, triggered_by)
            self._stats.error_count += 1
            return False

        start_time = time.monotonic()
        from_state = self._current_state
        
        # 记录当前状态持续时间
        if from_state in self._state_entered_at:
            duration = time.monotonic() - self._state_entered_at[from_state]
            self._state_durations[from_state.value] = (
                self._state_durations.get(from_state.value, 0.0) + duration
            )

        # 执行转换
        self._current_state = to_state
        self._state_entered_at[to_state] = time.monotonic()
        
        transition = StateTransition(
            from_state=from_state,
            to_state=to_state,
            reason=reason,
            triggered_by=triggered_by,
            duration_ms=(time.monotonic() - start_time) * 1000,
        )
        
        self._transition_history.append(transition)
        self._stats.transition_count += 1
        self._stats.current_state = to_state
        self._stats.last_transition_at = time.time()

        # 触发回调
        self._trigger_callbacks("on_transition", transition)
        self._trigger_callbacks(f"on_enter_{to_state.value}", transition)
        self._trigger_callbacks(f"on_exit_{from_state.value}", transition)

        # 联动模块状态
        self._sync_module_states(to_state)

        logger.info("State transitioned: %s -> %s (reason: %s, triggered_by: %s)",
                   from_state.value, to_state.value, reason, triggered_by)
        return True

    def register_callback(self, event: str, callback: Callable[[StateTransition], None]) -> None:
        """
        注册状态事件回调。

        Args:
            event: 事件名称，如"on_transition", "on_enter_running", "on_exit_paused"等
            callback: 回调函数，接收StateTransition对象作为参数
        """
        self._callbacks.setdefault(event, []).append(callback)
        logger.debug("Callback registered for event: %s", event)

    def _trigger_callbacks(self, event: str, transition: StateTransition) -> None:
        """
        触发指定事件的所有回调。

        Args:
            event: 事件名称
            transition: 状态转换对象
        """
        for callback in self._callbacks.get(event, []):
            try:
                callback(transition)
            except Exception as e:
                logger.error("Callback execution failed for event '%s': %s", event, str(e), exc_info=True)
                raise  # 不吞异常，让调用者知道回调执行失败

    def _sync_module_states(self, global_state: SystemState) -> None:
        """
        联动模块状态：全局状态变化时同步各模块状态。

        Args:
            global_state: 新的全局状态
        """
        for module_name, module_state in self._module_states.items():
            if global_state == SystemState.SHUTTING_DOWN:
                if module_state != SystemState.SHUTTING_DOWN:
                    self._module_states[module_name] = SystemState.SHUTTING_DOWN
                    logger.debug("Module %s state synced to SHUTTING_DOWN", module_name)
            elif global_state == SystemState.ERROR:
                if module_state != SystemState.ERROR:
                    self._module_states[module_name] = SystemState.DEGRADED
                    logger.debug("Module %s state degraded due to global ERROR", module_name)

    def set_module_state(self, module_name: str, state: SystemState) -> None:
        """
        设置指定模块的状态。

        如果模块进入ERROR状态且系统当前在RUNNING状态，会自动触发系统降级到DEGRADED状态。

        Args:
            module_name: 模块名称
            state: 新的模块状态
        """
        self._module_states[module_name] = state
        logger.debug("Module %s state set to %s", module_name, state.value)
        
        # 如果有模块进入ERROR状态，全局状态可能降级
        if state == SystemState.ERROR:
            error_modules = sum(1 for s in self._module_states.values()
                               if s == SystemState.ERROR)
            if error_modules > 0 and self._current_state == SystemState.RUNNING:
                self.transition(SystemState.DEGRADED,
                               reason=f"{error_modules}个模块进入ERROR状态",
                               triggered_by=module_name)

    def get_module_state(self, module_name: str) -> Optional[SystemState]:
        """
        获取指定模块的状态。

        Args:
            module_name: 模块名称

        Returns:
            模块状态，如果模块不存在则返回None
        """
        return self._module_states.get(module_name)

    def get_transition_history(self, limit: int = 50) -> List[StateTransition]:
        """
        获取最近的状态转换历史。

        Args:
            limit: 返回的最大记录数量，默认为50

        Returns:
            最近的转换记录列表
        """
        if limit <= 0:
            return []
        return self._transition_history[-limit:]

    def get_stats(self) -> StateStats:
        """
        获取状态统计信息。

        Returns:
            包含当前状态、状态持续时间、转换计数等统计信息的StateStats对象
        """
        # 更新当前状态持续时间
        if self._current_state in self._state_entered_at:
            current_duration = time.monotonic() - self._state_entered_at[self._current_state]
            self._stats.state_durations = dict(self._state_durations)
            self._stats.state_durations[self._current_state.value] = (
                self._stats.state_durations.get(self._current_state.value, 0.0) + current_duration
            )
        
        if self._current_state == SystemState.RUNNING:
            running_entered_at = self._state_entered_at.get(
                SystemState.RUNNING, time.monotonic())
            self._stats.uptime_seconds = time.monotonic() - running_entered_at

        return self._stats

    def is_running(self) -> bool:
        """检查系统是否处于运行状态"""
        return self._current_state == SystemState.RUNNING

    def is_healthy(self) -> bool:
        """检查系统是否健康（RUNNING或PAUSED状态）"""
        return self._current_state in (SystemState.RUNNING, SystemState.PAUSED)

    def force_transition(self, to_state: SystemState, reason: str = "",
                         triggered_by: str = "emergency") -> bool:
        """
        强制状态转换（跳过合法性校验，仅用于紧急运维场景）。

        Args:
            to_state: 目标状态
            reason: 强制转换原因
            triggered_by: 触发者标识，默认为"emergency"

        Returns:
            强制转换成功返回True
        """
        from_state = self._current_state
        self._current_state = to_state
        self._state_entered_at[to_state] = time.monotonic()
        
        transition = StateTransition(
            from_state=from_state,
            to_state=to_state,
            reason=f"[强制] {reason}",
            triggered_by=triggered_by,
        )
        
        self._transition_history.append(transition)
        self._stats.transition_count += 1
        self._stats.current_state = to_state
        self._stats.last_transition_at = time.time()
        
        self._trigger_callbacks("on_transition", transition)
        self._trigger_callbacks(f"on_enter_{to_state.value}", transition)
        self._trigger_callbacks(f"on_exit_{from_state.value}", transition)
        
        logger.warning("Force state transition: %s -> %s (reason: %s, triggered_by: %s)",
                      from_state.value, to_state.value, reason, triggered_by)
        return True
