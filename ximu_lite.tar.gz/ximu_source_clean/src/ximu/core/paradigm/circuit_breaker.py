"""环境熔断器：CLOSED→OPEN→HALF_OPEN→CLOSED状态机，失败率/连续失败/超时触发，冷却期+半开探测，覆盖工具/模型/API/数据库调用。"""

import time
import threading
import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class CircuitState(Enum):
    """熔断器状态"""
    CLOSED = "closed"           # 关闭：正常放行请求
    OPEN = "open"               # 打开：快速失败，拒绝请求
    HALF_OPEN = "half_open"     # 半开：允许少量探测请求


@dataclass
class CircuitBreakerConfig:
    """熔断器配置"""
    failure_threshold: float = 0.5       # 失败率阈值（0-1）
    consecutive_failures: int = 5         # 连续失败次数阈值
    timeout_seconds: float = 30.0         # 响应超时阈值
    cooldown_seconds: float = 60.0        # 冷却期（OPEN状态持续时间）
    half_open_max_requests: int = 3       # 半开状态最大探测请求数
    min_requests: int = 10                 # 计算失败率的最小请求数
    window_seconds: float = 300.0         # 统计时间窗口
    max_concurrent_requests: int = 50      # 舱壁模式：最大并发请求数


@dataclass
class CircuitBreakerStats:
    """熔断器统计信息"""
    state: CircuitState = CircuitState.CLOSED
    total_requests: int = 0
    success_count: int = 0
    failure_count: int = 0
    timeout_count: int = 0
    consecutive_failures: int = 0
    failure_rate: float = 0.0
    last_failure_at: Optional[float] = None
    last_success_at: Optional[float] = None
    opened_at: Optional[float] = None
    transition_count: int = 0


class CircuitBreaker:
    """环境熔断器：单个资源的熔断器实现"""

    def __init__(self, name: str, config: Optional[CircuitBreakerConfig] = None) -> None:
        """初始化熔断器。

        Args:
            name: 熔断器名称，用于日志和回调标识。
            config: 熔断器配置，若未提供则使用默认配置。
        """
        self.name = name
        self.config = config or CircuitBreakerConfig()
        self._state: CircuitState = CircuitState.CLOSED
        self._stats: CircuitBreakerStats = CircuitBreakerStats()
        self._request_window: List[Tuple[float, bool]] = []  # (monotonic_ts, is_success)
        self._half_open_requests: int = 0
        self._half_open_dispatched: int = 0
        self._opened_at_mono: Optional[float] = None  # 冷却期时长计算用monotonic(抗NTP回拨)
        self._concurrent_requests: int = 0  # 舱壁模式：当前并发请求数
        self._on_open_callbacks: List[Callable[[str, str], Any]] = []
        self._on_close_callbacks: List[Callable[[str, str], Any]] = []
        self._lock: threading.RLock = threading.RLock()  # 并发安全：状态/计数转换原子化

    @property
    def state(self) -> CircuitState:
        """获取当前状态。

        Returns:
            当前的熔断器状态。
        """
        return self._state

    def allow_request(self) -> bool:
        """是否允许请求通过（熔断器状态+舱壁并发限制）。

        Returns:
            若请求允许通过则返回True，否则返回False。
        """
        with self._lock:
            # 舱壁模式：检查并发请求数
            if self._concurrent_requests >= self.config.max_concurrent_requests:
                logger.debug("熔断器 %s 舱壁已满，并发请求数: %d", self.name, self._concurrent_requests)
                return False

            now = time.monotonic()
            if self._state == CircuitState.CLOSED:
                return True

            if self._state == CircuitState.OPEN:
                # 检查是否过了冷却期（持续时间计算用monotonic）
                if self._opened_at_mono is not None:
                    cooldown_elapsed = now - self._opened_at_mono
                    if cooldown_elapsed >= self.config.cooldown_seconds:
                        logger.debug("熔断器 %s 冷却期结束，进入HALF_OPEN状态", self.name)
                        self._transition_to(CircuitState.HALF_OPEN, reason="冷却期结束")
                        self._half_open_requests = 0
                        self._half_open_dispatched = 1
                        return True

                return False

            if self._state == CircuitState.HALF_OPEN:
                if self._half_open_dispatched < self.config.half_open_max_requests:
                    self._half_open_dispatched += 1
                    return True
                return False

            return False

    def record_success(self) -> None:
        """记录成功请求。"""
        with self._lock:
            now_wall = time.time()
            now_mono = time.monotonic()
            self._stats.total_requests += 1
            self._stats.success_count += 1
            self._stats.consecutive_failures = 0
            self._stats.last_success_at = now_wall  # wall-clock审计时间戳，保留
            self._request_window.append((now_mono, True))
            self._cleanup_window()

            if self._state == CircuitState.HALF_OPEN:
                self._half_open_requests += 1
                # 半开状态下成功次数足够则关闭熔断器
                if self._half_open_requests >= self.config.half_open_max_requests:
                    self._transition_to(CircuitState.CLOSED, reason="半开探测全部成功")

            self._update_failure_rate()

    def record_failure(self, is_timeout: bool = False) -> None:
        """记录失败请求。

        Args:
            is_timeout: 是否为超时导致的失败。
        """
        with self._lock:
            now_wall = time.time()
            now_mono = time.monotonic()
            self._stats.total_requests += 1
            self._stats.failure_count += 1
            self._stats.consecutive_failures += 1
            self._stats.last_failure_at = now_wall  # wall-clock审计时间戳，保留
            if is_timeout:
                self._stats.timeout_count += 1
            self._request_window.append((now_mono, False))
            self._cleanup_window()

            if self._state == CircuitState.HALF_OPEN:
                # 半开状态下任何失败都重新打开
                self._transition_to(CircuitState.OPEN, reason="半开探测失败")
                self._half_open_dispatched = 0
                return

            if self._state == CircuitState.CLOSED:
                # 检查是否需要打开熔断器
                if self._should_open():
                    self._transition_to(CircuitState.OPEN, reason="失败率/连续失败超过阈值")

            self._update_failure_rate()

    def _should_open(self) -> bool:
        """判断是否应该打开熔断器。

        Returns:
            若满足打开条件则返回True，否则返回False。
        """
        # 连续失败超过阈值
        if self._stats.consecutive_failures >= self.config.consecutive_failures:
            return True

        # 失败率超过阈值（需要足够的请求数）
        recent = self._get_recent_requests()
        if len(recent) >= self.config.min_requests:
            failures = sum(1 for _, success in recent if not success)
            failure_rate = failures / len(recent)
            if failure_rate >= self.config.failure_threshold:
                return True

        return False

    def _transition_to(self, new_state: CircuitState, reason: str = "") -> None:
        """转换状态。

        Args:
            new_state: 目标状态。
            reason: 转换原因，用于日志和回调。
        """
        logger.info("熔断器 %s 状态转换: %s -> %s, 原因: %s", self.name, self._state.value, new_state.value, reason)
        self._state = new_state
        self._stats.state = new_state
        self._stats.transition_count += 1

        if new_state == CircuitState.OPEN:
            self._stats.opened_at = time.time()        # wall-clock审计时间戳，保留
            self._opened_at_mono = time.monotonic()    # 冷却期时长计算用monotonic
            for callback in self._on_open_callbacks:
                try:
                    callback(self.name, reason)
                except Exception as e:
                    logger.warning("熔断器打开回调失败: %s", e)
        elif new_state == CircuitState.CLOSED:
            self._stats.consecutive_failures = 0
            for callback in self._on_close_callbacks:
                try:
                    callback(self.name, reason)
                except Exception as e:
                    logger.warning("熔断器关闭回调失败: %s", e)

    def _cleanup_window(self) -> None:
        """清理过期的请求记录（滑动窗口为持续时间计算，用monotonic）。"""
        now = time.monotonic()
        cutoff = now - self.config.window_seconds
        self._request_window = [(ts, success) for ts, success in self._request_window if ts >= cutoff]

    def _get_recent_requests(self) -> List[Tuple[float, bool]]:
        """获取最近时间窗口内的请求。

        Returns:
            最近时间窗口内的请求列表，每个元素为(时间戳, 是否成功)的元组。
        """
        return self._request_window

    def _update_failure_rate(self) -> None:
        """更新失败率。"""
        recent = self._get_recent_requests()
        if recent:
            failures = sum(1 for _, success in recent if not success)
            self._stats.failure_rate = failures / len(recent)

    def get_stats(self) -> CircuitBreakerStats:
        """获取熔断器统计信息。

        Returns:
            当前的统计信息。
        """
        return self._stats

    def reset(self) -> None:
        """重置熔断器。"""
        with self._lock:
            logger.info("熔断器 %s 重置", self.name)
            self._state = CircuitState.CLOSED
            self._stats = CircuitBreakerStats()
            self._request_window = []
            self._half_open_requests = 0
            self._half_open_dispatched = 0
            self._opened_at_mono = None
            self._concurrent_requests = 0

    def execute(self, func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        """执行受保护的函数调用（熔断器+舱壁保护）。

        Args:
            func: 要执行的函数。
            args: 传递给函数的位置参数。
            kwargs: 传递给函数的关键字参数。

        Returns:
            函数的执行结果。

        Raises:
            CircuitBreakerOpenError: 当熔断器处于OPEN状态或舱壁已满时。
            Exception: 当函数执行抛出异常时。
        """
        # 根因修复(R27): 原实现先 allow_request()(放锁)再 _concurrent_requests+=1(无锁),
        # 构成 check-then-act(TOCTOU)竞态: 多线程可同时通过舱壁检查后再并发自增, 突破
        # max_concurrent_requests 上限。 改为持锁原子完成"检查+自增", func 仍在锁外运行。
        with self._lock:
            if not self.allow_request():
                raise CircuitBreakerOpenError(f"熔断器 {self.name} 处于OPEN状态或舱壁已满，请求被拒绝")
            self._concurrent_requests += 1

        start_time = time.monotonic()  # elapsed测量用monotonic抗NTP回拨
        try:
            result = func(*args, **kwargs)
            elapsed = time.monotonic() - start_time
            if elapsed > self.config.timeout_seconds:
                logger.warning("熔断器 %s 调用超时: %.2fs > %.2fs", self.name, elapsed, self.config.timeout_seconds)
                self.record_failure(is_timeout=True)
            else:
                self.record_success()
            return result
        except Exception as e:
            self.record_failure()
            raise e
        finally:
            with self._lock:
                self._concurrent_requests -= 1


class CircuitBreakerOpenError(Exception):
    """熔断器打开状态异常。"""

    def __init__(self, message: str = ""):
        """初始化异常。

        Args:
            message: 错误信息。
        """
        super().__init__(message)
        self.message = message


class CircuitBreakerRegistry:
    """熔断器注册表：管理多个资源的熔断器。"""

    def __init__(self) -> None:
        """初始化注册表。"""
        self._breakers: Dict[str, CircuitBreaker] = {}
        self._lock: threading.RLock = threading.RLock()

    def get_or_create(self, name: str, config: Optional[CircuitBreakerConfig] = None) -> CircuitBreaker:
        """获取或创建熔断器。

        Args:
            name: 熔断器名称。
            config: 熔断器配置，若不存在则使用此配置创建。

        Returns:
            熔断器实例。
        """
        with self._lock:
            if name not in self._breakers:
                logger.debug("创建新的熔断器: %s", name)
                self._breakers[name] = CircuitBreaker(name, config)
            return self._breakers[name]

    def get(self, name: str) -> Optional[CircuitBreaker]:
        """获取熔断器。

        Args:
            name: 熔断器名称。

        Returns:
            熔断器实例，若不存在则返回None。
        """
        with self._lock:
            return self._breakers.get(name)

    def get_all_stats(self) -> Dict[str, CircuitBreakerStats]:
        """获取所有熔断器统计。

        Returns:
            所有熔断器的统计信息字典，键为熔断器名称。
        """
        with self._lock:
            return {name: breaker.get_stats() for name, breaker in self._breakers.items()}

    def get_open_breakers(self) -> List[str]:
        """获取所有处于OPEN状态的熔断器。

        Returns:
            处于OPEN状态的熔断器名称列表。
        """
        with self._lock:
            return [name for name, breaker in self._breakers.items() if breaker.state == CircuitState.OPEN]
