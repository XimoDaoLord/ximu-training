from enum import Enum
from typing import Any, Dict, List, Optional
import time
import uuid
from dataclasses import dataclass, field

class RoleType(Enum):
    """统一角色类型枚举（OMNI-BRAIN V2范式核心）"""
    SOURCE = "source"  # 数据来源：模块执行完成后产生标准输出，统一写入数据总线
    VALIDATOR = "validator"  # 验证器：对比大脑预测值与实际执行结果，计算偏差
    EXECUTOR = "executor"  # 执行器：接收大脑决策指令，调度对应模块执行
    EVOLVER = "evolver"  # 进化器：分析验证结果，提取可学习模式，生成改进建议
    MEMORY = "memory"  # 记忆体：模块执行结果+关键上下文，按L1/L2/L3三级存储

@dataclass
class RoleOutput:
    """角色标准输出（所有角色产生的数据都遵循此格式）"""
    output_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    role_type: RoleType = RoleType.SOURCE
    source_module: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    prediction: Optional[Dict[str, Any]] = None
    actual: Optional[Dict[str, Any]] = None
    deviation: float = 0.0
    confidence: float = 1.0
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

class RoleBase:
    """角色基类（所有五角色的共同接口）"""
    def __init__(self, role_type: RoleType, name: str = ""):
        self.role_type = role_type
        self.name = name or role_type.value
        self._outputs: List[RoleOutput] = []
        self._call_count = 0
        self._error_count = 0

    def process(self, input_data: Dict[str, Any]) -> RoleOutput:
        """处理输入数据，产生标准输出（子类重写）"""
        self._call_count += 1
        output = RoleOutput(role_type=self.role_type, source_module=self.name, data=input_data)
        self._outputs.append(output)
        return output

    def get_outputs(self, limit: int = 50) -> List[RoleOutput]:
        """获取历史输出"""
        return self._outputs[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        """获取角色统计信息"""
        return {
            "role_type": self.role_type.value,
            "name": self.name,
            "call_count": self._call_count,
            "error_count": self._error_count,
            "output_count": len(self._outputs),
        }

class SourceRole(RoleBase):
    """数据来源角色：模块执行完成后产生标准输出，统一写入数据总线"""
    def __init__(self, name: str = "source"):
        super().__init__(RoleType.SOURCE, name)
        self._data_bus: List[RoleOutput] = []

    def process(self, input_data: Dict[str, Any]) -> RoleOutput:
        """产生标准输出并写入数据总线"""
        output = super().process(input_data)
        self._data_bus.append(output)
        return output

    def get_data_bus(self, limit: int = 100) -> List[RoleOutput]:
        """获取数据总线内容"""
        return self._data_bus[-limit:]

class ValidatorRole(RoleBase):
    """验证器角色：对比大脑预测值与实际执行结果，计算偏差"""
    def __init__(self, name: str = "validator"):
        super().__init__(RoleType.VALIDATOR, name)

    def validate(self, prediction: Dict[str, Any], actual: Dict[str, Any]) -> RoleOutput:
        """对比预测与实际，计算偏差"""
        self._call_count += 1
        deviation = self._compute_deviation(prediction, actual)
        weight = 1.0 if deviation < 0.1 else min(100.0, 10.0 + deviation * 90.0)
        output = RoleOutput(
            role_type=RoleType.VALIDATOR,
            source_module=self.name,
            prediction=prediction,
            actual=actual,
            deviation=deviation,
            confidence=max(0.0, 1.0 - deviation),
            metadata={"weight": weight, "is_correct": deviation < 0.1},
        )
        self._outputs.append(output)
        return output

    def _compute_deviation(self, prediction: Dict[str, Any], actual: Dict[str, Any]) -> float:
        """计算预测与实际的偏差度（0-1）"""
        if not prediction and not actual:
            return 0.0
        all_keys = set(prediction.keys()) | set(actual.keys())
        if not all_keys:
            return 0.0
        differences = 0
        for key in all_keys:
            p_val = prediction.get(key)
            a_val = actual.get(key)
            if p_val != a_val:
                differences += 1
        return differences / len(all_keys)

class ExecutorRole(RoleBase):
    """执行器角色：接收大脑决策指令，调度对应模块执行"""
    def __init__(self, name: str = "executor"):
        super().__init__(RoleType.EXECUTOR, name)
        self._registered_modules: Dict[str, Any] = {}

    def register_module(self, module_name: str, module: Any) -> None:
        """注册可执行模块"""
        self._registered_modules[module_name] = module

    def execute(self, decision: Dict[str, Any]) -> RoleOutput:
        """执行大脑决策指令"""
        self._call_count += 1
        module_name = decision.get("module", "")
        action = decision.get("action", "")
        params = decision.get("params", {})
        result = {"module": module_name, "action": action, "executed": False}
        if module_name in self._registered_modules:
            try:
                module = self._registered_modules[module_name]
                if hasattr(module, action):
                    method = getattr(module, action)
                    execution_result = method(**params) if params else method()
                    result["executed"] = True
                    result["result"] = execution_result
                else:
                    result["error"] = f"模块 {module_name} 没有方法 {action}"
                    self._error_count += 1
            except Exception as e:
                result["error"] = str(e)
                self._error_count += 1
        else:
            result["error"] = f"模块 {module_name} 未注册"
            self._error_count += 1
        output = RoleOutput(
            role_type=RoleType.EXECUTOR,
            source_module=self.name,
            data=result,
        )
        self._outputs.append(output)
        return output

class EvolverRole(RoleBase):
    """进化器角色：分析验证结果，提取可学习模式，生成改进建议"""
    def __init__(self, name: str = "evolver"):
        super().__init__(RoleType.EVOLVER, name)
        self._improvement_suggestions: List[Dict[str, Any]] = []
        self._learned_patterns: List[Dict[str, Any]] = []

    def analyze(self, validation_output: RoleOutput) -> RoleOutput:
        """分析验证结果，提取可学习模式"""
        self._call_count += 1
        suggestions = []
        patterns = []
        if validation_output.deviation > 0.3:
            patterns.append({
                "type": "high_deviation",
                "deviation": validation_output.deviation,
                "description": "预测偏差较大，需要学习修正",
            })
            suggestions.append({
                "target": "prediction_model",
                "action": "update_weights",
                "priority": "high",
                "reason": f"偏差 {validation_output.deviation:.2f} 超过阈值",
            })
        elif validation_output.deviation < 0.05:
            patterns.append({
                "type": "accurate_prediction",
                "deviation": validation_output.deviation,
                "description": "预测准确，可强化当前策略",
            })
            suggestions.append({
                "target": "prediction_model",
                "action": "reinforce",
                "priority": "low",
                "reason": "预测准确，强化当前策略",
            })
        self._learned_patterns.extend(patterns)
        self._improvement_suggestions.extend(suggestions)
        output = RoleOutput(
            role_type=RoleType.EVOLVER,
            source_module=self.name,
            data={"patterns": patterns, "suggestions": suggestions},
            confidence=validation_output.confidence,
        )
        self._outputs.append(output)
        return output

    def get_suggestions(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取改进建议"""
        return self._improvement_suggestions[-limit:]

class MemoryRole(RoleBase):
    """记忆体角色：模块执行结果+关键上下文，按L1/L2/L3三级存储"""
    def __init__(self, name: str = "memory"):
        super().__init__(RoleType.MEMORY, name)
        self._l1: List[RoleOutput] = []  # 工作记忆（最近）
        self._l2: List[RoleOutput] = []  # 短期记忆
        self._l3: List[RoleOutput] = []  # 长期记忆
        self._l1_capacity = 100
        self._l2_capacity = 1000
        self._l3_capacity = 10000

    def store(self, output: RoleOutput, level: str = "l1") -> None:
        """存储执行结果到指定记忆层级"""
        self._call_count += 1
        if level == "l1":
            self._l1.append(output)
            if len(self._l1) > self._l1_capacity:
                old = self._l1.pop(0)
                self._l2.append(old)
        elif level == "l2":
            self._l2.append(output)
            if len(self._l2) > self._l2_capacity:
                old = self._l2.pop(0)
                self._l3.append(old)
        elif level == "l3":
            self._l3.append(output)
            if len(self._l3) > self._l3_capacity:
                self._l3.pop(0)  # 遗忘最旧的记忆

    def retrieve(self, query: Dict[str, Any], level: str = "all") -> List[RoleOutput]:
        """从记忆中检索相关结果"""
        results = []
        sources = []
        if level in ("l1", "all"):
            sources.extend(self._l1)
        if level in ("l2", "all"):
            sources.extend(self._l2)
        if level in ("l3", "all"):
            sources.extend(self._l3)
        for output in sources:
            if self._match_query(output, query):
                results.append(output)
        return results[-50:]

    def _match_query(self, output: RoleOutput, query: Dict[str, Any]) -> bool:
        """简单匹配查询"""
        for key, value in query.items():
            if key == "role_type" and output.role_type != value:
                return False
            if key == "source_module" and output.source_module != value:
                return False
        return True

    def get_memory_stats(self) -> Dict[str, Any]:
        """获取记忆统计"""
        return {
            "l1_count": len(self._l1),
            "l2_count": len(self._l2),
            "l3_count": len(self._l3),
            "total": len(self._l1) + len(self._l2) + len(self._l3),
            "l1_capacity": self._l1_capacity,
            "l2_capacity": self._l2_capacity,
            "l3_capacity": self._l3_capacity,
        }
