# -*- coding: utf-8 -*-
"""OMNI-BRAIN V2 范式核心模块：六大核心要素完整实现

本模块聚合了系统范式的核心组件，包括角色、状态机、熔断器、
异步管道、双路径协调及六层架构。
"""

import logging
from typing import Any

logger = logging.getLogger(__name__)

__version__ = "0.5"

# --- 角色模块 ---
from .roles import (
    RoleType,
    RoleOutput,
    RoleBase,
    SourceRole,
    ValidatorRole,
    ExecutorRole,
    EvolverRole,
    MemoryRole,
)

# --- 状态机模块 ---
from .state_machine import (
    SystemState,
    StateTransition,
    StateStats,
    GlobalStateMachine,
    VALID_TRANSITIONS,
)

# --- 熔断器模块 ---
from .circuit_breaker import (
    CircuitState,
    CircuitBreakerConfig,
    CircuitBreakerStats,
    CircuitBreaker,
    CircuitBreakerOpenError,
    CircuitBreakerRegistry,
)

# --- 异步管道模块 ---
from .async_pipeline import (
    PipelineStatus,
    PipelineMessage,
    PipelineStats,
    AsyncPipeline,
    DataCollectionPipeline,
    ValidationPipeline,
    LearningPipeline,
    MemoryPipeline,
)

# --- 双路径模块 ---
from .dual_path import (
    PathType,
    PathRequest,
    PathResponse,
    PathStats,
    OnlinePath,
    OfflinePath,
    DualPathCoordinator,
)

# --- 六层架构模块 ---
from .six_layer import (
    LayerType,
    LayerInterface,
    LayerStats,
    LayerBase,
    DecisionCoreLayer,
    WorldModelLayer,
    CausalEngineLayer,
    MemorySystemLayer,
    UnifiedRepresentationLayer,
    DataLayer,
    SixLayerArchitecture,
)

__all__ = [
    # 角色
    "RoleType",
    "RoleOutput",
    "RoleBase",
    "SourceRole",
    "ValidatorRole",
    "ExecutorRole",
    "EvolverRole",
    "MemoryRole",
    # 状态机
    "SystemState",
    "StateTransition",
    "StateStats",
    "GlobalStateMachine",
    "VALID_TRANSITIONS",
    # 熔断器
    "CircuitState",
    "CircuitBreakerConfig",
    "CircuitBreakerStats",
    "CircuitBreaker",
    "CircuitBreakerOpenError",
    "CircuitBreakerRegistry",
    # 异步管道
    "PipelineStatus",
    "PipelineMessage",
    "PipelineStats",
    "AsyncPipeline",
    "DataCollectionPipeline",
    "ValidationPipeline",
    "LearningPipeline",
    "MemoryPipeline",
    # 双路径
    "PathType",
    "PathRequest",
    "PathResponse",
    "PathStats",
    "OnlinePath",
    "OfflinePath",
    "DualPathCoordinator",
    # 六层架构
    "LayerType",
    "LayerInterface",
    "LayerStats",
    "LayerBase",
    "DecisionCoreLayer",
    "WorldModelLayer",
    "CausalEngineLayer",
    "MemorySystemLayer",
    "UnifiedRepresentationLayer",
    "DataLayer",
    "SixLayerArchitecture",
]

logger.debug("OMNI-BRAIN V2 范式核心模块初始化完成，版本: %s", __version__)
