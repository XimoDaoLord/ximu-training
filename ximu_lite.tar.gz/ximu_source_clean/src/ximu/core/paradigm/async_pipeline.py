import asyncio
import logging
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from .roles import RoleOutput

logger = logging.getLogger(__name__)

class PipelineStatus(Enum):
    """管道状态"""
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPED = "stopped"
    ERROR = "error"

@dataclass
class PipelineMessage:
    """管道消息"""
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    payload: Any = None
    source: str = ""
    target: str = ""
    priority: int = 0
    retry_count: int = 0
    max_retries: int = 3
    created_at: float = field(default_factory=time.time)
    processed_at: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class PipelineStats:
    """管道统计信息"""
    status: PipelineStatus = PipelineStatus.IDLE
    total_received: int = 0
    total_processed: int = 0
    total_failed: int = 0
    total_retried: int = 0
    total_rejected: int = 0
    dropped_on_stop: int = 0
    dead_letter_count: int = 0
    queue_size: int = 0
    avg_processing_time_ms: float = 0.0
    last_error: Optional[str] = None

class AsyncPipeline:
    """异步管道基类：异步非阻塞、背压控制、重试机制、死信队列"""

    def __init__(self, name: str, max_queue_size: int = 1000,
                 batch_size: int = 10, process_interval: float = 0.1,
                 max_dead_letters: int = 10000):
        self.name = name
        self.max_queue_size = max_queue_size
        self.batch_size = batch_size
        self.process_interval = process_interval
        self._max_dead_letters = max_dead_letters
        self._queue: deque[PipelineMessage] = deque()
        self._dead_letter_queue: deque[PipelineMessage] = deque(maxlen=max_dead_letters)
        self._stats = PipelineStats()
        self._status = PipelineStatus.IDLE
        self._processors: List[Callable[..., Any]] = []
        self._running: bool = False
        self._processing_times: List[float] = []

    def register_processor(self, processor: Callable[..., Any]) -> None:
        """注册消息处理器"""
        self._processors.append(processor)

    def submit(self, message: PipelineMessage) -> bool:
        """提交消息到管道（背压控制）"""
        if len(self._queue) >= self.max_queue_size:
            self._stats.total_rejected += 1
            self._stats.queue_size = len(self._queue)
            return False
        self._queue.append(message)
        self._stats.total_received += 1
        self._stats.queue_size = len(self._queue)
        return True

    async def process_batch(self) -> int:
        """处理一批消息"""
        if not self._queue:
            return 0
        batch = []
        for _ in range(min(self.batch_size, len(self._queue))):
            batch.append(self._queue.popleft())
        processed = 0
        for message in batch:
            start_time = time.monotonic()
            try:
                for processor in self._processors:
                    if asyncio.iscoroutinefunction(processor):
                        await processor(message)
                    else:
                        processor(message)
                message.processed_at = time.time()
                self._stats.total_processed += 1
                processed += 1
                elapsed = (time.monotonic() - start_time) * 1000
                self._processing_times.append(elapsed)
                if len(self._processing_times) > 1000:
                    self._processing_times.pop(0)
            except Exception as e:
                message.retry_count += 1
                self._stats.total_retried += 1
                if message.retry_count < message.max_retries:
                    self._queue.append(message)
                else:
                    if len(self._dead_letter_queue) >= self._max_dead_letters:
                        logger.warning(
                            "Pipeline[%s] dead-letter queue full(%d), dropping oldest",
                            self.name, self._max_dead_letters)
                    self._dead_letter_queue.append(message)
                    self._stats.dead_letter_count += 1
                    self._stats.total_failed += 1
                    self._stats.last_error = str(e)
        self._stats.queue_size = len(self._queue)
        if self._processing_times:
            self._stats.avg_processing_time_ms = sum(self._processing_times) / len(self._processing_times)
        return processed

    async def run(self) -> None:
        """运行管道主循环"""
        self._running = True
        self._status = PipelineStatus.RUNNING
        self._stats.status = PipelineStatus.RUNNING
        while self._running:
            try:
                if self._status == PipelineStatus.PAUSED:
                    await asyncio.sleep(self.process_interval)
                    continue
                await self.process_batch()
                if self._status == PipelineStatus.ERROR:
                    self._status = PipelineStatus.RUNNING
                    self._stats.status = PipelineStatus.RUNNING
                    self._stats.last_error = None
                await asyncio.sleep(self.process_interval)
            except Exception as e:
                self._status = PipelineStatus.ERROR
                self._stats.status = PipelineStatus.ERROR
                self._stats.last_error = str(e)
                await asyncio.sleep(self.process_interval)
        remaining = len(self._queue)
        if remaining > 0:
            try:
                while self._queue:
                    await self.process_batch()
            except Exception as e:
                self._stats.dropped_on_stop += len(self._queue)
                logger.warning("Pipeline[%s] drain on stop failed: %s",
                               self.name, e)
                self._queue.clear()
        self._status = PipelineStatus.STOPPED
        self._stats.status = PipelineStatus.STOPPED

    def stop(self) -> None:
        """停止管道"""
        self._running = False

    def pause(self) -> None:
        """暂停管道"""
        self._status = PipelineStatus.PAUSED
        self._stats.status = PipelineStatus.PAUSED

    def get_stats(self) -> PipelineStats:
        """获取管道统计信息"""
        return self._stats

    def get_dead_letters(self, limit: int = 50) -> List[PipelineMessage]:
        """获取死信队列消息（deque不支持切片，转list后取尾部）"""
        return list(self._dead_letter_queue)[-limit:]

class DataCollectionPipeline(AsyncPipeline):
    """数据采集管道：模块执行结果→标准化→数据总线→中转系统"""

    def __init__(self, max_queue_size: int = 1000):
        super().__init__("data_collection", max_queue_size)
        self._data_bus: List[RoleOutput] = []

    def collect(self, output: RoleOutput) -> bool:
        """采集模块执行结果"""
        message = PipelineMessage(
            payload=output,
            source=output.source_module,
            target="data_bus",
            metadata={"role_type": output.role_type.value},
        )
        return self.submit(message)

    def get_data_bus(self, limit: int = 100) -> List[RoleOutput]:
        """获取数据总线内容"""
        return self._data_bus[-limit:]

class ValidationPipeline(AsyncPipeline):
    """验证管道：预测值vs实际值→偏差计算→标记→写入验证结果"""

    def __init__(self, max_queue_size: int = 1000):
        super().__init__("validation", max_queue_size)
        self._validation_results: List[Dict[str, Any]] = []

    def validate(self, prediction: Dict[str, Any],
                 actual: Dict[str, Any], source: str = "") -> bool:
        """提交验证任务"""
        message = PipelineMessage(
            payload={"prediction": prediction, "actual": actual},
            source=source,
            target="validation_results",
        )
        return self.submit(message)

    def get_validation_results(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取验证结果"""
        return self._validation_results[-limit:]

class LearningPipeline(AsyncPipeline):
    """学习管道：验证结果→错误分类→根因分析→模式提取→改进建议→写回大脑"""

    def __init__(self, max_queue_size: int = 1000):
        super().__init__("learning", max_queue_size)
        self._improvements: List[Dict[str, Any]] = []
        self._patterns: List[Dict[str, Any]] = []

    def submit_learning_task(self, validation_result: Dict[str, Any]) -> bool:
        """提交学习任务"""
        message = PipelineMessage(
            payload=validation_result,
            source="validation",
            target="brain",
        )
        return self.submit(message)

    def get_improvements(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取改进建议"""
        return self._improvements[-limit:]

class MemoryPipeline(AsyncPipeline):
    """记忆管道：执行结果+上下文→分类→L1/L2/L3存储→代谢降权→遗忘/强化"""

    def __init__(self, max_queue_size: int = 1000):
        super().__init__("memory", max_queue_size)
        self._l1: List[RoleOutput] = []
        self._l2: List[RoleOutput] = []
        self._l3: List[RoleOutput] = []

    def store(self, output: RoleOutput, level: str = "l1") -> bool:
        """存储到记忆管道"""
        message = PipelineMessage(
            payload=output,
            source=output.source_module,
            target=f"memory_{level}",
            metadata={"level": level},
        )
        return self.submit(message)

    def get_memory_stats(self) -> Dict[str, int]:
        """获取记忆统计"""
        return {"l1": len(self._l1), "l2": len(self._l2), "l3": len(self._l3)}
