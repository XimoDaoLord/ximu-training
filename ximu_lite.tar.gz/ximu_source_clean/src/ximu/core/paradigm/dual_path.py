# 状态: [OK] 已实现
# 蓝图: OMNI-BRAIN V2范式 在线/离线双路径
"""在线/离线双路径：OnlinePath实时响应低延迟+在线学习，OfflinePath批量高吞吐+离线训练，双路径协同。"""
import asyncio
import time
import uuid
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Union

from .roles import RoleOutput, RoleType
from .async_pipeline import (
    DataCollectionPipeline, ValidationPipeline, LearningPipeline, MemoryPipeline,
)

# 日志配置
logger = logging.getLogger(__name__)

__version__ = "0.5"


class PathType(Enum):
    """路径类型枚举"""
    ONLINE = "online"
    OFFLINE = "offline"


@dataclass
class PathRequest:
    """路径请求数据结构，封装用户输入、上下文及优先级等信息。"""
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    path_type: PathType = PathType.ONLINE
    user_input: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    priority: int = 0
    created_at: float = field(default_factory=time.time)
    deadline: Optional[float] = None  # 在线路径的响应截止时间


@dataclass
class PathResponse:
    """路径响应数据结构，包含决策、结果、预测、延迟及状态等信息。"""
    response_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    request_id: str = ""
    path_type: PathType = PathType.ONLINE
    decision: Dict[str, Any] = field(default_factory=dict)
    result: Any = None
    prediction: Optional[Dict[str, Any]] = None
    actual: Optional[Dict[str, Any]] = None
    confidence: float = 1.0
    latency_ms: float = 0.0
    status: str = "success"  # success/failure/timeout
    timestamp: float = field(default_factory=time.time)


@dataclass
class PathStats:
    """路径统计信息，记录请求量、成功率、延迟分布及吞吐量等。"""
    path_type: PathType = PathType.ONLINE
    total_requests: int = 0
    total_responses: int = 0
    success_count: int = 0
    failure_count: int = 0
    timeout_count: int = 0
    avg_latency_ms: float = 0.0
    p95_latency_ms: float = 0.0
    throughput: float = 0.0  # 请求/秒
    online_learning_count: int = 0
    offline_training_count: int = 0


class OnlinePath:
    """在线路径：用户输入→大脑决策→工具执行→结果返回→用户确认，实时响应低延迟，在线学习+在线预测。"""

    def __init__(
        self,
        timeout_ms: float = 5000.0,
        max_concurrent: int = 100,
    ):
        """
        初始化在线路径。

        Args:
            timeout_ms: 在线响应超时时间（毫秒）。
            max_concurrent: 最大并发请求数。
        """
        self.timeout_ms = timeout_ms
        self.max_concurrent = max_concurrent
        self._stats = PathStats(path_type=PathType.ONLINE)
        self._latencies: List[float] = []
        self._decision_engine: Optional[Callable[..., Any]] = None
        self._execution_engine: Optional[Callable[..., Any]] = None
        self._data_pipeline = DataCollectionPipeline()
        self._validation_pipeline = ValidationPipeline()
        self._memory_pipeline = MemoryPipeline()
        self._pending_requests: Dict[str, PathRequest] = {}
        self._start_time = time.monotonic()
        self._prediction_history: List[Dict[str, Any]] = []
        self._feedback_history: List[Dict[str, Any]] = []
        self._prediction_accuracy: float = 0.0

    def set_decision_engine(self, engine: Callable[..., Any]) -> None:
        """设置决策引擎，支持同步或异步可调用对象。"""
        self._decision_engine = engine

    def set_execution_engine(self, engine: Callable[..., Any]) -> None:
        """设置执行引擎，支持同步或异步可调用对象。"""
        self._execution_engine = engine

    async def _run_decision(self, request: PathRequest) -> Optional[Dict[str, Any]]:
        """
        调用决策引擎（支持同步/异步），返回标准化 decision dict。

        Args:
            request: 路径请求对象。

        Returns:
            决策结果字典，若未设置引擎则返回 None。
        """
        if not self._decision_engine:
            return None
        try:
            if asyncio.iscoroutinefunction(self._decision_engine):
                decision: Any = await self._decision_engine(request.user_input, request.context)
            else:
                decision = self._decision_engine(request.user_input, request.context)
            return decision if isinstance(decision, dict) else {"result": decision}
        except Exception as e:
            logger.error(f"决策引擎执行异常: {e}", exc_info=True)
            return None

    async def _run_execution(self, decision: Dict[str, Any]) -> Any:
        """
        调用执行引擎（支持同步/异步），返回原始结果。

        Args:
            decision: 决策结果字典。

        Returns:
            执行引擎的原始返回结果。
        """
        if not self._execution_engine:
            return None
        try:
            if asyncio.iscoroutinefunction(self._execution_engine):
                return await self._execution_engine(decision)
            return self._execution_engine(decision)
        except Exception as e:
            logger.error(f"执行引擎执行异常: {e}", exc_info=True)
            return {"error": str(e)}

    async def process(self, request: PathRequest) -> PathResponse:
        """
        处理在线请求：决策→执行→返回→在线学习。

        Args:
            request: 路径请求对象。

        Returns:
            路径响应对象，包含决策、结果、延迟及状态。
        """
        start_time = time.monotonic()
        self._stats.total_requests += 1
        self._pending_requests[request.request_id] = request
        response = PathResponse(
            request_id=request.request_id,
            path_type=PathType.ONLINE,
        )
        try:
            # 1. 大脑决策
            decision = await self._run_decision(request)
            if decision is not None:
                response.decision = decision
                response.prediction = decision

            # 2. 工具执行
            if self._execution_engine and response.decision:
                result = await self._run_execution(response.decision)
                response.result = result
                response.actual = result if isinstance(result, dict) else {"result": result}

            # 3. 计算延迟
            latency = (time.monotonic() - start_time) * 1000
            response.latency_ms = latency
            self._latencies.append(latency)
            if len(self._latencies) > 10000:
                self._latencies.pop(0)

            # 4. 超时检查
            if latency > self.timeout_ms:
                response.status = "timeout"
                self._stats.timeout_count += 1
                logger.warning(
                    f"在线请求 {request.request_id} 超时: {latency:.2f}ms > {self.timeout_ms}ms"
                )
            else:
                response.status = "success"
                self._stats.success_count += 1

            # 5. 在线学习：数据采集→验证→记忆
            output = RoleOutput(
                role_type=RoleType.SOURCE,
                source_module="online_path",
                data={"request": request.user_input, "response": response.result},
                prediction=response.prediction,
                actual=response.actual,
            )
            self._data_pipeline.collect(output)
            self._memory_pipeline.store(output, level="l1")
            self._stats.online_learning_count += 1

        except Exception as e:
            response.status = "failure"
            response.result = str(e)
            self._stats.failure_count += 1
            logger.error(f"在线请求处理失败 (request_id={request.request_id}): {e}", exc_info=True)
        finally:
            self._pending_requests.pop(request.request_id, None)
            self._stats.total_responses += 1

        return response

    def predict(self, request: PathRequest) -> Dict[str, Any]:
        """
        在线预测：基于历史数据实时预测执行结果，不实际执行。

        Args:
            request: 路径请求，包含用户输入和上下文。

        Returns:
            预测结果字典，包含 predicted_result、confidence、based_on_history。
        """
        prediction: Dict[str, Any] = {
            "request_id": request.request_id,
            "predicted_result": None,
            "confidence": 0.5,
            "based_on_history": len(self._prediction_history),
        }
        if self._decision_engine:
            try:
                if asyncio.iscoroutinefunction(self._decision_engine):
                    try:
                        asyncio.get_running_loop()
                        # 已在 async 上下文，同步方法不能阻塞，降级返回基线预测
                        prediction["confidence"] = 0.4
                    except RuntimeError:
                        # 无 running loop，安全创建新循环
                        result = asyncio.run(
                            self._decision_engine(request.user_input, request.context)
                        )
                        prediction["predicted_result"] = (
                            result if isinstance(result, dict) else {"result": result}
                        )
                        prediction["confidence"] = 0.8
                else:
                    result = self._decision_engine(request.user_input, request.context)
                    prediction["predicted_result"] = (
                        result if isinstance(result, dict) else {"result": result}
                    )
                    prediction["confidence"] = 0.8
            except Exception as e:
                logger.warning(f"在线预测降级 (request_id={request.request_id}): {e}")
                prediction["confidence"] = 0.3

        self._prediction_history.append(
            {"request_id": request.request_id, "prediction": prediction, "timestamp": time.time()}
        )
        if len(self._prediction_history) > 1000:
            self._prediction_history.pop(0)
        return prediction

    def learn_from_feedback(self, request_id: str, feedback: Dict[str, Any]) -> bool:
        """
        在线学习：从用户反馈中即时学习，更新预测准确率。

        Args:
            request_id: 关联的请求ID。
            feedback: 用户反馈字典，包含 satisfied(bool)、correction(可选)、rating(可选1-5)。

        Returns:
            是否成功记录反馈并更新学习状态。
        """
        if not request_id or not feedback:
            return False

        record = {
            "request_id": request_id,
            "feedback": feedback,
            "timestamp": time.time(),
            "learned": True,
        }
        self._feedback_history.append(record)
        if len(self._feedback_history) > 1000:
            self._feedback_history.pop(0)

        # 更新预测准确率（基于所有历史反馈的滑动平均）
        if self._feedback_history:
            total = len(self._feedback_history)
            satisfied_count = sum(
                1 for f in self._feedback_history if f["feedback"].get("satisfied", False)
            )
            self._prediction_accuracy = satisfied_count / total

        self._stats.online_learning_count += 1
        logger.debug(f"在线反馈学习成功 (request_id={request_id}, accuracy={self._prediction_accuracy:.3f})")
        return True

    def get_prediction_accuracy(self) -> float:
        """获取在线预测准确率（基于用户反馈）。"""
        return self._prediction_accuracy

    def get_stats(self) -> PathStats:
        """获取在线路径统计信息。"""
        if self._latencies:
            self._stats.avg_latency_ms = sum(self._latencies) / len(self._latencies)
            sorted_latencies = sorted(self._latencies)
            n = len(sorted_latencies)
            p95_idx = min(n - 1, max(0, int(n * 0.95) - 1))
            self._stats.p95_latency_ms = sorted_latencies[p95_idx]

        elapsed = time.monotonic() - self._start_time
        if elapsed > 0:
            self._stats.throughput = self._stats.total_responses / elapsed
        return self._stats


class OfflinePath:
    """
    离线路径：批量数据处理→深度分析→模式提取→知识沉淀→模型更新，
    异步高吞吐，离线学习+离线训练。
    """

    def __init__(
        self,
        batch_size: int = 100,
        max_queue_size: int = 10000,
    ):
        """
        初始化离线路径。

        Args:
            batch_size: 每批次处理的数据条数。
            max_queue_size: 最大数据队列容量。
        """
        self.batch_size = batch_size
        self.max_queue_size = max_queue_size
        self._stats = PathStats(path_type=PathType.OFFLINE)
        self._data_queue: List[Dict[str, Any]] = []
        self._knowledge_base: List[Dict[str, Any]] = []
        self._patterns: List[Dict[str, Any]] = []
        self._learning_pipeline = LearningPipeline()
        self._running = False
        self._start_time = time.monotonic()

    async def ingest_batch(self, data: List[Dict[str, Any]]) -> int:
        """
        将数据批量摄入队列。

        Args:
            data: 待处理的数据列表。

        Returns:
            成功摄入的数据条数。
        """
        if not data:
            return 0

        # 限制队列大小，防止内存溢出
        current_len = len(self._data_queue)
        if current_len + len(data) > self.max_queue_size:
            excess = current_len + len(data) - self.max_queue_size
            self._data_queue = self._data_queue[excess:]
            logger.warning(f"离线路径队列已满，丢弃 {excess} 条数据")

        self._data_queue.extend(data)
        self._stats.total_requests += len(data)
        logger.debug(f"离线路径摄入 {len(data)} 条数据，当前队列长度: {len(self._data_queue)}")
        return len(data)

    async def process_batch(self) -> int:
        """
        处理队列中的批量数据。

        Returns:
            本次处理的数据条数。
        """
        if not self._data_queue:
            return 0

        # 取出一批数据
        batch = self._data_queue[:self.batch_size]
        self._data_queue = self._data_queue[self.batch_size:]
        self._stats.total_responses += len(batch)

        processed_count = 0
        for item in batch:
            try:
                # 通过学习管道处理数据
                self._learning_pipeline.process(item)
                self._stats.offline_training_count += 1
                processed_count += 1
            except Exception as e:
                logger.error(f"离线路径处理数据失败: {e}", exc_info=True)
                self._stats.failure_count += 1

        logger.info(f"离线路径处理完成，批次大小: {len(batch)}, 成功: {processed_count}")
        return processed_count

    def get_patterns(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        获取提取的模式。

        Args:
            limit: 返回的模式数量限制。

        Returns:
            模式列表。
        """
        return self._patterns[-limit:]

    def update_model(self, model_update: Dict[str, Any]) -> bool:
        """
        应用离线学习生成的模型更新。

        Args:
            model_update: 模型更新字典。

        Returns:
            是否成功应用。
        """
        if not model_update:
            return False
        try:
            # 这里可以对接实际的模型更新逻辑
            self._patterns.append(model_update)
            logger.info(f"离线路径应用模型更新: {model_update.get('metadata', {})}")
            return True
        except Exception as e:
            logger.error(f"应用模型更新失败: {e}", exc_info=True)
            return False

    def get_stats(self) -> PathStats:
        """获取离线路径统计信息。"""
        elapsed = time.monotonic() - self._start_time
        if elapsed > 0:
            self._stats.throughput = self._stats.total_responses / elapsed
        return self._stats


class DualPathCoordinator:
    """
    双路径协调器：协调在线路径与离线路径，实现数据同步、知识迁移与模型更新。
    """

    def __init__(self):
        """初始化双路径协调器。"""
        self.online_path = OnlinePath()
        self.offline_path = OfflinePath()
        self._coordination_count: int = 0
        self._shared_memory: List[Dict[str, Any]] = []
        self._applied_knowledge: int = 0
        self._running = False

    async def process_cycle(self) -> Dict[str, Any]:
        """
        执行一次双路径协调周期。

        1. 同步离线数据到在线路径。
        2. 批量处理离线数据。
        3. 应用离线学习结果。
        4. 生成模型更新。

        Returns:
            协调周期结果字典。
        """
        start = time.monotonic()
        result = {
            "synced": 0,
            "processed": 0,
            "knowledge_applied": False,
            "model_updated": False,
            "cycle_time_ms": 0.0,
            "cycle_number": self._coordination_count,
        }

        try:
            # 1. 同步离线数据到在线路径
            synced = await self.offline_path.ingest_batch(self._shared_memory)
            result["synced"] = synced

            # 2. 批量处理离线数据
            processed = await self.offline_path.process_batch()
            result["processed"] = processed

            # 3. 应用离线学习到在线路径
            knowledge_applied = self.apply_offline_learning()
            result["knowledge_applied"] = knowledge_applied

            # 4. 生成模型更新反馈
            model_update = self._generate_model_update()
            if model_update:
                self.offline_path.update_model(model_update)
                result["model_updated"] = True

            cycle_time = (time.monotonic() - start) * 1000
            result["cycle_time_ms"] = round(cycle_time, 2)
            self._coordination_count += 1

            logger.debug(f"双路径协调周期 #{self._coordination_count} 完成: {result}")

        except Exception as e:
            logger.error(f"双路径协调周期执行异常: {e}", exc_info=True)
            result["error"] = str(e)

        return result

    def apply_offline_learning(self) -> bool:
        """
        将离线路径提取的知识应用到在线路径。

        Returns:
            是否成功应用。
        """
        try:
            patterns = self.offline_path.get_patterns(limit=5)
            if not patterns:
                return False

            # 简单应用逻辑：将模式写入共享内存供在线路径参考
            self._shared_memory.extend(patterns)
            self._applied_knowledge += len(patterns)
            logger.info(f"应用离线学习知识，共享内存新增 {len(patterns)} 条记录")
            return True
        except Exception as e:
            logger.error(f"应用离线学习失败: {e}", exc_info=True)
            return False

    def _generate_model_update(self) -> Optional[Dict[str, Any]]:
        """
        从离线模式和知识库生成模型更新建议。

        Returns:
            模型更新建议字典，若无更新则返回 None。
        """
        patterns = self.offline_path.get_patterns(limit=5)
        if not patterns:
            return None

        freq_patterns = [p for p in patterns if p.get("type") == "frequency_pattern"]
        if not freq_patterns:
            return None

        weights: Dict[str, float] = {}
        for p in freq_patterns:
            feature = p.get("feature", "unknown")
            weights[f"pattern_{feature}"] = p.get("frequency", 0.5)

        return {
            "weights": weights,
            "learning_rate": 0.01,
            "metadata": {"source": "dual_path_coordinator", "patterns": len(freq_patterns)},
        }

    def get_stats(self) -> Dict[str, Any]:
        """获取双路径协调统计信息。"""
        stats: Dict[str, Any] = {
            "online": self.online_path.get_stats().__dict__,
            "offline": self.offline_path.get_stats().__dict__,
            "shared_memory_size": len(self._shared_memory),
            "coordination_count": self._coordination_count,
            "applied_knowledge": self._applied_knowledge,
        }
        return stats
