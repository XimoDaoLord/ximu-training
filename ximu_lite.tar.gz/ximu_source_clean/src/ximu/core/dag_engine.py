#!/usr/bin/env python3
"""汐沫AI · DAG引擎 - 阶段4。"""
from __future__ import annotations
import logging
import ast
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

__version__ = "0.5"


@dataclass
class NodeState:
    """节点状态数据类。"""
    task_id: str
    in_degree: int = 0
    out_degree: int = 0
    status: str = "pending"
    condition: Optional[str] = None
    dep_type: str = "finish"
    resource_key: Optional[str] = None
    successors: List[str] = field(default_factory=list)
    predecessors: List[str] = field(default_factory=list)


class DAGEngine:
    """DAG引擎：构建和管理任务依赖图。"""

    _ALLOWED_NODES: Optional[Tuple[type, ...]] = None
    _ALLOWED_CMP_OPS: Optional[Tuple[type, ...]] = None
    _ALLOWED_BIN_OPS: Optional[Tuple[type, ...]] = None
    _ALLOWED_BOOL_OPS: Optional[Tuple[type, ...]] = None
    _ALLOWED_UNARY_OPS: Optional[Tuple[type, ...]] = None
    _SAFE_GLOBALS: Dict[str, Any] = {"__builtins__": {}}
    _COND_CACHE_MAXSIZE: int = 256

    @classmethod
    def _ensure_ast_constants(cls) -> None:
        """延迟初始化AST白名单常量。"""
        if cls._ALLOWED_NODES is None:
            cls._ALLOWED_NODES = (ast.Expression, ast.Name, ast.Constant, ast.Compare, ast.BoolOp, ast.UnaryOp, ast.BinOp, ast.Load)
            cls._ALLOWED_CMP_OPS = (ast.Eq, ast.NotEq, ast.Lt, ast.Gt, ast.LtE, ast.GtE)
            cls._ALLOWED_BIN_OPS = (ast.Add, ast.Sub, ast.Mult, ast.Div)
            cls._ALLOWED_BOOL_OPS = (ast.And, ast.Or)
            cls._ALLOWED_UNARY_OPS = (ast.UAdd, ast.USub, ast.Not, ast.Invert)

    def __init__(self, scheduler: Any = None, config: Optional[Dict[str, Any]] = None) -> None:
        """初始化DAG引擎实例。"""
        self._scheduler = scheduler
        self._config = config or {}
        self._logger = logging.getLogger(__name__)
        self._adjacency_list: Dict[str, List[str]] = defaultdict(list)
        self._reverse_adjacency: Dict[str, List[str]] = defaultdict(list)
        self._nodes: Dict[str, NodeState] = {}
        self._suspended_tasks: Set[str] = set()
        self._condition_listeners: Dict[str, List[str]] = defaultdict(list)
        self._stats: Dict[str, Any] = {"nodes_created": 0, "edges_created": 0, "cycles_detected": 0, "suspended_tasks": 0, "resumed_tasks": 0}
        self._cond_cache: Dict[str, Any] = {}
        self._topo_cache: Optional[List[str]] = None

    def build_dag(self, nodes: List[str], edges: List[Tuple[str, str, Dict[str, Any]]]) -> bool:
        """构建DAG,检测循环依赖。"""
        if nodes is None:
            return False
        if edges is None:
            edges = []
        self._clear_dag()
        self._init_nodes(nodes)
        self._add_edges(edges)
        if self._detect_cycles():
            return False
        return True

    def _clear_dag(self) -> None:
        """清空现有DAG结构。"""
        self._adjacency_list.clear()
        self._reverse_adjacency.clear()
        self._nodes.clear()
        self._topo_cache = None
        self._cond_cache.clear()

    def _init_nodes(self, nodes: List[str]) -> None:
        """初始化 DAG 节点表。"""
        for node_id in nodes:
            self._nodes[node_id] = NodeState(task_id=node_id)
            self._stats["nodes_created"] += 1

    def _add_edges(self, edges: List[Tuple[str, str, Dict[str, Any]]]) -> None:
        """向 DAG 添加边。"""
        for src, dst, metadata in edges:
            if src not in self._nodes or dst not in self._nodes:
                continue
            dep_type = metadata.get("type", "finish")
            condition = metadata.get("condition")
            self._adjacency_list[src].append(dst)
            self._reverse_adjacency[dst].append(src)
            self._nodes[src].out_degree += 1
            self._nodes[dst].in_degree += 1
            self._nodes[src].successors.append(dst)
            self._nodes[dst].predecessors.append(src)
            if condition:
                self._nodes[dst].condition = condition
                self._nodes[dst].dep_type = "cond"
            else:
                self._nodes[dst].dep_type = dep_type
            self._stats["edges_created"] += 1

    def _detect_cycles(self) -> bool:
        """使用Kahn算法检测循环依赖。"""
        in_degree = {node_id: self._nodes[node_id].in_degree for node_id in self._nodes}
        queue = deque([nid for nid, deg in in_degree.items() if deg == 0])
        visited_count = 0
        topo_order: List[str] = []
        while queue:
            node = queue.popleft()
            visited_count += 1
            topo_order.append(node)
            for successor in self._adjacency_list.get(node, []):
                in_degree[successor] -= 1
                if in_degree[successor] == 0:
                    queue.append(successor)
        if visited_count < len(self._nodes):
            self._stats["cycles_detected"] += 1
            return True
        self._topo_cache = topo_order
        return False

    def eval_condition(self, condition: str, context: Dict[str, Any]) -> bool:
        """条件表达式安全求值。"""
        self._ensure_ast_constants()
        tree = ast.parse(condition, mode='eval')
        for node in ast.walk(tree):
            if not isinstance(node, self._ALLOWED_NODES):
                raise ValueError(f"Disallowed node type: {type(node).__name__}")
        code = compile(tree, '<condition>', 'eval')
        return bool(eval(code, self._SAFE_GLOBALS, context))
