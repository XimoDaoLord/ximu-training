# -*- coding: utf-8 -*-
"""
分层记忆系统（口径对齐版） v0.5

四层记忆真实落点：
    L0 会话：chat.db messages 表（按话题/分支，永久）
    L1 短期：memory_tier 进程内存 + memory_tier.db（TTL 1 天，近期常用/会话临时）
    L2 长期：long_term.json（memory_engine，跨话题长期语义/情景记忆）
    L3 画像：user_profile.json（src.ximu.core.memory.user_profile，全局公共画像）

本模块（memory_tier）只承载 L1 短期：
- L1 内存（当前会话）：临时上下文、中间过程结果，进程结束即丢。
- L1/L2 SQLite（memory_tier.db，重启在）：成功执行路径、工具结果、短期偏好。
- 磁盘永久记忆（permanent=True 或 level=3）：写 memory_permanent/，用于用户明确
  “记住”、反复纠正、成功经验、失败教训——【注意：这是“永久磁盘记忆”，不是 L3 用户画像】。
  L3 用户画像由 user_profile.py 独立维护，绝不与本磁盘目录混用。

自动升降级：
- L1 高频访问 → 升级到 L2；L2 长期高频/被用户标记重要 → 永久磁盘（permanent）。
- L2 低价值/过期 → 降权归档或删除。
- 污染：错误记忆标记 polluted，不影响后续召回。
"""
from __future__ import annotations

import os
import json
import time
import sqlite3
import threading
import hashlib
import re
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

__version__ = "0.5"

logger = logging.getLogger(__name__)

# P58b: memory_tier 过程事件 ns 黑名单
_PROCESS_NS_BLACKLIST: frozenset = frozenset({
    "prompt_inject", "prompt_injection", "subtask_done", "subtask_done_event",
    "lesson_success", "lesson_failure", "task_start", "task_complete",
    "tool_call", "error", "audit", "audit_chain",
})

# 过程事件 ns 前缀
_PROCESS_NS_PREFIXES: tuple = (
    "prompt_inject", "subtask_done", "lesson_", "task_", "tool_", "audit_",
)

# 工作/开发信号词
_WORK_SIGNALS = re.compile(
    r"(代码|开发|函数|程序|bug|报错|部署|接口|API|爬虫|脚本|项目|任务|"
    r"记住|记住这个|以后记住|偏好|我喜欢|我习惯|经验|教训|踩坑|优化|重构|"
    r"数据库|SQL|前端|后端|组件|模块|测试|上线|服务器|git)"
)


class MemoryTier:
    """分层记忆管理器，封装 L1 短期、L2 SQLite 和 L3 永久磁盘记忆逻辑。"""

    def __init__(self):
        """初始化记忆层：加载配置、初始化连接、建立目录。"""
        self._lock = threading.RLock()
        self._L1: Dict[str, Dict[str, Any]] = {}
        self._L1_MAX = 999999  # P0-23: L1缓存无上限（原256过小）
        self._L2_PERSIST_CONN: Optional[sqlite3.Connection] = None
        self._L2_CONN_LOCK = threading.Lock()
        self._db_path: str = self._get_db_path()
        self._permanent_dir: str = self._get_permanent_dir()
        self._external_dir: str = self._get_external_dir()

        # 确保目录存在
        Path(self._permanent_dir).mkdir(parents=True, exist_ok=True)
        try:
            Path(self._external_dir).mkdir(parents=True, exist_ok=True)
        except (PermissionError, OSError):
            pass  # 外部目录不可用时降级到内存模式

    def _get_db_path(self) -> str:
        """获取 L2 SQLite 数据库路径。"""
        try:
            from src.ximu.core.data_root import memory_tier_db_path as _mtd
            return _mtd()
        except Exception:
            # 向后兼容：旧 data_root 只有 memory_longterm_dir
            try:
                from src.ximu.core.data_root import memory_longterm_dir as _mld
                return os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "ui",
                                    "web_ui", "data", "memory_tier.db")
            except Exception:
                return os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "ui",
                                    "web_ui", "data", "memory_tier.db")

    def _get_permanent_dir(self) -> str:
        """获取 L3 永久磁盘记忆目录路径。"""
        try:
            from src.ximu.core.data_root import memory_permanent_dir as _mpd
            return _mpd()
        except Exception:
            try:
                from src.ximu.core.data_root import memory_longterm_dir as _mld
                return _mld()
            except Exception:
                return os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "ui",
                                    "web_ui", "data", "memory_permanent")

    def _get_external_dir(self) -> str:
        """获取外部备份目录路径。"""
        return os.environ.get("XIMU_EXTERNAL_DIR", "/sdcard/ximu")

    @staticmethod
    def _is_process_ns(ns: str) -> bool:
        """判断 ns 是否为过程事件（审计/日志/计数器），命中则不入记忆。"""
        if not ns:
            return False
        n = str(ns).strip().lower()
        if n in _PROCESS_NS_BLACKLIST:
            return True
        for prefix in _PROCESS_NS_PREFIXES:
            if n.startswith(prefix):
                return True
        return False

    @staticmethod
    def _h(s: str) -> str:
        """生成 MD5 哈希值。"""
        return hashlib.md5(s.encode("utf-8")).hexdigest()

    @staticmethod
    def classify(content: str) -> str:
        """自动判断记忆桶：开发/代码/任务/记住 → work；普通闲聊 → daily。"""
        if not content:
            return "daily"
        if _WORK_SIGNALS.search(content):
            return "work"
        return "daily"

    def _get_conn(self) -> sqlite3.Connection:
        """返回持久化 sqlite 连接（WAL + autocommit）。首调建表。"""
        if self._L2_PERSIST_CONN is None:
            with self._L2_CONN_LOCK:
                if self._L2_PERSIST_CONN is None:
                    c = sqlite3.connect(self._db_path, timeout=5, check_same_thread=False,
                                        isolation_level=None)  # autocommit
                    try:
                        c.execute("PRAGMA journal_mode=WAL")
                        c.execute("PRAGMA synchronous=NORMAL")
                    except Exception as e:
                        logger.warning(f"Failed to set SQLite pragmas: {e}")
                    c.execute("""CREATE TABLE IF NOT EXISTS mem (
                        ns TEXT, key TEXT, value TEXT, ts REAL, ttl REAL,
                        level INTEGER, hits INTEGER, polluted INTEGER,
                        PRIMARY KEY (ns, key))""")
                    self._L2_PERSIST_CONN = c
        return self._L2_PERSIST_CONN

    def _write_permanent(self, ns: str, key: str, value: Any, level: int = 3) -> None:
        """写入 L3 永久磁盘记忆（辅助函数）。"""
        fp = os.path.join(self._permanent_dir, self._h(ns + "|" + key) + ".json")
        try:
            data = {"ns": ns, "key": key, "value": value,
                    "ts": time.time(), "level": level, "permanent": True}
            with open(fp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            logger.debug(f"Written permanent memory to {fp}")
        except Exception as e:
            logger.error(f"Failed to write permanent memory {ns}:{key}: {e}")

    def _read_permanent(self, ns: str, key: str) -> Optional[Dict[str, Any]]:
        """读取 L3 永久磁盘记忆（辅助函数）。"""
        fp = os.path.join(self._permanent_dir, self._h(ns + "|" + key) + ".json")
        if not os.path.exists(fp):
            return None
        try:
            with open(fp, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to read permanent memory {ns}:{key}: {e}")
            return None

    def remember(self, ns: str, key: str, value: Any,
                 level: int = 2, ttl: float = 86400.0,
                 permanent: bool = False) -> None:
        """
        写记忆。

        Args:
            ns: 命名空间。
            key: 记忆键。
            value: 记忆值。
            level: 层级 (1=L1, 2=L2, 3=L3)。
            ttl: 生存时间（秒）。
            permanent: 是否永久保存（覆盖 level=3）。

        Note:
            - level=1: L1 短期（进程内存 + memory_tier.db）
            - level=2: L1/L2 常用（memory_tier.db）
            - level=3 / permanent: 永久磁盘记忆（memory_permanent/）
        """
        if self._is_process_ns(ns):
            return

        k = f"{ns}:{self._h(key)}"
        now = time.time()

        with self._lock:
            if permanent or level == 3:
                # 永久磁盘记忆
                self._write_permanent(ns, key, value, level)
                return

            # L1 + L2 逻辑
            self._L1[k] = {"v": value, "ts": now, "ttl": ttl, "level": level, "hits": 1, "polluted": False}

            # LRU Eviction (简单实现：如果超过限制，移除最旧的 64 个)
            if len(self._L1) > self._L1_MAX:
                # 这里为了性能，只做简单的移除，不保证严格 LRU
                for old in list(self._L1)[:64]:
                    self._L1.pop(old, None)

            try:
                c = self._get_conn()
                c.execute("INSERT OR REPLACE INTO mem (ns,key,value,ts,ttl,level,hits,polluted) VALUES (?,?,?,?,?,?,?,?)",
                          (ns, k, json.dumps(value, ensure_ascii=False), now, ttl, level, 1, 0))
            except Exception as e:
                logger.error(f"Failed to write to memory_tier.db: {e}")

    def recall(self, ns: str, key: str) -> Optional[Any]:
        """
        三级召回：L1 → L2 → L3。命中自动升级（L1→L2→L3）。

        Args:
            ns: 命名空间。
            key: 记忆键。

        Returns:
            记忆值，如果未找到或已污染则返回 None。
        """
        k = f"{ns}:{self._h(key)}"
        with self._lock:
            # L1
            it = self._L1.get(k)
            if it and time.time() - it["ts"] < it["ttl"] and not it.get("polluted"):
                it["hits"] = it.get("hits", 1) + 1
                return it["v"]

            # L2
            try:
                c = self._get_conn()
                row = c.execute("SELECT value, ts, ttl, level, hits, polluted FROM mem WHERE ns=? AND key=?",
                                (ns, k)).fetchone()
                if row:
                    v, ts, ttl, level, hits, polluted = row
                    if polluted:
                        return None
                    if time.time() - ts < ttl:
                        val = json.loads(v)
                        self._L1[k] = {"v": val, "ts": ts, "ttl": ttl, "level": level,
                                      "hits": hits + 1, "polluted": False}
                        return val
            except Exception as e:
                logger.error(f"Failed to recall from memory_tier.db: {e}")

            # L3 磁盘
            data = self._read_permanent(ns, key)
            if data and not data.get("polluted"):
                return data["value"]

        return None

    def mark_polluted(self, ns: str, key: str) -> None:
        """
        标记错误记忆为污染，后续不召回。

        Args:
            ns: 命名空间。
            key: 记忆键。
        """
        k = f"{ns}:{self._h(key)}"
        with self._lock:
            if k in self._L1:
                self._L1[k]["polluted"] = True
            try:
                c = self._get_conn()
                c.execute("UPDATE mem SET polluted=1 WHERE ns=? AND key=?", (ns, k))
            except Exception as e:
                logger.error(f"Failed to mark polluted in memory_tier.db: {e}")

            data = self._read_permanent(ns, key)
            if data:
                data["polluted"] = True
                self._write_permanent(ns, key, data["value"], data.get("level", 3))

    def forget(self, ns: str, key: str) -> None:
        """
        用户手动删除记忆（真删：L1/L2/L3 全清）。

        Args:
            ns: 命名空间。
            key: 记忆键。
        """
        k = f"{ns}:{self._h(key)}"
        with self._lock:
            self._L1.pop(k, None)
            try:
                c = self._get_conn()
                c.execute("DELETE FROM mem WHERE ns=? AND key=?", (ns, k))
            except Exception as e:
                logger.error(f"Failed to delete from memory_tier.db: {e}")

            fp = os.path.join(self._permanent_dir, self._h(ns + "|" + key) + ".json")
            if os.path.exists(fp):
                try:
                    os.remove(fp)
                except Exception as e:
                    logger.error(f"Failed to delete permanent memory file {fp}: {e}")

    def cleanup_expired(self, max_age_days: float = 30.0) -> None:
        """
        定期清理过期记忆（L2 过期 + L3 旧文件）。

        Args:
            max_age_days: 最大保留天数。
        """
        cutoff = time.time() - max_age_days * 86400
        try:
            c = self._get_conn()
            c.execute("DELETE FROM mem WHERE ts < ?", (cutoff,))
            logger.info(f"Cleaned up {c.rowcount} expired entries from memory_tier.db")
        except Exception as e:
            logger.error(f"Failed to cleanup memory_tier.db: {e}")

        try:
            for f in os.listdir(self._permanent_dir):
                fp = os.path.join(self._permanent_dir, f)
                try:
                    if os.path.getmtime(fp) < cutoff:
                        os.remove(fp)
                except Exception as e:
                    logger.error(f"Failed to cleanup permanent file {fp}: {e}")
        except Exception as e:
            logger.error(f"Failed to list permanent directory: {e}")


# ===== 公共 API 兼容层 =====
_tier = MemoryTier()

remember = _tier.remember
recall = _tier.recall
mark_polluted = _tier.mark_polluted
forget = _tier.forget
cleanup_expired = _tier.cleanup_expired
classify = MemoryTier.classify
