# -*- coding: utf-8 -*-
"""
连接器基类与连接结果数据结构。
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import logging

logger = logging.getLogger(__name__)

@dataclass
class ConnectionResult:
    """
    连接测试结果。
    
    Attributes:
    ok (bool): 是否连接成功。
    message (str): 连接结果消息。
    latency_ms (float): 连接耗时（毫秒）。
    metadata (Dict[str, Any]): 附加元数据。
    """
    ok: bool
    message: str = ""
    latency_ms: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """
        将连接结果转换为字典。
        
        Returns:
        Dict[str, Any]: 连接结果字典。
        """
        return {"ok": self.ok, "message": self.message, "latency_ms": self.latency_ms, "metadata": self.metadata}

class ConnectorBase:
    """
    外部系统连接器基类。
    
    子类需提供：connector_type、display_name、config_schema，并实现test_connection。
    
    Attributes:
    connector_type (str): 连接器类型。
    display_name (str): 连接器显示名称。
    category (str): 连接器分类。
    config_schema (List[Dict[str, Any]]): 配置schema。
    name (str): 连接器名称。
    config (Dict[str, Any]): 连接器配置。
    connected (bool): 是否已连接。
    """
    connector_type: str = "base"
    display_name: str = "Base Connector"
    category: str = "crm"
    # 对应仓库二级分类
    config_schema: List[Dict[str, Any]] = []

    def __init__(self, name: str, config: Optional[Dict[str, Any]] = None) -> None:
        """
        初始化连接器。
        
        Args:
        name (str): 连接器名称。
        config (Optional[Dict[str, Any]], optional): 连接器配置。 Defaults to None.
        """
        self.name = name
        self.config: Dict[str, Any] = dict(config or {})
        self.connected: bool = False

    def validate_config(self, config: Optional[Dict[str, Any]] = None) -> List[str]:
        """
        校验连接器配置。
        
        Returns:
        List[str]: 缺失的必填字段名列表（空列表表示通过）。
        """
        cfg = config if config is not None else self.config
        missing = []
        for field_def in self.config_schema:
            if field_def.get("required"):
                val = cfg.get(field_def["name"], field_def.get("default"))
                if val in (None, ""):
                    missing.append(field_def["name"])
        return missing

    def test_connection(self) -> ConnectionResult:
        """
        测试连接。
        
        Returns:
        ConnectionResult: 连接测试结果。
        """
        missing = self.validate_config()
        if missing:
            logger.info(f"缺失必填配置：{missing}")
            return ConnectionResult(False, f"missing required config: {missing}")
        self.connected = True
        logger.info("连接成功")
        return ConnectionResult(True, "config valid (offline check)")

    def to_dict(self) -> Dict[str, Any]:
        """
        将连接器转换为字典。
        
        Returns:
        Dict[str, Any]: 连接器字典。
        """
        return {
            "id": self.name,
            "name": self.display_name,
            "type": self.connector_type,
            "category": self.category,
            "config_schema": self.config_schema,
            "connected": self.connected,
            "configured": not bool(self.validate_config()),
        }
