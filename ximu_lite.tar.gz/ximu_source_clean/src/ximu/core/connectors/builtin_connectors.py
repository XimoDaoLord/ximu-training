# -*- coding: utf-8 -*-
"""首批内置连接器定义：CRM / ERP / 工单 / 客服 / 知识库 / 文档系统 /
飞书 / 钉钉 / 企业微信 / GitHub / Google Workspace。

每个连接器提供配置 schema 与离线连接测试接口。
"""
from __future__ import annotations

from typing import Any, Dict, List, Type

from .connector_base import ConnectorBase

# 定义 Schema 字段类型
SchemaField = Dict[str, Any]

def _schema(host: str, token: bool = True) -> List[SchemaField]:
    """生成标准基础配置 Schema。

    Args:
        host (str): 主机标识，用于描述字段。
        token (bool): 是否包含 API Token 字段。

    Returns:
        List[Dict[str, Any]]: 包含配置项定义的列表。
    """
    fields: List[SchemaField] = [
        {
            "name": "base_url",
            "type": "string",
            "required": True,
            "default": "",
            "description": f"{host} 服务地址",
        },
    ]
    if token:
        fields.append(
            {
                "name": "api_token",
                "type": "string",
                "required": True,
                "default": "",
                "description": "访问令牌",
            }
        )
    return fields

# ---- 业务系统类 ----

class CRMConnector(ConnectorBase):
    """CRM 客户管理系统连接器。"""
    connector_type: str = "crm"
    display_name: str = "CRM 客户管理"
    category: str = "业务系统"
    config_schema: List[SchemaField] = _schema("CRM")

class ERPConnector(ConnectorBase):
    """ERP 企业资源计划系统连接器。"""
    connector_type: str = "erp"
    display_name: str = "ERP 企业资源"
    category: str = "业务系统"
    config_schema: List[SchemaField] = _schema("ERP")

class TicketConnector(ConnectorBase):
    """工单系统连接器。"""
    connector_type: str = "ticket"
    display_name: str = "工单系统"
    category: str = "业务系统"
    config_schema: List[SchemaField] = _schema("工单")

class CSConnector(ConnectorBase):
    """客服系统连接器。"""
    connector_type: str = "helpdesk"
    display_name: str = "客服系统"
    category: str = "业务系统"
    config_schema: List[SchemaField] = _schema("客服")

class KBConnector(ConnectorBase):
    """知识库连接器。"""
    connector_type: str = "knowledge_base"
    display_name: str = "知识库"
    category: str = "业务系统"
    config_schema: List[SchemaField] = _schema("知识库")

class DocSystemConnector(ConnectorBase):
    """文档系统连接器。"""
    connector_type: str = "docs"
    display_name: str = "文档系统"
    category: str = "业务系统"
    config_schema: List[SchemaField] = _schema("文档")

# ---- 协作平台类 ----

class FeishuConnector(ConnectorBase):
    """飞书连接器。"""
    connector_type: str = "feishu"
    display_name: str = "飞书"
    category: str = "协作平台"
    config_schema: List[SchemaField] = [
        {
            "name": "app_id",
            "type": "string",
            "required": True,
            "default": "",
            "description": "飞书应用 App ID",
        },
        {
            "name": "app_secret",
            "type": "string",
            "required": True,
            "default": "",
            "description": "飞书应用 App Secret",
        },
        {
            "name": "base_url",
            "type": "string",
            "required": False,
            "default": "https://open.feishu.cn/open-apis",
            "description": "飞书开放平台地址",
        },
    ]

class DingTalkConnector(ConnectorBase):
    """钉钉连接器。"""
    connector_type: str = "dingtalk"
    display_name: str = "钉钉"
    category: str = "协作平台"
    config_schema: List[SchemaField] = [
        {
            "name": "app_key",
            "type": "string",
            "required": True,
            "default": "",
            "description": "钉钉应用 AppKey",
        },
        {
            "name": "app_secret",
            "type": "string",
            "required": True,
            "default": "",
            "description": "钉钉应用 AppSecret",
        },
        {
            "name": "base_url",
            "type": "string",
            "required": False,
            "default": "https://oapi.dingtalk.com",
            "description": "钉钉开放平台地址",
        },
    ]

class WeComConnector(ConnectorBase):
    """企业微信连接器。"""
    connector_type: str = "wecom"
    display_name: str = "企业微信"
    category: str = "协作平台"
    config_schema: List[SchemaField] = [
        {
            "name": "corp_id",
            "type": "string",
            "required": True,
            "default": "",
            "description": "企业微信 CorpID",
        },
        {
            "name": "corp_secret",
            "type": "string",
            "required": True,
            "default": "",
            "description": "企业微信应用 Secret",
        },
        {
            "name": "agent_id",
            "type": "string",
            "required": False,
            "default": "",
            "description": "应用 AgentId",
        },
    ]

class GitHubConnector(ConnectorBase):
    """GitHub 连接器。"""
    connector_type: str = "github"
    display_name: str = "GitHub"
    category: str = "协作平台"
    config_schema: List[SchemaField] = [
        {
            "name": "github_token",
            "type": "string",
            "required": False,
            "default": "",
            "description": "GitHub Personal Access Token（公开仓库可留空）",
        },
        {
            "name": "base_url",
            "type": "string",
            "required": False,
            "default": "https://api.github.com",
            "description": "GitHub API 地址",
        },
    ]

class GoogleWorkspaceConnector(ConnectorBase):
    """Google Workspace 连接器。"""
    connector_type: str = "google_workspace"
    display_name: str = "Google Workspace"
    category: str = "协作平台"
    config_schema: List[SchemaField] = [
        {
            "name": "client_id",
            "type": "string",
            "required": True,
            "default": "",
            "description": "OAuth Client ID",
        },
        {
            "name": "client_secret",
            "type": "string",
            "required": True,
            "default": "",
            "description": "OAuth Client Secret",
        },
        {
            "name": "refresh_token",
            "type": "string",
            "required": False,
            "default": "",
            "description": "OAuth Refresh Token",
        },
    ]

# 内置连接器类列表
BUILTIN_CONNECTORS: List[Type[ConnectorBase]] = [
    CRMConnector,
    ERPConnector,
    TicketConnector,
    CSConnector,
    KBConnector,
    DocSystemConnector,
    FeishuConnector,
    DingTalkConnector,
    WeComConnector,
    GitHubConnector,
    GoogleWorkspaceConnector,
]

def register_builtin(registry: Any) -> None:
    """把首批内置连接器注册进给定 registry。

    Args:
        registry: 连接器注册表实例，需具备 register_type 方法。
        
    Raises:
        AttributeError: 如果 registry 不包含 register_type 方法。
    """
    if not hasattr(registry, "register_type"):
        raise AttributeError("registry 必须实现 register_type 方法")
        
    for cls in BUILTIN_CONNECTORS:
        try:
            registry.register_type(cls)
        except Exception as e:
            print(f"Failed to register connector {cls.__name__}: {e}")
            raise
