from __future__ import annotations

import logging
from typing import Dict, List, Optional

from .connector_base import ConnectorBase, ConnectionResult
from .connector_registry import ConnectorRegistry, get_connector_registry
from .builtin_connectors import BUILTIN_CONNECTORS, register_builtin

__all__ = [
    "ConnectorBase",
    "ConnectionResult",
    "ConnectorRegistry",
    "get_connector_registry",
    "BUILTIN_CONNECTORS",
    "register_builtin",
]

class ConnectorManager:
    """连接器管理器，负责管理连接器的注册和获取。"""
    def __init__(self, registry: ConnectorRegistry):
        """初始化连接器管理器。"""
        self.registry = registry

    def get_connector(self, connector_name: str) -> Optional[ConnectorBase]:
        """根据名称获取连接器实例。"""
        try:
            connector = self.registry.get_connector(connector_name)
            logger.info(f"获取连接器 {connector_name} 成功")
            return connector
        except Exception as e:
            logger.error(f"获取连接器 {connector_name} 失败：{str(e)}")
            return None

    def register_connector(self, connector: ConnectorBase) -> None:
        """注册连接器。"""
        try:
            self.registry.register_connector(connector)
            logger.info(f"注册连接器 {connector.name} 成功")
        except Exception as e:
            logger.error(f"注册连接器 {connector.name} 失败：{str(e)}")

def get_connector_registry() -> ConnectorRegistry:
    """获取连接器注册表。"""
    return ConnectorRegistry()

class ConnectorRegistry:
    """连接器注册表，负责管理连接器的注册和获取。"""
    def __init__(self):
        """初始化连接器注册表。"""
        self._connectors: Dict[str, ConnectorBase] = {}

    def register_connector(self, connector: ConnectorBase) -> None:
        """注册连接器。"""
        self._connectors[connector.name] = connector

    def get_connector(self, connector_name: str) -> Optional[ConnectorBase]:
        """根据名称获取连接器实例。"""
        return self._connectors.get(connector_name)

class BuiltinConnectorManager:
    """内置连接器管理器，负责管理内置连接器的注册和获取。"""
    def __init__(self, registry: ConnectorRegistry):
        """初始化内置连接器管理器。"""
        self.registry = registry

    def register_builtin_connector(self, connector: ConnectorBase) -> None:
        """注册内置连接器。"""
        self.registry.register_connector(connector)

    def get_builtin_connector(self, connector_name: str) -> Optional[ConnectorBase]:
        """根据名称获取内置连接器实例。"""
        return self.registry.get_connector(connector_name)

def register_builtin(connector: ConnectorBase) -> None:
    """注册内置连接器。"""
    registry = get_connector_registry()
    manager = BuiltinConnectorManager(registry)
    manager.register_builtin_connector(connector)

def get_connector_registry() -> ConnectorRegistry:
    """获取连接器注册表。"""
    return ConnectorRegistry()

logger = logging.getLogger(__name__)