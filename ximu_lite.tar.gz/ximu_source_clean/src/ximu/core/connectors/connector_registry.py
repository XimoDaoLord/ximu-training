import json
import os
import threading
from typing import Any, Dict, List, Optional, Type

from .connector_base import ConnectorBase, ConnectionResult

class ConnectorRegistry:
    """
    连接器类型注册中心 + 实例管理 + JSON 配置自动加载。

    Attributes:
        _types (Dict[str, Type[ConnectorBase]]): 类型注册表。
        _instances (Dict[str, ConnectorBase]): 实例管理表。
        _catalog (List[Dict[str, Any]]): JSON 配置目录。
        _lock (threading.Lock): 线程锁。
        _catalog_loaded (bool): 是否已加载 JSON 配置。
    """

    def __init__(self) -> None:
        """
        初始化连接器注册中心。
        """
        self._types: Dict[str, Type[ConnectorBase]] = {}
        self._instances: Dict[str, ConnectorBase] = {}
        self._catalog: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._catalog_loaded = False

    def register_type(self, cls: Type[ConnectorBase]) -> None:
        """
        注册连接器类型。

        Args:
            cls (Type[ConnectorBase]): 类型。
        """
        self._types[cls.connector_type] = cls

    def list_types(self) -> List[Dict[str, str]]:
        """
        获取已注册的连接器类型列表。

        Returns:
            List[Dict[str, str]]: 类型列表。
        """
        return [{"type": t, "name": c.display_name, "category": c.category} for t, c in self._types.items()]

    def create(self, connector_type: str, name: str, config: Optional[Dict[str, Any]] = None) -> ConnectorBase:
        """
        创建连接器实例。

        Args:
            connector_type (str): 类型。
            name (str): 名称。
            config (Optional[Dict[str, Any]], optional): 配置。 Defaults to None.

        Returns:
            ConnectorBase: 实例。
        """
        cls = self._types.get(connector_type)
        if cls is None:
            raise KeyError(f"unknown connector type: {connector_type}")
        with self._lock:
            inst = cls(name, config)
            self._instances[name] = inst
            return inst

    def get(self, name: str) -> Optional[ConnectorBase]:
        """
        获取连接器实例。

        Args:
            name (str): 名称。

        Returns:
            Optional[ConnectorBase]: 实例。
        """
        return self._instances.get(name)

    def list_instances(self) -> List[Dict[str, Any]]:
        """
        获取已创建的连接器实例列表。

        Returns:
            List[Dict[str, Any]]: 实例列表。
        """
        return [i.to_dict() for i in self._instances.values()]

    def remove(self, name: str) -> bool:
        """
        移除连接器实例。

        Args:
            name (str): 名称。

        Returns:
            bool: 是否成功。
        """
        with self._lock:
            return self._instances.pop(name, None) is not None

    def test(self, name: str) -> Dict[str, Any]:
        """
        测试连接器连接。

        Args:
            name (str): 名称。

        Returns:
            Dict[str, Any]: 测试结果。
        """
        inst = self._instances.get(name)
        if inst is None:
            return ConnectionResult(False, "connector not found").to_dict()
        return inst.test_connection().to_dict()

    def _default_catalog_dir(self) -> str:
        """
        获取默认连接器 JSON 配置目录。

        Returns:
            str: 目录。
        """
        here = os.path.dirname(os.path.abspath(__file__))
        return os.path.abspath(os.path.join(here, "..", "..", "connectors"))

    def load_from_catalog(self, catalog_path: Optional[str] = None) -> int:
        """
        从 catalog.json 加载连接器目录元数据。

        Args:
            catalog_path (Optional[str], optional): catalog.json 路径。 Defaults to None.

        Returns:
            int: 加载到的连接器数量。
        """
        if catalog_path is None:
            catalog_path = os.path.join(self._default_catalog_dir(), "catalog.json")
        if not os.path.isfile(catalog_path):
            return 0
        try:
            with open(catalog_path, encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return 0
        connectors = data.get("connectors", [])
        loaded = 0
        for conn in connectors:
            cid = conn.get("id") or conn.get("name", "")
            if not cid:
                continue
            detail_file = conn.get("file", f"{cid}.json")
            detail_path = os.path.join(os.path.dirname(catalog_path), detail_file)
            detail: Dict[str, Any] = {}
            if os.path.isfile(detail_path):
                try:
                    with open(detail_path, encoding="utf-8") as f:
                        detail = json.load(f)
                except Exception:
                    detail = {}
            merged = {**conn, **detail}
            merged["_catalog_file"] = catalog_path
            merged["_detail_file"] = detail_path if detail else None
            self._catalog.append(merged)
            loaded += 1
            self._catalog_loaded = True
        return loaded

    def load_from_json_dir(self, json_dir: Optional[str] = None) -> int:
        """
        扫描目录下所有 *.json 连接器配置文件并加载。

        Args:
            json_dir (Optional[str], optional): 目录路径。 Defaults to None.

        Returns:
            int: 新加载的连接器数量。
        """
        if json_dir is None:
            json_dir = self._default_catalog_dir()
        if not os.path.isdir(json_dir):
            return 0
        existing_ids = {c.get("id") for c in self._catalog}
        loaded = 0
        for jpath in sorted(glob.glob(os.path.join(json_dir, "*.json"))):
            fname = os.path.basename(jpath)
            if fname in ("catalog.json",):
                continue
            try:
                with open(jpath, encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                continue
            cid = data.get("id") or fname[:-5]
            if cid in existing_ids:
                continue
            data["_detail_file"] = jpath
            self._catalog.append(data)
            existing_ids.add(cid)
            loaded += 1
        return loaded

    def list(self) -> List[Dict[str, Any]]:
        """
        返回所有已加载的连接器列表（目录 + 实例合并）。

        Returns:
            List[Dict[str, Any]]: 列表。
        """
        if not self._catalog_loaded:
            self.load_from_catalog()
            self.load_from_json_dir()
        result: List[Dict[str, Any]] = []
        seen_ids: set = set()
        # 1) JSON catalog 中的连接器
        for c in self._catalog:
            cid = c.get("id", "")
            seen_ids.add(cid)
            result.append({
                "id": cid,
                "name": c.get("name", cid),
                "type": c.get("category", c.get("type", "unknown")),
                "category": c.get("category", "未分类"),
                "description": c.get("description", ""),
                "tools": c.get("tools", []),
                "authMode": c.get("authMode", "unknown"),
                "endpoint": c.get("endpoint", c.get("gateway", "")),
                "gateway": c.get("gateway", ""),
                "status": c.get("status", "not_configured"),
                "configured": c.get("status") == "connected",
                "lastUpdated": c.get("lastUpdated", ""),
                "source": "catalog",
            })
        # 2) 已创建的实例（覆盖/补充）
        for name, inst in self._instances.items():
            d = inst.to_dict()
            d["source"] = "instance"
            found = False
            for i, r in enumerate(result):
                if r["id"] == name or r["name"] == name:
                    result[i] = {**r, **d, "source": "instance"}
                    found = True
                    break
            if not found:
                result.append(d)
        # 3) 已注册但未实例化的类型
        for t, cls in self._types.items():
            if t not in seen_ids and t not in [r.get("id") for r in result]:
                result.append({
                    "id": t,
                    "name": cls.display_name,
                    "type": t,
                    "category": cls.category,
                    "description": f"内置连接器类型: {cls.display_name}",
                    "tools": [],
                    "authMode": "unknown",
                    "endpoint": "",
                    "status": "type_registered",
                    "configured": False,
                    "source": "builtin_type",
                })
        return result

    def add(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        添加一个连接器配置到目录（内存中，不写盘）。

        Args:
            config (Dict[str, Any]): 配置。

        Returns:
            Dict[str, Any]: 结果。
        """
        cid = config.get("id") or config.get("name", "")
        if not cid:
            return {"success": False, "error": "缺少 id/name"}
        config["id"] = cid
        config.setdefault("status", "not_configured")
        config.setdefault("addedAt", time.strftime("%Y-%m-%d %H:%M:%S"))
        self._catalog.append(config)
        return {"success": True, "id": cid, "connector": config}

    def remove_catalog(self, cid: str) -> bool:
        """
        从目录中移除一个连接器配置。

        Args:
            cid (str): id。

        Returns:
            bool: 是否成功。
        """
        before = len(self._catalog)
        self._catalog = [c for c in self._catalog if c.get("id") != cid]
        return len(self._catalog) < before

    def test_by_id(self, cid: str) -> Dict[str, Any]:
        """
        按 id 测试连接器连接。

        Args:
            cid (str): id。

        Returns:
            Dict[str, Any]: 测试结果。
        """
        # 先找实例
        inst = self._instances.get(cid)
        if inst is not None:
            return inst.test_connection().to_dict()
        # 再找 catalog 条目
        for c in self._catalog:
            if c.get("id") == cid:
                return {
                    "ok": False,
                    "message": f"连接器 {cid} 未实例化，请先配置凭证",
                    "latency_ms": 0.0,
                    "metadata": {"status": c.get("status", "not_configured")},
                }
        return {"ok": False, "message": f"connector not found: {cid}", "latency_ms": 0.0, "metadata": {}}

_REGISTRY: Optional[ConnectorRegistry] = None

def get_connector_registry() -> ConnectorRegistry:
    """
    进程级单例。首次调用时自动注册内置类型 + 加载 JSON 目录。

    Returns:
        ConnectorRegistry: 实例。
    """
    global _REGISTRY
    if _REGISTRY is None:
        _REGISTRY = ConnectorRegistry()
        # 自动注册内置连接器类型
        try:
            from .builtin_connectors import register_builtin
            register_builtin(_REGISTRY)
        except Exception:
            pass
        # 自动加载 JSON 配置目录
        _REGISTRY.load_from_catalog()
        _REGISTRY.load_from_json_dir()
    return _REGISTRY
