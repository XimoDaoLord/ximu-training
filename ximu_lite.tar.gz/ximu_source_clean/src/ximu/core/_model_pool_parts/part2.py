"""带 TTL 过期和 LRU 驱逐策略的线程安全内存缓存池模块。

提供通用的 :class:`BaseTTLStore` 基类及一组按业务域隔离的子类，
统一封装线程安全键值存储、TTL 惰性过期、LRU 容量驱逐和细粒度统计。
子类通过覆盖 :attr:`store_name` 区分业务域，便于日志与监控定位。

主要特性：
- 线程安全的键值存储，使用 ``threading.RLock`` 保护
- 惰性 TTL 过期检查，避免全量扫描开销
- LRU 容量驱逐，在超过 max_size 时自动清理最久未访问条目
- 细粒度统计：命中率、驱逐次数、"未命中"细分为"从未存在/已过期"
- 批量操作接口：put_many/get_many/remove_many 提升高并发性能
- 快照查询接口：keys/values/items/to_dict 在锁内完成过期过滤
- 原子统计快照：通过 StatsSnapshot 数据类支持并发安全的监控采集

设计改进：
- 惰性清理：put 时随机抽样检查过期条目，避免 O(N) 全量扫描
- 优化 get/remove 逻辑，消除冗余键检查
- 统计计数器封装为独立数据类，支持原子快照导出
- 统一命名规范（snake_case），修复原始代码中的不一致问题

.. versionadded:: 0.5
"""

import logging
import random
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

__version__ = "0.5"


def _now() -> float:
    """获取当前 UNIX 时间戳（秒）。

    :return: 当前 UNIX 时间戳，单位秒。
    """
    return time.time()


@dataclass(frozen=True)
class StatsSnapshot:
    """统计信息原子快照，用于并发安全的监控数据采集。

    Attributes:
        hits: 命中次数
        misses: 未命中次数
        evictions: LRU 驱逐次数
        total_writes: 总写入次数
        never_existed: 从未存在的未命中次数
        expired: 已过期未命中次数
        active_size: 逻辑有效（未过期）条目数
        physical_size: 物理存储大小
    """
    hits: int
    misses: int
    evictions: int
    total_writes: int
    never_existed: int
    expired: int
    active_size: int
    physical_size: int

    def to_dict(self, store_name: str = "") -> Dict[str, Any]:
        """将快照转换为字典，便于日志记录和监控上报。

        Args:
            store_name: 存储实例的业务域名称

        Returns:
            包含所有统计指标的字典
        """
        total = self.hits + self.misses
        hit_rate = self.hits / total if total > 0 else 0.0
        return {
            "store_name": store_name,
            "hits": self.hits,
            "misses": self.misses,
            "hit_rate": hit_rate,
            "evictions": self.evictions,
            "writes": self.total_writes,
            "never_existed": self.never_existed,
            "expired": self.expired,
            "active_size": self.active_size,
            "physical_size": self.physical_size,
        }


class BaseTTLStore:
    """带 TTL 过期和 LRU 驱逐策略的线程安全内存存储基类。

    核心特性：
    - 每次写入记录时间戳，读取时惰性判断是否过期
    - 物理条目数超过 ``max_size`` 时自动驱逐最久未访问条目（LRU）
    - 所有公共操作均由 ``threading.RLock`` 保护，可安全并发调用
    - 提供命中率、驱逐次数、以及"未命中"细分为"从未存在/已过期"的统计
    - ``keys``/``values``/``items``/``to_dict`` 在锁内完成过期过滤，避免竞态条件

    性能优化：
    - 惰性清理：put 时随机抽样检查过期条目，避免 O(N) 全量扫描
    - 使用 __slots__ 减少内存占用
    - 统计计数器通过锁保护，支持原子快照导出
    """

    # 子类可覆盖以提供业务域名称，用于日志与统计区分
    store_name: str = "BaseTTLStore"

    # 惰性清理抽样大小，在 put 时随机检查此数量的条目
    _SAMPLE_SIZE: int = 32

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        """初始化存储实例。

        Args:
            max_size: 最大物理条目数（正整数），超过时触发 LRU 驱逐
            ttl: 条目生存时间（秒，正数），超过后视为过期

        Raises:
            ValueError: 当 max_size 或 ttl 非正时抛出
        """
        if max_size <= 0:
            raise ValueError(f"max_size 必须为正整数，收到: {max_size}")
        if ttl <= 0:
            raise ValueError(f"ttl 必须为正数，收到: {ttl}")

        self._max_size: int = max_size
        self._ttl: float = ttl
        self._lock: threading.RLock = threading.RLock()
        self._store: "OrderedDict[Any, Tuple[Any, float]]" = OrderedDict()

        # 统计计数器
        self._hits: int = 0
        self._misses: int = 0
        self._evictions: int = 0
        self._total_writes: int = 0
        self._never_existed_count: int = 0
        self._expired_count: int = 0

        # 惰性清理跟踪
        self._last_purge_time: float = _now()
        self._purge_interval: float = min(ttl / 10, 1.0)

    # ------------------------------------------------------------------
    # 内部辅助方法
    # ------------------------------------------------------------------

    def _is_expired(self, ts: float, now: Optional[float] = None) -> bool:
        """判断给定时间戳是否已超过 TTL。

        Args:
            ts: 条目写入时的时间戳
            now: 参考时间戳；缺省时取当前时间

        Returns:
            已过期返回 True，否则返回 False
        """
        if now is None:
            now = _now()
        return (now - ts) > self._ttl

    def _lazy_purge_expired(self, now: Optional[float] = None) -> int:
        """惰性清理过期条目（调用前必须已持有锁）。

        采用随机抽样策略，避免每次 put 都全量扫描 O(N) 的开销。
        当距离上次全量清理超过 purge_interval 时，执行全量清理。

        Args:
            now: 参考时间戳；缺省时取当前时间

        Returns:
            被清理的条目数量
        """
        if now is None:
            now = _now()

        # 检查是否应该执行全量清理
        if now - self._last_purge_time >= self._purge_interval:
            removed = self._full_purge_expired(now)
            self._last_purge_time = now
            return removed

        # 随机抽样清理
        if not self._store:
            return 0

        sample_keys = random.sample(
            list(self._store.keys()),
            min(self._SAMPLE_SIZE, len(self._store))
        )
        removed = 0
        for key in sample_keys:
            entry = self._store.get(key)
            if entry is None:
                continue
            _, ts = entry
            if self._is_expired(ts, now):
                del self._store[key]
                removed += 1

        if removed:
            logger.debug("%s: 惰性清理 %d 个过期条目（抽样）", self.store_name, removed)

        return removed

    def _full_purge_expired(self, now: Optional[float] = None) -> int:
        """在已持有锁的前提下清理所有过期条目。

        Args:
            now: 参考时间戳；缺省时取当前时间

        Returns:
            被清理的条目数量
        """
        if now is None:
            now = _now()

        removed = 0
        for key in list(self._store.keys()):
            entry = self._store.get(key)
            if entry is None:
                continue
            _, ts = entry
            if self._is_expired(ts, now):
                del self._store[key]
                removed += 1

        if removed:
            logger.debug("%s: 全量清理 %d 个过期条目", self.store_name, removed)

        return removed

    def _get_stats_snapshot_locked(self, active_size: Optional[int] = None) -> StatsSnapshot:
        """获取统计原子快照（调用前必须已持有锁）。

        Args:
            active_size: 预计算的逻辑有效条目数；缺省时计算

        Returns:
            StatsSnapshot 实例
        """
        if active_size is None:
            now = _now()
            active_size = sum(
                1 for _, ts in self._store.values() if not self._is_expired(ts, now)
            )

        return StatsSnapshot(
            hits=self._hits,
            misses=self._misses,
            evictions=self._evictions,
            total_writes=self._total_writes,
            never_existed=self._never_existed_count,
            expired=self._expired_count,
            active_size=active_size,
            physical_size=len(self._store),
        )

    def _evict_lru_if_needed(self) -> None:
        """在已持有锁的前提下执行 LRU 驱逐（调用前必须已持有锁）。

        当物理条目数超过 max_size 时，驱逐最久未访问的条目。
        """
        while len(self._store) > self._max_size:
            evicted_key, _ = self._store.popitem(last=False)
            self._evictions += 1
            logger.debug(
                "%s: 触发 LRU 驱逐键 %r（物理大小=%d，上限=%d）",
                self.store_name, evicted_key,
                len(self._store), self._max_size,
            )

    # ------------------------------------------------------------------
    # 核心读写操作
    # ------------------------------------------------------------------

    def put(self, key: Any, value: Any) -> None:
        """写入或更新条目，并触发 LRU 容量检查。

        Args:
            key: 条目键，需可哈希
            value: 条目值
        """
        with self._lock:
            self._lazy_purge_expired()
            self._store[key] = (value, _now())
            self._store.move_to_end(key)
            self._total_writes += 1
            self._evict_lru_if_needed()

    def get(self, key: Any, default: Optional[Any] = None) -> Optional[Any]:
        """读取条目，键不存在或已过期时返回 default。

        命中与未命中都会更新统计；未命中进一步细分为
        "从未存在"与"已过期"两类，便于监控区分。

        Args:
            key: 要查找的键
            default: 未命中时返回的默认值

        Returns:
            命中时返回缓存值，否则返回 default
        """
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                self._misses += 1
                self._never_existed_count += 1
                return default

            value, ts = entry
            if self._is_expired(ts):
                del self._store[key]
                self._misses += 1
                self._expired_count += 1
                return default

            self._store.move_to_end(key)
            self._hits += 1
            return value

    def remove(self, key: Any) -> bool:
        """删除指定键对应的条目。

        Args:
            key: 要删除的键

        Returns:
            存在并成功删除返回 True，否则返回 False
        """
        with self._lock:
            if key in self._store:
                del self._store[key]
                logger.debug("%s: 删除键 %r", self.store_name, key)
                return True
            return False

    def contains(self, key: Any) -> bool:
        """检查键是否存在且未过期。

        本方法不会更新 hits（避免污染命中率），但会在未命中
        时更新 never_existed 与 expired 细分统计。

        Args:
            key: 要检查的键

        Returns:
            存在且未过期返回 True
        """
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                self._never_existed_count += 1
                return False

            _, ts = entry
            if self._is_expired(ts):
                del self._store[key]
                self._expired_count += 1
                return False

            self._store.move_to_end(key)
            return True

    # ------------------------------------------------------------------
    # 批量操作
    # ------------------------------------------------------------------

    def put_many(self, items: Dict[Any, Any]) -> int:
        """批量写入条目。

        Args:
            items: 键值对字典

        Returns:
            成功写入的条目数量
        """
        if not items:
            return 0

        with self._lock:
            self._lazy_purge_expired()

            now = _now()
            written = 0
            for key, value in items.items():
                self._store[key] = (value, now)
                self._store.move_to_end(key)
                written += 1
            self._total_writes += written

            self._evict_lru_if_needed()
            logger.debug("%s: 批量写入 %d 个条目", self.store_name, written)
            return written

    def get_many(self, keys: List[Any], default: Optional[Any] = None) -> Dict[Any, Any]:
        """批量读取条目。

        Args:
            keys: 要查找的键列表
            default: 未命中时返回的默认值（保持接口一致性）

        Returns:
            键值对字典，仅包含找到的条目
        """
        if not keys:
            return {}

        result: Dict[Any, Any] = {}
        with self._lock:
            now = _now()
            for key in keys:
                entry = self._store.get(key)
                if entry is None:
                    self._misses += 1
                    self._never_existed_count += 1
                    continue

                value, ts = entry
                if self._is_expired(ts, now):
                    del self._store[key]
                    self._misses += 1
                    self._expired_count += 1
                    continue

                self._store.move_to_end(key)
                self._hits += 1
                result[key] = value

        return result

    def remove_many(self, keys: List[Any]) -> int:
        """批量删除条目。

        Args:
            keys: 要删除的键列表

        Returns:
            成功删除的条目数量
        """
        if not keys:
            return 0

        with self._lock:
            removed = 0
            for key in keys:
                if key in self._store:
                    del self._store[key]
                    removed += 1

            if removed:
                logger.debug("%s: 批量删除 %d 个条目", self.store_name, removed)
            return removed

    # -------------------------------------------------------------
    # 快照查询接口
    # -------------------------------------------------------------

    def _get_valid_items_snapshot(self, now: Optional[float] = None) -> List[Tuple[Any, Any]]:
        """获取所有未过期条目的快照列表（调用前必须已持有锁）。

        Args:
            now: 参考时间戳；缺省时取当前时间

        Returns:
            包含 (key, value) 元组的列表
        """
        if now is None:
            now = _now()
        result: List[Tuple[Any, Any]] = []
        for key, (value, ts) in self._store.items():
            if not self._is_expired(ts, now):
                result.append((key, value))
        return result

    def keys(self) -> List[Any]:
        """返回所有未过期条目的键列表。

        Returns:
            键的列表
        """
        with self._lock:
            valid_items = self._get_valid_items_snapshot()
        return [k for k, _ in valid_items]

    def values(self) -> List[Any]:
        """返回所有未过期条目的值列表。

        Returns:
            值的列表
        """
        with self._lock:
            valid_items = self._get_valid_items_snapshot()
        return [v for _, v in valid_items]

    def items(self) -> List[Tuple[Any, Any]]:
        """返回所有未过期条目的 (key, value) 列表。

        Returns:
            (key, value) 元组列表
        """
        with self._lock:
            valid_items = self._get_valid_items_snapshot()
        return valid_items

    def __len__(self) -> int:
        """返回未过期条目的数量。

        Returns:
            逻辑有效条目数
        """
        with self._lock:
            now = _now()
            return sum(1 for _, ts in self._store.values() if not self._is_expired(ts, now))

    def __contains__(self, key: Any) -> bool:
        """检查键是否存在且未过期。

        Args:
            key: 要检查的键

        Returns:
            存在且未过期返回 True
        """
        return self.contains(key)

    # ------------------------------------------------------------------
    # 配置属性
    # ------------------------------------------------------------------

    @property
    def ttl(self) -> float:
        """返回 TTL 配置值（秒）。"""
        return self._ttl

    @property
    def max_size(self) -> int:
        """返回最大容量配置值。"""
        return self._max_size

    # ------------------------------------------------------------------
    # 统计与序列化
    # ------------------------------------------------------------------

    def get_stats(self) -> Dict[str, Any]:
        """返回当前统计信息快照。

        Returns:
            包含容量、命中、驱逐、过期未命中等指标的字典
        """
        with self._lock:
            snapshot = self._get_stats_snapshot_locked()
            result = snapshot.to_dict(self.store_name)
            result["max_size"] = self._max_size
            result["ttl"] = self._ttl
            return result

    def to_dict(self) -> Dict[Any, Any]:
        """将所有未过期条目序列化为普通字典。

        Returns:
            仅包含未过期条目的 {key: value} 字典
        """
        with self._lock:
            valid_items = self._get_valid_items_snapshot()
        return {k: v for k, v in valid_items}


# ----------------------------------------------------------------------
# 业务域 Store 子类
# ----------------------------------------------------------------------


class CacheStore(BaseTTLStore):
    """通用缓存存储：用于存储需要按业务域隔离的缓存数据。"""
    store_name: str = "CacheStore"


class MetadataStore(BaseTTLStore):
    """元数据存储：用于模型、接口等元数据，支持 TTL 自动过期。"""
    store_name: str = "MetadataStore"


class EventStore(BaseTTLStore):
    """事件存储：用于存储临时事件数据，过期后自动清除。"""
    store_name: str = "EventStore"


class MetricStore(BaseTTLStore):
    """指标存储：用于存储监控指标的历史快照。"""
    store_name: str = "MetricStore"


class LogStore(BaseTTLStore):
    """日志存储：用于存储结构化日志条目，带 TTL 自动过期。"""
    store_name: str = "LogStore"


class StateStore(BaseTTLStore):
    """状态存储：用于存储有状态的临时工作区数据。"""
    store_name: str = "StateStore"


class SnapshotStore(BaseTTLStore):
    """快照存储：用于存储数据快照，支持按 TTL 自动清理。"""
    store_name: str = "SnapshotStore"


class IndexStore(BaseTTLStore):
    """索引存储：用于存储辅助索引数据，带 TTL 自动过期。"""
    store_name: str = "IndexStore"
