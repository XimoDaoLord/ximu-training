import numpy as np
import threading
import logging
import json
import os
from typing import List, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class OptimizerBase:
    """线程安全的优化器抽象基类，定义状态管理与参数更新接口。"""

    def __init__(self, learning_rate: float, beta1: float = 0.9, beta2: float = 0.999) -> None:
        """初始化优化器，设置学习率与动量超参数。

        Args:
            learning_rate: 学习率。
            beta1: 一阶矩衰减率。
            beta2: 二阶矩衰减率。
        """
        if not 0 < learning_rate:
            raise ValueError("Learning rate must be positive.")
        if not (0 <= beta1 <= 1):
            raise ValueError("beta1 must be in [0, 1].")
        if not (0 <= beta2 <= 1):
            raise ValueError("beta2 must be in [0, 1].")

        self.learning_rate: float = learning_rate
        self.beta1: float = beta1
        self.beta2: float = beta2

        self.params_history: List[np.ndarray] = []
        self.m: List[np.ndarray] = []
        self.v: List[np.ndarray] = []
        self.t: int = 0
        self.last_time: Optional[datetime] = None
        self._lock: threading.Lock = threading.Lock()

    def _initialize_state(self, params: List[np.ndarray]) -> None:
        """根据输入参数初始化一阶矩和二阶矩状态。

        Args:
            params: 参数量列表，用于确定状态形状。
        """
        self.m = [np.zeros_like(param) for param in params]
        self.v = [np.zeros_like(param) for param in params]
        self.params_history = [np.copy(param) for param in params]
        self.t = 0
        logger.info("Optimizer state initialized.")

    def _validate_params(
        self,
        params: List[np.ndarray],
        gradients: List[np.ndarray]
    ) -> None:
        """校验参数和梯度的数量与形状一致性。

        Args:
            params: 当前参数列表。
            gradients: 当前梯度列表。

        Raises:
            ValueError: 当参数/梯度数量或形状不匹配时抛出。
        """
        if len(params) != len(gradients):
            raise ValueError(f"Number of parameters ({len(params)}) != number of gradients ({len(gradients)}).")

        if self.params_history:
            if len(params) != len(self.params_history):
                raise ValueError("Number of parameters changed during optimization.")
            for i, (param, ref) in enumerate(zip(params, self.params_history)):
                if param.shape != ref.shape:
                    raise ValueError(f"Parameter shape mismatch at index {i}: expected {ref.shape}, got {param.shape}.")

    def update(self, params: List[np.ndarray], gradients: List[np.ndarray]) -> List[np.ndarray]:
        """执行 Adam 参数更新步骤，线程安全。

        Args:
            params: 待更新的参数列表（原地修改）。
            gradients: 对应的梯度列表。

        Returns:
            更新后的参数列表（与原列表引用相同）。

        Raises:
            ValueError: 参数或梯度校验失败时抛出。
        """
        with self._lock:
            current_time = datetime.now()
            delta_t = (current_time - self.last_time).total_seconds() if self.last_time else 0.0
            self.last_time = current_time

            self._validate_params(params, gradients)

            if not self.params_history:
                self._initialize_state(params)

            self.t += 1
            epsilon = 1e-8

            for i, (param, grad) in enumerate(zip(params, gradients)):
                self.m[i] = self.beta1 * self.m[i] + (1 - self.beta1) * grad
                self.v[i] = self.beta2 * self.v[i] + (1 - self.beta2) * (grad ** 2)

                m_hat = self.m[i] / (1 - self.beta1 ** self.t)
                v_hat = self.v[i] / (1 - self.beta2 ** self.t)

                params[i] = param - self.learning_rate * m_hat / (np.sqrt(v_hat) + epsilon)

            thread_id = threading.current_thread().ident
            logger.debug(f"Thread {thread_id} updated parameters in {delta_t:.4f}s.")
            return params

    def save_state(self, filepath: str) -> None:
        """将优化器完整状态序列化并保存到文件。

        Args:
            filepath: 目标文件路径。

        Raises:
            IOError: 文件写入失败时抛出。
        """
        state = {
            "learning_rate": self.learning_rate,
            "beta1": self.beta1,
            "beta2": self.beta2,
            "m": self.m,
            "v": self.v,
            "t": self.t,
            "params_history": self.params_history
        }
        try:
            with open(filepath, "w") as f:
                json.dump(state, f)
            logger.info(f"Optimizer state saved to {filepath}.")
        except OSError as e:
            logger.error(f"Failed to save state to {filepath}: {e}")
            raise

    def load_state(self, filepath: str) -> None:
        """从文件加载优化器状态。

        Args:
            filepath: 源文件路径。

        Raises:
            IOError: 文件读取失败时抛出。
            ValueError: 文件内容结构不合法时抛出。
        """
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"State file not found: {filepath}")

        try:
            with open(filepath, "r") as f:
                state = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            logger.error(f"Failed to load state from {filepath}: {e}")
            raise

        required_keys = {"learning_rate", "beta1", "beta2", "m", "v", "t", "params_history"}
        if not required_keys.issubset(state.keys()):
            missing = required_keys - state.keys()
            raise ValueError(f"Invalid state file, missing keys: {missing}")

        self.learning_rate = state["learning_rate"]
        self.beta1 = state["beta1"]
        self.beta2 = state["beta2"]
        self.m = state["m"]
        self.v = state["v"]
        self.t = state["t"]
        self.params_history = state["params_history"]
        logger.info(f"Optimizer state loaded from {filepath}.")

class AdamOptimizer(OptimizerBase):
    """线程安全的 Adam 优化器实现，支持状态持久化与恢复。"""

    def __init__(self, learning_rate: float, beta1: float = 0.9, beta2: float = 0.999) -> None:
        """初始化 Adam 优化器。

        Args:
            learning_rate: 学习率。
            beta1: 一阶矩衰减率。
            beta2: 二阶矩衰减率。
        """
        super().__init__(learning_rate, beta1, beta2)
        self.logger = logging.getLogger("AdamOptimizer")

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    optimizer = AdamOptimizer(learning_rate=0.001)

    params = [np.random.randn(10), np.random.randn(10)]
    gradients = [np.random.randn(10), np.random.randn(10)]

    updated = optimizer.update(params, gradients)
    optimizer.save_state("optimizer_state.json")
    optimizer.load_state("optimizer_state.json")
    updated = optimizer.update(params, gradients)
