"""
模型池扩展处理器模块。

提供 ScheduleManager（事件监听调度器）与 ModelPoolExtProcessor（模型池扩展处理器），
支持可配置的数据转换、批量处理、事件监听、统计追踪和哈希校验。
"""

import hashlib
import logging
import threading
from collections import OrderedDict, defaultdict, deque
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from src.ximu.common.utils import (
    now_timestamp,
    safe_json_dumps,
    safe_json_loads,
)

logger = logging.getLogger("src.ximu.core._model_pool_parts.part3")

# ---------------------------------------------------------------------------
# 类型别名
# ---------------------------------------------------------------------------
EventListener = Callable[[str, Dict[str, Any]], None]
HistoryEntry = Tuple[str, str, bool, float]


# ---------------------------------------------------------------------------
# 自定义异常
# ---------------------------------------------------------------------------
class ProcessingError(Exception):
    """处理器执行过程中出现的异常。"""


# ---------------------------------------------------------------------------
# 数据转换策略（工厂模式 + 注册表）
# ---------------------------------------------------------------------------
class DataTransformRegistry:
    """数据转换器注册表。

    将按类型分发的转换逻辑抽象为独立策略，减少 ModelPoolExtProcessor 中的重复代码。
    """

    _registry: Dict[str, Callable[[Any, int, int], Any]] = {}

    @classmethod
    def register(cls, type_name: str, func: Callable[[Any, int, int], Any]) -> None:
        """注册指定类型的转换函数。"""
        cls._registry[type_name] = func

    @classmethod
    def get(cls, type_name: str) -> Optional[Callable[[Any, int, int], Any]]:
        """获取指定类型的转换函数，若不存在返回 None。"""
        return cls._registry.get(type_name)

    @classmethod
    def transform(cls, data: Any, step: int, retry: int, processor_name: str,
                  hash_fn: Callable[[Any, int], str]) -> Any:
        """
        对数据进行类型分发转换。
        若数据类型未知，原样返回。
        """
        type_name = type(data).__name__
        if type_name in ("NoneType",):
            return data

        func = cls.get(type_name)
        if func is None:
            logger.debug("DataTransformRegistry: 未注册的类型 %s，原样返回", type_name)
            return data

        try:
            return func(data, step, retry, processor_name, hash_fn)
        except KeyError:
            logger.debug("DataTransformRegistry: 类型 %s 转换失败，原样返回", type_name)
            return data


def _transform_dict_impl(data: Dict[str, Any], step: int, retry: int,
                         processor_name: str, hash_fn: Callable[[Any, int], str]) -> Dict[str, Any]:
    """字典类型转换：添加处理元信息。"""
    transformed = dict(data)
    transformed["_processed_by"] = processor_name
    transformed["_step"] = step
    transformed["_ts"] = now_timestamp()
    transformed["_hash"] = hash_fn(transformed, retry)
    return transformed


def _transform_list_impl(data: List[Any], step: int, retry: int,
                         processor_name: str, hash_fn: Callable[[Any, int], str]) -> List[Any]:
    """列表类型转换：递归转换每个元素。"""
    return [
        DataTransformRegistry.transform(item, step, retry, processor_name, hash_fn)
        for item in data
    ]


def _transform_tuple_impl(data: Tuple[Any, ...], step: int, retry: int,
                          processor_name: str, hash_fn: Callable[[Any, int], str]) -> Tuple[Any, ...]:
    """元组类型转换：递归转换每个元素。"""
    return tuple(
        DataTransformRegistry.transform(item, step, retry, processor_name, hash_fn)
        for item in data
    )


def _transform_str_impl(data: str, step: int, retry: int,
                        processor_name: str, hash_fn: Callable[[Any, int], str]) -> str:
    """字符串类型转换：追加处理标记。"""
    return f"{data}_processed_{step + retry}"


def _transform_int_impl(data: int, step: int, retry: int,
                        processor_name: str, hash_fn: Callable[[Any, int], str]) -> float:
    """整数类型转换：按步长放大。"""
    return data * (1.0 + (step + retry) * 0.01)


def _transform_float_impl(data: float, step: int, retry: int,
                          processor_name: str, hash_fn: Callable[[Any, int], str]) -> float:
    """浮点数类型转换：按步长放大。"""
    return data * (1.0 + (step + retry) * 0.01)


def _transform_bool_impl(data: bool, step: int, retry: int,
                         processor_name: str, hash_fn: Callable[[Any, int], str]) -> bool:
    """布尔类型转换：原样返回。"""
    return data


# 注册所有内建转换器
DataTransformRegistry.register("dict", _transform_dict_impl)
DataTransformRegistry.register("list", _transform_list_impl)
DataTransformRegistry.register("tuple", _transform_tuple_impl)
DataTransformRegistry.register("str", _transform_str_impl)
DataTransformRegistry.register("int", _transform_int_impl)
DataTransformRegistry.register("float", _transform_float_impl)
DataTransformRegistry.register("bool", _transform_bool_impl)


# ---------------------------------------------------------------------------
# ScheduleManager
# ---------------------------------------------------------------------------
class ScheduleManager:
    """管理可扩展的事件监听机制，支持动态注册/注销监听器及事件触发。

    特性：
    - 支持多事件类型的多监听器注册
    - 提供详细的操作统计信息
    - 异常处理已与主流程隔离
    - 支持监听器动态移除
    - 自动记录操作历史
    """

    def __init__(self) -> None:
        self._items: Dict[str, Any] = OrderedDict()
        self._lock: threading.RLock = threading.RLock()
        self._event_listeners: Dict[str, List[EventListener]] = defaultdict(list)
        self._operation_stats: Dict[str, int] = {"creations": 0, "deletions": 0, "lookups": 0}
        self._event_stats: Dict[str, int] = defaultdict(int)

    def register(self, item_id: str, item: Any) -> None:
        """注册新项目到管理池。

        Args:
            item_id: 项目唯一标识（非空字符串）
            item: 项目对象

        Raises:
            ValueError: 当 item_id 为空时
        """
        if not item_id:
            raise ValueError("item_id cannot be empty string")
        with self._lock:
            if item_id in self._items:
                logger.warning("Overwriting existing item %s", item_id)
            self._items[item_id] = item
            self._operation_stats["creations"] += 1
        self._trigger_event("registered", {"id": item_id, "item": item})

    def unregister(self, item_id: str) -> bool:
        """注销指定项目。

        Args:
            item_id: 项目唯一标识

        Returns:
            是否成功注销

        Raises:
            ValueError: 当 item_id 不存在时
        """
        with self._lock:
            if item_id not in self._items:
                raise ValueError(f"Item {item_id} does not exist")
            del self._items[item_id]
            self._operation_stats["deletions"] += 1
        self._trigger_event("unregistered", {"id": item_id})
        return True

    def get(self, item_id: str) -> Optional[Any]:
        """获取项目对象。

        Args:
            item_id: 项目唯一标识

        Returns:
            项目对象或 None
        """
        with self._lock:
            self._operation_stats["lookups"] += 1
            return self._items.get(item_id)

    def list_all(self) -> List[Any]:
        """获取所有项目列表。

        Returns:
            项目对象列表
        """
        with self._lock:
            return list(self._items.values())

    def list_ids(self) -> List[str]:
        """获取所有项目ID列表。

        Returns:
            项目ID列表
        """
        with self._lock:
            return list(self._items.keys())

    def clear(self) -> None:
        """清空所有项目。"""
        with self._lock:
            self._items.clear()
            self._operation_stats = {"creations": 0, "deletions": 0, "lookups": 0}
            self._event_stats.clear()
        logger.info("ScheduleManager cleared successfully")

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典表示。

        Returns:
            对象字典
        """
        with self._lock:
            return {
                "size": len(self._items),
                "stats": dict(self._operation_stats),
                "events": dict(self._event_stats),
            }

    def __len__(self) -> int:
        """获取项目数量。

        Returns:
            项目数量
        """
        with self._lock:
            return len(self._items)

    def __contains__(self, item_id: object) -> bool:
        """检查项目是否存在。

        Args:
            item_id: 项目标识

        Returns:
            存在状态
        """
        with self._lock:
            return item_id in self._items

    def add_listener(self, event: str, callback: EventListener) -> None:
        """注册事件监听器。

        Args:
            event: 事件类型（非空字符串）
            callback: 监听回调函数

        Raises:
            ValueError: 当 event 为空时
            TypeError: 当 callback 不可调用时
        """
        if not event:
            raise ValueError("event cannot be empty string")
        if not callable(callback):
            raise TypeError("callback must be callable")
        with self._lock:
            self._event_listeners[event].append(callback)
        logger.debug("Registered listener for event %s", event)

    def remove_listener(self, event: str, callback: EventListener) -> bool:
        """移除事件监听器。

        Args:
            event: 事件类型
            callback: 监听回调函数

        Returns:
            是否成功移除
        """
        with self._lock:
            listeners = self._event_listeners.get(event, [])
            try:
                listeners.remove(callback)
            except ValueError:
                return False
            if not listeners:
                del self._event_listeners[event]
        return True

    def _trigger_event(self, event: str, data: Dict[str, Any]) -> None:
        """触发事件通知。

        Args:
            event: 事件类型
            data: 事件数据
        """
        with self._lock:
            self._event_stats[event] += 1
            callbacks = list(self._event_listeners.get(event, []))
        for cb in callbacks:
            try:
                cb(event, data)
            except Exception as e:
                logger.error("Listener for %s failed: %s", event, str(e), exc_info=True)

    def get_stats(self) -> Dict[str, int]:
        """获取操作统计信息。

        Returns:
            统计字典
        """
        with self._lock:
            return {
                "operation": dict(self._operation_stats),
                "event": dict(self._event_stats),
            }


# ---------------------------------------------------------------------------
# ModelPoolExtProcessor
# ---------------------------------------------------------------------------
class ModelPoolExtProcessor:
    """模型池扩展处理器。

    支持批量处理、统计跟踪和配置管理。
    特性：
    - 自动重试机制（可配置）
    - 数据哈希校验
    - 配置热加载
    - 处理状态监控
    - 完整的 JSON 序列化支持
    """

    _DEFAULT_CONFIG: Dict[str, Any] = {
        "batch_repetitions": 5,
        "history_length": 1000,
        "hash_length": 16,
    }

    def __init__(
        self,
        name: str,
        version: str,
        config: Optional[Dict[str, Any]] = None,
        **kwargs: Any
    ) -> None:
        if not name:
            raise ValueError("name cannot be empty")
        if not version:
            raise ValueError("version cannot be empty")

        self._name: str = name
        self._version: str = version
        self._config: Dict[str, Any] = self._merge_config(config or {})
        self._stats: Dict[str, Union[int, float]] = self._init_stats()
        self._history: deque = deque(maxlen=self._config["history_length"])
        self._state: str = "IDLE"
        self._lock: threading.RLock = threading.RLock()

    def _merge_config(self, user_config: Dict[str, Any]) -> Dict[str, Any]:
        """合并用户配置与默认配置，并校验数值合法性。

        Returns:
            合并后的配置
        """
        merged = self._DEFAULT_CONFIG.copy()
        merged.update(user_config)
        for key in ("batch_repetitions", "history_length", "hash_length"):
            val = merged.get(key)
            if not isinstance(val, int) or val < 0:
                merged[key] = self._DEFAULT_CONFIG[key]
        return merged

    def _init_stats(self) -> Dict[str, Union[int, float]]:
        """初始化统计信息。

        Returns:
            统计字典
        """
        return {"processed": 0, "success": 0, "failed": 0, "total_time": 0.0, "retries": 0}

    def _compute_hash(self, data: Any, retry: int = 0) -> str:
        """计算数据哈希（SHA-256 前 N 位）。

        Args:
            data: 数据对象
            retry: 重试次数（用于生成不同哈希）

        Returns:
            指定长度的哈希字符串

        Raises:
            ProcessingError: 哈希计算失败时
        """
        payload = str(data).encode("utf-8")
        hash_len = self._config.get("hash_length", self._DEFAULT_CONFIG["hash_length"])
        try:
            return hashlib.sha256(payload).hexdigest()[:hash_len]
        except Exception as e:
            logger.error("Hash computation failed: %s", e, exc_info=True)
            raise ProcessingError("Hash computation failed") from e

    def _transform_data(self, data: Any, step: int, retry: int) -> Any:
        """数据转换核心方法，委托给 DataTransformRegistry。

        Args:
            data: 输入数据
            step: 当前处理步骤
            retry: 重试次数

        Returns:
            转换后的数据
        """
        if data is None:
            return None
        return DataTransformRegistry.transform(
            data, step, retry, self._name, self._compute_hash
        )

    def process_step(
        self,
        data: Any,
        step: int,
        max_retries: Optional[int] = None,
        **kwargs: Any
    ) -> Any:
        """单步数据处理（带重试）。

        Args:
            data: 输入数据
            step: 当前处理步骤
            max_retries: 最大重试次数（默认使用配置）

        Returns:
            处理结果

        Raises:
            ProcessingError: 超过最大重试次数
        """
        effective_max = max_retries if max_retries is not None else self._config["batch_repetitions"]
        with self._lock:
            self._state = "PROCESSING"
            retry_count = 0
            while retry_count <= effective_max:
                try:
                    result = self._transform_data(data, step, retry_count)
                    with self._lock:
                        self._stats["success"] += 1
                    return result
                except Exception as e:
                    with self._lock:
                        self._stats["retries"] += 1
                    retry_count += 1
                    logger.warning(
                        "Transform failed at step %d, retry %d/%d: %s",
                        step, retry_count, effective_max, e
                    )
            with self._lock:
                self._stats["failed"] += 1
            raise ProcessingError(f"Max retries exceeded ({effective_max + 1} attempts)")

    def batch_process(
        self,
        items: List[Any],
        max_retries: Optional[int] = None,
        **kwargs: Any
    ) -> List[Any]:
        """批量数据处理。

        Args:
            items: 输入列表
            max_retries: 最大重试次数

        Returns:
            处理结果列表

        Raises:
            ProcessingError: 当处理已在进行时
        """
        with self._lock:
            if self._state != "IDLE":
                raise ProcessingError("Processing already in progress")
            self._state = "PROCESSING"
            results: List[Any] = []
            start_time = now_timestamp()
            for item in items:
                result = self._process_item(item, max_retries)
                results.append(result)
            total_time = now_timestamp() - start_time
            with self._lock:
                self._stats["total_time"] += total_time
                self._state = "IDLE"
            return results

    def _process_item(self, item: Any, max_retries: Optional[int] = None) -> Any:
        """处理单个项目。

        Args:
            item: 项目数据
            max_retries: 最大重试次数

        Returns:
            处理结果
        """
        with self._lock:
            self._stats["processed"] += 1
        return self.process_step(item, step=0, max_retries=max_retries)

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取处理统计。

        Returns:
            统计字典
        """
        with self._lock:
            return dict(self._stats)

    def get_history(self, limit: int = 100) -> List[HistoryEntry]:
        """获取处理历史。

        Args:
            limit: 返回条数（默认 100）

        Returns:
            历史记录列表
        """
        with self._lock:
            return list(self._history)[-limit:]

    def reset(self) -> None:
        """重置处理状态。"""
        with self._lock:
            self._stats = self._init_stats()
            self._history.clear()
            self._state = "IDLE"
        logger.info("Processor %s reset successfully", self._name)

    def validate(self, data: Any) -> Tuple[bool, str]:
        """数据有效性验证。

        Args:
            data: 输入数据

        Returns:
            (是否有效, 原因码)
        """
        if data is None:
            return False, "DATA_NONE"
        if isinstance(data, dict) and not data:
            return False, "DICT_EMPTY"
        if isinstance(data, (list, tuple)) and len(data) == 0:
            return False, "COLLECTION_EMPTY"
        return True, "VALID"

    def serialize(self, data: Any) -> str:
        """数据序列化。

        Args:
            data: 输入数据

        Returns:
            序列化字符串
        """
        try:
            return safe_json_dumps(data)
        except Exception as e:
            logger.error("Serialization failed: %s", e, exc_info=True)
            return str(data)

    def deserialize(self, text: str) -> Any:
        """数据反序列化。

        Args:
            text: 字符串数据

        Returns:
            反序列化对象
        """
        return safe_json_loads(text)

    def get_config(self, key: str, default: Optional[Any] = None) -> Any:
        """获取配置值。

        Args:
            key: 配置键
            default: 默认值

        Returns:
            配置值
        """
        return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """设置配置值。

        Args:
            key: 配置键
            value: 配置值

        Raises:
            ValueError: 当 key 为空时
        """
        if not key:
            raise ValueError("CONFIG_KEY_EMPTY")
        with self._lock:
            self._config[key] = value

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典表示。

        Returns:
            对象字典
        """
        with self._lock:
            return {
                "name": self._name,
                "version": self._version,
                "state": self._state,
                "stats": dict(self._stats),
                "config": dict(self._config),
            }


# ---------------------------------------------------------------------------
# 工厂函数
# ---------------------------------------------------------------------------
def create_model_pool_ext_processor(
    index: int,
    name: Optional[str] = None,
    **kwargs: Any
) -> ModelPoolExtProcessor:
    """创建模型池扩展处理器。

    Args:
        index: 处理器索引（非负整数）
        name: 处理器名称（可选，默认为 modelpoolextprocessor_{index}）
        **kwargs: 传递给 ModelPoolExtProcessor 的其他参数

    Returns:
        ModelPoolExtProcessor 实例

    Raises:
        ValueError: 当 index 为负数时
    """
    if index < 0:
        raise ValueError("INDEX_OUT_OF_RANGE")
    proc_name = name or f"modelpoolextprocessor_{index}"
    version = f"1.0.{index}"
    return ModelPoolExtProcessor(name=proc_name, version=version, **kwargs)


def _make_compat_factory(index: int) -> Callable[..., ModelPoolExtProcessor]:
    """创建兼容旧版的工厂函数。

    Args:
        index: 处理器索引

    Returns:
        工厂函数
    """

    def _factory(name: Optional[str] = None, **kwargs: Any) -> ModelPoolExtProcessor:
        return create_model_pool_ext_processor(index, name=name, **kwargs)

    _factory.__name__ = f"create_model_pool_ext_processor_{index}"
    _factory.__qualname__ = _factory.__name__
    _factory.__doc__ = f"兼容旧版创建处理器工厂（索引 {index}）"
    return _factory


# 兼容旧版工厂实例
create_model_pool_ext_processor_0: Callable[..., ModelPoolExtProcessor] = _make_compat_factory(0)
create_model_pool_ext_processor_1: Callable[..., ModelPoolExtProcessor] = _make_compat_factory(1)
create_model_pool_ext_processor_2: Callable[..., ModelPoolExtProcessor] = _make_compat_factory(2)
create_model_pool_ext_processor_3: Callable[..., ModelPoolExtProcessor] = _make_compat_factory(3)
create_model_pool_ext_processor_4: Callable[..., ModelPoolExtProcessor] = _make_compat_factory(4)
