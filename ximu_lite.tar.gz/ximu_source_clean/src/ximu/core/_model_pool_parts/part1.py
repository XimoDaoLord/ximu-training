from __future__ import annotations
import logging
import threading
import time
from collections import deque
from typing import Any, Deque, Dict, Iterator, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

class Config:
    """全局配置参数类。

    集中管理模型调度池的各项阈值与默认值，避免散落的魔法数字。
    """
    def __init__(self) -> None:
        self.max_concurrent: int = 100
        self.daily_quota: int = -1
        self.sliding_window_size: int = 60  # 固定60秒窗口
        self.capacity: float = 100.0
        self.refill_rate: float = 1.0

class HealthScoreCalculator:
    """健康评分计算组件。

    根据失败率和延迟分布独立计算健康评分，不依赖具体模型实例状态。
    支持样本不足时的优雅降级处理。
    """
    def __init__(self) -> None:
        self.fail_rate_threshold: float = 0.1
        self.delay_threshold: float = 0.5

    def calculate(self, fail_rate: float, delay: float) -> float:
        if fail_rate > self.fail_rate_threshold or delay > self.delay_threshold:
            return 0.0
        return 1.0 - fail_rate - delay

class RateLimiter:
    """令牌桶限流器实现。

    基于令牌桶算法控制并发请求速率，支持容量与补充速率的可配置性，
    并实现滑动窗口动态调整策略。
    """
    def __init__(
        self,
        capacity: float,
        refill_rate: float,
        model_id: str = "",
        max_concurrent: int = 100,
        daily_quota: int = -1,
        sliding_window_size: int = 60,
    ) -> None:
        self.capacity: float = capacity
        self.refill_rate: float = refill_rate
        self.model_id: str = model_id
        self.max_concurrent: int = max_concurrent
        self.daily_quota: int = daily_quota
        self.sliding_window_size: int = sliding_window_size
        self.tokens: float = capacity
        self.last_refill: float = time.time()
        self.current_connections: int = 0
        self.daily_used: int = 0
        self._read_lock: threading.RLock = threading.RLock()
        self._write_lock: threading.RLock = threading.RLock()
        self._request_times: Deque[float] = deque(maxlen=sliding_window_size)

    def _refill(self) -> None:
        with self._write_lock:
            now = time.time()
            elapsed = now - self.last_refill
            added = elapsed * self.refill_rate
            self.tokens = min(self.capacity, self.tokens + added)
            self.last_refill = now

    def _adjust_capacity(self) -> None:
        with self._write_lock:
            if not self._request_times:
                return
            now = time.time()
            while self._request_times and now - self._request_times[0] > 60.0:
                self._request_times.popleft()
            request_count = len(self._request_times)
            current_rate = request_count / 60.0 if request_count > 0 else 0.0
            if current_rate > 0 and self.refill_rate > 0:
                ratio = current_rate / self.refill_rate
                new_capacity = min(self.capacity * 2, self.capacity * ratio * 1.5)
                if new_capacity != self.capacity:
                    logger.info(
                        "Adjusting rate limiter capacity for model %s: %.0f -> %.0f",
                        self.model_id,
                        self.capacity,
                        new_capacity,
                    )
                    self.capacity = new_capacity
                    self.tokens = min(self.tokens, new_capacity)

    def get_tokens(self) -> float:
        with self._read_lock:
            self._refill()
            return self.tokens

    def acquire(self) -> bool:
        with self._write_lock:
            self._refill()
            if self.daily_quota > 0 and self.daily_used >= self.daily_quota:
                logger.debug("Daily quota exhausted for model %s", self.model_id)
                return False
            if self.current_connections >= self.max_concurrent:
                logger.debug(
                    "Max concurrent limit reached for model %s", self.model_id
                )
                return False
            if self.tokens < 1.0:
                logger.debug("Rate limiter exhausted for model %s", self.model_id)
                return False
            self.tokens -= 1.0
            self.current_connections += 1
            self.daily_used += 1
            self._request_times.append(time.time())
            logger.debug(
                "Acquired slot for model %s, connections=%d, tokens=%.2f",
                self.model_id,
                self.current_connections,
                self.tokens,
            )
            return True

    def release(self) -> None:
        with self._write_lock:
            self.current_connections = max(0, self.current_connections - 1)

    def daily_reset(self) -> None:
        """重置每日使用量，每日调用一次。"""
        with self._write_lock:
            self.daily_used = 0

class ErrorStatistics:
    """错误类型分类统计组件。

    维护最近 N 次错误的类型分布，支持熔断器决策。
    """
    def __init__(self, max_errors: int = 100) -> None:
        self.max_errors: int = max_errors
        self.error_counts: Dict[str, int] = {}
        self._lock: threading.Lock = threading.Lock()

    def record_error(self, error_type: str) -> None:
        with self._lock:
            self.error_counts[error_type] = self.error_counts.get(error_type, 0) + 1

    def get_error_distribution(self) -> Dict[str, int]:
        return self.error_counts.copy()

    def reset(self) -> None:
        """重置错误统计周期，清空所有计数。"""
        with self._lock:
            self.error_counts.clear()

class ModelInstance:
    """模型实例封装。

    聚合单个模型实例的运行状态、熔断器状态、限流器状态与统计指标。
    所有状态变更均在内部锁保护下完成，保证线程安全。
    """
    def __init__(self, model_id: str, config: Config) -> None:
        self.model_id: str = model_id
        self.config: Config = config
        self.health_score: float = 1.0
        self.error_statistics: ErrorStatistics = ErrorStatistics()
        self.rate_limiter: RateLimiter = RateLimiter(
            capacity=config.capacity,
            refill_rate=config.refill_rate,
            model_id=model_id,
            max_concurrent=config.max_concurrent,
            daily_quota=config.daily_quota,
            sliding_window_size=config.sliding_window_size,
        )
        self._lock: threading.Lock = threading.Lock()

    def update_health_score(self, fail_rate: float, delay: float) -> None:
        with self._lock:
            self.health_score = HealthScoreCalculator().calculate(fail_rate, delay)

    def record_error(self, error_type: str) -> None:
        with self._lock:
            self.error_statistics.record_error(error_type)

    def can_acquire(self) -> bool:
        with self._lock:
            return self.rate_limiter.acquire()

    def release(self) -> None:
        with self._lock:
            self.rate_limiter.release()

    def get_health_score(self) -> float:
        """获取当前健康评分，线程安全。"""
        with self._lock:
            return self.health_score

    def get_error_distribution(self) -> Dict[str, int]:
        with self._lock:
            return self.error_statistics.get_error_distribution()

    def reset_error(self) -> None:
        """重置错误统计周期，清空所有计数。"""
        with self._lock:
            self.error_statistics.reset()
