"""指标计数器模块：提供线程安全的实时统计与时间窗口回溯能力。"""

import logging
import math
from bisect import bisect_left
from collections import deque
from threading import Lock
from typing import Any, Deque, Dict, List, Optional, Tuple

# 配置日志记录器
logger = logging.getLogger(__name__)


class MetricCounter:
    """
    线程安全的指标计数器，支持实时统计与时间窗口回溯。

    该类维护两个主要队列：历史数据队列和时间戳队列，
    通过锁机制保证多线程环境下的安全性。
    支持累计统计和指定时间窗口内的统计模式。
    """

    def __init__(
        self,
        name: str,
        history_maxlen: int = 10000,
        timestamp_maxlen: Optional[int] = None,
    ) -> None:
        """
        初始化指标计数器。

        :param name: 计数器名称
        :param history_maxlen: 历史队列最大长度，必须为正整数
        :param timestamp_maxlen: 时间戳队列最大长度，默认为history_maxlen
        :raises ValueError: 当history_maxlen非正整数时抛出
        """
        if history_maxlen <= 0:
            raise ValueError("history_maxlen must be a positive integer")

        self._name = name
        self._lock = Lock()

        # 累计统计变量
        self._value: float = 0.0
        self._count: int = 0
        self._sum: float = 0.0
        self._min: float = math.inf
        self._max: float = -math.inf

        # 双队列：历史数据和对应时间戳
        ts_maxlen = timestamp_maxlen if timestamp_maxlen is not None else history_maxlen
        if ts_maxlen <= 0:
            raise ValueError("timestamp_maxlen must be a positive integer or None")

        self._history: Deque[Tuple[float, float]] = deque(maxlen=history_maxlen)
        self._timestamps: Deque[float] = deque(maxlen=ts_maxlen)

        # 预计算时间戳索引数组，用于优化窗口查找
        self._timestamp_index: List[float] = []

        logger.debug(
            "Initialized MetricCounter '%s' with history_maxlen=%d, timestamp_maxlen=%d",
            name,
            history_maxlen,
            ts_maxlen,
        )

    def record(self, value: float, timestamp: float) -> None:
        """
        记录单个指标值及其时间戳，并更新基础统计。

        :param value: 指标值
        :param timestamp: 时间戳（单调递增）
        :raises ValueError: 当时间戳非单调递增时抛出
        """
        with self._lock:
            # 检查时间戳单调性
            if self._timestamps and timestamp <= self._timestamps[-1]:
                logger.error(
                    "Invalid timestamp sequence in '%s': new_ts=%.6f <= last_ts=%.6f",
                    self._name,
                    timestamp,
                    self._timestamps[-1],
                )
                raise ValueError(
                    f"Timestamps must be strictly increasing (new={timestamp}, last={self._timestamps[-1]})"
                )

            # 更新累计统计
            self._value += value
            self._count += 1
            self._sum += value
            self._min = min(self._min, value)
            self._max = max(self._max, value)

            # 添加历史记录
            self._history.append((timestamp, value))
            self._timestamps.append(timestamp)
            self._timestamp_index.append(timestamp)

            # 一致性校验：由于使用不同maxlen，可能会不一致，强制同步
            self._synchronize_queues()

    def _synchronize_queues(self) -> None:
        """
        强制同步队列长度，确保历史队列和时间戳队列长度一致。
        当队列长度不一致时，从较短队列的尾部删除多余元素。

        注意：此方法必须在持有锁的情况下调用。
        """
        hist_len = len(self._history)
        ts_len = len(self._timestamps)
        idx_len = len(self._timestamp_index)

        if hist_len != ts_len or hist_len != idx_len:
            logger.warning(
                "Queue length drift detected in '%s': history=%d, timestamps=%d, index=%d. Synchronizing...",
                self._name,
                hist_len,
                ts_len,
                idx_len,
            )

            # 确定目标长度（取最小值，保留最旧的数据）
            target_len = min(hist_len, ts_len, idx_len)

            # 从历史队列尾部删除多余元素
            while len(self._history) > target_len:
                self._history.pop()

            # 从时间戳队列尾部删除多余元素
            while len(self._timestamps) > target_len:
                self._timestamps.pop()

            # 从时间戳索引尾部删除多余元素
            while len(self._timestamp_index) > target_len:
                self._timestamp_index.pop()

            logger.info(
                "Queues synchronized for '%s': history=%d, timestamps=%d, index=%d",
                self._name,
                len(self._history),
                len(self._timestamps),
                len(self._timestamp_index),
            )

    def get(self, window_size: Optional[float] = None) -> Dict[str, Any]:
        """
        获取统计结果，支持窗口内或累计模式。

        :param window_size: 窗口大小（秒），为None时返回累计统计；
                            必须为正数，否则抛出ValueError
        :return: 统计结果字典
        :raises ValueError: 当window_size非正数时抛出
        """
        with self._lock:
            if window_size is None:
                return self._get_cumulative_stats()

            if window_size <= 0:
                raise ValueError("window_size must be a positive number")

            return self._get_window_stats(window_size)

    def _get_cumulative_stats(self) -> Dict[str, Any]:
        """
        获取累计统计指标。

        :return: 包含value, count, sum, min, max的字典
        """
        return {
            "value": self._value,
            "count": self._count,
            "sum": self._sum,
            "min": self._min if self._count > 0 else None,
            "max": self._max if self._count > 0 else None,
        }

    def _get_window_stats(self, window_size: float) -> Dict[str, Any]:
        """
        获取指定时间窗口内的统计指标。

        :param window_size: 时间窗口大小（秒），必须为正数
        :return: 包含count, sum, min, max的字典
        """
        if window_size <= 0:
            raise ValueError("window_size must be a positive number")

        if not self._timestamps:
            logger.debug("No data available for window calculation in '%s'", self._name)
            return {"count": 0, "sum": 0.0, "min": None, "max": None}

        # 验证队列一致性
        if len(self._history) != len(self._timestamps):
            raise ValueError(
                f"Queue length mismatch in '{self._name}': history={len(self._history)}, "
                f"timestamps={len(self._timestamps)}. Call _synchronize_queues() first."
            )

        current_time = self._timestamps[-1]
        cutoff = current_time - window_size

        # 使用预计算的时间戳索引数组进行二分查找
        if self._timestamp_index:
            idx = bisect_left(self._timestamp_index, cutoff)
        else:
            idx = bisect_left(list(self._timestamps), cutoff)

        # 提取窗口内的数据
        window_values = [h[1] for h in list(self._history)[idx:]]

        if not window_values:
            logger.debug(
                "Window stats for '%s' (size=%.2f) resulted in no data", self._name, window_size
            )
            return {"count": 0, "sum": 0.0, "min": None, "max": None}

        return {
            "count": len(window_values),
            "sum": sum(window_values),
            "min": min(window_values),
            "max": max(window_values),
        }

    def reset(self) -> None:
        """重置所有累计指标和历史记录。"""
        with self._lock:
            self._value = 0.0
            self._count = 0
            self._sum = 0.0
            self._min = math.inf
            self._max = -math.inf
            self._history.clear()
            self._timestamps.clear()
            self._timestamp_index.clear()
            logger.info("MetricCounter '%s' has been reset", self._name)

    @property
    def name(self) -> str:
        """获取计数器名称。"""
        return self._name

    def __repr__(self) -> str:
        """返回计数器的字符串表示。"""
        return f"MetricCounter(name={self._name!r}, count={self._count})"
