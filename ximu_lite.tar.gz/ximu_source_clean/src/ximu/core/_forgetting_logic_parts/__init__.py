"""Split parts of forgetting_logic."""

__version__ = "0.5"
