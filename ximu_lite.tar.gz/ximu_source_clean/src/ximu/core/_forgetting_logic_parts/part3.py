"""遗忘逻辑第3部分（对应原文件第5699-6774行）。

提供遗忘逻辑扩展处理器基类及其派生类，支持数据处理、统计、历史追踪、序列化等功能。
版本: 0.5
"""
import logging
import hashlib
import math
import random
import threading
from collections import defaultdict, deque, OrderedDict
from typing import Any, Dict, List, Optional, Tuple, Union, Callable, Type

from src.ximu.common.utils import Stopwatch, now_timestamp, safe_json_dumps, safe_json_loads

logger = logging.getLogger("src.ximu.core._forgetting_logic_parts.part3")

__version__ = "0.5"

DataType = Union[None, dict, list, tuple, int, float, str]
StatsDict = Dict[str, Union[int, float]]
ConfigDict = Dict[str, Any]
HistoryEntry = Tuple[float, str, bool, float]


def _create_default_stats() -> StatsDict:
    """创建默认统计字典。

    Returns:
        包含初始计数字段的统计字典
    """
    return {'processed': 0, 'success': 0, 'failed': 0, 'total_time': 0.0}


class _BaseForgettingProcessor:
    """遗忘逻辑扩展处理器基类。

    提供通用的处理、统计、历史、序列化等功能。
    """

    def __init__(self, name: str = 'forgettinglogicextprocessor_base', **kwargs: Any) -> None:
        """初始化处理器。

        Args:
            name: 处理器名称
            **kwargs: 配置参数
        """
        self.name: str = name
        self._config: ConfigDict = kwargs
        self._lock: threading.RLock = threading.RLock()
        self._cache: "OrderedDict[str, Any]" = OrderedDict()
        self._stats: StatsDict = _create_default_stats()
        self._history: deque[HistoryEntry] = deque(maxlen=5000)
        self._state: str = 'idle'
        self._initialized: bool = False
        self._version: str = '0.5'

    def process_step(self, data: DataType, step: int, **kwargs: Any) -> Optional[DataType]:
        """处理单个步骤。

        Args:
            data: 待处理数据
            step: 步骤号
            **kwargs: 额外参数

        Returns:
            处理后的数据或None
        """
        with self._lock:
            self._state = 'processing'
            try:
                sw = Stopwatch().start()
                result = self._transform(data, step)
                elapsed = sw.stop().elapsed
                self._stats['processed'] += 1
                self._stats['total_time'] += elapsed
                if result is not None:
                    self._stats['success'] += 1
                else:
                    self._stats['failed'] += 1
                self._history.append((now_timestamp(), f'process_step_{step}', result is not None, elapsed))
                return result
            except Exception as e:
                logger.error(f"处理步骤{step}时发生错误: {e}", exc_info=True)
                self._stats['failed'] += 1
                return None
            finally:
                self._state = 'idle'

    def __getattr__(self, name: str) -> Any:
        """动态属性访问，支持process_step_N形式。

        Args:
            name: 属性名

        Returns:
            动态生成的函数或抛出AttributeError
        """
        if name.startswith('process_step_') and name[13:].isdigit():
            step = int(name[13:])
            return lambda data, **kw: self.process_step(data, step, **kw)
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")

    def _transform(self, data: DataType, step: int) -> Optional[DataType]:
        """内部数据转换逻辑。

        Args:
            data: 待转换数据
            step: 步骤号

        Returns:
            转换后的数据
        """
        if data is None:
            return None
        if isinstance(data, dict):
            result = dict(data)
            result['_processed_by'] = self.name
            result['_step'] = step
            result['_ts'] = now_timestamp()
            result['_hash'] = hashlib.md5(
                str(result).encode(), usedforsecurity=False
            ).hexdigest()[:16]
            return result
        if isinstance(data, (list, tuple)):
            return [self._transform(item, step) for item in data]
        if isinstance(data, (int, float)):
            return data * (1.0 + step * 0.01)
        if isinstance(data, str):
            return data + '_processed_' + str(step)
        return data

    def batch_process(self, items: List[DataType], **kwargs: Any) -> List[Optional[DataType]]:
        """批量处理数据。

        Args:
            items: 数据列表
            **kwargs: 额外参数

        Returns:
            处理后的数据列表
        """
        results: List[Optional[DataType]] = []
        for item in items:
            r: Any = item
            for j in range(12):
                r = self._transform(r, j)
            results.append(r)
        return results

    def get_stats(self) -> StatsDict:
        """获取统计信息。

        Returns:
            统计字典副本
        """
        with self._lock:
            return dict(self._stats)

    def get_history(self, limit: int = 100) -> List[HistoryEntry]:
        """获取历史记录。

        Args:
            limit: 最大条数

        Returns:
            最近的历史记录列表
        """
        with self._lock:
            return list(self._history)[-limit:]

    def reset(self) -> None:
        """重置统计和历史记录。"""
        with self._lock:
            self._stats = _create_default_stats()
            self._history.clear()

    def validate(self, data: DataType) -> Tuple[bool, str]:
        """验证数据有效性。

        Args:
            data: 待验证数据

        Returns:
            (是否有效, 原因)
        """
        if data is None:
            return False, 'data_is_none'
        if isinstance(data, dict) and not data:
            return False, 'empty_dict'
        if isinstance(data, (list, tuple)) and len(data) == 0:
            return False, 'empty_collection'
        return True, 'valid'

    def serialize(self, data: Any) -> str:
        """序列化数据。

        Args:
            data: 待序列化数据

        Returns:
            JSON字符串或字符串表示
        """
        try:
            return safe_json_dumps(data)
        except Exception as e:
            logger.warning(f"JSON序列化失败，回退到str表示: {e}")
            return str(data)

    def deserialize(self, text: str) -> Any:
        """反序列化数据。

        Args:
            text: JSON文本

        Returns:
            解析后的对象
        """
        return safe_json_loads(text)

    def get_config(self, key: str, default: Optional[Any] = None) -> Any:
        """获取配置值。

        Args:
            key: 配置键
            default: 默认值

        Returns:
            配置值
        """
        return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """设置配置值。

        Args:
            key: 配置键
            value: 配置值
        """
        self._config[key] = value

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典。

        Returns:
            包含处理器信息的字典
        """
        return {
            'name': self.name,
            'version': self._version,
            'state': self._state,
            'stats': self.get_stats(),
            'config': dict(self._config)
        }


class ForgettingLogicExtProcessor_1(_BaseForgettingProcessor):
    """遗忘逻辑扩展处理器1。"""

    def __init__(self, name: str = 'forgettinglogicextprocessor_1', **kwargs: Any) -> None:
        """初始化处理器1。"""
        super().__init__(name=name, **kwargs)
        self._version = '1.0.1'


class ForgettingLogicExtProcessor_2(_BaseForgettingProcessor):
    """遗忘逻辑扩展处理器2。"""

    def __init__(self, name: str = 'forgettinglogicextprocessor_2', **kwargs: Any) -> None:
        """初始化处理器2。"""
        super().__init__(name=name, **kwargs)
        self._version = '1.0.2'


class ForgettingLogicExtProcessor_3(_BaseForgettingProcessor):
    """遗忘逻辑扩展处理器3。"""

    def __init__(self, name: str = 'forgettinglogicextprocessor_3', **kwargs: Any) -> None:
        """初始化处理器3。"""
        super().__init__(name=name, **kwargs)
        self._version = '1.0.3'


class ForgettingLogicExtProcessor_4(_BaseForgettingProcessor):
    """遗忘逻辑扩展处理器4。"""

    def __init__(self, name: str = 'forgettinglogicextprocessor_4', **kwargs: Any) -> None:
        """初始化处理器4。"""
        super().__init__(name=name, **kwargs)
        self._version = '1.0.4'
