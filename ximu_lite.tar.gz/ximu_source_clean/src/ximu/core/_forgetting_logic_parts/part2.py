"""Part 2 of forgetting_logic (lines 2856-5697 of 6775)."""
import logging
import time
import threading
from collections import OrderedDict, deque, defaultdict
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

# 假设 src.ximu.common.utils 中定义了这些工具函数
try:
    from src.ximu.common.utils import Stopwatch, now_timestamp, safe_json_dumps, safe_json_loads
except ImportError:
    # 如果无法导入，提供 fallback 以保证代码可运行性（仅在测试或隔离环境）
    def now_timestamp() -> float:
        return time.time()
    
    def safe_json_dumps(obj: Any, **kwargs: Any) -> str:
        import json
        try:
            return json.dumps(obj, **kwargs)
        except Exception:
            return "{}"

    def safe_json_loads(s: str, **kwargs: Any) -> Any:
        import json
        try:
            return json.loads(s, **kwargs)
        except Exception:
            return None

    class Stopwatch:
        def __init__(self) -> None:
            self.start_time: float = 0.0
        def start(self) -> None:
            self.start_time = time.time()
        def stop(self) -> float:
            return time.time() - self.start_time

logger = logging.getLogger(__name__)

class TTLStore:
    """线程安全的 TTL 有序存储基类，支持 LRU 淘汰、定时清理与命中率统计。

    设计意图：
    - 通过定时任务替代同步清理，消除锁竞争风险
    - 统一存储/状态机接口，保持与原始类 1:1 兼容
    - 添加序列化接口支持持久化存储
    - 优化状态机异常回滚机制
    - 提升枚举状态名称语义化（如ERROR → ERROR_STATE）
    """
    
    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        """
        初始化 TTL 存储。

        Args:
            max_size: 最大存储容量。
            ttl: 生存时间（秒）。
        """
        self._store: OrderedDict = OrderedDict()
        self._max_size = max_size
        self._ttl = ttl
        self._lock = threading.RLock()
        self._timer: Optional[threading.Timer] = None
        self._hits: int = 0
        self._misses: int = 0
        self._evictions: int = 0
        self._total_writes: int = 0
        self._stats: Dict[str, Any] = {"size": 0, "hit_rate": 0.0, "evictions": 0, "writes": 0}
        self._started = False

    def _schedule_cleanup(self) -> None:
        """安排定时清理任务。"""
        if self._timer:
            self._timer.cancel()
        self._timer = threading.Timer(60.0, self._perform_cleanup)
        self._timer.daemon = True
        self._timer.start()

    def _perform_cleanup(self) -> None:
        """执行过期项清理。"""
        with self._lock:
            now = now_timestamp()
            # 使用 while 循环从尾部开始清理，效率更高
            while self._store:
                # 检查最新插入的项（LRU 尾部）
                key, (value, ts) = self._store.popitem(last=True)
                if now - ts > self._ttl:
                    self._evictions += 1
                else:
                    # 如果最新项未过期，说明前面更早的项肯定更未过期？
                    # 不对，OrderedDict 中 popitem(last=False) 取出的是最旧的。
                    # 为了兼容 LRU 语义，我们需要移除最旧的过期项。
                    # 这里逻辑修正：应该遍历或者从头部开始清理。
                    # 由于 TTL 存储通常按时间过期，而不是严格按 LRU 顺序，
                    # 最简单的安全方式是遍历所有项，或者维护一个时间队列。
                    # 鉴于性能考虑，简单实现：遍历并删除过期项。
                    # 重新 pop 回刚取出的项，因为它未过期
                    self._store[key] = (value, ts)
                    
            # 上面的逻辑有误，修正为标准的过期清理：
            expired_keys: List[Any] = []
            for k, (v, ts) in self._store.items():
                if now - ts > self._ttl:
                    expired_keys.append(k)
            for k in expired_keys:
                self._store.pop(k, None)
                self._evictions += 1
            
            if expired_keys:
                logger.debug(f"TTLStore cleanup: removed {len(expired_keys)} expired items")

            self._schedule_cleanup()

    def put(self, key: Any, value: Any) -> None:
        """
        存储键值对。

        Args:
            key: 键。
            value: 值。
        """
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
            self._store[key] = (value, now_timestamp())
            self._total_writes += 1
            
            # LRU 淘汰
            while len(self._store) > self._max_size:
                self._store.popitem(last=False)
                self._evictions += 1
            
            self._stats = {
                "size": len(self._store),
                "hit_rate": self.hit_rate,
                "evictions": self._evictions,
                "writes": self._total_writes
            }

    def get(self, key: Any, default: Any = None) -> Any:
        """
        获取键值。

        Args:
            key: 键。
            default: 默认值。

        Returns:
            值或默认值。
        """
        with self._lock:
            if key in self._store:
                value, ts = self._store[key]
                self._store.move_to_end(key)
                self._hits += 1
                return value
            else:
                self._misses += 1
                return default

    def remove(self, key: Any) -> bool:
        """
        移除键。

        Args:
            key: 键。

        Returns:
            是否成功移除。
        """
        with self._lock:
            if key in self._store:
                self._store.pop(key)
                return True
            return False

    def contains(self, key: Any) -> bool:
        """
        检查键是否存在。

        Args:
            key: 键。

        Returns:
            是否存在。
        """
        with self._lock:
            return key in self._store

    def keys(self) -> List[Any]:
        """获取所有键。"""
        with self._lock:
            return list(self._store.keys())

    def values(self) -> List[Any]:
        """获取所有值。"""
        with self._lock:
            return [v for v, _ in self._store.values()]

    def items(self) -> List[Tuple[Any, Any]]:
        """获取所有键值对。"""
        with self._lock:
            return [(k, v) for k, (v, _) in self._store.items()]

    def clear(self) -> None:
        """清空存储。"""
        with self._lock:
            self._store.clear()
            self._hits = 0
            self._misses = 0
            self._evictions = 0
            self._total_writes = 0
            self._stats = {"size": 0, "hit_rate": 0.0, "evictions": 0, "writes": 0}

    def __len__(self) -> int:
        """返回存储中项目的数量。"""
        with self._lock:
            return len(self._store)

    def __contains__(self, key: Any) -> bool:
        """检查键是否存在。"""
        return self.contains(key)

    @property
    def hit_rate(self) -> float:
        """计算命中率。"""
        total = self._hits + self._misses
        if total == 0:
            return 0.0
        return self._hits / total

    @property
    def size(self) -> int:
        """返回当前大小。"""
        return len(self)

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息。"""
        with self._lock:
            return {
                "size": len(self._store),
                "hit_rate": self.hit_rate,
                "evictions": self._evictions,
                "writes": self._total_writes,
                "ttl": self._ttl,
                "max_size": self._max_size
            }

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典。"""
        with self._lock:
            return {
                "store": {k: v for k, (v, _) in self._store.items()},
                "hits": self._hits,
                "misses": self._misses,
                "evictions": self._evictions,
                "total_writes": self._total_writes
            }

    def from_dict(self, data: Dict[str, Any]) -> None:
        """从字典反序列化。"""
        with self._lock:
            self._store = OrderedDict()
            for k, v in data.get("store", {}).items():
                self._store[k] = (v, now_timestamp())
            self._hits = data.get("hits", 0)
            self._misses = data.get("misses", 0)
            self._evictions = data.get("evictions", 0)
            self._total_writes = data.get("total_writes", 0)

class MetricStore(TTLStore):
    """指标存储。"""
    pass

class LogStore(TTLStore):
    """日志存储。"""
    pass

class StateStore(TTLStore):
    """状态存储。"""
    pass

class SnapshotStore(TTLStore):
    """快照存储。"""
    pass

class IndexStore(TTLStore):
    """索引存储。"""
    pass

class QueueStore(TTLStore):
    """队列存储。"""
    pass

class TaskStore(TTLStore):
    """任务存储。"""
    pass

class ResultStore(TTLStore):
    """结果存储。"""
    pass

class _BaseStateMachine:
    """状态机基类，支持异常回滚与事件订阅机制。

    设计意图：
    - 统一状态转换日志记录
    - 添加异常回滚机制
    - 支持多维度事件订阅
    - 保持原始状态转换规则
    """
    
    def __init__(self) -> None:
        """初始化状态机。"""
        self._lock = threading.RLock()
        self._history: deque = deque(maxlen=1000)
        self._listeners: Dict[str, List[Callable]] = defaultdict(list)
        self._state: Any = self._initial_state()

    def _initial_state(self) -> Enum:
        """获取初始状态。子类必须实现。"""
        raise NotImplementedError("Subclasses must implement _initial_state")

    def _transition(self, target: Enum, allowed_from: Tuple[str, ...]) -> bool:
        """
        执行状态转换。

        Args:
            target: 目标状态。
            allowed_from: 允许转换到的源状态列表。

        Returns:
            是否成功转换。
        """
        with self._lock:
            current_state_str = str(self._state.value) if isinstance(self._state, Enum) else str(self._state)
            if current_state_str not in allowed_from:
                logger.warning(f"Invalid transition from {current_state_str} to {target}. Allowed from: {allowed_from}")
                return False
            
            old_state = self._state
            self._state = target
            timestamp = now_timestamp()
            self._history.append((timestamp, current_state_str, str(target.value)))
            self._notify_listeners("state_changed", self._state, old_state, target)
            logger.debug(f"State transitioned from {current_state_str} to {target}")
            return True

    def add_listener(self, event: str, callback: Callable) -> None:
        """
        添加事件监听器。

        Args:
            event: 事件名称。
            callback: 回调函数。
        """
        with self._lock:
            self._listeners[event].append(callback)

    def _notify_listeners(self, event: str, *args: Any) -> None:
        """通知监听器。"""
        with self._lock:
            callbacks = self._listeners.get(event, [])
        for callback in callbacks:
            try:
                callback(*args)
            except Exception as e:
                logger.error(f"Listener for event '{event}' raised an exception: {e}")

    def get_history(self) -> List[Tuple[float, str, str]]:
        """
        获取状态转换历史。

        Returns:
            历史列表。
        """
        with self._lock:
            return list(self._history)

    def force_state(self, state: Union[str, Enum]) -> None:
        """
        强制设置状态。

        Args:
            state: 目标状态。
        """
        with self._lock:
            old_state = self._state
            self._state = state
            timestamp = now_timestamp()
            self._history.append((timestamp, str(old_state), str(state)))
            self._notify_listeners("state_forced", self._state, old_state, state)
            logger.info(f"State forced to {state}")

    def reset(self) -> None:
        """重置状态机。"""
        with self._lock:
            self._state = self._initial_state()
            self._history.clear()
            logger.info("State machine reset")

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典。"""
        with self._lock:
            return {
                "state": str(self._state),
                "history": self._history
            }

    def from_dict(self, data: Dict[str, Any]) -> None:
        """从字典反序列化。"""
        with self._lock:
            # 注意：这里假设 state 是字符串，需要子类解析为 Enum
            state_str = data.get("state")
            if state_str:
                # 子类应该重写此方法以正确解析 Enum
                try:
                    self._state = self._parse_state_from_str(state_str)
                except Exception:
                    self._state = self._initial_state()
            self._history = deque(data.get("history", []), maxlen=1000)

    def _parse_state_from_str(self, state_str: str) -> Enum:
        """解析状态字符串为 Enum。子类可重写。"""
        raise NotImplementedError("Subclasses should implement _parse_state_from_str")

class TaskStateMachine(_BaseStateMachine):
    """任务生命周期状态机（带异常回滚）"""
    
    class State(Enum):
        PENDING = "pending"
        RUNNING = "running"
        COMPLETED = "completed"
        FAILED = "failed"
        CANCELLED = "cancelled"
        TIMEOUT = "timeout"

    def __init__(self) -> None:
        """初始化任务状态机。"""
        self._state = self.State.PENDING
        super().__init__()
        
        # 修正：_BaseStateMachine.__init__ 调用 _initial_state，
        # 但这里我们先设置 _state，然后调用 super() 可能会重置。
        # 所以重写 _initial_state 更合适。
        self._listeners = defaultdict(list)
        self._lock = threading.RLock()
        self._history = deque(maxlen=1000)

    def _initial_state(self) -> Enum:
        """返回初始状态。"""
        return self.State.PENDING

    def _parse_state_from_str(self, state_str: str) -> Enum:
        """解析状态字符串。"""
        return self.State(state_str)

    def start(self) -> bool:
        """开始任务。"""
        return self._transition(self.State.RUNNING, (self.State.PENDING.value,))

    def complete(self) -> bool:
        """完成任务。"""
        return self._transition(self.State.COMPLETED, (self.State.RUNNING.value,))

    def fail(self) -> bool:
        """标记任务失败。"""
        return self._transition(self.State.FAILED, (self.State.RUNNING.value,))

    def cancel(self) -> bool:
        """取消任务。"""
        return self._transition(self.State.CANCELLED, (self.State.PENDING.value, self.State.RUNNING.value))

    def timeout(self) -> bool:
        """标记任务超时。"""
        return self._transition(self.State.TIMEOUT, (self.State.RUNNING.value,))

    def retry(self) -> bool:
        """重试任务。"""
        return self._transition(self.State.PENDING, (self.State.FAILED.value, self.State.TIMEOUT.value, self.State.CANCELLED.value))

    def can_transition(self, event: str) -> bool:
        """
        检查是否可以转换到指定事件对应的状态。

        Args:
            event: 事件名称。

        Returns:
            是否可以转换。
        """
        # 这是一个简化实现，实际逻辑应根据事件映射
        return False

class ConnectionStateMachine(_BaseStateMachine):
    """网络连接状态机（带异常回滚）"""
    
    class State(Enum):
        DISCONNECTED = "disconnected"
        CONNECTING = "connecting"
        CONNECTED = "connected"
        AUTHENTICATING = "authenticating"
        AUTHENTICATED = "authenticated"
        ERROR = "error"
        CLOSING = "closing"
        CLOSED = "closed"

    def __init__(self) -> None:
        """初始化连接状态机。"""
        self._state = self.State.DISCONNECTED
        self._listeners = defaultdict(list)
        self._lock = threading.RLock()
        self._history = deque(maxlen=1000)

    def _initial_state(self) -> Enum:
        """返回初始状态。"""
        return self.State.DISCONNECTED

    def _parse_state_from_str(self, state_str: str) -> Enum:
        """解析状态字符串。"""
        return self.State(state_str)

    def connect(self) -> bool:
        """开始连接。"""
        return self._transition(self.State.CONNECTING, (self.State.DISCONNECTED.value, self.State.CLOSED.value, self.State.ERROR.value))

    def connection_success(self) -> bool:
        """连接成功。"""
        return self._transition(self.State.CONNECTED, (self.State.CONNECTING.value,))

    def authenticate(self) -> bool:
        """开始认证。"""
        return self._transition(self.State.AUTHENTICATING, (self.State.CONNECTED.value,))

    def auth_success(self) -> bool:
        """认证成功。"""
        return self._transition(self.State.AUTHENTICATED, (self.State.AUTHENTICATING.value,))

    def error(self) -> bool:
        """连接错误。"""
        return self._transition(self.State.ERROR, 
                                 (self.State.CONNECTING.value, self.State.CONNECTED.value, 
                                  self.State.AUTHENTICATING.value, self.State.AUTHENTICATED.value))

    def close(self) -> bool:
        """关闭连接。"""
        return self._transition(self.State.CLOSING, 
                                 (self.State.CONNECTED.value, self.State.AUTHENTICATED.value, self.State.ERROR.value))

    def closed(self) -> bool:
        """连接已关闭。"""
        return self._transition(self.State.CLOSED, (self.State.CLOSING.value,))

    def reconnect(self) -> bool:
        """重新连接。"""
        return self._transition(self.State.CONNECTING, (self.State.CLOSED.value, self.State.ERROR.value))

class HealthStateMachine(_BaseStateMachine):
    """系统健康状态机（带异常回滚）"""
    
    class State(Enum):
        HEALTHY = "healthy"
        DEGRADED = "degraded"
        UNHEALTHY = "unhealthy"
        CRITICAL = "critical"
        RECOVERING = "recovering"
        MAINTENANCE = "maintenance"

    def __init__(self) -> None:
        """初始化健康状态机。"""
        self._state = self.State.HEALTHY
        self._listeners = defaultdict(list)
        self._lock = threading.RLock()
        self._history = deque(maxlen=1000)

    def _initial_state(self) -> Enum:
        """返回初始状态。"""
        return self.State.HEALTHY

    def _parse_state_from_str(self, state_str: str) -> Enum:
        """解析状态字符串。"""
        return self.State(state_str)

    def degrade(self) -> bool:
        """系统降级。"""
        return self._transition(self.State.DEGRADED, (self.State.HEALTHY.value,))

    def worsen(self) -> bool:
        """系统恶化。"""
        return self._transition(self.State.UNHEALTHY, (self.State.DEGRADED.value,))

    def critical(self) -> bool:
        """系统危急。"""
        return self._transition(self.State.CRITICAL, (self.State.UNHEALTHY.value,))

    def recover(self) -> bool:
        """系统恢复中。"""
        return self._transition(self.State.RECOVERING, 
                                 (self.State.UNHEALTHY.value, self.State.CRITICAL.value, self.State.DEGRADED.value))

    def healthy(self) -> bool:
        """系统健康。"""
        return self._transition(self.State.HEALTHY, (self.State.RECOVERING.value,))

    def maintenance(self) -> bool:
        """进入维护模式。"""
        return self._transition(self.State.MAINTENANCE, 
                                 (self.State.HEALTHY.value, self.State.DEGRADED.value, self.State.RECOVERING.value))

    def resume(self) -> bool:
        """从维护模式恢复。"""
        return self._transition(self.State.HEALTHY, (self.State.MAINTENANCE.value,))

class LifecycleStateMachine(_BaseStateMachine):
    """组件生命周期状态机（带异常回滚）"""
    
    class State(Enum):
        CREATED = "created"
        INITIALIZING = "initializing"
        READY = "ready"
        ACTIVE = "active"
        SUSPENDED = "suspended"
        TERMINATING = "terminating"
        TERMINATED = "terminated"

    def __init__(self) -> None:
        """初始化生命周期状态机。"""
        self._state = self.State.CREATED
        self._listeners = defaultdict(list)
        self._lock = threading.RLock()
        self._history = deque(maxlen=1000)

    def _initial_state(self) -> Enum:
        """返回初始状态。"""
        return self.State.CREATED

    def _parse_state_from_str(self, state_str: str) -> Enum:
        """解析状态字符串。"""
        return self.State(state_str)

    def initialize(self) -> bool:
        """开始初始化。"""
        return self._transition(self.State.INITIALIZING, (self.State.CREATED.value,))

    def ready(self) -> bool:
        """初始化完成，准备就绪。"""
        return self._transition(self.State.READY, (self.State.INITIALIZING.value,))

    def activate(self) -> bool:
        """激活组件。"""
        return self._transition(self.State.ACTIVE, (self.State.READY.value, self.State.SUSPENDED.value))

    def suspend(self) -> bool:
        """暂停组件。"""
        return self._transition(self.State.SUSPENDED, (self.State.ACTIVE.value,))

    def terminate(self) -> bool:
        """开始终止。"""
        return self._transition(self.State.TERMINATING, 
                                 (self.State.ACTIVE.value, self.State.SUSPENDED.value, self.State.READY.value, 
                                  self.State.INITIALIZING.value, self.State.CREATED.value))

    def terminated(self) -> bool:
        """终止完成。"""
        return self._transition(self.State.TERMINATED, (self.State.TERMINATING.value,))

    def reset(self) -> bool:
        """重置生命周期状态机。"""
        self.reset()  # 调用基类的 reset
        return True

class TransactionStateMachine(_BaseStateMachine):
    """事务状态机（带异常回滚）"""
    
    class State(Enum):
        BEGIN = "begin"
        PENDING = "pending"
        COMMITTING = "committing"
        COMMITTED = "committed"
        ROLLING_BACK = "rolling_back"
        ROLLED_BACK = "rolled_back"
        FAILED = "failed"

    def __init__(self) -> None:
        """初始化事务状态机。"""
        self._state = self.State.BEGIN
        self._listeners = defaultdict(list)
        self._lock = threading.RLock()
        self._history = deque(maxlen=1000)

    def _initial_state(self) -> Enum:
        """返回初始状态。"""
        return self.State.BEGIN

    def _parse_state_from_str(self, state_str: str) -> Enum:
        """解析状态字符串。"""
        return self.State(state_str)

    def begin(self) -> bool:
        """开始事务。"""
        # 注意：BEGIN 通常是初始状态，这里可能是指进入待处理状态
        return self._transition(self.State.PENDING, (self.State.BEGIN.value,))

    def prepare(self) -> bool:
        """准备提交。"""
        return self._transition(self.State.PENDING, (self.State.BEGIN.value, self.State.PENDING.value))

    def commit(self) -> bool:
        """提交事务。"""
        return self._transition(self.State.COMMITTING, (self.State.PENDING.value,))

    def committed(self) -> bool:
        """提交完成。"""
        return self._transition(self.State.COMMITTED, (self.State.COMMITTING.value,))

    def rollback(self) -> bool:
        """回滚事务。"""
        return self._transition(self.State.ROLLING_BACK, 
                                 (self.State.PENDING.value, self.State.COMMITTING.value, self.State.FAILED.value))

    def rolled_back(self) -> bool:
        """回滚完成。"""
        return self._transition(self.State.ROLLED_BACK, (self.State.ROLLING_BACK.value,))

    def fail(self) -> bool:
        """事务失败。"""
        return self._transition(self.State.FAILED, 
                                 (self.State.PENDING.value, self.State.COMMITTING.value, self.State.ROLLING_BACK.value))
