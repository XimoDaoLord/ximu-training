"""
ximu.core._forgetting_logic_parts.part1

核心数据结构和工具函数定义，包括请求上下文、指标统计、负载均衡策略和缓存存储。
"""

import logging
import hashlib
import json
import os
import random
import threading
import time
import uuid
from collections import defaultdict, deque, OrderedDict
from dataclasses import dataclass, field
from enum import Enum
from functools import wraps
from typing import Any, Dict, List, Optional, Callable, TypeVar, Generic

# 日志记录器
logger = logging.getLogger(__name__)

# 配置和密钥管理（保持兼容）
try:
    from config.settings import config
    from config.key_manager import get_key_manager
except ImportError:
    config = {}
    def get_config(key: str, default: Any = None) -> Any:
        """获取配置项，若不存在则返回默认值。"""
        return default
    def get_key_manager() -> Optional[Any]:
        """获取密钥管理器实例，若不可用则返回 None。"""
        return None

# 类型别名
T = TypeVar('T')
K = TypeVar('K')
V = TypeVar('V')

def generate_id(prefix: str = 'id') -> str:
    """
    生成带有前缀的唯一标识符。
    
    Args:
        prefix: 标识符前缀
        
    Returns:
        生成的唯一标识符字符串
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"

def now_timestamp() -> float:
    """
    获取当前时间戳（秒级精度）。
    
    Returns:
        当前时间戳，以秒为单位
    """
    return time.time()

def now_timestamp_ms() -> int:
    """
    获取当前时间戳（毫秒级精度）。
    
    Returns:
        当前时间戳，以毫秒为单位
    """
    return int(time.time() * 1000)

def retry_on_failure(max_retries: int = 3, delay: float = 0.1) -> Callable:
    """
    创建重试装饰器，在失败时进行指数退避重试。
    
    Args:
        max_retries: 最大重试次数
        delay: 初始延迟时间（秒）
        
    Returns:
        装饰器函数
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exception: Optional[Exception] = None
            for i in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if i == max_retries - 1:
                        logger.warning(f"重试失败，已达到最大重试次数 {max_retries}", exc_info=e)
                        raise
                    sleep_time = delay * (2 ** i)
                    logger.debug(f"第 {i + 1} 次重试失败，{sleep_time} 秒后重试")
                    time.sleep(sleep_time)
            # 理论上不会执行到这里，但为了类型检查
            if last_exception:
                raise last_exception
            return None
        return wrapper
    return decorator

def safe_json_dumps(obj: Any, **kwargs: Any) -> str:
    """
    安全地将对象序列化为 JSON 字符串，处理不可序列化的类型。
    
    Args:
        obj: 要序列化的对象
        **kwargs: 传递给 json.dumps 的其他参数
        
    Returns:
        JSON 字符串
    """
    return json.dumps(obj, ensure_ascii=False, default=str, **kwargs)

def safe_json_loads(s: str, **kwargs: Any) -> Optional[Any]:
    """
    安全地解析 JSON 字符串，解析失败时返回 None。
    
    Args:
        s: JSON 字符串
        **kwargs: 传递给 json.loads 的其他参数
        
    Returns:
        解析后的 Python 对象，或解析失败时返回 None
    """
    try:
        return json.loads(s, **kwargs)
    except (json.JSONDecodeError, TypeError) as e:
        logger.debug(f"JSON 解析失败: {e}")
        return None

# 枚举类定义
class StatusType(Enum):
    """请求状态类型枚举。"""
    STATUS_A = 'statustype_a'
    STATUS_B = 'statustype_b'
    PENDING = 'pending'
    PROCESSING = 'processing'
    COMPLETED = 'completed'
    FAILED = 'failed'
    CANCELLED = 'cancelled'

class PriorityLevel(Enum):
    """优先级级别枚举。"""
    LOW = 'prioritylevel_low'
    MEDIUM = 'prioritylevel_medium'
    HIGH = 'prioritylevel_high'
    CRITICAL = 'prioritylevel_critical'

# 数据类定义
@dataclass
class RequestContext:
    """
    请求上下文，封装单次请求的完整状态信息。
    
    Attributes:
        id_: 请求唯一标识符
        timestamp: 时间戳
        data: 请求数据
        metadata: 元数据
        status: 当前状态
        priority: 优先级（数值越大优先级越高）
        retry_count: 已重试次数
        max_retries: 最大重试次数
        timeout_ms: 超时时间（毫秒）
        created_at: 创建时间戳
        updated_at: 更新时间戳
        version: 版本标识
        tags: 标签列表
        extra: 额外扩展字段
    """
    id_: str = ''
    timestamp: float = 0.0
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    status: str = 'pending'
    priority: int = 1
    retry_count: int = 0
    max_retries: int = 3
    timeout_ms: int = 30000
    created_at: float = field(default_factory=now_timestamp)
    updated_at: float = field(default_factory=now_timestamp)
    version: str = '1.0.0'
    tags: List[str] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)

# 指标统计基类
class BaseMetrics:
    """
    指标统计基类，提供通用的指标记录与查询功能。
    
    子类应实现特定的指标收集逻辑。
    """
    
    def __init__(self, name: str = ''):
        """
        初始化指标统计器。
        
        Args:
            name: 指标名称
        """
        self.name = name
        self._lock = threading.RLock()
        self._data: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=10000)
        self._window: float = 60.0
        self._last_reset: float = now_timestamp()
        self._total: float = 0.0
        self._count: int = 0
    
    def record(self, value: float, timestamp: Optional[float] = None) -> None:
        """
        记录一个指标值。
        
        Args:
            value: 指标数值
            timestamp: 时间戳，默认使用当前时间
        """
        ts = timestamp if timestamp is not None else now_timestamp()
        with self._lock:
            self._data['sum'] += value
            self._data['count'] += 1
            self._history.append((ts, value))
            self._total += value
            self._count += 1
            # 清理过期的历史记录
            if ts - self._window > self._last_reset:
                self._last_reset = ts
    
    def get_average(self) -> float:
        """
        获取当前窗口内的平均值。
        
        Returns:
            平均值，无数据时返回 0.0
        """
        with self._lock:
            if self._data['count'] == 0:
                return 0.0
            return self._data['sum'] / self._data['count']
    
    def get_total(self) -> float:
        """
        获取累计总和。
        
        Returns:
            累计总和
        """
        with self._lock:
            return self._total
    
    def get_count(self) -> int:
        """
        获取样本数量。
        
        Returns:
            样本数量
        """
        with self._lock:
            return int(self._data['count'])
    
    def reset(self) -> None:
        """重置所有指标统计值。"""
        with self._lock:
            self._data.clear()
            self._history.clear()
            self._total = 0.0
            self._count = 0
            self._last_reset = now_timestamp()
            logger.debug(f"指标 {self.name} 已重置")

class RequestMetrics(BaseMetrics):
    """
    请求指标统计，专门用于跟踪请求相关的性能数据。
    
    继承自 BaseMetrics，提供请求特定的指标收集方法。
    """
    
    def __init__(self, name: str = 'request_metrics'):
        """
        初始化请求指标统计器。
        
        Args:
            name: 指标名称
        """
        super().__init__(name)
        self._min_latency: float = 0.0
        self._max_latency: float = 0.0
        self._success_count: int = 0
        self._failure_count: int = 0
    
    def record_success(self, latency: float, timestamp: Optional[float] = None) -> None:
        """
        记录成功的请求。
        
        Args:
            latency: 请求延迟（秒）
            timestamp: 时间戳
        """
        with self._lock:
            self._success_count += 1
        self.record(latency, timestamp)
    
    def record_failure(self, latency: float, timestamp: Optional[float] = None) -> None:
        """
        记录失败的请求。
        
        Args:
            latency: 请求延迟（秒）
            timestamp: 时间戳
        """
        with self._lock:
            self._failure_count += 1
        self.record(latency, timestamp)
    
    def get_success_rate(self) -> float:
        """
        获取成功率。
        
        Returns:
            成功率（0.0-1.0），无请求时返回 1.0
        """
        with self._lock:
            total = self._success_count + self._failure_count
            if total == 0:
                return 1.0
            return self._success_count / total
    
    def get_min_latency(self) -> float:
        """获取最小延迟值。"""
        return self._min_latency
    
    def get_max_latency(self) -> float:
        """获取最大延迟值。"""
        return self._max_latency

class LatencyMetrics(BaseMetrics):
    """
    延迟指标统计，专门用于跟踪响应时间等延迟相关数据。
    
    继承自 BaseMetrics，提供延迟特定的统计方法。
    """
    
    def __init__(self, name: str = 'latency_metrics'):
        """
        初始化延迟指标统计器。
        
        Args:
            name: 指标名称
        """
        super().__init__(name)
        self._min: float = float('inf')
        self._max: float = 0.0
        self._sum_sq: float = 0.0  # 用于计算方差
    
    def record(self, value: float, timestamp: Optional[float] = None) -> None:
        """
        记录一个延迟值，同时更新最小值和最大值。
        
        Args:
            value: 延迟值（秒）
            timestamp: 时间戳
        """
        with self._lock:
            self._min = min(self._min, value) if self._min != float('inf') else value
            self._max = max(self._max, value)
            self._sum_sq += value * value
        super().record(value, timestamp)
    
    def get_min(self) -> float:
        """
        获取最小延迟值。
        
        Returns:
            最小延迟，无数据时返回 0.0
        """
        with self._lock:
            return self._min if self._min != float('inf') else 0.0
    
    def get_max(self) -> float:
        """
        获取最大延迟值。
        
        Returns:
            最大延迟
        """
        with self._lock:
            return self._max
    
    def get_std_dev(self) -> float:
        """
        计算标准差。
        
        Returns:
            标准差，样本数不足时返回 0.0
        """
        with self._lock:
            count = self.get_count()
            if count <= 1:
                return 0.0
            mean = self.get_average()
            variance = self._sum_sq / count - mean * mean
            if variance < 0:
                variance = 0.0
            return variance ** 0.5

# 负载均衡策略
class LoadBalancingStrategy(Generic[T]):
    """
    负载均衡策略基类。
    
    定义了负载均衡策略的接口规范。
    """
    
    def __init__(self, **kwargs: Any):
        """
        初始化策略。
        
        Args:
            **kwargs: 策略参数
        """
        self.strategy_name: str = 'base'
        self._params: Dict[str, Any] = kwargs
        self._call_count: int = 0
        self._success_count: int = 0
        self._lock = threading.Lock()
    
    def calculate(self, candidates: List[T], context: Optional[RequestContext] = None) -> Optional[T]:
        """
        从候选列表中选择一个目标。
        
        Args:
            candidates: 候选目标列表
            context: 请求上下文
            
        Returns:
            选中的目标，无候选时返回 None
        """
        raise NotImplementedError
    
    def mark_success(self) -> None:
        """标记一次成功选择。"""
        with self._lock:
            self._call_count += 1
            self._success_count += 1
    
    def mark_failure(self) -> None:
        """标记一次失败选择。"""
        with self._lock:
            self._call_count += 1
    
    def get_success_rate(self) -> float:
        """
        获取策略成功率。
        
        Returns:
            成功率（0.0-1.0）
        """
        with self._lock:
            if self._call_count == 0:
                return 1.0
            return self._success_count / self._call_count

class RoundRobinStrategy(LoadBalancingStrategy):
    """
    轮询负载均衡策略。
    
    按顺序依次选择候选目标，实现简单的轮询效果。
    """
    
    def __init__(self, **kwargs: Any):
        """
        初始化轮询策略。
        
        Args:
            **kwargs: 策略参数
        """
        super().__init__(**kwargs)
        self.strategy_name = 'round_robin'
        self._idx: int = 0
    
    def calculate(self, candidates: List[Any], context: Optional[RequestContext] = None) -> Optional[Any]:
        """
        使用轮询方式选择候选目标。
        
        Args:
            candidates: 候选目标列表
            context: 请求上下文（未使用，保留以符合接口）
            
        Returns:
            选中的目标，无候选时返回 None
        """
        with self._lock:
            self._call_count += 1
            if not candidates:
                logger.warning("轮询策略：候选列表为空")
                return None
            selected = candidates[self._idx % len(candidates)]
            self._idx += 1
            return selected

class RandomStrategy(LoadBalancingStrategy):
    """
    随机负载均衡策略。
    
    从候选列表中随机选择一个目标。
    """
    
    def __init__(self, **kwargs: Any):
        """
        初始化随机策略。
        
        Args:
            **kwargs: 策略参数
        """
        super().__init__(**kwargs)
        self.strategy_name = 'random'
    
    def calculate(self, candidates: List[Any], context: Optional[RequestContext] = None) -> Optional[Any]:
        """
        使用随机方式选择候选目标。
        
        Args:
            candidates: 候选目标列表
            context: 请求上下文（未使用，保留以符合接口）
            
        Returns:
            随机选中的目标，无候选时返回 None
        """
        with self._lock:
            self._call_count += 1
            if not candidates:
                logger.warning("随机策略：候选列表为空")
                return None
            selected = random.choice(candidates)
            return selected

class WeightedStrategy(LoadBalancingStrategy):
    """
    加权负载均衡策略。
    
    根据预设权重选择候选目标，权重越高被选中概率越大。
    """
    
    def __init__(self, weights: Optional[Dict[Any, float]] = None, **kwargs: Any):
        """
        初始化加权策略。
        
        Args:
            weights: 权重映射，键为候选目标，值为权重
            **kwargs: 策略参数
        """
        super().__init__(**kwargs)
        self.strategy_name = 'weighted'
        self._weights: Dict[Any, float] = weights or {}
    
    def calculate(self, candidates: List[Any], context: Optional[RequestContext] = None) -> Optional[Any]:
        """
        使用加权方式选择候选目标。
        
        Args:
            candidates: 候选目标列表
            context: 请求上下文（未使用，保留以符合接口）
            
        Returns:
            加权选中的目标，无候选时返回 None
        """
        with self._lock:
            self._call_count += 1
            if not candidates:
                logger.warning("加权策略：候选列表为空")
                return None
            
            # 构建权重列表
            weight_list: List[float] = []
            for candidate in candidates:
                weight = self._weights.get(candidate, 1.0)
                weight_list.append(weight)
            
            total_weight = sum(weight_list)
            if total_weight <= 0:
                return random.choice(candidates)
            
            random_value = random.uniform(0, total_weight)
            cumulative = 0.0
            for candidate, weight in zip(candidates, weight_list):
                cumulative += weight
                if random_value <= cumulative:
                    return candidate
            
            # 边界情况，返回最后一个
            return candidates[-1]

# 缓存存储
class RequestStore:
    """
    基于 LRU 算法的请求缓存存储。
    
    使用 OrderedDict 实现 LRU 淘汰策略，并支持 TTL 过期。
    """
    
    def __init__(self, max_size: int = 10000, ttl: float = 3600.0):
        """
        初始化请求存储。
        
        Args:
            max_size: 最大缓存条目数
            ttl: 生存时间（秒）
        """
        self._store: OrderedDict[str, tuple[Any, float]] = OrderedDict()
        self._max_size: int = max_size
        self._ttl: float = ttl
        self._lock = threading.RLock()
        self._hits: int = 0
        self._misses: int = 0
        self._evictions: int = 0
        self._total_writes: int = 0
    
    def put(self, key: str, value: Any) -> None:
        """
        写入缓存。
        
        Args:
            key: 缓存键
            value: 缓存值
        """
        with self._lock:
            self._store[key] = (value, now_timestamp())
            self._store.move_to_end(key)
            self._total_writes += 1
            
            # LRU 淘汰
            if len(self._store) > self._max_size:
                self._store.popitem(last=False)
                self._evictions += 1
                logger.debug(f"缓存淘汰，当前大小: {len(self._store)}")
    
    def get(self, key: str) -> Optional[Any]:
        """
        读取缓存。
        
        Args:
            key: 缓存键
            
        Returns:
            缓存值，不存在或过期时返回 None
        """
        with self._lock:
            if key not in self._store:
                self._misses += 1
                return None
            
            value, timestamp = self._store[key]
            
            # TTL 检查
            if now_timestamp() - timestamp > self._ttl:
                del self._store[key]
                self._misses += 1
                logger.debug(f"缓存过期: {key}")
                return None
            
            # 更新 LRU 顺序
            self._store.move_to_end(key)
            self._hits += 1
            return value
    
    def delete(self, key: str) -> bool:
        """
        删除缓存条目。
        
        Args:
            key: 缓存键
            
        Returns:
            是否成功删除
        """
        with self._lock:
            if key in self._store:
                del self._store[key]
                return True
            return False
    
    def clear(self) -> None:
        """清空所有缓存条目。"""
        with self._lock:
            self._store.clear()
            logger.info("缓存已清空")
    
    def get_size(self) -> int:
        """
        获取当前缓存大小。
        
        Returns:
            缓存条目数
        """
        with self._lock:
            return len(self._store)
    
    def get_hit_rate(self) -> float:
        """
        获取缓存命中率。
        
        Returns:
            命中率（0.0-1.0），无访问记录时返回 1.0
        """
        with self._lock:
            total = self._hits + self._misses
            if total == 0:
                return 1.0
            return self._hits / total
    
    def get_stats(self) -> Dict[str, Any]:
        """
        获取缓存统计数据。
        
        Returns:
            包含大小、命中率、淘汰次数等统计信息的字典
        """
        with self._lock:
            return {
                'size': len(self._store),
                'max_size': self._max_size,
                'hits': self._hits,
                'misses': self._misses,
                'evictions': self._evictions,
                'total_writes': self._total_writes,
                'hit_rate': self.get_hit_rate()
            }
