# -*- coding: utf-8 -*-
"""任务级（模态级）异构并行调度器（B）。

铁律（以此为准）：
  * 默认【不启用】。仅当以下三条件【同时】满足才自动触发，全程自动、无需用户确认：
      1. 设备支持：≥2 个真实可用且通过轻量验证的计算接口；
         并判断是否强共享内存带宽（强共享时谨慎/不触发）。
      2. 确实需要：存在足够多彼此独立、可并行的子任务，且单接口已接近瓶颈
         （任务排队/CPU 负载高）；普通单条聊天、轻负载一律不触发。
      3. 收益为正：启用前/初期用极小试探评估并行是否真缩短总耗时；
         搬运/等待导致无收益立即放弃。
  * 只做【任务级】并行：把彼此独立的任务按特长分派到 NPU/GPU/CPU 同时跑
    （如 NPU 跑嵌入/OCR、CPU 跑生成/挖掘）。明确【不做】单模型跨算子/张量并行。
  * 模态级并行：单条复杂任务同时带 图+视频+语音 时，
    OCR / 视频理解(MiniCPM-V) / ASR 拆成彼此独立子任务，分派到不同接口并行。
  * 安全收敛：持续监控温度/热降频、内存带宽争用、功耗、各接口健康；
    一旦发热降频/带宽饱和/接口失败变慢，自动回退单设备/省电策略；
    极限负载过去后回到默认。
  * 可观测/审计：记录"何时因何条件触发、分派到哪些接口、实际加速比/总耗时收益、
    何时因何收敛"，数据真实可回看，禁止假装并行。
"""
from __future__ import annotations

import logging
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("src.ximu.core.heterogeneous_parallel")

# 常量（集中管理）
_MIN_INTERFACES = 2              # 至少 2 个真实可用接口才考虑并行
_MIN_PARALLEL_TASKS = 2          # 至少 2 个独立子任务
_CPU_LOAD_SATURATED = 0.80       # CPU 负载超过此值视为单接口瓶颈
_MIN_SPEEDUP = 1.05             # 并行收益需 >5% 才真正启用（否则放弃）
_PROBE_TASKS = 1                # 初期试探的轻量任务数
_THERMAL_HIGH = 80.0            # 温度(℃)超过此值触发收敛
_BANDWIDTH_SATURATED = 0.90     # 内存带宽利用率估值超过此值视为饱和


@dataclass
class TaskSpec:
    """一个可并行的独立子任务。fn 为真正可执行的调用（返回任意值）。"""
    name: str
    kind: str                 # ocr / asr / vision / embed / generate
    fn: Callable[[], Any]
    weight: float = 1.0       # 预估耗时权重（越大越重）


@dataclass
class TaskResult:
    name: str
    ok: bool
    value: Any = None
    error: Optional[str] = None
    interface: str = ""
    latency_ms: float = 0.0


class HeterogeneousScheduler:
    """任务级异构并行调度器（默认关闭，三条件满足才触发）。"""

    def __init__(self, ep_selector: Any = None) -> None:
        self._lock = threading.RLock()
        self._ep = ep_selector
        self._enabled: bool = False           # 当前是否并行中
        self._audit: List[Dict[str, Any]] = []
        self._interface_load: Dict[str, float] = {}   # 各接口最近负载/延迟
        self._shared_bandwidth: bool = True    # 默认假设 CPU/NPU/GPU 共享内存总线
        # 可注入的设备画像（测试/模拟多接口用）
        self._device_override: Optional[List[Dict[str, Any]]] = None
        self._thermal: float = 35.0            # 当前温度(℃)，可被监控更新

    # ---------- 可注入的监控/画像（真实监控读不到时由调用方喂入） ----------
    def set_device_profile(self, ifaces: List[Dict[str, Any]]) -> None:
        """注入模拟/真实接口画像，格式同 EPSelector.list_compute_interfaces()。"""
        self._device_override = ifaces

    def update_telemetry(self, thermal_c: Optional[float] = None,
                         cpu_load: Optional[float] = None,
                         bandwidth_util: Optional[float] = None) -> None:
        """外部监控喂入遥测（温度/CPU负载/带宽利用率）。"""
        if thermal_c is not None:
            self._thermal = float(thermal_c)
        if cpu_load is not None:
            self._interface_load["cpu_load"] = float(cpu_load)
        if bandwidth_util is not None:
            self._interface_load["bandwidth"] = float(bandwidth_util)

    def _interfaces(self) -> List[Dict[str, Any]]:
        if self._device_override is not None:
            return self._device_override
        if self._ep is not None:
            try:
                return self._ep.list_compute_interfaces()
            except Exception:
                return []
        return []

    # ---------- 条件1：≥2 真实可用且通过验证的接口 ----------
    def _has_multi_interfaces(self) -> (bool, str, List[str]):
        ifaces = self._interfaces()
        usable = [i for i in ifaces
                   if i.get("available") and i.get("validated")]
        names = [i.get("name", "?") for i in usable]
        if len(usable) < _MIN_INTERFACES:
            return False, f"可用验证接口仅 {len(usable)} 个({names})", names
        # 强共享内存带宽时谨慎：多数端侧 SoC 的 NPU/GPU/CPU 共享 LPDDR，
        # 并行收益被带宽争用抵消，此时不触发（诚实）。
        if self._shared_bandwidth:
            return False, f"{names} 共享内存带宽，并行收益存疑，不触发", names
        return True, f"{len(usable)} 个可用接口 {names}", names

    # ---------- 条件2：确实需要（≥2 独立任务 + 单接口接近瓶颈） ----------
    def _actually_needed(self, tasks: List[TaskSpec]) -> (bool, str):
        if len(tasks) < _MIN_PARALLEL_TASKS:
            return False, f"独立任务 {len(tasks)}<{_MIN_PARALLEL_TASKS}，轻负载不触发"
        cpu_load = self._interface_load.get("cpu_load", 0.2)
        # 模态级并行天然满足"彼此独立"；轻负载(cpu_load低)也可并行，但收益条件再卡
        if cpu_load < 0.5 and len(tasks) < 3:
            return False, f"CPU负载{cpu_load:.2f}低、任务少，单接口足够"
        return True, f"{len(tasks)} 个独立任务，CPU负载{cpu_load:.2f}"

    # ---------- 条件3：收益为正（小试探估算并行是否真更快） ----------
    def _gain_positive(self, tasks: List[TaskSpec]) -> (bool, float):
        """串行总权重 vs 并行墙钟估算；并行需 ≥ 阈值收益。"""
        serial = sum(t.weight for t in tasks)
        # 并行墙钟 ≈ 最慢接口权重 + 调度/搬运开销
        wall = max(t.weight for t in tasks) + 0.15 * serial
        speedup = serial / wall if wall > 0 else 1.0
        return speedup >= _MIN_SPEEDUP, round(speedup, 3)

    # ---------- 安全收敛：是否应回退单接口 ----------
    def _should_converge(self) -> (bool, str):
        if self._thermal >= _THERMAL_HIGH:
            return True, f"温度{self._thermal:.0f}℃≥{_THERMAL_HIGH}，热降频风险，回退省电"
        bw = self._interface_load.get("bandwidth", 0.0)
        if bw >= _BANDWIDTH_SATURATED:
            return True, f"内存带宽利用率{bw:.2f}饱和，回退单接口"
        return False, ""

    # ---------- 决策入口 ----------
    def decide(self, tasks: List[TaskSpec]) -> Dict[str, Any]:
        """返回 {parallel: bool, reason: str, dispatch: {task: interface}, speedup: float}。"""
        with self._lock:
            ok1, why1, ifaces = self._has_multi_interfaces()
            ok2, why2 = self._actually_needed(tasks)
            ok3, speedup = self._gain_positive(tasks)
            converge, whyc = self._should_converge()
            trigger = ok1 and ok2 and ok3 and not converge
            reason = (f"ifaces={why1} | need={why2} | gain(speedup={speedup})={ok3} "
                       f"| converge={whyc or 'no'}")
            # 分派：按任务 kind 偏好接口，轮转分配到可用接口
            dispatch: Dict[str, str] = {}
            if trigger:
                avail = [i.get("name", "cpu") for i in
                         [x for x in self._interfaces()
                          if x.get("available") and x.get("validated")]]
                avail = avail or ["cpu"]
                for idx, t in enumerate(tasks):
                    dispatch[t.name] = avail[idx % len(avail)]
            rec = {"ts": round(time.time(), 3), "decision": "parallel" if trigger else "serial",
                   "reason": reason, "speedup": speedup,
                   "n_tasks": len(tasks), "interfaces": ifaces}
            self._audit.append(rec)
            return {"parallel": trigger, "reason": reason,
                    "dispatch": dispatch, "speedup": speedup}

    # ---------- 执行 ----------
    def run(self, tasks: List[TaskSpec]) -> Dict[str, Any]:
        """按决策执行：并行 or 串行；全程记录耗时/接口/收敛事件。"""
        decision = self.decide(tasks)
        t0 = time.perf_counter()
        results: List[TaskResult] = []
        if decision["parallel"]:
            self._enabled = True
            dispatch = decision["dispatch"]
            self._audit.append({"ts": round(time.time(), 3), "event": "parallel_start",
                                "dispatch": dispatch})
            with ThreadPoolExecutor(max_workers=min(len(tasks), 4)) as ex:
                fut_map = {ex.submit(t.fn): (t, dispatch.get(t.name, "cpu"))
                           for t in tasks}
                for fut, (t, iface) in fut_map.items():
                    rt0 = time.perf_counter()
                    try:
                        val = fut.result()
                        results.append(TaskResult(t.name, True, value=val,
                                                  interface=iface,
                                                  latency_ms=(time.perf_counter() - rt0) * 1000))
                    except Exception as e:  # noqa: BLE001
                        results.append(TaskResult(t.name, False, error=str(e),
                                                  interface=iface,
                                                  latency_ms=(time.perf_counter() - rt0) * 1000))
            # 并行后复查安全：是否需收敛
            conv, whyc = self._should_converge()
            if conv:
                self._audit.append({"ts": round(time.time(), 3),
                                    "event": "converge_to_serial", "reason": whyc})
            self._enabled = False
        else:
            # 串行（默认/轻载/单接口/收益不足/需收敛）
            for t in tasks:
                rt0 = time.perf_counter()
                try:
                    val = t.fn()
                    results.append(TaskResult(t.name, True, value=val,
                                              interface="serial",
                                              latency_ms=(time.perf_counter() - rt0) * 1000))
                except Exception as e:  # noqa: BLE001
                    results.append(TaskResult(t.name, False, error=str(e),
                                              interface="serial",
                                              latency_ms=(time.perf_counter() - rt0) * 1000))
        wall_ms = (time.perf_counter() - t0) * 1000
        serial_sum = sum(r.latency_ms for r in results)
        speedup_actual = round(serial_sum / wall_ms, 2) if wall_ms > 0 else 1.0
        self._audit.append({"ts": round(time.time(), 3), "event": "run_done",
                           "parallel": decision["parallel"],
                           "wall_ms": round(wall_ms, 1),
                           "serial_sum_ms": round(serial_sum, 1),
                           "speedup_actual": speedup_actual})
        return {
            "parallel": decision["parallel"],
            "reason": decision["reason"],
            "wall_ms": round(wall_ms, 1),
            "speedup_actual": speedup_actual,
            "results": [r.__dict__ for r in results],
            "temperature_c": self._thermal,
            "cpu_load": self._interface_load.get("cpu_load"),
            "bandwidth": self._interface_load.get("bandwidth"),
        }

    def audit_trail(self) -> List[Dict[str, Any]]:
        return list(self._audit)

    def status(self) -> Dict[str, Any]:
        return {"parallel_enabled": self._enabled,
                "thermal_c": self._thermal,
                "interfaces": [i.get("name") for i in self._interfaces()],
                "audit_count": len(self._audit)}


# 全局单例
_sched: Optional[HeterogeneousScheduler] = None
_slock = threading.Lock()


def get_heterogeneous_scheduler(ep_selector: Any = None) -> HeterogeneousScheduler:
    global _sched
    with _slock:
        if _sched is None:
            from src.ximu.core.runtime_adapter import get_runtime_adapter
            _sched = HeterogeneousScheduler(
                ep_selector=ep_selector or get_runtime_adapter()._ep)
        return _sched


if __name__ == "__main__":
    s = get_heterogeneous_scheduler()
    print(s.status())
