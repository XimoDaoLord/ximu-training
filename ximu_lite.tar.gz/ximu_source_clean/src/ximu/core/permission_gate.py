# -*- coding: utf-8 -*-
"""运行时权限门控模块。

按用户在引导页选的等级真实放行shell执行。等级包括standard/shizuku/root，
其中root等级优先使用su提权，设备未root时降级为应用权限并标注。
"""
import json
import os
import subprocess
import threading
import time
from typing import Dict, Any

_LOCK = threading.Lock()

try:
    from src.ximu.core.data_root import runtime_permission_mode_path as _rpm_path
    _MODE_FILE: str = os.path.abspath(_rpm_path())
except Exception:
    _HERE: str = os.path.dirname(os.path.abspath(__file__))
    _MODE_FILE: str = os.path.abspath(os.path.join(_HERE, "..", "..", "ui", "web_ui", "data", "runtime_permission_mode.json"))

_VALID_MODES: set = {"standard", "shizuku", "root"}
_current_mode: str = "standard"
_root_probe_cache: Dict[str, Any] = {"ts": 0.0, "ok": None}
_ROOT_PROBE_TTL: float = 30.0


def real_root_available() -> bool:
    """诚实检测当前环境是否真有可用root（su提权真实可跑通）。

    不假装：设备未root/无su一律返回False。结果缓存30s防每次fork。

    Returns:
        bool: 当前环境是否具备可用的root权限。
    """
    global _root_probe_cache
    now = time.monotonic()
    if _root_probe_cache["ok"] is not None and (now - _root_probe_cache["ts"]) < _ROOT_PROBE_TTL:
        return bool(_root_probe_cache["ok"])
    ok = False
    try:
        if hasattr(os, "geteuid") and os.geteuid() == 0:
            ok = True
        else:
            result = subprocess.run(["su", "-c", "true"], capture_output=True, timeout=2, shell=False)
            ok = (result.returncode == 0)
    except Exception:
        ok = False
    _root_probe_cache["ts"] = now
    _root_probe_cache["ok"] = ok
    return ok


def _load() -> str:
    """加载持久化的权限模式。

    Returns:
        str: 当前权限模式，若加载失败则返回\"standard\"。
    """
    global _current_mode
    try:
        if os.path.exists(_MODE_FILE):
            with open(_MODE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                mode = data.get("mode", "standard")
                if mode in _VALID_MODES:
                    _current_mode = mode
    except (json.JSONDecodeError, OSError, KeyError, TypeError):
        pass
    return _current_mode


def get_mode() -> str:
    """获取当前权限模式。

    Returns:
        str: 当前权限模式（standard, shizuku, root）。
    """
    return _load()


def describe_mode() -> Dict[str, Any]:
    """获取带诚实标注的权限状态。

    mode是用户在引导页选的等级；real_root是设备真实探测结果。前端据此诚实显示。

    Returns:
        dict: 包含mode/effective_mode/real_root/allow_shell的字典。
    """
    mode = get_mode()
    real_root = real_root_available()
    effective = mode
    if mode == "root" and not real_root:
        effective = "shizuku"
    return {
        "mode": mode,
        "effective_mode": effective,
        "real_root": real_root,
        "allow_shell": effective in ("shizuku", "root"),
    }


def set_mode(mode: str) -> bool:
    """设置权限模式并持久化。

    Args:
        mode: 权限模式字符串（standard, shizuku, root）。

    Returns:
        bool: 设置成功返回True，否则返回False。
    """
    global _current_mode
    if mode not in _VALID_MODES:
        return False
    with _LOCK:
        try:
            os.makedirs(os.path.dirname(_MODE_FILE), exist_ok=True)
            with open(_MODE_FILE, "w", encoding="utf-8") as f:
                json.dump({"mode": mode}, f, ensure_ascii=False)
            _current_mode = mode
            return True
        except (OSError, json.JSONDecodeError) as e:
            print(f"Failed to set permission mode: {e}")
            return False


def allow_shell() -> bool:
    """检查当前等级是否允许执行外部shell。

    Returns:
        bool: 如果当前模式为shizuku或root则返回True。
    """
    return get_mode() in ("shizuku", "root")


def exec_shell(cmd: str, timeout: int = 15) -> Dict[str, Any]:
    """按当前等级执行shell命令。

    Args:
        cmd: 要执行的shell命令字符串。
        timeout: 命令执行的超时时间（秒），默认为15。

    Returns:
        dict: 包含ok/code/out/via的字典。
    """
    mode = get_mode()
    if mode == "standard":
        return {"ok": False, "code": -1, "out": "基础权限禁止执行shell，请在引导页升级为Shizuku/Root权限", "via": "denied"}
    use_su = (mode == "root")
    if use_su:
        argv = ["su", "-c", cmd]
    else:
        sh = "/system/bin/sh" if os.path.exists("/system/bin/sh") else "sh"
        argv = [sh, "-c", cmd]
    try:
        result = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
        via = "su(root)" if use_su and result.returncode == 0 else ("app-shell" if not use_su else "su-fallback-appshell")
        if use_su and result.returncode != 0:
            stderr_content = result.stderr or ""
            if "Permission denied" not in stderr_content:
                try:
                    fallback_result = subprocess.run(["/system/bin/sh", "-c", cmd], capture_output=True, text=True, timeout=timeout)
                    return {"ok": fallback_result.returncode == 0, "code": fallback_result.returncode, "out": (fallback_result.stdout or "") + (fallback_result.stderr or ""), "via": "root-requested-but-not-rooted-fallback"}
                except Exception as e:
                    return {"ok": False, "code": result.returncode, "out": (result.stdout or "") + (result.stderr or str(e)), "via": via}
        return {"ok": result.returncode == 0, "code": result.returncode, "out": (result.stdout or "") + (result.stderr or ""), "via": via}
    except FileNotFoundError:
        if use_su:
            try:
                fallback_result = subprocess.run(["/system/bin/sh", "-c", cmd], capture_output=True, text=True, timeout=timeout)
                return {"ok": fallback_result.returncode == 0, "code": fallback_result.returncode, "out": fallback_result.stdout or fallback_result.stderr or "", "via": "root-requested-no-su-fallback-appshell"}
            except Exception as e:
                return {"ok": False, "code": -1, "out": str(e), "via": "no-su"}
        return {"ok": False, "code": -1, "out": "未找到sh", "via": "no-sh"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "code": -1, "out": f"命令执行超时（{timeout}秒）", "via": "timeout"}
    except Exception as e:
        return {"ok": False, "code": -1, "out": str(e), "via": "error"}
