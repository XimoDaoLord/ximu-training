import logging
logger = logging.getLogger("src.ximu.core.lifecycle_manager")
# -*- coding: utf-8 -*-
"""
任务生命周期管理器:管理任务从创建到归档的全生命周期。
阶段10:任务生命周期管理(F-09/D-24)
模块定位:任务创建→就绪→运行→完成→交付→归档→清理的全流程管理、
任务超时控制、任务取消、任务重试、任务查询、任务统计。
"""

import time
import json
import os
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Any, Callable
from enum import Enum

try:
    from .task_scheduler import TaskNode, TaskStatus
except ImportError:
    TaskNode = TaskStatus = None


class ExportFormat(Enum):
    """导出格式"""
    JSON = "json"
    Markdown = "markdown"
    HTML = "html"


@dataclass
class DeliveryResult:
    """交付结果"""
    task_id: str
    root_id: str
    success: bool
    deliverables: List[Dict[str, Any]] = field(default_factory=list)
    missing_goals: List[str] = field(default_factory=list)
    exported_files: List[str] = field(default_factory=list)
    summary: str = ""


class TaskLifecycleManager:
    """
    任务生命周期管理器:管理任务从创建到归档的全生命周期。
    """

    def __init__(self, scheduler=None, config: Optional[Dict] = None):
        self._scheduler = scheduler
        self._config = config or {}
        self._logger = logging.getLogger(__name__)

        # 交付目录
        self._exports_dir = self._config.get("exports_dir", "./exports")
        os.makedirs(self._exports_dir, exist_ok=True)

        # 归档目录
        self._archive_dir = self._config.get("archive_dir", "./archives")
        os.makedirs(self._archive_dir, exist_ok=True)

        # 交付钩子
        self._delivery_hooks: List[Callable[[str, DeliveryResult], None]] = []

        # 统计
        self._stats = {
            "tasks_completed": 0,
            "tasks_cancelled": 0,
            "tasks_archived": 0,
            "deliveries_exported": 0
        }

        self._logger.info("TaskLifecycleManager initialized")

    # ==========
    # 方法一:finalize_and_deliver（任务完成与交付,F-09/D-24）
    # ==========

    def finalize_and_deliver(self, root_task_id: str) -> Optional[DeliveryResult]:
        """
        任务完成与交付
        F-09: 任务完成后必须生成交付物
        D-24: 交付物格式标准化
        """
        try:
            # 收集所有结果
            deliverables = self._collect_all_results(root_task_id)

            # 检查目标覆盖
            original_input = self._read_original_input(root_task_id)
            missing_goals = self._check_goal_coverage(original_input, deliverables)

            # 构建交付结果
            result = self._build_deliverables(root_task_id, deliverables, missing_goals)

            # 导出交付物
            self._export_deliverable(root_task_id, result)

            # 触发交付钩子
            for hook in self._delivery_hooks:
                try:
                    hook(root_task_id, result)
                except Exception as e:
                    self._logger.warning(f"Delivery hook failed: {e}")

            # 更新统计
            self._stats["tasks_completed"] += 1
            self._stats["deliveries_exported"] += 1

            self._logger.info(f"Task {root_task_id} finalized and delivered")
            return result

        except Exception as e:
            self._logger.error(f"Failed to finalize task {root_task_id}: {e}")
            return None

    def _collect_all_results(self, root_task_id: str) -> List[Dict[str, Any]]:
        """收集所有子任务结果"""
        if not self._scheduler:
            return []

        results = []
        try:
            task = self._get_task(root_task_id)
            if task and task.children:
                for child_id in task.children:
                    child = self._get_task(child_id)
                    if child and child.result is not None:
                        results.append({
                            "task_id": child_id,
                            "result": child.result,
                            "status": child.status.value
                        })
        except Exception as e:
            self._logger.warning(f"Failed to collect results: {e}")

        return results

    def _read_original_input(self, root_task_id: str) -> Optional[Dict]:
        """读取原始输入"""
        try:
            task = self._get_task(root_task_id)
            if task and task.input_data:
                return task.input_data
        except Exception as e:
            self._logger.warning(f"Failed to read input: {e}")
        return None

    def _check_goal_coverage(self, original_input: Optional[Dict],
                             deliverables: List[Dict]) -> List[str]:
        """检查目标覆盖情况"""
        missing = []
        if not original_input:
            return missing

        required_goals = original_input.get("goals", [])
        delivered_goals = []

        for d in deliverables:
            if isinstance(d, dict) and "goal" in d:
                delivered_goals.append(d["goal"])

        for goal in required_goals:
            if goal not in delivered_goals:
                missing.append(goal)

        return missing

    def _build_deliverables(self, root_task_id: str,
                            deliverables: List[Dict],
                            missing_goals: List[str]) -> DeliveryResult:
        """构建交付结果"""
        return DeliveryResult(
            task_id=root_task_id,
            root_id=root_task_id,
            success=len(missing_goals) == 0,
            deliverables=deliverables,
            missing_goals=missing_goals,
            exported_files=[],
            summary=self._generate_delivery_summary(root_task_id, deliverables, missing_goals)
        )

    def _detect_result_type(self, result: Any) -> str:
        """检测结果类型"""
        if result is None:
            return "none"
        elif isinstance(result, dict):
            return "dict"
        elif isinstance(result, list):
            return "list"
        elif isinstance(result, str):
            return "string"
        elif isinstance(result, (int, float)):
            return "number"
        else:
            return "object"

    def _export_deliverable(self, root_task_id: str, result: DeliveryResult) -> List[str]:
        """导出交付物"""
        exported = []
        try:
            # 导出JSON
            json_path = os.path.join(self._exports_dir, f"{root_task_id}_delivery.json")
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(result.__dict__, f, indent=2, ensure_ascii=False)
            exported.append(json_path)

            # 导出Markdown
            md_path = os.path.join(self._exports_dir, f"{root_task_id}_delivery.md")
            with open(md_path, 'w', encoding='utf-8') as f:
                f.write("# 任务交付报告\\n\\n")
                f.write(f"**任务ID**: {root_task_id}\\n\\n")
                f.write(f"**成功**: {result.success}\\n\\n")
                f.write(f"**摘要**: {result.summary}\\n\\n")
            exported.append(md_path)

            self._stats["deliveries_exported"] += 1

        except Exception as e:
            self._logger.warning(f"Failed to export deliverables: {e}")

        return exported

    def _format_deliverable(self, deliverables: List[Dict], format_type: str) -> str:
        """格式化交付物"""
        if format_type == "json":
            return json.dumps(deliverables, indent=2, ensure_ascii=False)
        elif format_type == "markdown":
            lines = ["# 交付物\\n"]
            for i, d in enumerate(deliverables, 1):
                lines.append(f"## 交付物 {i}\\n")
                lines.append(f"```json\\n{json.dumps(d, indent=2, ensure_ascii=False)}\\n```\\n")
            return "\\n".join(lines)
        else:
            return str(deliverables)

    def _generate_delivery_summary(self, root_task_id: str,
                                   deliverables: List[Dict],
                                   missing_goals: List[str]) -> str:
        """生成交付摘要"""
        parts = [f"任务 {root_task_id} 交付完成"]
        parts.append(f"交付物数量: {len(deliverables)}")
        if missing_goals:
            parts.append(f"未达成目标: {', '.join(missing_goals)}")
        else:
            parts.append("所有目标已达成")
        return "; ".join(parts)

    def cancel_task(self, task_id: str, reason: str = "") -> bool:
        """取消任务"""
        try:
            task = self._get_task(task_id)
            if not task:
                return False

            if task.status in (TaskStatus.COMPLETED, TaskStatus.ARCHIVED):
                self._logger.warning(f"Task {task_id} already completed, cannot cancel")
                return False

            task.status = TaskStatus.CANCELLED
            task.cancel_reason = reason
            task.end_time = time.time()

            self._stats["tasks_cancelled"] += 1
            self._logger.info(f"Task {task_id} cancelled: {reason}")
            return True

        except Exception as e:
            self._logger.error(f"Failed to cancel task {task_id}: {e}")
            return False

    def retry_task(self, task_id: str) -> bool:
        """重试任务"""
        try:
            task = self._get_task(task_id)
            if not task:
                return False

            if task.retry_count >= 5:  # F-06: 最多重试5次
                self._logger.warning(f"Task {task_id} exceeded max retries")
                return False

            task.status = TaskStatus.READY
            task.retry_count += 1
            task.start_time = time.time()

            self._logger.info(f"Task {task_id} retried (attempt {task.retry_count})")
            return True

        except Exception as e:
            self._logger.error(f"Failed to retry task {task_id}: {e}")
            return False

    def query_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """查询任务"""
        try:
            task = self._get_task(task_id)
            if not task:
                return None

            return {
                "task_id": task_id,
                "status": task.status.value,
                "retry_count": task.retry_count,
                "start_time": task.start_time,
                "end_time": task.end_time,
                "result_type": self._detect_result_type(task.result) if task.result else None,
                "cancel_reason": getattr(task, 'cancel_reason', None)
            }

        except Exception as e:
            self._logger.error(f"Failed to query task {task_id}: {e}")
            return None

    def _archive_task(self, task_id: str) -> bool:
        """归档任务"""
        try:
            task = self._get_task(task_id)
            if not task:
                return False

            # 移动到归档目录
            archive_path = os.path.join(self._archive_dir, f"{task_id}.json")
            task_data = {
                "task_id": task_id,
                "status": task.status.value,
                "start_time": task.start_time,
                "end_time": task.end_time,
                "retry_count": task.retry_count,
                "result": task.result
            }

            with open(archive_path, 'w', encoding='utf-8') as f:
                json.dump(task_data, f, indent=2, ensure_ascii=False)

            task.status = TaskStatus.ARCHIVED
            self._stats["tasks_archived"] += 1

            self._logger.info(f"Task {task_id} archived")
            return True

        except Exception as e:
            self._logger.error(f"Failed to archive task {task_id}: {e}")
            return False

    def _get_task(self, task_id: str) -> Optional[TaskNode]:
        """获取任务"""
        if not self._scheduler:
            return None
        return self._scheduler.get_task(task_id)

    def add_delivery_hook(self, hook: Callable[[str, DeliveryResult], None]) -> None:
        """添加交付钩子"""
        self._delivery_hooks.append(hook)
        self._logger.info(f"Added delivery hook, total hooks: {len(self._delivery_hooks)}")

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return self._stats.copy()


LifecycleManager = TaskLifecycleManager
