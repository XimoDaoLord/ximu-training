# -*- coding: utf-8 -*-
"""任务间上下文传递（InterTaskContext）——中转池在“任务协作”方向的落地。

父任务拆出的原子任务之间，需要把 A 的提纯结果传给 B。本模块以真实的
core.transit_pool.TransitPool（读写分离/快照/回滚/容量控制）为唯一后端：
- publish：生产者任务把提纯结果写入某 channel 的槽位；
- consume：消费者任务读取；A、B 近乎同时启动、B 先到时按超时等待，不会读到脏空值；
- snapshot/rollback：整组任务上下文可快照、可回滚。
不新建第二套存储，避免重复实现；TransitPool 由此获得真实调用方（不再是死代码）。

版本: 0.5
"""
from __future__ import annotations

import logging
import os
import tempfile
import threading
import time
import uuid
from typing import Any, Dict, Optional

from src.ximu.core.transit_pool import TransitPool

# 配置日志记录器
logger = logging.getLogger(__name__)

# 版本号
__version__ = "0.5"


class InterTaskContext:
    """任务间上下文管理器，基于 TransitPool 实现生产者-消费者模式的数据传递。
    
    该类提供 publish/consume 机制用于原子任务间的数据交换，
    并支持快照和回滚操作以保证事务一致性。
    """

    def __init__(
        self,
        pool: Optional[TransitPool] = None,
        storage_path: Optional[str] = None,
    ) -> None:
        """初始化 InterTaskContext 实例。
        
        若未提供 pool，则根据 storage_path 或环境变量创建默认的 TransitPool。
        
        Args:
            pool: 可选的 TransitPool 实例。如果为 None，则自动创建。
            storage_path: 存储路径。如果 pool 为 None 且 storage_path 为 None，
                         则从环境变量 XIMU_TRANSIT_DIR 获取，或使用临时目录。
        """
        if pool is None:
            # 优先使用显式提供的 storage_path
            if storage_path is None:
                # 尝试从环境变量获取统一中转目录
                env_path = os.environ.get("XIMU_TRANSIT_DIR")
                if env_path:
                    logger.debug("使用环境变量 XIMU_TRANSIT_DIR: %s", env_path)
                    storage_path = env_path
                else:
                    # 兜底方案：创建临时目录，确保单元/独立脚本可运行
                    storage_path = tempfile.mkdtemp(prefix="ximu_itc_")
                    logger.debug("创建临时存储目录: %s", storage_path)
            
            logger.info("创建新的 TransitPool，存储路径: %s", storage_path)
            pool = TransitPool(config={"storage_path": storage_path})
        
        self.pool = pool
        self._cond = threading.Condition()
        
        # 记录初始化信息
        logger.debug(
            "InterTaskContext 初始化完成，pool=%s, version=%s",
            id(self.pool),
            __version__
        )

    @staticmethod
    def _slot(channel: str) -> str:
        """生成渠道对应的槽位名称。
        
        Args:
            channel: 渠道名称
            
        Returns:
            格式化的槽位标识符字符串
        """
        return f"channel::{channel}"

    def publish(
        self,
        channel: str,
        producer_task_id: str,
        payload: Any,
    ) -> bool:
        """生产者写入提纯结果到指定渠道。
        
        Args:
            channel: 目标渠道名称
            producer_task_id: 生产者任务ID，用于追溯来源
            payload: 要传递的数据负载
            
        Returns:
            bool: 写入是否成功
            
        Raises:
            Exception: 当底层 TransitPool 写入发生不可恢复错误时
        """
        # 构造标准信封结构
        envelope: Dict[str, Any] = {
            "producer": producer_task_id,
            "published_at": time.time(),
            "status": "ready",
            "payload": payload,
        }
        
        slot_name = self._slot(channel)
        logger.debug(
            "发布数据到渠道 '%s' (槽位: %s), 生产者: %s",
            channel, slot_name, producer_task_id
        )
        
        try:
            result = self.pool.write_slot(channel, slot_name, envelope)
            
            if not result.success:
                logger.warning(
                    "发布失败: 渠道 '%s', 生产者 '%s', 原因: %s",
                    channel, producer_task_id, getattr(result, 'error', '未知')
                )
                return False
            
            # 唤醒所有等待的消费者
            with self._cond:
                self._cond.notify_all()
            
            logger.debug("发布成功: 渠道 '%s'", channel)
            return True
            
        except Exception as e:
            logger.exception("发布过程中发生异常: 渠道 '%s'", channel)
            raise e

    def consume(
        self,
        channel: str,
        consumer_task_id: str,
        wait: bool = True,
        timeout: float = 5.0,
        poll_interval: float = 0.01,
    ) -> Optional[Dict[str, Any]]:
        """消费者读取指定渠道的数据。
        
        Args:
            channel: 源渠道名称
            consumer_task_id: 消费者任务ID，用于记录消费方
            wait: 是否等待数据就绪。若为 False，立即返回当前值或 None
            timeout: 最大等待时间（秒），仅当 wait=True 时生效
            poll_interval: 轮询间隔（秒），用于条件等待
            
        Returns:
            包含数据和元信息的字典，若超时或无数据则返回 None
            
        Notes:
            返回的字典会额外添加 "consumer" 字段标记消费方
        """
        slot_name = self._slot(channel)
        logger.debug(
            "开始消费渠道 '%s' (槽位: %s), 等待模式: %s, 超时: %.2fs",
            channel, slot_name, wait, timeout
        )
        
        deadline = time.time() + timeout if wait else 0.0
        start_time = time.time()
        
        while True:
            # 尝试读取槽位数据
            value = self.pool.read_slot(channel, slot_name)
            
            if value is not None:
                # 复制数据并添加消费者标识
                result: Dict[str, Any] = dict(value)
                result["consumer"] = consumer_task_id
                elapsed = time.time() - start_time
                logger.debug(
                    "消费成功: 渠道 '%s', 消费者 '%s', 耗时: %.4fs",
                    channel, consumer_task_id, elapsed
                )
                return result
            
            # 判断是否超时或不需要等待
            if not wait or time.time() >= deadline:
                logger.info(
                    "消费超时或无数据: 渠道 '%s', 等待模式: %s",
                    channel, wait
                )
                return None
            
            # 计算剩余等待时间，避免过冲
            remaining = deadline - time.time()
            wait_duration = min(poll_interval, max(0.0, remaining))
            
            if wait_duration > 0:
                with self._cond:
                    self._cond.wait(wait_duration)
            else:
                # 防止死循环，即使等待时间为0也短暂休眠
                time.sleep(poll_interval)

    def snapshot(self, channel: str) -> Optional[str]:
        """创建指定渠道的快照。
        
        Args:
            channel: 要快照的渠道名称
            
        Returns:
            快照ID字符串，若创建失败则返回 None
        """
        snapshot_id = f"snap_{uuid.uuid4().hex[:12]}"
        logger.debug("尝试创建快照: 渠道 '%s', 快照ID '%s'", channel, snapshot_id)
        
        success = self.pool.create_snapshot(snapshot_id, channel)
        
        if success:
            logger.info("快照创建成功: 渠道 '%s', ID '%s'", channel, snapshot_id)
            return snapshot_id
        else:
            logger.warning("快照创建失败: 渠道 '%s'", channel)
            return None

    def rollback(self, snapshot_id: str) -> bool:
        """回滚到指定快照。
        
        Args:
            snapshot_id: 之前通过 snapshot() 方法创建的快照ID
            
        Returns:
            bool: 回滚是否成功
        """
        logger.info("开始回滚到快照: '%s'", snapshot_id)
        
        success = self.pool.rollback_to_snapshot(snapshot_id)
        
        if success:
            logger.info("回滚成功: 快照 '%s'", snapshot_id)
        else:
            logger.warning("回滚失败: 快照 '%s'", snapshot_id)
            
        return success

    def stats(self) -> Dict[str, Any]:
        """获取当前上下文统计信息。
        
        Returns:
            包含池状态统计的字典
        """
        try:
            statistics = self.pool.get_stats()
            logger.debug("获取统计信息成功: %s", statistics)
            return statistics
        except Exception as e:
            logger.error("获取统计信息时发生异常", exc_info=e)
            raise
