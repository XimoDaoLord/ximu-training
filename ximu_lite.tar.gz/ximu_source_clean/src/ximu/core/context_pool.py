import logging
import json
import re
import time
import threading
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Any, Tuple
from enum import Enum

logger = logging.getLogger("src.ximu.core.context_pool")

# 提纯：不可见控制字符（保留 \t \n）与需掩码的密钥/凭据
_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
_SECRET_RE = re.compile(
    r"(sk-[A-Za-z0-9]{20,}|AIza[0-9A-Za-z_\-]{30,}|ghp_[A-Za-z0-9]{20,}|"
    r"(?i:bearer\s+)[A-Za-z0-9._\-]{16,}|"
    r"(?i:(?:password|api[_-]?key|token)\s*[=:]\s*)\S+)"
)


class ContextPriority(Enum):
    """上下文优先级枚举"""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4


class TaskType(Enum):
    """任务类型枚举"""
    INDEPENDENT = "independent"
    DEPENDENT = "dependent"
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"


@dataclass
class ContextSlot:
    """
    上下文槽位数据结构
    
    用于存储上下文池中的单个上下文单元，包含内容、优先级、任务类型等元数据。
    """
    slot_id: str
    content: Any
    priority: ContextPriority = ContextPriority.NORMAL
    task_type: TaskType = TaskType.INDEPENDENT
    created_at: float = field(default_factory=time.time)
    expires_at: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PurificationResult:
    """
    提纯结果数据结构
    
    包含原始内容、过滤后的内容、提取统计信息、置信度得分及错误列表。
    """
    original_content: Any
    filtered_content: Any
    extraction_stats: Dict[str, Any]
    confidence_score: float
    errors: List[str]


class ContextPool:
    """
    上下文池核心类
    
    提供线程安全的上下文存储、检索、淘汰机制。
    支持基于优先级和时间的自动淘汰策略，以及统计信息收集。
    """

    def __init__(self, max_size: int = 1000):
        """
        初始化上下文池
        
        Args:
            max_size: 池的最大容量
        """
        self._slots: Dict[str, ContextSlot] = {}
        self._max_size: int = max_size
        self._lock: threading.RLock = threading.RLock()
        self._purification_stats: Dict[str, Any] = {
            "total_processed": 0,
            "total_filtered_tokens": 0,
            "total_retained_tokens": 0,
            "layer_stats": {}
        }
        self._cache_hits: int = 0
        self._cache_misses: int = 0
        self._tokens_saved: int = 0
        self._token_per_hit: int = 600
        
        logger.info(f"ContextPool initialized: max_size={max_size}")

    def put(self, slot_id: str, content: Any,
            priority: ContextPriority = ContextPriority.NORMAL,
            task_type: TaskType = TaskType.INDEPENDENT,
            expires_at: Optional[float] = None) -> bool:
        """
        放入上下文槽位
        
        如果池已满，先清理过期项，若仍满则淘汰优先级最低且创建时间最早的槽位。
        
        Args:
            slot_id: 槽位ID
            content: 上下文内容
            priority: 优先级
            task_type: 任务类型
            expires_at: 过期时间戳
            
        Returns:
            bool: 是否成功放入
        """
        with self._lock:
            return self._put_locked(slot_id, content, priority, task_type, expires_at)

    def _put_locked(self, slot_id: str, content: Any,
                    priority: ContextPriority,
                    task_type: TaskType,
                    expires_at: Optional[float]) -> bool:
        """
        put方法的内部实现，要求调用方持有锁
        
        Args:
            slot_id: 槽位ID
            content: 上下文内容
            priority: 优先级
            task_type: 任务类型
            expires_at: 过期时间戳
            
        Returns:
            bool: 是否成功放入
        """
        old_slot = self._slots.get(slot_id)
        if old_slot is not None:
            logger.warning(
                "Overwrite slot %s (old priority=%s, old created_at=%s)",
                slot_id, 
                getattr(old_slot.priority, "name", old_slot.priority),
                getattr(old_slot, "created_at", 0)
            )
            self._slots.pop(slot_id, None)

        if len(self._slots) >= self._max_size:
            self._purge_expired()
            if len(self._slots) >= self._max_size:
                victim = self._pick_eviction_victim()
                if victim is None:
                    logger.warning(f"Context pool full ({self._max_size}) and no evictable slot")
                    return False
                logger.warning("Context pool full (%s), evict lowest/oldest slot %s",
                               self._max_size, victim)
                self._slots.pop(victim, None)

        self._slots[slot_id] = ContextSlot(
            slot_id=slot_id,
            content=content,
            priority=priority,
            task_type=task_type,
            expires_at=expires_at,
        )
        logger.debug(f"Context slot put: {slot_id}")
        return True

    def _purge_expired(self) -> int:
        """
        清理所有已过期槽位
        
        Returns:
            int: 清理的数量
        """
        now = time.time()
        expired = [
            sid for sid, s in self._slots.items()
            if s.expires_at is not None and s.expires_at <= now
        ]
        for sid in expired:
            self._slots.pop(sid, None)
        return len(expired)

    def _pick_eviction_victim(self) -> Optional[str]:
        """
        挑选淘汰对象：优先级数值最低，同级中创建时间最早的
        
        Returns:
            Optional[str]: 被淘汰的槽位ID，如果没有可淘汰项则返回None
        """
        if not self._slots:
            return None

        def rank(item: Tuple[str, ContextSlot]) -> Tuple[int, float]:
            sid, slot = item
            pr = slot.priority.value if isinstance(slot.priority, ContextPriority) else ContextPriority.NORMAL.value
            return (pr, slot.created_at)

        return min(self._slots.items(), key=rank)[0]

    def get(self, slot_id: str) -> Optional[ContextSlot]:
        """
        获取上下文槽位，若已过期则清理并返回None
        
        Args:
            slot_id: 槽位ID
            
        Returns:
            Optional[ContextSlot]: 槽位对象或None
        """
        with self._lock:
            slot = self._slots.get(slot_id)
            if slot is not None:
                if slot.expires_at is not None and slot.expires_at <= time.time():
                    self._slots.pop(slot_id, None)
                    self._cache_misses += 1
                    return None
                self._cache_hits += 1
                self._tokens_saved += self._token_per_hit
                return slot
            else:
                self._cache_misses += 1
                return None

    def remove(self, slot_id: str) -> bool:
        """
        移除上下文槽位
        
        Args:
            slot_id: 槽位ID
            
        Returns:
            bool: 是否移除成功
        """
        with self._lock:
            if slot_id in self._slots:
                del self._slots[slot_id]
                return True
            return False

    def size(self) -> int:
        """
        获取当前槽位数
        
        Returns:
            int: 当前槽位数量
        """
        with self._lock:
            return len(self._slots)

    def clear(self) -> None:
        """
        清空所有槽位
        """
        with self._lock:
            self._slots.clear()

    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            Dict[str, Any]: 包含缓存命中率、当前大小等统计信息
        """
        total = self._cache_hits + self._cache_misses
        hit_rate = (self._cache_hits / total) if total > 0 else 0.0
        return {
            **self._purification_stats,
            "current_size": len(self._slots),
            "max_size": self._max_size,
            "cache_hits": self._cache_hits,
            "cache_misses": self._cache_misses,
            "hit_rate": round(hit_rate, 4),
            "tokens_saved_est": self._tokens_saved,
        }


class ContextPoolManager:
    """
    上下文池管理器
    
    用于管理多个命名上下文池的创建、获取和列表查询。
    """

    def __init__(self):
        """初始化上下文池管理器"""
        self._pools: Dict[str, ContextPool] = {}
        logger.info("ContextPoolManager initialized")

    def create_pool(self, pool_id: str, max_size: int = 1000) -> ContextPool:
        """
        创建新的上下文池，如果已存在则返回现有池
        
        Args:
            pool_id: 池ID
            max_size: 池的最大容量
            
        Returns:
            ContextPool: 上下文池实例
        """
        if pool_id in self._pools:
            return self._pools[pool_id]

        pool = ContextPool(max_size=max_size)
        self._pools[pool_id] = pool
        logger.info(f"Created pool: {pool_id}")
        return pool

    def get_pool(self, pool_id: str) -> Optional[ContextPool]:
        """
        获取指定ID的上下文池
        
        Args:
            pool_id: 池ID
            
        Returns:
            Optional[ContextPool]: 池实例或None
        """
        return self._pools.get(pool_id)

    def list_pools(self) -> List[str]:
        """
        列出所有池ID
        
        Returns:
            List[str]: 池ID列表
        """
        return list(self._pools.keys())


class ContextPurificationEngine:
    """
    上下文提纯引擎
    
    负责对上下文内容进行提纯，包括移除控制字符和掩码敏感信息。
    """

    def __init__(self):
        """初始化提纯引擎"""
        self._stats: Dict[str, int] = {
            "total_processed": 0,
            "filters_applied": 0
        }
        logger.info("ContextPurificationEngine initialized")

    def purify(self, content: Any, context: Dict[str, Any],
               task_type: TaskType = TaskType.INDEPENDENT,
               priority: ContextPriority = ContextPriority.NORMAL) -> PurificationResult:
        """
        对原始内容进行提纯
        
        Args:
            content: 原始内容
            context: 上下文信息
            task_type: 任务类型
            priority: 优先级
            
        Returns:
            PurificationResult: 提纯结果
        """
        self._stats["total_processed"] += 1
        original = content

        if isinstance(content, str):
            try:
                parsed: Any = json.loads(content)
            except json.JSONDecodeError:
                parsed = {"raw_text": content}
        else:
            parsed = content

        counters: Dict[str, int] = {
            "control_chars_removed": 0,
            "secrets_masked": 0,
            "changed_fields": 0
        }

        def _clean_text(value: str) -> str:
            before_len = len(value)
            value = _CTRL_RE.sub("", value)
            counters["control_chars_removed"] += before_len - len(value)
            value, n_masked = _SECRET_RE.subn("***MASKED***", value)
            counters["secrets_masked"] += n_masked
            return value

        def _walk(node: Any) -> Any:
            if isinstance(node, str):
                cleaned = _clean_text(node)
                if cleaned != node:
                    counters["changed_fields"] += 1
                return cleaned
            if isinstance(node, dict):
                return {k: _walk(v) for k, v in node.items()}
            if isinstance(node, list):
                return [_walk(v) for v in node]
            return node

        filtered = _walk(parsed)
        
        if counters["changed_fields"] > 0:
            self._stats["filters_applied"] += counters["changed_fields"]
            
        extraction_stats: Dict[str, Any] = {
            **counters,
            "input_type": type(parsed).__name__
        }
        
        confidence = max(0.5, 1.0 - 0.1 * counters["secrets_masked"] - 0.02 * counters["control_chars_removed"])

        return PurificationResult(
            original_content=original,
            filtered_content=filtered,
            extraction_stats=extraction_stats,
            confidence_score=round(confidence, 4),
            errors=[]
        )

    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            Dict[str, Any]: 提纯引擎统计信息
        """
        return self._stats
