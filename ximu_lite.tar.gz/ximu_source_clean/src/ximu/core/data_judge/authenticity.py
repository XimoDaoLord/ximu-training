"""Re-export hub for authenticity (split into 2 parts, original 3729 lines)."""
import warnings as _w
_w.warn("authenticity has been split, import from specific part", DeprecationWarning, stacklevel=2)


import importlib as _il
import logging as _logging

for _n in ['part1', 'part2']:
    try:
        _m = _il.import_module("._authenticity_parts." + _n, package=__package__)
        for _x in dir(_m):
            if not _x.startswith("_"):
                globals()[_x] = getattr(_m, _x)
    except Exception as _e:
        _logging.warning(f"Re-export {__name__}.{_n} failed: {_e}")
