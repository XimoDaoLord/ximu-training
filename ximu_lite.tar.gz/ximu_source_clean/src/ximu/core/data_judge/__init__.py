# -*- coding: utf-8 -*-
__version__ = "0.5"
"""五重数据校验模块：真实性/完整性/相关性/时效性/一致性判断框架"""

from src.ximu.core.data_judge.authenticity import AuthenticityJudge, AuthenticityResult
# 注：completeness.py 动态导入 part1/part2 存在循环导入，会拖垮整个 data_judge 导入。
# 完整性判断改由 DataValidator.completeness() 客观打分，本地提供 CompletenessResult，
# 不再从 completeness.py 导入 CompletenessJudge。
from dataclasses import dataclass, field
from typing import List
@dataclass
class CompletenessResult:
    score: float = 0.0
    missing_fields: List[str] = field(default_factory=list)
    coverage: float = 0.0
    suggestions: List[str] = field(default_factory=list)
    def to_dict(self):
        return {"score": self.score, "missing_fields": self.missing_fields,
                "coverage": self.coverage, "suggestions": self.suggestions}
CompletenessJudge = None  # 旧类因循环导入不可用，占位避免外部 ImportError
from src.ximu.core.data_judge.relevance import RelevanceJudge, RelevanceResult
from src.ximu.core.data_judge.timeliness import TimelinessJudge, TimelinessResult
from src.ximu.core.data_judge.consistency import ConsistencyJudge, ConsistencyResult
from src.ximu.core.data_judge.value import ValueJudge, ValueResult

import logging
logger = logging.getLogger(__name__)

def __init__() -> None:
    """初始化五重校验模块"""
    pass

__all__ = [
    "AuthenticityJudge", "AuthenticityResult",
    "CompletenessJudge", "CompletenessResult",
    "RelevanceJudge", "RelevanceResult",
    "TimelinessJudge", "TimelinessResult",
    "ConsistencyJudge", "ConsistencyResult",
    "ValueJudge", "ValueResult"
]

class DataValidator:
    """统一数据校验入口，支持链式调用"""
    def __init__(self, data: dict) -> None:
        self.data = data
        self.results = []

    def __call__(self, *judges: tuple) -> list:
        """执行多维度校验
        Args:
            *judges: 校验器组合（ tuple[校验器类, 校验参数]...）
        Returns:
            校验结果列表（DataResult）
        """
        for judge, params in judges:
            self.results.append(judge(self.data, *params).to_dict())
        return self.results

    def authenticity(self, threshold: float = 0.8) -> AuthenticityResult:
        """执行真实性校验
        Args:
            threshold: 真实性阈值（0.0-1.0）
        Returns:
            AuthenticityResult
        """
        logger.info(f"启动真实性校验（阈值={threshold:.2f}）")
        return AuthenticityJudge(self.data, threshold).judge()

    def completeness(self, required: list = None) -> CompletenessResult:
        """执行完整性校验（客观确定性打分，0-100，非随机）。

        基于：必填字段是否齐备且非空、文本是否有足够长度与结构。
        Args:
            required: 必填字段列表
        Returns:
            CompletenessResult（score 为 0-100）
        """
        logger.info("启动完整性校验")
        required = required or ["text"]
        res = CompletenessResult()
        missing = [k for k in required
                   if not self.data.get(k) or not str(self.data.get(k)).strip()]
        res.missing_fields = missing
        score = 0.0
        # 必填字段齐备且非空：占 50 分
        if not missing:
            score += 50.0
        else:
            score += 50.0 * (len(required) - len(missing)) / max(len(required), 1)
        text = str(self.data.get("text", "") or "")
        # 文本长度充分：占 30 分
        if len(text.strip()) >= 200:
            score += 30.0
        elif len(text.strip()) >= 50:
            score += 20.0
        elif len(text.strip()) >= 10:
            score += 10.0
        # 有结构（换行/标点/分段）：占 20 分
        if any(ch in text for ch in ("\n", "。", "：", ":", "```")):
            score += 20.0
        res.score = round(score, 1)
        res.coverage = 1.0 if not missing else (
            (len(required) - len(missing)) / max(len(required), 1))
        return res

    def relevance(self, context: dict = None) -> RelevanceResult:
        """执行相关性校验
        Args:
            context: 校验上下文信息
        Returns:
            RelevanceResult
        """
        logger.info("启动相关性校验")
        return RelevanceJudge(self.data, context).judge()

    def timeliness(self, valid_time: int = 86400) -> TimelinessResult:
        """执行时效性校验
        Args:
            valid_time: 有效时长（秒）
        Returns:
            TimelinessResult
        """
        logger.info(f"启动时效性校验（有效时长={valid_time}秒）")
        return TimelinessJudge(self.data, valid_time).judge()

    def consistency(self, reference: dict = None) -> ConsistencyResult:
        """执行一致性校验
        Args:
            reference: 一致性参照标准
        Returns:
            ConsistencyResult
        """
        logger.info("启动一致性校验")
        return ConsistencyJudge(self.data, reference).judge()

    def value(self, rules: dict = None) -> ValueResult:
        """执行值域校验
        Args:
            rules: 值域规则字典
        Returns:
            ValueResult
        """
        logger.info("启动值域校验")
        return ValueJudge(self.data, rules).judge()
