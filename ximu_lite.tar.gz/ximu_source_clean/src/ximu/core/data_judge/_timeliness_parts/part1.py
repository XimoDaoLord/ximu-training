"""
时效性判断模块 - 第一部分
"""
import json
import time
import math
import threading
import asyncio
import logging
from typing import Any, Dict, List, Optional, Tuple, Callable, Union
from dataclasses import dataclass, asdict, fields
from datetime import datetime
from collections import defaultdict
from copy import deepcopy
import heapq
import statistics

from src.ximu.common.utils import generate_id

__version__ = "0.5"


def _setup_logger(name: str) -> logging.Logger:
    """
    设置并获取指定名称的 logger。

    Args:
        name: logger 的名称。

    Returns:
        配置好的 Logger 实例。
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        logger.propagate = False
    return logger


_logger: logging.Logger = _setup_logger(__name__)


@dataclass
class TimelinessResult:
    """
    时效性结果数据类

    Attributes:
        score: 综合时效性得分 (0.0 - 1.0)
        freshness: 新鲜度指标 (0.0 - 1.0)
        is_expired: 是否已过期
        age_seconds: 数据年龄（秒）
        decay_rate: 衰减率
    """

    score: float = 0.0
    freshness: float = 0.0
    is_expired: bool = False
    age_seconds: float = 0.0
    decay_rate: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """
        将 TimelinessResult 转换为字典。

        Returns:
            包含所有字段的字典。
        """
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TimelinessResult":
        """
        从字典创建 TimelinessResult 实例。

        Args:
            data: 包含字段数据的字典。

        Returns:
            TimelinessResult 实例。

        Raises:
            ValueError: 当包含未知键时警告但忽略。
        """
        valid_keys = {f.name for f in fields(cls)}
        filtered = {k: v for k, v in data.items() if k in valid_keys}
        if not filtered:
            _logger.debug("from_dict received no valid keys, using defaults")
        return cls(**filtered)


class _ItemStore:
    """
    通用线程安全项存储基类，消除重复代码。
    """

    def __init__(self, prefix: str) -> None:
        self._store: Dict[str, Dict[str, Any]] = {}
        self._stats: Dict[str, int] = defaultdict(int)
        self._lock = threading.Lock()
        self._prefix = prefix

    def _generate_id(self) -> str:
        """生成唯一项ID"""
        return generate_id(f"{self._prefix}_item")

    def _create_item(self, data: Dict[str, Any], stat_key: str) -> str:
        """创建并存储项"""
        if not isinstance(data, dict):
            raise TypeError("data must be a dictionary")

        item_id = self._generate_id()
        now = time.time()
        record = {
            "id": item_id,
            "data": data,
            "created_at": now,
            "updated_at": now,
            "version": 1,
        }

        with self._lock:
            self._store[item_id] = record
            self._stats[f"{stat_key}_created"] += 1
            _logger.debug(
                "Created %s item: %s, total: %d", self._prefix, item_id, len(self._store)
            )
        return item_id

    def _get_stats(self, stat_prefix: str) -> Dict[str, Union[int, float]]:
        """获取统计信息"""
        with self._lock:
            return {
                "total": len(self._store),
                "created": self._stats.get(f"{stat_prefix}_created", 0),
                "updated": self._stats.get(f"{stat_prefix}_updated", 0),
                "deleted": self._stats.get(f"{stat_prefix}_deleted", 0),
            }


class TimelinessJudge:
    """
    时效性判断器

    核心功能：评估数据的新鲜度、计算衰减分数、判断是否过期。
    """

    def __init__(self) -> None:
        self._item_store = _ItemStore("timelinessjudge")
        self._logger = logging.getLogger(f"{__name__}.TimelinessJudge")

    def create_timelinessjudge_item(self, data: Dict[str, Any]) -> str:
        """
        创建 TimelinessJudge item。

        Args:
            data: 要存储的数据。

        Returns:
            创建的项目 ID。

        Raises:
            TypeError: 当 data 不是字典时。
        """
        return self._item_store._create_item(data, "timelinessjudge_item")

    def get_timelinessjudge_item_stats(self) -> Dict[str, Union[int, float]]:
        """
        获取 TimelinessJudge item 统计信息。

        Returns:
            包含 total, created, updated, deleted 的字典。
        """
        return self._item_store._get_stats("timelinessjudge_item")

    def evaluate(
        self,
        data: Dict[str, Any],
        current_time: Optional[float] = None,
        ttl: float = 86400,
    ) -> TimelinessResult:
        """
        评估数据的时效性。

        Args:
            data: 数据字典。
            current_time: 当前时间戳，默认为 time.time()。
            ttl: 生存时间（秒），默认为 86400。

        Returns:
            TimelinessResult 对象。

        Raises:
            ValueError: 当 ttl 不是正数时。
            TypeError: 当提取的时间戳不是数字时。
        """
        if current_time is None:
            current_time = time.time()

        if not isinstance(ttl, (int, float)) or ttl <= 0:
            raise ValueError("ttl must be a positive number")

        timestamp = self._extract_timestamp(data)
        if timestamp is None:
            _logger.debug("No timestamp found in data, returning neutral result")
            return TimelinessResult(
                score=0.5,
                freshness=0.5,
                is_expired=False,
                age_seconds=0.0,
                decay_rate=0.0,
            )

        if not isinstance(timestamp, (int, float)):
            raise TypeError("extracted timestamp must be a number")

        age = current_time - timestamp
        if age < 0:
            # 处理未来时间戳或时钟偏移
            age = 0.0
            freshness = 1.0
            is_expired = False
            decay = 1.0
        else:
            freshness = max(0.0, 1.0 - (age / ttl))
            is_expired = age > ttl
            decay = self._exponential_decay(age, ttl)

        result = TimelinessResult(
            score=decay,
            freshness=freshness,
            is_expired=is_expired,
            age_seconds=age,
            decay_rate=decay,
        )
        _logger.debug(
            "Evaluation complete: age=%.2fs, decay=%.4f, expired=%s",
            age,
            decay,
            is_expired,
        )
        return result

    def _extract_timestamp(self, data: Dict[str, Any]) -> Optional[float]:
        """
        从数据中提取时间戳。

        按优先级尝试以下键：
        1. "timestamp"
        2. "created_at"

        Args:
            data: 数据字典。

        Returns:
            提取的时间戳（float），如果未找到则返回 None。
        """
        for key in ("timestamp", "created_at"):
            if key in data:
                ts = data[key]
                if isinstance(ts, (int, float)):
                    return float(ts)
        return None

    def _exponential_decay(self, age: float, ttl: float) -> float:
        """
        计算指数衰减。

        使用公式: exp(-age / ttl)，使得在 age=ttl 时衰减到 1/e ≈ 0.368。

        Args:
            age: 年龄（秒）。
            ttl: 生存时间（秒）。

        Returns:
            衰减后的分数 (0.0 - 1.0)。

        Raises:
            ValueError: 当 ttl <= 0 时。
        """
        if ttl <= 0:
            raise ValueError("ttl must be positive")
        if age <= 0:
            return 1.0
        return math.exp(-1.0 * age / ttl)


class TimestampAnalyzer:
    """
    时间戳分析器

    核心功能：分析时间戳序列的统计特性。
    """

    def __init__(self) -> None:
        self._item_store = _ItemStore("timestampanalyzer")
        self._logger = logging.getLogger(f"{__name__}.TimestampAnalyzer")

    def create_timestampanalyzer_item(self, data: Dict[str, Any]) -> str:
        """
        创建 TimestampAnalyzer item。

        Args:
            data: 要存储的数据。

        Returns:
            创建的项目 ID。

        Raises:
            TypeError: 当 data 不是字典时。
        """
        return self._item_store._create_item(data, "timestampanalyzer_item")

    def analyze(self, timestamps: List[float]) -> Dict[str, float]:
        """
        分析时间戳序列。

        Args:
            timestamps: 时间戳列表。

        Returns:
            包含统计信息的字典，包括:
            - count: 时间戳数量
            - first: 最早时间戳
            - last: 最晚时间戳
            - span: 时间跨度
            - avg_interval: 平均间隔
            - median_interval: 中位数间隔
            - std_interval: 间隔标准差

        Raises:
            TypeError: 当列表中包含非数字值时。
            ValueError: 当列表长度不足时。
        """
        if not timestamps:
            _logger.debug("Empty timestamps list, returning empty result")
            return {}

        if not all(isinstance(ts, (int, float)) for ts in timestamps):
            raise TypeError("all timestamps must be numbers")

        sorted_ts = sorted(timestamps)
        n = len(sorted_ts)

        if n == 1:
            result: Dict[str, float] = {
                "count": 1.0,
                "first": float(sorted_ts[0]),
                "last": float(sorted_ts[0]),
                "span": 0.0,
                "avg_interval": 0.0,
                "median_interval": 0.0,
                "std_interval": 0.0,
            }
            _logger.debug("Single timestamp analysis complete")
            return result

        intervals = [
            sorted_ts[i + 1] - sorted_ts[i] for i in range(n - 1)
        ]

        avg_interval = statistics.mean(intervals)
        median_interval = statistics.median(intervals)
        std_interval = (
            statistics.stdev(intervals) if len(intervals) > 1 else 0.0
        )

        result = {
            "count": float(n),
            "first": float(sorted_ts[0]),
            "last": float(sorted_ts[-1]),
            "span": float(sorted_ts[-1] - sorted_ts[0]),
            "avg_interval": float(avg_interval),
            "median_interval": float(median_interval),
            "std_interval": float(std_interval),
        }
        _logger.debug("Timestamp analysis complete: n=%d, span=%.2f", n, result["span"])
        return result


class FreshnessDecay:
    """
    新鲜度衰减计算器

    使用半衰期模型计算数据的时效性得分。
    """

    def calculate(self, age: float, half_life: float = 86400) -> float:
        """
        根据半衰期计算衰减分数。

        使用公式: 0.5 ** (age / half_life)

        Args:
            age: 年龄（秒）。
            half_life: 半衰期（秒），默认为 86400。

        Returns:
            衰减分数 (0.0 - 1.0)。

        Raises:
            ValueError: 当 age < 0 或 half_life <= 0 时。
        """
        if age < 0:
            raise ValueError("age must be non-negative")
        if half_life <= 0:
            raise ValueError("half_life must be positive")

        score = 0.5 ** (age / half_life)
        _logger.debug(
            "Freshness calculation: age=%.2f, half_life=%.2f, score=%.4f",
            age,
            half_life,
            score,
        )
        return score

    def decay_curve(
        self,
        max_age: float,
        points: int = 10,
        half_life: float = 86400,
    ) -> List[Tuple[float, float]]:
        """
        生成衰减曲线。

        Args:
            max_age: 最大年龄（秒）。
            points: 采样点数量，默认为 10。
            half_life: 半衰期（秒），默认为 86400。

        Returns:
            包含 (age, score) 元组的列表，长度为 points + 1。

        Raises:
            ValueError: 当参数无效时。
        """
        if max_age < 0:
            raise ValueError("max_age must be non-negative")
        if points < 0:
            raise ValueError("points must be non-negative")
        if half_life <= 0:
            raise ValueError("half_life must be positive")

        result: List[Tuple[float, float]] = []
        for i in range(points + 1):
            age = i * max_age / points
            score = self.calculate(age, half_life)
            result.append((age, score))

        _logger.debug(
            "Decay curve generated: points=%d, max_age=%.2f", points, max_age
        )
        return result
