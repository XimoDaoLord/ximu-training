"""Timeliness sub-module for data judgment.

This package provides utilities for determining the timeliness of data 
within the ximu core data judgment pipeline.
"""

__version__ = "0.5"

import logging

# Configure a module-level logger
logger = logging.getLogger(__name__)

__all__ = [
    "__version__",
    "logger",
]
