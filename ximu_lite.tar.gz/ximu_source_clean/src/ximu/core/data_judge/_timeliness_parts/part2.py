import json
import logging
import threading
import time
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple, Callable, Set, Iterator

from src.ximu.common.utils import generate_id

logger = logging.getLogger("src.ximu.core.data_judge._timeliness_parts.part2")

class TTLCache:
    """带TTL的线程安全缓存，支持过期淘汰和最大容量限制。"""
    
    def __init__(self, max_size: int = 10000, default_ttl: float = 300.0):
        """初始化TTL缓存。"""
        if max_size <= 0:
            raise ValueError("max_size must be positive")
        if default_ttl <= 0:
            raise ValueError("default_ttl must be positive")
            
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.RLock()
    
    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """设置缓存条目。"""
        if not key:
            raise ValueError("Cache key cannot be empty")
            
        effective_ttl = ttl if ttl is not None else self._default_ttl
        if effective_ttl <= 0:
            raise ValueError("TTL must be positive")

        with self._lock:
            self._cache[key] = {"value": value, "time": time.monotonic(), "ttl": effective_ttl}
            self._evict_if_needed()
    
    def get(self, key: str) -> Optional[Any]:
        """获取缓存值，自动清除过期条目。"""
        with self._lock:
            entry = self._cache.get(key)
            if entry:
                elapsed = time.monotonic() - entry["time"]
                if elapsed < entry["ttl"]:
                    return entry["value"]
                # 删除过期条目
                del self._cache[key]
        return None
    
    def invalidate(self, key: str) -> bool:
        """使指定缓存条目失效。"""
        with self._lock:
            return self._cache.pop(key, None) is not None
    
    def clear(self) -> int:
        """清空缓存。"""
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
        return count
    
    def size(self) -> int:
        """获取当前缓存大小。"""
        with self._lock:
            return len(self._cache)
    
    def max_size(self) -> int:
        """获取缓存最大容量。"""
        return self._max_size
    
    def _evict_if_needed(self) -> None:
        """当缓存超过最大容量时，移除最旧的条目。"""
        if len(self._cache) > self._max_size:
            # 找到时间戳最小的条目（最旧）
            oldest_key, oldest_entry = min(
                self._cache.items(), key=lambda x: x[1]["time"]
            )
            logger.debug("TTLCache evicted oldest entry: %s", oldest_key)
            del self._cache[oldest_key]

class ExpiryDetector:
    """过期检测器，管理数据项的存储、缓存和配置，提供过期检测能力。"""
    
    def __init__(self, cache_max_size: int = 10000, cache_default_ttl: float = 86400.0):
        """初始化过期检测器。"""
        self._item_store: Dict[str, Dict[str, Any]] = {}
        self._cache = TTLCache(max_size=cache_max_size, default_ttl=cache_default_ttl)
        self._metrics: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._config: Dict[str, Any] = {}
        self._default_config: Dict[str, Any] = {}
        self._config_version: int = 1
        self._event_handlers: Dict[str, Callable] = {}
        self._stats: Dict[str, int] = defaultdict(int)
        self._lock = threading.RLock()
        self._initialized: bool = False
        self._status: str = "idle"
        self._start_time: float = time.time()
        
        # 用于内部追踪缓存键的前缀，避免冲突
        self._cache_key_prefix = "exp_det_cache_"
    
    # ------------------------------------------------------------------
    # 数据项管理
    # ------------------------------------------------------------------
    
    def create_item(self, data: Dict[str, Any]) -> str:
        """创建数据项并存储。"""
        if not isinstance(data, dict):
            raise TypeError("Data must be a dictionary")
            
        item_id = generate_id("expiry_item")
        now = time.time()
        record: Dict[str, Any] = {
            "id": item_id,
            "data": data,
            "created_at": now,
            "updated_at": now,
            "version": 1,
        }
        with self._lock:
            self._item_store[item_id] = record
            self._stats["item_created"] += 1
        logger.debug("Created item: %s", item_id)
        return item_id
    
    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取数据项内容。"""
        with self._lock:
            record = self._item_store.get(item_id)
            if record:
                # 返回深拷贝以防止外部修改影响内部状态
                return copy.deepcopy(record["data"])
            return None
    
    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新数据项内容。"""
        if not isinstance(data, dict):
            raise TypeError("Update data must be a dictionary")

        with self._lock:
            if item_id in self._item_store:
                record = self._item_store[item_id]
                # 合并数据
                record["data"].update(data)
                record["updated_at"] = time.time()
                record["version"] += 1
                self._stats["item_updated"] += 1
                logger.debug("Updated item: %s, version: %d", item_id, record["version"])
                return True
        logger.debug("Update failed, item not found: %s", item_id)
        return False
    
    def delete_item(self, item_id: str) -> bool:
        """删除数据项。"""
        with self._lock:
            if item_id in self._item_store:
                del self._item_store[item_id]
                self._stats["item_deleted"] += 1
                logger.debug("Deleted item: %s", item_id)
                return True
        logger.debug("Delete failed, item not found: %s", item_id)
        return False
    
    def list_items(
        self, page: int = 1, page_size: int = 20, filters: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """分页列出数据项。"""
        if page < 1:
            raise ValueError("Page number must be >= 1")
        if page_size < 1:
            raise ValueError("Page size must be >= 1")

        with self._lock:
            items = list(self._item_store.values())
            
        # 应用过滤器
        if filters:
            items = [
                it for it in items
                if all(it["data"].get(k) == v for k, v in filters.items())
            ]
            
        total = len(items)
        start = (page - 1) * page_size
        end = start + page_size
        
        # 返回数据副本
        page_items = [copy.deepcopy(it["data"]) for it in items[start:end]]
        
        return {
            "items": page_items,
            "total": total,
            "page": page,
            "page_size": page_size,
        }
    
    def count_items(self) -> int:
        """统计数据项总数。"""
        with self._lock:
            return len(self._item_store)
    
    def search_items(
        self, query: str, fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """在指定字段中搜索数据项。"""
        if not query:
            return []
            
        results: List[Dict[str, Any]] = []
        query_lower = query.lower()
        
        with self._lock:
            for record in self._item_store.values():
                data = record["data"]
                if not data:
                    continue
                    
                search_fields = fields if fields is not None else list(data.keys())
                matched = False
                for field in search_fields:
                    val = data.get(field)
                    if val is None:
                        continue
                    val_str = str(val).lower()
                    if query_lower in val_str:
                        matched = True
                        break
                        
                if matched:
                    results.append(copy.deepcopy(data))
        return results
    
    def batch_create_items(self, batch: List[Dict[str, Any]]) -> List[str]:
        """批量创建数据项。"""
        return [self.create_item(item) for item in batch]
    
    def batch_delete_items(self, ids: List[str]) -> int:
        """批量删除数据项。"""
        count = 0
        for item_id in ids:
            if self.delete_item(item_id):
                count += 1
        return count
    
    def export_items(self, path: str) -> str:
        """导出数据项到JSON文件。"""
        with self._lock:
            data = [copy.deepcopy(list(self._item_store.values()))]
            
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data[0] if data else [], f, ensure_ascii=False, indent=2, default=str)
            
        logger.info("Exported %d items to %s", len(data[0]) if data else 0, path)
        return path
    
    def import_items(self, path: str) -> int:
        """从JSON文件导入数据项。"""
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            logger.error("Invalid JSON in import file %s: %s", path, e)
            raise
            
        count = 0
        for record in data:
            # 确保记录格式正确
            if not isinstance(record, dict) or "id" not in record or "data" not in record:
                continue
                
            item_id = record["id"]
            with self._lock:
                self._item_store[item_id] = record
            count += 1
            
        logger.info("Imported %d items from %s", count, path)
        return count
    
    def get_item_stats(self) -> Dict[str, Any]:
        """获取数据项统计信息。"""
        with self._lock:
            return {
                "total": len(self._item_store),
                "created": self._stats.get("item_created", 0),
                "updated": self._stats.get("item_updated", 0),
                "deleted": self._stats.get("item_deleted", 0),
            }
    
    # ------------------------------------------------------------------
    # 缓存管理
    # ------------------------------------------------------------------
    
    def get_cache(self, key: str) -> Optional[Any]:
        """获取缓存值。"""
        return self._cache.get(f"{self._cache_key_prefix}{key}")
    
    def set_cache(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """设置缓存条目。"""
        self._cache.set(f"{self._cache_key_prefix}{key}", value, ttl)
    
    def invalidate_cache(self, key: str) -> bool:
        """使缓存条目失效。"""
        return self._cache.invalidate(f"{self._cache_key_prefix}{key}")
    
    def clear_cache(self) -> int:
        """清空全部缓存。"""
        return self._cache.clear()
    
    def get_cache_stats(self) -> Dict[str, int]:
        """获取缓存统计信息。"""
        return {
            "size": self._cache.size(),
            "max_size": self._cache.max_size(),
        }
    
    # ------------------------------------------------------------------
    # 指标统计
    # ------------------------------------------------------------------
    
    def record_metric(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录指标值。"""
        with self._lock:
            # 使用JSON序列化作为键，确保一致性
            label_key = json.dumps(labels or {}, sort_keys=True)
            self._metrics[label_key].append(
                {"value": value, "time": time.time(), "labels": labels or {}}
            )
            # 限制每个指标组的存储数量
            if len(self._metrics[label_key]) > 10000:
                self._metrics[label_key] = self._metrics[label_key][-5000:]
    
    def get_metric_stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """获取指标统计值。"""
        with self._lock:
            label_key = json.dumps(labels or {}, sort_keys=True)
            values = [e["value"] for e in self._metrics.get(label_key, [])]
            
        if not values:
            return {"count": 0, "mean": 0, "min": 0, "max": 0, "p50": 0, "p95": 0, "p99": 0}
            
        sorted_vals = sorted(values)
        n = len(sorted_vals)
        
        def _percentile(p: float) -> float:
            """计算给定百分比的值。"""
            idx = min(int(n * p), n - 1)
            return sorted_vals[idx]
        
        return {
            "count": n,
            "mean": sum(values) / n,
            "min": sorted_vals[0],
            "max": sorted_vals[-1],
            "p50": _percentile(0.5),
            "p95": _percentile(0.95),
            "p99": _percentile(0.99),
        }
    
    # ------------------------------------------------------------------
    # 序列化与配置
    # ------------------------------------------------------------------
    
    def to_dict(self) -> Dict[str, Any]:
        """将检测器序列化为字典。"""
        with self._lock:
            return {
                "item_store": copy.deepcopy(self._item_store),
                "config": copy.deepcopy(self._config),
                "config_version": self._config_version,
                "stats": dict(self._stats),
                "metrics": {k: v for k, v in self._metrics.items()}, # 简化序列化，实际可省略
            }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ExpiryDetector":
        """从字典创建检测器实例。"""
        obj = cls()
        # 安全地恢复状态
        if "item_store" in data:
            obj._item_store = data["item_store"]
        if "config" in data:
            obj._config = data["config"]
        if "config_version" in data:
            obj._config_version = data["config_version"]
        if "stats" in data:
            # 重置stats为默认dict
            obj._stats = defaultdict(int, data["stats"])
        return obj
    
    def to_json(self, indent: int = 2) -> str:
        """将检测器序列化为JSON字符串。"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent, default=str)
    
    @classmethod
    def from_json(cls, text: str) -> "ExpiryDetector":
        """从JSON字符串创建检测器实例。"""
        try:
            data = json.loads(text)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON string: {e}")
        return cls.from_dict(data)
    
    def save(self, path: str) -> str:
        """保存检测器状态到文件。"""
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.to_json())
        logger.debug("ExpiryDetector saved to %s", path)
        return path
    
    @classmethod
    def load(cls, path: str) -> "ExpiryDetector":
        """从文件加载检测器状态。"""
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        return cls.from_json(content)
    
    def clone(self) -> "ExpiryDetector":
        """创建当前实例的深拷贝。"""
        return copy.deepcopy(self)
    
    def merge(self, other: "ExpiryDetector") -> "ExpiryDetector":
        """合并另一个检测器的非私有属性到当前实例。"""
        if not isinstance(other, ExpiryDetector):
            raise TypeError("Can only merge with ExpiryDetector instance")
            
        with self._lock:
            # 合并项存储
            self._item_store.update(copy.deepcopy(other._item_store))
            # 合并配置
            self._config.update(copy.deepcopy(other._config))
            # 合并统计信息（简化处理，仅累加计数）
            for k, v in other._stats.items():
                self._stats[k] += v
                
        logger.debug("Merged with another ExpiryDetector instance")
        return self
