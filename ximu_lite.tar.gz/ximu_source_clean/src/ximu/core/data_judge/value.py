from __future__ import annotations

import importlib
import logging
import warnings
from typing import Any, Dict, Optional

__version__ = "0.5"

logger = logging.getLogger(__name__)

warnings.warn(
    "value has been split, import from specific part",
    DeprecationWarning,
    stacklevel=2
)

_PART_NAMES: tuple[str, ...] = ("part1", "part2")

def reexport_part(part_name: str) -> None:
    """Dynamically re-export public symbols from a value part module."""
    module_path = f"._value_parts.{part_name}"
    try:
        module = importlib.import_module(module_path, package=__package__)
    except ImportError as exc:
        # 降级：不抛出，避免模块级导入失败导致DataValidator崩溃
        logger.debug("Failed to import %s (degraded): %s", module_path, exc)
        return

    # Re-export all public names (not starting with underscore)
    for name in dir(module):
        if not name.startswith("_"):
            globals()[name] = getattr(module, name)

    logger.debug("Successfully re-exported public symbols from %s", module_path)

# Perform re-exports for each part
for _part in _PART_NAMES:
    reexport_part(_part)