"""
数据完整性判断核心模块 - 第一部分

提供线程安全的数据存储、LRU缓存管理、指标记录、配置管理及事件总线组件，
并通过 CompletenessJudge 进行聚合封装，支持高并发下的数据生命周期管理。
"""

import json
import time
import threading
import logging
import os
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple, Callable, Iterator
from dataclasses import dataclass, field, asdict
from collections import OrderedDict

from src.ximu.common.utils import generate_id

logger = logging.getLogger(__name__)

@dataclass
class CompletenessResult:
    """
    数据完整性评估结果

    包含完整性得分、缺失字段列表、覆盖率及改进建议。
    支持序列化为字典和从字典反序列化，便于API传输或持久化。
    """
    score: float = 0.0
    missing_fields: List[str] = field(default_factory=list)
    coverage: float = 0.0
    suggestions: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """转换为标准字典格式"""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Any) -> "CompletenessResult":
        """从字典反序列化结果对象"""
        if not isinstance(data, dict):
            raise TypeError("Input must be a dictionary")
        valid_keys = set(cls.__dataclass_fields__.keys())
        filtered_data = {}
        for key, value in data.items():
            if key not in valid_keys:
                continue
            expected_type = cls.__dataclass_fields__[key].type
            if key in ("score", "coverage"):
                filtered_data[key] = float(value) if isinstance(value, (int, float)) else 0.0
            elif key in ("missing_fields", "suggestions"):
                filtered_data[key] = [str(item) for item in value] if isinstance(value, list) else []
            else:
                filtered_data[key] = value
        return cls(**filtered_data)

class ManageableComponent(ABC):
    """可管理组件抽象基类"""
    @abstractmethod
    def get_stats(self) -> Dict[str, Any]:
        """获取组件统计信息"""
        pass

    @abstractmethod
    def reset(self) -> None:
        """重置组件状态"""
        pass

class DataStorage(ManageableComponent):
    """线程安全的数据存储模块"""
    def __init__(self) -> None:
        self._items: Dict[str, Dict[str, Any]] = {}
        self._stats: Dict[str, int] = defaultdict(int)
        self._lock = threading.RLock()
        self._logger = logger

    def create_item(self, data: Dict[str, Any]) -> str:
        """创建新数据项"""
        if not data:
            raise ValueError("Data dictionary cannot be empty")
        with self._lock:
            item_id = generate_id("item")
            self._items[item_id] = {
                "id": item_id,
                "data": data,
                "created": time.time()
            }
            self._stats["created"] += 1
        self._logger.debug("Created item %s", item_id)
        return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取数据项"""
        with self._lock:
            record = self._items.get(item_id)
            return record["data"].copy() if record else None

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新数据项"""
        if not data:
            raise ValueError("Update data dictionary cannot be empty")
        with self._lock:
            record = self._items.get(item_id)
            if not record:
                self._logger.warning("Update failed: item %s not found", item_id)
                return False
            record["data"].update(data)
            record["updated"] = time.time()
            self._stats["updated"] += 1
        self._logger.debug("Updated item %s", item_id)
        return True

    def delete_item(self, item_id: str) -> bool:
        """删除数据项"""
        with self._lock:
            if item_id not in self._items:
                self._logger.warning("Delete failed: item %s not found", item_id)
                return False
            self._items.pop(item_id)
        self._logger.debug("Deleted item %s", item_id)
        return True

    def list_items(
        self,
        page: int = 1,
        page_size: int = 20,
        filters: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """分页查询数据项"""
        if page < 1:
            page = 1
        if page_size < 1:
            page_size = 20
        with self._lock:
            items = list(self._items.values())
            if filters:
                items = [it for it in items if all(it["data"].get(k) == v for k, v in filters.items())]
            total = len(items)
            start = (page - 1) * page_size
            result_items = [it["data"].copy() for it in items[start:start + page_size]]
        return {"items": result_items, "total": total, "page": page}

    def count_items(self) -> int:
        """统计数据量"""
        with self._lock:
            return len(self._items)

    def batch_create_items(self, items: List[Dict[str, Any]]) -> List[str]:
        """批量创建数据项"""
        for item in items:
            if not item:
                raise ValueError("Each item in batch must be non-empty dictionary")
        ids = []
        with self._lock:
            for item in items:
                item_id = generate_id("item")
                self._items[item_id] = {
                    "id": item_id,
                    "data": item,
                    "created": time.time()
                }
                self._stats["created"] += 1
                ids.append(item_id)
        self._logger.debug("Batch created %d items", len(ids))
        return ids

    def batch_delete_items(self, item_ids: List[str]) -> int:
        """批量删除数据项"""
        with self._lock:
            deleted = 0
            for item_id in item_ids:
                if item_id in self._items:
                    self._items.pop(item_id)
                    deleted += 1
        self._logger.debug("Batch deleted %d items", deleted)
        return deleted

    def export_items(self, path: str) -> str:
        """导出数据到JSON文件"""
        with self._lock:
            data = [dict(v) for v in self._items.values()]
        try:
            dir_name = os.path.dirname(path)
            if dir_name:
                os.makedirs(dir_name, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            self._logger.info("Exported %d items to %s", len(data), path)
        except IOError as e:
            self._logger.error("Export failed: %s", e)
            raise
        return path

    def import_items(self, path: str, overwrite: bool = False) -> int:
        """导入数据从JSON文件"""
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (IOError, json.JSONDecodeError) as e:
            self._logger.error("Import failed: %s", e)
            raise

        count = 0
        skipped = 0
        valid_record = {
            "id": str,
            "data": dict,
            "created": float,
            "updated": float
        }
        with self._lock:
            for record in data:
                if not isinstance(record, dict):
                    continue
                item_id = record.get("id") or generate_id("item")
                if item_id in self._items and not overwrite:
                    skipped += 1
                    continue
                if not all(k in record for k in valid_record):
                    self._logger.warning("Skipping invalid record: %s", record)
                    continue
                self._items[item_id] = record
                count += 1
        if skipped > 0:
            self._logger.info("Skipped %d existing items", skipped)
        self._logger.info("Imported %d items from %s", count, path)
        return count

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        with self._lock:
            return {
                "total": len(self._items),
                "created": self._stats.get("created", 0),
                "updated": self._stats.get("updated", 0)
            }

    def reset(self) -> None:
        """重置存储"""
        with self._lock:
            self._items.clear()
            self._stats = defaultdict(int)
            self._logger.info("Storage reset")

class CacheManager(ManageableComponent):
    """LRU缓存管理器"""
    def __init__(self, max_size: int = 10000, default_ttl: float = 300.0) -> None:
        self._cache: OrderedDict[str, Dict[str, Any]] = OrderedDict()
        self._max_size = max(1, max_size)
        self._default_ttl = max(0.0, default_ttl)
        self._lock = threading.RLock()
        self._logger = logger

    def get_cache(self, key: str) -> Optional[Any]:
        """获取缓存项"""
        with self._lock:
            entry = self._cache.get(key)
            if not entry:
                return None
            current_time = time.time()
            if current_time - entry["time"] >= entry["ttl"]:
                self._cache.pop(key)
                return None
            self._cache.move_to_end(key)
            return entry["value"]

    def set_cache(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """设置缓存项"""
        effective_ttl = self._default_ttl if ttl is None else max(0.0, ttl)
        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
            self._cache[key] = {
                "value": value,
                "time": time.time(),
                "ttl": effective_ttl
            }
            while len(self._cache) > self._max_size:
                self._cache.popitem(last=False)

    def clear_cache(self) -> int:
        """清空缓存"""
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
        self._logger.debug("Cleared %d entries", count)
        return count

    def get_stats(self) -> Dict[str, Any]:
        """获取缓存统计"""
        with self._lock:
            return {
                "size": len(self._cache),
                "max_size": self._max_size,
                "ttl_default": self._default_ttl
            }

    def reset(self) -> None:
        """重置缓存"""
        with self._lock:
            self._cache.clear()

class MetricRecorder(ManageableComponent):
    """指标记录器"""
    def __init__(self, max_records_per_key: int = 10000, trim_threshold: int = 5000) -> None:
        self._metrics: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._max_records = max(1, max_records_per_key)
        self._trim_threshold = max(1, min(trim_threshold, self._max_records))
        self._lock = threading.RLock()
        self._logger = logger

    @staticmethod
    def _make_key(labels: Optional[Dict[str, Any]]) -> str:
        """生成标签键"""
        return json.dumps(labels or {}, sort_keys=True, default=str)

    def record_metric(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录指标"""
        key = self._make_key(labels)
        with self._lock:
            self._metrics[key].append({"value": float(value), "time": time.time()})
            if len(self._metrics[key]) > self._max_records:
                self._metrics[key] = self._metrics[key][-self._trim_threshold:]

    def get_metric(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """获取聚合指标"""
        key = self._make_key(labels)
        with self._lock:
            values = [v["value"] for v in self._metrics.get(key, [])]
        if not values:
            return {
                "count": 0,
                "mean": 0.0,
                "min": 0.0,
                "max": 0.0,
                "p50": 0.0,
                "p95": 0.0,
                "p99": 0.0
            }
        sorted_values = sorted(values)
        count = len(sorted_values)
        return {
            "count": count,
            "mean": sum(sorted_values) / count,
            "min": sorted_values[0],
            "max": sorted_values[-1],
            "p50": self._percentile(sorted_values, 0.50),
            "p95": self._percentile(sorted_values, 0.95),
            "p99": self._percentile(sorted_values, 0.99)
        }

    @staticmethod
    def _percentile(sorted_values: List[float], percentile: float) -> float:
        """计算百分位"""
        if not sorted_values:
            return 0.0
        n = len(sorted_values)
        if n == 1:
            return sorted_values[0]
        percentile = max(0.0, min(1.0, percentile))
        rank = (n - 1) * percentile
        lower_idx = int(rank)
        upper_idx = min(lower_idx + 1, n - 1)
        weight = rank - lower_idx
        return sorted_values[lower_idx] + (sorted_values[upper_idx] - sorted_values[lower_idx]) * weight

    def get_stats(self) -> Dict[str, Any]:
        """获取统计"""
        with self._lock:
            return {
                "metric_keys": len(self._metrics),
                "total_records": sum(len(v) for v in self._metrics.values())
            }

    def reset(self) -> None:
        """重置指标"""
        with self._lock:
            self._metrics.clear()

class ConfigManager(ManageableComponent):
    """配置管理器"""
    def __init__(self) -> None:
        self._config = {}
        self._default_config = {}
        self._version = 1
        self._lock = threading.RLock()
        self._logger = logger

    def get_config(self, key: str, default: Any = None) -> Any:
        """获取配置"""
        with self._lock:
            return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """设置配置"""
        with self._lock:
            self._config[key] = value
            self._version += 1

    def get_all_config(self) -> Dict[str, Any]:
        """获取所有配置"""
        with self._lock:
            return dict(self._config)

    def update_config(self, updates: Dict[str, Any]) -> None:
        """批量更新配置"""
        with self._lock:
            self._config.update(updates)
            self._version += 1

    def reset_config(self) -> None:
        """重置配置"""
        with self._lock:
            self._config = dict(self._default_config)
            self._version = 1

    def get_stats(self) -> Dict[str, Any]:
        """获取统计"""
        with self._lock:
            return {
                "keys": len(self._config),
                "version": self._version
            }

    def set_default_config(self, defaults: Dict[str, Any]) -> None:
        """设置默认配置"""
        with self._lock:
            self._default_config = dict(defaults)

    def reset(self) -> None:
        """重置配置管理器"""
        with self._lock:
            self._config = {}
            self._version = 1

class EventBus(ManageableComponent):
    """事件总线"""
    def __init__(self) -> None:
        self._handlers: Dict[str, List[Callable[[Any], bool]]] = defaultdict(list)
        self._lock = threading.RLock()
        self._logger = logger

    def register_handler(self, handler: Callable[[Any], bool]) -> str:
        """注册处理器"""
        if not callable(handler):
            raise TypeError("Handler must be callable")
        handler_id = generate_id("handler")
        with self._lock:
            self._handlers[handler_id].append(handler)
        self._logger.debug("Registered handler %s", handler_id)
        return handler_id

    def unregister_handler(self, handler_id: str) -> bool:
        """注销处理器"""
        with self._lock:
            if handler_id in self._handlers:
                del self._handlers[handler_id]
                return True
        return False

    def dispatch_event(self, event: Any) -> bool:
        """发布事件"""
        success = False
        with self._lock:
            for handlers in self._handlers.values():
                for handler in handlers:
                    if not handler(event):
                        success = False
                        break
                if not success:
                    break
        self._logger.debug("Dispatched event %s", event)
        return success

    def get_stats(self) -> Dict[str, Any]:
        """获取统计"""
        with self._lock:
            return {
                "handler_count": sum(len(h) for h in self._handlers.values()),
                "total_events": 0
            }

    def reset(self) -> None:
        """重置事件总线"""
        with self._lock:
            self._handlers.clear()

class CompletenessJudge:
    """完整性判断器"""
    def __init__(self, storage: DataStorage, cache: CacheManager, metrics: MetricRecorder) -> None:
        self._storage = storage
        self._cache = cache
        self._metrics = metrics
        self._logger = logger

    def evaluate(self) -> CompletenessResult:
        """执行完整性评估"""
        self._cache.clear_cache()
        self._storage.reset()
        self._metrics.reset()
        self._cache.set_cache("data_count", self._storage.count_items(), ttl=3600)
        self._metrics.record_metric(1.0, labels={"system": "dataintegrity"})
        self._cache.set_cache("metric_p99", self._metrics.get_metric().get("p99", 0.0), ttl=3600)
        self._cache.set_cache("valid_records", self._check_valid_records(), ttl=3600)
        self._cache.set_cache("missing_fields", self._check_missing_fields(), ttl=3600)
        self._cache.set_cache("coverage", self._calculate_coverage(), ttl=3600)
        self._cache.set_cache("suggestions", self._generate_suggestions(), ttl=3600)
        self._cache.set_cache("version", 1, ttl=86400)

        result = CompletenessResult()
        with self._cache.get_cache("valid_records"):
            result.score = self._cache.get_cache("valid_records") * 0.4
        with self._cache.get_cache("missing_fields"):
            result.missing_fields = self._cache.get_cache("missing_fields")
        with self._cache.get_cache("coverage"):
            result.coverage = self._cache.get_cache("coverage")
        with self._cache.get_cache("suggestions"):
            result.suggestions = self._cache.get_cache("suggestions")
        with self._cache.get_cache("version"):
            pass

        self._storage.reset()
        self._cache.clear_cache()
        self._metrics.reset()
        return result

    def _check_valid_records(self) -> int:
        """检查有效记录数"""
        valid_count = 0
        with self._storage.get_stats() as stats:
            total = stats["total"]
            for _ in range(total):
                item = self._storage.get_item(generate_id("item"))
                if item:
                    valid_count += 1
        return valid_count

    def _check_missing_fields(self) -> List[str]:
        """检查缺失字段"""
        required_fields = ["id", "data", "created"]
        missing = []
        with self._storage.get_stats() as stats:
            for _ in range(stats["total"]):
                item = self._storage.get_item(generate_id("item"))
                if not item:
                    continue
                if not all(field in item for field in required_fields):
                    missing.extend([field for field in required_fields if field not in item])
        return list(set(missing))

    def _calculate_coverage(self) -> float:
        """计算覆盖率"""
        total = self._storage.count_items()
        valid = self._check_valid_records()
        return valid / total if total > 0 else 0.0

    def _generate_suggestions(self) -> List[str]:
        """生成改进建议"""
        suggestions = []
        if self._check_missing_fields():
            suggestions.append("补全缺失字段")
        if self._calculate_coverage() < 0.8:
            suggestions.append("优化数据采集质量")
        return suggestions
