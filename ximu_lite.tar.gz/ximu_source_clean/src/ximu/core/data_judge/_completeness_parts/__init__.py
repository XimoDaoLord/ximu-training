"""
数据完整性检查模块 - 版本0.5
功能：处理数据完整性验证与分割逻辑
"""

import logging
from typing import Any, Dict, List, Optional, Tuple

__version__ = "0.5.0"

class CompletenessJudge:
    """数据完整性判断核心组件
    
    负责数据完整性验证与分块处理
    """
    
    def __init__(self, data_config: Dict[str, Dict]) -> None:
        """初始化数据完整性配置
        
        Args:
            data_config: 数据完整性配置字典
                格式示例: {
                    "split规则": {"key1": "按日期", "key2": "按ID"},
                    "校验规则": {"必填字段": ["field1", "field2"]}
                }
        """
        self.config = data_config
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)
        self._init_log_handler()
    
    def _init_log_handler(self) -> None:
        """初始化日志处理器"""
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
    
    def split_data(
        self,
        raw_data: Dict[str, Any],
        split_key: str,
        split_value: Any
    ) -> Tuple[List[Dict], bool]:
        """数据分块处理
        
        根据配置规则对原始数据进行分块
        若分块失败返回空列表
        
        Args:
            raw_data: 原始数据字典
            split_key: 分块键名
            split_value: 分块键值
        
        Returns:
            (分块数据列表, 是否成功)
        
        Raises:
            ValueError: 分块键不存在配置中
        """
        if split_key not in self.config.get("split规则", {}):
            self.logger.error(f"无效分块键: {split_key}")
            raise ValueError("分块键未在配置中定义")
        
        self.logger.info(f"开始分块数据 - 键: {split_key} 值: {split_value}")
        split规则 = self.config["split规则"]
        target_key = split规则[split_key]
        
        try:
            split_data = []
            for item in raw_data.values():
                if item[target_key] == split_value:
                    split_data.append(item)
            return split_data, True
        except KeyError as e:
            self.logger.error(f"数据缺失字段: {e}")
            return [], False
        except Exception as e:
            self.logger.error(f"分块异常: {str(e)}")
            return [], False
    
    def check_completeness(
        self,
        data_part: Dict[str, Any],
        required_fields: List[str]
    ) -> bool:
        """数据完整性校验
        
        检查数据块是否包含所有必填字段
        
        Args:
            data_part: 数据分块
            required_fields: 必填字段列表
        
        Returns:
            是否完整
        
        Raises:
            TypeError: required_fields非列表类型
        """
        if not isinstance(required_fields, list):
            self.logger.error("无效校验参数类型")
            raise TypeError("required_fields必须为列表")
        
        self.logger.info(f"开始完整性校验 - 需要字段: {required_fields}")
        missing = [f for f in required_fields if f not in data_part]
        if missing:
            self.logger.error(f"缺失字段: {', '.join(missing)}")
            return False
        self.logger.info("数据完整性验证通过")
        return True
