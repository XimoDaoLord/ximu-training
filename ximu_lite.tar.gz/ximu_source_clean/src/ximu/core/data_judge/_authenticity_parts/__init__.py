"""
Split parts of authenticity into manageable components.
"""

from typing import List

class AuthenticityPart:
    """表示一个真实性部分的类。

    Attributes:
        part_id (int): 真实性部分的唯一标识符。
        content (str): 真实性部分的内容。
    """
    def __init__(self, part_id: int, content: str) -> None:
        """初始化一个真实性部分。

        Args:
            part_id (int): 真实性部分的唯一标识符。
            content (str): 真实性部分的内容。
        """
        self.part_id = part_id
        self.content = content

    def __str__(self) -> str:
        """返回真实性部分的字符串表示形式。"""
        return f"AuthenticityPart(part_id={self.part_id}, content='{self.content}')"

def split_authenticity_parts(authenticity_data: str) -> List[AuthenticityPart]:
    """将真实性数据分割成多个部分。

    Args:
        authenticity_data (str): 真实性数据。

    Returns:
        List[AuthenticityPart]: 分割后的真实性部分列表。
    """
    parts = authenticity_data.split(';')
    return [AuthenticityPart(i, part) for i, part in enumerate(parts, start=1)]
