"""伪造检测器核心模块 - 数据管理、缓存、指标统计与配置中心。

本模块提供线程安全的伪造检测器实现，支持完整的数据生命周期管理、
本地缓存、性能指标采集、配置持久化及事件驱动机制。
"""

from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from collections import defaultdict, deque
from contextlib import contextmanager
from dataclasses import dataclass, asdict
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import redis

logger = logging.getLogger(__name__)

# 定义常量
DEFAULT_TTL: int = 86400
MAX_HISTORY_SIZE: int = 5000
DEFAULT_PAGE_SIZE: int = 20
MAX_ITEMS_TO_FETCH: int = 1000
CACHE_MAX_SIZE: int = 10000
CACHE_DEFAULT_TTL: float = 300.0


def generate_id(prefix: str = "item") -> str:
    """生成唯一标识符

    Args:
        prefix: 标识符前缀

    Returns:
        格式化的唯一ID字符串
    """
    timestamp = int(time.time() * 1000000)
    unique = uuid.uuid4().hex[:8]
    return f"{prefix}_{timestamp}_{unique}"


@dataclass
class DetectionItem:
    """检测项数据模型

    存储单个检测项的完整信息，包含唯一ID、数据内容、
    创建/更新时间戳以及版本号。
    """
    id: str
    data: Dict[str, Any]
    created_at: float
    updated_at: float
    version: int

    def to_dict(self) -> Dict[str, Any]:
        """将数据类转换为字典，便于JSON序列化"""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> DetectionItem:
        """从字典创建检测项实例

        Args:
            data: 包含检测项字段的字典

        Returns:
            DetectionItem 实例
        """
        return cls(**data)


class ItemRepository:
    """伪造检测项数据访问层，提供线程安全CRUD与索引管理

    负责检测项的创建、查询、更新、删除及倒排索引维护，
    支持分页、过滤与批量操作。
    """

    def __init__(self, redis_client: redis.Redis) -> None:
        """初始化数据存储、索引和统计结构

        Args:
            redis_client: 共享的Redis客户端实例
        """
        self._client = redis_client
        self._index: Dict[Tuple[str, str], List[str]] = defaultdict(list)
        self._stats: Dict[str, int] = {"created": 0, "updated": 0, "deleted": 0}
        self._lock = threading.RLock()
        self._tx_ops: List[str] = []

    @contextmanager
    def transaction(self) -> List[str]:
        """原子事务上下文管理器

        支持在事务块内记录操作类型，finally块中统一提交统计。
        Yields:
            用于记录操作类型的列表
        """
        self._tx_ops.clear()
        try:
            yield self._tx_ops
        finally:
            self._stats["updated"] += self._tx_ops.count("update")
            self._stats["deleted"] += self._tx_ops.count("delete")
            self._tx_ops.clear()

    def create(self, data: Dict[str, Any]) -> str:
        """创建新检测项

        Args:
            data: 检测项数据字典

        Returns:
            新创建项的唯一ID
        """
        now = time.time()
        item = DetectionItem(
            id=generate_id("item"),
            data=data,
            created_at=now,
            updated_at=now,
            version=1
        )
        with self._lock:
            self._client.setex(f"item:{item.id}", DEFAULT_TTL, json.dumps(item.to_dict()))
            self._build_index(item)
            self._stats["created"] += 1
        return item.id

    def get(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取检测项数据

        Args:
            item_id: 检测项ID

        Returns:
                检测项数据字典，不存在时返回None
        """
        with self._lock:
            item_str = self._client.get(f"item:{item_id}")
            if item_str:
                return json.loads(item_str)
            return None

    def update(self, item_id: str, updates: Dict[str, Any]) -> bool:
        """更新检测项

        Args:
            item_id: 检测项ID
            updates: 要更新的字段字典

        Returns:
            更新成功返回True，否则返回False
        """
        with self._lock:
            item_str = self._client.get(f"item:{item_id}")
            if not item_str:
                return False
            item = json.loads(item_str)
            old_data = item.get("data", {}).copy()
            item["data"].update(updates)
            item["updated_at"] = time.time()
            item["version"] += 1
            self._client.setex(f"item:{item_id}", DEFAULT_TTL, json.dumps(item))
            self._update_index(item_id, old_data, item["data"])
            self._stats["updated"] += 1
            return True

    def delete(self, item_id: str) -> bool:
        """删除检测项

        Args:
            item_id: 检测项ID

        Returns:
            删除成功返回True，否则返回False
        """
        with self._lock:
            if not self._client.exists(f"item:{item_id}"):
                return False
            self._client.delete(f"item:{item_id}")
            self._delete_index(item_id)
            self._stats["deleted"] += 1
            return True

    def list_items(
        self,
        page: int = 1,
        page_size: int = DEFAULT_PAGE_SIZE,
        filters: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """分页查询检测项

        Args:
            page: 页码，从1开始
            page_size: 每页数量
            filters: 过滤条件字典

        Returns:
            包含items、total、page、page_size的分页结果
        """
        with self._lock:
            # 简化实现：使用SCAN代替LRange以避免阻塞，或者假设所有ID都在一个集合中
            # 原实现使用 LRange 但 key 是 "items:all" 而创建时并未插入列表，这里修正为遍历键或保持原逻辑但修正逻辑错误
            # 为了兼容原逻辑假设，我们假设存在一个全局列表或我们需要扫描。
            # 鉴于原代码逻辑缺陷（create未写入items:all），我们改为直接过滤键空间，这是更稳健的做法
            pattern = "item:*"
            items = []
            cursor = 0
            while True:
                cursor, keys = self._client.scan(cursor=cursor, match=pattern, count=100)
                for key in keys:
                    item_str = self._client.get(key)
                    if item_str:
                        items.append(json.loads(item_str))
                if cursor == 0:
                    break
                if len(items) >= MAX_ITEMS_TO_FETCH:
                    break

        if filters:
            items = [
                item for item in items
                if all(item.get("data", {}).get(k) == v for k, v in filters.items())
            ]
        total = len(items)
        start = (page - 1) * page_size
        return {
            "items": items[start:start + page_size],
            "total": total,
            "page": page,
            "page_size": page_size
        }

    def search(
        self,
        query: str,
        fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """基于倒排索引的模糊搜索

        Args:
            query: 搜索关键词
            fields: 限定搜索字段，None表示搜索所有字段

        Returns:
            匹配的检测项数据列表
        """
        if not query:
            return []
        query_lower = query.lower()
        results: List[Dict[str, Any]] = []
        seen_ids: set = set()

        with self._lock:
            for (field, value), item_ids in self._index.items():
                if fields and field not in fields:
                    continue
                if query_lower in value:
                    for item_id in item_ids:
                        if item_id in seen_ids:
                            continue
                        item_str = self._client.get(f"item:{item_id}")
                        if item_str and query_lower in str(item_str).lower():
                            results.append(json.loads(item_str))
                            seen_ids.add(item_id)
        return results

    def _build_index(self, item: DetectionItem) -> None:
        """构建倒排索引"""
        for field, value in item.data.items():
            key: Tuple[str, str] = (field, str(value).lower())
            self._index[key].append(item.id)

    def _update_index(self, item_id: str, old_data: Dict[str, Any], new_data: Dict[str, Any]) -> None:
        """更新倒排索引（增量更新）"""
        # 移除旧索引
        for field, old_val in old_data.items():
            key: Tuple[str, str] = (field, str(old_val).lower())
            if item_id in self._index[key]:
                self._index[key].remove(item_id)
                if not self._index[key]:
                    del self._index[key]
        
        # 添加新索引
        for field, new_val in new_data.items():
            key: Tuple[str, str] = (field, str(new_val).lower())
            self._index[key].append(item_id)

    def _delete_index(self, item_id: str) -> None:
        """清理索引记录"""
        keys_to_remove: List[Tuple[str, str]] = []
        for key, ids in list(self._index.items()):
            if item_id in ids:
                ids.remove(item_id)
                if not ids:
                    keys_to_remove.append(key)
        for key in keys_to_remove:
            del self._index[key]


class RedisLRUCache:
    """Redis近似LRU缓存实现

    使用ZSET存储访问时间，支持配置化连接与自动过期。
    """

    def __init__(self, config: Dict[str, Any]) -> None:
        """初始化Redis连接和缓存参数

        Args:
            config: Redis连接配置字典，包含host、port、db等
        """
        self._client = redis.Redis(
            host=config.get("host", "localhost"),
            port=config.get("port", 6379),
            db=config.get("db", 0),
            decode_responses=True
        )
        self._max_size: int = CACHE_MAX_SIZE
        self._ttl: float = CACHE_DEFAULT_TTL
        self._lock = threading.RLock()
        logger.info("Redis缓存初始化完成")

    def get(self, key: str) -> Optional[str]:
        """获取缓存值

        Args:
            key: 缓存键

        Returns:
            缓存值字符串，不存在或过期时返回None
        """
        with self._lock:
            data_key = f"cache:{key}:data"
            time_key = "cache:times"

            if not self._client.exists(data_key):
                return None

            data_str = self._client.get(data_key)
            if not data_str:
                return None

            score = self._client.zscore(time_key, key)
            if score is None or time.time() - score >= self._ttl:
                self._client.delete(data_key, time_key)
                return None

            # 刷新访问时间
            self._client.zincrby(time_key, 0, key) 
            # 注意: 通常LRU是更新访问顺序，这里使用 ZINCRBY 0 不会改变分数，如果需要LRU语义应该 ZADD NX/CH 或 ZINCRBY 增加量
            # 为了简单维持原逻辑近似，我们这里假设 get 不刷新时间戳或者使用固定过期
            # 原代码逻辑是 zscore 获取旧时间，判断是否过期。
            # 为了支持 LRU 近似，通常需要在 get 时更新 score。
            self._client.zadd(time_key, {key: time.time()}, nx=False) # 刷新时间
            
            return data_str

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """设置缓存值

        Args:
            key: 缓存键
            value: 缓存值
            ttl: 过期时间（秒），None时使用默认值
        """
        with self._lock:
            data_key = f"cache:{key}:data"
            time_key = "cache:times"
            cache_ttl = ttl if ttl is not None else self._ttl

            data_str = json.dumps(value)
            now = time.time()

            self._client.setex(data_key, int(cache_ttl), data_str)
            self._client.zadd(time_key, {key: now})

            if self._client.zcard(time_key) > self._max_size:
                self._prune_old(time_key)

    def invalidate(self, key: str) -> bool:
        """使缓存项失效

        Args:
            key: 缓存键

        Returns:
            失效成功返回True，键不存在返回False
        """
        with self._lock:
            data_key = f"cache:{key}:data"
            time_key = "cache:times"

            if not self._client.exists(data_key):
                return False

            self._client.delete(data_key)
            self._client.zrem(time_key, key)
            return True

    def clear(self) -> int:
        """清空缓存

        Returns:
            删除的键数量
        """
        with self._lock:
            keys = self._client.keys("cache:*:data")
            count = 0
            for data_key in keys:
                # 提取 key 部分用于 zrem
                # data_key 格式: cache:{key}:data
                raw_key = data_key.split("cache:")[1].rsplit(":data", 1)[0]
                time_key = "cache:times"
                self._client.delete(data_key)
                self._client.zrem(time_key, raw_key)
                count += 1
            return count

    def _prune_old(self, time_key: str) -> None:
        """定期清理过期缓存"""
        with self._lock:
            if self._client.zcard(time_key) <= self._max_size:
                return

            # 移除最旧的超出限制的部分
            trim_count = self._client.zcard(time_key) - self._max_size
            # 获取最旧的 N 个成员
            oldest_members = self._client.zrange(time_key, 0, trim_count - 1, withscores=False)
            for key in oldest_members:
                data_key = f"cache:{key}:data"
                self._client.delete(data_key, time_key)

    @property
    def client(self) -> redis.Redis:
        """获取Redis客户端实例"""
        return self._client


class MetricsCollector:
    """性能指标收集器

    使用deque存储历史记录，支持分位数统计与时间范围查询。
    """

    def __init__(self, max_history: int = MAX_HISTORY_SIZE) -> None:
        """初始化指标收集器

        Args:
            max_history: 最大历史记录数
        """
        self._max_history: int = max_history
        self._metrics: Dict[str, deque] = defaultdict(
            lambda: deque(maxlen=max_history)
        )
        self._lock = threading.RLock()
        logger.debug("MetricsCollector初始化完成")

    def record(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录指标值

        Args:
            value: 指标数值
            labels: 标签字典，用于区分不同维度的指标
        """
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True)
            self._metrics[key].append((time.time(), value))

    def get_stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, float]:
        """获取统计指标

        Args:
            labels: 标签字典，用于查询特定维度的统计

        Returns:
            包含count、mean、min、max、p50、p95、p99的统计字典
        """
        with self._lock:
            key = json.dumps(labels or {}, sort_keys=True)
            records = list(self._metrics.get(key, []))

        if not records:
            return {
                "count": 0.0, "mean": 0.0, "min": 0.0, "max": 0.0,
                "p50": 0.0, "p95": 0.0, "p99": 0.0
            }

        sorted_vals = sorted(r[1] for r in records)
        n = len(sorted_vals)

        def percentile(p: float) -> float:
            if n == 1:
                return sorted_vals[0]
            k = (n - 1) * p
            f = int(k)
            c = f + 1
            if c >= n:
                return sorted_vals[n - 1]
            return sorted_vals[f] + (sorted_vals[c] - sorted_vals[f]) * (k - f)

        return {
            "count": float(n),
            "mean": sum(sorted_vals) / n,
            "min": sorted_vals[0],
            "max": sorted_vals[-1],
            "p50": percentile(0.50),
            "p95": percentile(0.95),
            "p99": percentile(0.99)
        }


class ConfigManager:
    """配置管理器，负责配置的加载、保存与版本控制。"""

    def __init__(self) -> None:
        """初始化配置管理器，加载默认配置。"""
        self._config: Dict[str, Any] = {
            "version": "0.5",
            "threshold": 0.5,
            "cache_ttl": CACHE_DEFAULT_TTL,
            "max_items": 10000
        }
        self._lock = threading.RLock()

    def get(self, key: str, default: Optional[Any] = None) -> Any:
        """获取配置项

        Args:
            key: 配置键
            default: 键不存在时的默认值

        Returns:
            配置值
        """
        with self._lock:
            return self._config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """设置配置项

        Args:
            key: 配置键
            value: 配置值
        """
        with self._lock:
            self._config[key] = value

    def reload(self) -> None:
        """重新加载配置（占位实现）"""
        logger.info("配置重新加载")


class EventEmitter:
    """事件发射器，支持订阅和发布事件。"""

    def __init__(self) -> None:
        """初始化事件发射器，注册订阅关系。"""
        self._subscribers: Dict[str, List[Callable]] = defaultdict(list)
        self._lock = threading.RLock()

    def subscribe(self, event_type: str, callback: Callable) -> None:
        """订阅事件

        Args:
            event_type: 事件类型
            callback: 回调函数
        """
        with self._lock:
            self._subscribers[event_type].append(callback)

    def publish(self, event_type: str, data: Any) -> None:
        """发布事件

        Args:
            event_type: 事件类型
            data: 事件数据
        """
        with self._lock:
            for callback in self._subscribers.get(event_type, []):
                try:
                    callback(data)
                except Exception as e:
                    logger.error(f"事件处理错误: {event_type}, 错误: {e}")


class ForgeryDetector:
    """伪造检测器主类，整合数据访问、缓存、指标、配置与事件系统。"""

    def __init__(self, redis_client: redis.Redis, config: Dict[str, Any]) -> None:
        """初始化伪造检测器

        Args:
            redis_client: Redis客户端实例
            config: 配置字典
        """
        self.repo = ItemRepository(redis_client)
        self.cache = RedisLRUCache(config)
        self.metrics = MetricsCollector()
        self.config_mgr = ConfigManager()
        self.event_emitter = EventEmitter()
        self._initialized: bool = False
        self._status: str = "idle"
        self._start_time: float = 0.0
        self._threshold: float = config.get("threshold", 0.5)
        self._lock = threading.RLock()
        logger.info("ForgeryDetector初始化完成")

    def initialize(self) -> bool:
        """初始化检测器

        Returns:
            初始化成功返回True
        """
        with self._lock:
            if self._initialized:
                return True
            try:
                self._start_time = time.time()
                self._initialized = True
                self._status = "running"
                logger.info("检测器初始化完成")
                return True
            except Exception as e:
                self._status = "error"
                logger.error(f"初始化失败: {str(e)}")
                return False

    def shutdown(self) -> bool:
        """关闭检测器

        Returns:
            关闭成功返回True
        """
        with self._lock:
            if not self._initialized:
                return True
            try:
                self._initialized = False
                self._status = "stopped"
                logger.info("检测器已关闭")
                return True
            except Exception as e:
                logger.error(f"关闭失败: {str(e)}")
                return False

    def restart(self) -> bool:
        """重启检测器

        Returns:
            重启成功返回True
        """
        self.shutdown()
        time.sleep(0.1)
        return self.initialize()

    def get_status(self) -> str:
        """获取检测器状态

        Returns:
            当前状态字符串
        """
        return self._status

    def is_healthy(self) -> bool:
        """检查健康状态

        Returns:
            健康返回True
        """
        return self._initialized and self._status != "error"

    def get_uptime(self) -> float:
        """获取运行时间（秒）

        Returns:
            运行秒数
        """
        if not self._initialized:
            return 0.0
        return time.time() - self._start_time
