"""
数据真实性判断核心模块
提供基于内存的数据真实性判断服务，包含项目CRUD、LRU缓存、指标记录和配置管理
"""
import json
import time
import threading
import logging
from typing import Any, Dict, List, Optional, Tuple, Union, Callable
from dataclasses import dataclass, field, asdict
from collections import OrderedDict, defaultdict
from datetime import datetime
import os
import uuid
import statistics
import copy
import gzip
import io

# 默认配置常量
DEFAULT_CACHE_MAX_SIZE: int = 10000
DEFAULT_CACHE_TTL: float = 300.0
DEFAULT_METRICS_MAX_HISTORY: int = 10000
DEFAULT_METRICS_RETENTION_WINDOW: int = 5000
CONFIG_COMPRESSION: str = "gzip"

# 全局日志记录器
_LOGGER = logging.getLogger("authenticity_core")
if not _LOGGER.handlers:
    _HANDLER = logging.StreamHandler()
    _FORMATTER = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    _HANDLER.setFormatter(_FORMATTER)
    _LOGGER.addHandler(_HANDLER)
    _LOGGER.setLevel(logging.INFO)


def _generate_id(prefix: str) -> str:
    """生成带前缀的唯一ID
    
    Args:
        prefix: ID前缀
        
    Returns:
        唯一的字符串ID
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


@dataclass
class AuthenticityResult:
    """真实性判断结果数据类
    
    Attributes:
        score: 真实性评分 (0.0-1.0)
        verified: 是否已验证
        sources: 数据来源列表
        conflicts: 冲突列表
        method: 判断方法
    """
    score: float = 0.0
    verified: bool = False
    sources: List[str] = field(default_factory=list)
    conflicts: List[str] = field(default_factory=list)
    method: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典
        
        Returns:
            包含所有字段的字典
        """
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuthenticityResult":
        """从字典创建实例
        
        Args:
            data: 包含字段数据的字典
            
        Returns:
            AuthenticityResult实例
        """
        valid_keys = set(cls.__dataclass_fields__.keys())
        filtered = {k: v for k, v in data.items() if k in valid_keys}
        return cls(**filtered)


class LRUCache:
    """带TTL的线程安全LRU缓存实现
    
    使用OrderedDict实现O(1)的最近最少使用淘汰策略，支持过期条目自动清理
    """

    def __init__(self, max_size: int = DEFAULT_CACHE_MAX_SIZE, default_ttl: float = DEFAULT_CACHE_TTL) -> None:
        """初始化LRU缓存
        
        Args:
            max_size: 最大缓存条目数
            default_ttl: 默认缓存生存时间（秒）
        """
        if max_size <= 0:
            raise ValueError("max_size must be positive")
        self._cache: OrderedDict[str, Tuple[Any, float, float]] = OrderedDict()
        self._max_size: int = max_size
        self._default_ttl: float = default_ttl
        self._lock: threading.RLock = threading.RLock()
        self._hits: int = 0
        self._misses: int = 0
        self._logger = _LOGGER

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值
        
        Args:
            key: 缓存键
            
        Returns:
            缓存值，如果不存在或已过期则返回None
        """
        with self._lock:
            if key not in self._cache:
                self._misses += 1
                return None
            
            value, timestamp, ttl = self._cache[key]
            current_age = time.monotonic() - timestamp
            
            if current_age >= ttl:
                # 删除过期条目
                del self._cache[key]
                self._misses += 1
                self._logger.debug(f"Cache expired for key: {key}")
                return None
            
            # 命中，移动到末尾
            self._hits += 1
            self._cache.move_to_end(key)
            return value

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """设置缓存值
        
        Args:
            key: 缓存键
            value: 缓存值
            ttl: 生存时间，如果为None则使用默认值
        """
        if ttl is not None and ttl < 0:
            raise ValueError("ttl must be non-negative")
        
        effective_ttl = self._default_ttl if ttl is None else ttl
        with self._lock:
            # 如果键已存在，先删除以正确移动位置
            if key in self._cache:
                del self._cache[key]
            
            self._cache[key] = (value, time.monotonic(), effective_ttl)
            
            # 清理过期条目（可选优化，避免内存浪费）
            self._purge_expired()
            
            # 如果超过最大大小，淘汰最久未使用的
            if len(self._cache) > self._max_size:
                self._cache.popitem(last=False)

    def _purge_expired(self) -> int:
        """清理所有过期条目
        
        Returns:
            被清除的过期条目数量
        """
        purged = 0
        now = time.monotonic()
        expired_keys = [
            k for k, (_, ts, ttl) in self._cache.items()
            if now - ts >= ttl
        ]
        for key in expired_keys:
            del self._cache[key]
            purged += 1
        
        if purged > 0:
            self._logger.debug(f"Purged {purged} expired cache entries")
        return purged

    def invalidate(self, key: str) -> bool:
        """使指定键的缓存失效
        
        Args:
            key: 缓存键
            
        Returns:
            如果键存在并被删除则返回True
        """
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                return True
            return False

    def clear(self) -> int:
        """清空缓存
        
        Returns:
            被清除的条目数量
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
            self._hits = 0
            self._misses = 0
            self._logger.debug(f"Cache cleared, {count} entries removed")
            return count

    def get_stats(self) -> Dict[str, Any]:
        """获取缓存统计信息
        
        Returns:
            包含size, max_size, hits, misses, hit_rate的字典
        """
        with self._lock:
            # 先清理过期条目以获得准确统计
            self._purge_expired()
            
            size = len(self._cache)
            total = self._hits + self._misses
            hit_rate = (self._hits / total * 100) if total > 0 else 0.0
            return {
                "size": size,
                "max_size": self._max_size,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": round(hit_rate, 2)
            }

    def __len__(self) -> int:
        """返回缓存条目数量"""
        with self._lock:
            return len(self._cache)

    def __contains__(self, key: str) -> bool:
        """检查键是否在缓存中且未过期
        
        Args:
            key: 缓存键
            
        Returns:
            如果键存在且未过期则返回True
        """
        with self._lock:
            if key not in self._cache:
                return False
            
            value, timestamp, ttl = self._cache[key]
            if time.monotonic() - timestamp < ttl:
                # 更新访问顺序
                self._cache.move_to_end(key)
                return True
            else:
                # 删除过期条目
                del self._cache[key]
                return False


def _percentile(sorted_list: List[float], percentile: float) -> float:
    """计算给定百分位值
    
    Args:
        sorted_list: 已排序的浮点数列表
        percentile: 百分位 (0.0-1.0)
        
    Returns:
        百分位对应的值
    """
    if not sorted_list:
        return 0.0
    
    n = len(sorted_list)
    if n == 1:
        return sorted_list[0]
    
    # 使用线性插值计算百分位
    rank = percentile * (n - 1)
    lower_rank = int(rank)
    upper_rank = lower_rank + 1
    fraction = rank - lower_rank
    
    if upper_rank >= n:
        return sorted_list[-1]
    
    lower_val = sorted_list[lower_rank]
    upper_val = sorted_list[upper_rank]
    
    return lower_val + fraction * (upper_val - lower_val)


class MetricsStore:
    """指标存储和统计计算
    
    基于标签分组存储指标值，支持百分位计算
    """

    def __init__(self, max_history: int = DEFAULT_METRICS_MAX_HISTORY, retention_window: int = DEFAULT_METRICS_RETENTION_WINDOW) -> None:
        """初始化指标存储
        
        Args:
            max_history: 每个标签组合的最大历史记录数
            retention_window: 超出最大历史时保留的最新记录数
        """
        if max_history <= 0:
            raise ValueError("max_history must be positive")
        if retention_window < 0 or retention_window > max_history:
            raise ValueError("retention_window must be between 0 and max_history")
        
        self._data: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._max_history: int = max_history
        self._retention_window: int = retention_window
        self._lock: threading.RLock = threading.RLock()
        self._logger = _LOGGER

    def _key_from_labels(self, labels: Optional[Dict[str, Any]]) -> str:
        """从标签生成缓存键
        
        Args:
            labels: 标签字典
            
        Returns:
            JSON字符串作为键
        """
        return json.dumps(labels or {}, sort_keys=True)

    def record(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录指标值
        
        Args:
            value: 指标数值
            labels: 标签字典
        """
        key = self._key_from_labels(labels)
        entry: Dict[str, Any] = {
            "value": value,
            "time": time.time(),
            "labels": dict(labels) if labels else {}
        }
        
        with self._lock:
            bucket = self._data[key]
            bucket.append(entry)
            
            if len(bucket) > self._max_history:
                # 保留最新的retention_window条记录
                del bucket[:-self._retention_window]
                self._logger.debug(f"Metrics bucket {key} exceeded max_history, trimmed to {self._retention_window}")

    def get_stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """计算指标统计
        
        Args:
            labels: 标签字典
            
        Returns:
            包含count, mean, min, max, p50, p95, p99的字典
        """
        key = self._key_from_labels(labels)
        
        with self._lock:
            # 在锁内获取副本，避免竞态条件
            entries = list(self._data.get(key, []))
        
        if not entries:
            return {
                "count": 0,
                "mean": 0.0,
                "min": 0.0,
                "max": 0.0,
                "p50": 0.0,
                "p95": 0.0,
                "p99": 0.0
            }
        
        values = [e["value"] for e in entries]
        sorted_vals = sorted(values)
        n = len(sorted_vals)
        
        return {
            "count": n,
            "mean": statistics.mean(values),
            "min": min(values),
            "max": max(values),
            "p50": _percentile(sorted_vals, 0.5),
            "p95": _percentile(sorted_vals, 0.95),
            "p99": _percentile(sorted_vals, 0.99)
        }

    def get_history(self, labels: Optional[Dict[str, Any]] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """获取指标历史记录
        
        Args:
            labels: 标签字典
            limit: 返回的最大记录数
            
        Returns:
            最近的历史记录列表
        """
        if limit <= 0:
            return []
        
        key = self._key_from_labels(labels)
        
        with self._lock:
            entries = list(self._data.get(key, []))
        
        return entries[-limit:]

    def reset(self) -> None:
        """重置所有指标数据"""
        with self._lock:
            self._data.clear()
            self._logger.debug("Metrics store reset")


class ConfigManager:
    """配置管理器
    
    线程安全的配置读写，支持版本跟踪和压缩导出
    """

    def __init__(self, default_config: Optional[Dict[str, Any]] = None) -> None:
        """初始化配置管理器
        
        Args:
            default_config: 默认配置字典
        """
        self._config: Dict[str, Any] = copy.deepcopy(default_config) if default_config else {}
        self._default_config: Dict[str, Any] = copy.deepcopy(default_config) if default_config else {}
        self._version: int = 1
        self._lock: threading.RLock = threading.RLock()
        self._logger = _LOGGER

    def get(self, key: str, default: Any = None) -> Any:
        """获取配置值
        
        Args:
            key: 配置键
            default: 默认值
            
        Returns:
            配置值或默认值
        """
        with self._lock:
            return self._config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """设置配置值
        
        Args:
            key: 配置键
            value: 配置值
        """
        with self._lock:
            self._config[key] = value
            self._version += 1

    def get_all(self) -> Dict[str, Any]:
        """获取所有配置的副本
        
        Returns:
            配置字典的深拷贝
        """
        with self._lock:
            return copy.deepcopy(self._config)

    def update(self, updates: Dict[str, Any]) -> None:
        """批量更新配置
        
        Args:
            updates: 要更新的配置字典
        """
        with self._lock:
            self._config.update(copy.deepcopy(updates))
            self._version += 1

    def reset(self) -> None:
        """重置为默认配置"""
        with self._lock:
            self._config = copy.deepcopy(self._default_config)
            self._version += 1
            self._logger.debug("Config reset to defaults")

    def get_version(self) -> int:
        """获取配置版本号
        
        Returns:
            当前版本号
        """
        return self._version

    def export(self, path: str) -> str:
        """导出配置到压缩文件
        
        在锁内获取配置快照，在锁外执行文件I/O操作以避免长时间持锁
        
        Args:
            path: 目标文件路径
            
        Returns:
            文件路径
            
        Raises:
            IOError: 文件写入失败时
        """
        with self._lock:
            # 在锁内获取配置的深拷贝快照，保证一致性
            snapshot = copy.deepcopy(self._config)
        
        try:
            with gzip.open(path, "wb") as f:
                json.dump(snapshot, f, ensure_ascii=False, indent=2)
            self._logger.info(f"Config exported to {path}")
        except (IOError, OSError) as e:
            self._logger.error(f"Failed to export config: {e}")
            raise
        
        return path

    def import_config(self, path: str) -> bool:
        """从压缩文件导入配置
        
        在锁外读取文件，在锁内更新配置
        
        Args:
            path: 源文件路径
            
        Returns:
            导入成功返回True，失败返回False
        """
        try:
            with gzip.open(path, "rb") as f:
                raw_data = f.read()
            data = json.loads(raw_data)
            
            if not isinstance(data, dict):
                raise ValueError("Config file must contain a JSON object")
            
            with self._lock:
                self._config.update(copy.deepcopy(data))
                self._version += 1
                self._logger.info(f"Config imported from {path}, version: {self._version}")
            
            return True
            
        except (IOError, OSError) as e:
            self._logger.warning(f"Failed to read config file: {e}")
            return False
        except json.JSONDecodeError as e:
            self._logger.warning(f"Invalid JSON in config file: {e}")
            return False
        except ValueError as e:
            self._logger.warning(f"Invalid config structure: {e}")
            return False


class EventManager:
    """事件管理器
    
    管理事件的注册、注销和触发
    """

    def __init__(self) -> None:
        """初始化事件管理器"""
        self._handlers: Dict[str, Callable[[Any], None]] = {}
        self._lock: threading.RLock = threading.RLock()
        self._logger = _LOGGER

    def on(self, handler: Callable[[Any], None]) -> str:
        """注册事件处理器
        
        Args:
            handler: 事件回调函数
            
        Returns:
            处理器ID
        """
        if not callable(handler):
            raise TypeError("Handler must be callable")
        
        handler_id = _generate_id("handler")
        with self._lock:
            self._handlers[handler_id] = handler
            self._logger.debug(f"Handler registered: {handler_id}")
        
        return handler_id

    def off(self, handler_id: str) -> bool:
        """移除事件处理器
        
        Args:
            handler_id: 处理器ID
            
        Returns:
            如果处理器存在并被移除则返回True
        """
        with self._lock:
            if handler_id in self._handlers:
                del self._handlers[handler_id]
                self._logger.debug(f"Handler removed: {handler_id}")
                return True
            return False

    def emit(self, data: Any = None) -> int:
        """触发事件
        
        Args:
            data: 传递给处理器的事件数据
            
        Returns:
            成功调用的处理器数量
        """
        with self._lock:
            # 获取处理器的副本，避免在调用期间修改字典
            handlers = list(self._handlers.values())
        
        count = 0
        for handler in handlers:
            try:
                handler(data)
                count += 1
            except Exception as e:
                self._logger.warning(f"Event handler error: {e}")
        
        return count

    def get_handler_count(self) -> int:
        """获取处理器数量
        
        Returns:
            当前注册的处理器数量
        """
        with self._lock:
            return len(self._handlers)

    def clear(self) -> None:
        """清空所有处理器"""
        with self._lock:
            count = len(self._handlers)
            self._handlers.clear()
            if count > 0:
                self._logger.debug(f"Event handlers cleared ({count} removed)")


class AuthenticityJudge:
    """真实性判断器
    
    提供数据真实性判断的核心服务，整合项目存储、缓存、指标和配置管理
    """

    def __init__(
        self,
        cache_max_size: int = DEFAULT_CACHE_MAX_SIZE,
        cache_default_ttl: float = DEFAULT_CACHE_TTL,
        metrics_max_history: int = DEFAULT_METRICS_MAX_HISTORY,
        metrics_retention_window: int = DEFAULT_METRICS_RETENTION_WINDOW
    ) -> None:
        """初始化真实性判断器
        
        Args:
            cache_max_size: 缓存最大条目数
            cache_default_ttl: 缓存默认生存时间
            metrics_max_history: 指标最大历史数
            metrics_retention_window: 指标保留窗口
        """
        self._item_store: Dict[str, Dict[str, Any]] = {}
        self._stats: Dict[str, int] = defaultdict(int)
        self._lock: threading.RLock = threading.RLock()
        self._logger = _LOGGER

        self._cache = LRUCache(
            max_size=cache_max_size,
            default_ttl=cache_default_ttl
        )
        self._metrics = MetricsStore(
            max_history=metrics_max_history,
            retention_window=metrics_retention_window
        )
        self._config_manager = ConfigManager()
        self._event_manager = EventManager()

        self._initialized: bool = False
        self._status: str = "idle"
        self._start_time: float = 0.0
        self._state_history: List[Tuple[str, float]] = []
        self._current_state: str = "idle"

    # ==================== 项目CRUD ====================

    def create_item(self, data: Dict[str, Any]) -> str:
        """创建项目
        
        Args:
            data: 项目数据
            
        Returns:
            新创建项目的ID
            
        Raises:
            TypeError: 如果data不是字典
        """
        if not isinstance(data, dict):
            raise TypeError("data must be a dictionary")
        
        item_id = _generate_id("item")
        record = {
            "id": item_id,
            "data": copy.deepcopy(data),
            "created_at": time.time(),
            "updated_at": time.time(),
            "version": 1
        }
        
        with self._lock:
            self._item_store[item_id] = record
            self._stats["items_created"] += 1
        
        self._logger.debug(f"Created item: {item_id}")
        return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取项目数据
        
        Args:
            item_id: 项目ID
            
        Returns:
            项目数据字典的深拷贝，如果不存在则返回None
        """
        with self._lock:
            record = self._item_store.get(item_id)
        
        if record:
            return copy.deepcopy(record["data"])
        return None

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新项目数据
        
        Args:
            item_id: 项目ID
            data: 要更新的数据
            
        Returns:
            更新成功返回True，项目不存在返回False
            
        Raises:
            TypeError: 如果data不是字典
        """
        if not isinstance(data, dict):
            raise TypeError("data must be a dictionary")
        
        with self._lock:
            if item_id in self._item_store:
                record = self._item_store[item_id]
                record["data"].update(copy.deepcopy(data))
                record["updated_at"] = time.time()
                record["version"] += 1
                self._stats["items_updated"] += 1
                return True
        
        self._logger.warning(f"Attempted to update non-existent item: {item_id}")
        return False

    def delete_item(self, item_id: str) -> bool:
        """删除项目
        
        Args:
            item_id: 项目ID
            
        Returns:
            删除成功返回True，项目不存在返回False
        """
        with self._lock:
            if item_id in self._item_store:
                del self._item_store[item_id]
                self._stats["items_deleted"] += 1
                self._logger.debug(f"Deleted item: {item_id}")
                return True
            return False

    def list_items(
        self,
        page: int = 1,
        page_size: int = 20,
        filters: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """列出项目（分页）
        
        Args:
            page: 页码（从1开始）
            page_size: 每页大小
            filters: 过滤条件字典
            
        Returns:
            包含items, total, page, page_size的字典
            
        Raises:
            ValueError: 如果page或page_size小于1
        """
        if page < 1:
            raise ValueError("page must be >= 1")
        if page_size < 1:
            raise ValueError("page_size must be >= 1")
        
        with self._lock:
            items = [copy.deepcopy(r["data"]) for r in self._item_store.values()]
        
        if filters:
            items = [
                it for it in items
                if all(it.get(k) == v for k, v in filters.items())
            ]
        
        total = len(items)
        start = (page - 1) * page_size
        end = start + page_size
        
        return {
            "items": items[start:end],
            "total": total,
            "page": page,
            "page_size": page_size
        }

    def count_items(self) -> int:
        """统计项目数量
        
        Returns:
            当前存储的项目总数
        """
        with self._lock:
            return len(self._item_store)

    def search_items(
        self,
        query: str,
        fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """搜索项目
        
        Args:
            query: 搜索查询（不区分大小写）
            fields: 要搜索的字段列表，None表示搜索所有字段
            
        Returns:
            匹配的项目数据列表（深拷贝）
        """
        if not query or not isinstance(query, str):
            return []
        
        results: List[Dict[str, Any]] = []
        query_lower = query.lower()
        seen_ids: set = set()
        
        with self._lock:
            records = [copy.deepcopy(r) for r in self._item_store.values()]
        
        for record in records:
            data = record["data"]
            item_id = record["id"]
            
            # 避免重复添加同一项目
            if item_id in seen_ids:
                continue
            
            search_fields = fields if fields else list(data.keys())
            matched = False
            
            for f in search_fields:
                val = str(data.get(f, "")).lower()
                if query_lower in val:
                    matched = True
                    break
            
            if matched:
                seen_ids.add(item_id)
                results.append(copy.deepcopy(data))
        
        return results

    def batch_create_items(self, batch: List[Dict[str, Any]]) -> List[str]:
        """批量创建项目
        
        Args:
            batch: 项目数据列表
            
        Returns:
            新创建项目的ID列表
            
        Raises:
            TypeError: 如果batch中包含非字典元素
        """
        if not isinstance(batch, list):
            raise TypeError("batch must be a list")
        
        ids: List[str] = []
        with self._lock:
            for item in batch:
                if not isinstance(item, dict):
                    raise TypeError("Each item in batch must be a dictionary")
                item_id = _generate_id("item")
                record = {
                    "id": item_id,
                    "data": copy.deepcopy(item),
                    "created_at": time.time(),
                    "updated_at": time.time(),
                    "version": 1
                }
                self._item_store[item_id] = record
                ids.append(item_id)
            self._stats["items_created"] += len(ids)
        
        self._logger.debug(f"Batch created {len(ids)} items")
        return ids

    def batch_delete_items(self, ids: List[str]) -> int:
        """批量删除项目
        
        Args:
            ids: 项目ID列表
            
        Returns:
            成功删除的项目数量
        """
        if not isinstance(ids, list):
            raise TypeError("ids must be a list")
        
        count = 0
        with self._lock:
            for item_id in ids:
                if item_id in self._item_store:
                    del self._item_store[item_id]
                    count += 1
            
            if count > 0:
                self._stats["items_deleted"] += count
        
        self._logger.debug(f"Batch deleted {count} items")
        return count

    def clear_all_items(self) -> int:
        """清除所有项目
        
        Returns:
            被清除的项目数量
        """
        with self._lock:
            count = len(self._item_store)
            self._item_store.clear()
            if count > 0:
                self._stats["items_deleted"] += count
                self._logger.debug(f"Clear all: removed {count} items")
            return count

    # ==================== 缓存操作代理 ====================

    def cache_set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """设置缓存值
        
        Args:
            key: 缓存键
            value: 缓存值
            ttl: 生存时间
        """
        self._cache.set(key, value, ttl)

    def cache_get(self, key: str) -> Optional[Any]:
        """获取缓存值
        
        Args:
            key: 缓存键
            
        Returns:
            缓存值或None
        """
        return self._cache.get(key)

    def cache_clear(self) -> int:
        """清空缓存
        
        Returns:
            被清除的条目数量
        """
        return self._cache.clear()

    # ==================== 指标操作代理 ====================

    def record_metric(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录指标值
        
        Args:
            value: 指标数值
            labels: 标签字典
        """
        self._metrics.record(value, labels)

    def get_metric_stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """获取指标统计
        
        Args:
            labels: 标签字典
            
        Returns:
            统计结果字典
        """
        return self._metrics.get_stats(labels)

    # ==================== 配置管理代理 ====================

    def get_config(self, key: str, default: Any = None) -> Any:
        """获取配置值
        
        Args:
            key: 配置键
            default: 默认值
            
        Returns:
            配置值
        """
        return self._config_manager.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """设置配置值
        
        Args:
            key: 配置键
            value: 配置值
        """
        self._config_manager.set(key, value)

    def export_config(self, path: str) -> str:
        """导出配置到文件
        
        Args:
            path: 目标文件路径
            
        Returns:
            文件路径
        """
        return self._config_manager.export(path)

    def import_config(self, path: str) -> bool:
        """从文件导入配置
        
        Args:
            path: 源文件路径
            
        Returns:
            导入成功返回True
        """
        return self._config_manager.import_config(path)

    # ==================== 事件管理代理 ====================

    def on_event(self, handler: Callable[[Any], None]) -> str:
        """注册事件处理器
        
        Args:
            handler: 事件回调函数
            
        Returns:
            处理器ID
        """
        return self._event_manager.on(handler)

    def off_event(self, handler_id: str) -> bool:
        """移除事件处理器
        
        Args:
            handler_id: 处理器ID
            
        Returns:
            移除成功返回True
        """
        return self._event_manager.off(handler_id)

    def emit_event(self, data: Any = None) -> int:
        """触发事件
        
        Args:
            data: 事件数据
            
        Returns:
            成功调用的处理器数量
        """
        return self._event_manager.emit(data)

    # ==================== 状态管理 ====================

    def get_status(self) -> str:
        """获取当前状态
        
        Returns:
            状态字符串
        """
        return self._current_state

    def get_stats_summary(self) -> Dict[str, Any]:
        """获取统计摘要
        
        Returns:
            包含各项统计指标的字典
        """
        with self._lock:
            stats_copy = dict(self._stats)
        
        return {
            "items": {
                "total": self.count_items(),
                "created": stats_copy.get("items_created", 0),
                "updated": stats_copy.get("items_updated", 0),
                "deleted": stats_copy.get("items_deleted", 0)
            },
            "cache": self._cache.get_stats(),
            "version": self._config_manager.get_version()
        }

    def __repr__(self) -> str:
        """返回对象的字符串表示"""
        item_count = self.count_items()
        return f"<AuthenticityJudge items={item_count} status={self._current_state}>"
