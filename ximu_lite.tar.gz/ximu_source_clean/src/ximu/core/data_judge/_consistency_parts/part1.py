# -*- coding: utf-8 -*-
"""一致性判断模块：五重判断之一致性判断。

检查数据在多源、多时间点、多维度上的一致性，发现矛盾数据。
"""
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union

__version__ = "0.5"


def _setup_logger(name: str) -> logging.Logger:
    """设置日志记录器。

    Args:
        name: 日志记录器的名称。

    Returns:
        配置好的日志记录器实例。
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


@dataclass
class ConsistencyResult:
    """一致性判断结果。

    Attributes:
        item_id: 唯一标识符。
        is_consistent: 是否一致。
        consistency_score: 一致性得分（0.0 到 1.0）。
        conflicts: 发现的冲突列表。
        checked_fields: 检查的字段列表。
        data_sources: 数据来源列表。
        checked_at: 检查时间戳。
        details: 详细信息字典。
    """
    item_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    is_consistent: bool = True
    consistency_score: float = 1.0
    conflicts: List[Dict[str, Any]] = field(default_factory=list)
    checked_fields: List[str] = field(default_factory=list)
    data_sources: List[str] = field(default_factory=list)
    checked_at: float = field(default_factory=time.time)
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典。

        Returns:
            包含所有字段的字典表示。
        """
        return {
            "item_id": self.item_id,
            "is_consistent": self.is_consistent,
            "consistency_score": self.consistency_score,
            "conflicts": self.conflicts,
            "checked_fields": self.checked_fields,
            "data_sources": self.data_sources,
            "checked_at": self.checked_at,
            "details": self.details,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConsistencyResult":
        """从字典创建实例。

        Args:
            data: 包含字段的字典。

        Returns:
            ConsistencyResult 实例。
        """
        valid_keys = set(cls.__dataclass_fields__.keys())
        filtered_data = {k: v for k, v in data.items() if k in valid_keys}
        return cls(**filtered_data)


class ConsistencyJudge:
    """一致性判断器：五重判断之一，检查数据多源一致性。

    Attributes:
        _logger: 日志记录器。
        _items: 存储一致性判断条目的字典。
        _cache: 缓存字典。
        _check_count: 检查次数计数器。
    """

    def __init__(self) -> None:
        """初始化一致性判断器。"""
        self._logger = _setup_logger("consistency_judge")
        self._items: Dict[str, Dict[str, Any]] = {}
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._check_count: int = 0

    def create_consistencyjudge_item(self, data: Dict[str, Any]) -> str:
        """创建一致性判断条目。

        Args:
            data: 条目数据。

        Returns:
            条目的唯一标识符。

        Raises:
            TypeError: 如果 data 不是字典类型。
        """
        if not isinstance(data, dict):
            raise TypeError("data must be a dictionary")

        item_id = data.get("item_id", str(uuid.uuid4()))
        self._items[item_id] = {**data, "item_id": item_id, "created_at": time.time()}
        self._logger.debug("Created item with id: %s", item_id)
        return item_id

    def get_consistencyjudge_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取一致性判断条目。

        Args:
            item_id: 条目标识符。

        Returns:
            条目数据，如果不存在则返回 None。
        """
        return self._items.get(item_id)

    def update_consistencyjudge_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """更新一致性判断条目。

        Args:
            item_id: 条目标识符。
            data: 更新数据。

        Returns:
            如果更新成功返回 True，否则返回 False。
        """
        if item_id not in self._items:
            self._logger.warning("Attempted to update non-existent item: %s", item_id)
            return False
        self._items[item_id].update(data)
        self._items[item_id]["updated_at"] = time.time()
        self._logger.debug("Updated item with id: %s", item_id)
        return True

    def delete_consistencyjudge_item(self, item_id: str) -> bool:
        """删除一致性判断条目。

        Args:
            item_id: 条目标识符。

        Returns:
            如果删除成功返回 True，否则返回 False。
        """
        if item_id in self._items:
            del self._items[item_id]
            self._logger.debug("Deleted item with id: %s", item_id)
            return True
        else:
            self._logger.warning("Attempted to delete non-existent item: %s", item_id)
            return False

    def list_consistencyjudge_items(self, page: int = 1, page_size: int = 20,
                                    filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """列出一致性判断条目。

        Args:
            page: 页码（从1开始）。
            page_size: 每页大小。
            filters: 过滤条件字典。

        Returns:
            包含分页结果的字典。

        Raises:
            ValueError: 如果 page 或 page_size 小于 1。
        """
        if page < 1:
            raise ValueError("page must be at least 1")
        if page_size < 1:
            raise ValueError("page_size must be at least 1")

        items = list(self._items.values())
        if filters:
            for key, value in filters.items():
                items = [i for i in items if i.get(key) == value]

        start = (page - 1) * page_size
        end = start + page_size
        return {
            "items": items[start:end],
            "total": len(items),
            "page": page,
            "page_size": page_size,
        }

    def count_consistencyjudge_items(self) -> int:
        """统计条目数量。

        Returns:
            条目总数。
        """
        return len(self._items)

    def check_consistency(self, data_records: List[Dict[str, Any]],
                          fields: Optional[List[str]] = None) -> ConsistencyResult:
        """检查多条数据记录的一致性。

        Args:
            data_records: 要检查的数据记录列表。
            fields: 要检查的字段列表，如果为 None 则检查所有字段。

        Returns:
            ConsistencyResult 对象。

        Raises:
            TypeError: 如果 data_records 不是列表或包含非字典元素。
        """
        self._check_count += 1

        if not isinstance(data_records, list):
            raise TypeError("data_records must be a list")
        if not all(isinstance(r, dict) for r in data_records):
            raise TypeError("All elements in data_records must be dictionaries")

        if not data_records:
            return ConsistencyResult(is_consistent=True, consistency_score=1.0)

        if len(data_records) == 1:
            return ConsistencyResult(
                is_consistent=True,
                consistency_score=1.0,
                checked_fields=fields or list(data_records[0].keys())
            )

        # 确定要检查的字段
        if fields is None:
            all_fields = sorted(set().union(*(r.keys() for r in data_records)))
        else:
            all_fields = fields

        conflicts: List[Dict[str, Any]] = []
        total_checks = 0

        for field_name in all_fields:
            values = [r.get(field_name) for r in data_records if field_name in r]
            if len(values) <= 1:
                continue

            total_checks += 1
            unique_values = set(str(v) for v in values)
            if len(unique_values) > 1:
                conflicts.append({
                    "field": field_name,
                    "values": values,
                    "description": f"字段 {field_name} 在 {len(values)} 条记录中存在 {len(unique_values)} 个不同值",
                })

        consistency_score = 1.0 - (len(conflicts) / max(1, total_checks))
        return ConsistencyResult(
            is_consistent=len(conflicts) == 0,
            consistency_score=round(consistency_score, 4),
            conflicts=conflicts,
            checked_fields=all_fields,
            data_sources=[r.get("_source", "unknown") for r in data_records],
        )

    def get_consistencyjudge_item_stats(self) -> Dict[str, Any]:
        """获取统计信息。

        Returns:
            包含统计信息的字典。
        """
        return {
            "total_items": len(self._items),
            "check_count": self._check_count,
            "cache_size": len(self._cache),
        }

    def get_consistencyjudge_cache(self, key: str) -> Optional[Any]:
        """获取缓存值。

        Args:
            key: 缓存键。

        Returns:
            缓存值，如果不存在或已过期则返回 None。
        """
        cached_item = self._cache.get(key)
        if cached_item is None:
            return None

        expires_at = cached_item.get("expires_at", 0)
        if time.time() > expires_at:
            del self._cache[key]
            return None

        return cached_item.get("value")

    def set_consistencyjudge_cache(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """设置缓存值。

        Args:
            key: 缓存键。
            value: 要缓存的值。
            ttl: 生存时间（秒），默认 300 秒。

        Raises:
            ValueError: 如果 ttl 为负数。
        """
        if ttl < 0:
            raise ValueError("ttl must be non-negative")

        self._cache[key] = {
            "value": value,
            "expires_at": time.time() + ttl,
        }
        self._logger.debug("Cached item with key: %s, ttl: %.1f", key, ttl)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConsistencyJudge":
        """从字典创建 ConsistencyJudge 实例。

        Args:
            data: 包含状态数据的字典。

        Returns:
            恢复状态的 ConsistencyJudge 实例。
        """
        instance = cls()
        if "items" in data:
            instance._items = data["items"]
        if "cache" in data:
            instance._cache = data["cache"]
        if "check_count" in data:
            instance._check_count = data["check_count"]
        return instance

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典。

        Returns:
            包含内部状态的字典表示。
        """
        return {
            "items": self._items,
            "cache": self._cache,
            "check_count": self._check_count
        }


class BaseConsistencyChecker:
    """基础一致性检查器。"""
    def __init__(self):
        pass
