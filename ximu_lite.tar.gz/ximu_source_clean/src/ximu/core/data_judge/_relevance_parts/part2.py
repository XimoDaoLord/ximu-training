"""
相关性重排器数据管理与缓存模块。
"""

import asyncio
import json
import pickle
import statistics
import threading
import time
from collections import defaultdict, OrderedDict
from copy import deepcopy
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Tuple

from src.ximu.common.utils import generate_id
from .part1 import _setup_logger

class RelevanceRanker:
    """
    相关性重排器，提供数据管理、缓存、指标、配置和事件系统。
    """

    def __init__(self) -> None:
        """
        初始化重排器，设置存储、缓存、指标、配置、事件及状态字段。
        """
        self._item_store: Dict[str, Dict[str, Any]] = {}
        self._cache: "OrderedDict[str, Dict[str, Any]]" = OrderedDict()
        self._max_cache_size: int = 10000
        self._metrics: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._stats: "defaultdict[str, int]" = defaultdict(int)
        self._config: Dict[str, Any] = {}
        self._default_config: Dict[str, Any] = {}
        self._config_version: int = 1
        self._evt_handlers: Dict[str, Callable] = {}
        self._initialized: bool = False
        self._status: str = "idle"
        self._start_time: float = 0.0
        self._stages: List[str] = []
        self._queue: List[Any] = []
        self._total_enqueued: int = 0
        self._total_dequeued: int = 0
        self._registry: Dict[str, Any] = {}
        self._valid_states: List[str] = ['idle', 'running', 'paused', 'stopped', 'error']
        self._current_state: str = "idle"
        self._initial_state: str = "idle"
        self._state_history: List[str] = []
        self._transitions: List[Tuple[str, str]] = []
        self._tasks: Dict[str, Any] = {}
        self._workers: Dict[str, Any] = {}
        self._lambda_: float = 0.5
        self._lock: threading.RLock = threading.RLock()
        self._logger = _setup_logger(self.__class__.__name__)

    # ── Item CRUD ────────────────────────────────────────────────

    def create_item(self, data: Dict[str, Any]) -> str:
        """
        创建条目并返回其 ID。

        Args:
            data: 条目的数据字典。

        Returns:
            新条目的唯一 ID。
        """
        item_id = generate_id("item")
        record = {
            "id": item_id,
            "data": data,
            "created_at": time.time(),
            "updated_at": time.time(),
            "version": 1,
        }
        with self._lock:
            self._item_store[item_id] = record
            self._stats["item_created"] += 1
            self._logger.debug("Created item %s", item_id)
        return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """
        根据 ID 获取条目的数据。

        Args:
            item_id: 条目 ID。

        Returns:
            条目数据字典，不存在时返回 None。
        """
        with self._lock:
            record = self._item_store.get(item_id)
            if record is None:
                return None
            return record["data"]

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """
        更新指定条目的数据。

        Args:
            item_id: 条目 ID。
            data: 要合并更新的字段。

        Returns:
            更新成功返回 True，条目不存在返回 False。
        """
        with self._lock:
            record = self._item_store.get(item_id)
            if record is None:
                return False
            record["data"].update(data)
            record["updated_at"] = time.time()
            record["version"] += 1
            self._stats["item_updated"] += 1
            self._logger.debug("Updated item %s (version %d)", item_id, record["version"])
        return True

    def delete_item(self, item_id: str) -> bool:
        """
        删除指定条目。

        Args:
            item_id: 条目 ID。

        Returns:
            删除成功返回 True，条目不存在返回 False。
        """
        with self._lock:
            if item_id not in self._item_store:
                return False
            del self._item_store[item_id]
            self._stats["item_deleted"] += 1
            self._logger.debug("Deleted item %s", item_id)
        return True

    def list_items(
        self,
        page: int = 1,
        page_size: int = 20,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        分页列出条目，支持按字段过滤。

        Args:
            page: 页码，从 1 开始。
            page_size: 每页条数。
            filters: 过滤条件字典，键为字段名，值为期望值。

        Returns:
            包含 items、total、page、page_size 的字典。
        """
        with self._lock:
            items = list(self._item_store.values())
            if filters:
                items = [it for it in items if all(it["data"].get(key) == value for key, value in filters.items())]
            total = len(items)
            start = (page - 1) * page_size
            end = start + page_size
            return {
                "items": [it["data"] for it in items[start:end]],
                "total": total,
                "page": page,
                "page_size": page_size,
            }

    def count_items(self) -> int:
        """
        返回当前条目总数。

        Returns:
            条目数量。
        """
        with self._lock:
            return len(self._item_store)

    def search_items(
        self, query: str, fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        对条目数据进行全文关键词搜索。

        Args:
            query: 搜索关键词。
            fields: 指定搜索的字段列表，None 时搜索所有字段。

        Returns:
            匹配的记录数据列表。
        """
        results: List[Dict[str, Any]] = []
        query_lower = query.lower()
        with self._lock:
            for record in self._item_store.values():
                data = record["data"]
                search_fields = fields or list(data.keys())
                for field in search_fields:
                    val = str(data.get(field, "")).lower()
                    if query_lower in val:
                        results.append(data)
                        break
        return results

    def batch_create_items(self, batch: List[Dict[str, Any]]) -> List[str]:
        """
        批量创建条目。

        Args:
            batch: 待创建的数据字典列表。

        Returns:
            创建成功的条目 ID 列表。
        """
        return [self.create_item(item) for item in batch]

    def batch_delete_items(self, ids: List[str]) -> int:
        """
        批量删除条目。

        Args:
            ids: 要删除的条目 ID 列表。

        Returns:
            实际删除的条目数量。
        """
        count = sum(1 for item_id in ids if self.delete_item(item_id))
        self._logger.debug("Batch deleted %d items", count)
        return count

    def export_items(self, path: str) -> str:
        """
        将全部条目导出为 JSON 文件。

        Args:
            path: 输出文件路径。

        Returns:
            输出文件路径。
        """
        with self._lock:
            data = list(self._item_store.values())
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2, default=str)
            self._logger.info("Exported items to %s", path)
        return path

    def import_items(self, path: str) -> int:
        """
        从 JSON 文件导入条目。

        Args:
            path: 输入文件路径。

        Returns:
            成功导入的条目数量。
        """
        count = 0
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        for record in data:
            item_id = record.get("id", generate_id("item"))
            with self._lock:
                self._item_store[item_id] = record
            count += 1
            self._logger.info("Imported %d items from %s", count, path)
        return count

    def get_item_stats(self) -> Dict[str, int]:
        """
        返回条目的统计摘要。

        Returns:
            包含 total、created、updated、deleted 的字典。
        """
        with self._lock:
            return {
                "total": len(self._item_store),
                "created": self._stats["item_created"],
                "updated": self._stats["item_updated"],
                "deleted": self._stats["item_deleted"],
            }

    # ── Cache ───────────────────────────────────────────────────

    def get_cache(self, key: str) -> Optional[Any]:
        """
        获取缓存值，自动淘汰过期条目。

        Args:
            key: 缓存键。

        Returns:
            缓存值，不存在或已过期时返回 None。
        """
        with self._lock:
            entry = self._cache.pop(key, None)
            if entry is None:
                return None
            elapsed = time.monotonic() - entry["time"]
            if elapsed >= entry["ttl"]:
                self._logger.debug("Cache miss (expired): %s", key)
                return None
            with self._lock:
                self._cache[key] = entry
            return entry["value"]

    def set_cache(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """
        写入缓存，超出最大容量时淘汰最旧条目。

        Args:
            key: 缓存键。
            value: 缓存值。
            ttl: 存活时间（秒）。
        """
        entry = {"value": value, "time": time.monotonic(), "ttl": ttl}
        with self._lock:
            self._cache[key] = entry
            self._cache.move_to_end(key)
            while len(self._cache) > self._max_cache_size:
                self._cache.popitem(last=False)
            self._logger.debug("Cache set: %s", key)

    def invalidate_cache(self, key: str) -> bool:
        """
        使指定缓存键失效。

        Args:
            key: 缓存键。

        Returns:
            失效成功返回 True，键不存在返回 False。
        """
        with self._lock:
            result = self._cache.pop(key, None) is not None
            if result:
                self._logger.debug("Cache invalidated: %s", key)
            return result

    def clear_cache(self) -> int:
        """
        清空全部缓存。

        Returns:
            清空前的缓存条目数。
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
            self._logger.debug("Cache cleared, removed %d entries", count)
        return count

    def get_cache_stats(self) -> Dict[str, int]:
        """
        返回缓存统计信息。

        Returns:
            包含 size 和 max_size 的字典。
        """
        with self._lock:
            return {"size": len(self._cache), "max_size": self._max_cache_size}

    # ── Metrics ─────────────────────────────────────────────────

    def record_metric(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """
        记录一条带标签的指标数据。

        Args:
            value: 指标值。
            labels: 标签字典，用于区分不同维度。
        """
        key = json.dumps(labels or {}, sort_keys=True)
        with self._lock:
            self._metrics[key].append({"value": value, "time": time.time(), "labels": labels or {}})
            if len(self._metrics[key]) > 10000:
                self._metrics[key] = self._metrics[key][-5000:]

    def get_metric_stats(
        self, labels: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        计算指定标签维度的指标统计（含分位数）。

        Args:
            labels: 标签字典，None 表示全部维度聚合。

        Returns:
            包含 count、mean、min、max、p50、p95、p99 的字典。
        """
        key = json.dumps(labels or {}, sort_keys=True)
        with self._lock:
            values = [e["value"] for e in self._metrics.get(key, [])]
            if not values:
                return {
                    "count": 0,
                    "mean": 0,
                    "min": 0,
                    "max": 0,
                    "p50": 0,
                    "p95": 0,
                    "p99": 0,
                }
            sorted_vals = sorted(values)
            n = len(sorted_vals)
            return {
                "count": n,
                "mean": statistics.mean(values),
                "min": sorted_vals[0],
                "max": sorted_vals[-1],
                "p50": sorted_vals[int(n * 0.5)],
                "p95": sorted_vals[min(int(n * 0.95), n - 1)],
                "p99": sorted_vals[min(int(n * 0.99), n - 1)],
            }

    def get_metric_history(
        self, labels: Optional[Dict[str, Any]] = None, limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        获取最近的历史指标记录。

        Args:
            labels: 标签字典。
            limit: 返回记录数量上限。

        Returns:
            最近 limit 条指标记录列表。
        """
        key = json.dumps(labels or {}, sort_keys=True)
        with self._lock:
            values = [e["value"] for e in self._metrics.get(key, [])]
            if not values:
                return []
            sorted_vals = sorted(values)
            n = len(sorted_vals)
            return [
                {"value": val, "time": time.time(), "labels": labels or {}} for val in sorted_vals[-limit:]
            ]

    # ── Export/Import ───────────────────────────────────────────

    def to_dict(self) -> Dict[str, Any]:
        """
        将重排器转换为字典。

        Returns:
            字典。
        """
        data = {
            "item_store": self._item_store,
            "cache": self._cache,
            "max_cache_size": self._max_cache_size,
            "metrics": self._metrics,
            "stats": self._stats,
            "config": self._config,
            "default_config": self._default_config,
            "config_version": self._config_version,
            "evt_handlers": self._evt_handlers,
            "initialized": self._initialized,
            "status": self._status,
            "start_time": self._start_time,
            "stages": self._stages,
            "queue": self._queue,
            "total_enqueued": self._total_enqueued,
            "total_dequeued": self._total_dequeued,
            "registry": self._registry,
            "valid_states": self._valid_states,
            "current_state": self._current_state,
            "initial_state": self._initial_state,
            "state_history": self._state_history,
            "transitions": self._transitions,
            "tasks": self._tasks,
            "workers": self._workers,
            "lambda_": self._lambda_,
        }
        return data

    def to_json(self, indent: int = 2) -> str:
        """
        将重排器转换为 JSON 字符串。

        Args:
            indent: JSON 缩进空格数。

        Returns:
            JSON 字符串。
        """
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent, default=str)

    @classmethod
    def from_json(cls, text: str) -> "RelevanceRanker":
        """
        从 JSON 字符串反序列化创建重排器实例。

        Args:
            text: JSON 字符串。

        Returns:
            新实例。
        """
        return cls.from_dict(json.loads(text))

    def serialize(self) -> bytes:
        """
        将重排器序列化为字节。

        Returns:
            字节数据。
        """
        return pickle.dumps(self.to_dict())

    @classmethod
    def deserialize(cls, data: bytes) -> "RelevanceRanker":
        """
        从字节反序列化创建重排器实例。

        Args:
            data: 字节数据。

        Returns:
            新实例。
        """
        return cls.from_dict(pickle.loads(data))

    def save(self, path: str) -> str:
        """
        将重排器保存到 JSON 文件。

        Args:
            path: 文件路径。

        Returns:
            文件路径。
        """
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.to_json())
        self._logger.info("Saved ranker to %s", path)
        return path

    @classmethod
    def load(cls, path: str) -> "RelevanceRanker":
        """
        从 JSON 文件加载重排器。

        Args:
            path: 文件路径。

        Returns:
            加载后的实例。
        """
        with open(path, "r", encoding="utf-8") as f:
            instance = cls.from_json(f.read())
            instance._logger.info("Loaded ranker from %s", path)
        return instance

    def clone(self) -> "RelevanceRanker":
        """
        深拷贝当前重排器实例。

        Returns:
            新实例。
        """
        return deepcopy(self)

    def merge(self, other: "RelevanceRanker") -> "RelevanceRanker":
        """
        合并另一个重排器的公开字段。

        Args:
            other: 源重排器实例。

        Returns:
            当前实例（自引用）。
        """
        for key, value in other.__dict__.items():
            if not key.startswith("_") and value is not None:
                setattr(self, key, value)
        return self
