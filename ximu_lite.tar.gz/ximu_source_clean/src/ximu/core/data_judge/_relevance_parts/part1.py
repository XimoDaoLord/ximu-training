"""
相关性判断核心模块，提供线程安全的数据存储、LRU缓存及指标统计功能。
"""

import asyncio
import json
import logging
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple, Callable, Deque, Set, Union

from src.ximu.common.utils import generate_id

logger = logging.getLogger(__name__)

def _setup_logger(name: str) -> logging.Logger:
    """
    创建并配置带格式化输出的日志记录器。

    Args:
        name (str): 日志记录器名称

    Returns:
        logging.Logger: 日志记录器实例
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


@dataclass
class RelevanceResult:
    """
    相关性判断结果数据类，包含分数、匹配词和排名信息。
    """

    score: float = 0.0
    matched_terms: List[str] = field(default_factory=list)
    context_score: float = 0.0
    rank: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """
        将结果转换为字典格式。

        Returns:
            Dict[str, Any]: 结果字典
        """
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RelevanceResult":
        """
        从字典数据构造RelevanceResult实例。

        Args:
            data (Dict[str, Any]): 字典数据

        Returns:
            RelevanceResult: RelevanceResult实例
        """
        valid_keys = set(cls.__dataclass_fields__.keys())
        filtered_data = {k: v for k, v in data.items() if k in valid_keys}
        return cls(**filtered_data)


class _LRUCache:
    """
    带TTL过期机制的线程安全LRU缓存实现。
    """

    def __init__(self, max_size: int = 10000, default_ttl: float = 300.0) -> None:
        """
        初始化缓存实例。

        Args:
            max_size (int, optional): 缓存最大容量。 Defaults to 10000.
            default_ttl (float, optional): 缓存项默认过期时间（秒）。 Defaults to 300.0.
        """
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._cache: Deque[Tuple[str, int, Dict[str, Any]]] = deque()
        self._lock = asyncio.Lock()

    async def get(self, key: str) -> Optional[Any]:
        """
        获取缓存值，过期则自动删除并返回None。

        Args:
            key (str): 缓存键

        Returns:
            Optional[Any]: 缓存值或None
        """
        with self._lock:
            entry_key = (key, self._get_version(key))
            entry = self._cache.get(entry_key)
            if entry is None:
                return None
            now = time.monotonic()
            if now - entry[1] >= entry[2]["ttl"]:
                del self._cache[entry_key]
                return None
            self._cache.move_to_end(entry_key)
            return entry[2]["value"]

    async def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """
        设置缓存项，支持自定义TTL，超出容量时驱逐最久未使用的项。

        Args:
            key (str): 缓存键
            value (Any): 缓存值
            ttl (Optional[float], optional): 缓存项过期时间（秒）。 Defaults to None.
        """
        actual_ttl = ttl if ttl is not None else self._default_ttl
        version = self._get_version(key)
        entry_key = (key, version)
        entry = {
            "value": value,
            "time": time.monotonic(),
            "ttl": actual_ttl,
            "version": version,
        }
        with self._lock:
            if entry_key in self._cache:
                self._cache.move_to_end(entry_key)
            self._cache[entry_key] = entry
            if len(self._cache) > self._max_size:
                self._cache.popitem(last=False)

    async def invalidate(self, key: str) -> bool:
        """
        删除指定缓存项，成功返回True。

        Args:
            key (str): 缓存键

        Returns:
            bool: 是否删除成功
        """
        with self._lock:
            return self._cache.pop((key, self._get_version(key)), None) is not None

    async def clear(self) -> int:
        """
        清空缓存，返回清除的条目数量。

        Returns:
            int: 清除的条目数量
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
            return count

    async def stats(self) -> Dict[str, int]:
        """
        返回缓存当前状态统计信息。

        Returns:
            Dict[str, int]: 缓存统计信息
        """
        with self._lock:
            return {
                "size": len(self._cache),
                "max_size": self._max_size,
                "evictions": self._max_size - len(self._cache),
            }

    def _get_version(self, key: str) -> int:
        """
        获取数据版本号（需配合存储层实现）

        Args:
            key (str): 数据键

        Returns:
            int: 数据版本号
        """
        raise NotImplementedError("Version control requires storage integration")


class _MetricRecorder:
    """
    线程安全的指标记录器，支持按标签分组记录和统计。
    """

    def __init__(self, max_history_per_key: int = 10000, clean_interval: float = 3600.0) -> None:
        """
        初始化指标记录器实例。

        Args:
            max_history_per_key (int, optional): 每个标签分组的历史记录最大容量。 Defaults to 10000.
            clean_interval (float, optional): 后台清理线程的清理间隔（秒）。 Defaults to 3600.0.
        """
        self._max_history = max_history_per_key
        self._metrics: Dict[str, Deque[Dict[str, Any]]] = defaultdict(deque)
        self._lock = asyncio.Lock()
        self._clean_interval = clean_interval
        self._clean_task = asyncio.create_task(self._clean_overdue_records())

    async def record(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """
        记录一条指标数据，自动按标签分组管理历史长度。

        Args:
            value (float): 指标值
            labels (Optional[Dict[str, Any]], optional): 标签数据。 Defaults to None.
        """
        label_key = json.dumps(labels or {}, sort_keys=True)
        with self._lock:
            self._metrics[label_key].append(
                {"value": value, "time": time.time(), "labels": labels or {}}
            )

    async def get_stats(
        self, labels: Optional[Dict[str, Any]] = None
    ) -> Dict[str, float]:
        """
        计算指定标签分组指标的统计数据，包括均值、分位数等。

        Args:
            labels (Optional[Dict[str, Any]], optional): 标签数据。 Defaults to None.

        Returns:
            Dict[str, float]: 统计数据
        """
        label_key = json.dumps(labels or {}, sort_keys=True)
        with self._lock:
            entries = self._metrics.get(label_key, [])
            if not entries:
                return {
                    "count": 0.0,
                    "mean": 0.0,
                    "min": 0.0,
                    "max": 0.0,
                    "p50": 0.0,
                    "p95": 0.0,
                    "p99": 0.0,
                }
            sorted_vals = sorted(e["value"] for e in entries)
            n = len(sorted_vals)
            return {
                "count": float(n),
                "mean": sum(sorted_vals) / n if n else 0.0,
                "min": sorted_vals[0] if n else 0.0,
                "max": sorted_vals[-1] if n else 0.0,
                "p50": self._percentile(sorted_vals, 0.50),
                "p95": self._percentile(sorted_vals, 0.95),
                "p99": self._percentile(sorted_vals, 0.99),
            }

    async def get_history(
        self, labels: Optional[Dict[str, Any]] = None, limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        获取指定标签分组的近期指标历史记录。

        Args:
            labels (Optional[Dict[str, Any]], optional): 标签数据。 Defaults to None.
            limit (int, optional): 历史记录最大数量。 Defaults to 100.

        Returns:
            List[Dict[str, Any]]: 历史记录列表
        """
        label_key = json.dumps(labels or {}, sort_keys=True)
        with self._lock:
            entries = list(self._metrics.get(label_key, []))
            return entries[-limit:] if entries else []

    def reset(self) -> None:
        """
        重置所有指标记录。
        """
        with self._lock:
            self._metrics.clear()
            logger.info("Metrics recorder reset")

    @staticmethod
    def _percentile(sorted_values: List[float], percentile: float) -> float:
        """
        计算已排序数据的中位数/分位数。

        Args:
            sorted_values (List[float]): 已排序数据
            percentile (float): 分位数

        Returns:
            float: 中位数/分位数
        """
        if not sorted_values:
            return 0.0
        if len(sorted_values) == 1:
            return sorted_values[0]
        pct = max(0.0, min(1.0, percentile))
        k = int(len(sorted_values) * pct)
        k = max(0, min(k, len(sorted_values) - 1))
        return sorted_values[k]

    async def _clean_overdue_records(self) -> None:
        """
        后台清理线程，定期清理过期标签分组记录。
        """
        while True:
            await asyncio.sleep(self._clean_interval)
            with self._lock:
                for label_key, entries in list(self._metrics.items()):
                    if len(entries) > self._max_history:
                        entries.popleft()


class _MemoryIndex:
    """
    内存倒排索引，加速字段搜索。
    """

    def __init__(self) -> None:
        """
        初始化索引实例。
        """
        self._index: Dict[str, Dict[str, List[str]]] = defaultdict(lambda: defaultdict(list))
        self._field_names: Set[str] = set()

    def add(self, item_id: str, data: Dict[str, Any]) -> None:
        """
        添加条目到索引。

        Args:
            item_id (str): 条目ID
            data (Dict[str, Any]): 条目数据
        """
        for field_name, value in data.items():
            self._field_names.add(field_name)
            terms = [term.lower() for term in str(value).split() if term]
            for term in terms:
                self._index[field_name][term].append(item_id)

    def remove(self, item_id: str) -> None:
        """
        从索引中移除条目。

        Args:
            item_id (str): 条目ID
        """
        if item_id in self._index:
            for field_name in self._index:
                if item_id in self._index[field_name]:
                    self._index[field_name].remove(item_id)

    def search(self, query: str, fields: Optional[List[str]] = None) -> List[str]:
        """
        按关键词搜索相关条目ID。

        Args:
            query (str): 搜索关键词
            fields (Optional[List[str]], optional): 搜索字段列表。 Defaults to None.

        Returns:
            List[str]: 相关条目ID列表
        """
        if not query:
            return []
        query_lower = query.lower()
        fields = fields or self._field_names
        results = set()
        for field_name in fields:
            if field_name in self._index:
                terms = [term for term in str(query).split() if term]
                for term in terms:
                    if term in self._index[field_name]:
                        results.update(self._index[field_name][term])
        return list(results)


class RelevanceStore:
    """
    线程安全的相关性判断数据存储，支持CRUD操作和基础搜索。
    """

    def __init__(self, index: _MemoryIndex) -> None:
        """
        初始化数据存储实例。

        Args:
            index (_MemoryIndex): 索引实例
        """
        self._store: Dict[str, Dict[str, Any]] = {}
        self._lock = asyncio.Lock()
        self._index = index
        self._counter: Dict[str, int] = defaultdict(int)

    async def create(self, data: Dict[str, Any]) -> str:
        """
        创建新条目，返回生成的唯一ID。

        Args:
            data (Dict[str, Any]): 条目数据

        Returns:
            str: 生成的唯一ID
        """
        item_id = generate_id("relevancejudge_item")
        now = time.time()
        record = {
            "id": item_id,
            "data": dict(data),
            "created_at": now,
            "updated_at": now,
            "version": 1,
        }
        with self._lock:
            self._store[item_id] = record
            self._index.add(item_id, record["data"])
            self._counter["created"] += 1
            logger.debug("Created item %s", item_id)
        return item_id

    async def get(self, item_id: str) -> Optional[Dict[str, Any]]:
        """
        获取指定ID的条目数据。

        Args:
            item_id (str): 条目ID

        Returns:
            Optional[Dict[str, Any]]: 条目数据或None
        """
        with self._lock:
            record = self._store.get(item_id)
            return dict(record["data"]) if record else None

    async def update(self, item_id: str, data: Dict[str, Any]) -> bool:
        """
        更新指定ID的条目数据，返回是否成功。

        Args:
            item_id (str): 条目ID
            data (Dict[str, Any]): 条目数据

        Returns:
            bool: 是否成功
        """
        with self._lock:
            record = self._store.get(item_id)
            if record is None:
                return False
            record["data"].update(data)
            record["updated_at"] = time.time()
            record["version"] += 1
            self._index.remove(item_id)
            self._index.add(item_id, record["data"])
            self._counter["updated"] += 1
            logger.debug("Updated item %s", item_id)
        return True

    async def delete(self, item_id: str) -> bool:
        """
        删除指定ID的条目，返回是否成功。

        Args:
            item_id (str): 条目ID

        Returns:
            bool: 是否成功
        """
        with self._lock:
            if item_id not in self._store:
                return False
            del self._store[item_id]
            self._index.remove(item_id)
            self._counter["deleted"] += 1
            logger.debug("Deleted item %s", item_id)
        return True

    async def list_items(
        self, page: int = 1, page_size: int = 20, filters: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        分页列出条目，支持按字段过滤。

        Args:
            page (int, optional): 页码。 Defaults to 1.
            page_size (int, optional): 每页条目数量。 Defaults to 20.
            filters (Optional[Dict[str, Any]], optional): 过滤条件。 Defaults to None.

        Returns:
            Dict[str, Any]: 条目列表
        """
        if page < 1:
            page = 1
        if page_size < 1:
            page_size = 10
        with self._lock:
            items = list(self._store.values())
            total = len(items)
            if filters:
                items = [item for item in items if all(item["data"].get(k) == v for k, v in filters.items())]
            start = (page - 1) * page_size
            page_items = items[start:start + page_size]
            return {
                "items": [it["data"] for it in page_items],
                "total": total,
                "page": page,
                "page_size": page_size,
            }

    async def count(self) -> int:
        """
        返回存储中的条目总数。

        Returns:
            int: 条目总数
        """
        with self._lock:
            return len(self._store)

    async def search(
        self, query: str, fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        按关键词搜索条目，支持指定搜索字段。

        Args:
            query (str): 搜索关键词
            fields (Optional[List[str]], optional): 搜索字段列表。 Defaults to None.

        Returns:
            List[Dict[str, Any]]: 相关条目列表
        """
        if not query:
            return []
        query_lower = query.lower()
        fields = fields or self._index.field_names()
        with self._lock:
            item_ids = self._index.search(query, fields)
            results = []
            for item_id in item_ids:
                results.append(dict(self._store[item_id]["data"]))
            return results

    async def batch_create(self, batch: List[Dict[str, Any]]) -> List[str]:
        """
        批量创建条目，返回所有生成的ID列表。

        Args:
            batch (List[Dict[str, Any]]): 条目数据列表

        Returns:
            List[str]: 生成的ID列表
        """
        return [await self.create(item) for item in batch]

    async def batch_delete(self, ids: List[str]) -> int:
        """
        批量删除条目，返回成功删除的数量。

        Args:
            ids (List[str]): 条目ID列表

        Returns:
            int: 成功删除的数量
        """
        return sum(1 for item_id in ids if await self.delete(item_id))
