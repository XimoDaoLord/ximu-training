from __future__ import annotations

import importlib
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

def import_part(part_name: str) -> None:
    """Import a specific completeness part and re-export its public members."""
    module_name = f"._completeness_parts.{part_name}"
    try:
        module = importlib.import_module(module_name, package=__package__)
        for member_name in dir(module):
            if not member_name.startswith("_"):
                globals()[member_name] = getattr(module, member_name)
    except Exception as _e:
        logger.warning(f"Re-export {__name__}.{part_name} failed: {_e}")

# Import parts
import_part('part1')
import_part('part2')