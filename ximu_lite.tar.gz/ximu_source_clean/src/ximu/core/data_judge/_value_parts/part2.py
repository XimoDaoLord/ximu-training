"""值域判断 - 独特性评分器模块。

提供 UniquenessScorer 组件，用于管理评分项的 CRUD、缓存、
指标统计、配置及事件处理。采用职责分离设计，避免上帝类反模式。
"""

import json
import time
import threading
import statistics
import logging
from contextlib import nullcontext
from typing import Any, Dict, List, Optional, Tuple, Callable, Union
from collections import defaultdict, OrderedDict

from src.ximu.common.utils import generate_id

__version__ = "0.5"

logger = logging.getLogger(__name__)


class MetricsCollector:
    """指标收集器，负责记录与统计数值指标。

    支持按标签维度统计 count、mean、min、max、p50、p95、p99。
    内部使用有序数组维护统计数据，避免每次查询时全量排序。
    """

    def __init__(self, max_entries_per_label: int = 10000, thread_safe: bool = True) -> None:
        """初始化指标收集器。

        Args:
            max_entries_per_label: 每个标签组合保留的最大条目数。
            thread_safe: 是否启用线程安全锁，默认 True。
        """
        self._lock: Optional[threading.RLock] = threading.RLock() if thread_safe else None
        self._metrics: Dict[str, List[Dict[str, Any]]] = {}
        self._max_entries: int = max_entries_per_label
        self._logger: logging.Logger = logging.getLogger(f"{self.__class__.__name__}")

    def record(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录一个指标值。

        Args:
            value: 指标数值。
            labels: 标签字典，用于区分不同维度的指标。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            key = self._build_label_key(labels)
            if key not in self._metrics:
                self._metrics[key] = []
            self._metrics[key].append({"value": value, "time": time.time(), "labels": labels or {}})
            if len(self._metrics[key]) > self._max_entries:
                self._metrics[key] = self._metrics[key][-self._max_entries // 2:]

    def get_stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, float]:
        """获取指定标签的指标统计。

        Args:
            labels: 标签字典。

        Returns:
            包含 count、mean、min、max、p50、p95、p99 的字典。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            key = self._build_label_key(labels)
            values = [e["value"] for e in self._metrics.get(key, [])]

        if not values:
            return {"count": 0, "mean": 0.0, "min": 0.0, "max": 0.0, "p50": 0.0, "p95": 0.0, "p99": 0.0}

        sorted_vals = sorted(values)
        n = len(sorted_vals)
        return {
            "count": n,
            "mean": statistics.mean(values),
            "min": sorted_vals[0],
            "max": sorted_vals[-1],
            "p50": sorted_vals[int(n * 0.5)],
            "p95": sorted_vals[min(int(n * 0.95), n - 1)],
            "p99": sorted_vals[min(int(n * 0.99), n - 1)],
        }

    def get_history(self, labels: Optional[Dict[str, Any]] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """获取指标历史。

        Args:
            labels: 标签字典。
            limit: 返回的最大条目数。

        Returns:
            最近 N 条记录列表。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            key = self._build_label_key(labels)
            return list(self._metrics.get(key, []))[-limit:]

    def reset(self) -> None:
        """清空所有指标数据。"""
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            self._metrics.clear()

    @staticmethod
    def _build_label_key(labels: Optional[Dict[str, Any]]) -> str:
        """构建标签键。

        Args:
            labels: 标签字典。

        Returns:
            序列化后的标签键字符串。
        """
        return json.dumps(labels or {}, sort_keys=True, default=str)


class CacheManager:
    """带 TTL 的 LRU 风格缓存管理器。

    使用 OrderedDict 实现 O(1) 的插入和删除操作，支持 TTL 自动过期。
    """

    def __init__(self, max_size: int = 10000, thread_safe: bool = True) -> None:
        """初始化缓存。

        Args:
            max_size: 缓存最大条目数。
            thread_safe: 是否启用线程安全锁，默认 True。
        """
        self._lock: Optional[threading.RLock] = threading.RLock() if thread_safe else None
        self._cache: OrderedDict = OrderedDict()
        self._max_size: int = max_size
        self._logger: logging.Logger = logging.getLogger(f"{self.__class__.__name__}")

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值。

        Args:
            key: 缓存键。

        Returns:
            缓存值，若不存在或过期则返回 None。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            entry = self._cache.get(key)
            if not entry:
                return None
            if time.monotonic() - entry["time"] >= entry["ttl"]:
                self._cache.pop(key, None)
                return None
            self._cache.move_to_end(key)
            return entry["value"]

    def set(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """设置缓存。

        Args:
            key: 缓存键。
            value: 缓存值。
            ttl: 生存时间（秒）。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            self._cache[key] = {"value": value, "time": time.monotonic(), "ttl": ttl}
            self._cache.move_to_end(key)
            while len(self._cache) > self._max_size:
                self._cache.popitem(last=False)

    def invalidate(self, key: str) -> bool:
        """使指定键失效。

        Args:
            key: 缓存键。

        Returns:
            是否成功移除。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            return self._cache.pop(key, None) is not None

    def clear(self) -> int:
        """清空缓存，返回移除条数。"""
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            count = len(self._cache)
            self._cache.clear()
            return count

    def get_stats(self) -> Dict[str, int]:
        """获取缓存统计信息。"""
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            return {"size": len(self._cache), "max_size": self._max_size}


class ConfigManager:
    """配置管理器，支持版本控制与序列化。"""

    def __init__(self, thread_safe: bool = True) -> None:
        """初始化配置管理器。

        Args:
            thread_safe: 是否启用线程安全锁，默认 True。
        """
        self._lock: Optional[threading.RLock] = threading.RLock() if thread_safe else None
        self._config: Dict[str, Any] = {}
        self._default_config: Dict[str, Any] = {}
        self._version: int = 1
        self._logger: logging.Logger = logging.getLogger(f"{self.__class__.__name__}")

    def get(self, key: str, default: Any = None) -> Any:
        """获取配置项。

        Args:
            key: 配置键。
            default: 默认值。

        Returns:
            配置值或默认值。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            return self._config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """设置配置项。

        Args:
            key: 配置键。
            value: 配置值。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            self._config[key] = value
            self._version += 1
            self._logger.debug("Config set: %s=%r", key, value)

    def get_all(self) -> Dict[str, Any]:
        """获取全部配置的副本。"""
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            return dict(self._config)

    def update(self, updates: Dict[str, Any]) -> None:
        """批量更新配置。

        Args:
            updates: 配置字典。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            self._config.update(updates)
            self._version += 1

    def reset(self) -> None:
        """重置为默认配置。"""
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            self._config = dict(self._default_config)
            self._version += 1

    def set_default(self, key: str, value: Any) -> None:
        """设置默认配置项。

        Args:
            key: 配置键。
            value: 默认值。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            self._default_config[key] = value
            if key not in self._config:
                self._config[key] = value

    def get_version(self) -> int:
        """获取配置版本号。"""
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            return self._version

    def export_to_file(self, path: str) -> str:
        """导出配置到 JSON 文件。

        Args:
            path: 文件路径。

        Returns:
            文件路径。

        Raises:
            ValueError: 路径为空或包含非法字符。
        """
        if not path:
            raise ValueError("文件路径不能为空")
        if ".." in path or path.startswith("/"):
            raise ValueError(f"非法路径: {path}")
        data = self.get_all()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        self._logger.info("Config exported to %s", path)
        return path

    def import_from_file(self, path: str) -> bool:
        """从 JSON 文件导入配置。

        Args:
            path: 文件路径。

        Returns:
            是否成功。
        """
        if not path:
            raise ValueError("文件路径不能为空")
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                raise ValueError("配置文件格式错误，应为字典")
            self.update(data)
            self._logger.info("Config imported from %s", path)
            return True
        except (IOError, OSError, json.JSONDecodeError, ValueError, TypeError) as e:
            self._logger.warning("Config import failed: %s", e)
            return False


class EventManager:
    """事件处理器管理器。

    支持动态注册/注销处理器，emit 在锁外执行以避免死锁。
    """

    def __init__(self, thread_safe: bool = True) -> None:
        """初始化事件管理器。

        Args:
            thread_safe: 是否启用线程安全锁，默认 True。
        """
        self._lock: Optional[threading.RLock] = threading.RLock() if thread_safe else None
        self._handlers: Dict[str, Callable] = {}
        self._logger: logging.Logger = logging.getLogger(f"{self.__class__.__name__}")

    def on(self, handler: Callable) -> str:
        """注册事件处理器。

        Args:
            handler: 可调用对象。

        Returns:
            处理器 ID。
        """
        handler_id = generate_id("evt_handler")
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            self._handlers[handler_id] = handler
            self._logger.debug("Event handler registered: %s", handler_id)
        return handler_id

    def off(self, handler_id: str) -> bool:
        """移除事件处理器。

        Args:
            handler_id: 处理器 ID。

        Returns:
            是否成功移除。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            if self._handlers.pop(handler_id, None) is not None:
                self._logger.debug("Event handler removed: %s", handler_id)
                return True
            return False

    def emit(self, data: Any = None) -> int:
        """触发事件，调用所有注册的处理器。

        Args:
            data: 事件数据。

        Returns:
            成功调用的处理器数量。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            handlers = list(self._handlers.values())
        count = 0
        for handler in handlers:
            try:
                handler(data)
                count += 1
            except Exception as e:
                self._logger.warning("Event handler error: %s", e)
        return count

    def get_count(self) -> int:
        """获取处理器数量。"""
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            return len(self._handlers)

    def clear(self) -> None:
        """清空所有处理器。"""
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            self._handlers.clear()


class ItemRepository:
    """评分项数据仓库，封装 CRUD 操作。"""

    def __init__(self, thread_safe: bool = True) -> None:
        """初始化仓库。

        Args:
            thread_safe: 是否启用线程安全锁，默认 True。
        """
        self._lock: Optional[threading.RLock] = threading.RLock() if thread_safe else None
        self._store: Dict[str, Dict[str, Any]] = {}
        self._stats: Dict[str, int] = defaultdict(int)
        self._logger: logging.Logger = logging.getLogger(f"{self.__class__.__name__}")

    def create(self, data: Dict[str, Any]) -> str:
        """创建评分项。

        Args:
            data: 项数据。

        Returns:
            项 ID。
        """
        item_id = generate_id("uniquenessscorer_item")
        record = {
            "id": item_id,
            "data": data,
            "created_at": time.time(),
            "updated_at": time.time(),
            "version": 1,
        }
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            self._store[item_id] = record
            self._stats["item_created"] += 1
            self._logger.debug("Item created: %s", item_id)
        return item_id

    def get(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取评分项数据。

        Args:
            item_id: 项 ID。

        Returns:
            项数据或 None。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            record = self._store.get(item_id)
            if record:
                self._stats["item_read"] += 1
            return record

    def update(self, item_id: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """更新评分项。

        Args:
            item_id: 项 ID。
            data: 更新数据。

        Returns:
            更新后的项数据或 None。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            record = self._store.get(item_id)
            if not record:
                return None
            record["data"].update(data)
            record["updated_at"] = time.time()
            record["version"] += 1
            self._stats["item_updated"] += 1
            self._logger.debug("Item updated: %s", item_id)
            return record

    def delete(self, item_id: str) -> bool:
        """删除评分项。

        Args:
            item_id: 项 ID。

        Returns:
            是否成功删除。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            if item_id in self._store:
                del self._store[item_id]
                self._stats["item_deleted"] += 1
                self._logger.debug("Item deleted: %s", item_id)
                return True
            return False

    def list_all(self) -> List[Dict[str, Any]]:
        """获取所有评分项。

        Returns:
            项数据列表。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            return list(self._store.values())

    def get_stats(self) -> Dict[str, int]:
        """获取操作统计。

        Returns:
            统计数据字典。
        """
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            return dict(self._stats)

    def clear(self) -> None:
        """清空所有项。"""
        lock_ctx = self._lock if self._lock else nullcontext()
        with lock_ctx:
            self._store.clear()


class UniquenessScorer:
    """独特性评分器，组合各子组件提供统一 API。

    封装 ItemRepository、CacheManager、MetricsCollector、
    ConfigManager 和 EventManager，保持公共接口兼容。
    """

    def __init__(self, thread_safe: bool = True, max_cache_size: int = 10000,
                 max_metrics_entries: int = 10000) -> None:
        """初始化 UniquenessScorer。

        Args:
            thread_safe: 是否启用线程安全锁。
            max_cache_size: 缓存最大条目数。
            max_metrics_entries: 指标最大条目数。
        """
        self._thread_safe: bool = thread_safe
        self._repository: ItemRepository = ItemRepository(thread_safe=thread_safe)
        self._cache: CacheManager = CacheManager(max_size=max_cache_size, thread_safe=thread_safe)
        self._metrics: MetricsCollector = MetricsCollector(
            max_entries_per_label=max_metrics_entries, thread_safe=thread_safe
        )
        self._config: ConfigManager = ConfigManager(thread_safe=thread_safe)
        self._events: EventManager = EventManager(thread_safe=thread_safe)
        self._logger: logging.Logger = logging.getLogger(f"{self.__class__.__name__}")
        self._logger.debug("UniquenessScorer initialized")

    # -- 项 CRUD 委托 --

    def create_item(self, data: Dict[str, Any]) -> str:
        """创建评分项。

        Args:
            data: 项数据。

        Returns:
            项 ID。
        """
        return self._repository.create(data)

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """获取评分项数据。

        Args:
            item_id: 项 ID。

        Returns:
            项数据或 None。
        """
        return self._repository.get(item_id)

    def update_item(self, item_id: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """更新评分项。

        Args:
            item_id: 项 ID。
            data: 更新数据。

        Returns:
            更新后的项数据或 None。
        """
        return self._repository.update(item_id, data)

    def delete_item(self, item_id: str) -> bool:
        """删除评分项。

        Args:
            item_id: 项 ID。

        Returns:
            是否成功删除。
        """
        return self._repository.delete(item_id)

    def list_items(self) -> List[Dict[str, Any]]:
        """获取所有评分项。

        Returns:
            项数据列表。
        """
        return self._repository.list_all()

    def get_item_stats(self) -> Dict[str, int]:
        """获取项操作统计。

        Returns:
            统计数据字典。
        """
        return self._repository.get_stats()

    def clear_items(self) -> None:
        """清空所有项。"""
        self._repository.clear()

    # -- 缓存委托 --

    def cache_get(self, key: str) -> Optional[Any]:
        """获取缓存值。

        Args:
            key: 缓存键。

        Returns:
            缓存值或 None。
        """
        return self._cache.get(key)

    def cache_set(self, key: str, value: Any, ttl: float = 300.0) -> None:
        """设置缓存。

        Args:
            key: 缓存键。
            value: 缓存值。
            ttl: 生存时间（秒）。
        """
        self._cache.set(key, value, ttl)

    def cache_invalidate(self, key: str) -> bool:
        """使指定键失效。

        Args:
            key: 缓存键。

        Returns:
            是否成功移除。
        """
        return self._cache.invalidate(key)

    def cache_clear(self) -> int:
        """清空缓存。

        Returns:
            移除条数。
        """
        return self._cache.clear()

    def get_cache_stats(self) -> Dict[str, int]:
        """获取缓存统计。

        Returns:
            统计信息字典。
        """
        return self._cache.get_stats()

    # -- 指标委托 --

    def record_metric(self, value: float, labels: Optional[Dict[str, Any]] = None) -> None:
        """记录指标值。

        Args:
            value: 指标数值。
            labels: 标签字典。
        """
        self._metrics.record(value, labels)

    def get_metric_stats(self, labels: Optional[Dict[str, Any]] = None) -> Dict[str, float]:
        """获取指标统计。

        Args:
            labels: 标签字典。

        Returns:
            统计字典。
        """
        return self._metrics.get_stats(labels)

    def get_metric_history(self, labels: Optional[Dict[str, Any]] = None,
                           limit: int = 100) -> List[Dict[str, Any]]:
        """获取指标历史。

        Args:
            labels: 标签字典。
            limit: 返回最大条目数。

        Returns:
            历史记录列表。
        """
        return self._metrics.get_history(labels, limit)

    def reset_metrics(self) -> None:
        """清空指标数据。"""
        self._metrics.reset()

    # -- 配置委托 --

    def get_config(self, key: str, default: Any = None) -> Any:
        """获取配置项。

        Args:
            key: 配置键。
            default: 默认值。

        Returns:
            配置值或默认值。
        """
        return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """设置配置项。

        Args:
            key: 配置键。
            value: 配置值。
        """
        self._config.set(key, value)

    def get_all_config(self) -> Dict[str, Any]:
        """获取全部配置。

        Returns:
            配置字典。
        """
        return self._config.get_all()

    def get_config_version(self) -> int:
        """获取配置版本号。

        Returns:
            版本号。
        """
        return self._config.get_version()

    def export_config(self, path: str) -> str:
        """导出配置到文件。

        Args:
            path: 文件路径。

        Returns:
            文件路径。
        """
        return self._config.export_to_file(path)

    def import_config(self, path: str) -> bool:
        """从文件导入配置。

        Args:
            path: 文件路径。

        Returns:
            是否成功。
        """
        return self._config.import_from_file(path)

    # -- 事件委托 --

    def on_event(self, handler: Callable) -> str:
        """注册事件处理器。

        Args:
            handler: 可调用对象。

        Returns:
            处理器 ID。
        """
        return self._events.on(handler)

    def off_event(self, handler_id: str) -> bool:
        """移除事件处理器。

        Args:
            handler_id: 处理器 ID。

        Returns:
            是否成功移除。
        """
        return self._events.off(handler_id)

    def emit_event(self, data: Any = None) -> int:
        """触发事件。

        Args:
            data: 事件数据。

        Returns:
            成功调用的处理器数量。
        """
        return self._events.emit(data)

    def get_event_handler_count(self) -> int:
        """获取处理器数量。

        Returns:
            处理器数量。
        """
        return self._events.get_count()

    def clear_events(self) -> None:
        """清空所有处理器。"""
        self._events.clear()
