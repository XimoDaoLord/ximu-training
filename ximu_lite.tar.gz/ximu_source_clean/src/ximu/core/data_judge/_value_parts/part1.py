"""价值判断系统核心数据层。

提供价值判断数据的内存存储、CRUD操作、LRU缓存和倒排索引搜索功能。
"""

import json
import time
import threading
import logging
import sqlite3
import uuid
from typing import (
    Any,
    Dict,
    List,
    Optional,
    Tuple,
    Callable,
    Set,
    Union
)
from pathlib import Path
from dataclasses import dataclass, field, asdict
from collections import OrderedDict

try:
    from src.ximu.common.utils import generate_id
except ImportError:
    def generate_id(prefix: str) -> str:
        """生成带前缀的唯一ID。

        Args:
            prefix: ID前缀

        Returns:
            唯一标识字符串
        """
        return f"{prefix}_{uuid.uuid4().hex}"

logger = logging.getLogger("src.ximu.core.data_judge._value_parts.part1")


class _FlexibleJSONEncoder(json.JSONEncoder):
    """支持更多Python类型的JSON编码器。

    处理datetime、pathlib.Path、bytes等常见但标准JSON不支持的类型。
    """

    def default(self, obj: Any) -> Any:
        """将非标准类型转换为可序列化形式。

        Args:
            obj: 待转换对象

        Returns:
            可序列化的替代值
        """
        import datetime

        if isinstance(obj, (datetime.datetime, datetime.date)):
            return obj.isoformat()
        if isinstance(obj, Path):
            return str(obj)
        if isinstance(obj, bytes):
            return obj.decode("utf-8", errors="replace")
        if isinstance(obj, set):
            return list(obj)
        return super().default(obj)


def _serialize_labels(labels: Optional[Dict[str, Any]]) -> str:
    """将标签字典序列化为稳定的JSON字符串。

    Args:
        labels: 标签字典，可为None

    Returns:
        排序键后的JSON字符串
    """
    if labels is None:
        return "{}"
    try:
        return json.dumps(labels, sort_keys=True, cls=_FlexibleJSONEncoder)
    except (TypeError, ValueError) as exc:
        logger.warning("标签序列化失败，使用空标签: %s", exc)
        return "{}"


@dataclass
class ValueResult:
    """价值判断结果数据类。

    属性:
        score: 综合评分
        usefulness: 有用性评分
        uniqueness: 独特性评分
        roi: 投资回报率
        dimensions: 各维度细项得分
    """

    score: float = 0.0
    usefulness: float = 0.0
    uniqueness: float = 0.0
    roi: float = 0.0
    dimensions: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式。

        Returns:
            包含所有字段的字典
        """
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ValueResult":
        """从字典创建实例。

        Args:
            data: 源字典

        Returns:
            ValueResult实例
        """
        valid_keys = cls.__dataclass_fields__
        return cls(**{k: v for k, v in data.items() if k in valid_keys})


class _LRUCache:
    """线程安全的LRU缓存实现。

    使用OrderedDict实现O(1)的插入和驱逐操作。
    支持自动过期清理和容量限制。
    """

    def __init__(self, max_size: int = 10000, default_ttl: float = 300.0) -> None:
        """初始化LRU缓存。

        Args:
            max_size: 最大缓存条目数，负数表示无限制
            default_ttl: 默认过期时间（秒）
        """
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._lock = threading.RLock()
        self._cache: OrderedDict[str, Tuple[Any, float, float]] = OrderedDict()

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值并更新访问顺序。

        Args:
            key: 缓存键

        Returns:
            缓存值；若不存在或已过期则返回None
        """
        with self._lock:
            if key not in self._cache:
                return None
            value, expire_at, _ = self._cache[key]
            if time.monotonic() > expire_at:
                del self._cache[key]
                return None
            self._cache.move_to_end(key)
            return value

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """设置缓存值。

        Args:
            key: 缓存键
            value: 缓存值
            ttl: 过期时间（秒），None使用默认值
        """
        with self._lock:
            actual_ttl = ttl if ttl is not None else self._default_ttl
            expire_at = time.monotonic() + actual_ttl
            if key in self._cache:
                del self._cache[key]
            self._cache[key] = (value, expire_at, time.monotonic())
            self._evict_if_needed()

    def invalidate(self, key: str) -> bool:
        """使指定缓存条目失效。

        Args:
            key: 缓存键

        Returns:
            是否成功失效
        """
        with self._lock:
            return self._cache.pop(key, None) is not None

    def clear(self) -> int:
        """清空整个缓存。

        Returns:
            清除的条目数
        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
            return count

    def stats(self) -> Dict[str, Any]:
        """获取缓存统计信息。

        Returns:
            包含size和max_size的字典
        """
        with self._lock:
            return {"size": len(self._cache), "max_size": self._max_size}

    def _evict_if_needed(self) -> None:
        """驱逐超出容量的最久未使用条目。"""
        if self._max_size <= 0:
            return
        while len(self._cache) > self._max_size:
            evicted_key, _ = self._cache.popitem(last=False)
            logger.debug("LRU evict: %s", evicted_key)


class _InvertedIndex:
    """简单的倒排索引，用于加速字符串搜索。

    维护 field -> (term -> set of item_ids) 的映射。
    """

    def __init__(self) -> None:
        """初始化倒排索引。"""
        self._index: Dict[str, Dict[str, Set[str]]] = {}
        self._lock = threading.Lock()
        self._item_ids: Set[str] = set()

    def add(self, item_id: str, data: Dict[str, Any]) -> None:
        """将数据项加入索引。

        Args:
            item_id: 项ID
            data: 数据内容
        """
        with self._lock:
            self._item_ids.add(item_id)
            for field_name, value in data.items():
                text = str(value).lower()
                terms = text.split()
                if field_name not in self._index:
                    self._index[field_name] = {}
                for term in terms:
                    if term not in self._index[field_name]:
                        self._index[field_name][term] = set()
                    self._index[field_name][term].add(item_id)

    def remove(self, item_id: str, data: Dict[str, Any]) -> None:
        """从索引中移除数据项。

        Args:
            item_id: 项ID
            data: 数据内容
        """
        with self._lock:
            self._item_ids.discard(item_id)
            for field_name, value in data.items():
                text = str(value).lower()
                terms = text.split()
                index_for_field = self._index.get(field_name)
                if not index_for_field:
                    continue
                for term in terms:
                    if term in index_for_field:
                        index_for_field[term].discard(item_id)
                        if not index_for_field[term]:
                            del index_for_field[term]

    def search(self, query: str, fields: Optional[List[str]] = None) -> List[str]:
        """按关键词搜索匹配的item_id列表。

        Args:
            query: 搜索关键词
            fields: 指定字段列表，None表示全字段

        Returns:
            匹配的item_id列表
        """
        with self._lock:
            query_terms = set(query.lower().split())
            if not query_terms or not self._item_ids:
                return list(self._item_ids)

            candidates: Optional[Set[str]] = None
            field_sources = self._index if fields is None else {
                f: self._index.get(f, {}) for f in fields if f in self._index
            }
            for term in query_terms:
                term_set: Set[str] = set()
                for field_terms in field_sources.values():
                    term_set.update(field_terms.get(term, set()))
                if candidates is None:
                    candidates = term_set
                elif term_set:
                    candidates &= term_set
                else:
                    candidates = set()

            return list(candidates)


class ValueJudge:
    """价值判断核心数据层。

    作为Value Result系统的内存数据存储与管理中心，
    支持item CRUD、LRU缓存、指标统计、配置管理和事件分发。
    所有公开方法均为线程安全。
    """

    def __init__(
        self,
        max_cache_size: int = 10000,
        cache_ttl: float = 300.0,
        metrics_retention: int = 10000,
        db_path: str = "value_judge.db"
    ) -> None:
        """初始化ValueJudge。

        Args:
            max_cache_size: LRU缓存最大条目数
            cache_ttl: 缓存默认过期时间（秒）
            metrics_retention: 每条指标历史的最大保留条目数
            db_path: 数据库文件路径
        """
        self._item_store: Dict[str, Dict[str, Any]] = {}
        self._index = _InvertedIndex()
        self._cache = _LRUCache(max_size=max_cache_size, default_ttl=cache_ttl)
        self._metrics: Dict[str, List[Dict[str, Any]]] = {}
        self._metrics_retention = max(metrics_retention, 1)
        self._config: Dict[str, Any] = {}
        self._config_version = 0
        self._evt_handlers: Dict[str, Callable[[Any], None]] = {}
        self._stats: Dict[str, int] = {}
        self._lock = threading.RLock()

        self._db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None
        self._cursor: Optional[sqlite3.Cursor] = None
        self._db_lock = threading.Lock()
        self._init_db()

        self._initialized = False
        self._status = "idle"
        self._start_time = 0.0

        self._logger = logging.getLogger(f"{self.__class__.__name__}")

    def _init_db(self) -> None:
        """初始化数据库连接和表结构"""
        with self._db_lock:
            try:
                self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
                self._cursor = self._conn.cursor()
                self._cursor.execute('''
                    CREATE TABLE IF NOT EXISTS items (
                        id TEXT PRIMARY KEY,
                        data TEXT,
                        created_at REAL,
                        updated_at REAL,
                        version INTEGER
                    )
                ''')
                self._cursor.execute('''
                    CREATE TABLE IF NOT EXISTS metrics (
                        key TEXT,
                        value REAL,
                        time REAL,
                        labels TEXT,
                        PRIMARY KEY (key, time)
                    )
                ''')
                self._conn.commit()
            except sqlite3.Error as e:
                logger.error("Failed to initialize database: %s", e)
                raise

    def _save_db(self) -> None:
        """保存内存数据到数据库"""
        with self._db_lock:
            if not self._cursor or not self._conn:
                return
            try:
                self._cursor.execute("DELETE FROM items")
                for item_id, record in self._item_store.items():
                    self._cursor.execute('''
                        INSERT INTO items VALUES (?, ?, ?, ?, ?)
                    ''', (item_id, json.dumps(record["data"]), 
                          record["created_at"], record["updated_at"], record["version"]))
                self._conn.commit()
                
                self._cursor.execute("DELETE FROM metrics")
                for key, entries in self._metrics.items():
                    for entry in entries:
                        self._cursor.execute('''
                            INSERT INTO metrics VALUES (?, ?, ?, ?)
                        ''', (key, entry["value"], entry["time"], json.dumps(entry["labels"])))
                self._conn.commit()
            except sqlite3.Error as e:
                logger.error("Failed to save database: %s", e)

    def _load_db(self) -> None:
        """加载数据库数据到内存"""
        with self._db_lock:
            if not self._cursor:
                return
            try:
                self._cursor.execute("SELECT * FROM items")
                for row in self._cursor.fetchall():
                    self._item_store[row[0]] = {
                        "id": row[0],
                        "data": json.loads(row[1]),
                        "created_at": row[2],
                        "updated_at": row[3],
                        "version": row[4]
                    }
                
                self._cursor.execute("SELECT * FROM metrics")
                for row in self._cursor.fetchall():
                    key, value, time, labels = row
                    self._metrics.setdefault(key, []).append({
                        "value": value,
                        "time": time,
                        "labels": json.loads(labels)
                    })
            except sqlite3.Error as e:
                logger.error("Failed to load database: %s", e)

    def create_item(self, data: Dict[str, Any]) -> str:
        """创建数据项并加入倒排索引

        Args:
            data: 要存储的数据字典

        Returns:
            新创建项的唯一ID
        """
        with self._lock:
            item_id = generate_id("valuejudge_item")
            record = {
                "id": item_id,
                "data": data,
                "created_at": time.time(),
                "updated_at": time.time(),
                "version": 1
            }
            self._item_store[item_id] = record
            self._index.add(item_id, data)
            self._save_db()
            self._incr_stat("item_created")
            self._logger.debug("Created item: %s", item_id)
            return item_id

    def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """按ID获取数据项

        Args:
            item_id: 数据项ID

        Returns:
            数据内容字典；不存在时返回None
        """
        with self._lock:
            record = self._item_store.get(item_id, {})
            return record.get("data", None)

    def update_item(self, item_id: str, data: Dict[str, Any]) -> bool:
        """合并更新数据项并刷新索引

        Args:
            item_id: 数据项ID
            data: 要合并更新的字段

        Returns:
            是否成功更新
        """
        with self._lock:
            record = self._item_store.get(item_id)
            if not record:
                return False
            old_data = record["data"].copy()
            record["data"].update(data)
            record["updated_at"] = time.time()
            record["version"] += 1
        self._index.remove(item_id, old_data)
        self._index.add(item_id, record["data"])
        self._save_db()
        self._incr_stat("item_updated")
        return True

    def delete_item(self, item_id: str) -> bool:
        """删除数据项并移除索引

        Args:
            item_id: 数据项ID

        Returns:
            是否成功删除
        """
        with self._lock:
            record = self._item_store.pop(item_id, None)
        if not record:
            return False
        self._index.remove(item_id, record["data"])
        self._save_db()
        self._incr_stat("item_deleted")
        self._logger.debug("Deleted item: %s", item_id)
        return True

    def list_items(
        self,
        page: int = 1,
        page_size: int = 20,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """分页列出数据项

        Args:
            page: 页码（从1开始）
            page_size: 每页条数
            filters: 过滤条件，仅支持精确匹配

        Returns:
            包含items、total、page、page_size的字典
        """
        with self._lock:
            items = list(self._item_store.values())

        if filters:
            filtered: List[Dict[str, Any]] = []
            for record in items:
                if all(
                    record["data"].get(k) == v for k, v in filters.items()
                ):
                    filtered.append(record["data"])
            items = filtered

        total = len(items)
        start = max((page - 1) * page_size, 0)
        end = start + max(page_size, 0)
        return {
            "items": items[start:end],
            "total": total,
            "page": page,
            "page_size": page_size,
        }

    def count_items(self) -> int:
        """返回当前数据项总数"""
        with self._lock:
            return len(self._item_store)

    def search_items(
        self, query: str, fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """使用倒排索引搜索数据项

        Args:
            query: 搜索关键词（支持空格分词）
            fields: 指定搜索字段；None表示全字段

        Returns:
            匹配的数据项列表
        """
        matched_ids = self._index.search(query, fields)
        results: List[Dict[str, Any]] = []
        with self._lock:
            for item_id in matched_ids:
                record = self._item_store.get(item_id)
                if record is not None:
                    results.append(record["data"])
        return results

    def batch_create_items(self, batch: List[Dict[str, Any]]) -> List[str]:
        """批量创建数据项，单次加锁

        Args:
            batch: 数据项字典列表

        Returns:
            创建的项ID列表
        """
        ids: List[str] = []
        with self._lock:
            for item_data in batch:
                item_id = generate_id("valuejudge_item")
                record: Dict[str, Any] = {
                    "id": item_id,
                    "data": dict(item_data),
                    "created_at": time.time(),
                    "updated_at": time.time(),
                    "version": 1
                }
                self._item_store[item_id] = record
                ids.append(item_id)
            if ids:
                self._stats["item_created"] = (
                    self._stats.get("item_created", 0) + len(ids)
                )
        for item_id, item_data in zip(ids, batch):
            self._index.add(item_id, item_data)
        self._save_db()
        self._logger.debug("Batch created %d items", len(ids))
        return ids

    def batch_delete_items(self, ids: List[str]) -> int:
        """批量删除数据项，单次加锁

        Args:
            ids: 要删除的项ID列表

        Returns:
            成功删除的数量
        """
        deleted = 0
        with self._lock:
            for item_id in ids:
                record = self._item_store.pop(item_id, None)
                if record is not None:
                    deleted += 1
        for item_id in ids:
            if item_id not in self._item_store:
                # 我们需要从索引中移除，但需要知道旧数据
                # 由于我们在锁外无法获取旧数据，这里简化处理
                # 实际上应该在锁内收集要移除的数据
                pass
        
        # 重新实现批量删除以确保索引一致性
        removed_data = []
        with self._lock:
            for item_id in ids:
                record = self._item_store.pop(item_id, None)
                if record is not None:
                    removed_data.append((item_id, record["data"]))
        
        for item_id, data in removed_data:
            self._index.remove(item_id, data)
            
        if removed_data:
            self._incr_stat("item_deleted")
            self._save_db()
            self._logger.debug("Batch deleted %d items", len(removed_data))
        return len(removed_data)

    def export_items(self, path: str) -> str:
        """将所有数据项导出为JSON文件

        Args:
            path: 输出文件路径

        Returns:
            实际写入的文件路径
        """
        with self._lock:
            snapshot = list(self._item_store.values())
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(snapshot, fh, ensure_ascii=False, indent=2, cls=_FlexibleJSONEncoder)
        self._logger.info("Exported %d items to %s", len(snapshot), path)
        return path

    def import_items(self, path: str) -> int:
        """从JSON文件批量导入数据项

        Args:
            path: 输入文件路径

        Returns:
            成功导入的项数量

        Raises:
            FileNotFoundError: 文件不存在时抛出
        """
        if not Path(path).exists():
            raise FileNotFoundError(f"File {path} not found")
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        count = 0
        with self._lock:
            for record in data:
                item_id = record.get("id", generate_id("valuejudge_item"))
                self._item_store[item_id] = record
                count += 1
        for record in data:
            self._index.add(record["id"], record.get("data", {}))
        self._save_db()
        self._logger.info("Imported %d items from %s", count, path)
        return count

    def get_item_stats(self) -> Dict[str, Any]:
        """获取数据项统计摘要"""
        with self._lock:
            return {
                "total": len(self._item_store),
                "created": self._stats.get("item_created", 0),
                "updated": self._stats.get("item_updated", 0),
                "deleted": self._stats.get("item_deleted", 0),
            }

    def get_cache(self, key: str) -> Optional[Any]:
        """获取缓存值"""
        return self._cache.get(key)

    def set_cache(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """设置缓存值"""
        self._cache.set(key, value, ttl)

    def _incr_stat(self, stat_key: str) -> None:
        """递增统计计数器"""
        with self._lock:
            self._stats[stat_key] = self._stats.get(stat_key, 0) + 1

    def close(self) -> None:
        """关闭数据库连接"""
        with self._db_lock:
            if self._conn:
                self._conn.close()
                self._conn = None
                self._cursor = None
