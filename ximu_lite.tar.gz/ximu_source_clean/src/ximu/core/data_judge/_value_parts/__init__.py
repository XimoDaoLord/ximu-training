"""Split parts of value."""

__version__ = "0.5"

# 保持原有import路径和公共API兼容
# 此模块为包初始化文件，主要提供版本信息和模块说明

__all__ = ["__version__"]
