# -*- coding: utf-8 -*-
"""本地工作区路径管理：统一解析 uploads / memory / sandbox / snapshots 等工作目录。

运行时各模块通过 XIMU_WORKSPACE 环境变量指定工作区根目录，
本模块提供标准化的子路径解析，避免各模块各自硬编码 ./local_workspace/xxx。
"""
from __future__ import annotations

import os
import logging
from pathlib import Path
from typing import Optional

# 版本号
__version__ = "0.5"

# 配置常量
_WORKSPACE_ENV = "XIMU_WORKSPACE"
_DEFAULT_ROOT = "./local_workspace"
_SUBDIR_NAMES = ["uploads", "memory", "sandbox", "pool_snapshots"]

# 初始化日志记录器
logger = logging.getLogger(__name__)


def get_workspace_root() -> Path:
    """
    获取本地工作区根目录。

    优先读取环境变量 XIMU_WORKSPACE，若未设置则使用默认路径 ./local_workspace。
    如果目录不存在，将自动创建。

    Returns:
        Path: 工作区根目录的绝对路径对象。

    Raises:
        OSError: 当目录创建失败时抛出（例如权限不足）。
    """
    root_str = os.environ.get(_WORKSPACE_ENV, _DEFAULT_ROOT)
    root = Path(root_str)

    try:
        root.mkdir(parents=True, exist_ok=True)
        logger.info(f"Workspace root initialized: {root}")
        return root
    except OSError as e:
        logger.error(f"Failed to create workspace root at {root}: {e}")
        raise


def get_subdir(name: str, create: bool = True) -> Path:
    """
    获取工作区下的子目录路径。

    Args:
        name (str): 子目录名称。
        create (bool, optional): 是否自动创建子目录。默认为 True。

    Returns:
        Path: 子目录的绝对路径对象。

    Raises:
        OSError: 当目录创建失败时抛出（例如权限不足）。
    """
    root = get_workspace_root()
    p = root / name

    if create:
        try:
            p.mkdir(parents=True, exist_ok=True)
            logger.debug(f"Subdirectory verified/created: {p}")
        except OSError as e:
            logger.error(f"Failed to create subdirectory {p}: {e}")
            raise

    return p


def get_uploads_dir() -> Path:
    """获取上传目录路径。"""
    return get_subdir("uploads")


def get_memory_dir() -> Path:
    """获取内存目录路径。"""
    return get_subdir("memory")


def get_sandbox_dir() -> Path:
    """获取沙箱目录路径。"""
    return get_subdir("sandbox")


def get_snapshots_dir() -> Path:
    """获取快照目录路径。"""
    return get_subdir("pool_snapshots")


__all__ = [
    "get_workspace_root", "get_subdir",
    "get_uploads_dir", "get_memory_dir",
    "get_sandbox_dir", "get_snapshots_dir",
]
