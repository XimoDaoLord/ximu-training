"""
沙箱子工作区：隔离的用户文件操作目录。
"""
from typing import Optional

class LocalWorkspace:
    """
    本地沙箱子工作区类，用于隔离用户文件操作。
    """
    def __init__(self, workspace_path: str) -> None:
        """
        初始化沙箱子工作区。

        :param workspace_path: 沙箱子工作区的路径
        """
        self.workspace_path = workspace_path
        self._ensure_workspace_exists()

    def _ensure_workspace_exists(self) -> None:
        """
        确保沙箱子工作区存在，如果不存在则创建。
        """
        import os
        if not os.path.exists(self.workspace_path):
            os.makedirs(self.workspace_path)

    def create_file(self, file_name: str, content: str) -> None:
        """
        在沙箱子工作区中创建一个文件。

        :param file_name: 文件名
        :param content: 文件内容
        """
        import os
        file_path = os.path.join(self.workspace_path, file_name)
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(content)

    def read_file(self, file_name: str) -> str:
        """
        读取沙箱子工作区中的文件内容。

        :param file_name: 文件名
        :return: 文件内容
        """
        import os
        file_path = os.path.join(self.workspace_path, file_name)
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File {file_name} not found in workspace.")
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()

    def delete_file(self, file_name: str) -> None:
        """
        删除沙箱子工作区中的文件。

        :param file_name: 文件名
        """
        import os
        file_path = os.path.join(self.workspace_path, file_name)
        if os.path.exists(file_path):
            os.remove(file_path)
