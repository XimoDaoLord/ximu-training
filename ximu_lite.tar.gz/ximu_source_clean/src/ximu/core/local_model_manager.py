# -*- coding: utf-8 -*-
"""
本地模型管理器 - 扫描、识别、注册并管理本地多格式AI模型文件。

支持格式：GGUF、GGML、Safetensors、PyTorch(.pt/.pth)、ONNX。
自动读取模型元数据，注册到统一资源注册中心，支持本地推理调用与失败回退机制。
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import struct
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Protocol, Set, Tuple

logger = logging.getLogger(__name__)

# ==================== 枚举与数据类 ====================


class ModelFormat(Enum):
    """模型文件格式枚举。"""
    GGUF = "gguf"
    GGML = "ggml"
    SAFETENSORS = "safetensors"
    PYTORCH = "pytorch"
    ONNX = "onnx"
    UNKNOWN = "unknown"


class ModelQuantization(Enum):
    """模型量化方式枚举。"""
    F16 = "f16"
    F32 = "f32"
    Q4_0 = "q4_0"
    Q4_1 = "q4_1"
    Q5_0 = "q5_0"
    Q5_1 = "q5_1"
    Q8_0 = "q8_0"
    Q8_1 = "q8_1"
    UNKNOWN = "unknown"


class ModelPurpose(Enum):
    """模型用途标签枚举。"""
    CODE_GENERATION = "code_generation"
    CREATIVE_WRITING = "creative_writing"
    REASONING = "reasoning"
    ANALYSIS = "analysis"
    TRANSLATION = "translation"
    MULTI_MODAL = "multi_modal"
    GENERAL = "general"


class ModelCapability(Enum):
    """模型能力维度枚举。"""
    EMBED = "embed"
    GENERATE = "generate"
    OCR = "ocr"
    ASR = "asr"
    VISION = "vision"


class LocalModelStatus(Enum):
    """本地模型运行状态枚举。"""
    READY = "ready"
    SCANNING = "scanning"
    ERROR = "error"
    DISABLED = "disabled"


@dataclass
class LocalModelInfo:
    """本地模型元数据信息。"""
    model_id: str
    name: str
    path: str
    format: ModelFormat
    size_bytes: int
    quantization: ModelQuantization
    context_window: int
    parameters: int
    purpose: List[ModelPurpose]
    tags: List[str]
    status: LocalModelStatus = LocalModelStatus.READY
    enabled: bool = True
    last_used: Optional[str] = None
    call_count: int = 0
    success_rate: float = 1.0
    avg_latency_ms: float = 0.0
    capabilities: List[ModelCapability] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典供JSON存储或API传输。"""
        return {
            "model_id": self.model_id,
            "name": self.name,
            "path": self.path,
            "format": self.format.value,
            "size_bytes": self.size_bytes,
            "quantization": self.quantization.value,
            "context_window": self.context_window,
            "parameters": self.parameters,
            "purpose": [p.value for p in self.purpose],
            "tags": self.tags,
            "status": self.status.value,
            "enabled": self.enabled,
            "last_used": self.last_used,
            "call_count": self.call_count,
            "success_rate": self.success_rate,
            "avg_latency_ms": self.avg_latency_ms,
            "capabilities": [c.value for c in self.capabilities],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> LocalModelInfo:
        """从字典反序列化为LocalModelInfo。"""
        def _safe_enum(enum_cls: type, value: Any, default: Enum) -> Enum:
            try:
                return enum_cls(value)
            except (ValueError, KeyError):
                logger.debug("Unknown %s value: %r, using %r", enum_cls.__name__, value, default)
                return default

        return cls(
            model_id=str(data.get("model_id", "unknown")),
            name=str(data.get("name", "unknown")),
            path=str(data.get("path", "")),
            format=_safe_enum(ModelFormat, data.get("format"), ModelFormat.UNKNOWN),
            size_bytes=int(data.get("size_bytes", 0)),
            quantization=_safe_enum(ModelQuantization, data.get("quantization"), ModelQuantization.UNKNOWN),
            context_window=int(data.get("context_window", 0)),
            parameters=int(data.get("parameters", 0)),
            purpose=[
                _safe_enum(ModelPurpose, p, ModelPurpose.GENERAL)
                for p in data.get("purpose", [])
            ],
            tags=[str(t) for t in data.get("tags", [])],
            status=_safe_enum(LocalModelStatus, data.get("status", "ready"), LocalModelStatus.READY),
            enabled=bool(data.get("enabled", True)),
            last_used=data.get("last_used"),
            call_count=int(data.get("call_count", 0)),
            success_rate=float(data.get("success_rate", 1.0)),
            avg_latency_ms=float(data.get("avg_latency_ms", 0.0)),
            capabilities=[
                _safe_enum(ModelCapability, c, ModelCapability.GENERATE)
                for c in data.get("capabilities", [])
            ],
        )


@dataclass
class ModelScanResult:
    """单次目录扫描结果。"""
    scanned_path: str
    found_models: List[LocalModelInfo]
    errors: List[str]
    scan_time_ms: float

    @property
    def models(self) -> List[LocalModelInfo]:
        """兼容旧调用方的别名。"""
        return self.found_models


@dataclass
class ModelCallResult:
    """模型推理调用结果。"""
    success: bool
    model_id: str
    output: Optional[str]
    error: Optional[str]
    latency_ms: float
    fallback_triggered: bool = False
    detailed_error: Optional[str] = None


# ==================== 协议定义 ====================


class ResourceRegistryProtocol(Protocol):
    """资源注册中心协议，解耦具体实现。"""
    def register(self, resource_type: str, resource_id: str, metadata: Dict[str, Any]) -> None: ...
    def unregister(self, resource_type: str, resource_id: str) -> None: ...
    def get_resource(self, resource_type: str, resource_id: str) -> Optional[Dict[str, Any]]: ...


class ModelInferenceEngine(Protocol):
    """推理引擎协议。"""
    def generate(self, prompt: str, model_id: str, **kwargs: Any) -> str: ...
    def embed(self, text: str, model_id: str, **kwargs: Any) -> List[float]: ...


class ProgressCallback(Protocol):
    """扫描进度回调协议。"""
    def __call__(self, scanned: int, total: int, current_file: str) -> None: ...


# ==================== 资源注册中心 ====================


class PersistentResourceRegistry:
    """
    持久化资源注册中心。

    提供线程安全的模型资源注册、注销和查询功能，支持 SQLite 数据库存储。
    """
    DB_NAME = "model_registry.db"
    TABLE_NAME = "model_resources"

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._db_path = os.path.abspath(self.DB_NAME)
        self._init_database()

    def _init_database(self) -> None:
        import sqlite3
        with self._lock, sqlite3.connect(self._db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS {} (
                    resource_type TEXT PRIMARY KEY,
                    resource_id TEXT PRIMARY KEY,
                    metadata BLOB
                )""".format(self.TABLE_NAME)
            )

    def register(self, resource_type: str, resource_id: str, metadata: Dict[str, Any]) -> None:
        """注册资源到注册中心。"""
        with self._lock, sqlite3.connect(self._db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT OR REPLACE INTO {} VALUES (?, ?, ?)".format(self.TABLE_NAME),
                (resource_type, resource_id, sqlite3.Binary(json.dumps(metadata)))
            )
            logger.info("Registered %s/%s", resource_type, resource_id)

    def unregister(self, resource_type: str, resource_id: str) -> None:
        """从注册中心注销资源。"""
        with self._lock, sqlite3.connect(self._db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "DELETE FROM {} WHERE resource_type = ? AND resource_id = ?".format(self.TABLE_NAME),
                (resource_type, resource_id)
            )
            logger.debug("Unregistered %s/%s", resource_type, resource_id)

    def get_resource(self, resource_type: str, resource_id: str) -> Optional[Dict[str, Any]]:
        """查询已注册的资源。"""
        with self._lock, sqlite3.connect(self._db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT metadata FROM {} WHERE resource_type = ? AND resource_id = ?".format(self.TABLE_NAME),
                (resource_type, resource_id)
            )
            result = cursor.fetchone()
            return json.loads(result[0].decode()) if result else None

    def list_resources(self, resource_type: str) -> List[Dict[str, Any]]:
        """列出指定类型的所有资源。"""
        with self._lock, sqlite3.connect(self._db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT metadata FROM {} WHERE resource_type = ?".format(self.TABLE_NAME),
                (resource_type,)
            )
            return [json.loads(row[0].decode()) for row in cursor.fetchall()]

# ==================== 文件验证器 ====================


class ModelFileValidator:
    """
    模型文件验证器。

    负责检测不同格式模型的完整性、有效性及量化类型。
    """
    SUPPORTED_EXTENSIONS: Set[str] = {".gguf", ".ggml", ".safetensors", ".pt", ".pth", ".onnx"}
    GGUF_MAGIC_V2: int = 0x46554747
    MAX_HEADER_SIZE: int = 10 * 1024 * 1024

    GGUF_SCALAR_FMT: Dict[int, str] = {
        0: "<B", 1: "<b", 2: "<H", 3: "<h", 4: "<I", 5: "<i",
        6: "<f", 7: "<B", 10: "<Q", 11: "<q", 12: "<d",
    }
    GGUF_FILETYPE_MAP: Dict[int, ModelQuantization] = {
        0: ModelQuantization.F32, 1: ModelQuantization.F16,
        2: ModelQuantization.Q4_0, 3: ModelQuantization.Q4_1,
        6: ModelQuantization.Q5_0, 7: ModelQuantization.Q5_1,
        8: ModelQuantization.Q8_0, 9: ModelQuantization.Q8_1,
    }

    @staticmethod
    def is_supported_extension(filepath: str) -> bool:
        """检查文件扩展名是否受支持。"""
        return os.path.splitext(filepath)[1].lower() in ModelFileValidator.SUPPORTED_EXTENSIONS

    def validate(self, filepath: str) -> Tuple[bool, str]:
        """验证模型文件是否有效。"""
        if not os.path.exists(filepath):
            return False, f"File not found: {filepath}"
        if not self.is_supported_extension(filepath):
            return False, f"Unsupported extension: {filepath}"
        try:
            file_size = os.path.getsize(filepath)
            if file_size == 0:
                return False, "Empty file"
        except OSError as e:
            logger.warning("OS error getting file size for %s: %s", filepath, e)
            return False, f"OS error: {e}"

        ext = os.path.splitext(filepath)[1].lower()
        validators = {
            ".gguf": self._validate_gguf,
            ".safetensors": self._validate_safetensors,
            ".onnx": self._validate_onnx,
            ".pt": self._validate_pytorch,
            ".pth": self._validate_pytorch,
        }
        validator = validators.get(ext)
        if validator is None:
            return True, ""
        try:
            return validator(filepath)
        except OSError as e:
            logger.debug("OS error during validation of %s: %s", filepath, e)
            return False, f"OS error: {e}"
        except Exception as e:
            logger.debug("Validation failed for %s: %s", filepath, e)
            return False, f"Validation error: {e}"

    def _validate_gguf(self, filepath: str) -> Tuple[bool, str]:
        """验证 GGUF 文件头部魔数。"""
        try:
            with open(filepath, "rb") as f:
                magic_bytes = f.read(4)
                if len(magic_bytes) < 4:
                    return False, "File too short for GGUF magic"
                magic = struct.unpack("<I", magic_bytes)[0]
                if magic != self.GGUF_magic_v2:
                    return False, f"Invalid GGUF magic number: {magic:#x}"
            return True, ""
        except Exception as e:
            return False, f"GGUF read error: {e}"

    def _detect_gguf_quantization(self, filepath: str) -> ModelQuantization:
        """从 GGUF 元数据提取量化类型。"""
        try:
            with open(filepath, "rb") as f:
                magic_bytes = f.read(4)
                if len(magic_bytes) < 4:
                    return ModelQuantization.UNKNOWN
                magic = struct.unpack("<I", magic_bytes)[0]
                if magic != self.GGUF_magic_v2:
                    return ModelQuantization.UNKNOWN
                version_bytes = f.read(4)
                if len(version_bytes) < 4:
                    return ModelQuantization.UNKNOWN
                version = struct.unpack("<I", version_bytes)[0]
                if version not in (1, 2, 3):
                    return ModelQuantization.UNKNOWN
                f.read(8)  # tensor count placeholder
                count_bytes = f.read(8)
                if len(count_bytes) < 8:
                    return ModelQuantization.UNKNOWN
                kv_count = struct.unpack("<Q", count_bytes)[0]

                metadata: Dict[str, Any] = {}
                for _ in range(min(kv_count, 200)):
                    key_len_bytes = f.read(8)
                    if len(key_len_bytes) < 8:
                        break
                    key_len = struct.unpack("<Q", key_len_bytes)[0]
                    if key_len == 0 or key_len > 512:
                        break
                    key_data = f.read(key_len)
                    if len(key_data) < key_len:
                        break
                    key = key_data.decode("utf-8", "replace")
                    vtype_bytes = f.read(4)
                    if len(vtype_bytes) < 4:
                        break
                    vtype = struct.unpack("<I", vtype_bytes)[0]
                    try:
                        metadata[key] = self._read_gguf_value(f, vtype)
                    except Exception:
                        break

                file_type_key = "general.file_type" if "general.file_type" in metadata else "general.filetype"
                file_type_val = metadata.get(file_type_key)
                if isinstance(file_type_val, int) and file_type_val in self.GGUF_FILETYPE_MAP:
                    return self.GGUF_FILETYPE_MAP[file_type_val]
            return ModelQuantization.UNKNOWN
        except Exception:
            return ModelQuantization.UNKNOWN

    def _read_gguf_value(self, f: Any, vtype: int) -> Any:
        """按 GGUF 类型读取单个值。"""
        fmt = self.GGUF_SCALAR_FMT.get(vtype)
        if fmt is not None:
            size = struct.calcsize(fmt)
            data = f.read(size)
            if len(data) < size:
                raise EOFError
            return struct.unpack(fmt, data)[0]
        if vtype == 8:
            n_bytes = f.read(8)
            if len(n_bytes) < 8:
                raise EOFError
            n = struct.unpack("<Q", n_bytes)[0]
            data = f.read(n)
            return data.decode("utf-8", "replace") if n > 0 else ""
        if vtype == 9:
            etype_bytes = f.read(4)
            if len(etype_bytes) < 4:
                raise EOFError
            etype = struct.unpack("<I", etype_bytes)[0]
            n_bytes = f.read(8)
            if len(n_bytes) < 8:
                raise EOFError
            n = struct.unpack("<Q", n_bytes)[0]
            limit = min(n, 100)
            result = []
            for _ in range(limit):
                val = self._read_gguf_value(f, etype)
                result.append(val)
            return result
        return None

    def _detect_pytorch_quantization(self, filepath: str) -> ModelQuantization:
        """从 PyTorch 文件推断量化方式。"""
        try:
            import torch
            with open(filepath, "rb") as f:
                sig = f.read(16)
                if sig[:4] != b"PK\x03\x04":
                    return ModelQuantization.UNKNOWN
            state_dict = torch.load(filepath, map_location="cpu", weights_only=True)
            for key, val in state_dict.items():
                if isinstance(val, torch.Tensor):
                    dtype = str(val.dtype).lower()
                    if dtype == "float16":
                        return ModelQuantization.F16
                    elif dtype == "float32":
                        return ModelQuantization.F32
                    elif "q" in dtype:
                        parts = dtype.split('.')
                        if len(parts) > 1 and parts[1] in ("4", "5", "8"):
                            return ModelQuantization.__getattribute__(ModelQuantization, f"Q{parts[1]}_{parts[2]}_0")
            return ModelQuantization.UNKNOWN
        except ImportError:
            logger.debug("torch not available, skipping PyTorch quantization")
            return ModelQuantization.UNKNOWN
        except Exception as e:
            logger.debug("PyTorch quantization detection failed: %s", e)
            return ModelQuantization.UNKNOWN


# 兼容别名
class LocalModelManager:
    """本地模型管理器。"""
    def __init__(self, config=None):
        self.config = config or {}
    def list_models(self):
        return []
    def load_model(self, name: str):
        return None


LocalModelManager.GGUF_MAGIC_V2 = b"GGUF"  # type: ignore
