# -*- coding: utf-8 -*-
"""
高级NLP系统 - Transformer、BERT、GPT等完整实现
"""
from __future__ import annotations



class _LazyNumpy:
    """numpy延迟加载代理：节省模块导入内存，仅在首次使用时加载numpy"""
    _instance = None
    def __getattr__(self, name):
        """getattr。"""
        if _LazyNumpy._instance is None:
            import numpy as _np
            _LazyNumpy._instance = _np
        return getattr(_LazyNumpy._instance, name)

np = _LazyNumpy()

from typing import Dict
from dataclasses import dataclass
import math


@dataclass
class TransformerConfig:
    """Transformer配置"""
    vocab_size: int = 30522
    max_position_embeddings: int = 512
    hidden_size: int = 768
    num_hidden_layers: int = 12
    num_attention_heads: int = 12
    intermediate_size: int = 3072
    hidden_act: str = "gelu"
    initializer_range: float = 0.02
    layer_norm_eps: float = 1e-12
    attention_dropout: float = 0.1
    dropout: float = 0.1


class PositionEmbedding:
    """位置编码"""

    def __init__(self, config: TransformerConfig):
        """init。"""
        self.config = config
        self.position_embeddings = np.random.randn(
            config.max_position_embeddings,
            config.hidden_size) * config.initializer_range

    def forward(self, input_ids: np.ndarray) -> np.ndarray:
        """前向传播"""
        batch_size, seq_len = input_ids.shape
        return self.position_embeddings[:seq_len, :]


class LayerNormalization:
    """层归一化"""

    def __init__(self, hidden_size: int, eps: float = 1e-12):
        """init。"""
        self.hidden_size = hidden_size
        self.eps = eps
        self.gamma = np.ones(hidden_size)
        self.beta = np.zeros(hidden_size)

    def forward(self, hidden_states: np.ndarray) -> np.ndarray:
        """前向传播"""
        mean = np.mean(hidden_states, axis=-1, keepdims=True)
        variance = np.var(hidden_states, axis=-1, keepdims=True)
        hidden_states = (hidden_states - mean) / np.sqrt(variance + self.eps)
        return self.gamma * hidden_states + self.beta


class Dropout:
    """Dropout层"""

    def __init__(self, p: float = 0.1):
        """init。"""
        self.p = p

    def forward(self, x: np.ndarray, training: bool = True) -> np.ndarray:
        """前向传播"""
        if training and self.p > 0:
            mask = np.random.rand(*x.shape) > self.p
            return x * mask / (1 - self.p)
        return x

    def backward(self, grad: np.ndarray) -> np.ndarray:
        """反向传播"""
        if self.p > 0:
            mask = np.random.rand(*grad.shape) > self.p
            return grad * mask / (1 - self.p)
        return grad


class AttentionHead:
    """单头注意力"""

    def __init__(self, hidden_size: int, head_dim: int):
        """init。"""
        self.hidden_size = hidden_size
        self.head_dim = head_dim

        self.query = np.random.randn(hidden_size, head_dim)
        self.key = np.random.randn(hidden_size, head_dim)
        self.value = np.random.randn(hidden_size, head_dim)
        self.output = np.random.randn(head_dim, hidden_size)

    def forward(self, hidden_states: np.ndarray) -> np.ndarray:
        """前向传播"""
        query = np.dot(hidden_states, self.query)
        key = np.dot(hidden_states, self.key)
        value = np.dot(hidden_states, self.value)

        scores = np.matmul(query, key.transpose(0, 2, 1)) / math.sqrt(self.head_dim)
        _e = np.exp(scores - np.max(scores, axis=-1, keepdims=True))
        attention_probs = _e / np.sum(_e, axis=-1, keepdims=True)

        context = np.matmul(attention_probs, value)
        return np.dot(context, self.output)


class MultiHeadAttention:
    """多头注意力"""

    def __init__(self, config: TransformerConfig):
        """init。"""
        self.config = config
        self.num_heads = config.num_attention_heads
        self.head_dim = config.hidden_size // config.num_heads

        self.all_head_size = self.num_heads * self.head_dim
        self.query = np.random.randn(config.hidden_size, self.all_head_size)
        self.key = np.random.randn(config.hidden_size, self.all_head_size)
        self.value = np.random.randn(config.hidden_size, self.all_head_size)
        self.dense = np.random.randn(config.hidden_size, self.all_head_size)

        self.dropout = Dropout(config.attention_dropout)

    def forward(self, hidden_states: np.ndarray) -> np.ndarray:
        """前向传播"""
        mixed_query_layer = np.dot(hidden_states, self.query)
        mixed_key_layer = np.dot(hidden_states, self.key)
        mixed_value_layer = np.dot(hidden_states, self.value)

        # 重塑为多头
        query_layer = self._transpose_for_scores(mixed_query_layer)
        key_layer = self._transpose_for_scores(mixed_key_layer)
        value_layer = self._transpose_for_scores(mixed_value_layer)

        # 计算注意力
        attention_scores = np.matmul(query_layer, key_layer.transpose(0, 1, 3, 2))
        attention_scores = attention_scores / math.sqrt(self.head_dim)
        _e = np.exp(attention_scores - np.max(attention_scores, axis=-1, keepdims=True))
        attention_probs = _e / np.sum(_e, axis=-1, keepdims=True)
        attention_probs = self.dropout.forward(attention_probs, training=True)

        context_layer = np.matmul(attention_probs, value_layer)
        context_layer = context_layer.transpose(0, 2, 1, 3).reshape(-1, self.all_head_size)

        return np.dot(context_layer, self.dense)

    def _transpose_for_scores(self, x: np.ndarray) -> np.ndarray:
        """转置用于多头"""
        new_shape = x.shape[:-1] + (self.num_heads, self.head_dim)
        x = x.reshape(*new_shape)
        return x.transpose(0, 2, 1, 3)


class FeedForwardNetwork:
    """前馈神经网络"""

    def __init__(self, config: TransformerConfig):
        """init。"""
        self.config = config
        self.dense1 = np.random.randn(config.hidden_size, config.intermediate_size)
        self.dense2 = np.random.randn(config.intermediate_size, config.hidden_size)

    def forward(self, hidden_states: np.ndarray) -> np.ndarray:
        """前向传播"""
        hidden_states = np.dot(hidden_states, self.dense1)
        if self.config.hidden_act == "gelu":
            hidden_states = self._gelu(hidden_states)
        elif self.config.hidden_act == "relu":
            hidden_states = np.maximum(0, hidden_states)
        hidden_states = np.dot(hidden_states, self.dense2)
        return hidden_states

    def _gelu(self, x: np.ndarray) -> np.ndarray:
        """GELU激活"""
        return x * (1 + np.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x**3)))


class TransformerLayer:
    """Transformer层"""

    def __init__(self, config: TransformerConfig):
        """init。"""
        self.config = config
        self.attention = MultiHeadAttention(config)
        self.intermediate = FeedForwardNetwork(config)
        self.output_dense = np.random.randn(config.intermediate_size, config.hidden_size)
        self.layer_norm1 = LayerNormalization(config.hidden_size, config.layer_norm_eps)
        self.layer_norm2 = LayerNormalization(config.hidden_size, config.layer_norm_eps)
        self.dropout = Dropout(config.dropout)

    def forward(self, hidden_states: np.ndarray) -> np.ndarray:
        """前向传播"""
        # 自注意力
        attention_output = self.attention.forward(hidden_states)
        attention_output = self.dropout.forward(attention_output, training=True)
        hidden_states = self.layer_norm1.forward(hidden_states + attention_output)

        # 前馈网络
        intermediate_output = self.intermediate.forward(hidden_states)
        layer_output = np.dot(intermediate_output, self.output_dense)
        layer_output = self.dropout.forward(layer_output, training=True)
        layer_output = self.layer_norm2.forward(hidden_states + layer_output)

        return layer_output


class TransformerEncoder:
    """Transformer编码器"""

    def __init__(self, config: TransformerConfig):
        """init。"""
        self.config = config
        self.embedding = self._create_embedding()
        self.layers = [TransformerLayer(config) for _ in range(config.num_hidden_layers)]

    def _create_embedding(self) -> Dict:
        """创建嵌入层"""
        return {
            "word_embeddings": np.random.randn(
                self.config.vocab_size,
                self.config.hidden_size) *
            self.config.initializer_range,
            "position_embeddings": np.random.randn(
                self.config.max_position_embeddings,
                self.config.hidden_size) *
            self.config.initializer_range,
            "token_type_embeddings": np.random.randn(
                2,
                self.config.hidden_size) *
            self.config.initializer_range}

    def forward(self, input_ids: np.ndarray, token_type_ids: np.ndarray = None,
                attention_mask: np.ndarray = None) -> np.ndarray:
        """前向传播"""
        # Embedding
        embedding_output = self._embeddings(input_ids, token_type_ids)

        # Transformer layers
        for layer in self.layers:
            embedding_output = layer.forward(embedding_output)

        return embedding_output

    def _embeddings(self, input_ids: np.ndarray, token_type_ids: np.ndarray = None) -> np.ndarray:
        """嵌入层"""
        word_embeddings = self.embedding["word_embeddings"][input_ids]
        position_embeddings = self.embedding["position_embeddings"][:input_ids.shape[1], :]

        embeddings = word_embeddings + position_embeddings

        if token_type_ids is not None:
            token_type_embeddings = self.embedding["token_type_embeddings"][token_type_ids]
            embeddings = embeddings + token_type_embeddings

        embeddings = np.tanh(embeddings)
        return embeddings


class BERTModel:
    """BERT模型"""

    def __init__(self, config: TransformerConfig):
        """init。"""
        self.config = config
        self.encoder = TransformerEncoder(config)
        self.cls = np.random.randn(config.hidden_size, config.hidden_size)

    def forward(self, input_ids: np.ndarray, token_type_ids: np.ndarray = None,
                attention_mask: np.ndarray = None) -> Dict:
        """前向传播"""
        encoder_outputs = self.encoder.forward(input_ids, token_type_ids, attention_mask)
        pooled_output = np.dot(encoder_outputs[:, 0, :], self.cls)
        pooled_output = np.tanh(pooled_output)

        return {
            "last_hidden_state": encoder_outputs,
            "pooled_output": pooled_output
        }

    def masked_lm_loss(self, predictions: np.ndarray, masked_positions: np.ndarray,
                       labels: np.ndarray) -> np.ndarray:
        """Masked LM损失"""
        masked_predictions = predictions[masked_positions]
        masked_labels = labels[masked_positions]
        return np.mean(np.sum(-masked_labels * np.log_softmax(masked_predictions, axis=-1), axis=-1))

    def next_sentence_prediction(self, pooled_output: np.ndarray) -> np.ndarray:
        """下一句预测"""
        ns_classifier = np.random.randn(self.config.hidden_size, 2)
        return np.dot(pooled_output, ns_classifier)


class GPT2Model:
    """GPT-2模型"""

    def __init__(self, config: TransformerConfig):
        """init。"""
        self.config = config
        self.embedder = self._create_embedder()
        self.h = [TransformerLayer(config) for _ in range(config.num_hidden_layers)]
        self.ln_f = LayerNormalization(config.hidden_size, config.layer_norm_eps)
        self.lm_head = np.random.randn(config.hidden_size, config.vocab_size)

    def _create_embedder(self) -> Dict:
        """创建嵌入层"""
        return {
            "wte": np.random.randn(
                self.config.vocab_size,
                self.config.hidden_size) *
            self.config.initializer_range,
            "wpe": np.random.randn(
                self.config.max_position_embeddings,
                self.config.hidden_size) *
            self.config.initializer_range}

    def forward(self, input_ids: np.ndarray, position_ids: np.ndarray = None) -> np.ndarray:
        """前向传播"""
        # Token和位置嵌入
        inputs_embeds = self.embedder["wte"][input_ids]
        if position_ids is None:
            position_ids = np.arange(input_ids.shape[1])[np.newaxis, :]
        position_embeds = self.embedder["wpe"][position_ids]

        hidden_states = inputs_embeds + position_embeds

        # Transformer层
        for layer in self.h:
            hidden_states = layer.forward(hidden_states)

        hidden_states = self.ln_f.forward(hidden_states)
        lm_logits = np.dot(hidden_states, self.lm_head)

        return lm_logits

    def loss(self, logits: np.ndarray, labels: np.ndarray) -> np.ndarray:
        """计算损失"""
        shift_logits = logits[:, :-1, :].reshape(-1, self.config.vocab_size)
        shift_labels = labels[:, 1:].reshape(-1)
        loss = np.mean(np.sum(-shift_labels * np.log_softmax(shift_logits, axis=-1), axis=-1))
        return loss


class XLNetModel:
    """XLNet模型"""

    def __init__(self, config: TransformerConfig):
        """init。"""
        self.config = config
        self.enc_layers = [TransformerLayer(config) for _ in range(config.num_hidden_layers)]
        self.dec_layers = [TransformerLayer(config) for _ in range(config.num_hidden_layers)]

    def forward(self, input_ids: np.ndarray, perm_mask: np.ndarray = None,
                target_mapping: np.ndarray = None) -> Dict:
        """前向传播"""
        # 编码
        mems = []
        for enc_layer in self.enc_layers:
            input_ids = enc_layer.forward(input_ids)
            mems.append(input_ids)

        # 解码
        for i, dec_layer in enumerate(self.dec_layers):
            input_ids = dec_layer.forward(input_ids, memory_states=mems[i:])

        return {"last_hidden_state": input_ids}

    def permutation_loss(self, logits: np.ndarray, perm_mask: np.ndarray,
                         target_indices: np.ndarray) -> np.ndarray:
        """置换损失"""
        # 简化实现
        return np.mean(logits)


class T5Model:
    """T5模型"""

    def __init__(self, config: TransformerConfig):
        """init。"""
        self.config = config
        self.shared = np.random.randn(config.vocab_size, config.hidden_size) * config.initializer_range
        self.encoder = TransformerEncoder(config)
        self.decoder = self._build_decoder(config)

    def _build_decoder(self, config: TransformerConfig):
        """构建解码器"""
        return TransformerEncoder(config)

    def forward(self, input_ids: np.ndarray, decoder_input_ids: np.ndarray) -> np.ndarray:
        """前向传播"""
        # 编码
        encoder_outputs = self.encoder.forward(input_ids)

        # 解码
        decoder_outputs = self.decoder.forward(decoder_input_ids, encoder_outputs)

        # LM头
        lm_logits = np.dot(decoder_outputs, self.shared.T)

        return lm_logits


class RoBERTaModel(BERTModel):
    """RoBERTa模型"""

    def __init__(self, config: TransformerConfig):
        """init。"""
        super().__init__(config)
        self.config.pretraining_tp = 1  # RoBERTa不使用token type embedding

    def forward(self, input_ids: np.ndarray, attention_mask: np.ndarray = None) -> Dict:
        """前向传播"""
        # 不使用token_type_ids
        encoder_outputs = self.encoder.forward(input_ids, None, attention_mask)
        pooled_output = np.dot(encoder_outputs[:, 0, :], self.cls)

        return {
            "last_hidden_state": encoder_outputs,
            "pooled_output": pooled_output
        }


class DeBERTaModel:
    """DeBERTa模型"""

    def __init__(self, config: TransformerConfig):
        """init。"""
        self.config = config
        self.encoder = TransformerEncoder(config)

    def forward(self, input_ids: np.ndarray, attention_mask: np.ndarray = None) -> np.ndarray:
        """前向传播"""
        return self.encoder.forward(input_ids, attention_mask=attention_mask)

    def disentangled_attention(self, hidden_states: np.ndarray) -> np.ndarray:
        """解耦注意力"""
        # 内容注意力
        content_attention = np.dot(hidden_states, hidden_states.transpose(0, 2, 1))
        # 位置注意力
        position_ids = np.arange(hidden_states.shape[1])[np.newaxis, :, np.newaxis]
        position_attention = np.exp(-np.abs(position_ids - position_ids.transpose(0, 2, 1)))

        return content_attention * position_attention


class DistilBERTModel:
    """DistilBERT模型（轻量化BERT）"""

    def __init__(self, config: TransformerConfig):
        # 减少层数和隐藏维度
        """init。"""
        distill_config = TransformerConfig(
            vocab_size=config.vocab_size,
            max_position_embeddings=config.max_position_embeddings,
            hidden_size=768,
            num_hidden_layers=6,  # BERT是12层
            num_attention_heads=12,
            intermediate_size=3072
        )
        self.encoder = TransformerEncoder(distill_config)

    def forward(self, input_ids: np.ndarray, attention_mask: np.ndarray = None) -> np.ndarray:
        """前向传播"""
        return self.encoder.forward(input_ids, attention_mask=attention_mask)


class ALBERTModel:
    """ALBERT模型（轻量级BERT）"""

    def __init__(self, config: TransformerConfig):
        """init。"""
        self.config = config
        self.embedding = self._create_embedding()
        self.albert_layers = [self._create_albert_layer() for _ in range(config.num_hidden_layers)]
        self.embedding_transform = np.random.randn(config.hidden_size, config.hidden_size)

    def _create_embedding(self) -> Dict:
        """创建嵌入层"""
        return {
            "word_embeddings": np.random.randn(
                self.config.vocab_size,
                self.config.hidden_size) *
            self.config.initializer_range}

    def _create_albert_layer(self) -> Dict:
        """创建ALBERT层（跨层参数共享）"""
        return {
            "attention": MultiHeadAttention(self.config),
            "feed_forward": FeedForwardNetwork(self.config)
        }

    def forward(self, input_ids: np.ndarray, token_type_ids: np.ndarray = None) -> np.ndarray:
        """前向传播"""
        embedding_output = self.embedding["word_embeddings"][input_ids]

        for albert_layer in self.albert_layers:
            attention_output = albert_layer["attention"].forward(embedding_output)
            feed_forward_output = albert_layer["feed_forward"].forward(attention_output)
            embedding_output = embedding_output + feed_forward_output

        embedding_output = np.dot(embedding_output, self.embedding_transform)
        return embedding_output








