#!/usr/bin/env python3
"""
汐沫AI高级记忆引擎 - Advanced Memory Engine Module
功能:七层提纯、语义索引、长期记忆、记忆代谢
架构:
    - 多层记忆存储（短期/中期/长期）
    - 七层信息提纯引擎
    - 语义索引与检索
    - 记忆巩固与遗忘机制
    - 记忆关联与推理
版本:0.5
作者:Agnes AI Agent
日期:2024-01-15
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto

logger = logging.getLogger(__name__)


def _gen_chunk_id() -> str:
    """
    生成唯一的记忆片段ID

    延迟导入uuid模块，仅在首次创建MemoryChunk时加载
    确保高性能且避免循环依赖

    Returns:
        str: UUID4格式的唯一标识符
    """
    import uuid
    return str(uuid.uuid4())


class MemoryLevel(Enum):
    """
    记忆层级枚举

    定义不同层次的记忆类型，从感觉记忆到程序性记忆
    层级越高，信息处理深度越大，存储周期越长
    """
    SENSORY = auto()
    SHORT_TERM = auto()
    WORKING = auto()
    MEDIUM_TERM = auto()
    LONG_TERM = auto()
    EPISODIC = auto()
    SEMANTIC = auto()
    PROCEDURAL = auto()


class MemoryType(Enum):
    """
    记忆类型枚举

    定义记忆内容的不同模态和结构
    """
    TEXT = auto()
    IMAGE = auto()
    AUDIO = auto()
    VIDEO = auto()
    STRUCTURED = auto()
    KNOWLEDGE = auto()
    EXPERIENCE = auto()
    SKILL = auto()


class ConsolidationStrategy(Enum):
    """
    记忆巩固策略枚举

    定义记忆从短期到长期的转化机制
    """
    IMMEDIATE = auto()
    BATCH = auto()
    SLEEP_DEPENDENT = auto()
    EVENT_DRIVEN = auto()
    MANUAL = auto()


@dataclass
class MemoryChunk:
    """
    记忆片段数据类

    表示单个记忆单元，包含内容、元数据、访问统计等信息
    支持访问追踪、衰退计算和序列化

    Attributes:
        chunk_id: 唯一标识符
        memory_type: 记忆类型
        content: 记忆内容（任意类型）
        level: 记忆层级
        timestamp: 创建时间戳
        importance: 重要性评分（0.0-1.0）
        accessibility: 可访问性评分（0.0-1.0）
        context: 上下文信息
        tags: 标签列表
        associations: 关联记忆ID列表
        access_count: 访问次数
        last_accessed: 最后访问时间
    """
    chunk_id: str = field(default_factory=_gen_chunk_id)
    memory_type: MemoryType = MemoryType.TEXT
    content: Any = None
    level: MemoryLevel = MemoryLevel.SHORT_TERM
    timestamp: datetime = field(default_factory=datetime.now)
    importance: float = 0.5
    accessibility: float = 1.0
    context: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    associations: List[str] = field(default_factory=list)
    access_count: int = 0
    last_accessed: Optional[datetime] = None

    def access(self) -> None:
        """
        记录一次访问

        增加访问计数器，更新时间戳，提升可访问性
        可访问性最大值为1.0

        Raises:
            ValueError: 当访问记录异常时
        """
        try:
            self.access_count += 1
            self.last_accessed = datetime.now()
            self.accessibility = min(1.0, self.accessibility + 0.05)
            logger.debug(f"Memory chunk {self.chunk_id} accessed, count={self.access_count}")
        except Exception as e:
            logger.error(f"Failed to record access for chunk {self.chunk_id}: {e}")
            raise

    def decay(self, rate: float = 0.01) -> None:
        """
        应用记忆衰退

        降低可访问性，模拟遗忘过程
        可访问性最小值为0.0

        Args:
            rate: 衰退率（默认0.01）

        Raises:
            ValueError: 当衰退计算异常时
        """
        try:
            self.accessibility = max(0.0, self.accessibility - rate)
            logger.debug(f"Memory chunk {self.chunk_id} decayed by {rate}, accessibility={self.accessibility}")
        except Exception as e:
            logger.error(f"Failed to apply decay to chunk {self.chunk_id}: {e}")
            raise

    def to_dict(self) -> Dict[str, Any]:
        """
        序列化为字典

        将记忆片段转换为可JSON序列化的字典格式
        内容字段截断为前500字符以避免过大

        Returns:
            Dict[str, Any]: 序列化后的字典
        """
        return {
            "chunk_id": self.chunk_id,
            "memory_type": self.memory_type.name,
            "content": str(self.content)[:500] if self.content else None,
            "level": self.level.name,
            "timestamp": self.timestamp.isoformat(),
            "importance": self.importance,
            "accessibility": self.accessibility,
            "tags": self.tags,
            "associations": self.associations,
            "access_count": self.access_count
        }

    def __post_init__(self) -> None:
        """
        数据类初始化后处理

        验证字段完整性并记录创建事件
        """
        if self.chunk_id is None:
            self.chunk_id = _gen_chunk_id()
        logger.debug(f"Memory chunk created: {self.chunk_id}, type={self.memory_type.name}, level={self.level.name}")


# P0修复：AdvancedMemory别名指向MemoryChunk，保持向后兼容
AdvancedMemory = MemoryChunk

# 公共API版本标记
__version__ = "0.5"
