# -*- coding: utf-8 -*-
"""核心模块自注册装配（F20/F21 接通层）。

背景：personality_team/ 与 self_optimization/ 已存在且可独立工作，
但此前没有任何主流程引用它们（grep 无外部调用点），等于"挂在角落"。
本模块负责把这两个单例挂进统一 component_registry，使：
  - 任务调度/反思面板可经注册表发现人格团队与自优化器；
  - 不改动 main.py、不改任何现有函数签名与 import 链。

设计：全部 try/except 惰性装配，任一模块失败不影响其余，也不阻断启动。
"""
from __future__ import annotations

import logging
import threading
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# 使用线程锁确保幂等性和并发安全
_wired_lock = threading.Lock()
_wired = False

# 模块版本号
MODULE_VERSION = "0.5"


def _get_component_registry() -> Dict[str, Any]:
    """复用 prompt_system 维护的统一注册表命名空间，避免另起炉灶。

    如果无法导入 prompt_system 或获取注册表，返回空字典。
    此异常属于配置缺失或依赖问题，记录警告但不中断流程。
    """
    try:
        from .prompt_system.manager import _COMPONENT_REGISTRY
        return _COMPONENT_REGISTRY
    except Exception as e:
        logger.warning("无法获取组件注册表，返回空字典: %s", e)
        return {}


def _wire_personality_team(reg: Dict[str, Any]) -> None:
    """装配 F20 人格团队协作模块。

    将 personality_team 单例实例注册到组件注册表中。
    若导入或获取实例失败，记录警告并跳过，不影响其他模块装配。

    参数:
        reg: 组件注册表字典
    """
    try:
        from .personality_team import get_personality_team
        reg["personality_team"] = {
            "type": "personality_team",
            "instance": get_personality_team(),
            "version": MODULE_VERSION,
            "live": True,
        }
        logger.debug("personality_team 已装配到注册表")
    except Exception as e:
        logger.warning("personality_team 装配跳过: %s", e)


def _wire_self_optimization(reg: Dict[str, Any]) -> None:
    """装配 F21 系统自我优化模块。

    将 self_optimization 单例实例注册到组件注册表中。
    若导入或获取实例失败，记录警告并跳过，不影响其他模块装配。

    参数:
        reg: 组件注册表字典
    """
    try:
        from .self_optimization import get_self_optimizer
        reg["self_optimization"] = {
            "type": "self_optimization",
            "instance": get_self_optimizer(),
            "version": MODULE_VERSION,
            "live": True,
        }
        logger.debug("self_optimization 已装配到注册表")
    except Exception as e:
        logger.warning("self_optimization 装配跳过: %s", e)


def get_component_registry() -> Dict[str, Any]:
    """获取统一组件注册表。

    此函数是公共 API，保持与原始接口兼容。
    复用 prompt_system 维护的注册表命名空间。

    返回:
        组件注册表字典
    """
    return _get_component_registry()


def ensure_wired(force: bool = False) -> Dict[str, Any]:
    """把已存在但未接线的核心模块装配进注册表。幂等。

    使用线程锁保证并发安全，避免重复装配。
    支持 force 参数强制重新装配（即使已装配过）。

    参数:
        force: 是否强制重新装配，默认为 False

    返回:
        装配完成后的组件注册表字典
    """
    global _wired

    with _wired_lock:
        if _wired and not force:
            logger.debug("核心模块已装配，跳过重复装配")
            return get_component_registry()

        reg = get_component_registry()

        # F20 人格团队协作：多人格 scope 隔离、绑定子任务、走中转池
        _wire_personality_team(reg)

        # F21 系统自我优化：瓶颈发现 + 缓存/路由/调度自动优化
        _wire_self_optimization(reg)

        _wired = True
        logger.debug("核心模块装配流程完成")
        return reg


def wired_modules() -> Dict[str, Any]:
    """获取只读视图：当前已装配进注册表的核心模块清单。

    此函数是公共 API，保持与原始接口兼容。
    仅返回标记为 live=True 的组件。

    返回:
        包含已装配核心模块的字典，键为模块名，值为模块信息字典
    """
    ensure_wired()
    reg = get_component_registry()
    return {
        k: v for k, v in reg.items()
        if isinstance(v, dict) and v.get("live", False)
    }
