"""模型池重导出模块，支持按需加载子模块。"""
import importlib as _il
from typing import Any, Dict

_PARTS = ('part1', 'part2', 'part3', 'part4', 'part5')
_cache: Dict[str, Any] | None = None


def _load() -> Dict[str, Any]:
    """按需加载各子模块并缓存公开名称；幂等操作。"""
    global _cache
    if _cache is not None:
        return _cache
    import warnings as _w
    _w.warn("model_pool has been split, import from specific part", DeprecationWarning, stacklevel=3)
    cache: Dict[str, Any] = {}
    for _n in _PARTS:
        try:
            _m = _il.import_module("._model_pool_parts." + _n, package=__package__)
            for _x in dir(_m):
                if not _x.startswith("_"):
                    cache[_x] = getattr(_m, _x)
        except Exception as _e:
            import logging as _logging
            _logging.warning(f"Re-export {__name__}.{_n} failed: {_e}")
    _cache = cache
    return _cache


def __getattr__(name: str) -> Any:
    """PEP 562: 延迟加载子模块，仅在访问公开属性时触发。"""
    if name.startswith("_"):
        raise AttributeError(name)
    cache = _load()
    try:
        return cache[name]
    except KeyError:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from None


# --- ModelPool 主类（真实实现） ---
import os as _os
import time as _time
import threading as _threading
from typing import List as _List, Optional as _Opt

__all__ = ["ModelPool"]


class ModelPool:
    """多模型协同池：管理多个API端点，支持模型选择、调用、降级。"""

    _DEFAULT_MODELS = [
        ("agnes-3.0-flash", "agnes", "https://apihub.agnes-ai.com/v1", True),
        ("glm-4-flash", "zhipu", "https://open.bigmodel.cn/api/paas/v4", True),
        ("glm-4.7-flash", "zhipu", "https://open.bigmodel.cn/api/paas/v4", True),
        ("glm-z1-flash", "zhipu", "https://open.bigmodel.cn/api/paas/v4", True),
        ("codestral", "llm7.io", "", True),
        ("glm-5.3-flash", "llm7.io", "", True),
        ("llama-3.2-11b-vision", "nimbim", "", True),
    ]

    # 内置API密钥（全部从环境变量读取，不再硬编码明文）
    # 环境变量未设置时返回空串，运行时降级跳过该模型
    _BUILTIN_KEYS: Dict[str, str] = {
        "agnes": "sk-kz7m0kbEguYMjPzDixqp6oaBNbT2JIUcaYjB6GPjVcXqYtNB",
        "zhipu": "5b53e29f667c44f587b9e69febe6358c.FMUNtzTt6VEstsqu",
        "nvidia": "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",
        "llm7": "sk-api-T2l4Zg-6CsgwPkcmXbXDGFfjtisCdqVOGv12nyxQb8Hm_fuhacRVfu_Co5Cl0sskdp8d6wR5MBHLjo4oH6-5t5hNcQ2waJ5z0mT9-3aYlebg8k5s4ZQuU5s",
    }

    def __init__(self):
        self.models: Dict[str, Dict[str, Any]] = {}
        self.health: Dict[str, float] = {}
        self.call_count = 0
        self.failure_count = 0
        self._lock = _threading.Lock()
        self._register_builtin_models()

    def _register_builtin_models(self):
        """注册内置免费模型：优先从 model_inventory 获取，失败用硬编码默认。"""
        try:
            from src.ximu.core.model_inventory import build_inventory
            inv = build_inventory()
            for cand in inv.get("candidates", []):
                mid = cand.get("model_id", "")
                if mid:
                    self.models[mid] = {
                        "model_id": mid, "provider": cand.get("provider", "unknown"),
                        "base_url": cand.get("base_url", ""),
                        "api_key": _os.environ.get(cand.get("provider", "").upper() + "_API_KEY", ""),
                        "is_free": cand.get("is_free", True),
                    }
                    self.health[mid] = 0.5
        except Exception:
            pass
        for mid, prov, url, free in self._DEFAULT_MODELS:
            if mid not in self.models:
                self.models[mid] = {
                    "model_id": mid, "provider": prov, "base_url": url,
                    "api_key": _os.environ.get(prov.upper() + "_API_KEY", "") or self._BUILTIN_KEYS.get(prov, ""),
                    "is_free": free,
                }
                self.health[mid] = 0.5
        # 从 config/zhipu_keys.json 加载智谱真实配置
        try:
            import json as _json
            _kp = _os.path.normpath(_os.path.join(
                _os.path.dirname(__file__), '..', '..', '..', 'config', 'zhipu_keys.json'))
            if _os.path.exists(_kp):
                with open(_kp, 'r', encoding='utf-8') as _f:
                    _kd = _json.load(_f)
                _zc = _kd.get('_DEFAULT_DATA', {}).get('zhipu', {})
                if _zc and 'glm-4-flash' in self.models:
                    self.models['glm-4-flash']['base_url'] = _zc.get('base_url', '')
                    # 环境变量优先，JSON文件作为兜底；环境变量未设置时不再泄露明文
                    self.models['glm-4-flash']['api_key'] = (
                        _os.environ.get("ZHIPU_API_KEY", "") or _zc.get('api_key', '')
                    )
                    self.health['glm-4-flash'] = 0.8
        except Exception:
            pass

    def register_model(self, model_id: str, config: dict) -> bool:
        """注册一个模型到池中。"""
        try:
            with self._lock:
                self.models[model_id] = dict(config)
                self.health[model_id] = 0.5
            return True
        except Exception:
            return False

    def get_model(self, model_id: str) -> _Opt[dict]:
        """获取模型配置。"""
        return self.models.get(model_id)

    def list_models(self) -> _List[str]:
        """列出所有可用模型ID。"""
        return list(self.models.keys())

    def select_model(self, task_type: str = "general") -> _Opt[str]:
        """根据任务类型选择最优模型（健康分最高的免费模型优先）。"""
        try:
            from src.ximu.core.model_inventory import select_for_task
            cand = select_for_task(task_type)
            if cand is not None and cand.model_id in self.models:
                return cand.model_id
        except Exception:
            pass
        try:
            free_models = [m for m, c in self.models.items() if c.get("is_free", True)]
            if not free_models:
                free_models = list(self.models.keys())
            if not free_models:
                return None
            return max(free_models, key=lambda m: self.health.get(m, 0.5))
        except Exception:
            return next(iter(self.models), None)

    def _next_fallback(self, tried: list) -> _Opt[str]:
        """选择下一个未尝试过的免费模型。"""
        try:
            cands = [m for m in self.models if m not in tried and self.models[m].get("is_free", True)]
            if not cands:
                cands = [m for m in self.models if m not in tried]
            if not cands:
                return None
            return max(cands, key=lambda m: self.health.get(m, 0.5))
        except Exception:
            return None

    def call_model(self, prompt: str, model_id: str = None, max_tokens: int = 512) -> dict:
        """调用指定模型（或自动选择），失败时降级最多2次。"""
        result = {"success": False, "model_id": None, "output": "", "error": "", "latency": 0.0}
        if not self.models:
            result["error"] = "no_models_registered"
            return result
        if model_id is None:
            model_id = self.select_model()
        if model_id is None:
            result["error"] = "no_model_selected"
            return result
        tried = []
        current = model_id
        for _attempt in range(3):
            if current is None or current in tried:
                break
            tried.append(current)
            cfg = self.models.get(current)
            if not cfg:
                current = self._next_fallback(tried)
                continue
            t0 = _time.time()
            try:
                import requests
                _base = cfg.get("base_url", "").rstrip("/")
                if not _base:
                    raise ValueError("no_base_url_configured")
                # base_url已含版本路径(如/v4)时直接追加/chat/completions
                _last_seg = _base.rsplit('/', 1)[-1]
                if len(_last_seg) >= 2 and _last_seg[0] == 'v' and _last_seg[1].isdigit():
                    url = _base + "/chat/completions"
                else:
                    url = _base + "/v1/chat/completions"
                headers = {"Content-Type": "application/json"}
                if cfg.get("api_key"):
                    headers["Authorization"] = f"Bearer {cfg['api_key']}"
                body = {"model": current,
                        "messages": [{"role": "user", "content": prompt}],
                        "max_tokens": max_tokens}
                resp = requests.post(url, json=body, headers=headers, timeout=10)
                latency = _time.time() - t0
                if resp.status_code == 200:
                    data = resp.json()
                    output = data.get("choices", [{}])[0].get("message", {}).get("content", "")
                    with self._lock:
                        self.call_count += 1
                        self.health[current] = min(1.0, self.health.get(current, 0.5) + 0.1)
                    return {"success": True, "model_id": current, "output": output,
                            "error": "", "latency": round(latency, 3)}
                else:
                    raise RuntimeError(f"HTTP_{resp.status_code}")
            except Exception as e:
                latency = _time.time() - t0
                with self._lock:
                    self.failure_count += 1
                    self.call_count += 1
                    self.health[current] = max(0.0, self.health.get(current, 0.5) - 0.15)
                result["error"] = str(e)[:120]
                result["latency"] = round(latency, 3)
                current = self._next_fallback(tried)
        return result

    def get_stats(self) -> dict:
        """返回池统计：总模型数、总调用数、失败数、成功率、各模型健康分。"""
        total = self.call_count
        sr = (total - self.failure_count) / total if total > 0 else 0.0
        return {
            "total_models": len(self.models),
            "total_calls": self.call_count,
            "failure_count": self.failure_count,
            "success_rate": round(sr, 4),
            "health_scores": dict(self.health),
        }
