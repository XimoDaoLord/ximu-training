"""Re-export hub for mood_system (split into 2 parts, original 3523 lines)."""

import importlib
import logging
import warnings

__version__ = "0.5"

logger = logging.getLogger(__name__)

def _reexport_module() -> None:
    """Re-export public names from the split sub-modules.
    
    This function imports 'part1' and 'part2' from the '_mood_system_parts' 
    package and re-exports all public names (those not starting with '_') 
    into the global namespace of this module. This maintains backward compatibility 
    for imports that expect to find mood_system contents at the top level.
    
    Raises:
        None: Exceptions are caught and logged to prevent breaking the import chain.
    """
    for part_name in ['part1', 'part2']:
        try:
            module = importlib.import_module(
                f"._mood_system_parts.{part_name}",
                package=__package__,
            )

            # Re-export all public attributes
            for attr_name in dir(module):
                if not attr_name.startswith('_'):
                    setattr(globals(), attr_name, getattr(module, attr_name))

            logger.debug(f"Successfully re-exported module: {part_name}")

        except Exception as e:
            logger.warning(f"Re-export {__name__}.{part_name} failed: {e}")

# Emit deprecation warning
warnings.warn(
    "mood_system has been split, import from specific part",
    DeprecationWarning,
    stacklevel=2
)

# Execute the re-export logic
_reexport_module()
