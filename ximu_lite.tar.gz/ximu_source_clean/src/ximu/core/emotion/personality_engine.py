import warnings
"""
0.5版本personality_engine模块导出器
将原3616行代码重构为结构化导入机制
保持原有__package__和全局API兼容性
核心功能：自动导入并导出personality_engine_parts.part1和part2模块
"""
import importlib as _il
import logging as _logging
from typing import Any, Optional, TypeVar

_T = TypeVar('_T')

def _import_part(part_name: str, package: str) -> Optional[dict[str, Any]]:
    """安全导入指定personality_engine部件
    :param part_name: 部件名称（part1或part2）
    :param package: 当前模块的package标识
    :return: 导入成功的模块属性字典，失败返回None
    """
    try:
        module = _il.import_module(f"._{part_name}", package=package)
        return {name: getattr(module, name) for name in dir(module) if not name.startswith('_')}
    except ImportError as e:
        _logging.warning(f"Failed to import {package}.{part_name}: {str(e)}")
        return None

def _safe_reexport(module_attrs: dict[str, Any]) -> None:
    """安全导出模块属性到全局命名空间
    :param module_attrs: 需要导出的属性字典
    """
    for name, obj in module_attrs.items():
        if not name.startswith('_'):
            globals()[name] = obj

def __init__module() -> None:
    """初始化并导出personality_engine两个部件
    通过__init__模块方法触发导出过程
    """
    parts = ['part1', 'part2']
    for part in parts:
        attrs = _import_part(part, __package__)
        if attrs:
            _safe_reexport(attrs)

__init__module()

# 保留原始警告信息
_w = warnings
_w.warn("personality_engine has been split, import from specific part", 
        DeprecationWarning, stacklevel=2)
