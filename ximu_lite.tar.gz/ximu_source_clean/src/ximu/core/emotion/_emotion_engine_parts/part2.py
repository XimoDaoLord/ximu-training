"""
情绪引擎核心组件：生成、表达、调节
基于事件驱动架构，提供可复用的基础类与具体实现
"""

import logging
import os
import json
import threading
from collections import deque, defaultdict
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
from .part1 import EmotionItem, EmotionState, EmotionMemory
from src.ximu.common.utils import now_timestamp

logger = logging.getLogger(__name__)

class EmotionComponent:
    """
    情绪组件基类，提供存储管理、事件总线、指标记录、生命周期管理等公共功能。
    派生类可在此基础之上实现具体的情绪处理逻辑。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化组件
        """
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=500)
        self._initialized: bool = False
        self._last_maintenance: float = 0.0
        self._maintenance_interval: float = 300.0
        self._store_types: Dict[str, type] = {}

    def register_store(self, name: str, store_obj: Any) -> None:
        """
        注册一个情绪存储实例
        """
        if not isinstance(store_obj, (EmotionMemoryStore, EmotionStateStore, HistoryStore)):
            raise TypeError(f"无效的情绪存储类型: {type(store_obj).__name__}")
        with self._lock:
            self._stores[name] = store_obj
            self._store_types[name] = type(store_obj)
            logger.debug("已注册情绪存储 '%s'，类型: %s", name, type(store_obj).__name__)
            self._emit("store_registered", {"name": name})

    def get_store(self, name: str) -> Optional[Any]:
        """
        获取指定名称的情绪存储
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """
        移除指定名称的情绪存储
        """
        with self._lock:
            s = self._stores.pop(name, None)
            if s:
                self._store_types.pop(name, None)
                logger.debug("已移除情绪存储 '%s'", name)
                self._emit("store_removed", {"name": name})
            return s is not None

    def on(self, event: str, handler: Callable) -> None:
        """
        注册事件处理器
        """
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable) -> None:
        """
        注销事件处理器
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Optional[Dict[str, Any]] = None) -> None:
        """
        发出事件，通知所有注册的处理程序
        """
        handlers = list(self._event_handlers.get(event, []))
        for h in handlers:
            try:
                h(data or {})
            except Exception as e:
                logger.debug("操作失败: %s", e, exc_info=True)

    def record_metric(self, name: str, value: float) -> None:
        """
        记录指标数据
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({"metric": name, "value": value, "timestamp": now_timestamp()})

    def get_metric(self, name: str) -> float:
        """
        获取指定指标的值
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """
        获取所有指标数据
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        """
        重置所有指标
        """
        with self._lock:
            self._metrics.clear()
            logger.debug("已重置指标数据")

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取最近的指标历史记录
        """
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """
        初始化组件
        """
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._emit("initialized", {})
            logger.debug("情绪组件已初始化")
            return True

    def shutdown(self) -> bool:
        """
        关闭组件
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            self._emit("shutdown", {})
            logger.debug("情绪组件已关闭")
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Union[str, int]]:
        """
        维护情绪存储，清理过期数据
        """
        with self._lock:
            now = now_timestamp()
            if not force and now - self._last_maintenance < self._maintenance_interval:
                return {"status": "skipped"}
            cleaned = 0
            for name, s in self._stores.items():
                if hasattr(s, "cleanup_expired"):
                    try:
                        cleaned += s.cleanup_expired()
                    except Exception as e:
                        logger.debug("操作失败: %s", e, exc_info=True)
            self._last_maintenance = now
            self._emit("maintenance", {"cleaned": cleaned})
            logger.debug("情绪组件维护完成，清理了 %d 条数据", cleaned)
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        """
        获取组件统计信息
        """
        with self._lock:
            store_stats = {}
            for name, s in self._stores.items():
                if hasattr(s, "get_stats"):
                    try:
                        store_stats[name] = s.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(s, "size"):
                    store_stats[name] = {"size": s.size()}
            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history),
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        将组件状态转换为字典
        """
        with self._lock:
            return {
                "config": dict(self._config),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys()),
            }

    def export_state(self, filepath: str) -> None:
        """
        导出组件状态到文件
        """
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, default=str)
        logger.debug("已导出状态到文件 %s", filepath)

    def import_state(self, filepath: str) -> bool:
        """
        从文件导入组件状态
        """
        if not os.path.exists(filepath):
            logger.warning("导入失败，文件不存在: %s", filepath)
            return False
        with open(filepath, "r", encoding="utf-8") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                logger.error("导入失败，JSON 格式错误: %s", e)
                return False
        with self._lock:
            if "config" in data and isinstance(data["config"], dict):
                self._config.update(data["config"])
            if "metrics" in data and isinstance(data["metrics"], dict):
                self._metrics.update(data["metrics"])
            logger.debug("已导入状态从文件 %s", filepath)
            return True


class EmotionGenerator(EmotionComponent):
    """
    情绪生成器，负责根据外部事件生成情绪状态。
    继承自 EmotionComponent，添加了情绪生成逻辑。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化情绪生成器
        """
        super().__init__(**kwargs)
        self._generation_rules: List[Dict[str, Any]] = []

    def add_generation_rule(self, rule: Dict[str, Any]) -> None:
        """
        添加情绪生成规则
        """
        with self._lock:
            self._generation_rules.append(rule)
            logger.debug("已添加情绪生成规则: %s", rule.get("name", "unknown"))

    def remove_generation_rule(self, rule_name: str) -> bool:
        """
        移除指定名称的情绪生成规则
        """
        with self._lock:
            original_length = len(self._generation_rules)
            self._generation_rules = [r for r in self._generation_rules if r.get("name") != rule_name]
            removed = len(self._generation_rules) < original_length
            if removed:
                logger.debug("已移除情绪生成规则: %s", rule_name)
            return removed

    def generate_emotion(self, context: Dict[str, Any]) -> Optional[EmotionItem]:
        """
        根据上下文生成情绪
        """
        with self._lock:
            for rule in self._generation_rules:
                if self._matches_rule(context, rule):
                    emotion = EmotionItem(
                        category=rule.get("category", "neutral"),
                        valence=rule.get("valence", 0.0),
                        arousal=rule.get("arousal", 0.0),
                        duration=rule.get("duration", 10.0),
                    )
                    self._emit("emotion_generated", {"emotion": emotion, "context": context})
                    logger.debug("已生成情绪: %s", emotion.category)
                    return emotion
            logger.debug("没有匹配的情绪生成规则")
            return None

    def _matches_rule(self, context: Dict[str, Any], rule: Dict[str, Any]) -> bool:
        """
        检查上下文是否匹配生成规则
        """
        conditions = rule.get("conditions", {})
        for key, value in conditions.items():
            if context.get(key) != value:
                return False
        return True


class EmotionExpressor(EmotionComponent):
    """
    情绪表达器，负责将情绪状态转化为可感知表达形式。
    继承自 EmotionComponent，添加了情绪表达逻辑。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化情绪表达器
        """
        super().__init__(**kwargs)
        self._expression_handlers: Dict[str, Callable] = {}

    def register_expression_handler(self, handler_name: str, handler: Callable) -> None:
        """
        注册情绪表达处理程序
        """
        with self._lock:
            self._expression_handlers[handler_name] = handler
            logger.debug("已注册情绪表达处理程序: %s", handler_name)

    def unregister_expression_handler(self, handler_name: str) -> bool:
        """
        注销情绪表达处理程序
        """
        with self._lock:
            if handler_name in self._expression_handlers:
                del self._expression_handlers[handler_name]
                logger.debug("已注销情绪表达处理程序: %s", handler_name)
                return True
            return False

    def express_emotion(self, emotion: EmotionItem) -> Dict[str, Any]:
        """
        表达情绪状态
        """
        with self._lock:
            result = {}
            for name, handler in self._expression_handlers.items():
                try:
                    result[name] = handler(emotion)
                except Exception as e:
                    logger.debug("情绪表达处理程序失败: %s, 错误: %s", name, e, exc_info=True)
                    result[name] = "error"
            self._emit("emotion_expressed", {"emotion": emotion, "result": result})
            logger.debug("已表达情绪: %s", emotion.category)
            return result


class EmotionRegulator(EmotionComponent):
    """
    情绪调节器，负责调节和转换情绪状态。
    继承自 EmotionComponent，添加了情绪调节逻辑。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化情绪调节器
        """
        super().__init__(**kwargs)
        self._regulation_strategies: List[Callable] = []
        self._intensity_modifier: float = 1.0

    def add_regulation_strategy(self, strategy: Callable) -> None:
        """
        添加情绪调节策略
        """
        with self._lock:
            self._regulation_strategies.append(strategy)
            logger.debug("已添加情绪调节策略: %s", strategy.__name__)

    def remove_regulation_strategy(self, strategy_name: str) -> bool:
        """
        移除指定名称的情绪调节策略
        """
        with self._lock:
            original_length = len(self._regulation_strategies)
            self._regulation_strategies = [s for s in self._regulation_strategies if s.__name__ != strategy_name]
            removed = len(self._regulation_strategies) < original_length
            if removed:
                logger.debug("已移除情绪调节策略: %s", strategy_name)
            return removed

    def set_intensity_modifier(self, modifier: float) -> None:
        """
        设置情绪强度调节系数
        """
        with self._lock:
            self._intensity_modifier = modifier
            logger.debug("已设置强度调节系数: %.2f", modifier)

    def regulate_emotion(self, emotion: EmotionItem) -> EmotionItem:
        """
        调节情绪状态
        """
        with self._lock:
            regulated = emotion
            for strategy in self._regulation_strategies:
                try:
                    regulated = strategy(regulated)
                except Exception as e:
                    logger.debug("情绪调节策略失败: %s, 错误: %s", strategy.__name__, e, exc_info=True)
                    break
            if self._intensity_modifier != 1.0:
                regulated = EmotionItem(
                    category=regulated.category,
                    valence=regulated.valence * self._intensity_modifier,
                    arousal=regulated.arousal * self._intensity_modifier,
                    duration=regulated.duration,
                )
            self._emit("emotion_regulated", {"original": emotion, "regulated": regulated})
            logger.debug("已调节情绪: %s -> %s", emotion.category, regulated.category)
            return regulated


class EmotionDecisionMaker(EmotionComponent):
    """
    情绪决策器，根据当前情绪状态做出行为决策。
    继承自 EmotionComponent，添加了决策逻辑。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化情绪决策器
        """
        super().__init__(**kwargs)
        self._decision_rules: List[Dict[str, Any]] = []

    def add_decision_rule(self, rule: Dict[str, Any]) -> None:
        """
        添加情绪决策规则
        """
        with self._lock:
            self._decision_rules.append(rule)
            logger.debug("已添加情绪决策规则: %s", rule.get("name", "unknown"))

    def remove_decision_rule(self, rule_name: str) -> bool:
        """
        移除指定名称的情绪决策规则
        """
        with self._lock:
            original_length = len(self._decision_rules)
            self._decision_rules = [r for r in self._decision_rules if r.get("name") != rule_name]
            removed = len(self._decision_rules) < original_length
            if removed:
                logger.debug("已移除情绪决策规则: %s", rule_name)
            return removed

    def make_decision(self, emotion: EmotionItem) -> Dict[str, Any]:
        """
        根据情绪状态做出决策
        """
        with self._lock:
            for rule in self._decision_rules:
                if self._matches_rule(emotion, rule):
                    self._emit("decision_made", {"emotion": emotion, "decision": rule})
                    logger.debug("已做出决策: %s, 基于情绪: %s", rule.get("name", "unknown"), emotion.category)
                    return rule
            logger.debug("没有匹配的情绪决策规则")
            return {"action": "none", "confidence": 0.0}

    def _matches_rule(self, emotion: EmotionItem, rule: Dict[str, Any]) -> bool:
        """
        检查情绪是否匹配决策规则
        """
        conditions = rule.get("conditions", {})
        for key, value in conditions.items():
            if key == "category" and emotion.category != value:
                return False
            elif key == "valence" and abs(emotion.valence - value) > 0.1:
                return False
            elif key == "arousal" and abs(emotion.arousal - value) > 0.1:
                return False
        return True
