"""
汐沫AI - P5情感引擎 Emotion Engine
第1批 核心数据模型与存储层

本模块实现情感引擎的核心数据存储、状态管理与识别调度功能。
包含以下核心组件：
- 情感枚举类型定义
- 情感数据模型（EmotionItem/EmotionState/EmotionMemory）
- 通用情感存储引擎基类（EmotionStateStoreBase）
- 内存存储引擎（EmotionMemoryStore）
- LRU缓存机制（带TTL支持）
- 情感识别器（EmotionRecognizer）

Version: 0.5
"""

import json
import logging
import threading
import time
import uuid
import heapq
from collections import OrderedDict, defaultdict, deque
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple, TypeVar, Union
from dataclasses import dataclass, field, asdict

logger = logging.getLogger(__name__)

# 线程本地配置存储
_thread_local = threading.local()

# 类型别名
ItemId = str
ItemType = TypeVar("ItemType")


def _get_config() -> Optional[Dict[str, Any]]:
    """获取线程本地配置对象
    
    Returns:
        配置字典，若未配置则返回None
    """
    if not hasattr(_thread_local, "config"):
        try:
            from config.settings import config as _cfg
            _thread_local.config = _cfg
            logger.debug("Config loaded successfully")
        except ImportError:
            _thread_local.config = None
            logger.debug("Config not found, using defaults")
    return _thread_local.config


def generate_id(prefix: str = "id") -> str:
    """生成带前缀的唯一ID
    
    Args:
        prefix: ID前缀
        
    Returns:
        唯一ID字符串
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


def now_timestamp() -> float:
    """获取当前Unix时间戳
    
    Returns:
        当前时间戳（秒）
    """
    return time.time()


def now_datetime() -> datetime:
    """获取东八区当前时间
    
    Returns:
        东八区datetime对象
    """
    return datetime.now(timezone(timedelta(hours=8)))


class Stopwatch:
    """轻量级计时器，用于性能测量"""
    
    def __init__(self) -> None:
        self._start: float = 0.0
        self._end: float = 0.0

    def start(self) -> "Stopwatch":
        """启动计时器"""
        self._start = time.time()
        return self

    def stop(self) -> "Stopwatch":
        """停止计时器"""
        self._end = time.time()
        return self

    @property
    def elapsed_ms(self) -> float:
        """获取经过的时间（毫秒）"""
        return (self._end - self._start) * 1000.0


# ==================== 情感枚举定义 ====================

class EmotionCategory(str, Enum):
    """情感类别枚举"""
    JOY = "joy"
    SADNESS = "sadness"
    ANGER = "anger"
    FEAR = "fear"
    SURPRISE = "surprise"
    DISGUST = "disgust"
    TRUST = "trust"
    ANTICIPATION = "anticipation"
    NEUTRAL = "neutral"
    LOVE = "love"
    HATE = "hate"
    HOPE = "hope"
    DESPAIR = "despair"
    CALM = "calm"
    ANXIETY = "anxiety"


class AffectDimension(str, Enum):
    """情感维度枚举（PAD模型）"""
    VALENCE = "valence"
    AROUSAL = "arousal"
    DOMINANCE = "dominance"


class EmotionIntensity(str, Enum):
    """情感强度等级枚举"""
    FAINT = "faint"
    WEAK = "weak"
    MODERATE = "moderate"
    STRONG = "strong"
    INTENSE = "intense"
    OVERWHELMING = "overwhelming"


class EmotionGenerationSource(str, Enum):
    """情感生成来源枚举"""
    EXTERNAL = "external"
    INTERNAL = "internal"
    MEMORY = "memory"
    EMPATHY = "empathy"
    HABIT = "habit"
    GOAL = "goal"


class EmotionRegulationStrategy(str, Enum):
    """情感调节策略枚举"""
    REAPPRAISAL = "reappraisal"
    SUPPRESSION = "suppression"
    DISTRACTION = "distraction"
    ACCEPTANCE = "acceptance"
    REFLECTION = "reflection"
    EXPRESSION = "expression"


class EmotionDecisionFactor(str, Enum):
    """情感决策影响因素枚举"""
    MOOD = "mood"
    PERSONALITY = "personality"
    CONTEXT = "context"
    GOAL = "goal"
    RELATIONSHIP = "relationship"
    PAST_EXPERIENCE = "past_experience"


# ==================== 情感数据模型 ====================

@dataclass
class EmotionItem:
    """情感存储项数据模型"""
    item_id: str
    content: str
    store_type: str
    category: str
    source: str
    tags: List[str]
    created_at: float
    updated_at: float
    last_accessed: float
    access_count: int
    importance: float
    weight: float
    valence: float
    arousal: float
    dominance: float
    metadata: Dict[str, Any]
    permanent: bool = False

    def __post_init__(self) -> None:
        """初始化默认时间戳"""
        if self.created_at == 0.0:
            self.created_at = now_timestamp()
        if self.updated_at == 0.0:
            self.updated_at = now_timestamp()
        if self.last_accessed == 0.0:
            self.last_accessed = now_timestamp()

    def access(self) -> None:
        """标记访问并更新时间戳"""
        self.last_accessed = now_timestamp()
        self.access_count += 1

    def get_strength(self) -> float:
        """计算情感强度（基于配置化阈值）
        
        Returns:
            强度值 [0.0, 1.0]
        """
        config = _get_config()
        if config is None:
            access_threshold = 20
        else:
            access_threshold = config.get("ACCESS_THRESHOLD", 20)
        
        access_factor = min(1.0, self.access_count / max(1, access_threshold))
        strength = (0.3 + 0.3 * access_factor + 0.4 * self.importance) * self.weight
        return max(0.0, min(1.0, strength))

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典"""
        return asdict(self)


@dataclass
class EmotionState:
    """情感状态快照数据模型"""
    emotion_id: str
    category: str
    valence: float
    arousal: float
    dominance: float
    intensity: float
    source: str
    trigger: str
    created_at: float
    duration: float
    expressed: bool
    regulated: bool
    regulation_strategy: str
    metadata: Dict[str, Any]

    def __post_init__(self) -> None:
        """初始化默认时间戳"""
        if self.created_at == 0.0:
            self.created_at = now_timestamp()

    def express(self) -> None:
        """标记情感表达"""
        self.expressed = True

    def regulate(self, strategy: str) -> None:
        """执行情感调节
        
        Args:
            strategy: 调节策略名称
        """
        self.regulated = True
        self.regulation_strategy = strategy
        self.intensity *= 0.5

    def decay(self, rate: float = 0.01) -> None:
        """情感衰减处理
        
        Args:
            rate: 衰减率，默认0.01
        """
        self.intensity = max(0.0, self.intensity * (1.0 - rate))

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典"""
        return asdict(self)


@dataclass
class EmotionMemory:
    """情感记忆条目数据模型"""
    mem_id: str
    emotion_category: str
    context: str
    intensity: float
    valence: float
    created_at: float
    recall_count: int
    associated_memories: List[str]
    metadata: Dict[str, Any]

    def __post_init__(self) -> None:
        """初始化默认时间戳"""
        if self.created_at == 0.0:
            self.created_at = now_timestamp()

    def recall(self) -> None:
        """标记回忆次数"""
        self.recall_count += 1

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典"""
        return asdict(self)


# ==================== LRU缓存（带TTL） ====================

class LRUCache:
    """带TTL的LRU缓存实现
    
    Attributes:
        max_size: 最大缓存条目数
        default_ttl: 默认过期时间（秒）
    """
    
    def __init__(self, max_size: int = 500, default_ttl: float = 300.0) -> None:
        """初始化缓存
        
        Args:
            max_size: 最大缓存容量
            default_ttl: 默认TTL（秒）
        """
        self._cache: OrderedDict[str, Tuple[Any, float]] = OrderedDict()
        self._max_size = max(1, max_size)
        self._default_ttl = max(0.0, default_ttl)
        self._hits: int = 0
        self._misses: int = 0

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值
        
        Args:
            key: 缓存键
            
        Returns:
            缓存值，若过期或不存在则返回None
        """
        if key not in self._cache:
            self._misses += 1
            return None
        
        value, expire_at = self._cache[key]
        if time.time() > expire_at:
            del self._cache[key]
            self._misses += 1
            logger.debug(f"Cache key expired: {key}")
            return None
        
        self._cache.move_to_end(key)
        self._hits += 1
        return value

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """设置缓存值
        
        Args:
            key: 缓存键
            value: 缓存值
            ttl: 过期时间（秒），None则使用默认值
        """
        if len(self._cache) >= self._max_size:
            self._evict()
        
        expire_at = time.time() + (ttl if ttl is not None else self._default_ttl)
        self._cache[key] = (value, expire_at)

    def invalidate(self, key: str) -> bool:
        """使指定键失效
        
        Args:
            key: 缓存键
            
        Returns:
            是否成功删除
        """
        if key in self._cache:
            del self._cache[key]
            return True
        return False

    def clear(self) -> None:
        """清空缓存"""
        self._cache.clear()
        self._hits = 0
        self._misses = 0

    @property
    def size(self) -> int:
        """当前缓存大小"""
        return len(self._cache)

    @property
    def hit_rate(self) -> float:
        """缓存命中率"""
        total = self._hits + self._misses
        if total == 0:
            return 0.0
        return self._hits / total

    def _evict(self) -> None:
        """淘汰最久未使用的条目"""
        if self._cache:
            self._cache.popitem(last=False)


# ==================== 情感存储引擎基类 ====================

class EmotionStateStoreBase:
    """情感存储引擎基类，提供通用存储功能
    
    Attributes:
        _items: 主存储字典
        _tag_index: 标签索引
        _type_index: 类型索引
        _source_index: 来源索引
        _time_heap: 时间堆（用于淘汰）
        _max: 最大存储数量
        _lock: 线程锁
        _cache: LRU缓存
    """
    
    def __init__(self, max_items: int = 10000, cache_ttl: float = 300.0) -> None:
        """初始化存储引擎
        
        Args:
            max_items: 最大存储条目数
            cache_ttl: 缓存TTL（秒）
        """
        self._items: Dict[str, Any] = {}
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._type_index: Dict[str, Set[str]] = defaultdict(set)
        self._source_index: Dict[str, Set[str]] = defaultdict(set)
        self._time_heap: List[Tuple[float, str]] = []
        self._max = max(1, max_items)
        self._lock = threading.RLock()
        self._cache = LRUCache(default_ttl=cache_ttl)
        self._config = _get_config()
        
        logger.info(f"EmotionStateStoreBase initialized with max_items={max_items}, cache_ttl={cache_ttl}")

    def add(self, item: Any) -> Any:
        """添加情感项
        
        Args:
            item: 情感数据项
            
        Returns:
            添加成功后的item
        """
        with self._lock:
            if len(self._items) >= self._max:
                self._evict_weakest()
            
            iid = self._extract_item_id(item)
            self._items[iid] = item
            
            for tag in getattr(item, "tags", []):
                self._tag_index[tag.lower()].add(iid)
            
            itype = self._extract_store_type(item)
            self._type_index[itype].add(iid)
            
            src = getattr(item, "source", "")
            if src:
                self._source_index[src].add(iid)
            
            heapq.heappush(self._time_heap, (self._get_created_at(item), iid))
            
            cache_key = f"{itype}_{iid}"
            self._cache.set(cache_key, item)
            
            logger.debug(f"Added item: {iid}, type={itype}")
            return item

    def get(self, item_id: str) -> Optional[Any]:
        """获取情感项
        
        Args:
            item_id: 项ID
            
        Returns:
            情感项，不存在则返回None
        """
        with self._lock:
            item = self._items.get(item_id)
            if item is None:
                return None
            
            if hasattr(item, "access"):
                item.access()
            
            return item

    def remove(self, item_id: str) -> bool:
        """删除情感项
        
        Args:
            item_id: 项ID
            
        Returns:
            是否删除成功
        """
        with self._lock:
            item = self._items.get(item_id)
            if item is None:
                return False
            
            # 从主存储移除
            del self._items[item_id]
            
            # 从标签索引移除
            for tag in getattr(item, "tags", []):
                tag_key = tag.lower()
                if tag_key in self._tag_index:
                    self._tag_index[tag_key].discard(item_id)
                    if not self._tag_index[tag_key]:
                        del self._tag_index[tag_key]
            
            # 从类型索引移除
            itype = self._extract_store_type(item)
            if itype in self._type_index:
                self._type_index[itype].discard(item_id)
                if not self._type_index[itype]:
                    del self._type_index[itype]
            
            # 从来源索引移除
            src = getattr(item, "source", "")
            if src:
                if src in self._source_index:
                    self._source_index[src].discard(item_id)
                    if not self._source_index[src]:
                        del self._source_index[src]
            
            # 使缓存失效
            cache_key = f"{itype}_{item_id}"
            self._cache.invalidate(cache_key)
            
            logger.debug(f"Removed item: {item_id}")
            return True

    def _evict_weakest(self) -> None:
        """淘汰最弱的情感项（基于时间堆和强度）"""
        if not self._time_heap:
            return
        
        # 找到最旧的条目进行淘汰
        _, oldest_id = heapq.heappop(self._time_heap)
        
        # 检查该条目是否仍然存在且非永久
        item = self._items.get(oldest_id)
        if item is None:
            # 条目已被移除，继续弹出
            while self._time_heap:
                _, oldest_id = heapq.heappop(self._time_heap)
                item = self._items.get(oldest_id)
                if item is not None:
                    break
            if item is None:
                return
        
        if getattr(item, "permanent", False):
            # 如果是永久项，跳过，尝试下一个
            logger.debug(f"Skipping eviction of permanent item: {oldest_id}")
            return
        
        self.remove(oldest_id)

    def _extract_item_id(self, item: Any) -> str:
        """从情感项中提取ID
        
        Args:
            item: 情感项
            
        Returns:
            项ID
        """
        return getattr(item, "item_id", getattr(item, "mem_id", getattr(item, "emotion_id", generate_id("item"))))

    def _extract_store_type(self, item: Any) -> str:
        """从情感项中提取存储类型
        
        Args:
            item: 情感项
            
        Returns:
            存储类型字符串
        """
        return getattr(item, "store_type", getattr(item, "category", "unknown"))

    def _get_created_at(self, item: Any) -> float:
        """从情感项中获取创建时间戳
        
        Args:
            item: 情感项
            
        Returns:
            创建时间戳
        """
        return getattr(item, "created_at", 0.0)


# ==================== 情感识别器 ====================

class EmotionRecognizer:
    """基于关键词的情感识别器"""
    
    _EMOTION_KEYWORDS: Dict[str, List[str]] = {
        "joy": ["快乐", "高兴", "开心", "喜悦", "快乐"],
        "sadness": ["悲伤", "难过", "伤心", "哭泣", "痛苦"],
        "anger": ["愤怒", "生气", "恼怒", "暴怒", "气愤"],
        "fear": ["害怕", "恐惧", "惊吓", "担忧", "焦虑"],
        "surprise": ["惊讶", "意外", "震惊", "惊奇", "诧异"],
        "disgust": ["恶心", "反感", "嫌弃", "厌恶", "憎恶"],
        "trust": ["信任", "相信", "信赖", "依赖", "放心"],
        "anticipation": ["期待", "盼望", "渴望", "向往", "憧憬"],
    }
    
    def __init__(self) -> None:
        """初始化情感识别器"""
        self._config = _get_config()
        self._keywords = dict(self._EMOTION_KEYWORDS)
        logger.info("EmotionRecognizer initialized")

    def recognize(self, text: str) -> List[Tuple[str, float]]:
        """识别文本中的情感
        
        Args:
            text: 输入文本
            
        Returns:
            [(情感类别, 置信度)]列表，按置信度降序
        """
        if not text or not text.strip():
            logger.warning("Empty text provided for emotion recognition")
            return []
        
        text_lower = text.lower()
        scores: Dict[str, float] = defaultdict(float)
        
        for emotion, keywords in self._keywords.items():
            match_count = 0
            for keyword in keywords:
                if keyword in text_lower:
                    match_count += 1
                    scores[emotion] += 1.0
            
            if match_count > 0:
                # 归一化：匹配数 / 总关键词数
                scores[emotion] /= len(keywords)
        
        if not scores:
            return [("neutral", 0.0)]
        
        max_score = max(scores.values())
        if max_score > 0:
            normalized_scores = {k: v / max_score for k, v in scores.items()}
        else:
            normalized_scores = scores
        
        result = sorted(normalized_scores.items(), key=lambda x: x[1], reverse=True)
        logger.debug(f"Recognized emotions from text: {result}")
        return result

    def update_keywords(self, emotion: str, keywords: List[str]) -> None:
        """更新情感关键词
        
        Args:
            emotion: 情感类别
            keywords: 关键词列表
        """
        if emotion not in self._keywords:
            self._keywords[emotion] = []
        self._keywords[emotion] = list(keywords)
        logger.info(f"Updated keywords for emotion: {emotion}")


# ==================== 内存情感存储引擎 ====================

class EmotionMemoryStore(EmotionStateStoreBase):
    """基于内存的情感存储引擎实现"""
    
    def __init__(self, max_items: int = 10000, cache_ttl: float = 300.0) -> None:
        """初始化内存情感存储引擎
        
        Args:
            max_items: 最大存储条目数
            cache_ttl: 缓存TTL（秒）
        """
        super().__init__(max_items, cache_ttl)

    def query_by_tag(self, tag: str) -> List[Any]:
        """根据标签查询情感项
        
        Args:
            tag: 标签名称
            
        Returns:
            匹配的情感项列表
        """
        with self._lock:
            tag_key = tag.lower()
            ids = self._tag_index.get(tag_key, set())
            items = []
            for iid in ids:
                item = self._items.get(iid)
                if item:
                    items.append(item)
            return items

    def query_by_type(self, store_type: str) -> List[Any]:
        """根据存储类型查询情感项
        
        Args:
            store_type: 存储类型
            
        Returns:
            匹配的情感项列表
        """
        with self._lock:
            ids = self._type_index.get(store_type, set())
            items = []
            for iid in ids:
                item = self._items.get(iid)
                if item:
                    items.append(item)
            return items

    def query_by_source(self, source: str) -> List[Any]:
        """根据来源查询情感项
        
        Args:
            source: 来源名称
            
        Returns:
            匹配的情感项列表
        """
        with self._lock:
            ids = self._source_index.get(source, set())
            items = []
            for iid in ids:
                item = self._items.get(iid)
                if item:
                    items.append(item)
            return items

    def get_all(self) -> List[Any]:
        """获取所有情感项
        
        Returns:
            所有情感项列表
        """
        with self._lock:
            return list(self._items.values())

    def get_stats(self) -> Dict[str, Any]:
        """获取存储统计信息
        
        Returns:
            包含各项统计的字典
        """
        with self._lock:
            return {
                "total_items": len(self._items),
                "cache_hit_rate": self._cache.hit_rate,
                "max_items": self._max,
                "tag_count": len(self._tag_index),
                "type_count": len(self._type_index),
                "source_count": len(self._source_index),
            }
