"""共情模块重导出中心 (Emotion Module Re-export Hub).

该文件作为共情模块的入口点，将原先的大型单文件模块拆分为多个子模块（part1, part2），
并在此处重新导出它们提供的公共 API。这种方式允许其他模块继续从统一路径导入，
同时保持了代码的可维护性和模块化设计。

版本: 0.5
"""
import importlib
import logging
from typing import List, Optional, Any

# 设置模块日志记录器
logger = logging.getLogger(__name__)

# 定义需要导入的子模块列表
_SUBMODULES: List[str] = ["_empathy_module_parts.part1", "_empathy_module_parts.part2"]


def _import_and_reexport(submodule_names: List[str], package: Optional[str]) -> None:
    """
    从指定的子模块中导入并重导出所有公共属性。

    此函数遍历给定的子模块名称列表，尝试从包中导入每个子模块。
    如果导入成功，它将遍历子模块的所有公开属性（不以 '_' 开头的名称），
    并将它们绑定到当前模块的全局命名空间中。如果导入过程中发生异常，
    记录警告日志但不中断整体导入流程。

    参数:
        submodule_names (List[str]): 需要导入的子模块名称列表。
        package (Optional[str]): 导入使用的包名，默认为当前模块的包名。
    """
    pkg = package if package else __package__
    for name in submodule_names:
        try:
            module = importlib.import_module(f".{name}", package=pkg)
            # 获取模块的所有公共属性并重导出
            public_attrs = [attr for attr in dir(module) if not attr.startswith("_")]
            for attr in public_attrs:
                globals()[attr] = getattr(module, attr)
            logger.debug(f"Successfully re-exported {len(public_attrs)} items from {name}")
        except ModuleNotFoundError as e:
            logger.warning(f"Submodule '{name}' not found in package '{pkg}': {e}")
        except Exception as e:
            logger.error(f"Failed to import or re-export from '{name}': {e}", exc_info=True)


def initialize() -> None:
    """
    初始化共情模块的重导出功能。

    该函数在模块加载时自动调用，负责从所有定义的子模块中
    重新导出公共 API。如果子模块不存在或导入失败，将记录日志
    但不会导致整个模块崩溃。
    """
    _import_and_reexport(_SUBMODULES, __package__)
    logger.info("Empathy module re-export hub initialized")


# 模块初始化
initialize()
