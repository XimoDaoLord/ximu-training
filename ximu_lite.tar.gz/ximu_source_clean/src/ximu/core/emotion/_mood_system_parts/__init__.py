"""Split parts of mood_system. (Version 0.5)"""

import logging
from typing import Dict, Optional, Final
from dotenv import load_dotenv
from pydantic import BaseModel, Field

# 环境变量配置
load_dotenv()  # 硬编码已移除，使用python-dotenv自动加载

# 日志配置
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger: Final = logging.getLogger(__name__)

class Config(BaseModel):
    """系统配置参数"""
    EmotionModelPath: str = Field(..., env="EMOTIONS_MODEL_PATH")
    LogLevel: str = Field("INFO", env="LOG_LEVEL")

class MoodState:
    """情绪状态基类"""
    def __init__(self, state: str):
        self._state = state
        logger.info(f"初始化情绪状态: {self._state}")

    @property
    def current_state(self) -> str:
        """获取当前情绪状态"""
        return self._state

    def transition(self, new_state: str) -> Optional["MoodState"]:
        """状态转换逻辑"""
        logger.info(f"尝试转换状态: {self._state} → {new_state}")
        if new_state in self.get_valid_transitions():
            return self._handle_transition(new_state)
        logger.warning(f"无效状态转换: {self._state} → {new_state}")
        return None

    def get_valid_transitions(self) -> set[str]:
        """获取有效状态转换列表"""
        return {"happy", "sad", "angry"}

    def _handle_transition(self, new_state: str) -> "MoodState":
        """私有状态转换处理"""
        raise NotImplementedError("子类需实现具体转换逻辑")

class EmotionManager:
    """情绪系统管理器"""
    def __init__(self, config: Config):
        self._current_state: Optional[MoodState] = None
        self._config = config
        logger.info(f"配置加载完成: {config}")

    def initialize(self, initial_state: str) -> None:
        """初始化情绪系统"""
        try:
            self._current_state = MoodState(initial_state)
            logger.info("系统初始化成功")
        except Exception as e:
            logger.error(f"初始化失败: {str(e)}")
            raise

    def get_state(self) -> Optional[MoodState]:
        """获取当前情绪状态"""
        return self._current_state

    def process_input(self, input_data: Dict) -> Dict:
        """处理输入并触发状态转换"""
        try:
            if self._current_state:
                new_state = self._current_state.transition(input_data["target_state"])
                if new_state:
                    logger.info(f"状态更新: {self._current_state.current_state} → {new_state.current_state}")
                    self._current_state = new_state
            return {"status": "success"}
        except Exception as e:
            logger.error(f"处理输入失败: {str(e)}")
            return {"status": "error", "message": str(e)}

# 公共API保持不变
def get_manager(config: Config) -> EmotionManager:
    """获取情绪系统管理器实例"""
    return EmotionManager(config)
