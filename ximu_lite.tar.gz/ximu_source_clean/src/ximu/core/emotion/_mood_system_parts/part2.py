import logging
from typing import Any, Callable, Dict, List, Optional
from collections import defaultdict, deque
from threading import RLock
from datetime import datetime
import json
import os
import random
import time

logger = logging.getLogger("src.ximu.core.emotion._mood_system_parts.part2")


class Registry:
    """
    注册表类，负责管理数据存储、事件处理、指标记录和系统状态。
    提供线程安全的接口来操作内部状态。
    """

    def __init__(self, **kwargs):
        """
        初始化注册表实例。

        Args:
            **kwargs: 配置参数。
        """
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = RLock()
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=500)
        self._initialized = False
        self._last_maintenance = 0.0
        self._maintenance_interval = 300.0

    def register_store(self, name: str, store_obj: Any) -> None:
        """
        注册一个新的数据存储对象。

        Args:
            name: 存储对象的名称。
            store_obj: 存储对象实例。
        """
        with self._lock:
            self._stores[name] = store_obj
            logger.info("Store registered: %s", name)
            self._emit("store_registered", {"name": name})

    def get_store(self, name: str) -> Optional[Any]:
        """
        获取已注册的存储对象。

        Args:
            name: 存储对象的名称。

        Returns:
            存储对象实例，如果不存在则返回 None。
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """
        移除已注册的存储对象。

        Args:
            name: 存储对象的名称。

        Returns:
            如果成功移除返回 True，否则返回 False。
        """
        with self._lock:
            s = self._stores.pop(name, None)
            if s:
                logger.info("Store removed: %s", name)
                self._emit("store_removed", {"name": name})
            return s is not None

    def on(self, event: str, handler: Callable) -> None:
        """
        注册事件处理器。

        Args:
            event: 事件名称。
            handler: 处理函数。
        """
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable) -> None:
        """
        注销事件处理器。

        Args:
            event: 事件名称。
            handler: 处理函数。
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Any = None) -> None:
        """
        触发事件并通知所有注册的处理器。

        Args:
            event: 事件名称。
            data: 事件数据。
        """
        handlers = self._event_handlers.get(event, [])
        for h in handlers:
            try:
                h(data or {})
            except Exception as e:
                logger.error("Event handler failed for event '%s': %s", event, e, exc_info=True)

    def record_metric(self, name: str, value: float) -> None:
        """
        记录指标值。

        Args:
            name: 指标名称。
            value: 指标值。
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({"metric": name, "value": value, "timestamp": datetime.now()})

    def get_metric(self, name: str) -> float:
        """
        获取指定指标的当前值。

        Args:
            name: 指标名称。

        Returns:
            指标值，如果不存在则返回 0.0。
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """
        获取所有指标的当前值。

        Returns:
            包含所有指标名称和值的字典。
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        """重置所有指标记录。"""
        with self._lock:
            self._metrics.clear()

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取指标历史记录。

        Args:
            limit: 返回的最大记录数。

        Returns:
            历史记录列表。
        """
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """
        初始化系统。

        Returns:
            如果初始化成功返回 True，如果已初始化则返回 False。
        """
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            logger.info("System initialized")
            self._emit("initialized", {})
            return True

    def shutdown(self) -> bool:
        """
        关闭系统。

        Returns:
            如果关闭成功返回 True，如果未初始化则返回 False。
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            logger.info("System shutdown")
            self._emit("shutdown", {})
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """
        执行系统维护，清理过期数据。

        Args:
            force: 是否强制执行维护。

        Returns:
            包含维护状态的字典。
        """
        with self._lock:
            now = time.time()
            if not force and now - self._last_maintenance < self._maintenance_interval:
                return {"status": "skipped"}

            cleaned = 0
            for name, s in self._stores.items():
                if hasattr(s, "cleanup_expired"):
                    try:
                        cleaned += s.cleanup_expired()
                    except Exception as e:
                        logger.error("Cleanup failed for store '%s': %s", name, e, exc_info=True)

            self._last_maintenance = now
            self._emit("maintenance", {"cleaned": cleaned})
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        """
        获取系统统计信息。

        Returns:
            包含初始化状态、存储统计、指标和历史的字典。
        """
        with self._lock:
            store_stats = {}
            for name, s in self._stores.items():
                if hasattr(s, "get_stats"):
                    try:
                        store_stats[name] = s.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(s, "size"):
                    store_stats[name] = {"size": s.size()}

            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history)
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        将当前状态转换为字典。

        Returns:
            状态字典。
        """
        with self._lock:
            return {
                "config": dict(self._config),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys())
            }

    def export_state(self, filepath: str) -> None:
        """
        导出当前状态到文件。

        Args:
            filepath: 目标文件路径。
        """
        with self._lock:
            state_data = self.to_dict()
            try:
                with open(filepath, "w", encoding="utf-8") as f:
                    json.dump(state_data, f, ensure_ascii=False, default=str)
                logger.info("State exported to %s", filepath)
            except IOError as e:
                logger.error("Failed to export state to %s: %s", filepath, e)

    def import_state(self, filepath: str) -> bool:
        """
        从文件导入状态。

        Args:
            filepath: 源文件路径。

        Returns:
            如果导入成功返回 True，否则返回 False。
        """
        if not os.path.exists(filepath):
            logger.warning("Import file not found: %s", filepath)
            return False

        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (IOError, json.JSONDecodeError) as e:
            logger.error("Failed to read import file %s: %s", filepath, e)
            return False

        with self._lock:
            if "config" in data:
                self._config.update(data["config"])
            if "metrics" in data:
                self._metrics.update(data["metrics"])
            logger.info("State imported from %s", filepath)
            return True


class MoodMemoryManager(Registry):
    """
    情绪记忆管理器，继承自 Registry，负责管理情绪状态、转换逻辑和预测。
    """

    def __init__(self, **kwargs):
        """
        初始化情绪记忆管理器。

        Args:
            **kwargs: 传递给父类 Registry 的参数。
        """
        super().__init__(**kwargs)
        self._state_start_time = time.monotonic()

    def check_state_expiry(self) -> Optional[Any]:
        """
        检查当前状态是否过期。

        Returns:
            如果状态过期，返回转换结果；否则返回 None。
        """
        state = self.states.get(self.current_state)
        if not state:
            return None
        duration = time.monotonic() - self._state_start_time
        if duration > state.duration_range[1]:
            logger.info("State %s expired, triggering transition", self.current_state)
            return self.transition("time_pass")
        return None

    def get_mood_summary(self) -> Dict[str, Any]:
        """
        获取当前情绪的摘要信息。

        Returns:
            包含当前状态、最近转换、状态分布和主导状态的字典。
        """
        current = self.get_current_state()
        recent_transitions = self.transition_log[-20:]
        state_counts = {}
        for entry in self.transition_log[-100:]:
            state_counts[entry["to"]] = state_counts.get(entry["to"], 0) + 1
        dominant = max(state_counts.items(), key=lambda x: x[1]) if state_counts else (self.current_state, 1)
        return {
            "current_state": current,
            "recent_transitions": recent_transitions,
            "state_distribution": state_counts,
            "dominant_recent_state": dominant[0],
            "total_transitions": len(self.transition_log)
        }

    def get_available_transitions(self) -> List[Dict[str, Any]]:
        """
        获取当前状态可用的转换列表。

        Returns:
            转换选项列表。
        """
        return [
            {"to": t.to_state, "trigger": t.trigger, "probability": t.probability}
            for t in self.transitions if t.from_state == self.current_state
        ]

    def predict_next_state(self, steps: int = 5) -> List[str]:
        """
        预测未来若干步的情绪状态。

        Args:
            steps: 预测步数。

        Returns:
            预测的状态列表。
        """
        predictions = []
        current = self.current_state
        for _ in range(steps):
            possible = [t for t in self.transitions if t.from_state == current]
            if not possible:
                break
            total_prob = sum(t.probability for t in possible)
            r = random.random() * total_prob
            cumulative = 0
            next_state = current
            for t in possible:
                cumulative += t.probability
                if r <= cumulative:
                    next_state = t.to_state
                    break
            predictions.append(next_state)
            current = next_state
        return predictions
