"""
汐沫AI - P5情绪系统 Mood System
接口扩展与其他层核心模块
"""

import json
import logging
import os
import random
import re
import threading
import time
import uuid
from collections import OrderedDict, defaultdict, deque, Counter
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone
from enum import Enum
from heapq import heappush, heappop
from typing import (
    Any, Callable, Dict, List, Optional, Set, Tuple, TypeVar, Union
)

try:
    from src.ximu.common.utils import score_stored_item
except ImportError:
    score_stored_item = None

logger = logging.getLogger("src.ximu.core.emotion._mood_system_parts.part1")

T = TypeVar("T")
U = TypeVar("U")


# =============================
# 工具函数
# =============================

def generate_id(prefix: str = "id") -> str:
    """生成带前缀的唯一标识符。

    Args:
        prefix: 标识符前缀。

    Returns:
        格式为 ``{prefix}_{16位十六进制}」的字符串。
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


def now_timestamp() -> float:
    """获取当前 Unix 时间戳。

    Returns:
        浮点时间戳。
    """
    return time.time()


def now_datetime() -> datetime:
    """获取当前带时区的 datetime 对象（UTC+8）。

    Returns:
        时区为 UTC+8 的 datetime。
    """
    return datetime.now(timezone(timedelta(hours=8)))


def format_datetime(dt: Optional[datetime] = None, fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    """格式化 datetime 对象。

    Args:
        dt: 待格式化时间，None 时使用当前时间。
        fmt: 格式化字符串。

    Returns:
        格式化后的字符串。
    """
    if dt is None:
        dt = now_datetime()
    return dt.strftime(fmt)


# =============================
# Stopwatch
# =============================

class Stopwatch:
    """高精度耗时测量工具。"""

    def __init__(self) -> None:
        """初始化计时器，未启动状态。"""
        self._start: float = 0.0
        self._end: float = 0.0

    def start(self) -> "Stopwatch":
        """开始计时。

        Returns:
            self，支持链式调用。
        """
        self._start = time.time()
        return self

    def stop(self) -> "Stopwatch":
        """停止计时。

        Returns:
            self，支持链式调用。
        """
        self._end = time.time()
        return self

    @property
    def elapsed_ms(self) -> float:
        """已流逝毫秒数。

        Returns:
            从开始到停止的毫秒数，若未开始则为 0。
        """
        if self._start == 0.0:
            return 0.0
        return (self._end - self._start) * 1000


# =============================
# 枚举定义
# =============================

class EmotionCategory(str, Enum):
    """情绪类别枚举。"""
    JOY = "joy"
    SADNESS = "sadness"
    ANGER = "anger"
    FEAR = "fear"
    SURPRISE = "surprise"
    DISGUST = "disgust"
    TRUST = "trust"
    ANTICIPATION = "anticipation"
    NEUTRAL = "neutral"
    LOVE = "love"
    HATE = "hate"
    HOPE = "hope"
    DESPAIR = "despair"
    CALM = "calm"
    ANXIETY = "anxiety"


class AffectDimension(str, Enum):
    """情感维度枚举（PAD 模型）。"""
    VALENCE = "valence"
    AROUSAL = "arousal"
    DOMINANCE = "dominance"


class EmotionIntensity(str, Enum):
    """情绪强度等级枚举。"""
    FAINT = "faint"
    WEAK = "weak"
    MODERATE = "moderate"
    STRONG = "strong"
    INTENSE = "intense"
    OVERWHELMING = "overwhelming"


class MoodState(str, Enum):
    """情绪状态枚举。"""
    EUPHORIC = "euphoric"
    HAPPY = "happy"
    CONTENT = "content"
    NEUTRAL = "neutral"
    LOW = "low"
    SAD = "sad"
    DEPRESSED = "depressed"
    ANXIOUS = "anxious"
    IRRITABLE = "irritable"
    CALM = "calm"
    EXCITED = "excited"
    FATIGUED = "fatigued"


class MoodRegulationMethod(str, Enum):
    """情绪调节方法枚举。"""
    COGNITIVE = "cognitive"
    BEHAVIORAL = "behavioral"
    SOCIAL = "social"
    PHYSICAL = "physical"
    EXPRESSIVE = "expressive"
    MEDITATIVE = "meditative"


class EmotionalContagionDirection(str, Enum):
    """情绪传染方向枚举。"""
    INBOUND = "inbound"
    OUTBOUND = "outbound"
    MUTUAL = "mutual"


# =============================
# 数据类
# =============================

@dataclass
class EmotionItem:
    """情绪条目，记录一条情绪相关的结构化数据。"""

    item_id: str = field(default_factory=generate_id)
    content: str = ""
    store_type: str = "general"
    category: str = ""
    source: str = ""
    tags: List[str] = field(default_factory=list)
    created_at: float = now_timestamp()
    updated_at: float = now_timestamp()
    last_accessed: float = now_timestamp()
    access_count: int = 0
    importance: float = 0.5
    weight: float = 1.0
    valence: float = 0.0
    arousal: float = 0.0
    dominance: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    permanent: bool = False

    def __post_init__(self) -> None:
        """初始化时间戳，若未指定则使用当前时间。"""
        if self.created_at == 0.0:
            self.created_at = now_timestamp()
        if self.updated_at == 0.0:
            self.updated_at = now_timestamp()
        if self.last_accessed == 0.0:
            self.last_accessed = now_timestamp()

    def access(self) -> None:
        """标记条目被访问一次，更新时间和计数。"""
        self.last_accessed = now_timestamp()
        self.access_count += 1

    def is_expired(self) -> bool:
        """判断条目是否过期。

        Returns:
            始终返回 False，子类可覆写。
        """
        return False

    def get_strength(self) -> float:
        """计算条目强度，基于访问频率、重要性和权重。

        Returns:
            0~1 之间的浮点数。
        """
        access_factor = min(1.0, self.access_count / 20.0)
        return (0.3 + 0.3 * access_factor + 0.4 * self.importance) * self.weight

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典。

        Returns:
            包含所有字段的字典。
        """
        return asdict(self)


@dataclass
class MoodRecord:
    """情绪记录，描述一次情绪事件的快照。"""

    mood_id: str = field(default_factory=generate_id)
    state: str = "neutral"
    valence: float = 0.0
    arousal: float = 0.0
    intensity: float = 0.3
    trigger: str = ""
    created_at: float = now_timestamp()
    duration: float = 0.0
    regulated: bool = False
    regulation_method: str = ""
    infection_source: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def regulate(self, method: str) -> None:
        """标记情绪已被调节。

        Args:
            method: 调节方法字符串。
        """
        self.regulated = True
        self.regulation_method = method
        self.intensity *= 0.6

    def decay(self, rate: float = 0.02) -> None:
        """情绪衰减。

        Args:
            rate: 衰减率，0~1 之间。
        """
        self.intensity = max(0.0, self.intensity * (1.0 - rate))

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典。

        Returns:
            包含所有字段的字典。
        """
        return asdict(self)


@dataclass
class MoodMemory:
    """情绪记忆条目，记录与情绪相关的记忆片段。"""

    mem_id: str = field(default_factory=generate_id)
    mood_state: str = "neutral"
    context: str = ""
    intensity: float = 0.0
    created_at: float = now_timestamp()
    recall_count: int = 0
    associated_events: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def recall(self) -> None:
        """标记记忆被回忆一次，增加回忆计数。"""
        self.recall_count += 1
        self.last_accessed = now_timestamp()

    def is_expired(self) -> bool:
        """判断记忆是否过期。

        Returns:
            超过24小时未访问则返回 True。
        """
        return time.time() - self.last_accessed > 86400

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典。

        Returns:
            包含所有字段的字典。
        """
        return asdict(self)


# =============================
# 通用条目存储（消除重复代码的核心抽象）
# =============================

class BaseMoodStore:
    """
    通用条目存储基类。

    提供线程安全的增删改查、多索引检索、LRU 查询缓存、
    正则/模糊搜索、批量操作、JSON 导出/导入等完整功能。
    子类只需指定默认容量即可复用全部逻辑。
    """

    _DEFAULT_MAX_ITEMS: int = 20000
    _LRU_CACHE_MAX: int = 500

    def __init__(self, max_items: int = _DEFAULT_MAX_ITEMS) -> None:
        """初始化存储结构。

        Args:
            max_items: 最大条目数，超出时触发淘汰策略。
        """
        self._items: Dict[str, Any] = {}
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._type_index: Dict[str, Set[str]] = defaultdict(set)
        self._source_index: Dict[str, Set[str]] = defaultdict(set)
        self._time_heap: List[Tuple[float, str]] = []
        self._max: int = max_items
        self._lock = threading.RLock()
        self._added = 0
        self._reads = 0
        self._deleted = 0
        self._updated = 0
        self._searches = 0
        self._cache_hits = 0
        self._cache_misses = 0
        self._query_cache: OrderedDict[str, List[Tuple[Any, float]]] = OrderedDict()
        self._lru_queue: deque = deque(maxlen=self._LRU_CACHE_MAX)

    # ---------- 内部工具 ----------

    @staticmethod
    def _extract_item_id(item: Any) -> str:
        """从条目对象中提取 ID，依次尝试 item_id, entry_id, id 属性。

        Args:
            item: 条目对象。

        Returns:
            提取到的 ID 字符串，若均不存在则生成新 ID。
        """
        item_id = getattr(item, "item_id", None)
        if item_id:
            return str(item_id)
        entry_id = getattr(item, "entry_id", None)
        if entry_id:
            return str(entry_id)
        generic_id = getattr(item, "id", None)
        if generic_id:
            return str(generic_id)
        return generate_id("item")

    @staticmethod
    def _extract_tags(item: Any) -> List[str]:
        """从条目对象中提取标签列表。

        Args:
            item: 条目对象。

        Returns:
            标签列表，无标签时返回空列表。
        """
        tags = getattr(item, "tags", [])
        if tags is None:
            return []
        return list(tags)

    @staticmethod
    def _extract_type(item: Any) -> str:
        """从条目对象中提取类型/分类。

        Args:
            item: 条目对象。

        Returns:
            类型字符串，无值时返回 "general"。
        """
        store_type = getattr(item, "store_type", None)
        if store_type:
            return str(store_type)
        category = getattr(item, "category", None)
        if category:
            return str(category)
        type_val = getattr(item, "type", None)
        if type_val:
            return str(type_val)
        return "general"

    @staticmethod
    def _extract_source(item: Any) -> str:
        """从条目对象中提取来源。

        Args:
            item: 条目对象。

        Returns:
            来源字符串，无值时返回空字符串。
        """
        source = getattr(item, "source", "")
        return str(source) if source else ""

    @staticmethod
    def _extract_created_at(item: Any) -> float:
        """从条目对象中提取创建时间。

        Args:
            item: 条目对象。

        Returns:
            时间戳，无值时使用当前时间。
        """
        created_at = getattr(item, "created_at", None)
        if created_at is not None:
            return float(created_at)
        return now_timestamp()

    @staticmethod
    def _extract_importance(item: Any) -> float:
        """从条目对象中提取重要性/权重。

        Args:
            item: 条目对象。

        Returns:
            重要性浮点数。
        """
        importance = getattr(item, "importance", None)
        if importance is not None:
            return float(importance)
        weight = getattr(item, "weight", None)
        if weight is not None:
            return float(weight)
        return 0.5

    @staticmethod
    def _extract_permanent(item: Any) -> bool:
        """从条目对象中提取是否永久标记。

        Args:
            item: 条目对象。

        Returns:
            是否永久保留。
        """
        return bool(getattr(item, "permanent", False))

    @staticmethod
    def _text_similarity(a: str, b: str) -> float:
        """计算两个字符串基于词集的 Jaccard 相似度。

        Args:
            a: 字符串 A。
            b: 字符串 B。

        Returns:
            0.0~1.0 之间的相似度。
        """
        if not a or not b:
            return 0.0
        sa, sb = set(a.split()), set(b.split())
        if not sa or not sb:
            return 0.0
        intersection = len(sa & sb)
        union = len(sa | sb)
        return intersection / union if union else 0.0

    def _invalidate_cache(self) -> None:
        """清空查询缓存。"""
        self._query_cache.clear()
        self._lru_queue.clear()

    def _evict_weakest(self) -> None:
        """淘汰最弱的非永久条目。"""
        if not self._items:
            return
        evictable = []
        with self._lock:
            for item_id, item in self._items.items():
                if not self._extract_permanent(item):
                    evictable.append((self._extract_importance(item), item_id))
        if evictable:
            evictable.sort()
            self.remove(evictable[0][1])

    # ---------- 索引维护 ----------

    def _index_item(self, item: Any, item_id: str) -> None:
        """将条目加入各索引。

        Args:
            item: 条目对象。
            item_id: 条目 ID。
        """
        for tag in self._extract_tags(item):
            self._tag_index[tag.lower()].add(item_id)

        item_type = self._extract_type(item)
        self._type_index[item_type].add(item_id)

        source = self._extract_source(item)
        if source:
            self._source_index[source].add(item_id)

        created_at = self._extract_created_at(item)
        heappush(self._time_heap, (created_at, item_id))

    def _unindex_item(self, item: Any, item_id: str) -> None:
        """将条目从各索引中移除。

        Args:
            item: 条目对象。
            item_id: 条目 ID。
        """
        for tag in self._extract_tags(item):
            self._tag_index[tag.lower()].discard(item_id)

        item_type = self._extract_type(item)
        self._type_index[item_type].discard(item_id)

        source = self._extract_source(item)
        if source:
            self._source_index[source].discard(item_id)

    # ---------- CRUD ----------

    def add(self, item: Any) -> Any:
        """添加条目到存储。

        Args:
            item: 待添加的条目对象。

        Returns:
            添加的条目对象。
        """
        with self._lock:
            if len(self._items) >= self._max:
                self._evict_weakest()

            item_id = self._extract_item_id(item)
            self._items[item_id] = item
            self._index_item(item, item_id)
            self._added += 1
            self._invalidate_cache()
            return item

    def get(self, item_id: str) -> Optional[Any]:
        """获取条目。

        Args:
            item_id: 条目 ID。

        Returns:
            条目对象或 None。
        """
        with self._lock:
            item = self._items.get(item_id)
            if item is not None:
                if hasattr(item, "access"):
                    item.access()
                self._reads += 1
            return item

    def get_or_default(self, item_id: str, default: Any = None) -> Any:
        """获取条目，不存在时返回默认值。

        Args:
            item_id: 条目 ID。
            default: 默认值。

        Returns:
            条目对象或默认值。
        """
        item = self.get(item_id)
        return item if item is not None else default

    def remove(self, item_id: str) -> bool:
        """移除条目。

        Args:
            item_id: 条目 ID。

        Returns:
            是否成功移除。
        """
        with self._lock:
            item = self._items.pop(item_id, None)
            if item is not None:
                self._unindex_item(item, item_id)
                self._deleted += 1
                self._invalidate_cache()
                return True
            return False

    def update(self, item_id: str, **kwargs: Any) -> bool:
        """更新条目属性。

        Args:
            item_id: 条目 ID。
            **kwargs: 要更新的字段。

        Returns:
            是否成功更新。
        """
        with self._lock:
            item = self._items.get(item_id)
            if item is None:
                return False
            for key, value in kwargs.items():
                if hasattr(item, key):
                    setattr(item, key, value)
            if hasattr(item, "updated_at"):
                item.updated_at = now_timestamp()
            self._updated += 1
            self._invalidate_cache()
            return True

    def contains(self, item_id: str) -> bool:
        """判断条目是否存在。

        Args:
            item_id: 条目 ID。

        Returns:
            是否存在。
        """
        with self._lock:
            return item_id in self._items

    # ---------- 搜索 ----------

    def search(
        self,
        query: str,
        limit: int = 20,
        category: str = "",
        tags: Optional[List[str]] = None,
        min_score: float = 0.0,
    ) -> List[Tuple[Any, float]]:
        """基于关键词搜索条目（带 LRU 缓存）。

        Args:
            query: 搜索关键词。
            limit: 最大返回数量。
            category: 类别过滤。
            tags: 标签过滤列表。
            min_score: 最低分数阈值。

        Returns:
            (条目, 分数) 元组列表，按分数降序。
        """
        with self._lock:
            cache_key = f"{query}:{category}:{tuple(tags or [])}:{min_score}:{limit}"
            if cache_key in self._query_cache and len(self._query_cache) <= self._LRU_CACHE_MAX:
                self._cache_hits += 1
                self._lru_queue.appendleft(cache_key)
                return self._query_cache[cache_key]

            self._cache_misses += 1
            self._searches += 1
            self._lru_queue.appendleft(cache_key)
            if len(self._lru_queue) > self._LRU_CACHE_MAX:
                removed_key = self._lru_queue.pop()
                if removed_key in self._query_cache:
                    del self._query_cache[removed_key]

            q = query.lower().strip()
            candidate_ids = set(self._items.keys())

            if category:
                candidate_ids &= self._type_index.get(category, set())

            if tags:
                tag_ids: Set[str] = set()
                for tag in tags:
                    tag_ids.update(self._tag_index.get(tag.lower(), set()))
                candidate_ids &= tag_ids

            scored: List[Tuple[float, Any]] = []
            q_words = q.split()

            if score_stored_item is not None:
                for item_id in candidate_ids:
                    item = self._items[item_id]
                    score = score_stored_item(item, q, q_words)
                    if score > min_score:
                        scored.append((score, item))
            else:
                for item_id in candidate_ids:
                    item = self._items[item_id]
                    content = (getattr(item, "content", "") or "").lower()
                    score = sum(1 for word in q_words if word in content) / max(1, len(q_words))
                    if score > min_score:
                        scored.append((score, item))

            scored.sort(key=lambda x: x[0], reverse=True)
            result = [(item, score) for score, item in scored[:limit]]

            self._query_cache[cache_key] = result
            return result

    def fuzzy_search(
        self,
        query: str,
        threshold: float = 0.6,
        limit: int = 20,
    ) -> List[Tuple[Any, float]]:
        """模糊搜索条目（基于 Jaccard 相似度）。

        Args:
            query: 搜索关键词。
            threshold: 相似度阈值。
            limit: 最大返回数量。

        Returns:
            (条目, 分数) 元组列表，按分数降序。
        """
        with self._lock:
            q = query.lower()
            scored: List[Tuple[float, Any]] = []
            for item_id, item in self._items.items():
                content = (getattr(item, "content", "") or "").lower()
                score = self._text_similarity(q, content)
                if score >= threshold:
                    scored.append((score, item))
            scored.sort(key=lambda x: x[0], reverse=True)
            return [(item, score) for score, item in scored[:limit]]

    def regex_search(self, pattern: str, limit: int = 20) -> List[Any]:
        """正则表达式搜索条目。

        Args:
            pattern: 正则表达式模式。
            limit: 最大返回数量。

        Returns:
            匹配的条目列表。
        """
        with self._lock:
            try:
                compiled = re.compile(pattern, re.IGNORECASE)
            except re.error:
                return []
            result: List[Any] = []
            for item_id, item in self._items.items():
                content = getattr(item, "content", "") or ""
                if compiled.search(content):
                    result.append(item)
                    if len(result) >= limit:
                        break
            return result


# =============================
# 按索引查询
# =============================

    def get_by_type(self, category: str, limit: int = 100) -> List[Any]:
        """按类型获取条目。

        Args:
            cate
        """
        with self._lock:
            return list(self._type_index.get(category, set())[:limit])
