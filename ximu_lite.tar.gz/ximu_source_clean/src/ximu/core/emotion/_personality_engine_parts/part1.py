"""
Personality Engine Part 1

汐沫AI - P5人格引擎 Personality Engine

Part 1 of personality_engine (lines 2-2750 of 3616).
"""

import logging
import os
import json
import time
import uuid
import heapq
import threading
import random
import re
from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, TypeVar, Union, Generic
from collections import OrderedDict, defaultdict, deque, Counter
from datetime import datetime, timedelta, timezone

logger = logging.getLogger("src.ximu.core.emotion._personality_engine_parts.part1")

try:
    from config.settings import config
except ImportError:
    config = None

T = TypeVar("T")

# ==================== 工具函数 ====================
def generate_id(prefix: str = "id") -> str:
    """
    生成唯一标识符，带前缀和UUID部分。

    Args:
        prefix: ID前缀字符串

    Returns:
        生成的唯一ID字符串
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"

def now_timestamp() -> float:
    """
    获取当前Unix时间戳。

    Returns:
        当前时间戳浮点数
    """
    return time.time()

def now_datetime() -> datetime:
    """
    获取当前东八区时间。

    Returns:
        当前时间的datetime对象（东八区时区）
    """
    return datetime.now(timezone(timedelta(hours=8)))

def format_datetime(dt: Optional[datetime] = None, fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    格式化日期时间为字符串。

    Args:
        dt: 要格式化的datetime对象，默认为当前时间
        fmt: 格式化字符串

    Returns:
        格式化后的时间字符串
    """
    if dt is None:
        dt = now_datetime()
    return dt.strftime(fmt)

class Stopwatch:
    """
    简单的计时器，用于测量代码段执行时间。
    """

    def __init__(self) -> None:
        """
        初始化计时器。
        """
        self._start: float = 0.0
        self._end: float = 0.0

    def start(self) -> "Stopwatch":
        """
        开始计时。

        Returns:
            自身，支持链式调用
        """
        self._start = time.time()
        return self

    def stop(self) -> "Stopwatch":
        """
        停止计时。

        Returns:
            自身，支持链式调用
        """
        self._end = time.time()
        return self

    @property
    def elapsed_ms(self) -> float:
        """
        获取经过的时间（毫秒）。

        Returns:
            经过的毫秒数
        """
        if self._start == 0.0 or self._end == 0.0:
            return 0.0
        return (self._end - self._start) * 1000

# ==================== 枚举类 ====================
class EmotionCategory(str, Enum):
    """
    情绪类别枚举。
    """
    JOY = "joy"
    SADNESS = "sadness"
    ANGER = "anger"
    FEAR = "fear"
    SURPRISE = "surprise"
    DISGUST = "disgust"
    TRUST = "trust"
    ANTICIPATION = "anticipation"
    NEUTRAL = "neutral"
    LOVE = "love"
    HATE = "hate"
    HOPE = "hope"
    DESPAIR = "despair"
    CALM = "calm"
    ANXIETY = "anxiety"

class AffectDimension(str, Enum):
    """
    情感维度枚举（效价、唤醒度、支配性）。
    """
    VALENCE = "valence"
    AROUSAL = "arousal"
    DOMINANCE = "dominance"

class EmotionIntensity(str, Enum):
    """
    情绪强度等级枚举。
    """
    FAINT = "faint"
    WEAK = "weak"
    MODERATE = "moderate"
    STRONG = "strong"
    INTENSE = "intense"
    OVERWHELMING = "overwhelming"

class PersonalityModel(str, Enum):
    """
    人格模型类型枚举。
    """
    BIG_FIVE = "big_five"
    MBTI = "mbti"
    HEXACO = "hexaco"
    DARK_TRIAD = "dark_triad"
    ATTACHMENT = "attachment"
    TEMPERAMENT = "temperament"

class MBTIDimension(str, Enum):
    """
    MBTI维度枚举。
    """
    EXTRAVERSION_INTROVERSION = "extraversion_introversion"
    SENSING_INTUITION = "sensing_intuition"
    THINKING_FEELING = "thinking_feeling"
    JUDGING_PERCEIVING = "judging_perceiving"

class PersonalityStage(str, Enum):
    """
    人格发展阶段枚举。
    """
    FORMING = "forming"
    DEVELOPING = "developing"
    STABLE = "stable"
    EVOLVING = "evolving"
    INTEGRATED = "integrated"

# ==================== 数据类 ====================
@dataclass
class EmotionItem:
    """
    情绪条目数据类，存储情绪相关的记忆片段。
    """
    item_id: str = ""
    content: str = ""
    store_type: str = "general"
    category: str = ""
    source: str = ""
    tags: List[str] = field(default_factory=list)
    created_at: float = 0.0
    updated_at: float = 0.0
    last_accessed: float = 0.0
    access_count: int = 0
    importance: float = 0.5
    weight: float = 1.0
    valence: float = 0.0
    arousal: float = 0.0
    dominance: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    permanent: bool = False

    def __post_init__(self) -> None:
        """
        初始化后处理，设置默认时间戳。
        """
        now = now_timestamp()
        if self.created_at == 0.0:
            self.created_at = now
        if self.updated_at == 0.0:
            self.updated_at = now
        if self.last_accessed == 0.0:
            self.last_accessed = now

    def access(self) -> None:
        """
        标记访问，更新最后访问时间并增加计数。
        """
        self.last_accessed = now_timestamp()
        self.access_count += 1

    def is_expired(self) -> bool:
        """
        检查条目是否过期。

        Returns:
            目前总是返回False，预留扩展接口
        """
        return False

    def get_strength(self) -> float:
        """
        计算条目的强度权重。

        Returns:
            基于访问频率、重要性和权重计算的综合强度值
        """
        access_factor = min(1.0, self.access_count / 20.0)
        return (0.3 + 0.3 * access_factor + 0.4 * self.importance) * self.weight

    def to_dict(self) -> Dict[str, Any]:
        """
        将数据类转换为字典。

        Returns:
            包含所有字段的字典
        """
        return asdict(self)

@dataclass
class PersonalityProfile:
    """
    人格画像数据类，存储人格特质信息。
    """
    profile_id: str = ""
    name: str = ""
    model: str = "big_five"
    traits: Dict[str, float] = field(default_factory=dict)
    mbti_type: str = ""
    created_at: float = 0.0
    updated_at: float = 0.0
    stage: str = "developing"
    consistency_score: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """
        初始化后处理，设置默认时间戳。
        """
        now = now_timestamp()
        if self.created_at == 0.0:
            self.created_at = now
        if self.updated_at == 0.0:
            self.updated_at = now

    def update_trait(self, trait: str, value: float) -> None:
        """
        更新特质的值。

        Args:
            trait: 特质名称
            value: 特质值，会被限制在[0.0, 1.0]范围内
        """
        self.traits[trait] = max(0.0, min(1.0, value))
        self.updated_at = now_timestamp()

    def get_trait(self, trait: str) -> float:
        """
        获取特质值。

        Args:
            trait: 特质名称

        Returns:
            特质值，不存在时返回默认值0.5
        """
        return self.traits.get(trait, 0.5)

    def to_dict(self) -> Dict[str, Any]:
        """
        将数据类转换为字典。

        Returns:
            包含所有字段的字典
        """
        return asdict(self)

@dataclass
class BehaviorRecord:
    """
    行为记录数据类，记录情境下的行为及其与预期特质的对比。
    """
    record_id: str = ""
    profile_id: str = ""
    situation: str = ""
    behavior: str = ""
    expected_traits: Dict[str, float] = field(default_factory=dict)
    actual_traits: Dict[str, float] = field(default_factory=dict)
    consistency: float = 0.0
    created_at: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """
        初始化后处理，设置默认创建时间。
        """
        if self.created_at == 0.0:
            self.created_at = now_timestamp()

    def to_dict(self) -> Dict[str, Any]:
        """
        将数据类转换为字典。

        Returns:
            包含所有字段的字典
        """
        return asdict(self)

# ==================== 基础存储类 ====================
class _BaseStore(Generic[T]):
    """
    通用条目存储基类，提供CRUD、搜索、索引、缓存等功能。
    通过泛型参数指定条目类型，消除重复代码。
    """

    def __init__(self, max_items: int = 5000, store_name: str = "store") -> None:
        """
        初始化存储类。

        Args:
            max_items: 最大存储条目数
            store_name: 存储名称，用于日志
        """
        self._items: Dict[str, T] = {}
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._type_index: Dict[str, Set[str]] = defaultdict(set)
        self._source_index: Dict[str, Set[str]] = defaultdict(set)
        self._time_heap: List[Tuple[float, str]] = []
        self._max: int = max_items
        self._lock: threading.RLock = threading.RLock()
        self._added: int = 0
        self._reads: int = 0
        self._deleted: int = 0
        self._updated: int = 0
        self._searches: int = 0
        self._cache_hits: int = 0
        self._cache_misses: int = 0
        self._query_cache: "OrderedDict[str, List[Tuple[T, float]]]" = OrderedDict()
        self._max_cache: int = 500
        self._store_name: str = store_name

    def _get_item_id(self, item: T) -> str:
        """
        从条目中提取ID。

        Args:
            item: 存储的条目

        Returns:
            条目的唯一标识符
        """
        for attr in ("item_id", "entry_id", "id"):
            val = getattr(item, attr, None)
            if val:
                return val
        return generate_id("item")

    def _get_item_type(self, item: T) -> str:
        """
        从条目中提取类型/类别。

        Args:
            item: 存储的条目

        Returns:
            条目的类型字符串
        """
        for attr in ("store_type", "category", "type"):
            val = getattr(item, attr, None)
            if val:
                return str(val)
        return "general"

    def _get_item_tags(self, item: T) -> List[str]:
        """
        从条目中提取标签列表。

        Args:
            item: 存储的条目

        Returns:
            标签列表，不存在时返回空列表
        """
        tags = getattr(item, "tags", None)
        if tags is None:
            return []
        return list(tags)

    def _get_item_source(self, item: T) -> str:
        """
        从条目中提取来源。

        Args:
            item: 存储的条目

        Returns:
            来源字符串，不存在时返回空字符串
        """
        src = getattr(item, "source", None)
        return str(src) if src else ""

    def _get_item_created_at(self, item: T) -> float:
        """
        从条目中提取创建时间。

        Args:
            item: 存储的条目

        Returns:
            创建时间戳
        """
        ts = getattr(item, "created_at", None)
        if ts:
            return float(ts)
        return now_timestamp()

    def _add_index_entries(self, iid: str, item: T) -> None:
        """
        添加条目到各个索引中。

        Args:
            iid: 条目ID
            item: 条目对象
        """
        for tag in self._get_item_tags(item):
            self._tag_index[tag.lower()].add(iid)
        itype = self._get_item_type(item)
        self._type_index[itype].add(iid)
        src = self._get_item_source(item)
        if src:
            self._source_index[src].add(iid)
        heapq.heappush(self._time_heap, (self._get_item_created_at(item), iid))

    def _remove_index_entries(self, iid: str, item: T) -> None:
        """
        从各个索引中移除条目。

        Args:
            iid: 条目ID
            item: 条目对象
        """
        for tag in self._get_item_tags(item):
            self._tag_index[tag.lower()].discard(iid)
        itype = self._get_item_type(item)
        self._type_index[itype].discard(iid)
        src = self._get_item_source(item)
        if src:
            self._source_index[src].discard(iid)

    def _invalidate_cache(self) -> None:
        """
        使查询缓存失效。
        """
        self._query_cache.clear()

    def _evict_weakest(self) -> None:
        """
        驱逐最弱的条目（非永久且重要性/权重最低的）。
        """
        if not self._items:
            return
        evictable: List[Tuple[float, str]] = []
        for iid, item in self._items.items():
            if getattr(item, "permanent", False):
                continue
            importance = getattr(item, "importance", None)
            if importance is None:
                importance = getattr(item, "weight", 0.5)
            evictable.append((float(importance), iid))
        if evictable:
            evictable.sort()
            self.remove(evictable[0][1])

    def add(self, item: T) -> T:
        """
        添加条目到存储中。

        Args:
            item: 要添加的条目

        Returns:
            添加的条目对象
        """
        with self._lock:
            if len(self._items) >= self._max:
                self._evict_weakest()
            iid = self._get_item_id(item)
            self._items[iid] = item
            self._add_index_entries(iid, item)
            self._added += 1
            self._invalidate_cache()
        return item

    def remove(self, iid: str) -> None:
        """
        移除条目。

        Args:
            iid: 条目ID
        """
        with self._lock:
            if iid in self._items:
                del self._items[iid]
                self._remove_index_entries(iid, self._items[iid])
                self._deleted += 1
                self._invalidate_cache()

    def update(self, iid: str, item: T) -> T:
        """
        更新条目。

        Args:
            iid: 条目ID
            item: 更新的条目对象

        Returns:
            更新的条目对象
        """
        with self._lock:
            if iid in self._items:
                self._remove_index_entries(iid, self._items[iid])
                self._items[iid] = item
                self._add_index_entries(iid, item)
                self._updated += 1
                self._invalidate_cache()
        return item

    def get(self, iid: str) -> Optional[T]:
        """
        获取条目。

        Args:
            iid: 条目ID

        Returns:
            条目对象，不存在时返回None
        """
        with self._lock:
            return self._items.get(iid)

    def search(self, query: str) -> List[Tuple[T, float]]:
        """
        搜索条目。

        Args:
            query: 搜索关键词

        Returns:
            搜索结果列表，包含条目对象和相关性分数
        """
        with self._lock:
            results: List[Tuple[T, float]] = []
            for iid, item in self._items.items():
                tags = self._get_item_tags(item)
                if query in tags:
                    results.append((item, 1.0))
                elif self._get_item_type(item) == query:
                    results.append((item, 0.5))
                elif self._get_item_source(item) == query:
                    results.append((item, 0.2))
            return results

    def to_dict(self) -> Dict[str, Any]:
        """
        将计算器状态转换为字典。

        Returns:
            包含配置、指标和存储名称的字典
        """
        with self._lock:
            return {
                "initialized": self._initialized,
                "stores": self._stores,
                "metrics": dict(self._metrics),
                "history": len(self._history),
            }

    def export_state(self, filepath: str) -> None:
        """
        导出计算器状态到JSON文件。

        Args:
            filepath: 输出文件路径

        Raises:
            OSError: 文件写入失败时
            ValueError: 文件路径无效时
        """
        if not filepath:
            raise ValueError("文件路径不能为空")
        safe_path = os.path.realpath(filepath)
        if os.path.isabs(safe_path) and not safe_path.startswith(os.getcwd()):
            raise PermissionError("不允许写入工作目录之外的路径")
        with open(safe_path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, default=str)

    def import_state(self, filepath: str) -> bool:
        """
        从JSON文件导入计算器状态。

        Args:
            filepath: 输入文件路径

        Returns:
            是否成功导入
        """
        if not filepath:
            raise ValueError("文件路径不能为空")
        safe_path = os.path.realpath(filepath)
        if os.path.isabs(safe_path) and not safe_path.startswith(os.getcwd()):
            raise PermissionError("不允许读取工作目录之外的路径")
        if not os.path.exists(safe_path):
            return False
        with open(safe_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        with self._lock:
            if "config" in data:
                self._config.update(data["config"])
            if "metrics" in data:
                self._metrics.update(data["metrics"])
        return True
