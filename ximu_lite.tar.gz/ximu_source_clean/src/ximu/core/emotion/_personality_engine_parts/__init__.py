"""Split parts of personality engine.

模块初始化文件，定义公共 API 导出，保持向后兼容。
版本号: 0.5
"""

import logging

__version__ = "0.5"

# 配置模块级日志器
_logger = logging.getLogger(__name__)

# 导出核心组件，保持公共 API 兼容
from src.ximu.core.emotion._personality_engine_parts.personality_engine import PersonalityEngine

__all__ = [
    "PersonalityEngine",
    "__version__",
]

# 记录模块加载事件
_logger.info("Personality engine module initialized, version %s", __version__)
