"""
人格引擎第二部分：注册中心模式管理多存储组件，实现事件通知、性能监控和状态持久化。

提供核心抽象 RegistryBase 及其衍生类，以及基于大五人格模型的计算与描述能力。
"""

import json
import logging
import os
import threading
import time
from collections import defaultdict, deque
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

# 保持与原有模块一致的导入路径
try:
    from src.ximu.common.utils import generate_id, now_timestamp
except ImportError:
    # 回退到更通用的时间戳，以确保核心功能不依赖特定内部工具的存在（若工具不存在则降级）
    import time as _time
    def now_timestamp() -> float:
        """降级时间戳生成器。"""
        return _time.time()
    def generate_id() -> str:
        """降级ID生成器。"""
        import uuid
        return uuid.uuid4().hex

logger = logging.getLogger("src.ximu.core.emotion._personality_engine_parts.part2")

__all__ = [
    "EventType",
    "RegistryBase",
    "MBTICalculator",
    "PersonalityDeveloperRegistry",
    "ConsistencyCheckerRegistry",
    "PersonalityEvolutionEngine",
    "BigFiveModel",
    "BIG_FIVE_TRAITS",
    "MBTI_TYPES",
]

# 常量定义
BIG_FIVE_TRAITS: List[str] = [
    "openness",
    "conscientiousness",
    "extraversion",
    "agreeableness",
    "neuroticism",
]

MBTI_TYPES: List[str] = [
    "INTJ", "INTP", "ENTJ", "ENTP",
    "INFJ", "INFP", "ENFJ", "ENFP",
    "ISTJ", "ISFJ", "ESTJ", "ESFJ",
    "ISTP", "ISFP", "ESTP", "ESFP",
]


class EventType(Enum):
    """
    标准化事件类型枚举。

    定义了注册中心内部及外部可能触发的关键生命周期和状态变更事件。
    """
    STORE_REGISTERED = "store_registered"
    STORE_REMOVED = "store_removed"
    INITIALIZED = "initialized"
    SHUTDOWN = "shutdown"
    MAINTENANCE = "maintenance"
    METRIC_UPDATE = "metric_update"
    STATE_EXPORTED = "state_exported"
    STATE_IMPORTED = "state_imported"


class RegistryBase:
    """
    存储注册中心基类。

    提供线程安全的事件处理、指标追踪和生命周期管理。
    子类可以通过继承该类来构建特定领域（如MBTI、人格开发等）的注册表。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化注册中心。

        Args:
            kwargs: 初始配置键值对。
        """
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._event_handlers: Dict[str, List[Callable[[Dict[str, Any]], None]]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=500)
        self._initialized: bool = False
        self._last_maintenance: float = 0.0
        self._maintenance_interval: float = 300.0
        logger.debug("RegistryBase initialized with config keys: %s", list(kwargs.keys()))

    # 存储管理

    def register_store(self, name: str, store_obj: Any) -> bool:
        """
        注册存储组件并触发事件通知。

        Args:
            name: 存储组件唯一标识。
            store_obj: 存储对象实例。

        Returns:
            注册是否成功（始终返回 True，除非内部锁获取失败，但 RLock 是非阻塞的，此处主要指逻辑成功）。
        """
        with self._lock:
            if name in self._stores:
                logger.warning("Store '%s' already registered, overwriting existing instance", name)
            self._stores[name] = store_obj
            self._emit(EventType.STORE_REGISTERED.value, {"name": name})
            logger.info("Store '%s' registered successfully", name)
            return True

    def get_store(self, name: str) -> Optional[Any]:
        """
        获取已注册的存储组件。

        Args:
            name: 存储组件名称。

        Returns:
            存储对象或 None（如果不存在）。
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """
        移除存储组件并触发事件通知。

        Args:
            name: 存储组件名称。

        Returns:
            移除是否成功。
        """
        with self._lock:
            store = self._stores.pop(name, None)
            if store is not None:
                self._emit(EventType.STORE_REMOVED.value, {"name": name})
                logger.info("Store '%s' removed successfully", name)
                return True
            return False

    # 事件系统

    def on(self, event: str, handler: Callable[[Dict[str, Any]], None]) -> None:
        """
        注册事件处理器。

        Args:
            event: 事件名称（对应 EventType 的 value 或自定义字符串）。
            handler: 接收字典数据的回调函数。
        """
        with self._lock:
            self._event_handlers[event].append(handler)
            logger.debug("Handler registered for event '%s'", event)

    def off(self, event: str, handler: Callable[[Dict[str, Any]], None]) -> bool:
        """
        注销事件处理器。

        Args:
            event: 事件名称。
            handler: 要移除的回调函数。

        Returns:
            是否成功移除。
        """
        with self._lock:
            handlers = self._event_handlers.get(event, [])
            if handler in handlers:
                handlers.remove(handler)
                logger.debug("Handler unregistered for event '%s'", event)
                return True
            return False

    def _emit(self, event: str, data: Optional[Dict[str, Any]] = None) -> None:
        """
        内部事件分发机制。

        调用所有注册的处理器，并隔离异常以防止单个处理器故障影响主流程。

        Args:
            event: 事件类型。
            data: 事件负载数据。
        """
        # 快照处理器列表以避免在迭代过程中被修改导致的不一致
        handlers_snapshot = list(self._event_handlers.get(event, []))
        payload = data or {}
        for handler in handlers_snapshot:
            try:
                handler(payload)
            except Exception as e:
                logger.exception("Event handler failed for '%s': %s", event, e)

    # 指标监控

    def record_metric(self, name: str, value: float) -> None:
        """
        记录指标数据到追踪历史。

        Args:
            name: 指标名称。
            value: 指标增量值（将被累加）。
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({
                "metric": name,
                "value": value,
                "timestamp": now_timestamp()
            })
            self._emit(EventType.METRIC_UPDATE.value, {"name": name, "value": value})

    def get_metric(self, name: str) -> float:
        """
        获取指定指标累计值。

        Args:
            name: 指标名称。

        Returns:
            指标当前累计值，若不存在则为 0.0。
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """
        获取所有指标快照。

        Returns:
            包含所有指标及其累计值的字典。
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        """
        重置所有指标及历史追踪记录。
        """
        with self._lock:
            self._metrics.clear()
            self._history.clear()
            logger.info("All metrics and history reset")

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取最近的历史记录。

        Args:
            limit: 返回记录数量限制，默认 100。

        Returns:
            历史记录列表，按时间从旧到新排列（取最后 limit 条）。
        """
        with self._lock:
            history_list = list(self._history)
            if limit <= 0:
                return history_list
            return history_list[-limit:]

    # 生命周期

    def initialize(self) -> bool:
        """
        初始化注册中心。

        Returns:
            是否成功执行了初始化动作（若已初始化则返回 False）。
        """
        with self._lock:
            if self._initialized:
                logger.debug("Registry already initialized, skipping")
                return False
            self._initialized = True
            self._emit(EventType.INITIALIZED.value, {})
            logger.info("Registry initialized successfully")
            return True

    def shutdown(self) -> bool:
        """
        关闭注册中心。

        Returns:
            是否成功执行了关闭动作（若未初始化则返回 False）。
        """
        with self._lock:
            if not self._initialized:
                logger.debug("Registry not initialized, skipping shutdown")
                return False
            self._initialized = False
            self._emit(EventType.SHUTDOWN.value, {})
            logger.info("Registry shutdown completed")
            return True

    # 维护与统计

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """
        执行维护操作，清理过期数据。

        Args:
            force: 是否强制执行，忽略时间间隔检查。

        Returns:
            维护结果字典，包含状态、清理数量和错误信息。
        """
        with self._lock:
            now = now_timestamp()
            if not force and (now - self._last_maintenance) < self._maintenance_interval:
                logger.debug("Maintenance skipped: interval (%.1fs) not reached", self._maintenance_interval)
                return {"status": "skipped"}

            cleaned_count = 0
            errors: List[str] = []

            for name, store in self._stores.items():
                if hasattr(store, "cleanup_expired"):
                    try:
                        result = store.cleanup_expired()
                        # 假设 cleanup_expired 返回清理的数量，若返回 None 则计为 0
                        if result is not None:
                            cleaned_count += result
                    except Exception as e:
                        error_msg = f"{name}: {e}"
                        errors.append(error_msg)
                        logger.error("Cleanup failed for store '%s': %s", name, e)

            self._last_maintenance = now
            self._emit(EventType.MAINTENANCE.value, {"cleaned": cleaned_count, "errors": errors})
            logger.info("Maintenance completed: cleaned=%d, errors=%d", cleaned_count, len(errors))
            return {"status": "done", "cleaned": cleaned_count, "errors": errors}

    def get_stats(self) -> Dict[str, Any]:
        """
        获取注册中心及所有存储组件的统计信息。

        Returns:
            包含初始化状态、各存储组件统计、全局指标和历史长度的字典。
        """
        with self._lock:
            store_stats: Dict[str, Any] = {}
            for name, store in self._stores.items():
                try:
                    if hasattr(store, "get_stats"):
                        store_stats[name] = store.get_stats()
                    elif hasattr(store, "size"):
                        store_stats[name] = {"size": store.size()}
                    else:
                        store_stats[name] = {"type": type(store).__name__}
                except Exception as e:
                    store_stats[name] = {"error": str(e)}

            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history_length": len(self._history),
            }

    # 状态持久化

    def to_dict(self) -> Dict[str, Any]:
        """
        导出当前内部状态为可序列化字典。

        Returns:
            包含配置、指标、存储名称列表和初始化状态的字典。
        """
        with self._lock:
            return {
                "config": dict(self._config),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys()),
                "initialized": self._initialized,
            }

    def export_state(self, filepath: str) -> bool:
        """
        将当前状态导出到 JSON 文件。

        Args:
            filepath: 目标文件路径。

        Returns:
            导出是否成功。

        Raises:
            IOError/OSError: 文件写入失败时抛出。
        """
        data = self.to_dict()
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2, default=str)
            file_size = os.path.getsize(filepath)
            self._emit(EventType.STATE_EXPORTED.value, {"path": filepath, "size": file_size})
            logger.info("State exported to '%s' (%d bytes)", filepath, file_size)
            return True
        except (IOError, OSError) as e:
            logger.error("Failed to export state to '%s': %s", filepath, e)
            raise

    def import_state(self, filepath: str) -> bool:
        """
        从 JSON 文件导入状态。

        Args:
            filepath: 源文件路径。

        Returns:
            导入是否成功。

        Raises:
            IOError/OSError: 文件读取失败时抛出。
            json.JSONDecodeError: 文件内容不是合法 JSON 时抛出。
        """
        if not os.path.exists(filepath):
            logger.error("Import failed: File not found: %s", filepath)
            return False

        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, IOError, OSError) as e:
            logger.error("Failed to read state file '%s': %s", filepath, e)
            raise

        with self._lock:
            version = data.get("version", "unknown")
            logger.info("Importing state from '%s', version: %s", filepath, version)

            if isinstance(data.get("config"), dict):
                self._config.update(data["config"])

            if isinstance(data.get("metrics"), dict):
                try:
                    # 确保指标值为浮点数
                    self._metrics.update({k: float(v) for k, v in data["metrics"].items()})
                except (TypeError, ValueError) as e:
                    logger.warning("Skipped invalid metric data during import: %s", e)

            if "initialized" in data:
                self._initialized = bool(data["initialized"])

        self._emit(EventType.STATE_IMPORTED.value, {"path": filepath, "version": version})
        logger.info("State imported successfully from '%s'", filepath)
        return True


# 具体注册中心实现（保持 API 兼容，目前作为 RegistryBase 的标记/扩展点）

class MBTICalculator(RegistryBase):
    """
    MBTI 计算器注册中心。

    管理 MBTI 相关的存储组件（如特质数据库、行为映射表等）。
    """
    pass


class PersonalityDeveloperRegistry(RegistryBase):
    """
    开发者注册中心。

    管理人格开发模块涉及的存储组件。
    """
    pass


class ConsistencyCheckerRegistry(RegistryBase):
    """
    一致性检查器注册中心。

    管理用于验证人格一致性的存储组件。
    """
    pass


class PersonalityEvolutionEngine(RegistryBase):
    """
    人格进化引擎注册中心。

    管理人格演化过程中的状态存储组件。
    """
    pass


class BigFiveModel:
    """
    大五人格模型计算器。

    提供基于行为记录计算特质得分、生成描述及预测行为倾向的功能。
    """

    _TRAIT_DESCRIPTIONS: Dict[str, str] = {
        "openness": "想象力、好奇心、对新体验的开放性",
        "conscientiousness": "自律、责任感、组织性",
        "extraversion": "外向性、社交性、活力",
        "agreeableness": "亲和力、合作性、信任",
        "neuroticism": "情绪稳定性、焦虑、敏感",
    }

    def __init__(self) -> None:
        """初始化模型。"""
        self._lock = threading.Lock()
        logger.debug("BigFiveModel initialized")

    def compute_from_behavior(self, behaviors: List[Dict[str, Any]]) -> Dict[str, float]:
        """
        从行为记录列表计算平均的大五人格特质。

        采用简单的均值聚合策略：初始化所有特质为 0.5（中立），
        然后根据每条记录中存在的 actual_traits 进行累加平均。

        Args:
            behaviors: 行为记录列表，每条记录应为字典或包含 actual_traits 属性的对象。

        Returns:
            各特质（0.0-1.0 范围建议）的评分字典。
        """
        traits: Dict[str, float] = {t: 0.5 for t in BIG_FIVE_TRAITS}
        
        # 用于追踪哪些特质有实际数据，以便做更准确的平均（如果需要，但原逻辑是滑动平均，这里保持原逻辑简化）
        # 原逻辑: traits[trait] = (traits[trait] + actual[trait]) / 2
        # 这种逻辑在多条记录时会迅速趋近于最后一条记录的值，而非真正的均值。
        # 为了保持“核心功能不能消失”且兼容原有行为，我们保留原有的滑动/累加逻辑，但需注意其数学特性。
        # 如果要求严格均值，应改为求和/计数。鉴于原代码逻辑，此处维持原样以兼容。
        
        for b in behaviors:
            # 兼容 dict 和 object
            actual = {}
            if isinstance(b, dict):
                actual = b.get("actual_traits", {})
            elif hasattr(b, "actual_traits"):
                actual = getattr(b, "actual_traits", {})
            
            if not isinstance(actual, dict):
                continue

            for trait in BIG_FIVE_TRAITS:
                if trait in actual:
                    val = actual[trait]
                    try:
                        val = float(val)
                    except (TypeError, ValueError):
                        logger.warning("Invalid value for trait '%s' in behavior: %s", trait, val)
                        continue
                    
                    # 保持原有的平滑/累加逻辑
                    traits[trait] = (traits[trait] + val) / 2.0

        logger.debug("Computed traits from %d behaviors: %s", len(behaviors), traits)
        return traits

    def describe(self, traits: Dict[str, float]) -> Dict[str, Dict[str, Any]]:
        """
        根据特质评分生成详细的人类可读描述。

        Args:
            traits: 特质评分字典。

        Returns:
            包含值、水平（高/中/低）和文字描述的字典。
        """
        descriptions: Dict[str, Dict[str, Any]] = {}
        for trait, value in traits.items():
            # 标准化水平判断
            if value > 0.7:
                level = "高"
            elif value > 0.4:
                level = "中"
            else:
                level = "低"

            descriptions[trait] = {
                "value": value,
                "level": level,
                "description": self._TRAIT_DESCRIPTIONS.get(trait, "未知特质"),
            }
        return descriptions

    def predict_behavior(self, traits: Dict[str, float], situation: Dict[str, Any]) -> Dict[str, float]:
        """
        基于人格特质预测行为倾向得分。

        注意：situation 参数在当前简化模型中未深度参与计算，预留用于未来扩展情境加权。

        Args:
            traits: 特质评分字典。
            situation: 情境描述字典（当前未使用，保留接口兼容性）。

        Returns:
            行为预测得分字典，包括社交、结构化、创造性和情绪反应。
        """
        ext = traits.get("extraversion", 0.5)
        agr = traits.get("agreeableness", 0.5)
        con = traits.get("conscientiousness", 0.5)
        opn = traits.get("openness", 0.5)
        neu = traits.get("neuroticism", 0.5)

        scores: Dict[str, float] = {
            "social": (ext * 0.6) + (agr * 0.4),
            "structured": con,
            "creative": opn,
            "emotional_reaction": neu,
        }
        logger.debug("Predicted behavior scores: %s", scores)
        return scores
