"""
情感引擎重导包，分为两部分，原代码有4246行。
"""

import warnings
import importlib
import logging

def _import_module(module_name: str, package: str) -> object:
    """
    导入模块，捕获异常并记录日志。

    Args:
    module_name (str): 模块名称
    package (str): 包名称

    Returns:
    object: 模块对象
    """
    try:
        return importlib.import_module(module_name, package=package)
    except Exception as e:
        logging.warning(f"导入模块 {module_name} 失败：{e}")
        return None

def _re_export(module_name: str, package: str) -> None:
    """
    重导包，导入指定模块并将其属性导入当前命名空间。

    Args:
    module_name (str): 模块名称
    package (str): 包名称
    """
    module = _import_module(module_name, package)
    if module:
        for name in dir(module):
            if not name.startswith("_"):
                globals()[name] = getattr(module, name)

def _deprecation_warning() -> None:
    """
    提示用户使用新的导包方式。
    """
    warnings.warn("emotion_engine 已经分离，建议从具体部分导入",
                  DeprecationWarning, stacklevel=2)

def main() -> None:
    """
    主函数，重导包并提示用户使用新的导包方式。
    """
    _deprecation_warning()
    _re_export("part1", __package__)
    _re_export("part2", __package__)

if __name__ == "__main__":
    main()
