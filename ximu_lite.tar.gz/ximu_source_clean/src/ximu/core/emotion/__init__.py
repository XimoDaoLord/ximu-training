"""
src/ximu/core/emotion/__init__.py
初始化文件，导入情感分析模块中的子模块和函数。
"""
from .emotion_analyzer import EmotionAnalyzer

__all__ = ['EmotionAnalyzer']
