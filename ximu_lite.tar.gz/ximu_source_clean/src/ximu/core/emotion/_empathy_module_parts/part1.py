# ---------------------------------------------------------------------------
# 安全路径校验（路径遍历防护）
# ---------------------------------------------------------------------------

def _validate_safe_path(filepath: str) -> str:
    """校验文件路径，防止路径遍历攻击。

    Args:
        filepath: 输入路径

    Returns:
        规范化后的安全路径

    Raises:
        ValueError: 路径包含非法字符或指向非文件系统位置
        OSError: 路径解析失败
    """
    if not filepath or not isinstance(filepath, str):
        raise ValueError(f"非法路径: {filepath!r}")

    # 规范化路径，消除 ../ 等相对路径片段
    norm_path = os.path.normpath(filepath)

    # 检查是否包含非法字符
    if "\x00" in norm_path:
        raise ValueError(f"路径包含非法空字符: {filepath!r}")

    # 禁止绝对路径中仅含 ".." 的场景（相对路径解析后仍可能逃逸）
    if ".." in norm_path.split(os.sep):
        raise ValueError(f"路径包含目录遍历片段: {filepath!r}")

    # 检查是否在文件系统中存在
    try:
        os.path.exists(norm_path)
    except OSError:
        raise OSError(f"路径不存在: {norm_path!r}")

    return norm_path
