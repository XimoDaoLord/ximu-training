"""Split parts of empathy_module."""

__version__ = "0.5"

# 此包用于存放 empathy_module 的拆分部分
# 当前为占位符包，保持原有公共 API 兼容
