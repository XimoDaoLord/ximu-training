"""
Empathy Module Registry Core - v0.5.0
继承自BaseRegistry实现存储组件统一管理
包含事件总线、指标监控、生命周期维护等核心功能
"""

import json
import time
import threading
import logging
import os
from typing import Any, Dict, List, Optional, Callable, Deque
from collections import defaultdict, deque

logger = logging.getLogger("src.ximu.core.emotion._empathy_module_parts.part2")

class RegistryConfig:
    """注册表配置类，定义历史长度和维护间隔等参数"""
    
    def __init__(self, history_maxlen: int = 500, maintenance_interval: float = 300.0) -> None:
        """
        初始化注册表配置
        
        Args:
            history_maxlen: 历史记录最大长度
            maintenance_interval: 维护间隔时间（秒）
        """
        if history_maxlen < 1:
            raise ValueError("history_maxlen must be positive")
        if maintenance_interval <= 0:
            raise ValueError("maintenance_interval must be positive")
        self.history_maxlen = history_maxlen
        self.maintenance_interval = maintenance_interval

    def to_dict(self) -> Dict[str, Any]:
        """
        将配置转换为字典
        
        Returns:
            包含配置参数的字典
        """
        return {
            "history_maxlen": self.history_maxlen,
            "maintenance_interval": self.maintenance_interval
        }

class BaseRegistry:
    """
    注册表基类，提供存储组件统一管理、事件总线、指标监控和生命周期维护功能
    所有注册表子类必须继承此类
    """
    
    def __init__(self, config: RegistryConfig, event_prefix: str = "registry") -> None:
        """
        初始化注册表基类
        
        Args:
            config: 注册表配置对象
            event_prefix: 事件前缀，用于区分不同注册表的事件
        """
        if not isinstance(config, RegistryConfig):
            raise TypeError("config must be an instance of RegistryConfig")
        self.config = config
        self.event_prefix = event_prefix
        self._stores: Dict[str, Any] = {}
        self._event_handlers: Dict[str, List[Callable[[Dict[str, Any]], None]]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: Deque[Dict[str, Any]] = deque(maxlen=config.history_maxlen)
        self._lock = threading.RLock()
        self._initialized = False
        self._last_maintenance: float = 0.0
        
        # 定义存储接口方法名，使用字符串而非类型注解以避免循环引用和运行时问题
        self._store_interface_methods = ('cleanupExpired', 'get_stats', 'size')

    def register_store(self, name: str, store_obj: Any) -> None:
        """
        注册存储组件到注册表
        
        Args:
            name: 存储组件名称
            store_obj: 存储组件对象，必须实现cleanupExpired、get_stats、size方法
            
        Raises:
            ValueError: 当存储对象缺少必要接口方法时
        """
        if not isinstance(name, str) or not name:
            raise ValueError("Store name must be a non-empty string")
            
        with self._lock:
            # 检查存储对象是否实现了必要的接口
            missing_methods = [
                method for method in self._store_interface_methods 
                if not hasattr(store_obj, method) or not callable(getattr(store_obj, method))
            ]
            if missing_methods:
                raise ValueError(f"Store '{name}' missing required interface methods: {missing_methods}")
                
            self._stores[name] = store_obj
            logger.debug(f"Store '{name}' registered successfully")
            self._emit("store_registered", {"name": name, "timestamp": time.time()})

    def get_store(self, name: str) -> Optional[Any]:
        """
        获取已注册的存储组件
        
        Args:
            name: 存储组件名称
            
        Returns:
            存储组件对象，如果不存在则返回None
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """
        移除已注册的存储组件
        
        Args:
            name: 存储组件名称
            
        Returns:
            成功移除返回True，否则返回False
        """
        with self._lock:
            if name in self._stores:
                self._stores.pop(name)
                logger.debug(f"Store '{name}' removed successfully")
                self._emit("store_removed", {"name": name, "timestamp": time.time()})
                return True
            return False

    def on(self, event: str, handler: Callable[[Dict[str, Any]], None]) -> None:
        """
        注册事件回调处理器
        
        Args:
            event: 事件名称
            handler: 事件处理函数，接收事件数据字典
        """
        if not callable(handler):
            raise TypeError("Handler must be callable")
            
        with self._lock:
            event_key = f"{self.event_prefix}_{event}"
            self._event_handlers[event_key].append(handler)
            logger.debug(f"Handler registered for event '{event}'")

    def off(self, event: str, handler: Callable[[Dict[str, Any]], None]) -> None:
        """
        移除事件回调处理器
        
        Args:
            event: 事件名称
            handler: 要移除的事件处理函数
        """
        with self._lock:
            event_key = f"{self.event_prefix}_{event}"
            if handler in self._event_handlers[event_key]:
                self._event_handlers[event_key].remove(handler)
                logger.debug(f"Handler removed for event '{event}'")

    def _emit(self, event: str, data: Optional[Dict[str, Any]] = None) -> None:
        """
        内部方法：广播事件到所有注册的处理器
        
        Args:
            event: 事件名称
            data: 事件数据，可选
        """
        with self._lock:
            event_key = f"{self.event_prefix}_{event}"
            handlers = list(self._event_handlers.get(event_key, []))
            
        for handler in handlers:
            try:
                handler(data or {})
            except Exception as e:
                logger.error(f"Event handler failed for '{event}': {e}", exc_info=True)
                # 不吞异常，但记录日志避免一个handler失败影响其他handlers

    def record_metric(self, name: str, value: float) -> None:
        """
        记录指标值（累加模式）
        
        Args:
            name: 指标名称
            value: 指标增量值
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({
                "metric": name,
                "value": value,
                "timestamp": time.time()
            })
            logger.debug(f"Metric '{name}' updated to {self._metrics[name]:.4f}")

    def get_metric(self, name: str) -> float:
        """
        获取指定指标的当前值
        
        Args:
            name: 指标名称
            
        Returns:
            指标当前值，如果不存在则返回0.0
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """
        获取所有指标的快照
        
        Returns:
            包含所有指标名称和值的字典
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        """
        重置所有指标为零
        """
        with self._lock:
            self._metrics.clear()
            logger.debug("All metrics reset to zero")

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取历史记录
        
        Args:
            limit: 返回最近多少条记录
            
        Returns:
            历史记录列表，按时间倒序排列（最新的在最后）
        """
        with self._lock:
            if limit <= 0:
                return []
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """
        初始化注册表
        
        Returns:
            成功初始化返回True，如果已经初始化则返回False
        """
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._last_maintenance = time.time()
            logger.info("Registry initialized")
            self._emit("initialized", {"timestamp": time.time()})
            return True

    def shutdown(self) -> bool:
        """
        关闭注册表
        
        Returns:
            成功关闭返回True，如果未初始化则返回False
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            logger.info("Registry shutdown")
            self._emit("shutdown", {"timestamp": time.time()})
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """
        执行维护任务，包括存储组件清理
        
        Args:
            force: 是否强制维护，忽略时间间隔限制
            
        Returns:
            维护结果字典，包含状态和清理数量
        """
        with self._lock:
            now = time.time()
            if not force and now - self._last_maintenance < self.config.maintenance_interval:
                logger.debug(f"Maintenance skipped, last maintenance was {now - self._last_maintenance:.1f}s ago")
                return {"status": "skipped", "reason": "interval_not_reached"}
                
            total_cleaned = 0
            cleanup_results = {}
            
            for name, store in self._stores.items():
                try:
                    cleanup_func = getattr(store, 'cleanupExpired', None)
                    if callable(cleanup_func):
                        cleaned = cleanup_func()
                        if not isinstance(cleaned, int):
                            cleaned = int(cleaned) if cleaned else 0
                        total_cleaned += cleaned
                        cleanup_results[name] = {"cleaned": cleaned, "status": "success"}
                    else:
                        cleanup_results[name] = {"status": "skipped", "reason": "method_missing"}
                        logger.warning(f"Store '{name}' does not implement cleanupExpired method")
                except Exception as e:
                    logger.error(f"Store '{name}' cleanup failed: {e}", exc_info=True)
                    cleanup_results[name] = {"status": "error", "message": str(e)}
                    # 不中断维护流程，继续处理其他存储
            
            self._last_maintenance = now
            logger.info(f"Maintenance completed, total cleaned: {total_cleaned}")
            self._emit("maintenance", {"cleaned": total_cleaned, "timestamp": now})
            return {"status": "done", "cleaned": total_cleaned, "details": cleanup_results}

    def get_stats(self) -> Dict[str, Any]:
        """
        获取注册表统计信息
        
        Returns:
            包含初始化状态、存储统计、指标和历史长度的字典
        """
        with self._lock:
            stores_stats: Dict[str, Dict[str, Any]] = {}
            for name, store in self._stores.items():
                store_info: Dict[str, Any] = {}
                try:
                    get_stats_func = getattr(store, 'get_stats', None)
                    if callable(get_stats_func):
                        result = get_stats_func()
                        if isinstance(result, dict):
                            store_info = result
                        else:
                            store_info = {"value": result}
                    else:
                        size_func = getattr(store, 'size', None)
                        if callable(size_func):
                            size_val = size_func()
                            store_info = {"size": size_val}
                        else:
                            store_info = {"status": "incomplete"}
                            logger.debug(f"Store '{name}' has no stats methods available")
                except Exception as e:
                    logger.error(f"Failed to get stats for store '{name}': {e}", exc_info=True)
                    store_info = {"error": str(e)}
                
                stores_stats[name] = store_info
            
            return {
                "initialized": self._initialized,
                "stores": stores_stats,
                "metrics": dict(self._metrics),
                "history_length": len(self._history),
                "last_maintenance": self._last_maintenance
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        将注册表状态序列化为字典
        
        Returns:
            包含配置、指标和存储名称的字典
        """
        with self._lock:
            return {
                "config": self.config.to_dict(),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys()),
                "initialized": self._initialized
            }

    def export_state(self, filepath: str) -> None:
        """
        导出注册表状态到文件
        
        Args:
            filepath: 目标文件路径
            
        Raises:
            IOError: 当文件写入失败时
        """
        try:
            state = self.to_dict()
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(state, f, ensure_ascii=False, indent=2, default=str)
            logger.info(f"Registry state exported to {filepath}")
        except IOError as e:
            logger.error(f"Failed to export registry state to {filepath}: {e}", exc_info=True)
            raise

    def import_state(self, filepath: str) -> bool:
        """
        从文件导入注册表状态
        
        Args:
            filepath: 源文件路径
            
        Returns:
            成功导入返回True，文件不存在或格式错误返回False
        """
        try:
            if not os.path.exists(filepath):
                logger.warning(f"Import file does not exist: {filepath}")
                return False
                
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            if not isinstance(data, dict):
                logger.error(f"Invalid state format in {filepath}")
                return False
            
            with self._lock:
                if "config" in data and isinstance(data["config"], dict):
                    try:
                        self.config = RegistryConfig(**data["config"])
                    except (TypeError, ValueError) as e:
                        logger.warning(f"Invalid config in import file: {e}")
                
                if "metrics" in data and isinstance(data["metrics"], dict):
                    for key, value in data["metrics"].items():
                        try:
                            self._metrics[key] = float(value)
                        except (ValueError, TypeError) as e:
                            logger.warning(f"Invalid metric value for '{key}': {e}")
                            self._metrics[key] = 0.0
                
                logger.info(f"Registry state imported from {filepath}")
            return True
            
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON from {filepath}: {e}", exc_info=True)
            return False
        except IOError as e:
            logger.error(f"Failed to read import file {filepath}: {e}", exc_info=True)
            return False

# 具体实现类
class EmpathyResponderRegistry(BaseRegistry):
    """共情响应注册表，用于管理共情响应相关的存储组件"""
    pass

class EmotionalSupporterRegistry(BaseRegistry):
    """情感支持注册表，用于管理情感支持相关的存储组件"""
    pass

class EmotionalContagionRegistry(BaseRegistry):
    """情感传染注册表，用于管理情感传染相关的存储组件"""
    pass

class EmpathyEvaluatorRegistry(BaseRegistry):
    """共情评估注册表，用于管理共情评估相关的存储组件"""
    pass
