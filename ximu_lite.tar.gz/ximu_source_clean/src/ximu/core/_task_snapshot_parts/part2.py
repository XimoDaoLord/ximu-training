"""任务快照持久化模块：提供线程安全的TTL缓存与基于磁盘WAL的断点续跑能力。

本模块实现了线程安全的 TTL 内存缓存 (TTLStore) 以及基于 Append-Only WAL 的快照持久化机制。
支持进程崩溃后的状态恢复（断点续跑），并通过后台清理线程防止内存泄漏和 WAL 文件无限膨胀。

主要特性：
1. 线程安全的 TTL 缓存：基于 OrderedDict 实现，支持自动过期和容量限制。
2. 断点续跑能力：通过 WAL 文件记录状态变更，支持崩溃恢复。
3. 自动清理机制：后台线程定期清理过期缓存条目和压缩 WAL 文件。
4. 线程安全：所有公开方法均保证线程安全。
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
import threading
import time
from collections import OrderedDict
from typing import Any, Dict, List, Optional, TypeVar, Union

from src.ximu.common.utils import now_timestamp, safe_json_dumps

logger = logging.getLogger(__name__)

T = TypeVar("T")

class TTLStore:
    """基于 OrderedDict 的线程安全 TTL 缓存，支持容量上限与过期驱逐。

    替代原文件中 MetricStore/LogStore/StateStore/SnapshotStore/IndexStore/
    QueueStore/TaskStore/ResultStore 等高度重复的实现。

    内部使用 RLock 保证线程安全，支持 LRU 驱逐和 TTL 过期检查。
    引入后台清理线程以主动释放过期内存，避免惰性清理导致的内存泄漏。
    """

    def __init__(
        self,
        max_size: int = 10000,
        ttl: float = 3600.0,
        cleanup_interval: float = 60.0,
    ) -> None:
        """初始化 TTLStore。

        Args:
            max_size: 缓存最大容量，超出时触发 LRU 驱逐。
            ttl: 时间戳（秒），超过该时间的条目视为过期。
            cleanup_interval: 后台清理线程的执行间隔（秒），设为 0 则不启动清理线程。
        """
        self._store: OrderedDict[str, tuple[Any, float]] = OrderedDict()
        self._max_size: int = max_size
        self._ttl: float = ttl
        self._lock: threading.RLock = threading.RLock()
        self._hits: int = 0
        self._misses: int = 0
        self._evictions: int = 0
        self._total_writes: int = 0

        self._cleanup_interval: float = cleanup_interval
        self._cleanup_thread: Optional[threading.Thread] = None
        self._stop_event: threading.Event = threading.Event()

        if cleanup_interval > 0:
            self._start_cleanup_thread()

    def _start_cleanup_thread(self) -> None:
        """启动后台清理线程。"""
        self._stop_event.clear()
        self._cleanup_thread = threading.Thread(
            target=self._cleanup_loop, daemon=True, name="TTLStore-Cleanup"
        )
        self._cleanup_thread.start()
        logger.debug("TTLStore 后台清理线程已启动，间隔: %.1f秒", self._cleanup_interval)

    def _stop_cleanup_thread(self) -> None:
        """停止后台清理线程。"""
        if self._cleanup_thread and self._cleanup_thread.is_alive():
            self._stop_event.set()
            self._cleanup_thread.join(timeout=2.0)
            logger.debug("TTLStore 后台清理线程已停止")

    def _cleanup_loop(self) -> None:
        """后台清理循环，定期清理过期条目。"""
        while not self._stop_event.wait(self._cleanup_interval):
            cleaned = self.cleanup()
            if cleaned > 0:
                logger.debug("TTLStore 后台清理移除 %d 个过期条目", cleaned)

    def put(self, key: str, value: Any) -> None:
        """写入键值对，更新最后访问时间并移动至链表末尾。

        Args:
            key: 缓存键，必须为字符串。
            value: 缓存值。

        Raises:
            TypeError: 如果 key 不是字符串。
        """
        if not isinstance(key, str):
            raise TypeError(f"缓存键必须为字符串，收到: {type(key)}")

        with self._lock:
            self._store[key] = (value, now_timestamp())
            self._store.move_to_end(key)
            self._total_writes += 1
            if len(self._store) > self._max_size:
                self._store.popitem(last=False)
                self._evictions += 1

    def get(self, key: str, default: Optional[T] = None) -> Union[Any, T]:
        """获取缓存值；若不存在或已过期则返回默认值。

        Args:
            key: 查询键。
            default: 未命中时的返回值。

        Returns:
            缓存值或未命中时的默认值。
        """
        if not isinstance(key, str):
            return default if default is not None else None

        with self._lock:
            if key in self._store:
                value, ts = self._store[key]
                if now_timestamp() - ts <= self._ttl:
                    self._store.move_to_end(key)
                    self._hits += 1
                    return value
                else:
                    self._store.pop(key, None)
                    self._misses += 1
            else:
                self._misses += 1
            return default

    def remove(self, key: str) -> bool:
        """删除指定键。

        Args:
            key: 待删除的键。

        Returns:
            键是否存在并已删除。
        """
        if not isinstance(key, str):
            return False

        with self._lock:
            return self._store.pop(key, None) is not None

    def contains(self, key: str) -> bool:
        """判断键是否存在且未过期。

        Args:
            key: 查询键。

        Returns:
            键有效时返回 True。
        """
        if not isinstance(key, str):
            return False

        with self._lock:
            if key in self._store:
                _, ts = self._store[key]
                if now_timestamp() - ts <= self._ttl:
                    return True
                else:
                    self._store.pop(key, None)
            return False

    def keys(self) -> List[str]:
        """返回所有有效（未过期）键的列表。

        Returns:
            有效键列表。
        """
        with self._lock:
            now = now_timestamp()
            return [k for k, (_, ts) in self._store.items() if now - ts <= self._ttl]

    def values(self) -> List[Any]:
        """返回所有有效（未过期）值的列表。

        Returns:
            有效值列表。
        """
        with self._lock:
            now = now_timestamp()
            return [v for k, (v, ts) in self._store.items() if now - ts <= self._ttl]

    def items(self) -> List[tuple[str, Any]]:
        """返回所有有效（未过期）键值对的列表。

        Returns:
            有效键值对列表。
        """
        with self._lock:
            now = now_timestamp()
            return [(k, v) for k, (v, ts) in self._store.items() if now - ts <= self._ttl]

    def cleanup(self) -> int:
        """批量清理过期条目。

        可由后台线程定期调用，也可手动触发。

        Returns:
            已清理的过期条目数量。
        """
        with self._lock:
            now = now_timestamp()
            expired = [k for k, (_, ts) in self._store.items() if now - ts > self._ttl]
            for k in expired:
                self._store.pop(k, None)
            return len(expired)

    def clear(self) -> None:
        """清空缓存中的所有条目。"""
        with self._lock:
            self._store.clear()
            self._hits = 0
            self._misses = 0
            self._evictions = 0
            self._total_writes = 0

    def __len__(self) -> int:
        """返回当前缓存中的条目总数（含已过期但未清理的）。"""
        with self._lock:
            return len(self._store)

    def __contains__(self, key: object) -> bool:
        """重载 in 运算符，判断键是否有效。

        如果 key 不是字符串，直接返回 False。
        """
        if not isinstance(key, str):
            return False
        return self.contains(key)

    @property
    def hit_rate(self) -> float:
        """返回缓存命中率。

        Returns:
            命中率，范围 [0.0, 1.0]。如果没有访问记录，返回 0.0。
        """
        total = self._hits + self._misses
        return self._hits / total if total > 0 else 0.0

    @property
    def size(self) -> int:
        """返回当前缓存条目数。"""
        return len(self._store)

    def get_stats(self) -> Dict[str, Any]:
        """返回缓存统计信息字典。

        Returns:
            包含 size/max_size/hits/misses/hit_rate/evictions/writes 的字典。
        """
        with self._lock:
            return {
                "size": len(self._store),
                "max_size": self._max_size,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": self.hit_rate,
                "evictions": self._evictions,
                "writes": self._total_writes,
            }

    def to_dict(self) -> Dict[str, Any]:
        """导出当前缓存内容为普通字典（仅包含未过期条目）。

        Returns:
            键值对字典，仅包含有效（未过期）条目。
        """
        with self._lock:
            now = now_timestamp()
            return {
                k: v for k, (v, ts) in self._store.items() if now - ts <= self._ttl
            }

    def close(self) -> None:
        """关闭 TTLStore，停止后台清理线程。

        应在程序退出或不再需要该缓存实例时调用。
        """
        self._stop_cleanup_thread()

# ============================================================
# 模块级单例与 WAL 工具
# ============================================================
class SingletonManager:
    """进程级单例管理器，使用文件锁和事件通知保证多进程安全。"""

    def __init__(self, lock_path: str = "/tmp/ximu_snap.lock"):
        self._lock_path = lock_path
        self._lock = threading.Lock()
        self._event = threading.Event()
        self._store: Optional[TTLStore] = None

    def acquire_lock(self) -> bool:
        """获取单例创建锁，并触发事件通知。"""
        if self._lock.acquire(timeout=5.0):
            self._event.set()
            return True
        return False

    def release_lock(self) -> None:
        """释放单例创建锁。"""
        self._lock.release()

    def get_instance(self, max_size: int = 10000, ttl: float = 3600.0) -> TTLStore:
        """获取或创建单例实例，使用文件锁保证线程安全。"""
        with self._lock:
            if self._store is None:
                self._store = TTLStore(max_size, ttl)
                logger.info("已创建 TTLStore 单例 (max_size=%d, ttl=%.1f)", max_size, ttl)
            self._event.wait()
            return self._store

    def reset_instance(self) -> None:
        """重置单例，停止后台线程并清除引用。"""
        with self._lock:
            if self._store is not None:
                self._store.close()
                self._store = None
                logger.info("TTLStore 单例已重置")

def get_snapshot_store(max_size: int = 10000, ttl: float = 3600.0) -> TTLStore:
    """获取进程级唯一的 SnapshotStore 单例，确保读写方共享同一实例。"""
    singleton = SingletonManager()
    return singleton.get_instance(max_size, ttl)

# WAL 管理器
class WALManager:
    """WAL 文件操作与压缩管理，支持原子写入和流式压缩。"""

    def __init__(self, loops_dir: str):
        self._loops_dir = loops_dir
        self._wal_path = self._create_wal_path()

    def _create_wal_path(self) -> str:
        """创建 WAL 文件路径。"""
        os.makedirs(self._loops_dir, exist_ok=True)
        return os.path.join(self._loops_dir, "_snapshot_wal.jsonl")

    def _atomic_append(self, key: str, value: Any) -> bool:
        """原子追加一条记录到 WAL，使用 fsync 保障原子性。"""
        try:
            loops_dir = os.path.dirname(self._wal_path)
            fd, tmp_path = tempfile.mkstemp(dir=loops_dir, suffix=".wal_tmp")
            with os.fdopen(fd, "a", encoding="utf-8") as f:
                record = json.dumps(
                    {"key": key, "value": value, "ts": now_timestamp()},
                    ensure_ascii=False,
                    default=safe_json_dumps,
                )
                f.write(record + "\n")
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, self._wal_path)
            return True
        except Exception as exc:
            logger.error("WAL 写入失败: key=%s, error=%s", key, exc)
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            return False

    def _streaming_compact(self) -> Dict[str, Any]:
        """流式压缩 WAL 文件，保留每个键的最新值。"""
        result: Dict[str, Any] = {}
        buffer: List[str] = []
        batch_size = 1000

        try:
            with open(self._wal_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    buffer.append(line)
                    if len(buffer) >= batch_size:
                        for buf_line in buffer:
                            try:
                                record = json.loads(buf_line)
                                if isinstance(record, dict) and "key" in record:
                                    result[record["key"]] = record.get("value")
                            except json.JSONDecodeError:
                                logger.warning("WAL 压缩时 JSON 解析失败，已跳过")
                        buffer.clear()
                # 处理剩余行
                for buf_line in buffer:
                    try:
                        record = json.loads(buf_line)
                        if isinstance(record, dict) and "key" in record:
                            result[record["key"]] = record.get("value")
                    except json.JSONDecodeError:
                        logger.warning("WAL 压缩时 JSON 解析失败，已跳过")
            return result
        finally:
            if os.path.exists(self._wal_path):
                self._write_compact_wal(result)

    def _write_compact_wal(self, data: Dict[str, Any]) -> None:
        """原子写入压缩后的 WAL 数据。"""
        loops_dir = os.path.dirname(self._wal_path)
        fd, tmp_path = tempfile.mkstemp(dir=loops_dir, suffix=".wal_compact")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                for key, value in data.items():
                    record = json.dumps(
                        {"key": key, "value": value, "ts": now_timestamp()},
                        ensure_ascii=False,
                        default=safe_json_dumps,
                    )
                    f.write(record + "\n")
            os.replace(tmp_path, self._wal_path)
            logger.info("WAL 压缩完成，剩余 %d 条记录", len(data))
        except Exception:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise

    def wal_put(self, key: str, value: Any) -> bool:
        """追加一条快照记录到 WAL 文件，自动触发压缩。"""
        if not isinstance(key, str):
            raise TypeError(f"WAL 键必须为字符串，收到: {type(key)}")

        try:
            self._atomic_append(key, value)
            wal_size = os.path.getsize(self._wal_path)
            if wal_size > 10 * 1024 * 1024:
                self._streaming_compact()
            return True
        except Exception as exc:
            logger.error("WAL 写入失败: key=%s, error=%s", key, exc)
            return False

    def wal_load(self) -> Dict[str, Any]:
        """从 WAL 文件加载最新快照状态。"""
        path = self._wal_path
        if not os.path.exists(path):
            return {}

        result: Dict[str, Any] = {}
        try:
            line_count = 0
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    line_count += 1
                    try:
                        record = json.loads(line)
                        if isinstance(record, dict) and "key" in record:
                            result[record["key"]] = record.get("value")
                    except json.JSONDecodeError:
                        logger.warning("WAL 第 %d 行 JSON 解析失败，已跳过", line_count)
            logger.debug("WAL 加载完成: 总行数=%d, 有效键=%d", line_count, len(result))
            return result
        except Exception as exc:
            logger.warning("WAL 加载异常，已隔离: path=%s, error=%s", path, exc)
            corrupted_path = path + ".corrupted"
            try:
                if os.path.exists(path):
                    os.replace(path, corrupted_path)
                    logger.error("WAL 文件已隔离至: %s", corrupted_path)
            except OSError as iso_exc:
                logger.error("隔离 WAL 文件失败: %s", iso_exc)
            return {}

    def wal_compact(self) -> int:
        """手动触发 WAL 压缩，去重并保留每个键的最新值。"""
        compact_data = self.wal_load()
        path = self._wal_path

        if not os.path.exists(path):
            return 0

        self._write_compact_wal(compact_data)
        return len(compact_data)

# 工具函数
def wal_path(loops_dir: str) -> str:
    """计算 WAL 文件路径。"""
    return os.path.join(loops_dir, "_snapshot_wal.jsonl")

def reset_snapshot_store() -> None:
    """重置单例，停止旧实例的后台线程并清除引用。"""
    singleton = get_snapshot_store()
    singleton.reset_instance()
