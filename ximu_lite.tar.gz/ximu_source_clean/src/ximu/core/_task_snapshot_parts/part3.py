"""任务快照处理组件 Part 3。

提供任务快照处理器和快照结构类，支持数据处理、验证、序列化、统计记录以及带淘汰策略的键值存储。
版本: 0.5
"""

import logging
import hashlib
from collections import deque
from threading import RLock
from typing import Any, Optional, Dict, List, Tuple, Union, Hashable

from src.ximu.common.utils import Stopwatch, now_timestamp, safe_json_dumps, safe_json_loads

logger = logging.getLogger("src.ximu.core._task_snapshot_parts.part3")


class TaskSnapshotProcessor:
    """
    任务快照处理器，负责处理、验证、序列化任务数据，并记录统计信息。
    
    核心功能包括：
    - 单步和批量数据处理
    - 统计信息记录（处理数、成功/失败、耗时）
    - 历史记录维护（带容量限制）
    - 数据验证与 JSON 序列化/反序列化
    - 线程安全的配置和状态管理
    """
    
    _VERSION = "0.5"
    
    def __init__(self, name: str = 'tasksnapshotprocessor', **kwargs: Any) -> None:
        """
        初始化任务快照处理器。

        参数:
            name: 处理器名称。
            **kwargs: 额外配置参数。
        """
        self.name: str = name
        self._config: Dict[str, Any] = kwargs
        self._lock: RLock = RLock()
        self._stats: Dict[str, Union[int, float]] = {
            'processed': 0, 
            'success': 0, 
            'failed': 0, 
            'total_time': 0.0
        }
        self._history: deque = deque(maxlen=5000)
        self._state: str = 'idle'
        self._initialized: bool = False
        self._version: str = self._VERSION
        self._initialized = True

    def process_step(self, data: Any, step: int, **kwargs: Any) -> Optional[Dict[str, Any]]:
        """
        处理单个数据步骤，记录统计信息和历史。

        参数:
            data: 待处理的数据。
            step: 步骤索引。
            **kwargs: 额外参数。

        返回:
            处理后的数据，若失败则返回 None。
        """
        with self._lock:
            self._state = 'processing'
            sw = Stopwatch().start()
            try:
                result = self._transform(data, step)
            except Exception as e:
                logger.exception("转换失败，step=%s, data_type=%s", step, type(data).__name__, exc_info=True)
                result = None
            
            elapsed = sw.stop().elapsed
            self._stats['processed'] += 1
            self._stats['total_time'] += elapsed
            
            if result is not None:
                self._stats['success'] += 1
            else:
                self._stats['failed'] += 1
            
            self._history.append((now_timestamp(), f'process_step_{step}', result is not None, elapsed))
            self._state = 'idle'
            return result

    def _transform(self, data: Any, step: int) -> Any:
        """
        内部数据转换逻辑，根据数据类型执行不同转换。

        参数:
            data: 原始数据。
            step: 当前步骤索引。

        返回:
            转换后的数据。
        """
        if data is None:
            return None
        
        if isinstance(data, dict):
            result = dict(data)
            result['_processed_by'] = self.name
            result['_step'] = step
            result['_ts'] = now_timestamp()
            try:
                hash_input = str(result).encode('utf-8')
                result['_hash'] = hashlib.md5(hash_input, usedforsecurity=False).hexdigest()[:16]
            except Exception as e:
                logger.warning("哈希计算失败: %s", str(e))
                result['_hash'] = "unknown"
            return result
        
        if isinstance(data, (list, tuple)):
            return [self._transform(item, step) for item in data]
        
        if isinstance(data, (int, float)):
            return data * (1.0 + step * 0.01)
        
        if isinstance(data, str):
            return f"{data}_processed_{step}"
        
        return data

    def batch_process(self, items: List[Any], **kwargs: Any) -> List[Any]:
        """
        批量处理多个数据项，每个项经过12步转换。

        参数:
            items: 数据项列表。
            **kwargs: 额外参数。

        返回:
            处理后的数据项列表。
        """
        results: List[Any] = []
        for item in items:
            r = item
            for j in range(12):
                try:
                    r = self._transform(r, j)
                except Exception as e:
                    logger.exception("批量处理转换失败，item_index=%s, step=%s", len(results), j, exc_info=True)
                    r = None
            results.append(r)
        return results

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """
        获取处理统计信息。

        返回:
            包含 processed, success, failed, total_time 的字典。
        """
        with self._lock:
            return dict(self._stats)

    def get_history(self, limit: int = 100) -> List[Tuple[float, str, bool, float]]:
        """
        获取最近的历史记录。

        参数:
            limit: 返回的最大记录数。

        返回:
            历史记录元组列表，每条记录为 (时间戳, 操作名, 成功标志, 耗时)。
        """
        with self._lock:
            return list(self._history)[-limit:]

    def reset(self) -> None:
        """
        重置统计信息和历史记录。
        """
        with self._lock:
            self._stats = {'processed': 0, 'success': 0, 'failed': 0, 'total_time': 0.0}
            self._history.clear()

    def validate(self, data: Any) -> Tuple[bool, str]:
        """
        验证数据是否有效。

        参数:
            data: 待验证的数据。

        返回:
            (是否有效, 验证结果描述) 元组。
        """
        if data is None:
            return False, 'data_is_none'
        if isinstance(data, dict) and not data:
            return False, 'empty_dict'
        if isinstance(data, (list, tuple)) and len(data) == 0:
            return False, 'empty_collection'
        return True, 'valid'

    def serialize(self, data: Any) -> str:
        """
        将数据序列化为 JSON 字符串。

        参数:
            data: 待序列化的数据。

        返回:
            序列化后的字符串，失败时返回原始字符串表示。
        """
        try:
            return safe_json_dumps(data)
        except Exception as e:
            logger.debug("序列化失败，回退到 str()，错误: %s", str(e))
            return str(data)

    def deserialize(self, text: str) -> Optional[Dict[str, Any]]:
        """
        将 JSON 字符串反序列化为字典。

        参数:
            text: JSON 字符串。

        返回:
            反序列化后的字典，失败时返回 None。
        """
        try:
            return safe_json_loads(text)
        except Exception as e:
            logger.warning("反序列化失败: %s", str(e))
            return None

    def get_config(self, key: str, default: Any = None) -> Any:
        """
        获取配置项。

        参数:
            key: 配置键。
            default: 默认值。

        返回:
            配置值或默认值。
        """
        return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """
        设置配置项。

        参数:
            key: 配置键。
            value: 配置值。
        """
        self._config[key] = value

    def to_dict(self) -> Dict[str, Any]:
        """
        导出处理器的完整状态为字典。

        返回:
            包含 name, version, state, stats, config 的字典。
        """
        return {
            'name': self.name,
            'version': self._version,
            'state': self._state,
            'stats': self.get_stats(),
            'config': dict(self._config)
        }


class TaskSnapshotStructure:
    """
    任务快照结构，提供带淘汰策略的键值存储，支持统计命中率和访问频率。
    
    特性包括：
    - 基于 deque 的 FIFO 淘汰策略
    - 键值索引加速查找
    - 命中/未命中/淘汰计数器
    - 线程安全的并发访问
    """
    
    _VERSION = "0.5"
    
    def __init__(self, max_size: int = 10000) -> None:
        """
        初始化快照结构。

        参数:
            max_size: 最大容量，超出时自动淘汰最旧项。
        """
        self._data: deque = deque(maxlen=max_size)
        self._index: Dict[Hashable, int] = {}
        self._lock: RLock = RLock()
        self._max_size: int = max_size
        self._hits: int = 0
        self._misses: int = 0
        self._evictions: int = 0

    def add(self, key: Hashable, value: Any) -> None:
        """
        添加或更新键值对。若超出容量则淘汰最旧项。

        参数:
            key: 键，必须可哈希。
            value: 值，任意类型。
        """
        with self._lock:
            if key in self._index:
                idx = self._index[key]
                self._data[idx] = (key, value, now_timestamp())
            else:
                if len(self._data) >= self._max_size:
                    old_key = self._data[0][0]
                    if old_key in self._index:
                        del self._index[old_key]
                    self._evictions += 1
                    logger.debug("因容量限制淘汰键: %s", old_key)
                self._data.append((key, value, now_timestamp()))
                self._index[key] = len(self._data) - 1

    def get(self, key: Hashable, default: Any = None) -> Tuple[Optional[Any], bool]:
        """
        获取指定键的值。

        参数:
            key: 要查找的键。
            default: 键不存在时返回的默认值。

        返回:
            (值, 是否命中) 元组。命中时返回存储的值，未命中时返回 default。
        """
        with self._lock:
            if key in self._index:
                self._hits += 1
                idx = self._index[key]
                # 将最近访问移到末尾，实现 LFU 近似
                item = self._data[idx]
                del self._data[idx]
                self._data.append(item)
                self._index[key] = len(self._data) - 1
                return item[1], True
            else:
                self._misses += 1
                return default, False

    def remove(self, key: Hashable) -> bool:
        """
        移除指定键值对。

        参数:
            key: 要移除的键。

        返回:
            是否成功移除。若键存在则移除并返回 True，否则返回 False。
        """
        with self._lock:
            if key in self._index:
                idx = self._index[key]
                del self._data[idx]
                del self._index[key]
                # 重建索引以反映数据位置变化
                self._rebuild_index()
                return True
            return False

    def _rebuild_index(self) -> None:
        """重建键到索引位置的映射，确保一致性。"""
        self._index = {}
        for i, (key, _, _) in enumerate(self._data):
            self._index[key] = i

    def contains(self, key: Hashable) -> bool:
        """
        检查键是否存在于快照结构中。

        参数:
            key: 要检查的键。

        返回:
            键是否存在，True 表示存在，False 表示不存在。
        """
        with self._lock:
            return key in self._index

    def clear(self) -> None:
        """清空所有键值对并重置统计计数器。"""
        with self._lock:
            self._data.clear()
            self._index.clear()
            self._hits = 0
            self._misses = 0
            self._evictions = 0

    def size(self) -> int:
        """
        获取当前存储的键值对数量。

        返回:
            当前键值对数量。
        """
        with self._lock:
            return len(self._data)

    def stats(self) -> Dict[str, int]:
        """
        获取快照结构的统计信息。

        返回:
            包含 hits, misses, evictions, size, hit_rate 的字典。
        """
        with self._lock:
            total = self._hits + self._misses
            hit_rate = (self._hits / total) if total > 0 else 0.0
            return {
                'hits': self._hits,
                'misses': self._misses,
                'evictions': self._evictions,
                'size': len(self._data),
                'hit_rate': round(hit_rate, 4)
            }
