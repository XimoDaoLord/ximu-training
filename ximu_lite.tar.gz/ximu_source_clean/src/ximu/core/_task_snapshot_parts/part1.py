"""
汐沫AI - 任务快照核心模块

本模块提供任务状态管理、重试策略、数据序列化、指标收集及枚举定义等核心基础设施。
设计原则：
1. 配置通过惰性加载和缓存机制获取，避免初始化延迟
2. 线程安全的核心组件使用锁保护共享状态
3. 数据类基于dataclasses实现，支持序列化和反序列化
4. 指标收集器支持多种统计窗口和计算方式
"""

import hashlib
import json
import logging
import os
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from enum import Enum
from functools import wraps
from typing import Any, Dict, List, Optional, TypeVar, Callable, Union, Deque

logger = logging.getLogger("src.ximu.core._task_snapshot_parts.part1")
T = TypeVar('T')

# ==================== 配置管理 ====================

class ConfigManager:
    """线程安全的配置管理器，支持惰性加载和缓存。"""
    
    def __init__(self):
        self._cache: Optional[Dict[str, Any]] = None
        self._lock = threading.Lock()
    
    @property
    def cache(self) -> Dict[str, Any]:
        """获取配置缓存，如果未加载则惰性加载。"""
        if self._cache is None:
            with self._lock:
                if self._cache is None:
                    self._cache = self._load_config()
        return self._cache
    
    def _load_config(self) -> Dict[str, Any]:
        """加载底层配置，支持多层fallback。"""
        try:
            from config.settings import config as app_config
            if isinstance(app_config, dict):
                logger.debug("Successfully loaded config from config.settings")
                return app_config
            else:
                logger.warning("config.settings returned non-dict type, using empty config")
                return {}
        except ImportError:
            logger.debug("config.settings module not found, using empty config")
            return {}
        except Exception as e:
            logger.warning(f"Failed to load config.settings: {e}", exc_info=True)
            return {}
    
    def get(self, key: str, default: Any = None) -> Any:
        """获取配置值。
        
        Args:
            key: 配置键名
            default: 默认值
            
        Returns:
            配置值或默认值
        """
        return self.cache.get(key, default)

# 全局配置管理器实例
_config_manager = ConfigManager()

LOCAL_WORKSPACE: str = os.environ.get('XIMU_WORKSPACE', './local_workspace')


def get_config(key: str, default: Any = None) -> Any:
    """获取配置值。

    Args:
        key: 配置键名
        default: 默认值

    Returns:
        配置值或默认值
    """
    return _config_manager.get(key, default)


def get_key_manager() -> Any:
    """获取密钥管理器实例。

    Returns:
        密钥管理器实例，不可用时返回None
    """
    try:
        from config.key_manager import get_key_manager
        result = get_key_manager()
        logger.debug("Successfully retrieved key manager")
        return result
    except ImportError:
        logger.debug("config.key_manager module not found")
        return None
    except Exception as e:
        logger.warning(f"Failed to retrieve key manager: {e}", exc_info=True)
        return None


# ==================== 工具函数 ====================

def generate_id(prefix: str = 'id') -> str:
    """生成唯一标识符。

    Args:
        prefix: 标识符前缀

    Returns:
        格式化的唯一ID字符串
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


def now_timestamp() -> float:
    """获取当前Unix时间戳（秒）。

    Returns:
        当前时间戳浮点数
    """
    return time.time()


def now_timestamp_ms() -> int:
    """获取当前时间戳（毫秒）。

    Returns:
        当前时间戳整数（毫秒）
    """
    return int(time.time() * 1000)


def compute_hash(data: str) -> str:
    """计算字符串的SHA256哈希值。

    Args:
        data: 待哈希的字符串

    Returns:
        十六进制哈希字符串
    """
    return hashlib.sha256(data.encode('utf-8')).hexdigest()


# ==================== 计时器 ====================

class Stopwatch:
    """高精度计时器，支持暂停与累计。

    使用monotonic时钟避免系统时间调整的影响。
    """

    def __init__(self) -> None:
        """初始化计时器，处于停止状态。"""
        self._elapsed: float = 0.0
        self._running: bool = False
        self._last_start: float = 0.0

    def start(self) -> 'Stopwatch':
        """启动或继续计时。

        Returns:
            self，支持链式调用
        """
        if not self._running:
            self._last_start = time.monotonic()
            self._running = True
            logger.debug("Stopwatch started")
        return self

    def stop(self) -> float:
        """停止计时并返回累计时间。

        Returns:
            累计 elapsed 时间（秒）
        """
        if self._running:
            self._elapsed += time.monotonic() - self._last_start
            self._running = False
            logger.debug(f"Stopwatch stopped, elapsed={self._elapsed:.3f}s")
        return self._elapsed

    def elapsed(self) -> float:
        """获取当前累计时间（含运行中部分）。

        Returns:
            当前经过时间（秒）
        """
        current = self._elapsed
        if self._running:
            current += time.monotonic() - self._last_start
        return current

    def reset(self) -> 'Stopwatch':
        """重置计时器。

        Returns:
            self，支持链式调用
        """
        self._elapsed = 0.0
        self._running = False
        self._last_start = 0.0
        logger.debug("Stopwatch reset")
        return self


# ==================== 重试装饰器 ====================

def retry_on_failure(
    max_retries: int = 3,
    delay: float = 0.1,
    backoff: float = 2.0
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """指数退避重试装饰器。

    Args:
        max_retries: 最大重试次数
        delay: 初始等待时间（秒）
        backoff: 退避倍数

    Returns:
        装饰后的函数
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            last_exception: Optional[Exception] = None

            for attempt in range(max_retries):
                try:
                    result = func(*args, **kwargs)
                    if attempt > 0:
                        logger.debug(f"Function {func.__name__} succeeded on attempt {attempt + 1}")
                    return result
                except Exception as e:
                    last_exception = e
                    if attempt == max_retries - 1:
                        logger.error(
                            f"Function {func.__name__} failed after {max_retries} attempts: {e}",
                            exc_info=True
                        )
                        raise

                    wait_time = delay * (backoff ** attempt)
                    logger.warning(
                        f"Retry {attempt + 1}/{max_retries} for {func.__name__}, "
                        f"waiting {wait_time:.2f}s, error: {e}"
                    )
                    time.sleep(wait_time)

            raise last_exception  # type: ignore[misc]

        return wrapper
    return decorator


# ==================== JSON工具 ====================

def safe_json_dumps(obj: Any, **kwargs: Any) -> str:
    """安全JSON序列化，处理不可序列化对象。

    Args:
        obj: 待序列化的对象
        **kwargs: json.dumps的其他参数

    Returns:
        JSON字符串
    """
    kwargs.setdefault('ensure_ascii', False)
    kwargs.setdefault('default', str)
    try:
        return json.dumps(obj, **kwargs)
    except Exception as e:
        logger.error(f"JSON serialization failed: {e}", exc_info=True)
        raise


def safe_json_loads(s: str, **kwargs: Any) -> Optional[Any]:
    """安全JSON反序列化，失败返回None。

    Args:
        s: JSON字符串
        **kwargs: json.loads的其他参数

    Returns:
        解析后的对象，解析失败返回None
    """
    if not s:
        return None

    try:
        result = json.loads(s, **kwargs)
        return result
    except (json.JSONDecodeError, TypeError) as e:
        logger.debug(f"JSON parse failed: {e}, input: {s[:100]}...")
        return None


# ==================== 枚举定义 ====================

class TaskStatus(Enum):
    """任务状态枚举。"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


class PriorityLevel(Enum):
    """优先级等级枚举。

    数值越高优先级越低（1=最高，5=最低）。
    """
    CRITICAL = 1
    HIGH = 2
    MEDIUM = 3
    LOW = 4
    MINIMAL = 5

    @classmethod
    def validate(cls, value: int) -> None:
        if value < 1 or value > 5:
            raise ValueError(f"PriorityLevel value must be 1-5, got {value}")


class OperationMode(Enum):
    """操作模式枚举。"""
    SYNC = "sync"
    ASYNC = "async"
    BATCH = "batch"
    STREAM = "stream"
    HYBRID = "hybrid"


class ErrorCodeCategory(Enum):
    """错误代码分类枚举。"""
    INTERNAL = "internal"
    VALIDATION = "validation"
    TIMEOUT = "timeout"
    RESOURCE_EXHAUSTED = "resource_exhausted"
    PERMISSION_DENIED = "permission_denied"
    NOT_FOUND = "not_found"
    SERVICE_UNAVAILABLE = "service_unavailable"
    UNKNOWN = "unknown"


class EventType(Enum):
    """事件类型枚举。"""
    CREATED = "created"
    STARTED = "started"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRIED = "retried"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


class DataFormat(Enum):
    """数据格式枚举。"""
    JSON = "json"
    XML = "xml"
    YAML = "yaml"
    CSV = "csv"
    BINARY = "binary"
    TEXT = "text"


class ProcessingState(Enum):
    """处理状态枚举。"""
    IDLE = "idle"
    RUNNING = "running"
    BLOCKED = "blocked"
    WAITING = "waiting"
    TERMINATED = "terminated"
    COMPLETED = "completed"


class ResourceType(Enum):
    """资源类型枚举。"""
    CPU = "cpu"
    MEMORY = "memory"
    DISK = "disk"
    NETWORK = "network"
    GPU = "gpu"
    IO = "io"


class QualityTier(Enum):
    """质量等级枚举。"""
    STANDARD = "standard"
    HIGH = "high"
    ULTRA = "ultra"
    PREMIUM = "premium"
    BASIC = "basic"


class LatencyBucket(Enum):
    """延迟分桶枚举。"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"
    EXCESSIVE = "excessive"


class CachePolicy(Enum):
    """缓存策略枚举。"""
    LRU = "lru"
    LFU = "lfu"
    FIFO = "fifo"
    NONE = "none"
    TTL = "ttl"


class RetryPolicy(Enum):
    """重试策略枚举。"""
    NONE = "none"
    FIXED = "fixed"
    EXPONENTIAL = "exponential"
    LINEAR = "linear"
    RANDOM = "random"


class LoadLevel(Enum):
    """负载等级枚举。"""
    IDLE = "idle"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class HealthGrade(Enum):
    """健康等级枚举。"""
    EXCELLENT = "excellent"
    GOOD = "good"
    FAIR = "fair"
    POOR = "poor"
    CRITICAL = "critical"


class RiskLevel(Enum):
    """风险等级枚举。"""
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ConfidenceLevel(Enum):
    """置信度等级枚举。"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    VERY_HIGH = "very_high"
    CERTAIN = "certain"


class TimeGranularity(Enum):
    """时间粒度枚举（单位：秒）。"""
    SECOND = 1
    MINUTE = 60
    HOUR = 3600
    DAY = 86400
    WEEK = 604800


class AggregationType(Enum):
    """聚合类型枚举。"""
    SUM = "sum"
    AVG = "avg"
    MIN = "min"
    MAX = "max"
    COUNT = "count"
    P95 = "p95"
    P99 = "p99"


class SortOrder(Enum):
    """排序顺序枚举。"""
    ASCENDING = "ascending"
    DESCENDING = "descending"


class FilterOperator(Enum):
    """过滤操作符枚举。"""
    EQUAL = "eq"
    NOT_EQUAL = "ne"
    GREATER = "gt"
    GREATER_EQUAL = "gte"
    LESS = "lt"
    LESS_EQUAL = "lte"
    CONTAINS = "contains"
    IN = "in"
    NOT_IN = "not_in"


# ==================== 数据类基类 ====================

@dataclass
class BaseSnapshotData:
    """快照数据基类，消除重复字段定义。

    提供通用的快照字段和序列化能力。
    使用dataclasses.asdict实现to_dict方法。
    """
    id: str = field(default_factory=lambda: generate_id('snap'))
    timestamp: float = field(default_factory=now_timestamp)
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    status: str = TaskStatus.PENDING.value
    priority: int = PriorityLevel.MEDIUM.value
    retry_count: int = 0
    max_retries: int = 3
    timeout_ms: int = 30000
    created_at: float = field(default_factory=now_timestamp)
    updated_at: float = field(default_factory=now_timestamp)
    version: str = '1.0.0'
    tags: List[str] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典表示。

        Returns:
            包含所有字段的字典
        """
        return asdict(self)

    def update_timestamp(self) -> None:
        """更新updated_at时间戳。"""
        self.updated_at = now_timestamp()

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'BaseSnapshotData':
        """从字典创建实例。

        使用dataclasses字段定义进行过滤，确保只包含已知字段。

        Args:
            d: 包含字段值的字典

        Returns:
            新创建的实例

        Raises:
            TypeError: 当输入不是字典时
        """
        if not isinstance(d, dict):
            raise TypeError(f"Expected dict, got {type(d).__name__}")

        # 获取类定义的所有字段名
        allowed_keys = {f.name for f in cls.__dataclass_fields__.values()}
        # 过滤只保留允许的字段
        filtered = {k: v for k, v in d.items() if k in allowed_keys}
        
        try:
            instance = cls(**filtered)
            logger.debug(f"Created {cls.__name__} instance from dict with {len(filtered)} fields")
            return instance
        except TypeError as e:
            logger.error(f"Failed to create {cls.__name__} from dict: {e}", exc_info=True)
            raise


# ==================== 具体数据类 ====================

@dataclass
class RequestContext(BaseSnapshotData):
    """请求上下文快照。"""
    pass


@dataclass
class ResponseMetadata(BaseSnapshotData):
    """响应元数据快照，默认优先级为HIGH。"""
    priority: int = field(default=PriorityLevel.HIGH.value)


@dataclass
class ProcessingResult(BaseSnapshotData):
    """处理结果快照。"""
    pass


@dataclass
class ErrorDetail(BaseSnapshotData):
    """错误详情快照。

    Attributes:
        error_code: 错误代码
        error_message: 错误消息
        stack_trace: 堆栈追踪
    """
    error_code: str = ''
    error_message: str = ''
    stack_trace: str = ''
    priority: int = field(default=PriorityLevel.LOW.value)


@dataclass
class EventRecord(BaseSnapshotData):
    """事件记录快照。

    Attributes:
        event_type: 事件类型
    """
    event_type: str = EventType.CREATED.value
    priority: int = field(default=PriorityLevel.MEDIUM.value)


@dataclass
class MetricSnapshot(BaseSnapshotData):
    """指标快照。"""
    pass


@dataclass
class ConfigSnapshot(BaseSnapshotData):
    """配置快照，默认优先级为LOW。"""
    priority: int = field(default=PriorityLevel.LOW.value)


@dataclass
class StatusReport(BaseSnapshotData):
    """状态报告快照。"""
    pass


@dataclass
class PerformanceStats(BaseSnapshotData):
    """性能统计快照。"""
    pass


@dataclass
class ResourceUsage(BaseSnapshotData):
    """资源使用情况快照。"""
    pass


@dataclass
class QualityMetrics(BaseSnapshotData):
    """质量指标快照，默认优先级为LOW。"""
    priority: int = field(default=PriorityLevel.LOW.value)


@dataclass
class LatencyStats(BaseSnapshotData):
    """延迟统计快照。"""
    pass


@dataclass
class CacheStats(BaseSnapshotData):
    """缓存统计快照，默认优先级为LOW。"""
    priority: int = field(default=PriorityLevel.LOW.value)


@dataclass
class RetryStats(BaseSnapshotData):
    """重试统计快照，默认优先级为LOW。"""
    priority: int = field(default=PriorityLevel.LOW.value)


@dataclass
class LoadStats(BaseSnapshotData):
    """负载统计快照。"""
    pass


@dataclass
class HealthReport(BaseSnapshotData):
    """健康报告快照。"""
    pass


@dataclass
class RiskAssessment(BaseSnapshotData):
    """风险评估快照，默认优先级为HIGH。"""
    priority: int = field(default=PriorityLevel.HIGH.value)


@dataclass
class ConfidenceScore(BaseSnapshotData):
    """置信度评分快照，默认优先级为LOW。"""
    priority: int = field(default=PriorityLevel.LOW.value)


@dataclass
class TimeWindow(BaseSnapshotData):
    """时间窗口快照，默认优先级为LOW。"""
    priority: int = field(default=PriorityLevel.LOW.value)


@dataclass
class AggregatedData(BaseSnapshotData):
    """聚合数据快照。"""
    pass


# ==================== 指标收集器 ====================

class MetricsCollector:
    """通用指标收集器，支持多种指标类型和窗口统计。

    线程安全，使用RLock保护共享状态。
    支持计数器（counters）和累计指标（metrics）两种模式。
    """

    # 预定义的指标名称
    METRIC_NAMES: tuple = (
        'total', 'success', 'failure', 'timeout', 'retry',
        'cancelled', 'queued', 'completed', 'active', 'waiting',
        'min', 'max', 'avg', 'p50', 'p90', 'p95', 'p99', 'p999', 'stddev'
    )

    def __init__(
        self,
        name: str = '',
        window_seconds: float = 60.0,
        history_size: int = 10000
    ) -> None:
        """初始化指标收集器。

        Args:
            name: 收集器名称
            window_seconds: 统计窗口大小（秒）
            history_size: 历史记录最大长度
        """
        if history_size < 1:
            raise ValueError(f"history_size must be >= 1, got {history_size}")

        self.name = name
        self._lock = threading.RLock()
        self._window = max(0.1, window_seconds)
        self._last_reset = now_timestamp()
        self._history: Deque[tuple] = deque(maxlen=history_size)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._counters: Dict[str, float] = {m: 0.0 for m in self.METRIC_NAMES}

        logger.debug(
            f"MetricsCollector '{name}' initialized: "
            f"window={window_seconds}s, history={history_size}"
        )

    def record(self, metric: str, value: float = 1.0) -> None:
        """记录单个指标值。

        Args:
            metric: 指标名称
            value: 指标值

        Raises:
            ValueError: 当metric不在已知列表中时（可选严格模式）
        """
        if metric not in self.METRIC_NAMES:
            logger.warning(
                f"Unknown metric '{metric}' for collector '{self.name}', "
                f"known: {self.METRIC_NAMES}"
            )

        with self._lock:
            self._counters[metric] = self._counters.get(metric, 0.0) + value
            self._metrics[metric] = self._metrics.get(metric, 0.0) + value
            self._history.append((now_timestamp(), metric, value))

    def get(self, metric: str) -> float:
        """获取指定指标的累计值。

        Args:
            metric: 指标名称

        Returns:
            指标值，不存在时返回0.0
        """
        with self._lock:
            return self._counters.get(metric, 0.0)

    def reset(self, metric: Optional[str] = None) -> None:
        """重置指标。

        Args:
            metric: 指定重置的指标，None表示重置所有
        """
        with self._lock:
            if metric:
                self._counters[metric] = 0.0
                logger.debug(f"Reset metric '{metric}' in collector '{self.name}'")
            else:
                for m in self.METRIC_NAMES:
                    self._counters[m] = 0.0
                self._metrics.clear()
                self._last_reset = now_timestamp()
                logger.debug(f"Reset all metrics in collector '{self.name}'")

    def get_rate(self, metric: str) -> float:
        """获取指标速率（每秒值）。

        Args:
            metric: 指标名称

        Returns:
            指标速率
        """
        with self._lock:
            elapsed = max(0.001, now_timestamp() - self._last_reset)
            return self._metrics.get(metric, 0.0) / elapsed

    def get_window_stats(self, metric: str, window: Optional[float] = None) -> Dict[str, float]:
        """获取指定窗口内的统计信息。

        Args:
            metric: 指标名称
            window: 窗口大小（秒），None使用默认值

        Returns:
            包含count/sum/avg/min/max的统计字典
        """
        with self._lock:
            win = window if window is not None else self._window
            now = now_timestamp()
            values = [
                v for t, m, v in self._history
                if m == metric and now - t < win
            ]

            if not values:
                return {'count': 0, 'sum': 0.0, 'avg': 0.0, 'min': 0.0, 'max': 0.0}

            total = sum(values)
            return {
                'count': len(values),
                'sum': total,
                'avg': total / len(values) if len(values) > 0 else 0.0,
                'min': min(values) if values else 0.0,
                'max': max(values) if values else 0.0,
            }

    def get_all_counters(self) -> Dict[str, float]:
        """获取所有计数器的快照。

        Returns:
            计数器字典
        """
        with self._lock:
            return dict(self._counters)

    def get_all_metrics(self) -> Dict[str, float]:
        """获取所有指标的累计值快照。

        Returns:
            指标字典
        """
        with self._lock:
            return dict(self._metrics)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典表示。"""
        with self._lock:
            return {
                'name': self.name,
                'window': self._window,
                'history_size': len(self._history),
                'counters': self._counters,
                'metrics': self._metrics,
                'last_reset': self._last_reset
            }
