"""
任务快照分割模块。

该模块提供了任务快照的分割功能，用于将大任务分割成小任务，方便管理和处理。
"""

import logging
from typing import List, Dict, Any

# 初始化日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def split_task_snapshot(task_snapshot: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    将任务快照分割成小任务。

    Args:
    task_snapshot (Dict[str, Any]): 任务快照数据，包含任务ID、任务名称、任务描述等信息。

    Returns:
    List[Dict[str, Any]]: 分割后的小任务列表。
    """
    # 日志记录
    logger.info("开始分割任务快照")

    # 初始化小任务列表
    small_tasks = []

    # 分割任务快照
    for task_id, task_data in task_snapshot.items():
        # 日志记录
        logger.info(f"分割任务ID：{task_id}")

        # 创建小任务
        small_task = {
            "task_id": task_id,
            "task_name": task_data["task_name"],
            "task_description": task_data["task_description"]
        }

        # 添加小任务到列表
        small_tasks.append(small_task)

    # 日志记录
    logger.info("任务快照分割完成")

    return small_tasks

def merge_task_snapshot(small_tasks: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    将小任务合并成任务快照。

    Args:
    small_tasks (List[Dict[str, Any]]): 小任务列表，包含任务ID、任务名称、任务描述等信息。

    Returns:
    Dict[str, Any]: 合并后的任务快照数据。
    """
    # 日志记录
    logger.info("开始合并小任务")

    # 初始化任务快照数据
    task_snapshot = {}

    # 合并小任务
    for small_task in small_tasks:
        # 日志记录
        logger.info(f"合并任务ID：{small_task['task_id']}")

        # 添加小任务数据到任务快照
        task_snapshot[small_task["task_id"]] = {
            "task_name": small_task["task_name"],
            "task_description": small_task["task_description"]
        }

    # 日志记录
    logger.info("小任务合并完成")

    return task_snapshot
