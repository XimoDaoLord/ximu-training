#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
本地嵌入模型（配置驱动，兼容BGE ONNX / Jina）。

设计：
  * 免费、离线、纯 CPU：做纯语义召回（学习系统分类、记忆检索、过滤初筛）
  * 可复用单例：memory_engine、error_learning、upload_gate 都复用本模块
  * 诚实降级：onnxruntime / tokenizers / 模型文件任一缺失，返回 None
  * 懒加载 + 进程内小缓存
  * 模型名 / 文件路径 / 输出维度全部来自统一配置 ModelConfig
    （config/model_config.yaml），本模块不再写死任何模型相关信息。

模型文件位置（由 ModelConfig 决定，不写死）：
  <本地模型根目录>/<legacy_bge.file>/<legacy_bge.onnx_model>
  <本地模型根目录>/<legacy_bge.file>/<legacy_bge.tokenizer>
  可用环境变量 XIMU_BGE_MODEL_DIR 显式覆盖模型目录。

接口：
  is_local_embedding_available() -> bool
  embed_text_local(text, as_query=False) -> list[float] | None  # L2归一化向量
  local_embedding_dim() -> int   # 输出维度（来自配置）
  local_embedding_backend() -> str
"""
from __future__ import annotations

import logging
import os
import threading
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger("src.ximu.core.local_bge_embedder")

# 版本号
__version__ = "0.5"

# 常量定义
_MAX_LEN: int = 512
_CACHE_MAX: int = 1024
_RETRIEVAL_INSTRUCTION: str = "为这个句子生成表示以用于检索相关文章："
_MISSING_ONNX_FILENAME: str = "__missing_onnx__"
_MISSING_TOKENIZER_FILENAME: str = "__missing_tokenizer__"

# 单例状态
_singleton_lock = threading.Lock()
_state: Dict[str, any] = {
    "ready": False,
    "tried": False,
    "session": None,
    "tokenizer": None,
    "cache": {},
    "cache_max": _CACHE_MAX,
}


# ---------------------------------------------------------------------------
# 配置访问器（懒加载：首次调用时从 ModelConfig 读取，import 时不依赖配置文件）
# ---------------------------------------------------------------------------

def _get_model_config_singleton():
    """获取 ModelConfig 单例，若不可用则返回 None。"""
    try:
        from src.ximu.core.model_config import get_model_config
        return get_model_config()
    except ImportError:
        logger.debug("[embed] ModelConfig 模块不可用")
        return None
    except Exception as e:
        logger.debug("[embed] ModelConfig 初始化失败: %s", e)
        return None


def _legacy_bge_cfg() -> dict:
    """读取 legacy_bge 配置字典（模型名/子目录/onnx/tokenizer 相对路径）。

    ModelConfig 不可用时返回空 dict，由调用方走诚实降级。
    """
    cfg_obj = _get_model_config_singleton()
    if cfg_obj is None:
        return {}
    try:
        return dict(cfg_obj.get_legacy_bge())
    except Exception as e:
        logger.debug("[embed] 获取 legacy_bge 配置失败: %s", e)
        return {}


def _bge_dim() -> int:
    """输出向量维度：正常路径来自 ModelConfig.get_dim('bge')。"""
    cfg_obj = _get_model_config_singleton()
    if cfg_obj is not None:
        try:
            return int(cfg_obj.get_dim("bge"))
        except Exception as e:
            logger.debug("[embed] 获取 BGE 维度失败: %s", e)
    # ModelConfig 完全不可用时的最后兜底（与加载器内置默认一致）；正常路径不会走到。
    return 1024


def _bge_name() -> str:
    """后端标识名（日志/backend 接口用），来自配置；不可用时返回占位串。"""
    cfg = _legacy_bge_cfg()
    return cfg.get("name", "local-embed-onnx")


def _resolve_model_dir() -> Path:
    """解析模型目录，优先使用环境变量，其次使用配置，最后使用默认路径。"""
    env = os.environ.get("XIMU_BGE_MODEL_DIR", "").strip()
    if env:
        p = Path(env)
        if p.exists():
            return p
    cfg = _legacy_bge_cfg()
    base = Path.home()
    cfg_obj = _get_model_config_singleton()
    if cfg_obj is not None:
        try:
            base = Path(cfg_obj.get_model_dir())
        except Exception as e:
            logger.debug("[embed] 获取模型目录配置失败: %s", e)
    
    # ModelConfig 不可用：回退到项目根下 data/用户数据/本地模型（与加载器默认一致）
    if base == Path.home() and cfg_obj is None:
        root = Path(__file__).resolve().parents[3]
        base = root / "data" / "用户数据" / "本地模型"
        
    sub = cfg.get("file", "")
    return (base / sub) if sub else base


def _load() -> bool:
    """懒加载 ONNX 会话和 Tokenizer，成功返回 True，失败返回 False。"""
    if _state["ready"]:
        return True
    if _state["tried"]:
        return False

    with _singleton_lock:
        if _state["ready"]:
            return True
        if _state["tried"]:
            return False
        _state["tried"] = True

        try:
            import onnxruntime as ort
            from tokenizers import Tokenizer
        except Exception as e:
            logger.warning("[embed] 依赖缺失: %s", e)
            return False

        mdir = _resolve_model_dir()
        cfg = _legacy_bge_cfg()
        onnx_rel = cfg.get("onnx_model") or ""
        tok_rel = cfg.get("tokenizer") or ""
        # 相对路径缺失时指向一个必然不存在的路径，触发"文件缺失"诚实降级，绝不抛异常
        onnx_path = (mdir / onnx_rel) if onnx_rel else (mdir / _MISSING_ONNX_FILENAME)
        tok_path = (mdir / tok_rel) if tok_rel else (mdir / _MISSING_TOKENIZER_FILENAME)

        if not onnx_path.exists() or not tok_path.exists():
            logger.warning("[embed] 模型文件缺失(dir=%s)", mdir)
            return False

        try:
            sess = ort.InferenceSession(str(onnx_path), providers=["CPUExecutionProvider"])
            tok = Tokenizer.from_file(str(tok_path))
            tok.enable_padding(pad_id=0, pad_token="[PAD]")
            tok.enable_truncation(max_length=_MAX_LEN)
        except Exception as e:
            logger.warning("[embed] 加载失败: %s", e)
            return False

        _state["session"] = sess
        _state["tokenizer"] = tok
        _state["ready"] = True
        logger.info("[embed] 就绪: %s (dim=%d)", _bge_name(), _bge_dim())
        return True


# ---------------------------------------------------------------------------
# 公共 API
# ---------------------------------------------------------------------------

def is_local_embedding_available() -> bool:
    """检查本地嵌入模型是否可用。"""
    return _load()


def local_embedding_dim() -> int:
    """返回本地嵌入向量维度（来自 ModelConfig，不再写死）。"""
    return _bge_dim()


def local_embedding_backend() -> str:
    """返回后端标识名，若不可用则返回 'unavailable'。"""
    if _state["ready"]:
        return _bge_name()
    return "unavailable"


def __getattr__(name: str):
    """PEP 562：兼容旧代码按模块名访问 LOCAL_EMBEDDING_DIM（懒解析为配置维度）。"""
    if name == "LOCAL_EMBEDDING_DIM":
        return _bge_dim()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def _embed_numpy(text: str, as_query: bool = False) -> Optional[List[float]]:
    """使用 NumPy 和 ONNX 会话生成 L2 归一化向量。"""
    sess = _state["session"]
    tok = _state["tokenizer"]
    if as_query:
        text = _RETRIEVAL_INSTRUCTION + text
    enc = tok.encode(text)
    feed = {
        "input_ids": np.array([enc.ids], dtype=np.int64),
        "attention_mask": np.array([enc.attention_mask], dtype=np.int64),
        "token_type_ids": np.array([enc.type_ids], dtype=np.int64),
    }
    out = sess.run(None, feed)[0]
    cls = out[0, 0, :]
    norm = float(np.linalg.norm(cls))
    if norm <= 0:
        return None
    return (cls / norm).astype("float32").tolist()


def _update_cache(key: str, value: List[float]) -> None:
    """更新缓存，若超出最大限制则移除最早添加的项。"""
    c = _state["cache"]
    c[key] = value
    while len(c) > _state["cache_max"]:
        c.pop(next(iter(c)), None)


def embed_text_local(text: str, as_query: bool = False) -> Optional[List[float]]:
    """生成L2归一化向量（维度来自配置）；不可用/失败返回None。绝不抛异常。"""
    if not text or not str(text).strip():
        return None
    if not _load():
        return None
    clean = str(text).strip()
    key = ("q:" if as_query else "d:") + clean
    hit = _state["cache"].get(key)
    if hit is not None:
        _update_cache(key, hit)
        return hit
    try:
        vec = _embed_numpy(clean, as_query=as_query)
    except Exception as e:
        logger.debug("[embed] embed失败: %s", e)
        return None
    if vec is None:
        return None
    _update_cache(key, vec)
    return vec


# ---------------------------------------------------------------------------
# 测试/演示
# ---------------------------------------------------------------------------

def _cosine_similarity(v1: List[float], v2: List[float]) -> float:
    """计算两个向量的余弦相似度。

    优化：用 numpy BLAS 一次性完成点积与 L2 范数，替代原先
    ``dot``/``mag1``/``mag2`` 三次 Python 生成器循环（向量可达 1024 维）。
    数学公式与原实现完全等价。
    """
    a = np.asarray(v1, dtype=np.float64)
    b = np.asarray(v2, dtype=np.float64)
    dot = float(np.dot(a, b))
    mag1 = float(np.linalg.norm(a))
    mag2 = float(np.linalg.norm(b))
    if mag1 == 0.0 or mag2 == 0.0:
        return 0.0
    return dot / (mag1 * mag2)


if __name__ == "__main__":
    print("available:", is_local_embedding_available())
    print("backend:", local_embedding_backend())
    a = embed_text_local("函数自己调用自己")
    b = embed_text_local("递归")
    c = embed_text_local("今天天气")
    if a and b and c:
        print("dim:", len(a))
        print("函数自调 vs 递归:", round(_cosine_similarity(a, b), 4))
        print("函数自调 vs 天气:", round(_cosine_similarity(a, c), 4))
