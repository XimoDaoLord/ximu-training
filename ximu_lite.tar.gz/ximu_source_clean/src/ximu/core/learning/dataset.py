"""
数据集模块，提供基础 Dataset 类。
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional


class Dataset:
    """数据集类，承载训练数据及其元信息。"""

    def __init__(
        self,
        data: Optional[List[Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.data: List[Any] = data or []
        self.metadata: Dict[str, Any] = metadata or {}

    def __len__(self) -> int:
        return len(self.data)

    def __getitem__(self, index: int) -> Any:
        return self.data[index]

    def add(self, item: Any) -> None:
        self.data.append(item)

    def as_list(self) -> List[Any]:
        return list(self.data)
