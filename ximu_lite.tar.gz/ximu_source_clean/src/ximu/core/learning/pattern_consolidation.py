"""
Re-export hub for pattern_consolidation (split into 3 parts, original 3246 lines).
"""
import logging as _logging
import importlib as _il
import warnings as _w
from typing import Any

_w.warn("pattern_consolidation has been split, import from specific part", DeprecationWarning, stacklevel=2)

def _import_pattern_consolidation_part(part_name: str) -> None:
    """
    导入 pattern_consolidation 模块的特定部分并将其内容重新导出。
    
    :param part_name: 要导入的部分名称。
    """
    try:
        module_name = f"._pattern_consolidation_parts.{part_name}"
        module = _il.import_module(module_name, package=__package__)
        for attribute_name in dir(module):
            if not attribute_name.startswith("_"):
                globals()[attribute_name] = getattr(module, attribute_name)
    except Exception as _e:
        _logging.warning(f"Re-export {__name__}.{part_name} failed: {_e}")

# 导入所有部分
_parts: list[str] = ['part1', 'part2', 'part3']
for part in _parts:
    _import_pattern_consolidation_part(part)