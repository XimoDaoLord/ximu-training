"""
反馈收集器 - 多渠道反馈收集
"""

import logging
import json
import os
import uuid
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, field, asdict

logger = logging.getLogger("src.ximu.core.learning.feedback_collector")

__version__ = "0.5"


class FeedbackType(Enum):
    """反馈类型"""
    POSITIVE = "positive"
    NEGATIVE = "negative"
    SUGGESTION = "suggestion"
    BUG_REPORT = "bug_report"
    FEATURE_REQUEST = "feature_request"
    COMPLAINT = "complaint"
    QUESTION = "question"


class FeedbackChannel(Enum):
    """反馈渠道"""
    TEXT = "text"
    VOICE = "voice"
    RATING = "rating"
    FORM = "form"
    EMOTION = "emotion"
    BEHAVIOR = "behavior"


@dataclass
class FeedbackRecord:
    """反馈记录"""
    feedback_id: str
    feedback_type: FeedbackType
    channel: FeedbackChannel
    content: str
    context: Dict[str, Any] = field(default_factory=dict)
    rating: Optional[int] = None
    timestamp: datetime = field(default_factory=datetime.now)
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    is_anonymized: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """
        将对象转换为字典表示。

        Returns:
            包含所有公共属性的字典。
        """
        data = asdict(self)
        data['feedback_type'] = self.feedback_type.value
        data['channel'] = self.channel.value
        data['timestamp'] = self.timestamp.isoformat()
        return data

    def to_json(self) -> str:
        """
        将反馈记录序列化为JSON字符串。

        Returns:
            JSON格式的字符串。
        """
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


class FeedbackCollector:
    """反馈收集器"""

    def __init__(self, storage_path: Optional[str] = None, max_records: int = 10000):
        """
        初始化反馈收集器。

        Args:
            storage_path: 反馈存储路径，默认为 ~/.ximu/feedback。
            max_records: 最大记录数量限制。
        """
        self.storage_path = storage_path or os.path.expanduser("~/.ximu/feedback")
        self.max_records = max_records
        self.records: List[FeedbackRecord] = []

        # 创建存储目录
        os.makedirs(self.storage_path, exist_ok=True)
        self._load_from_storage()

    def collect(self,
                content: str,
                feedback_type: FeedbackType,
                channel: FeedbackChannel = FeedbackChannel.TEXT,
                rating: Optional[int] = None,
                context: Optional[Dict[str, Any]] = None,
                user_id: Optional[str] = None,
                session_id: Optional[str] = None) -> FeedbackRecord:
        """
        收集反馈。

        Args:
            content: 反馈内容。
            feedback_type: 反馈类型。
            channel: 反馈渠道。
            rating: 评分 (1-5)。
            context: 上下文信息。
            user_id: 用户ID。
            session_id: 会话ID。

        Returns:
            反馈记录对象。
        """
        feedback_id = f"fb_{uuid.uuid4().hex[:12]}"

        record = FeedbackRecord(
            feedback_id=feedback_id,
            feedback_type=feedback_type,
            channel=channel,
            content=content,
            context=context or {},
            rating=rating,
            user_id=user_id,
            session_id=session_id,
            is_anonymized=user_id is None
        )

        self.records.append(record)

        # 保持记录数量限制
        if len(self.records) > self.max_records:
            self.records = self.records[-self.max_records:]

        # 自动保存到文件
        self._save_record(record)

        logger.info("收集反馈: %s, 渠道: %s", feedback_type.value, channel.value)
        return record

    def collect_rating(self, rating: int, comment: str = "") -> FeedbackRecord:
        """
        收集评分反馈。

        Args:
            rating: 评分 (1-5)。
            comment: 评语。

        Returns:
            反馈记录对象。
        """
        if rating >= 4:
            feedback_type = FeedbackType.POSITIVE
        elif rating <= 2:
            feedback_type = FeedbackType.NEGATIVE
        else:
            feedback_type = FeedbackType.SUGGESTION

        return self.collect(
            content=comment or f"评分: {rating}/5",
            feedback_type=feedback_type,
            channel=FeedbackChannel.RATING,
            rating=rating
        )

    def collect_bug_report(self,
                           description: str,
                           steps_to_reproduce: str,
                           severity: str = "medium") -> FeedbackRecord:
        """
        收集Bug报告。

        Args:
            description: Bug描述。
            steps_to_reproduce: 重现步骤。
            severity: 严重程度。

        Returns:
            反馈记录对象。
        """
        context = {
            'steps_to_reproduce': steps_to_reproduce,
            'severity': severity,
            'category': 'bug'
        }
        return self.collect(
            content=description,
            feedback_type=FeedbackType.BUG_REPORT,
            channel=FeedbackChannel.FORM,
            context=context
        )

    def collect_feature_request(self,
                                feature_description: str,
                                priority: str = "medium") -> FeedbackRecord:
        """
        收集功能请求。

        Args:
            feature_description: 功能描述。
            priority: 优先级。

        Returns:
            反馈记录对象。
        """
        context = {
            'priority': priority,
            'category': 'feature_request'
        }
        return self.collect(
            content=feature_description,
            feedback_type=FeedbackType.FEATURE_REQUEST,
            channel=FeedbackChannel.FORM,
            context=context
        )

    def collect_batch(self, feedbacks: List[Dict[str, Any]]) -> List[FeedbackRecord]:
        """
        批量收集反馈。

        Args:
            feedbacks: 反馈参数字典列表。

        Returns:
            反馈记录列表。
        """
        records = []
        for fb in feedbacks:
            record = self.collect(**fb)
            records.append(record)
        return records

    def get_recent_feedbacks(self, count: int = 10) -> List[FeedbackRecord]:
        """
        获取最近反馈。

        Args:
            count: 返回记录数量。

        Returns:
            最近的反馈记录列表。
        """
        return self.records[-count:] if self.records else []

    def get_feedback_stats(self) -> Dict[str, Any]:
        """
        获取反馈统计。

        Returns:
            包含统计信息的字典。
        """
        if not self.records:
            return {'total': 0}

        type_counts: Dict[str, int] = {}
        channel_counts: Dict[str, int] = {}
        rating_sum = 0
        rating_count = 0

        for record in self.records:
            type_counts[record.feedback_type.value] = type_counts.get(record.feedback_type.value, 0) + 1
            channel_counts[record.channel.value] = channel_counts.get(record.channel.value, 0) + 1
            if record.rating:
                rating_sum += record.rating
                rating_count += 1

        return {
            'total': len(self.records),
            'by_type': type_counts,
            'by_channel': channel_counts,
            'avg_rating': round(rating_sum / rating_count, 2) if rating_count > 0 else 0,
            'recent_count': len(self.records[-10:]) if self.records else 0
        }

    def _save_record(self, record: FeedbackRecord) -> None:
        """
        保存单条记录到文件。

        Args:
            record: 要保存的反馈记录。
        """
        try:
            filename = os.path.join(self.storage_path, f"{record.feedback_id}.json")
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(record.to_json())
        except IOError as e:
            logger.error("保存反馈记录失败: %s", str(e))
            raise

    def _load_from_storage(self) -> None:
        """
        从存储加载记录。
        """
        try:
            if os.path.exists(self.storage_path):
                for filename in os.listdir(self.storage_path):
                    if filename.endswith('.json'):
                        filepath = os.path.join(self.storage_path, filename)
                        with open(filepath, 'r', encoding='utf-8') as f:
                            data = json.load(f)
                            record = self._from_dict(data)
                            if record:
                                self.records.append(record)
            logger.info("从存储加载了 %d 条反馈记录", len(self.records))
        except Exception as e:
            logger.error("从存储加载反馈记录失败: %s", str(e))
            raise

    def _from_dict(self, data: Dict[str, Any]) -> Optional[FeedbackRecord]:
        """
        从字典创建反馈记录。

        Args:
            data: 包含反馈记录数据的字典。

        Returns:
            反馈记录对象，如果数据无效则返回 None。
        """
        try:
            return FeedbackRecord(
                feedback_id=data['feedback_id'],
                feedback_type=FeedbackType(data['feedback_type']),
                channel=FeedbackChannel(data['channel']),
                content=data['content'],
                context=data.get('context', {}),
                rating=data.get('rating'),
                timestamp=datetime.fromisoformat(data['timestamp']),
                user_id=data.get('user_id'),
                session_id=data.get('session_id'),
                is_anonymized=data.get('is_anonymized', True),
                metadata=data.get('metadata', {})
            )
        except (KeyError, ValueError, TypeError) as e:
            logger.warning("无法解析反馈记录数据: %s", str(e))
            return None
