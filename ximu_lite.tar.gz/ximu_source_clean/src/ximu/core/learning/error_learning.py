# -*- coding: utf-8 -*-
"""
汐沫AI 错误学习闭环模块。

本模块实现了基于特征匹配的错误学习闭环，通过记录、分类和检索失败案例来动态生成规避动作。
主要功能包括：
1. 记录真实的失败案例（异常、错误输出、任务失败）
2. 对错误进行分类（语法/逻辑/超时/越权/依赖缺失/网络/数据/配置等）
3. 提取错误特征用于后续检索
4. 持久化错误数据到本地JSON文件
5. 根据新任务的特征匹配检索已知错误，返回规避动作

同时保留对旧模块的向后兼容性支持。
"""

from __future__ import annotations

import json
import logging
import os
import re
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from functools import lru_cache
from typing import Any, Dict, List, Optional, Tuple

# 配置日志
logger = logging.getLogger(__name__)


# ===========================================================================
# 数据模型定义
# ===========================================================================

@dataclass
class ErrorRule:
    """错误分类规则定义。

    Attributes:
        category: 错误类别名称
        chinese_keywords: 中文关键词列表
        english_patterns: 英文正则表达式列表
        avoidance_action: 建议的规避动作
    """
    category: str
    chinese_keywords: List[str]
    english_patterns: List[str]
    avoidance_action: str

    def get_compiled_pattern(self) -> re.Pattern:
        """获取编译后的正则表达式，用于匹配错误消息。

        Returns:
            编译后的正则表达式对象
        """
        all_terms = self.chinese_keywords + self.english_patterns
        pattern = "|".join(all_terms)
        return re.compile(pattern, re.IGNORECASE)


@dataclass
class ErrorRecord:
    """错误记录数据类。

    Attributes:
        record_id: 记录唯一标识
        error_message: 原始错误消息
        error_category: 错误分类类别
        avoidance_action: 规避动作
        features: 错误特征字典
        timestamp: 记录时间戳
        context: 上下文信息
        metadata: 元数据
    """
    record_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    error_message: str = ""
    error_category: str = "unknown"
    avoidance_action: str = ""
    features: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone(timedelta(hours=8))).isoformat())
    context: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """将对象转换为字典。

        Returns:
            包含所有字段的字典
        """
        return {
            "record_id": self.record_id,
            "error_message": self.error_message,
            "error_category": self.error_category,
            "avoidance_action": self.avoidance_action,
            "features": self.features,
            "timestamp": self.timestamp,
            "context": self.context,
            "metadata": self.metadata
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ErrorRecord":
        """从字典创建对象。

        Args:
            data: 包含记录数据的字典

        Returns:
            ErrorRecord 实例
        """
        return cls(
            record_id=data.get("record_id", uuid.uuid4().hex),
            error_message=data.get("error_message", ""),
            error_category=data.get("error_category", "unknown"),
            avoidance_action=data.get("avoidance_action", ""),
            features=data.get("features", {}),
            timestamp=data.get("timestamp", datetime.now(timezone(timedelta(hours=8))).isoformat()),
            context=data.get("context", {}),
            metadata=data.get("metadata", {})
        )


# =========================================================================
# 错误分类规则库（数据驱动，可维护）
# =========================================================================

_ERROR_RULE_DEFS: List[Dict[str, Any]] = [
    {
        "category": "dependency",
        "chinese_keywords": ["找不到模块", "没有安装", "未安装", "导入失败", "无法导入",
                           "缺依赖", "缺少依赖", "模块不存在", "包缺失", "包未安装"],
        "english_patterns": [r"modulenotfound", r"no module named", r"importerror",
                           r"cannot import", r"package.*not found", r"could not import",
                           r"no such package", r"import.*error"],
        "avoidance_action": "skip_import"
    },
    {
        "category": "syntax",
        "chinese_keywords": ["语法错误", "缩进错误", "无法识别的语法", "括号不匹配",
                           "括号未闭合", "缺少括号", "括号错误"],
        "english_patterns": [r"syntaxerror", r"invalid syntax", r"indentationerror",
                           r"taberror", r"unexpected indent", r"unmatched",
                           r"parsing error"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "naming",
        "chinese_keywords": ["名称未定义", "变量未定义", "未定义的名称", "找不到变量",
                           "变量不存在"],
        "english_patterns": [r"nameerror", r"name ['\"]?.*['\"]? is not defined",
                           r"undefined name", r"is not defined"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "attribute",
        "chinese_keywords": ["属性不存在", "没有此属性", "属性错误", "无此属性"],
        "english_patterns": [r"attributeerror", r"has no attribute",
                           r"cannot access attribute", r"object has no"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "type_error",
        "chinese_keywords": ["类型错误", "不支持的操作数", "类型不匹配", "类型不兼容"],
        "english_patterns": [r"typeerror", r"unsupported operand", r"argument of type",
                           r"not.*support.*type"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "key_error",
        "chinese_keywords": ["键不存在", "缺少键", "键错误", "没有该键"],
        "english_patterns": [r"keyerror", r"missing key", r"no such key", r"key not found"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "index_error",
        "chinese_keywords": ["索引越界", "下标越界", "索引超出范围", "索引错误"],
        "english_patterns": [r"indexerror", r"out of range", r"index out of bounds",
                           r"list index out"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "zero_division",
        "chinese_keywords": ["除零错误", "除以零", "除数为零", "除以0"],
        "english_patterns": [r"zerodivisionerror", r"division by zero", r"zero division",
                           r"divide by zero"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "value_error",
        "chinese_keywords": ["值错误", "无效值", "非法值"],
        "english_patterns": [r"valueerror", r"invalid literal", r"illegal value",
                           r"bad value"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "none_error",
        "chinese_keywords": ["空值错误", "空对象错误", "None错误"],
        "english_patterns": [r"nonetype.*has no", r"nonetype.*object", r"None has no"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "recursion",
        "chinese_keywords": ["递归深度超限", "递归过深", "递归次数过多"],
        "english_patterns": [r"recursionerror", r"maximum recursion depth",
                           r"recursion limit"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "encoding",
        "chinese_keywords": ["编码错误", "解码失败", "字符集不支持", "编码不支持"],
        "english_patterns": [r"unicodedecodeerror", r"unicodeencodeerror",
                           r"encoding error", r"decode error", r"codec can't decode"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "json_parse",
        "chinese_keywords": ["JSON解析错误", "JSON格式错误", "JSON无效", "JSON解析失败"],
        "english_patterns": [r"jsondecodeerror", r"expecting value",
                           r"unterminated string", r"json.*parse.*error",
                           r"invalid json"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "regex_error",
        "chinese_keywords": ["正则表达式错误", "正则不合法", "正则错误"],
        "english_patterns": [r"re\.error", r"bad pattern", r"invalid regular expression",
                           r"bad escape"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "file_not_found",
        "chinese_keywords": ["文件不存在", "找不到文件", "文件未找到", "路径不存在",
                           "文件找不到"],
        "english_patterns": [r"filenotfounderror", r"no such file or directory",
                           r"enoent", r"file not found"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "permission",
        "chinese_keywords": ["权限不足", "越权", "拒绝访问", "不允许访问", "不在白名单"],
        "english_patterns": [r"permissionerror", r"permission denied", r"eacces",
                           r"operation not permitted", r"blocked path",
                           r"outside whitelist", r"403"],
        "avoidance_action": "sandbox"
    },
    {
        "category": "network",
        "chinese_keywords": ["网络错误", "连接失败", "连接被拒", "无法连接",
                           "域名解析", "DNS解析失败"],
        "english_patterns": [r"connectionerror", r"connection refused", r"econnreset",
                           r"econnaborted", r"httpsconnectionpool", r"getaddrinfo",
                           r"name resolution", r"dns.*fail", r"network error"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "auth",
        "chinese_keywords": ["认证失败", "未授权", "密钥无效", "API密钥错误", "密钥过期"],
        "english_patterns": [r"unauthorized", r"\b401\b",
                           r"api[_-]?key.*(invalid|missing|expired|wrong)",
                           r"authentication failed", r"auth.*failed"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "rate_limit",
        "chinese_keywords": ["限流", "请求过多", "频率限制", "请求过于频繁"],
        "english_patterns": [r"\b429\b", r"rate.?limit", r"too many requests",
                           r"rate limiting", r"throttl"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "http_error",
        "chinese_keywords": ["HTTP错误", "请求失败", "状态码错误", "服务器内部错误"],
        "english_patterns": [r"httperror", r"bad request", r"not found",
                           r"internal server error", r"\b500\b", r"\b404\b", r"\b400\b"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "timeout",
        "chinese_keywords": ["超时", "超时了", "响应太久", "等太久", "连接超时", "读取超时"],
        "english_patterns": [r"timeouterror", r"timed out", r"\btimeout\b",
                           r"deadlineexceeded", r"readtimeout"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "database",
        "chinese_keywords": ["数据库错误", "SQL错误", "查询失败", "数据库连接失败",
                           "数据库锁定"],
        "english_patterns": [r"sqlite3", r"psycopg2", r"sql.*error", r"syntax.*sql",
                           r"database is locked", r"operationalerror"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "version_conflict",
        "chinese_keywords": ["版本不兼容", "依赖版本冲突", "版本冲突", "版本要求不满足"],
        "english_patterns": [r"version conflict", r"incompatible version",
                           r"requires a different version", r"deprecat"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "resource",
        "chinese_keywords": ["内存不足", "内存耗尽", "打开文件过多", "资源不足", "资源耗尽"],
        "english_patterns": [r"memoryerror", r"outofmemory", r"oomkilled",
                           r"too many open files", r"\boom\b", r"out of memory",
                           r"resource temporarily unavailable"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "concurrency",
        "chinese_keywords": ["死锁", "并发冲突", "线程冲突", "竞争条件"],
        "english_patterns": [r"deadlock", r"lock timeout", r"race condition"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "assertion",
        "chinese_keywords": ["断言失败", "断言错误"],
        "english_patterns": [r"assertionerror", r"assertion failed", r"assert "],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "test_failure",
        "chinese_keywords": ["测试不通过", "测试失败", "用例失败", "单元测试失败"],
        "english_patterns": [r"test.*(failed|assert)", r"testcase failure",
                           r"assertion error in test"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "output_format",
        "chinese_keywords": ["输出格式不符", "输出格式错误", "格式不符预期", "返回格式错误"],
        "english_patterns": [r"output format.*(mismatch|incorrect)",
                           r"invalid output format", r"format not as expected"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "missing_field",
        "chinese_keywords": ["字段缺失", "缺少必填字段", "参数缺失", "缺少参数"],
        "english_patterns": [r"missing required field", r"required field.*missing",
                           r"missing argument", r"field.*required"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "parameter_error",
        "chinese_keywords": ["参数错误", "参数无效", "参数不合法", "非法参数", "参数过多",
                           "参数数量不对"],
        "english_patterns": [r"invalid argument", r"illegal argument", r"bad argument",
                           r"wrong number of arguments", r"missing.*parameter"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "data",
        "chinese_keywords": ["格式错误", "无法解析", "解析失败", "数据错误", "非法数据"],
        "english_patterns": [r"failed to parse", r"invalid literal", r"data error",
                           r"malformed"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "config",
        "chinese_keywords": ["配置缺失", "配置无效", "配置错误", "配置不完整"],
        "english_patterns": [r"config.*(missing|invalid|error)", r"configuration",
                           r"api[_-]?key"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "logic",
        "chinese_keywords": ["逻辑错误", "结果错误"],
        "english_patterns": [r"unexpected result", r"wrong answer", r"logic error"],
        "avoidance_action": "add_constraint"
    },
    {
        "category": "model_call_failed",
        "chinese_keywords": ["模型调用失败", "调用失败", "模型错误", "推理失败", "生成失败",
                           "接口调用失败", "请求模型失败"],
        "english_patterns": [r"model.*(call|invoke|request).*(fail|error)",
                           r"failed to (call|invoke|generate)", r"llm.*error",
                           r"completion.*(fail|error)", r"api call failed"],
        "avoidance_action": "switch_model"
    },
    {
        "category": "execution_error",
        "chinese_keywords": ["执行失败", "执行错误", "运行时错误", "运行错误", "子任务失败",
                           "任务执行失败"],
        "english_patterns": [r"execution.*(fail|error)", r"runtime error", r"run.*error",
                           r"subtask.*fail", r"task.*(fail|error)"],
        "avoidance_action": "retry_with_detail"
    },
    {
        "category": "reflection_failed",
        "chinese_keywords": ["反思失败", "检查失败", "质量检查失败"],
        "english_patterns": [r"reflection.*fail", r"quality.*check.*fail", r"review.*fail"],
        "avoidance_action": "retry_with_detail"
    }
]


class ErrorClassifier:
    """错误分类器。

    使用正则表达式规则对错误进行分类，支持数据驱动的配置方式。
    """

    def __init__(self, rules: Optional[List[Dict[str, Any]]] = None) -> None:
        """初始化分类器。

        Args:
            rules: 自定义规则列表，如果为None则使用默认规则
        """
        self.rules: List[Tuple[str, re.Pattern]] = []
        self._initialize_rules(rules if rules is not None else _ERROR_RULE_DEFS)

    def _initialize_rules(self, rule_defs: List[Dict[str, Any]]) -> None:
        """初始化规则列表。

        Args:
            rule_defs: 规则定义列表
        """
        for rule_def in rule_defs:
            category = rule_def["category"]
            chinese_keywords = rule_def.get("chinese_keywords", [])
            english_patterns = rule_def.get("english_patterns", [])
            all_terms = chinese_keywords + english_patterns

            if not all_terms:
                continue

            try:
                pattern = re.compile("|".join(all_terms), re.IGNORECASE)
                self.rules.append((category, pattern))
            except re.error as e:
                logger.warning("Invalid regex pattern for category %s: %s", category, e)
                continue

    def classify(self, error_message: str) -> Tuple[str, str]:
        """对错误消息进行分类。

        Args:
            error_message: 错误消息文本

        Returns:
            元组，包含错误类别和规避动作
        """
        if not error_message:
            return "unknown", "add_constraint"

        for category, pattern in self.rules:
            if pattern.search(error_message):
                # 获取规避动作
                avoidance_action = self._get_avoidance_action(category)
                return category, avoidance_action

        return "unknown", "add_constraint"

    def _get_avoidance_action(self, category: str) -> str:
        """获取指定类别的规避动作。

        Args:
            category: 错误类别

        Returns:
            规避动作字符串
        """
        for rule_def in _ERROR_RULE_DEFS:
            if rule_def["category"] == category:
                return rule_def.get("avoidance_action", "add_constraint")
        return "add_constraint"


class ErrorFeatureExtractor:
    """错误特征提取器。

    从错误消息中提取关键特征用于后续检索和匹配。
    """

    def extract_features(self, error_message: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """提取错误特征。

        Args:
            error_message: 错误消息
            context: 上下文信息

        Returns:
            特征字典
        """
        features: Dict[str, Any] = {}

        # 提取关键词
        keywords = self._extract_keywords(error_message)
        features["keywords"] = keywords

        # 提取错误类型
        error_type = self._extract_error_type(error_message)
        features["error_type"] = error_type

        # 提取HTTP状态码
        status_code = self._extract_http_status_code(error_message)
        if status_code:
            features["http_status_code"] = status_code

        # 提取文件路径
        file_path = self._extract_file_path(error_message)
        if file_path:
            features["file_path"] = file_path

        # 提取变量名
        variable_names = self._extract_variable_names(error_message)
        if variable_names:
            features["variable_names"] = variable_names

        # 添加上下文信息
        if context:
            features["context"] = context

        return features

    def _extract_keywords(self, text: str) -> List[str]:
        """提取关键词。

        Args:
            text: 文本内容

        Returns:
            关键词列表
        """
        keywords = []
        # 提取中文关键词
        chinese_pattern = re.compile(r'[\u4e00-\u9fa5]+')
        chinese_matches = chinese_pattern.findall(text)
        keywords.extend(chinese_matches[:10])  # 限制数量

        # 提取英文关键词
        english_pattern = re.compile(r'[a-zA-Z_]{3,}')
        english_matches = english_pattern.findall(text)
        keywords.extend([m.lower() for m in english_matches[:10]])

        return list(set(keywords))

    def _extract_error_type(self, text: str) -> Optional[str]:
        """提取错误类型。

        Args:
            text: 文本内容

        Returns:
            错误类型字符串或None
        """
        error_types = [
            "ModuleNotFoundError", "ImportError", "SyntaxError", "IndentationError",
            "TabError", "NameError", "AttributeError", "TypeError", "KeyError",
            "IndexError", "ZeroDivisionError", "ValueError", "RecursionError",
            "UnicodeDecodeError", "UnicodeEncodeError", "JSONDecodeError",
            "FileNotFoundError", "PermissionError", "ConnectionError",
            "TimeoutError", "RuntimeError", "AssertionError"
        ]

        for error_type in error_types:
            if error_type in text:
                return error_type

        return None

    def _extract_http_status_code(self, text: str) -> Optional[int]:
        """提取HTTP状态码。

        Args:
            text: 文本内容

        Returns:
            HTTP状态码或None
        """
        # 匹配独立的3位数状态码
        pattern = re.compile(r'\b([45]\d\d)\b')
        matches = pattern.findall(text)
        if matches:
            try:
                return int(matches[0])
            except ValueError:
                pass
        return None

    def _extract_file_path(self, text: str) -> Optional[str]:
        """提取文件路径。

        Args:
            text: 文本内容

        Returns:
            文件路径或None
        """
        # 匹配文件路径
        patterns = [
            r'[/\\][\w\-./\\]+',  # Unix和Windows路径
            r'file://[\w\-./]+',  # file URI
            r'\b[\w\-./]+\.\w{1,5}\b'  # 文件名
        ]

        for pattern in patterns:
            matches = re.findall(pattern, text)
            if matches:
                # 选择最可能的路径（最长的匹配）
                return max(matches, key=len)

        return None

    def _extract_variable_names(self, text: str) -> List[str]:
        """提取变量名。

        Args:
            text: 文本内容

        Returns:
            变量名列表
        """
        # 匹配可能的变量名
        pattern = re.compile(r"(?:name|variable|key|value|field|parameter)['\"]?[:=][^,\s]+")
        matches = pattern.findall(text)
        return [m.split(':')[-1].strip('\'"') if ':' in m else m.strip('\'"') for m in matches[:5]]


class ErrorStorage:
    """错误存储管理器。

    负责错误数据的持久化和检索。
    """

    def __init__(self, storage_path: Optional[str] = None) -> None:
        """初始化存储管理器。

        Args:
            storage_path: 存储文件路径，如果为None则使用默认路径
        """
        self.storage_path = storage_path or self._get_default_storage_path()
        self._cache: Optional[Dict[str, ErrorRecord]] = None
        self._lock = threading.Lock()

    def _get_default_storage_path(self) -> str:
        """获取默认存储路径。

        Returns:
            默认的文件路径
        """
        # 项目根目录
        project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
        storage_dir = os.path.join(project_root, "data", "learning")
        os.makedirs(storage_dir, exist_ok=True)
        return os.path.join(storage_dir, "error_library.json")

    def _load_from_disk(self) -> Dict[str, ErrorRecord]:
        """从磁盘加载数据。

        Returns:
            错误记录字典
        """
        if not os.path.exists(self.storage_path):
            return {}

        try:
            with open(self.storage_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return {k: ErrorRecord.from_dict(v) for k, v in data.items()}
        except (json.JSONDecodeError, KeyError) as e:
            logger.error("Failed to load error library: %s", e)
            return {}

    def _save_to_disk(self) -> None:
        """保存数据到磁盘。"""
        with self._lock:
            if self._cache is None:
                return

            try:
                data = {k: record.to_dict() for k, record in self._cache.items()}
                with open(self.storage_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
            except (IOError, json.JSONDecodeError) as e:
                logger.error("Failed to save error library: %s", e)

    def _get_cache(self) -> Dict[str, ErrorRecord]:
        """获取缓存。

        Returns:
            错误记录字典
        """
        if self._cache is None:
            self._cache = self._load_from_disk()
        return self._cache

    def save_error(self, record: ErrorRecord) -> bool:
        """保存错误记录。

        Args:
            record: 错误记录

        Returns:
            是否保存成功
        """
        with self._lock:
            if self._cache is None:
                self._cache = self._load_from_disk()

            self._cache[record.record_id] = record
            self._save_to_disk()
            return True

    def find_similar_errors(self, features: Dict[str, Any], threshold: float = 0.7) -> List[ErrorRecord]:
        """查找相似错误。

        Args:
            features: 特征字典
            threshold: 相似度阈值

        Returns:
            相似错误记录列表
        """
        cache = self._get_cache()
        similar_errors: List[ErrorRecord] = []

        for record in cache.values():
            similarity = self._calculate_similarity(features, record.features)
            if similarity >= threshold:
                similar_errors.append(record)

        return sorted(similar_errors, key=lambda x: self._calculate_similarity(features, x.features), reverse=True)

    def _calculate_similarity(self, features1: Dict[str, Any], features2: Dict[str, Any]) -> float:
        """计算两个特征集的相似度。

        Args:
            features1: 特征集1
            features2: 特征集2

        Returns:
            相似度分数 (0-1)
        """
        if not features1 or not features2:
            return 0.0

        common_keys = set(features1.keys()) & set(features2.keys())
        if not common_keys:
            return 0.0

        similarity_score = 0.0
        for key in common_keys:
            val1 = features1.get(key)
            val2 = features2.get(key)

            if val1 == val2:
                similarity_score += 1.0
            elif isinstance(val1, list) and isinstance(val2, list):
                # 对于列表，计算交集占比
                intersection = set(val1) & set(val2)
                union = set(val1) | set(val2)
                if union:
                    similarity_score += len(intersection) / len(union)
            else:
                # 对于其他类型，简单判断是否相近
                if self._values_are_similar(val1, val2):
                    similarity_score += 0.8

        return similarity_score / len(common_keys)

    def _values_are_similar(self, val1: Any, val2: Any) -> bool:
        """判断两个值是否相似。

        Args:
            val1: 值1
            val2: 值2

        Returns:
            是否相似
        """
        if val1 is None or val2 is None:
            return val1 is val2

        # 数值类型
        if isinstance(val1, (int, float)) and isinstance(val2, (int, float)):
            return abs(float(val1) - float(val2)) < 0.1

        # 字符串类型
        if isinstance(val1, str) and isinstance(val2, str):
            return val1.lower() == val2.lower()

        return False


class ErrorLearningPipeline:
    """错误学习流水线。

    整合分类、特征提取、存储和检索功能，提供完整的错误学习闭环。
    """

    def __init__(
        self,
        storage: Optional[ErrorStorage] = None,
        classifier: Optional[ErrorClassifier] = None,
        feature_extractor: Optional[ErrorFeatureExtractor] = None
    ) -> None:
        """初始化流水线。

        Args:
            storage: 错误存储管理器
            classifier: 错误分类器
            feature_extractor: 特征提取器
        """
        self.storage = storage or ErrorStorage()
        self.classifier = classifier or ErrorClassifier()
        self.feature_extractor = feature_extractor or ErrorFeatureExtractor()

    def record_failure(
        self,
        error_message: str,
        context: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> ErrorRecord:
        """记录失败案例。

        Args:
            error_message: 错误消息
            context: 上下文信息
            metadata: 元数据

        Returns:
            错误记录
        """
        # 分类错误
        category, avoidance_action = self.classifier.classify(error_message)

        # 提取特征
        features = self.feature_extractor.extract_features(error_message, context)

        # 创建记录
        record = ErrorRecord(
            error_message=error_message,
            error_category=category,
            avoidance_action=avoidance_action,
            features=features,
            context=context or {},
            metadata=metadata or {}
        )

        # 持久化
        self.storage.save_error(record)

        logger.info("Recorded error: category=%s, record_id=%s", category, record.record_id)

        return record

    def get_avoidance(self, new_features: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """获取规避动作。

        Args:
            new_features: 新任务的特征

        Returns:
            规避建议字典或None
        """
        similar_errors = self.storage.find_similar_errors(new_features)

        if not similar_errors:
            return None

        # 返回最高相似度的错误的规避动作
        best_match = similar_errors[0]
        return {
            "record_id": best_match.record_id,
            "category": best_match.error_category,
            "avoidance_action": best_match.avoidance_action,
            "original_error": best_match.error_message,
            "similarity": self.storage._calculate_similarity(new_features, best_match.features)
        }

    def get_statistics(self) -> Dict[str, Any]:
        """获取统计数据。

        Returns:
            统计信息字典
        """
        cache = self.storage._get_cache()
        total_records = len(cache)

        # 按类别统计
        category_counts: Dict[str, int] = {}
        for record in cache.values():
            category = record.error_category
            category_counts[category] = category_counts.get(category, 0) + 1

        return {
            "total_records": total_records,
            "category_distribution": category_counts,
            "top_categories": sorted(category_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        }


# 向后兼容：保留旧的模块级函数和类
def _get_default_pipeline() -> ErrorLearningPipeline:
    """获取默认流水线实例。

    Returns:
        默认流水线实例
    """
    return ErrorLearningPipeline()


# 模块级全局实例
_default_pipeline: Optional[ErrorLearningPipeline] = None
_pipeline_lock = threading.Lock()


def get_default_pipeline() -> ErrorLearningPipeline:
    """获取默认流水线（单例模式）。

    Returns:
        默认流水线实例
    """
    global _default_pipeline
    if _default_pipeline is None:
        with _pipeline_lock:
            if _default_pipeline is None:
                _default_pipeline = _get_default_pipeline()
    return _default_pipeline


# 模块级便捷函数
def record_failure(
    error_message: str,
    context: Optional[Dict[str, Any]] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> ErrorRecord:
    """记录失败案例（便捷函数）。

    Args:
        error_message: 错误消息
        context: 上下文信息
        metadata: 元数据

    Returns:
        错误记录
    """
    pipeline = get_default_pipeline()
    return pipeline.record_failure(error_message, context, metadata)


def get_avoidance(new_features: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """获取规避动作（便捷函数）。

    Args:
        new_features: 新任务的特征

    Returns:
        规避建议字典或None
    """
    pipeline = get_default_pipeline()
    return pipeline.get_avoidance(new_features)


def classify_error(error_message: str) -> Tuple[str, str]:
    """分类错误（便捷函数）。

    Args:
        error_message: 错误消息

    Returns:
        元组，包含错误类别和规避动作
    """
    pipeline = get_default_pipeline()
    return pipeline.classifier.classify(error_message)


def extract_features(
    error_message: str,
    context: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """提取特征（便捷函数）。

    Args:
        error_message: 错误消息
        context: 上下文信息

    Returns:
        特征字典
    """
    pipeline = get_default_pipeline()
    return pipeline.feature_extractor.extract_features(error_message, context)
