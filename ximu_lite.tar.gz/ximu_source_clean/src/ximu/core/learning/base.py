"""学习基础模块。"""
from __future__ import annotations

import abc
from typing import Any, Dict, Optional


class BaseLearningModule(abc.ABC):
    """学习模块基类。"""

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        self.config = config or {}
        self._trained = False

    @abc.abstractmethod
    def train(self, data: Any) -> None:
        """训练模块。"""
        ...

    @abc.abstractmethod
    def predict(self, input_data: Any) -> Any:
        """预测。"""
        ...

    def save(self, path: str) -> None:
        """保存模型。"""
        pass

    def load(self, path: str) -> None:
        """加载模型。"""
        pass
