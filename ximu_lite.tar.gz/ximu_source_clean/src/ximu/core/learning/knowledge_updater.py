"""
知识更新器 - 管理知识更新和版本控制

本模块提供了一个高级知识管理系统，支持知识的增删改查、版本控制、
回滚机制以及知识的导入导出功能。
"""

import logging
import copy
import json
import uuid
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, field

logger = logging.getLogger("src.ximu.core.learning.knowledge_updater")

__version__ = "0.5"


class UpdateType(Enum):
    """
    更新类型枚举

    定义了知识更新操作中可能发生的不同变更类型。
    """
    ADD = "add"
    MODIFY = "modify"
    DELETE = "delete"
    MERGE = "merge"
    ROLLBACK = "rollback"


@dataclass
class KnowledgeEntry:
    """
    知识条目数据类

    表示知识库中的单个条目，包含内容、版本及元数据。
    """
    knowledge_id: str
    content: Any
    version: int = 1
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """
        将对象转换为字典表示。

        Returns:
            包含公共属性的字典。
        """
        return {
            'knowledge_id': self.knowledge_id,
            'content': str(self.content)[:200] if self.content else None,
            'version': self.version,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'metadata': self.metadata
        }


@dataclass
class KnowledgeChange:
    """
    知识变更记录数据类

    记录知识条目的具体变更详情，用于审计追踪。
    """
    change_id: str
    knowledge_id: str
    change_type: UpdateType
    previous_value: Optional[Any] = None
    new_value: Optional[Any] = None
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """
        将对象转换为字典表示。

        Returns:
            包含公共属性的字典。
        """
        return {
            'change_id': self.change_id,
            'knowledge_id': self.knowledge_id,
            'change_type': self.change_type.value,
            'timestamp': self.timestamp.isoformat(),
            'metadata': self.metadata
        }


class KnowledgeUpdater:
    """
    知识更新器

    核心管理类，负责知识生命周期的管理，包括添加、更新、删除、
    版本控制、回滚以及序列化/反序列化操作。
    """

    def __init__(self, max_versions: int = 100, max_log_entries: int = 10000, min_log_entries: int = 5000):
        """
        初始化知识更新器。

        Args:
            max_versions: 每个知识条目保留的最大版本历史数量。
            max_log_entries: 变更日志允许的最大条目数。
            min_log_entries: 当日志超限时保留的最小条目数。
        """
        self.knowledge_base: Dict[str, KnowledgeEntry] = {}
        self.change_log: List[KnowledgeChange] = []
        self.max_versions = max_versions
        self.version_history: Dict[str, List[KnowledgeEntry]] = {}
        self.max_log_entries = max_log_entries
        self.min_log_entries = min_log_entries

    def add_knowledge(self, knowledge_id: str, content: Any, metadata: Optional[Dict[str, Any]] = None) -> KnowledgeEntry:
        """
        添加新的知识条目。

        Args:
            knowledge_id: 知识的唯一标识符。
            content: 知识的具体内容。
            metadata: 附加的元数据字典。

        Returns:
            新创建的知识条目对象。
        """
        if knowledge_id in self.knowledge_base:
            raise ValueError(f"知识条目 {knowledge_id} 已存在")

        entry = KnowledgeEntry(
            knowledge_id=knowledge_id,
            content=content,
            version=1,
            metadata=metadata or {}
        )
        self.knowledge_base[knowledge_id] = entry
        self._record_change(knowledge_id, UpdateType.ADD, None, content)
        logger.info("添加知识: %s", knowledge_id)
        return entry

    def update_knowledge(self, knowledge_id: str, new_content: Any, metadata: Optional[Dict[str, Any]] = None) -> Optional[KnowledgeEntry]:
        """
        更新现有知识条目。

        Args:
            knowledge_id: 要更新的知识标识符。
            new_content: 新的知识内容。
            metadata: 需要更新的元数据（将合并到现有元数据中）。

        Returns:
            更新后的知识条目对象，如果知识不存在则返回 None。
        """
        if knowledge_id not in self.knowledge_base:
            logger.warning("尝试更新不存在的知识: %s", knowledge_id)
            return None

        entry = self.knowledge_base[knowledge_id]
        previous_content = entry.content

        # 保存版本历史（深拷贝快照：entry随后会被就地改写，不能存活引用）
        if knowledge_id not in self.version_history:
            self.version_history[knowledge_id] = []
        self.version_history[knowledge_id].append(copy.deepcopy(entry))

        # 保持版本数量限制
        if len(self.version_history[knowledge_id]) > self.max_versions:
            self.version_history[knowledge_id] = self.version_history[knowledge_id][-self.max_versions:]

        # 更新条目
        entry.content = new_content
        entry.version += 1
        entry.updated_at = datetime.now()

        if metadata:
            entry.metadata.update(metadata)

        self._record_change(knowledge_id, UpdateType.MODIFY, previous_content, new_content)
        logger.info("更新知识: %s, 版本: %d", knowledge_id, entry.version)
        return entry

    def delete_knowledge(self, knowledge_id: str) -> bool:
        """
        删除知识条目。

        Args:
            knowledge_id: 要删除的知识标识符。

        Returns:
            如果删除成功返回 True，否则返回 False。
        """
        if knowledge_id not in self.knowledge_base:
            logger.warning("尝试删除不存在的知识: %s", knowledge_id)
            return False

        entry = self.knowledge_base.pop(knowledge_id)
        self._record_change(knowledge_id, UpdateType.DELETE, entry.content, None)
        logger.info("删除知识: %s", knowledge_id)
        return True

    def get_knowledge(self, knowledge_id: str) -> Optional[KnowledgeEntry]:
        """
        获取知识条目。

        Args:
            knowledge_id: 知识标识符。

        Returns:
            知识条目对象，如果不存在则返回 None。
        """
        return self.knowledge_base.get(knowledge_id)

    def get_version(self, knowledge_id: str, version: int) -> Optional[KnowledgeEntry]:
        """
        获取知识条目的特定版本。

        Args:
            knowledge_id: 知识标识符。
            version: 要获取的版本号。

        Returns:
            指定版本的知识条目对象，如果找不到则返回 None。
        """
        if knowledge_id not in self.version_history:
            return None

        versions = self.version_history[knowledge_id]
        # 从后向前查找，假设版本历史是按时间顺序追加的
        for entry in reversed(versions):
            if entry.version == version:
                return entry
        return None

    def rollback_to_version(self, knowledge_id: str, version: int) -> Optional[KnowledgeEntry]:
        """
        回滚到指定版本。

        Args:
            knowledge_id: 知识标识符。
            version: 目标版本号。

        Returns:
            回滚后的知识条目对象，如果失败则返回 None。
        """
        target_entry = self.get_version(knowledge_id, version)
        if not target_entry:
            logger.error("无法回滚知识 %s 到版本 %d，版本不存在", knowledge_id, version)
            return None

        # 使用 update_knowledge 以确保正确的版本历史记录
        updated_entry = self.update_knowledge(knowledge_id, target_entry.content)
        if updated_entry:
            self._record_change(knowledge_id, UpdateType.ROLLBACK, None, target_entry.content)
            logger.info("回滚知识: %s 到版本 %d", knowledge_id, version)
            return updated_entry
        return None

    def merge_knowledge(self, knowledge_id: str, new_content: Any, conflict_resolution: str = "new_wins") -> Optional[KnowledgeEntry]:
        """
        合并知识。

        如果知识不存在，则创建新条目。如果存在，则根据冲突解决策略合并内容。

        Args:
            knowledge_id: 知识标识符。
            new_content: 新内容。
            conflict_resolution: 冲突解决策略 ('new_wins', 'keep_existing', 'concatenate')。

        Returns:
            合并后的知识条目对象。
        """
        if knowledge_id not in self.knowledge_base:
            return self.add_knowledge(knowledge_id, new_content)

        entry = self.knowledge_base[knowledge_id]
        previous = entry.content

        # 简单合并策略
        if conflict_resolution == "keep_existing":
            merged_content = previous
        elif conflict_resolution == "concatenate":
            if previous and new_content:
                merged_content = f"{previous};{new_content}"
            else:
                merged_content = previous or new_content
        else:
            # 默认行为: new_wins
            merged_content = new_content

        return self.update_knowledge(knowledge_id, merged_content)

    def _record_change(self, knowledge_id: str, change_type: UpdateType, previous_value: Optional[Any], new_value: Optional[Any]) -> None:
        """
        记录变更。

        Args:
            knowledge_id: 知识标识符。
            change_type: 变更类型。
            previous_value: 变更前值。
            new_value: 变更后值。
        """
        change = KnowledgeChange(
            change_id=str(uuid.uuid4()),
            knowledge_id=knowledge_id,
            change_type=change_type,
            previous_value=previous_value,
            new_value=new_value
        )
        self.change_log.append(change)

        # 保持日志数量限制
        if len(self.change_log) > self.max_log_entries:
            self.change_log = self.change_log[-self.min_log_entries:]

    def to_json(self) -> str:
        """
        将知识更新器状态序列化为JSON字符串。

        Returns:
            JSON格式的字符串。
        """
        data = {
            'knowledge_base': {k: v.to_dict() for k, v in self.knowledge_base.items()},
            'change_log': [c.to_dict() for c in self.change_log],
            'max_versions': self.max_versions,
            'max_log_entries': self.max_log_entries,
            'min_log_entries': self.min_log_entries
        }
        return json.dumps(data, ensure_ascii=False, indent=2)

    def from_json(self, json_str: str) -> 'KnowledgeUpdater':
        """
        从JSON字符串反序列化知识更新器状态。

        Args:
            json_str: JSON格式的字符串。

        Returns:
            恢复后的知识更新器实例。
        """
        data = json.loads(json_str)
        self.knowledge_base = {}
        for k, v in data.get('knowledge_base', {}).items():
            self.knowledge_base[k] = KnowledgeEntry(
                knowledge_id=v['knowledge_id'],
                content=v['content'],
                version=v['version'],
                created_at=datetime.fromisoformat(v['created_at']),
                updated_at=datetime.fromisoformat(v['updated_at']),
                metadata=v.get('metadata', {})
            )
        self.change_log = []
        for c in data.get('change_log', []):
            self.change_log.append(KnowledgeChange(
                change_id=c['change_id'],
                knowledge_id=c['knowledge_id'],
                change_type=UpdateType(c['change_type']),
                previous_value=c.get('previous_value'),
                new_value=c.get('new_value'),
                timestamp=datetime.fromisoformat(c['timestamp']),
                metadata=c.get('metadata', {})
            ))
        self.max_versions = data.get('max_versions', 100)
        self.max_log_entries = data.get('max_log_entries', 10000)
        self.min_log_entries = data.get('min_log_entries', 5000)
        return self
