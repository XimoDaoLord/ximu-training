# -*- coding: utf-8 -*-
"""汐沫AI 数据进化与自我优化（硬边界保护）。

本文件提供最小真实实现的数据进化与自我优化功能：
- DataEvolution 类跟踪成功率/延迟等指标，在硬边界内自动调整参数
- 硬边界（不可突破）：temperature [0.0, 2.0], top_p [0.1, 1.0]
- 所有调整建议落盘到 data/learning/data_evolution.json
"""
from __future__ import annotations

import json
import os
import time
import threading
from typing import Any, Dict, List, Optional

# 硬边界：参数调整不可突破
_HARD_BOUNDS: Dict[str, tuple] = {
    "temperature": (0.0, 2.0),
    "top_p": (0.1, 1.0),
    "max_tokens": (64, 8192),
}

def _project_root() -> str:
    """获取项目根目录路径。"""
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))

def _data_path() -> str:
    """获取数据存储路径。"""
    d = os.path.join(_project_root(), "data", "learning")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "data_evolution.json")

class DataEvolution:
    """基于真实反馈的参数自优化器（带硬边界）。"""

    def __init__(self, db_path: Optional[str] = None):
        """初始化 DataEvolution 对象。"""
        self._lock = threading.Lock()
        self._path = db_path or _data_path()
        self._metrics: List[Dict[str, Any]] = []
        self._params: Dict[str, float] = {
            "temperature": 0.7,
            "top_p": 0.9,
            "max_tokens": 2048,
        }
        self._load()

    def _load(self) -> None:
        """加载现有数据。"""
        try:
            if os.path.exists(self._path):
                with open(self._path, "r", encoding="utf-8") as f:
                    d = json.load(f)
                self._metrics = d.get("metrics", [])
                self._params.update(d.get("params", {}))
        except Exception as e:
            print(f"Error loading data: {e}")

    def _save(self) -> None:
        """保存当前状态到文件。"""
        tmp = self._path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"metrics": self._metrics[-200:], "params": self._params,
                       "updated_at": time.time()}, f, ensure_ascii=False)
        os.replace(tmp, self._path)

    def record_outcome(self, success: bool, latency_ms: float = 0.0,
                       context: str = "") -> Dict[str, Any]:
        """记录一次执行结果，触发参数调整评估。"""
        with self._lock:
            self._metrics.append({
                "ts": time.time(), "success": success,
                "latency_ms": latency_ms, "context": context,
            })
            if len(self._metrics) > 200:
                self._metrics = self._metrics[-200:]
            adjustment = self._evolve_locked()
            self._save()
            return adjustment

    def _evolve_locked(self) -> Dict[str, Any]:
        """近20次成功率低于阈值时微调temperature（在硬边界内）。"""
        recent = self._metrics[-20:]
        if len(recent) < 10:
            return {"action": "none", "reason": "insufficient_data"}
        success_rate = sum(1 for m in recent if m["success"]) / len(recent)
        adj: Dict[str, Any] = {}
        if success_rate < 0.5:
            old = self._params["temperature"]
            new = max(_HARD_BOUNDS["temperature"][0], old - 0.1)
            self._params["temperature"] = new
            adj["temperature"] = {"old": old, "new": new}
        elif success_rate > 0.9:
            old = self._params["temperature"]
            new = min(_HARD_BOUNDS["temperature"][1], old + 0.05)
            self._params["temperature"] = new
            adj["temperature"] = {"old": old, "new": new}
        return {"action": "adjust" if adj else "none",
                "success_rate": round(success_rate, 3), "adjustments": adj}

    def get_params(self) -> Dict[str, float]:
        """获取当前参数设置。"""
        with self._lock:
            return dict(self._params)

    def stats(self) -> Dict[str, Any]:
        """获取统计信息。"""
        with self._lock:
            return {
                "total_records": len(self._metrics),
                "params": dict(self._params),
                "bounds": _HARD_BOUNDS,
                "path": self._path,
            }

_singleton: Optional[DataEvolution] = None
_slock = threading.Lock()

def get_data_evolution() -> DataEvolution:
    """获取 DataEvolution 单例。"""
    global _singleton
    if _singleton is None:
        with _slock:
            if _singleton is None:
                _singleton = DataEvolution()
    return _singleton