"""错误学习与记忆管理系统 - 核心数据模型与线程安全存储引擎。

本模块提供汐沫AI系统的错误学习基础设施，包括：
- 数据结构定义（学习条目、模式、错误记录、修正规则）
- 线程安全的记忆存储引擎（带多维索引和LRU缓存）
- 搜索功能（全文、模糊、正则、时间范围查询）
"""

from __future__ import annotations
import heapq
import json
import logging
import re
import threading
import time
import uuid
from collections import OrderedDict, defaultdict
from datetime import datetime, timedelta, timezone
from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Set, Tuple, TypeVar, Optional, Callable, Iterable

logger = logging.getLogger("src.ximu.core.learning._error_learning_parts.part1")

T = TypeVar("T")

def generate_id(prefix: str = "id") -> str:
    """生成带前缀的唯一ID。

    Args:
        prefix: ID前缀字符串（默认值为"id”）

    Returns:
        唯一标识符字符串（UUID格式）

    Raises:
        RuntimeError: UUID生成失败时抛出
    """
    try:
        return f"{prefix}_{uuid.uuid4().hex[:16]}"
    except Exception as e:
        logger.error("ID生成失败: %s", str(e))
        raise RuntimeError("ID生成异常") from e

def now_timestamp() -> float:
    """获取当前Unix时间戳（秒）。

    Returns:
        当前时间戳（浮点型）

    Raises:
        RuntimeError: 时间获取失败时抛出
    """
    try:
        return time.time()
    except Exception as e:
        logger.error("时间戳获取失败: %s", str(e))
        raise RuntimeError("时间获取异常") from e

def now_datetime() -> datetime:
    """获取当前东八区日期时间。

    Returns:
        带时区信息的datetime对象（UTC+8）

    Raises:
        RuntimeError: 时间获取失败时抛出
    """
    try:
        return datetime.now(timezone(timedelta(hours=8)))
    except Exception as e:
        logger.error("时区时间获取失败: %s", str(e))
        raise RuntimeError("时区时间异常") from e

def format_datetime(dt: Optional[datetime] = None, fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    """格式化日期时间为字符串。

    Args:
        dt: 输入datetime对象（默认为当前时间）
        fmt: 格式化字符串（默认为"YYYY-MM-DD HH:mm:ss"）

    Returns:
        格式化后的时间字符串

    Raises:
        ValueError: dt为无效时间对象时抛出
    """
    if dt is None:
        dt = now_datetime()
    if not isinstance(dt, datetime):
        raise ValueError("无效时间对象")
    return dt.strftime(fmt)

def _extract_id(item: Any) -> str:
    """从对象中提取唯一标识符。

    按优先级顺序尝试常见字段名：item_id、entry_id、id。

    Args:
        item: 目标对象（需包含至少一个ID属性）

    Returns:
        提取到的ID字符串

    Raises:
        ValueError: 无法从对象中提取ID时抛出
    """
    for attr_name in ("item_id", "entry_id", "id"):
        value = getattr(item, attr_name, None)
        if value is not None:
            return str(value)
    raise ValueError(f"无法从对象中提取ID: {type(item).__name__}")

def _extract_type(item: Any) -> str:
    """从对象中提取类型标识符。

    优先尝试store_type、type、category字段，其次使用类名。

    Args:
        item: 目标对象

    Returns:
        类型字符串（小写格式）
    """
    for attr_name in ("store_type", "type", "category"):
        value = getattr(item, attr_name, None)
        if value is not None:
            return str(value).lower()
    return str(type(item)).split(" ")[1].lower()

# ==================== 枚举定义 ====================

class LearningPhase(str, Enum):
    """学习阶段枚举。"""
    PERCEPTION = "perception"
    ENCODING = "encoding"
    CONSOLIDATION = "consolidation"
    APPLICATION = "application"
    FEEDBACK = "feedback"
    EVOLUTION = "evolution"

class LearningType(str, Enum):
    """学习类型枚举。"""
    SUPERVISED = "supervised"
    UNSUPERVISED = "unsupervised"
    REINFORCEMENT = "reinforcement"
    ONLINE = "online"
    OFFLINE = "offline"
    TRANSFER = "transfer"
    META = "meta"

class ErrorCategory(str, Enum):
    """错误分类枚举。"""
    SYNTAX = "syntax"
    LOGIC = "logic"
    RUNTIME = "runtime"
    RESOURCE = "resource"
    NETWORK = "network"
    PERMISSION = "permission"
    DATA = "data"
    CONFIG = "config"
    UNKNOWN = "unknown"

class LearningStatus(str, Enum):
    """学习状态枚举。"""
    IDENTIFIED = "identified"
    ANALYZED = "analyzed"
    CORRECTED = "corrected"
    VERIFIED = "verified"
    INTEGRATED = "integrated"

class CorrectionType(str, Enum):
    """修正类型枚举。"""
    PATCH = "patch"
    WORKAROUND = "workaround"
    PREVENTION = "prevention"
    MITIGATION = "mitigation"
    ROLLBACK = "rollback"

# ==================== 数据模型 ====================

@dataclass
class LearningItem:
    """学习条目数据模型。"""
    item_id: str = field(default_factory=generate_id)
    content: str = ""
    store_type: str = "general"
    category: str = ""
    source: str = ""
    tags: List[str] = field(default_factory=lambda: [""], metadata={"strip_whitespace": True})
    created_at: float = field(default_factory=now_timestamp)
    updated_at: float = field(default_factory=now_timestamp)
    last_accessed: float = field(default_factory=now_timestamp)
    access_count: int = 0
    importance: float = 0.5
    weight: float = 1.0
    confidence: float = 0.5
    metadata: Dict[str, Any] = field(default_factory=dict)
    permanent: bool = False

    def __post_init__(self) -> None:
        """初始化后处理：设置默认时间戳并规范化标签。"""
        self.tags = [tag.strip().lower() for tag in self.tags if tag.strip()]
        if self.created_at == 0:
            self.created_at = now_timestamp()
        if self.updated_at == 0:
            self.updated_at = now_timestamp()
        if self.last_accessed == 0:
            self.last_accessed = now_timestamp()

    def access(self) -> None:
        """记录一次访问，更新访问时间戳和计数。"""
        self.last_accessed = now_timestamp()
        self.access_count += 1

    def is_expired(self) -> bool:
        """检查条目是否过期。

        Returns:
            当前始终返回False，子类可覆盖。
        """
        return False

    def get_strength(self) -> float:
        """计算条目强度（综合访问频率、置信度、重要性和权重）。

        Returns:
            强度分数（0.0-1.0之间）
        """
        access_factor = min(1.0, self.access_count / 20.0)
        return (0.3 + 0.3 * access_factor + 0.2 * self.confidence + 0.2 * self.importance) * self.weight

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典表示。

        Returns:
            包含所有字段的字典。
        """
        return asdict(self)

# ==================== 工具类 ====================

class Stopwatch:
    """轻量级操作耗时计时器，用于性能监控。"""

    def __init__(self) -> None:
        self._start: float = 0.0
        self._end: float = 0.0

    def start(self) -> "Stopwatch":
        """启动计时，返回自身以支持链式调用。"""
        self._start = time.time()
        return self

    def stop(self) -> "Stopwatch":
        """停止计时，返回自身以支持链式调用。"""
        self._end = time.time()
        return self

    @property
    def elapsed_ms(self) -> float:
        """已耗时间（毫秒）。"""
        return (self._end - self._start) * 1000

# ==================== 存储引擎 ====================

class LearningRecordStore:
    """线程安全的错误学习记录存储引擎。

    支持多维索引（标签、类型、来源）、LRU查询缓存（版本化失效）、
    自动淘汰最弱条目、全文/模糊/正则搜索及批量操作。
    """

    def __init__(self, max_items: int = 20000) -> None:
        self._items: Dict[str, Any] = {}
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._type_index: Dict[str, Set[str]] = defaultdict(set)
        self._source_index: Dict[str, Set[str]] = defaultdict(set)
        self._max: int = max_items
        self._lock = threading.RLock()
        self._cache_version: int = 0
        self._version_map: Dict[str, int] = {}
        self._query_cache: OrderedDict[str, List[Tuple[Any, float]]] = OrderedDict(maxsize=500)
        self._strength_heap: List[Tuple[float, str]] = []

    def _invalidate_cache(self) -> None:
        self._cache_version += 1

    def _evict_weakest(self) -> bool:
        if not self._items:
            return False

        while self._strength_heap:
            strength, iid = self._strength_heap[0]
            if iid in self._items:
                item = self._items[iid]
                current_strength = -item.get_strength()
                if abs(current_strength - strength) > 1e-9:
                    heapq.heapreplace(self._strength_heap, (current_strength, iid))
                break
            heapq.heappop(self._strength_heap)

        while self._strength_heap:
            strength, iid = self._strength_heap[0]
            if iid not in self._items:
                heapq.heappop(self._strength_heap)
                continue

            item = self._items[iid]
            if item.permanent:
                heapq.heappop(self._strength_heap)
                continue

            del self._items[iid]
            self._removed_from_indexes(iid)
            self._deleted += 1
            logger.debug("淘汰最弱条目: %s", iid)
            return True

        return False

    def _removed_from_indexes(self, iid: str) -> None:
        item = self._items.get(iid)
        if item is None:
            return

        for tag in getattr(item, "tags", []):
            if tag:
                self._tag_index[tag].discard(iid)

        itype = _extract_type(item)
        self._type_index[itype].discard(iid)

        src = getattr(item, "source", "")
        if src:
            self._source_index[src].discard(iid)

    def add(self, item: Any) -> Any:
        """添加条目到存储，自动维护索引。

        Args:
            item: 要添加的对象，需具有item_id/entry_id/id属性之一

        Returns:
            添加的条目对象

        Raises:
            ValueError: 无法提取条目ID时抛出
            RuntimeError: 存储已满且无法淘汰有效条目时抛出
        """
        with self._lock:
            if len(self._items) >= self._max:
                if not self._evict_weakest():
                    raise RuntimeError("存储已满且无法淘汰有效条目")

            iid = _extract_id(item)
            if iid in self._items:
                raise ValueError(f"条目ID已存在: {iid}")

            self._items[iid] = item

            for tag in getattr(item, "tags", []):
                if tag:
                    self._tag_index[tag].add(iid)

            itype = _extract_type(item)
            self._type_index[itype].add(iid)

            src = getattr(item, "source", "")
            if src:
                self._source_index[src].add(iid)

            strength = -item.get_strength()
            heapq.heappush(self._strength_heap, (strength, iid))

            self._invalidate_cache()
            logger.debug("添加学习条目: %s, 总数: %d", iid, len(self._items))
            return item

    def get(self, iid: str) -> Optional[Any]:
        """按ID获取条目。

        Args:
            iid: 条目ID

        Returns:
            条目对象或None

        Raises:
            KeyError: ID不存在时抛出
        """
        with self._lock:
            if iid not in self._items:
                raise KeyError(f"不存在条目ID: {iid}")

            item = self._items[iid]
            if hasattr(item, "access"):
                item.access()
            self._reads += 1
            return item

    def search(self, query: str, limit: int = 20, category: str = "",
               tags: Optional[List[str]] = None, min_score: float = 0.0) -> List[Tuple[Any, float]]:
        """全文搜索，支持类别、标签过滤和最小分数阈值。

        Args:
            query: 搜索关键词
            limit: 最大返回数量
            category: 类别过滤
            tags: 标签过滤列表
            min_score: 最小相似度分数

        Returns:
            (条目, 分数)元组列表，按分数降序排列

        Raises:
            ValueError: 无效查询参数时抛出
        """
        from src.ximu.common.utils import score_stored_item

        with self._lock:
            cache_key = f"{query}:{category}:{tuple(tags or [])}:{min_score}:{limit}:{self._cache_version}"
            if cache_key in self._query_cache:
                self._cache_hits += 1
                self._query_cache.move_to_end(cache_key)
                return self._query_cache[cache_key]

            self._cache_misses += 1
            self._searches += 1

            q = query.lower().strip()
            cids: Set[str] = set(self._items.keys())

            if category:
                cids &= self._type_index.get(category, set())

            if tags:
                tids: Set[str] = set()
                for tag in tags:
                    tids.update(self._tag_index.get(tag.lower(), set()))
                cids &= tids

            scored: List[Tuple[float, Any]] = []
            q_words = q.split()
            for iid in cids:
                item = self._items[iid]
                s = score_stored_item(item, q, q_words)
                if s > min_score:
                    scored.append((s, item))

            scored.sort(key=lambda x: x[0], reverse=True)
            result: List[Tuple[Any, float]] = [(item, s) for s, item in scored[:limit]]

            self._query_cache[cache_key] = result
            if len(self._query_cache) > self._max_cache:
                self._query_cache.popitem(last=False)

            return result
