"""Part 1 of error_learning (lines 2-2799 of 3292)."""
from __future__ import annotations
from src.ximu.common.utils import score_stored_item, generate_id, now_timestamp
from .part1 import LearningItem
import logging
logger = logging.getLogger("src.ximu.core.learning._error_learning_parts.part1")
import os
import json
import heapq
import threading
import random
import re
from dataclasses import asdict
from typing import Any, Callable, Dict, List, Set, Tuple
from collections import OrderedDict,defaultdict,deque,Counter

"""汐沫AI - 错误学习 Error Learning System"""
try:
    from config.settings import config
except ImportError:
    config=None
class ExperienceStore:
    def __init__(self,max_items=20000):
        self._items:Dict[str,LearningItem]={}
        self._tag_index:Dict[str,Set[str]]=defaultdict(set)
        self._type_index:Dict[str,Set[str]]=defaultdict(set)
        self._source_index:Dict[str,Set[str]]=defaultdict(set)
        self._time_heap:List[Tuple[float,str]]=[]
        self._max=max_items
        self._lock=threading.RLock()
        self._added=0
        self._reads=0
        self._deleted=0
        self._updated=0
        self._searches=0
        self._cache_hits=0
        self._cache_misses=0
        self._query_cache:OrderedDict=OrderedDict()
        self._max_cache=500
    def add(self,item):
        """
        Add an item.
        @param item: Item to add.
        """
        with self._lock:
            if len(self._items)>=self._max:self._evict_weakest()
            iid=getattr(item,"item_id",getattr(item,"entry_id",getattr(item,"id",generate_id("item"))))
            self._items[iid]=item
            for tag in getattr(item,"tags",[]):self._tag_index[tag.lower()].add(iid)
            itype=getattr(item,"store_type",getattr(item,"category",getattr(item,"type","general")))
            self._type_index[itype].add(iid)
            src=getattr(item,"source","")
            if src:self._source_index[src].add(iid)
            heapq.heappush(self._time_heap,(getattr(item,"created_at",now_timestamp()),iid))
            self._added+=1
            self._invalidate_cache()
            return item
    def get(self,iid):
        """
        Retrieve a value by key.
        @return: Value or None.
        """
        with self._lock:
            item=self._items.get(iid)
            if item:
                if hasattr(item,"access"):item.access()
                self._reads+=1
            return item
    def get_or_default(self,iid,default=None):
        """
        Get value or return default.
        @param default: Default value.
        @return: Value.
        """
        item=self.get(iid)
        return item if item is not None else default
    def remove(self,iid):
        """
        Remove item by key.
        @return: True if removed.
        """
        with self._lock:
            item=self._items.pop(iid,None)
            if item:
                for tag in getattr(item,"tags",[]):self._tag_index[tag.lower()].discard(iid)
                itype=getattr(item,"store_type",getattr(item,"category",getattr(item,"type","general")))
                self._type_index[itype].discard(iid)
                src=getattr(item,"source","")
                if src:self._source_index[src].discard(iid)
                self._deleted+=1
                self._invalidate_cache()
                return True
            return False
    def update(self,iid,**kwargs):
        """Update state with data."""
        with self._lock:
            item=self._items.get(iid)
            if item:
                for k,v in kwargs.items():
                    if hasattr(item,k):setattr(item,k,v)
                if hasattr(item,"updated_at"):item.updated_at=now_timestamp()
                self._updated+=1
                self._invalidate_cache()
                return True
            return False
    def contains(self,iid):
        """
        Check if key exists.
        @return: Boolean.
        """
        with self._lock:return iid in self._items
    def search(self,query,limit=20,category="",tags=None,min_score=0.0):
        """
        Search for items.
        @param query: Search query.
        @return: List of matches.
        """
        with self._lock:
            cache_key=f"{query}:{category}:{tuple(tags or [])}:{min_score}:{limit}"
            if cache_key in self._query_cache:
                self._cache_hits+=1
                self._query_cache.move_to_end(cache_key)
                return self._query_cache[cache_key]
            self._cache_misses+=1
            self._searches+=1
            q=query.lower().strip()
            cids=set(self._items.keys())
            if category:cids&=self._type_index.get(category,set())
            if tags:
                tids=set()
                for t in tags:tids.update(self._tag_index.get(t.lower(),set()))
                cids&=tids
            scored=[]
            q_words=q.split()
            for iid in cids:
                item=self._items[iid]
                s=score_stored_item(item,q,q_words)
                if s>min_score:scored.append((s,item))
            scored.sort(key=lambda x:x[0],reverse=True)
            result=[(item,s) for s,item in scored[:limit]]
            self._query_cache[cache_key]=result
            if len(self._query_cache)>self._max_cache:self._query_cache.popitem(last=False)
            return result
    def fuzzy_search(self,query,threshold=0.6,limit=20):
        """
        Fuzzy search items.
        @param query: Query.
        @return: List of matches.
        """
        with self._lock:
            q=query.lower()
            scored=[]
            for iid,item in self._items.items():
                content=(getattr(item, "content") or "").lower()
                s=self._text_similarity(q,content)
                if s>=threshold:scored.append((s,item))
            scored.sort(key=lambda x:x[0],reverse=True)
            return [(item,s) for s,item in scored[:limit]]
    def regex_search(self,pattern,limit=20):
        """
        Regex search items.
        @param pattern: Regex pattern.
        @return: List of matches.
        """
        with self._lock:
            try:rx=re.compile(pattern,re.IGNORECASE)
            except re.error:return []
            result=[]
            for iid,item in self._items.items():
                content=(getattr(item, "content") or "")
                if rx.search(content):
                    result.append(item)
                    if len(result)>=limit:break
            return result
    def _text_similarity(self,a,b):
        if not a or not b:return 0.0
        sa,sb=set(a.split()),set(b.split())
        if not sa or not sb:return 0.0
        return len(sa&sb)/len(sa|sb)
    def get_by_type(self,ctype,limit=100):
        """
        Get by type.
        @param ctype: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._type_index.get(ctype,set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_by_tag(self,tag,limit=100):
        """
        Get by tag.
        @param tag: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._tag_index.get(tag.lower(),set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_by_source(self,src,limit=100):
        """
        Get by source.
        @param src: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._source_index.get(src,set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_time_range(self,start,end,limit=100):
        """
        Get time range.
        @param start: Input.
        @param end: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            result=[]
            for ts,iid in sorted(self._time_heap):
                if ts<start:continue
                if ts>end:break
                if iid in self._items:result.append(self._items[iid])
                if len(result)>=limit:break
            return result
    def get_recent(self,limit=50):
        """
        Get recent.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            items.sort(key=lambda x:getattr(x,"created_at",getattr(x,"timestamp",0)),reverse=True)
            return items[:limit]
    def get_oldest(self,limit=50):
        """
        Get oldest.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            items.sort(key=lambda x:getattr(x,"created_at",getattr(x,"timestamp",0)))
            return items[:limit]
    def get_all(self):
        """
        Retrieve all items.
        @return: Dict or list of items.
        """
        with self._lock:return list(self._items.values())
    def get_ids(self):
        """
        Get ids.
        @return: Value.
        """
        with self._lock:return list(self._items.keys())
    def size(self):
        """
        Get item count.
        @return: Integer.
        """
        with self._lock:return len(self._items)
    def is_empty(self):
        """
        Check if empty.
        @return: Boolean.
        """
        with self._lock:return len(self._items)==0
    def clear(self):
        """Clear all internal state."""
        with self._lock:
            self._items.clear()
            self._tag_index.clear()
            self._type_index.clear()
            self._source_index.clear()
            self._time_heap.clear()
            self._invalidate_cache()
    def _evict_weakest(self):
        if not self._items:return
        evictable=[(getattr(i,"importance",getattr(i,"weight",0.5)),iid) for iid,i in self._items.items() if not getattr(i,"permanent",False)]
        if evictable:
            evictable.sort()
            self.remove(evictable[0][1])
    def _invalidate_cache(self):
        self._query_cache.clear()
    def cleanup_expired(self):
        """Cleanup expired (ExperienceStore)."""
        with self._lock:
            expired=[iid for iid,i in self._items.items() if hasattr(i,"is_expired") and i.is_expired()]
            for iid in expired:self.remove(iid)
            return len(expired)
    def batch_add(self,items):
        """
        Batch add (ExperienceStore).
        @param items: Input.
        """
        return [self.add(item) for item in items]
    def batch_remove(self,iids):
        """
        Batch remove (ExperienceStore).
        @param iids: Input.
        """
        return sum(1 for iid in iids if self.remove(iid))
    def batch_get(self,iids):
        """
        Batch get (ExperienceStore).
        @param iids: Input.
        """
        return [self.get(iid) for iid in iids]
    def filter_by(self,predicate,limit=100):
        """
        Filter by (ExperienceStore).
        @param predicate: Input.
        @param limit: Input.
        """
        with self._lock:
            result=[]
            for iid,item in self._items.items():
                if predicate(item):
                    result.append(item)
                    if len(result)>=limit:break
            return result
    def map_items(self,func):
        """
        Map items (ExperienceStore).
        @param func: Input.
        """
        with self._lock:
            return {iid:func(item) for iid,item in self._items.items()}
    def reduce_items(self,func,initial=None):
        """
        Reduce items (ExperienceStore).
        @param func: Input.
        @param initial: Input.
        """
        with self._lock:
            result=initial
            for item in self._items.values():
                result=func(result,item) if result is not None else item
            return result
    def get_random(self,n=1):
        """
        Get random.
        @param n: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            if not items:return []
            return random.sample(items,min(n,len(items)))
    def get_stats(self):
        """
        Get current statistics snapshot.
        @return: Dict of statistics.
        """
        with self._lock:
            types=Counter(getattr(i,"store_type",getattr(i,"category",getattr(i,"type","general"))) for i in self._items.values())
            total_cache=self._cache_hits+self._cache_misses
            return {"total":len(self._items),"max":self._max,"added":self._added,
                "reads":self._reads,"deleted":self._deleted,"updated":self._updated,
                "searches":self._searches,"cache_hits":self._cache_hits,
                "cache_misses":self._cache_misses,
                "cache_hit_rate":self._cache_hits/max(1,total_cache),
                "types":dict(types),"tags":len(self._tag_index),
                "sources":len(self._source_index)}
    def to_dict(self):
        """
        Convert the object to a dictionary representation.
        @return: Dict with public attributes.
        """
        with self._lock:
            return {iid:asdict(i) if hasattr(i,"__dataclass_fields__") else str(i) for iid,i in self._items.items()}
    def export_json(self,filepath):
        """
        Export json (ExperienceStore).
        @param filepath: Input.
        """
        with open(filepath,"w",encoding="utf-8") as f:
            json.dump(self.to_dict(),f,ensure_ascii=False,default=str)
    def import_json(self,filepath):
        """
        Import json (ExperienceStore).
        @param filepath: Input.
        """
        if not os.path.exists(filepath):return 0
        # R28 根因修复：原实现 json.load 遇截断/非JSON文件直接抛 JSONDecodeError 崩溃。
        # 持久化文件损坏属运行期可恢复异常，应优雅返回0并记录日志，而非带崩进程。
        try:
            with open(filepath,"r",encoding="utf-8") as f:
                data=json.load(f)
        except (json.JSONDecodeError, OSError, ValueError) as e:
            logger.warning("import_json 读取失败 %s: %s", filepath, e)
            return 0
        count=0
        for iid,item_data in data.items():
            if isinstance(item_data,dict):
                item_data.setdefault("item_id",iid)
                count+=1
        return count

class LessonStore:
    def __init__(self,max_items=10000):
        self._items:Dict[str,LearningItem]={}
        self._tag_index:Dict[str,Set[str]]=defaultdict(set)
        self._type_index:Dict[str,Set[str]]=defaultdict(set)
        self._source_index:Dict[str,Set[str]]=defaultdict(set)
        self._time_heap:List[Tuple[float,str]]=[]
        self._max=max_items
        self._lock=threading.RLock()
        self._added=0
        self._reads=0
        self._deleted=0
        self._updated=0
        self._searches=0
        self._cache_hits=0
        self._cache_misses=0
        self._query_cache:OrderedDict=OrderedDict()
        self._max_cache=500
    def add(self,item):
        """
        Add an item.
        @param item: Item to add.
        """
        with self._lock:
            if len(self._items)>=self._max:self._evict_weakest()
            iid=getattr(item,"item_id",getattr(item,"entry_id",getattr(item,"id",generate_id("item"))))
            self._items[iid]=item
            for tag in getattr(item,"tags",[]):self._tag_index[tag.lower()].add(iid)
            itype=getattr(item,"store_type",getattr(item,"category",getattr(item,"type","general")))
            self._type_index[itype].add(iid)
            src=getattr(item,"source","")
            if src:self._source_index[src].add(iid)
            heapq.heappush(self._time_heap,(getattr(item,"created_at",now_timestamp()),iid))
            self._added+=1
            self._invalidate_cache()
            return item
    def get(self,iid):
        """
        Retrieve a value by key.
        @return: Value or None.
        """
        with self._lock:
            item=self._items.get(iid)
            if item:
                if hasattr(item,"access"):item.access()
                self._reads+=1
            return item
    def get_or_default(self,iid,default=None):
        """
        Get value or return default.
        @param default: Default value.
        @return: Value.
        """
        item=self.get(iid)
        return item if item is not None else default
    def remove(self,iid):
        """
        Remove item by key.
        @return: True if removed.
        """
        with self._lock:
            item=self._items.pop(iid,None)
            if item:
                for tag in getattr(item,"tags",[]):self._tag_index[tag.lower()].discard(iid)
                itype=getattr(item,"store_type",getattr(item,"category",getattr(item,"type","general")))
                self._type_index[itype].discard(iid)
                src=getattr(item,"source","")
                if src:self._source_index[src].discard(iid)
                self._deleted+=1
                self._invalidate_cache()
                return True
            return False
    def update(self,iid,**kwargs):
        """Update state with data."""
        with self._lock:
            item=self._items.get(iid)
            if item:
                for k,v in kwargs.items():
                    if hasattr(item,k):setattr(item,k,v)
                if hasattr(item,"updated_at"):item.updated_at=now_timestamp()
                self._updated+=1
                self._invalidate_cache()
                return True
            return False
    def contains(self,iid):
        """
        Check if key exists.
        @return: Boolean.
        """
        with self._lock:return iid in self._items
    def search(self,query,limit=20,category="",tags=None,min_score=0.0):
        """
        Search for items.
        @param query: Search query.
        @return: List of matches.
        """
        with self._lock:
            cache_key=f"{query}:{category}:{tuple(tags or [])}:{min_score}:{limit}"
            if cache_key in self._query_cache:
                self._cache_hits+=1
                self._query_cache.move_to_end(cache_key)
                return self._query_cache[cache_key]
            self._cache_misses+=1
            self._searches+=1
            q=query.lower().strip()
            cids=set(self._items.keys())
            if category:cids&=self._type_index.get(category,set())
            if tags:
                tids=set()
                for t in tags:tids.update(self._tag_index.get(t.lower(),set()))
                cids&=tids
            scored=[]
            q_words=q.split()
            for iid in cids:
                item=self._items[iid]
                s=score_stored_item(item,q,q_words)
                if s>min_score:scored.append((s,item))
            scored.sort(key=lambda x:x[0],reverse=True)
            result=[(item,s) for s,item in scored[:limit]]
            self._query_cache[cache_key]=result
            if len(self._query_cache)>self._max_cache:self._query_cache.popitem(last=False)
            return result
    def fuzzy_search(self,query,threshold=0.6,limit=20):
        """
        Fuzzy search items.
        @param query: Query.
        @return: List of matches.
        """
        with self._lock:
            q=query.lower()
            scored=[]
            for iid,item in self._items.items():
                content=(getattr(item, "content") or "").lower()
                s=self._text_similarity(q,content)
                if s>=threshold:scored.append((s,item))
            scored.sort(key=lambda x:x[0],reverse=True)
            return [(item,s) for s,item in scored[:limit]]
    def regex_search(self,pattern,limit=20):
        """
        Regex search items.
        @param pattern: Regex pattern.
        @return: List of matches.
        """
        with self._lock:
            try:rx=re.compile(pattern,re.IGNORECASE)
            except re.error:return []
            result=[]
            for iid,item in self._items.items():
                content=(getattr(item, "content") or "")
                if rx.search(content):
                    result.append(item)
                    if len(result)>=limit:break
            return result
    def _text_similarity(self,a,b):
        if not a or not b:return 0.0
        sa,sb=set(a.split()),set(b.split())
        if not sa or not sb:return 0.0
        return len(sa&sb)/len(sa|sb)
    def get_by_type(self,ctype,limit=100):
        """
        Get by type.
        @param ctype: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._type_index.get(ctype,set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_by_tag(self,tag,limit=100):
        """
        Get by tag.
        @param tag: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._tag_index.get(tag.lower(),set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_by_source(self,src,limit=100):
        """
        Get by source.
        @param src: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._source_index.get(src,set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_time_range(self,start,end,limit=100):
        """
        Get time range.
        @param start: Input.
        @param end: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            result=[]
            for ts,iid in sorted(self._time_heap):
                if ts<start:continue
                if ts>end:break
                if iid in self._items:result.append(self._items[iid])
                if len(result)>=limit:break
            return result
    def get_recent(self,limit=50):
        """
        Get recent.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            items.sort(key=lambda x:getattr(x,"created_at",getattr(x,"timestamp",0)),reverse=True)
            return items[:limit]
    def get_oldest(self,limit=50):
        """
        Get oldest.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            items.sort(key=lambda x:getattr(x,"created_at",getattr(x,"timestamp",0)))
            return items[:limit]
    def get_all(self):
        """
        Retrieve all items.
        @return: Dict or list of items.
        """
        with self._lock:return list(self._items.values())
    def get_ids(self):
        """
        Get ids.
        @return: Value.
        """
        with self._lock:return list(self._items.keys())
    def size(self):
        """
        Get item count.
        @return: Integer.
        """
        with self._lock:return len(self._items)
    def is_empty(self):
        """
        Check if empty.
        @return: Boolean.
        """
        with self._lock:return len(self._items)==0
    def clear(self):
        """Clear all internal state."""
        with self._lock:
            self._items.clear()
            self._tag_index.clear()
            self._type_index.clear()
            self._source_index.clear()
            self._time_heap.clear()
            self._invalidate_cache()
    def _evict_weakest(self):
        if not self._items:return
        evictable=[(getattr(i,"importance",getattr(i,"weight",0.5)),iid) for iid,i in self._items.items() if not getattr(i,"permanent",False)]
        if evictable:
            evictable.sort()
            self.remove(evictable[0][1])
    def _invalidate_cache(self):
        self._query_cache.clear()
    def cleanup_expired(self):
        """Cleanup expired (LessonStore)."""
        with self._lock:
            expired=[iid for iid,i in self._items.items() if hasattr(i,"is_expired") and i.is_expired()]
            for iid in expired:self.remove(iid)
            return len(expired)
    def batch_add(self,items):
        """
        Batch add (LessonStore).
        @param items: Input.
        """
        return [self.add(item) for item in items]
    def batch_remove(self,iids):
        """
        Batch remove (LessonStore).
        @param iids: Input.
        """
        return sum(1 for iid in iids if self.remove(iid))
    def batch_get(self,iids):
        """
        Batch get (LessonStore).
        @param iids: Input.
        """
        return [self.get(iid) for iid in iids]
    def filter_by(self,predicate,limit=100):
        """
        Filter by (LessonStore).
        @param predicate: Input.
        @param limit: Input.
        """
        with self._lock:
            result=[]
            for iid,item in self._items.items():
                if predicate(item):
                    result.append(item)
                    if len(result)>=limit:break
            return result
    def map_items(self,func):
        """
        Map items (LessonStore).
        @param func: Input.
        """
        with self._lock:
            return {iid:func(item) for iid,item in self._items.items()}
    def reduce_items(self,func,initial=None):
        """
        Reduce items (LessonStore).
        @param func: Input.
        @param initial: Input.
        """
        with self._lock:
            result=initial
            for item in self._items.values():
                result=func(result,item) if result is not None else item
            return result
    def get_random(self,n=1):
        """
        Get random.
        @param n: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            if not items:return []
            return random.sample(items,min(n,len(items)))
    def get_stats(self):
        """
        Get current statistics snapshot.
        @return: Dict of statistics.
        """
        with self._lock:
            types=Counter(getattr(i,"store_type",getattr(i,"category",getattr(i,"type","general"))) for i in self._items.values())
            total_cache=self._cache_hits+self._cache_misses
            return {"total":len(self._items),"max":self._max,"added":self._added,
                "reads":self._reads,"deleted":self._deleted,"updated":self._updated,
                "searches":self._searches,"cache_hits":self._cache_hits,
                "cache_misses":self._cache_misses,
                "cache_hit_rate":self._cache_hits/max(1,total_cache),
                "types":dict(types),"tags":len(self._tag_index),
                "sources":len(self._source_index)}
    def to_dict(self):
        """
        Convert the object to a dictionary representation.
        @return: Dict with public attributes.
        """
        with self._lock:
            return {iid:asdict(i) if hasattr(i,"__dataclass_fields__") else str(i) for iid,i in self._items.items()}
    def export_json(self,filepath):
        """
        Export json (LessonStore).
        @param filepath: Input.
        """
        with open(filepath,"w",encoding="utf-8") as f:
            json.dump(self.to_dict(),f,ensure_ascii=False,default=str)
    def import_json(self,filepath):
        """
        Import json (LessonStore).
        @param filepath: Input.
        """
        if not os.path.exists(filepath):return 0
        # R28 根因修复：原实现 json.load 遇截断/非JSON文件直接抛 JSONDecodeError 崩溃。
        # 持久化文件损坏属运行期可恢复异常，应优雅返回0并记录日志，而非带崩进程。
        try:
            with open(filepath,"r",encoding="utf-8") as f:
                data=json.load(f)
        except (json.JSONDecodeError, OSError, ValueError) as e:
            logger.warning("import_json 读取失败 %s: %s", filepath, e)
            return 0
        count=0
        for iid,item_data in data.items():
            if isinstance(item_data,dict):
                item_data.setdefault("item_id",iid)
                count+=1
        return count

class KnowledgeStore:
    def __init__(self,max_items=15000):
        self._items:Dict[str,LearningItem]={}
        self._tag_index:Dict[str,Set[str]]=defaultdict(set)
        self._type_index:Dict[str,Set[str]]=defaultdict(set)
        self._source_index:Dict[str,Set[str]]=defaultdict(set)
        self._time_heap:List[Tuple[float,str]]=[]
        self._max=max_items
        self._lock=threading.RLock()
        self._added=0
        self._reads=0
        self._deleted=0
        self._updated=0
        self._searches=0
        self._cache_hits=0
        self._cache_misses=0
        self._query_cache:OrderedDict=OrderedDict()
        self._max_cache=500
    def add(self,item):
        """
        Add an item.
        @param item: Item to add.
        """
        with self._lock:
            if len(self._items)>=self._max:self._evict_weakest()
            iid=getattr(item,"item_id",getattr(item,"entry_id",getattr(item,"id",generate_id("item"))))
            self._items[iid]=item
            for tag in getattr(item,"tags",[]):self._tag_index[tag.lower()].add(iid)
            itype=getattr(item,"store_type",getattr(item,"category",getattr(item,"type","general")))
            self._type_index[itype].add(iid)
            src=getattr(item,"source","")
            if src:self._source_index[src].add(iid)
            heapq.heappush(self._time_heap,(getattr(item,"created_at",now_timestamp()),iid))
            self._added+=1
            self._invalidate_cache()
            return item
    def get(self,iid):
        """
        Retrieve a value by key.
        @return: Value or None.
        """
        with self._lock:
            item=self._items.get(iid)
            if item:
                if hasattr(item,"access"):item.access()
                self._reads+=1
            return item
    def get_or_default(self,iid,default=None):
        """
        Get value or return default.
        @param default: Default value.
        @return: Value.
        """
        item=self.get(iid)
        return item if item is not None else default
    def remove(self,iid):
        """
        Remove item by key.
        @return: True if removed.
        """
        with self._lock:
            item=self._items.pop(iid,None)
            if item:
                for tag in getattr(item,"tags",[]):self._tag_index[tag.lower()].discard(iid)
                itype=getattr(item,"store_type",getattr(item,"category",getattr(item,"type","general")))
                self._type_index[itype].discard(iid)
                src=getattr(item,"source","")
                if src:self._source_index[src].discard(iid)
                self._deleted+=1
                self._invalidate_cache()
                return True
            return False
    def update(self,iid,**kwargs):
        """Update state with data."""
        with self._lock:
            item=self._items.get(iid)
            if item:
                for k,v in kwargs.items():
                    if hasattr(item,k):setattr(item,k,v)
                if hasattr(item,"updated_at"):item.updated_at=now_timestamp()
                self._updated+=1
                self._invalidate_cache()
                return True
            return False
    def contains(self,iid):
        """
        Check if key exists.
        @return: Boolean.
        """
        with self._lock:return iid in self._items
    def search(self,query,limit=20,category="",tags=None,min_score=0.0):
        """
        Search for items.
        @param query: Search query.
        @return: List of matches.
        """
        with self._lock:
            cache_key=f"{query}:{category}:{tuple(tags or [])}:{min_score}:{limit}"
            if cache_key in self._query_cache:
                self._cache_hits+=1
                self._query_cache.move_to_end(cache_key)
                return self._query_cache[cache_key]
            self._cache_misses+=1
            self._searches+=1
            q=query.lower().strip()
            cids=set(self._items.keys())
            if category:cids&=self._type_index.get(category,set())
            if tags:
                tids=set()
                for t in tags:tids.update(self._tag_index.get(t.lower(),set()))
                cids&=tids
            scored=[]
            q_words=q.split()
            for iid in cids:
                item=self._items[iid]
                s=score_stored_item(item,q,q_words)
                if s>min_score:scored.append((s,item))
            scored.sort(key=lambda x:x[0],reverse=True)
            result=[(item,s) for s,item in scored[:limit]]
            self._query_cache[cache_key]=result
            if len(self._query_cache)>self._max_cache:self._query_cache.popitem(last=False)
            return result
    def fuzzy_search(self,query,threshold=0.6,limit=20):
        """
        Fuzzy search items.
        @param query: Query.
        @return: List of matches.
        """
        with self._lock:
            q=query.lower()
            scored=[]
            for iid,item in self._items.items():
                content=(getattr(item, "content") or "").lower()
                s=self._text_similarity(q,content)
                if s>=threshold:scored.append((s,item))
            scored.sort(key=lambda x:x[0],reverse=True)
            return [(item,s) for s,item in scored[:limit]]
    def regex_search(self,pattern,limit=20):
        """
        Regex search items.
        @param pattern: Regex pattern.
        @return: List of matches.
        """
        with self._lock:
            try:rx=re.compile(pattern,re.IGNORECASE)
            except re.error:return []
            result=[]
            for iid,item in self._items.items():
                content=(getattr(item, "content") or "")
                if rx.search(content):
                    result.append(item)
                    if len(result)>=limit:break
            return result
    def _text_similarity(self,a,b):
        if not a or not b:return 0.0
        sa,sb=set(a.split()),set(b.split())
        if not sa or not sb:return 0.0
        return len(sa&sb)/len(sa|sb)
    def get_by_type(self,ctype,limit=100):
        """
        Get by type.
        @param ctype: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._type_index.get(ctype,set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_by_tag(self,tag,limit=100):
        """
        Get by tag.
        @param tag: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._tag_index.get(tag.lower(),set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_by_source(self,src,limit=100):
        """
        Get by source.
        @param src: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._source_index.get(src,set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_time_range(self,start,end,limit=100):
        """
        Get time range.
        @param start: Input.
        @param end: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            result=[]
            for ts,iid in sorted(self._time_heap):
                if ts<start:continue
                if ts>end:break
                if iid in self._items:result.append(self._items[iid])
                if len(result)>=limit:break
            return result
    def get_recent(self,limit=50):
        """
        Get recent.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            items.sort(key=lambda x:getattr(x,"created_at",getattr(x,"timestamp",0)),reverse=True)
            return items[:limit]
    def get_oldest(self,limit=50):
        """
        Get oldest.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            items.sort(key=lambda x:getattr(x,"created_at",getattr(x,"timestamp",0)))
            return items[:limit]
    def get_all(self):
        """
        Retrieve all items.
        @return: Dict or list of items.
        """
        with self._lock:return list(self._items.values())
    def get_ids(self):
        """
        Get ids.
        @return: Value.
        """
        with self._lock:return list(self._items.keys())
    def size(self):
        """
        Get item count.
        @return: Integer.
        """
        with self._lock:return len(self._items)
    def is_empty(self):
        """
        Check if empty.
        @return: Boolean.
        """
        with self._lock:return len(self._items)==0
    def clear(self):
        """Clear all internal state."""
        with self._lock:
            self._items.clear()
            self._tag_index.clear()
            self._type_index.clear()
            self._source_index.clear()
            self._time_heap.clear()
            self._invalidate_cache()
    def _evict_weakest(self):
        if not self._items:return
        evictable=[(getattr(i,"importance",getattr(i,"weight",0.5)),iid) for iid,i in self._items.items() if not getattr(i,"permanent",False)]
        if evictable:
            evictable.sort()
            self.remove(evictable[0][1])
    def _invalidate_cache(self):
        self._query_cache.clear()
    def cleanup_expired(self):
        """Cleanup expired (KnowledgeStore)."""
        with self._lock:
            expired=[iid for iid,i in self._items.items() if hasattr(i,"is_expired") and i.is_expired()]
            for iid in expired:self.remove(iid)
            return len(expired)
    def batch_add(self,items):
        """
        Batch add (KnowledgeStore).
        @param items: Input.
        """
        return [self.add(item) for item in items]
    def batch_remove(self,iids):
        """
        Batch remove (KnowledgeStore).
        @param iids: Input.
        """
        return sum(1 for iid in iids if self.remove(iid))
    def batch_get(self,iids):
        """
        Batch get (KnowledgeStore).
        @param iids: Input.
        """
        return [self.get(iid) for iid in iids]
    def filter_by(self,predicate,limit=100):
        """
        Filter by (KnowledgeStore).
        @param predicate: Input.
        @param limit: Input.
        """
        with self._lock:
            result=[]
            for iid,item in self._items.items():
                if predicate(item):
                    result.append(item)
                    if len(result)>=limit:break
            return result
    def map_items(self,func):
        """
        Map items (KnowledgeStore).
        @param func: Input.
        """
        with self._lock:
            return {iid:func(item) for iid,item in self._items.items()}
    def reduce_items(self,func,initial=None):
        """
        Reduce items (KnowledgeStore).
        @param func: Input.
        @param initial: Input.
        """
        with self._lock:
            result=initial
            for item in self._items.values():
                result=func(result,item) if result is not None else item
            return result
    def get_random(self,n=1):
        """
        Get random.
        @param n: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            if not items:return []
            return random.sample(items,min(n,len(items)))
    def get_stats(self):
        """
        Get current statistics snapshot.
        @return: Dict of statistics.
        """
        with self._lock:
            types=Counter(getattr(i,"store_type",getattr(i,"category",getattr(i,"type","general"))) for i in self._items.values())
            total_cache=self._cache_hits+self._cache_misses
            return {"total":len(self._items),"max":self._max,"added":self._added,
                "reads":self._reads,"deleted":self._deleted,"updated":self._updated,
                "searches":self._searches,"cache_hits":self._cache_hits,
                "cache_misses":self._cache_misses,
                "cache_hit_rate":self._cache_hits/max(1,total_cache),
                "types":dict(types),"tags":len(self._tag_index),
                "sources":len(self._source_index)}
    def to_dict(self):
        """
        Convert the object to a dictionary representation.
        @return: Dict with public attributes.
        """
        with self._lock:
            return {iid:asdict(i) if hasattr(i,"__dataclass_fields__") else str(i) for iid,i in self._items.items()}
    def export_json(self,filepath):
        """
        Export json (KnowledgeStore).
        @param filepath: Input.
        """
        with open(filepath,"w",encoding="utf-8") as f:
            json.dump(self.to_dict(),f,ensure_ascii=False,default=str)
    def import_json(self,filepath):
        """
        Import json (KnowledgeStore).
        @param filepath: Input.
        """
        if not os.path.exists(filepath):return 0
        # R28 根因修复：原实现 json.load 遇截断/非JSON文件直接抛 JSONDecodeError 崩溃。
        # 持久化文件损坏属运行期可恢复异常，应优雅返回0并记录日志，而非带崩进程。
        try:
            with open(filepath,"r",encoding="utf-8") as f:
                data=json.load(f)
        except (json.JSONDecodeError, OSError, ValueError) as e:
            logger.warning("import_json 读取失败 %s: %s", filepath, e)
            return 0
        count=0
        for iid,item_data in data.items():
            if isinstance(item_data,dict):
                item_data.setdefault("item_id",iid)
                count+=1
        return count

class FeedbackStore:
    def __init__(self,max_items=10000):
        self._items:Dict[str,LearningItem]={}
        self._tag_index:Dict[str,Set[str]]=defaultdict(set)
        self._type_index:Dict[str,Set[str]]=defaultdict(set)
        self._source_index:Dict[str,Set[str]]=defaultdict(set)
        self._time_heap:List[Tuple[float,str]]=[]
        self._max=max_items
        self._lock=threading.RLock()
        self._added=0
        self._reads=0
        self._deleted=0
        self._updated=0
        self._searches=0
        self._cache_hits=0
        self._cache_misses=0
        self._query_cache:OrderedDict=OrderedDict()
        self._max_cache=500
    def add(self,item):
        """
        Add an item.
        @param item: Item to add.
        """
        with self._lock:
            if len(self._items)>=self._max:self._evict_weakest()
            iid=getattr(item,"item_id",getattr(item,"entry_id",getattr(item,"id",generate_id("item"))))
            self._items[iid]=item
            for tag in getattr(item,"tags",[]):self._tag_index[tag.lower()].add(iid)
            itype=getattr(item,"store_type",getattr(item,"category",getattr(item,"type","general")))
            self._type_index[itype].add(iid)
            src=getattr(item,"source","")
            if src:self._source_index[src].add(iid)
            heapq.heappush(self._time_heap,(getattr(item,"created_at",now_timestamp()),iid))
            self._added+=1
            self._invalidate_cache()
            return item
    def get(self,iid):
        """
        Retrieve a value by key.
        @return: Value or None.
        """
        with self._lock:
            item=self._items.get(iid)
            if item:
                if hasattr(item,"access"):item.access()
                self._reads+=1
            return item
    def get_or_default(self,iid,default=None):
        """
        Get value or return default.
        @param default: Default value.
        @return: Value.
        """
        item=self.get(iid)
        return item if item is not None else default
    def remove(self,iid):
        """
        Remove item by key.
        @return: True if removed.
        """
        with self._lock:
            item=self._items.pop(iid,None)
            if item:
                for tag in getattr(item,"tags",[]):self._tag_index[tag.lower()].discard(iid)
                itype=getattr(item,"store_type",getattr(item,"category",getattr(item,"type","general")))
                self._type_index[itype].discard(iid)
                src=getattr(item,"source","")
                if src:self._source_index[src].discard(iid)
                self._deleted+=1
                self._invalidate_cache()
                return True
            return False
    def update(self,iid,**kwargs):
        """Update state with data."""
        with self._lock:
            item=self._items.get(iid)
            if item:
                for k,v in kwargs.items():
                    if hasattr(item,k):setattr(item,k,v)
                if hasattr(item,"updated_at"):item.updated_at=now_timestamp()
                self._updated+=1
                self._invalidate_cache()
                return True
            return False
    def contains(self,iid):
        """
        Check if key exists.
        @return: Boolean.
        """
        with self._lock:return iid in self._items
    def search(self,query,limit=20,category="",tags=None,min_score=0.0):
        """
        Search for items.
        @param query: Search query.
        @return: List of matches.
        """
        with self._lock:
            cache_key=f"{query}:{category}:{tuple(tags or [])}:{min_score}:{limit}"
            if cache_key in self._query_cache:
                self._cache_hits+=1
                self._query_cache.move_to_end(cache_key)
                return self._query_cache[cache_key]
            self._cache_misses+=1
            self._searches+=1
            q=query.lower().strip()
            cids=set(self._items.keys())
            if category:cids&=self._type_index.get(category,set())
            if tags:
                tids=set()
                for t in tags:tids.update(self._tag_index.get(t.lower(),set()))
                cids&=tids
            scored=[]
            q_words=q.split()
            for iid in cids:
                item=self._items[iid]
                s=score_stored_item(item,q,q_words)
                if s>min_score:scored.append((s,item))
            scored.sort(key=lambda x:x[0],reverse=True)
            result=[(item,s) for s,item in scored[:limit]]
            self._query_cache[cache_key]=result
            if len(self._query_cache)>self._max_cache:self._query_cache.popitem(last=False)
            return result
    def fuzzy_search(self,query,threshold=0.6,limit=20):
        """
        Fuzzy search items.
        @param query: Query.
        @return: List of matches.
        """
        with self._lock:
            q=query.lower()
            scored=[]
            for iid,item in self._items.items():
                content=(getattr(item, "content") or "").lower()
                s=self._text_similarity(q,content)
                if s>=threshold:scored.append((s,item))
            scored.sort(key=lambda x:x[0],reverse=True)
            return [(item,s) for s,item in scored[:limit]]
    def regex_search(self,pattern,limit=20):
        """
        Regex search items.
        @param pattern: Regex pattern.
        @return: List of matches.
        """
        with self._lock:
            try:rx=re.compile(pattern,re.IGNORECASE)
            except re.error:return []
            result=[]
            for iid,item in self._items.items():
                content=(getattr(item, "content") or "")
                if rx.search(content):
                    result.append(item)
                    if len(result)>=limit:break
            return result
    def _text_similarity(self,a,b):
        if not a or not b:return 0.0
        sa,sb=set(a.split()),set(b.split())
        if not sa or not sb:return 0.0
        return len(sa&sb)/len(sa|sb)
    def get_by_type(self,ctype,limit=100):
        """
        Get by type.
        @param ctype: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._type_index.get(ctype,set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_by_tag(self,tag,limit=100):
        """
        Get by tag.
        @param tag: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._tag_index.get(tag.lower(),set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_by_source(self,src,limit=100):
        """
        Get by source.
        @param src: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._source_index.get(src,set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_time_range(self,start,end,limit=100):
        """
        Get time range.
        @param start: Input.
        @param end: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            result=[]
            for ts,iid in sorted(self._time_heap):
                if ts<start:continue
                if ts>end:break
                if iid in self._items:result.append(self._items[iid])
                if len(result)>=limit:break
            return result
    def get_recent(self,limit=50):
        """
        Get recent.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            items.sort(key=lambda x:getattr(x,"created_at",getattr(x,"timestamp",0)),reverse=True)
            return items[:limit]
    def get_oldest(self,limit=50):
        """
        Get oldest.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            items.sort(key=lambda x:getattr(x,"created_at",getattr(x,"timestamp",0)))
            return items[:limit]
    def get_all(self):
        """
        Retrieve all items.
        @return: Dict or list of items.
        """
        with self._lock:return list(self._items.values())
    def get_ids(self):
        """
        Get ids.
        @return: Value.
        """
        with self._lock:return list(self._items.keys())
    def size(self):
        """
        Get item count.
        @return: Integer.
        """
        with self._lock:return len(self._items)
    def is_empty(self):
        """
        Check if empty.
        @return: Boolean.
        """
        with self._lock:return len(self._items)==0
    def clear(self):
        """Clear all internal state."""
        with self._lock:
            self._items.clear()
            self._tag_index.clear()
            self._type_index.clear()
            self._source_index.clear()
            self._time_heap.clear()
            self._invalidate_cache()
    def _evict_weakest(self):
        if not self._items:return
        evictable=[(getattr(i,"importance",getattr(i,"weight",0.5)),iid) for iid,i in self._items.items() if not getattr(i,"permanent",False)]
        if evictable:
            evictable.sort()
            self.remove(evictable[0][1])
    def _invalidate_cache(self):
        self._query_cache.clear()
    def cleanup_expired(self):
        """Cleanup expired (FeedbackStore)."""
        with self._lock:
            expired=[iid for iid,i in self._items.items() if hasattr(i,"is_expired") and i.is_expired()]
            for iid in expired:self.remove(iid)
            return len(expired)
    def batch_add(self,items):
        """
        Batch add (FeedbackStore).
        @param items: Input.
        """
        return [self.add(item) for item in items]
    def batch_remove(self,iids):
        """
        Batch remove (FeedbackStore).
        @param iids: Input.
        """
        return sum(1 for iid in iids if self.remove(iid))
    def batch_get(self,iids):
        """
        Batch get (FeedbackStore).
        @param iids: Input.
        """
        return [self.get(iid) for iid in iids]
    def filter_by(self,predicate,limit=100):
        """
        Filter by (FeedbackStore).
        @param predicate: Input.
        @param limit: Input.
        """
        with self._lock:
            result=[]
            for iid,item in self._items.items():
                if predicate(item):
                    result.append(item)
                    if len(result)>=limit:break
            return result
    def map_items(self,func):
        """
        Map items (FeedbackStore).
        @param func: Input.
        """
        with self._lock:
            return {iid:func(item) for iid,item in self._items.items()}
    def reduce_items(self,func,initial=None):
        """
        Reduce items (FeedbackStore).
        @param func: Input.
        @param initial: Input.
        """
        with self._lock:
            result=initial
            for item in self._items.values():
                result=func(result,item) if result is not None else item
            return result
    def get_random(self,n=1):
        """
        Get random.
        @param n: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            if not items:return []
            return random.sample(items,min(n,len(items)))
    def get_stats(self):
        """
        Get current statistics snapshot.
        @return: Dict of statistics.
        """
        with self._lock:
            types=Counter(getattr(i,"store_type",getattr(i,"category",getattr(i,"type","general"))) for i in self._items.values())
            total_cache=self._cache_hits+self._cache_misses
            return {"total":len(self._items),"max":self._max,"added":self._added,
                "reads":self._reads,"deleted":self._deleted,"updated":self._updated,
                "searches":self._searches,"cache_hits":self._cache_hits,
                "cache_misses":self._cache_misses,
                "cache_hit_rate":self._cache_hits/max(1,total_cache),
                "types":dict(types),"tags":len(self._tag_index),
                "sources":len(self._source_index)}
    def to_dict(self):
        """
        Convert the object to a dictionary representation.
        @return: Dict with public attributes.
        """
        with self._lock:
            return {iid:asdict(i) if hasattr(i,"__dataclass_fields__") else str(i) for iid,i in self._items.items()}
    def export_json(self,filepath):
        """
        Export json (FeedbackStore).
        @param filepath: Input.
        """
        with open(filepath,"w",encoding="utf-8") as f:
            json.dump(self.to_dict(),f,ensure_ascii=False,default=str)
    def import_json(self,filepath):
        """
        Import json (FeedbackStore).
        @param filepath: Input.
        """
        if not os.path.exists(filepath):return 0
        # R28 根因修复：原实现 json.load 遇截断/非JSON文件直接抛 JSONDecodeError 崩溃。
        # 持久化文件损坏属运行期可恢复异常，应优雅返回0并记录日志，而非带崩进程。
        try:
            with open(filepath,"r",encoding="utf-8") as f:
                data=json.load(f)
        except (json.JSONDecodeError, OSError, ValueError) as e:
            logger.warning("import_json 读取失败 %s: %s", filepath, e)
            return 0
        count=0
        for iid,item_data in data.items():
            if isinstance(item_data,dict):
                item_data.setdefault("item_id",iid)
                count+=1
        return count

class AuditStore:
    def __init__(self,max_items=10000):
        self._items:Dict[str,LearningItem]={}
        self._tag_index:Dict[str,Set[str]]=defaultdict(set)
        self._type_index:Dict[str,Set[str]]=defaultdict(set)
        self._source_index:Dict[str,Set[str]]=defaultdict(set)
        self._time_heap:List[Tuple[float,str]]=[]
        self._max=max_items
        self._lock=threading.RLock()
        self._added=0
        self._reads=0
        self._deleted=0
        self._updated=0
        self._searches=0
        self._cache_hits=0
        self._cache_misses=0
        self._query_cache:OrderedDict=OrderedDict()
        self._max_cache=500
    def add(self,item):
        """
        Add an item.
        @param item: Item to add.
        """
        with self._lock:
            if len(self._items)>=self._max:self._evict_weakest()
            iid=getattr(item,"item_id",getattr(item,"entry_id",getattr(item,"id",generate_id("item"))))
            self._items[iid]=item
            for tag in getattr(item,"tags",[]):self._tag_index[tag.lower()].add(iid)
            itype=getattr(item,"store_type",getattr(item,"category",getattr(item,"type","general")))
            self._type_index[itype].add(iid)
            src=getattr(item,"source","")
            if src:self._source_index[src].add(iid)
            heapq.heappush(self._time_heap,(getattr(item,"created_at",now_timestamp()),iid))
            self._added+=1
            self._invalidate_cache()
            return item
    def get(self,iid):
        """
        Retrieve a value by key.
        @return: Value or None.
        """
        with self._lock:
            item=self._items.get(iid)
            if item:
                if hasattr(item,"access"):item.access()
                self._reads+=1
            return item
    def get_or_default(self,iid,default=None):
        """
        Get value or return default.
        @param default: Default value.
        @return: Value.
        """
        item=self.get(iid)
        return item if item is not None else default
    def remove(self,iid):
        """
        Remove item by key.
        @return: True if removed.
        """
        with self._lock:
            item=self._items.pop(iid,None)
            if item:
                for tag in getattr(item,"tags",[]):self._tag_index[tag.lower()].discard(iid)
                itype=getattr(item,"store_type",getattr(item,"category",getattr(item,"type","general")))
                self._type_index[itype].discard(iid)
                src=getattr(item,"source","")
                if src:self._source_index[src].discard(iid)
                self._deleted+=1
                self._invalidate_cache()
                return True
            return False
    def update(self,iid,**kwargs):
        """Update state with data."""
        with self._lock:
            item=self._items.get(iid)
            if item:
                for k,v in kwargs.items():
                    if hasattr(item,k):setattr(item,k,v)
                if hasattr(item,"updated_at"):item.updated_at=now_timestamp()
                self._updated+=1
                self._invalidate_cache()
                return True
            return False
    def contains(self,iid):
        """
        Check if key exists.
        @return: Boolean.
        """
        with self._lock:return iid in self._items
    def search(self,query,limit=20,category="",tags=None,min_score=0.0):
        """
        Search for items.
        @param query: Search query.
        @return: List of matches.
        """
        with self._lock:
            cache_key=f"{query}:{category}:{tuple(tags or [])}:{min_score}:{limit}"
            if cache_key in self._query_cache:
                self._cache_hits+=1
                self._query_cache.move_to_end(cache_key)
                return self._query_cache[cache_key]
            self._cache_misses+=1
            self._searches+=1
            q=query.lower().strip()
            cids=set(self._items.keys())
            if category:cids&=self._type_index.get(category,set())
            if tags:
                tids=set()
                for t in tags:tids.update(self._tag_index.get(t.lower(),set()))
                cids&=tids
            scored=[]
            q_words=q.split()
            for iid in cids:
                item=self._items[iid]
                s=score_stored_item(item,q,q_words)
                if s>min_score:scored.append((s,item))
            scored.sort(key=lambda x:x[0],reverse=True)
            result=[(item,s) for s,item in scored[:limit]]
            self._query_cache[cache_key]=result
            if len(self._query_cache)>self._max_cache:self._query_cache.popitem(last=False)
            return result
    def fuzzy_search(self,query,threshold=0.6,limit=20):
        """
        Fuzzy search items.
        @param query: Query.
        @return: List of matches.
        """
        with self._lock:
            q=query.lower()
            scored=[]
            for iid,item in self._items.items():
                content=(getattr(item, "content") or "").lower()
                s=self._text_similarity(q,content)
                if s>=threshold:scored.append((s,item))
            scored.sort(key=lambda x:x[0],reverse=True)
            return [(item,s) for s,item in scored[:limit]]
    def regex_search(self,pattern,limit=20):
        """
        Regex search items.
        @param pattern: Regex pattern.
        @return: List of matches.
        """
        with self._lock:
            try:rx=re.compile(pattern,re.IGNORECASE)
            except re.error:return []
            result=[]
            for iid,item in self._items.items():
                content=(getattr(item, "content") or "")
                if rx.search(content):
                    result.append(item)
                    if len(result)>=limit:break
            return result
    def _text_similarity(self,a,b):
        if not a or not b:return 0.0
        sa,sb=set(a.split()),set(b.split())
        if not sa or not sb:return 0.0
        return len(sa&sb)/len(sa|sb)
    def get_by_type(self,ctype,limit=100):
        """
        Get by type.
        @param ctype: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._type_index.get(ctype,set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_by_tag(self,tag,limit=100):
        """
        Get by tag.
        @param tag: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._tag_index.get(tag.lower(),set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_by_source(self,src,limit=100):
        """
        Get by source.
        @param src: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            ids=self._source_index.get(src,set())
            items=[self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x:getattr(x,"created_at",0),reverse=True)
            return items[:limit]
    def get_time_range(self,start,end,limit=100):
        """
        Get time range.
        @param start: Input.
        @param end: Input.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            result=[]
            for ts,iid in sorted(self._time_heap):
                if ts<start:continue
                if ts>end:break
                if iid in self._items:result.append(self._items[iid])
                if len(result)>=limit:break
            return result
    def get_recent(self,limit=50):
        """
        Get recent.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            items.sort(key=lambda x:getattr(x,"created_at",getattr(x,"timestamp",0)),reverse=True)
            return items[:limit]
    def get_oldest(self,limit=50):
        """
        Get oldest.
        @param limit: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            items.sort(key=lambda x:getattr(x,"created_at",getattr(x,"timestamp",0)))
            return items[:limit]
    def get_all(self):
        """
        Retrieve all items.
        @return: Dict or list of items.
        """
        with self._lock:return list(self._items.values())
    def get_ids(self):
        """
        Get ids.
        @return: Value.
        """
        with self._lock:return list(self._items.keys())
    def size(self):
        """
        Get item count.
        @return: Integer.
        """
        with self._lock:return len(self._items)
    def is_empty(self):
        """
        Check if empty.
        @return: Boolean.
        """
        with self._lock:return len(self._items)==0
    def clear(self):
        """Clear all internal state."""
        with self._lock:
            self._items.clear()
            self._tag_index.clear()
            self._type_index.clear()
            self._source_index.clear()
            self._time_heap.clear()
            self._invalidate_cache()
    def _evict_weakest(self):
        if not self._items:return
        evictable=[(getattr(i,"importance",getattr(i,"weight",0.5)),iid) for iid,i in self._items.items() if not getattr(i,"permanent",False)]
        if evictable:
            evictable.sort()
            self.remove(evictable[0][1])
    def _invalidate_cache(self):
        self._query_cache.clear()
    def cleanup_expired(self):
        """Cleanup expired (AuditStore)."""
        with self._lock:
            expired=[iid for iid,i in self._items.items() if hasattr(i,"is_expired") and i.is_expired()]
            for iid in expired:self.remove(iid)
            return len(expired)
    def batch_add(self,items):
        """
        Batch add (AuditStore).
        @param items: Input.
        """
        return [self.add(item) for item in items]
    def batch_remove(self,iids):
        """
        Batch remove (AuditStore).
        @param iids: Input.
        """
        return sum(1 for iid in iids if self.remove(iid))
    def batch_get(self,iids):
        """
        Batch get (AuditStore).
        @param iids: Input.
        """
        return [self.get(iid) for iid in iids]
    def filter_by(self,predicate,limit=100):
        """
        Filter by (AuditStore).
        @param predicate: Input.
        @param limit: Input.
        """
        with self._lock:
            result=[]
            for iid,item in self._items.items():
                if predicate(item):
                    result.append(item)
                    if len(result)>=limit:break
            return result
    def map_items(self,func):
        """
        Map items (AuditStore).
        @param func: Input.
        """
        with self._lock:
            return {iid:func(item) for iid,item in self._items.items()}
    def reduce_items(self,func,initial=None):
        """
        Reduce items (AuditStore).
        @param func: Input.
        @param initial: Input.
        """
        with self._lock:
            result=initial
            for item in self._items.values():
                result=func(result,item) if result is not None else item
            return result
    def get_random(self,n=1):
        """
        Get random.
        @param n: Input.
        @return: Value.
        """
        with self._lock:
            items=list(self._items.values())
            if not items:return []
            return random.sample(items,min(n,len(items)))
    def get_stats(self):
        """
        Get current statistics snapshot.
        @return: Dict of statistics.
        """
        with self._lock:
            types=Counter(getattr(i,"store_type",getattr(i,"category",getattr(i,"type","general"))) for i in self._items.values())
            total_cache=self._cache_hits+self._cache_misses
            return {"total":len(self._items),"max":self._max,"added":self._added,
                "reads":self._reads,"deleted":self._deleted,"updated":self._updated,
                "searches":self._searches,"cache_hits":self._cache_hits,
                "cache_misses":self._cache_misses,
                "cache_hit_rate":self._cache_hits/max(1,total_cache),
                "types":dict(types),"tags":len(self._tag_index),
                "sources":len(self._source_index)}
    def to_dict(self):
        """
        Convert the object to a dictionary representation.
        @return: Dict with public attributes.
        """
        with self._lock:
            return {iid:asdict(i) if hasattr(i,"__dataclass_fields__") else str(i) for iid,i in self._items.items()}
    def export_json(self,filepath):
        """
        Export json (AuditStore).
        @param filepath: Input.
        """
        with open(filepath,"w",encoding="utf-8") as f:
            json.dump(self.to_dict(),f,ensure_ascii=False,default=str)
    def import_json(self,filepath):
        """
        Import json (AuditStore).
        @param filepath: Input.
        """
        if not os.path.exists(filepath):return 0
        # R28 根因修复：原实现 json.load 遇截断/非JSON文件直接抛 JSONDecodeError 崩溃。
        # 持久化文件损坏属运行期可恢复异常，应优雅返回0并记录日志，而非带崩进程。
        try:
            with open(filepath,"r",encoding="utf-8") as f:
                data=json.load(f)
        except (json.JSONDecodeError, OSError, ValueError) as e:
            logger.warning("import_json 读取失败 %s: %s", filepath, e)
            return 0
        count=0
        for iid,item_data in data.items():
            if isinstance(item_data,dict):
                item_data.setdefault("item_id",iid)
                count+=1
        return count

class ErrorAnalyzer:
    def __init__(self,**kwargs):
        self._stores:Dict[str,Any]={}
        self._config:Dict[str,Any]=dict(kwargs)
        self._lock=threading.RLock()
        self._event_handlers:Dict[str,List[Callable]]=defaultdict(list)
        self._metrics:Dict[str,float]=defaultdict(float)
        self._history:deque=deque(maxlen=500)
        self._initialized=False
        self._last_maintenance=0.0
        self._maintenance_interval=300.0
    def register_store(self,name,store_obj):
        """
        Register store (ErrorAnalyzer).
        @param name: Input.
        @param store_obj: Input.
        """
        with self._lock:
            self._stores[name]=store_obj
            self._emit("store_registered",{"name":name})
    def get_store(self,name):
        """
        Get store.
        @param name: Input.
        @return: Value.
        """
        with self._lock:return self._stores.get(name)
    def remove_store(self,name):
        """
        Remove store.
        @param name: Input.
        """
        with self._lock:
            s=self._stores.pop(name,None)
            if s:self._emit("store_removed",{"name":name})
            return s is not None
    def on(self,event,handler):
        """
        On (ErrorAnalyzer).
        @param event: Input.
        @param handler: Input.
        """
        with self._lock:self._event_handlers[event].append(handler)
    def off(self,event,handler):
        """
        Off (ErrorAnalyzer).
        @param event: Input.
        @param handler: Input.
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)
    def _emit(self,event,data=None):
        handlers=self._event_handlers.get(event,[])
        for h in handlers:
            try:h(data or {})
            except Exception as e:  # 合理忽略：回调/可选操作失败不影响主流程
                logger.debug("操作失败: %s", e, exc_info=True)
    def record_metric(self,name,value):
        """
        Record metric (ErrorAnalyzer).
        @param name: Input.
        @param value: Input.
        """
        with self._lock:
            self._metrics[name]+=value
            self._history.append({"metric":name,"value":value,"timestamp":now_timestamp()})
    def get_metric(self,name):
        """
        Get metric.
        @param name: Input.
        @return: Value.
        """
        with self._lock:return self._metrics.get(name,0.0)
    def get_all_metrics(self):
        """
        Get all metrics.
        @return: Value.
        """
        with self._lock:return dict(self._metrics)
    def reset_metrics(self):
        """Reset metrics (ErrorAnalyzer)."""
        with self._lock:self._metrics.clear()
    def get_history(self,limit=100):
        """
        Get historical records.
        @param limit: Input.
        @return: List of records.
        """
        with self._lock:return list(self._history)[-limit:]
    def initialize(self):
        """Initialize (ErrorAnalyzer)."""
        with self._lock:
            if self._initialized:return False
            self._initialized=True
            self._emit("initialized",{})
            return True
    def shutdown(self):
        """Shutdown (ErrorAnalyzer)."""
        with self._lock:
            if not self._initialized:return False
            self._initialized=False
            self._emit("shutdown",{})
            return True
    def maintenance(self,force=False):
        """
        Maintenance (ErrorAnalyzer).
        @param force: Input.
        """
        with self._lock:
            now=now_timestamp()
            if not force and now-self._last_maintenance<self._maintenance_interval:
                return {"status":"skipped"}
            cleaned=0
            for name,s in self._stores.items():
                if hasattr(s,"cleanup_expired"):
                    try:cleaned+=s.cleanup_expired()
                    except Exception as e:  # 合理忽略：回调/可选操作失败不影响主流程
                        logger.debug("操作失败: %s", e, exc_info=True)
            self._last_maintenance=now
            self._emit("maintenance",{"cleaned":cleaned})
            return {"status":"done","cleaned":cleaned}
    def get_stats(self):
        """
        Get current statistics snapshot.
        @return: Dict of statistics.
        """
        with self._lock:
            store_stats={}
            for name,s in self._stores.items():
                if hasattr(s,"get_stats"):
                    try:store_stats[name]=s.get_stats()
                    except Exception:store_stats[name]="error"
                elif hasattr(s,"size"):
                    store_stats[name]={"size":s.size()}
            return {"initialized":self._initialized,"stores":store_stats,
                "metrics":dict(self._metrics),"history":len(self._history)}
    def to_dict(self):
        """
        Convert the object to a dictionary representation.
        @return: Dict with public attributes.
        """
        with self._lock:
            return {"config":dict(self._config),"metrics":dict(self._metrics),
                "stores":list(self._stores.keys())}
    def export_state(self,filepath):
        """
        Export internal state.
        @param filepath: Input.
        @return: State dict.
        """
        with open(filepath,"w",encoding="utf-8") as f:
            json.dump(self.to_dict(),f,ensure_ascii=False,default=str)
    def import_state(self,filepath):
        """Import state from dict."""
        if not os.path.exists(filepath):return False
        with open(filepath,"r",encoding="utf-8") as f:
            data=json.load(f)
        with self._lock:
            if "config" in data:self._config.update(data["config"])
            if "metrics" in data:self._metrics.update(data["metrics"])
        return True
