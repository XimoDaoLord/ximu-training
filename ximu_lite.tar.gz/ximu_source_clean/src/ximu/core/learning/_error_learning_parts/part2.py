import json
import os
import logging
import threading
from typing import Any, Dict, List, Optional, Callable, Deque, Tuple
from collections import defaultdict, deque
from src.ximu.common.utils import generate_id, now_timestamp

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class StoreRegistryBase:
    """注册表基类，提供核心注册与监控功能"""
    def __init__(self, 
                 config: Dict[str, Any] = None, 
                 config_version: int = 1,
                 maintenance_interval: float = 300.0):
        self._version = config_version
        self._stores: Dict[str, Any] = defaultdict(dict)
        self._config: Dict[str, Any] = config or {}
        self._lock = threading.RLock()
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: Deque[Tuple[str, float, int]] = deque(maxlen=500)
        self._initialized = False
        self._last_maintenance = 0
        self._maintenance_interval = maintenance_interval
        self._health: Dict[str, Dict[str, Any]] = defaultdict(lambda: {"available": True, "errors": 0})

    def register_store(self, name: str, store_obj: Any) -> bool:
        """注册存储组件"""
        with self._lock:
            if name in self._stores:
                return False
            self._stores[name] = store_obj
            self._emit("store_registered", {"name": name, "version": self._version})
            return True

    def get_store(self, name: str) -> Optional[Any]:
        """获取存储组件"""
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """移除存储组件"""
        with self._lock:
            if name not in self._stores:
                return False
            store = self._stores.pop(name)
            self._emit("store_removed", {"name": name, "version": self._version})
            return True

    def on(self, event: str, handler: Callable[[Dict], None]) -> None:
        """注册事件处理器"""
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable[[Dict], None]) -> None:
        """移除事件处理器"""
        with self._lock:
            if event in self._event_handlers:
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Dict) -> None:
        """触发事件通知"""
        with self._lock:
            handlers = self._event_handlers.get(event, [])
            for handler in handlers:
                try:
                    handler(data)
                except Exception as e:
                    logger.error(f"Event handler '{event}' failed: {str(e)}", exc_info=True)

    def record_metric(self, name: str, value: float) -> None:
        """记录指标数据"""
        with self._lock:
            self._metrics[name] += value
            self._history.append((name, value, now_timestamp()))

    def get_metric(self, name: str) -> float:
        """获取指标数据"""
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """获取所有指标数据"""
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        """重置指标数据"""
        with self._lock:
            self._metrics.clear()

    def get_history(self, limit: int = 100) -> List[Tuple[str, float, int]]:
        """获取历史记录"""
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """初始化组件"""
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._health["system"] = {"available": True}
            self._emit("initialized", {"version": self._version})
            return True

    def shutdown(self) -> bool:
        """关闭组件"""
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            self._health["system"] = {"available": False}
            self._emit("shutdown", {"version": self._version})
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """执行维护操作"""
        with self._lock:
            now = now_timestamp()
            if not force and (now - self._last_maintenance) < self._maintenance_interval:
                return {"status": "skipped", "version": self._version}
            
            start_time = now_timestamp()
            cleaned = 0
            health_stats = defaultdict(lambda: {"available": True, "errors": 0})

            for name, store in self._stores.items():
                try:
                    if hasattr(store, "cleanupExpired"):
                        cleaned += store.cleanupExpired()
                    if hasattr(store, "getHealth"):
                        health = store.getHealth()
                        health_stats[name] = health
                except Exception as e:
                    logger.error(f"Store {name} maintenance failed: {str(e)}", exc_info=True)
                    health_stats[name]["available"] = False
                    health_stats[name]["errors"] += 1

            self._last_maintenance = now
            self._health.update(health_stats)
            self._emit("maintenance", {"cleaned": cleaned, "duration": now - start_time, "version": self._version})
            return {
                "status": "done",
                "cleaned": cleaned,
                "duration": now - start_time,
                "health": health_stats,
                "version": self._version
            }

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        with self._lock:
            stats = {
                "initialized": self._initialized,
                "metrics": dict(self._metrics),
                "history_length": len(self._history),
                "version": self._version
            }
            
            store_stats = {}
            for name, store in self._stores.items():
                if hasattr(store, "getStats"):
                    try:
                        store_stats[name] = store.getStats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(store, "size"):
                    store_stats[name] = {"size": store.size()}
            
            stats["stores"] = store_stats
            stats["health"] = self._health
            return stats

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典"""
        with self._lock:
            return {
                "version": self._version,
                "config": dict(self._config),
                "stores": list(self._stores.keys()),
                "metrics": dict(self._metrics),
                "history": list(self._history)
            }

    def export_state(self, filepath: str) -> bool:
        """导出内部状态"""
        with self._lock:
            state = self.to_dict()
            if "version" not in state or state["version"] != self._version:
                return False
            
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(state, f, ensure_ascii=False, default=str)
            return True

    def import_state(self, filepath: str) -> bool:
        """导入内部状态"""
        if not os.path.exists(filepath):
            return False
        
        with self._lock:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            if "version" not in data or data["version"] != self._version:
                return False
            
            self._config.update(data.get("config", {}))
            self._stores.update(data.get("stores", {}))
            self._metrics.update(data.get("metrics", {}))
            self._history = deque(data.get("history", []))
            self._health = data.get("health", defaultdict(lambda: {"available": True, "errors": 0}))
            return True

class RootCauseStoreRegistry(StoreRegistryBase):
    """根原因存储注册表"""
    def __init__(self, config: Dict[str, Any] = None):
        super().__init__(config, maintenance_interval=300.0, config_version=1)

class CorrectionStoreRegistry(StoreRegistryBase):
    """纠正存储注册表"""
    def __init__(self, config: Dict[str, Any] = None):
        super().__init__(config, maintenance_interval=180.0, config_version=1)

class LearningIntegrator(StoreRegistryBase):
    """学习集成器"""
    def __init__(self, config: Dict[str, Any] = None):
        super().__init__(config, maintenance_interval=600.0, config_version=1)

class ExperienceCurator(StoreRegistryBase):
    """经验策展人"""
    def __init__(self, config: Dict[str, Any] = None):
        super().__init__(config, maintenance_interval=900.0, config_version=1)
