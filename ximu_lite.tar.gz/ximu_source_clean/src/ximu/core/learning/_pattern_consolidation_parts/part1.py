"""
Part 1 of pattern_consolidation (lines 2-2757 of 3246).
汐沫AI - 模式沉淀 Pattern Consolidation System
"""

from src.ximu.common.utils import score_stored_item
import logging
import os
import json
import time
import uuid
import heapq
import threading
import random
import re
from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Set, Tuple, TypeVar, Optional, Union
from collections import OrderedDict, defaultdict, Counter
from datetime import datetime, timedelta, timezone

logger = logging.getLogger("src.ximu.core.learning._pattern_consolidation_parts.part1")

# 尝试导入配置，如果失败则设为None
try:
    from config.settings import config
except ImportError:
    config = None

# 版本标识
__version__ = "0.5"

T = TypeVar("T")


def generate_id(prefix: str = "id") -> str:
    """
    生成唯一ID。
    
    @param prefix: ID前缀。
    @return: 生成的唯一ID字符串。
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


def now_timestamp() -> float:
    """
    获取当前时间戳。
    
    @return: 当前时间戳（秒）。
    """
    return time.time()


def now_datetime() -> datetime:
    """
    获取当前UTC+8时区时间。
    
    @return: 当前UTC+8时区的datetime对象。
    """
    return datetime.now(timezone(timedelta(hours=8)))


def format_datetime(dt: Optional[datetime] = None, fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    格式化datetime对象。
    
    @param dt: 输入datetime对象，若为None则使用当前时间。
    @param fmt: 格式化字符串。
    @return: 格式化后的日期时间字符串。
    """
    if dt is None:
        dt = now_datetime()
    return dt.strftime(fmt)


class Stopwatch:
    """
    计时器类，用于测量代码执行时间。
    """
    
    def __init__(self) -> None:
        """
        初始化计时器。
        """
        self._start: float = 0.0
        self._end: float = 0.0

    def start(self) -> "Stopwatch":
        """
        开始计时。
        
        @return: 自身实例以支持链式调用。
        """
        self._start = time.time()
        return self

    def stop(self) -> "Stopwatch":
        """
        停止计时。
        
        @return: 自身实例以支持链式调用。
        """
        self._end = time.time()
        return self

    @property
    def elapsed_ms(self) -> float:
        """
        获取经过的毫秒数。
        
        @return: 经过的毫秒数。
        """
        if self._start == 0.0:
            return 0.0
        return (self._end - self._start) * 1000


class LearningPhase(str, Enum):
    """学习阶段枚举。"""
    PERCEPTION = "perception"
    ENCODING = "encoding"
    CONSOLIDATION = "consolidation"
    APPLICATION = "application"
    FEEDBACK = "feedback"
    EVOLUTION = "evolution"


class LearningType(str, Enum):
    """学习类型枚举。"""
    SUPERVISED = "supervised"
    UNSUPERVISED = "unsupervised"
    REINFORCEMENT = "reinforcement"
    ONLINE = "online"
    OFFLINE = "offline"
    TRANSFER = "transfer"
    META = "meta"


class ConsolidationPhase(str, Enum):
    """沉淀阶段枚举。"""
    VALIDATION = "validation"
    STORAGE = "storage"
    INDEXING = "indexing"
    ACTIVATION = "activation"
    RETIREMENT = "retirement"


class PatternStatus(str, Enum):
    """模式状态枚举。"""
    CANDIDATE = "candidate"
    VALIDATED = "validated"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    RETIRED = "retired"


@dataclass
class LearningItem:
    """
    学习项数据结构。
    
    表示系统中的一个学习单元，包含内容、标签、重要性等属性。
    """
    item_id: str = ""
    content: str = ""
    store_type: str = "general"
    category: str = ""
    source: str = ""
    tags: List[str] = field(default_factory=list)
    created_at: float = 0.0
    updated_at: float = 0.0
    last_accessed: float = 0.0
    access_count: int = 0
    importance: float = 0.5
    weight: float = 1.0
    confidence: float = 0.5
    metadata: Dict[str, Any] = field(default_factory=dict)
    permanent: bool = False

    def __post_init__(self) -> None:
        """
        数据类初始化后的钩子，设置默认时间戳。
        """
        now = now_timestamp()
        if self.created_at == 0.0:
            self.created_at = now
        if self.updated_at == 0.0:
            self.updated_at = now
        if self.last_accessed == 0.0:
            self.last_accessed = now

    def access(self) -> None:
        """
        记录访问操作，更新最后访问时间并增加访问计数。
        """
        self.last_accessed = now_timestamp()
        self.access_count += 1

    def is_expired(self) -> bool:
        """
        检查学习项是否过期。
        
        @return: 是否过期，当前始终返回False。
        """
        return False

    def get_strength(self) -> float:
        """
        计算学习项强度分数。
        
        @return: 基于访问频率、置信度和重要性计算的加权强度。
        """
        base_strength = (
            0.3 + 
            0.3 * min(1.0, self.access_count / 20.0) + 
            0.2 * self.confidence + 
            0.2 * self.importance
        )
        return base_strength * self.weight

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典表示。
        
        @return: 包含所有字段的字典。
        """
        return asdict(self)


@dataclass
class Pattern:
    """
    模式数据结构。
    
    表示从数据中提取的模式，包含支持度、置信度等统计指标。
    """
    pattern_id: str = ""
    name: str = ""
    pattern_type: str = "frequent"
    elements: List[str] = field(default_factory=list)
    support: float = 0.0
    confidence: float = 0.0
    lift: float = 1.0
    frequency: int = 0
    created_at: float = 0.0
    updated_at: float = 0.0
    usage_count: int = 0
    success_count: int = 0
    status: str = "candidate"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """
        数据类初始化后的钩子，设置默认时间戳。
        """
        if self.created_at == 0.0:
            self.created_at = now_timestamp()
        if self.updated_at == 0.0:
            self.updated_at = now_timestamp()

    def record_usage(self, success: bool = True) -> None:
        """
        记录模式使用。
        
        @param success: 使用是否成功。
        """
        self.usage_count += 1
        if success:
            self.success_count += 1
        self.updated_at = now_timestamp()

    @property
    def success_rate(self) -> float:
        """
        计算成功率。
        
        @return: 成功次数除以总使用次数（至少为1）。
        """
        return self.success_count / max(1, self.usage_count)

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典表示。
        
        @return: 包含所有字段的字典。
        """
        return asdict(self)


@dataclass
class ErrorRecord:
    """
    错误记录数据结构。
    
    记录系统错误，包含错误类型、上下文、根因分析等信息。
    """
    error_id: str = ""
    error_type: str = "general"
    message: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    severity: str = "medium"
    created_at: float = 0.0
    resolved: bool = False
    resolution: str = ""
    resolved_at: float = 0.0
    recurrence_count: int = 0
    root_cause: str = ""
    predicted: bool = False
    prediction_confidence: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """
        数据类初始化后的钩子，设置默认时间戳。
        """
        if self.created_at == 0.0:
            self.created_at = now_timestamp()

    def resolve(self, resolution: str, root_cause: str = "") -> None:
        """
        标记错误已解决。
        
        @param resolution: 解决方案描述。
        @param root_cause: 根本原因描述（可选）。
        """
        self.resolved = True
        self.resolution = resolution
        self.resolved_at = now_timestamp()
        if root_cause:
            self.root_cause = root_cause

    def record_recurrence(self) -> None:
        """
        记录错误复现。
        """
        self.recurrence_count += 1

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典表示。
        
        @return: 包含所有字段的字典。
        """
        return asdict(self)


@dataclass
class ConsolidationRecord:
    """
    沉淀记录数据结构。
    
    记录模式沉淀过程中的各个阶段。
    """
    record_id: str = ""
    pattern_id: str = ""
    phase: str = "validation"
    started_at: float = 0.0
    completed_at: float = 0.0
    result: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """
        数据类初始化后的钩子，设置默认时间戳。
        """
        if self.started_at == 0.0:
            self.started_at = now_timestamp()

    def complete(self, result: str) -> None:
        """
        标记沉淀记录完成。
        
        @param result: 结果描述。
        """
        self.completed_at = now_timestamp()
        self.result = result

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典表示。
        
        @return: 包含所有字段的字典。
        """
        return asdict(self)


class ValidatedPatternStore:
    """
    验证模式存储类。
    
    提供线程安全的模式存储、检索、索引和管理功能，
    支持基于类型、标签和源的索引，以及查询缓存。
    """
    
    def __init__(self, max_items: int = 10000) -> None:
        """
        初始化模式存储。
        
        @param max_items: 最大存储项数。
        """
        self._items: Dict[str, Any] = {}
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._type_index: Dict[str, Set[str]] = defaultdict(set)
        self._source_index: Dict[str, Set[str]] = defaultdict(set)
        self._time_heap: List[Tuple[float, str]] = []
        self._max: int = max_items
        self._lock = threading.RLock()
        
        # 统计计数器
        self._added: int = 0
        self._reads: int = 0
        self._deleted: int = 0
        self._updated: int = 0
        self._searches: int = 0
        self._cache_hits: int = 0
        self._cache_misses: int = 0
        
        # 查询缓存
        self._query_cache: OrderedDict[str, List[Tuple[Any, float]]] = OrderedDict()
        self._max_cache: int = 500

    def add(self, item: Any) -> Any:
        """
        添加项目到存储中。
        
        如果存储已满，会先驱逐最弱的项目。
        
        @param item: 要添加的项目。
        @return: 添加的项目。
        """
        with self._lock:
            if len(self._items) >= self._max:
                self._evict_weakest()
            
            # 获取项目ID，支持多种属性名
            item_id = getattr(item, "item_id", None)
            if item_id is None:
                item_id = getattr(item, "entry_id", None)
            if item_id is None:
                item_id = getattr(item, "id", None)
            if item_id is None:
                item_id = generate_id("item")
            
            self._items[item_id] = item
            
            # 更新标签索引
            tags = getattr(item, "tags", [])
            if isinstance(tags, (list, tuple, set)):
                for tag in tags:
                    if isinstance(tag, str):
                        self._tag_index[tag.lower()].add(item_id)
            
            # 更新类型索引
            item_type = getattr(item, "store_type", None)
            if item_type is None:
                item_type = getattr(item, "category", None)
            if item_type is None:
                item_type = getattr(item, "type", "general")
            self._type_index[item_type].add(item_id)
            
            # 更新源索引
            source = getattr(item, "source", "")
            if source:
                self._source_index[source].add(item_id)
            
            # 更新时间堆
            created_at = getattr(item, "created_at", now_timestamp())
            heapq.heappush(self._time_heap, (created_at, item_id))
            
            self._added += 1
            self._invalidate_cache()
            
            logger.debug("添加项目到存储: %s", item_id)
            return item

    def get(self, item_id: str) -> Optional[Any]:
        """
        根据ID获取项目。
        
        @param item_id: 项目ID。
        @return: 项目实例或None。
        """
        with self._lock:
            item = self._items.get(item_id)
            if item is not None:
                if hasattr(item, "access"):
                    item.access()
                self._reads += 1
            return item

    def get_or_default(self, item_id: str, default: Any = None) -> Any:
        """
        获取项目或返回默认值。
        
        @param item_id: 项目ID。
        @param default: 默认值。
        @return: 项目实例或默认值。
        """
        item = self.get(item_id)
        return item if item is not None else default

    def remove(self, item_id: str) -> bool:
        """
        删除项目。
        
        @param item_id: 项目ID。
        @return: 如果成功删除则返回True，否则返回False。
        """
        with self._lock:
            item = self._items.pop(item_id, None)
            if item is not None:
                # 从标签索引中移除
                tags = getattr(item, "tags", [])
                if isinstance(tags, (list, tuple, set)):
                    for tag in tags:
                        if isinstance(tag, str):
                            self._tag_index[tag.lower()].discard(item_id)
                
                # 从类型索引中移除
                item_type = getattr(item, "store_type", None)
                if item_type is None:
                    item_type = getattr(item, "category", None)
                if item_type is None:
                    item_type = getattr(item, "type", "general")
                self._type_index[item_type].discard(item_id)
                
                # 从源索引中移除
                source = getattr(item, "source", "")
                if source:
                    self._source_index[source].discard(item_id)
                
                self._deleted += 1
                self._invalidate_cache()
                logger.debug("删除项目: %s", item_id)
                return True
            return False

    def update(self, item_id: str, **kwargs: Any) -> bool:
        """
        更新项目属性。
        
        @param item_id: 项目ID。
        @param kwargs: 要更新的属性键值对。
        @return: 如果成功更新则返回True，否则返回False。
        """
        with self._lock:
            item = self._items.get(item_id)
            if item is not None:
                for key, value in kwargs.items():
                    if hasattr(item, key):
                        setattr(item, key, value)
                
                if hasattr(item, "updated_at"):
                    item.updated_at = now_timestamp()
                
                self._updated += 1
                self._invalidate_cache()
                logger.debug("更新项目: %s, 属性: %s", item_id, list(kwargs.keys()))
                return True
            return False

    def contains(self, item_id: str) -> bool:
        """
        检查项目是否存在。
        
        @param item_id: 项目ID。
        @return: 如果存在则返回True，否则返回False。
        """
        with self._lock:
            return item_id in self._items

    def search(
        self,
        query: str,
        limit: int = 20,
        category: str = "",
        tags: Optional[List[str]] = None,
        min_score: float = 0.0
    ) -> List[Tuple[Any, float]]:
        """
        搜索项目。
        
        @param query: 搜索查询字符串。
        @param limit: 最大返回结果数。
        @param category: 类别过滤。
        @param tags: 标签过滤列表。
        @param min_score: 最小分数阈值。
        @return: 匹配项目及其分数的列表。
        """
        with self._lock:
            # 构建缓存键
            cache_key = f"{query}:{category}:{tuple(tags or [])}:{min_score}:{limit}"
            
            if cache_key in self._query_cache:
                self._cache_hits += 1
                self._query_cache.move_to_end(cache_key)
                return self._query_cache[cache_key]
            
            self._cache_misses += 1
            self._searches += 1
            
            q_lower = query.lower().strip()
            candidate_ids: Set[str] = set(self._items.keys())
            
            # 按类别过滤
            if category:
                category_ids = self._type_index.get(category, set())
                candidate_ids &= category_ids
            
            # 按标签过滤
            if tags:
                tag_ids: Set[str] = set()
                for tag in tags:
                    if isinstance(tag, str):
                        tag_ids.update(self._tag_index.get(tag.lower(), set()))
                candidate_ids &= tag_ids
            
            # 计算分数
            scored: List[Tuple[float, Any]] = []
            query_words = q_lower.split() if q_lower else []
            
            for item_id in candidate_ids:
                if item_id not in self._items:
                    continue
                item = self._items[item_id]
                score = score_stored_item(item, q_lower, query_words)
                if score > min_score:
                    scored.append((score, item))
            
            # 按分数降序排序
            scored.sort(key=lambda x: x[0], reverse=True)
            
            # 限制结果数量
            result = [(item, score) for score, item in scored[:limit]]
            
            # 更新缓存
            self._query_cache[cache_key] = result
            if len(self._query_cache) > self._max_cache:
                self._query_cache.popitem(last=False)
            
            logger.debug("搜索查询: '%s', 结果数: %d", query, len(result))
            return result

    def fuzzy_search(
        self,
        query: str,
        threshold: float = 0.6,
        limit: int = 20
    ) -> List[Tuple[Any, float]]:
        """
        模糊搜索项目。
        
        @param query: 搜索查询字符串。
        @param threshold: 相似度阈值。
        @param limit: 最大返回结果数。
        @return: 匹配项目及其相似度的列表。
        """
        with self._lock:
            q_lower = query.lower()
            scored: List[Tuple[float, Any]] = []
            
            for item_id, item in self._items.items():
                content = (getattr(item, "content", "") or "").lower()
                similarity = self._text_similarity(q_lower, content)
                if similarity >= threshold:
                    scored.append((similarity, item))
            
            scored.sort(key=lambda x: x[0], reverse=True)
            result = [(item, score) for score, item in scored[:limit]]
            
            logger.debug("模糊搜索查询: '%s', 结果数: %d", query, len(result))
            return result

    def regex_search(self, pattern: str, limit: int = 20) -> List[Any]:
        """
        正则表达式搜索项目。
        
        @param pattern: 正则表达式模式。
        @param limit: 最大返回结果数。
        @return: 匹配的项目列表。
        """
        with self._lock:
            try:
                regex = re.compile(pattern, re.IGNORECASE)
            except re.error as e:
                logger.error("无效的正则表达式: %s, 错误: %s", pattern, e)
                return []
            
            result: List[Any] = []
            for item in self._items.values():
                content = getattr(item, "content", "") or ""
                if regex.search(content):
                    result.append(item)
                    if len(result) >= limit:
                        break
            
            logger.debug("正则搜索模式: '%s', 结果数: %d", pattern, len(result))
            return result

    def _text_similarity(self, text_a: str, text_b: str) -> float:
        """
        计算两个文本的Jaccard相似度。
        
        @param text_a: 文本A。
        @param text_b: 文本B。
        @return: 相似度分数，范围[0, 1]。
        """
        if not text_a or not text_b:
            return 0.0
        
        words_a = set(text_a.split())
        words_b = set(text_b.split())
        
        if not words_a or not words_b:
            return 0.0
        
        intersection = len(words_a & words_b)
        union = len(words_a | words_b)
        
        return intersection / union if union > 0 else 0.0

    def get_by_type(self, item_type: str, limit: int = 100) -> List[Any]:
        """
        按类型获取项目。
        
        @param item_type: 项目类型。
        @param limit: 最大返回结果数。
        @return: 按创建时间降序排列的项目列表。
        """
        with self._lock:
            item_ids = self._type_index.get(item_type, set())
            items = [
                self._items[item_id] 
                for item_id in item_ids 
                if item_id in self._items
            ]
            items.sort(key=lambda x: getattr(x, "created_at", 0), reverse=True)
            return items[:limit]

    def get_by_tag(self, tag: str, limit: int = 100) -> List[Any]:
        """
        按标签获取项目。
        
        @param tag: 标签名称。
        @param limit: 最大返回结果数。
        @return: 项目列表。
        """
        with self._lock:
            item_ids = self._tag_index.get(tag.lower(), set())
            items = [
                self._items[item_id] 
                for item_id in item_ids 
                if item_id in self._items
            ]
            return items[:limit]

    def get_by_source(self, source: str, limit: int = 100) -> List[Any]:
        """
        按来源获取项目。
        
        @param source: 来源标识。
        @param limit: 最大返回结果数。
        @return: 项目列表。
        """
        with self._lock:
            item_ids = self._source_index.get(source, set())
            items = [
                self._items[item_id] 
                for item_id in item_ids 
                if item_id in self._items
            ]
            return items[:limit]

    def sample(self, n: int) -> List[Any]:
        """
        随机采样项目。
        
        @param n: 采样数量。
        @return: 随机选择的样本列表。
        """
        with self._lock:
            items = list(self._items.values())
            if not items:
                return []
            return random.sample(items, min(n, len(items)))

    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息快照。
        
        @return: 包含各项统计数据的字典。
        """
        with self._lock:
            # 统计类型分布
            type_counter: Counter = Counter()
            for item in self._items.values():
                item_type = getattr(item, "store_type", None)
                if item_type is None:
                    item_type = getattr(item, "category", None)
                if item_type is None:
                    item_type = getattr(item, "type", "general")
                type_counter[item_type] += 1
            
            total_cache = self._cache_hits + self._cache_misses
            
            return {
                "total": len(self._items),
                "max": self._max,
                "added": self._added,
                "reads": self._reads,
                "deleted": self._deleted,
                "updated": self._updated,
                "searches": self._searches,
                "cache_hits": self._cache_hits,
                "cache_misses": self._cache_misses,
                "cache_hit_rate": self._cache_hits / max(1, total_cache),
                "types": dict(type_counter),
                "tags": len(self._tag_index),
                "sources": len(self._source_index)
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典表示。
        
        @return: 包含所有项目的字典，值为字典或字符串表示。
        """
        with self._lock:
            result = {}
            for item_id, item in self._items.items():
                if hasattr(item, "__dataclass_fields__"):
                    result[item_id] = asdict(item)
                else:
                    result[item_id] = str(item)
            return result

    def export_json(self, filepath: str) -> None:
        """
        导出到JSON文件。
        
        @param filepath: 文件路径。
        """
        with self._lock:
            data = self.to_dict()
        
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, default=str)
        logger.info("导出JSON文件: %s, 项目数: %d", filepath, len(data))

    def import_json(self, filepath: str) -> int:
        """
        从JSON文件导入数据。
        
        @param filepath: 文件路径。
        @return: 导入的项目数量。
        """
        if not os.path.exists(filepath):
            logger.warning("导入文件不存在: %s", filepath)
            return 0
        
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        count = 0
        for item_id, item_data in data.items():
            if isinstance(item_data, dict):
                item_data.setdefault("item_id", item_id)
                count += 1
        
        logger.info("导入JSON文件: %s, 项目数: %d", filepath, count)
        return count

    def _evict_weakest(self) -> None:
        """
        驱逐最弱的项目（内部方法）。
        
        从时间堆中弹出最早创建的项目，如果该项目已不存在则跳过。
        """
        while self._time_heap:
            _, item_id = heapq.heappop(self._time_heap)
            if item_id in self._items:
                self.remove(item_id)
                logger.debug("驱逐最弱项目: %s", item_id)
                break

    def _invalidate_cache(self) -> None:
        """
        使查询缓存失效（内部方法）。
        """
        self._query_cache.clear()

    def __len__(self) -> int:
        """
        返回存储中的项目数量。
        
        @return: 项目数量。
        """
        with self._lock:
            return len(self._items)

    def __contains__(self, item_id: str) -> bool:
        """
        检查项目是否在存储中。
        
        @param item_id: 项目ID。
        @return: 如果存在则返回True，否则返回False。
        """
        return self.contains(item_id)

    def __iter__(self) -> Any:
        """
        迭代器。
        
        @return: 项目值的迭代器。
        """
        with self._lock:
            return iter(list(self._items.values()))


# ===== 自动补全 =====

class ActivePatternStore:
    """ActivePatternStore - 活跃模式存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class ConsolidationQueueStore:
    """ConsolidationQueueStore。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class DeprecatedPatternStore:
    """DeprecatedPatternStore - 已废弃模式存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)

    def delete(self, key):
        self._data.pop(key, None)


class RetiredPatternStore:
    """RetiredPatternStore - 已退役模式存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)

    def delete(self, key):
        self._data.pop(key, None)
