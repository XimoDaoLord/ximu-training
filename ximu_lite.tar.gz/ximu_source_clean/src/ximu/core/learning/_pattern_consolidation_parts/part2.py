"""Part 2 of pattern_consolidation (lines 2759-3246 of 3246)."""
import logging
logger = logging.getLogger("src.ximu.core.learning._pattern_consolidation_parts.part2")
import os
import json
import threading
from typing import Any, Callable, Dict, List, Optional, Union
from collections import defaultdict, deque
from .part1 import ActivePatternStore
from .part1 import ConsolidationPhase
from .part1 import ConsolidationQueueStore
from .part1 import ConsolidationRecord
from .part1 import DeprecatedPatternStore
from .part1 import ErrorRecord
from .part1 import LearningItem
from .part1 import LearningPhase
from .part1 import LearningType
from re import Pattern
from .part3 import PatternApplicationStore
from .part3 import PatternAuditStore
from .part3 import PatternFeedbackStore
from .part3 import PatternIndexStore
from .part1 import PatternStatus
from .part3 import PatternVersionStore
from .part1 import RetiredPatternStore
from .part1 import ValidatedPatternStore
from src.ximu.common.utils import generate_id
from src.ximu.common.utils import now_timestamp

class _EventMetricMixin:
    """提供事件、指标、历史记录以及维护通用逻辑的混入类。"""
    def __init__(self, **kwargs):
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=500)
        self._initialized = False
        self._last_maintenance = 0.0
        self._maintenance_interval = 300.0

    def register_store(self, name: str, store_obj: Any) -> None:
        """
        注册存储对象。

        Args:
            name: 存储名称。
            store_obj: 存储对象实例。
        """
        with self._lock:
            self._stores[name] = store_obj
            self._emit("store_registered", {"name": name})
            logger.debug("存储已注册: %s", name)

    def get_store(self, name: str) -> Optional[Any]:
        """
        获取存储对象。

        Args:
            name: 存储名称。

        Returns:
            存储对象或 None。
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """
        移除存储对象。

        Args:
            name: 存储名称。

        Returns:
            是否成功移除。
        """
        with self._lock:
            s = self._stores.pop(name, None)
            if s:
                self._emit("store_removed", {"name": name})
                logger.debug("存储已移除: %s", name)
            return s is not None

    def on(self, event: str, handler: Callable) -> None:
        """
        注册事件处理器。

        Args:
            event: 事件名称。
            handler: 事件处理函数。
        """
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable) -> None:
        """
        注销事件处理器。

        Args:
            event: 事件名称。
            handler: 事件处理函数。
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Optional[Dict[str, Any]] = None) -> None:
        """
        触发事件。

        Args:
            event: 事件名称。
            data: 事件数据。
        """
        handlers = self._event_handlers.get(event, [])
        for h in handlers:
            try:
                h(data or {})
            except Exception as e:
                logger.debug("事件处理器失败: %s", e, exc_info=True)

    def record_metric(self, name: str, value: float) -> None:
        """
        记录指标。

        Args:
            name: 指标名称。
            value: 指标增量。
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({"metric": name, "value": value, "timestamp": now_timestamp()})

    def get_metric(self, name: str) -> float:
        """
        获取指标值。

        Args:
            name: 指标名称。

        Returns:
            指标值。
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """
        获取所有指标。

        Returns:
            包含所有指标的字典。
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        """重置所有指标。"""
        with self._lock:
            self._metrics.clear()
            logger.debug("指标已重置")

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取历史记录。

        Args:
            limit: 最大记录数。

        Returns:
            历史记录列表。
        """
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """
        初始化管理器。

        Returns:
            是否成功初始化（若已初始化则返回 False）。
        """
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._emit("initialized", {})
            logger.info("管理器已初始化")
            return True

    def shutdown(self) -> bool:
        """
        关闭管理器。

        Returns:
            是否成功关闭（若未初始化则返回 False）。
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            self._emit("shutdown", {})
            logger.info("管理器已关闭")
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """
        执行维护操作。

        Args:
            force: 是否强制执行。

        Returns:
            维护结果字典。
        """
        with self._lock:
            now = now_timestamp()
            if not force and now - self._last_maintenance < self._maintenance_interval:
                return {"status": "skipped"}
            
            cleaned = 0
            for name, s in self._stores.items():
                if hasattr(s, "cleanup_expired"):
                    try:
                        cleaned += s.cleanup_expired()
                    except Exception as e:
                        logger.warning("清理存储失败: %s, 错误: %s", name, e, exc_info=True)
            
            self._last_maintenance = now
            self._emit("maintenance", {"cleaned": cleaned})
            logger.debug("维护完成, 清理数量: %d", cleaned)
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        """
        获取当前统计快照。

        Returns:
            统计信息字典。
        """
        with self._lock:
            store_stats = {}
            for name, s in self._stores.items():
                if hasattr(s, "get_stats"):
                    try:
                        store_stats[name] = s.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(s, "size"):
                    store_stats[name] = {"size": s.size()}
            
            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history)
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典表示。

        Returns:
            包含公共属性的字典。
        """
        with self._lock:
            return {
                "config": dict(self._config),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys())
            }

    def export_state(self, filepath: str) -> None:
        """
        导出内部状态到文件。

        Args:
            filepath: 文件路径。
        """
        with self._lock:
            state = self.to_dict()
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(state, f, ensure_ascii=False, default=str)
            logger.debug("状态已导出: %s", filepath)
        except Exception as e:
            logger.error("导出状态失败: %s", e, exc_info=True)
            raise

    def import_state(self, filepath: str) -> bool:
        """
        从文件导入内部状态。

        Args:
            filepath: 文件路径。

        Returns:
            是否成功导入。
        """
        if not os.path.exists(filepath):
            logger.warning("状态文件不存在: %s", filepath)
            return False
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            with self._lock:
                if "config" in data:
                    self._config.update(data["config"])
                if "metrics" in data:
                    self._metrics.update(data["metrics"])
            logger.debug("状态已导入: %s", filepath)
            return True
        except Exception as e:
            logger.error("导入状态失败: %s", e, exc_info=True)
            return False


class PatternStorageManagerRegistry(_EventMetricMixin):
    """
    模式存储管理器注册表。
    用于管理多个模式存储实例的注册、查询和生命周期。
    """
    def __init__(self, **kwargs):
        """
        初始化注册表。

        Args:
            **kwargs: 配置参数。
        """
        super().__init__(**kwargs)


class PatternIndexer(_EventMetricMixin):
    """
    模式索引器。
    负责构建和维护模式索引，支持快速检索。
    """
    def __init__(self, **kwargs):
        """
        初始化索引器。

        Args:
            **kwargs: 配置参数。
        """
        super().__init__(**kwargs)


class PatternLifecycleManager(_EventMetricMixin):
    """
    模式生命周期管理器。
    管理模式的验证、激活、弃用和退休等阶段转换。
    """
    def __init__(self, **kwargs):
        """
        初始化管理器。

        Args:
            **kwargs: 配置参数。
        """
        super().__init__(**kwargs)


class PatternApplicationEngine(_EventMetricMixin):
    """
    模式应用引擎。
    负责将已验证的模式应用到具体场景中。
    """
    def __init__(self, **kwargs):
        """
        初始化引擎。

        Args:
            **kwargs: 配置参数。
        """
        super().__init__(**kwargs)


class PatternConsolidator:
    """
    模式固化器。
    负责将学习到的模式进行固化、验证和应用，并跟踪其生命周期。
    """
    def __init__(self, **kwargs):
        """
        初始化固化器。

        Args:
            **kwargs: 配置参数。
        """
        self.storage_manager = PatternStorageManagerRegistry(**kwargs)
        self.validated_store = ValidatedPatternStore()
        self.active_store = ActivePatternStore()
        self.deprecated_store = DeprecatedPatternStore()
        self.retired_store = RetiredPatternStore()
        self.validator = PatternValidator()
        self.config = kwargs

    def consolidate(self, pattern: LearningItem) -> ConsolidationRecord:
        """
        固化单个模式。

        Args:
            pattern: 待固化的学习项。

        Returns:
            固化记录。
        """
        record = ConsolidationRecord(pattern_id=pattern.id, pattern_name=pattern.name)
        logger.debug("开始固化模式: %s", pattern.name)
        
        validation = self.validator.validate(pattern)
        if validation['valid']:
            record.mark_validated()
            self.validated_store.add(pattern)
            record.mark_consolidated()
            self.active_store.add(pattern)
            record.complete("consolidated")
        else:
            issues = ','.join(validation['issues']) if validation['issues'] else 'unknown'
            record.complete(f"rejected:{issues}")
            logger.warning("模式固化被拒绝: %s, 原因: %s", pattern.name, issues)
        return record

    def batch_consolidate(self, patterns: List[LearningItem]) -> List[ConsolidationRecord]:
        """
        批量固化模式。

        Args:
            patterns: 学习项列表。

        Returns:
            固化记录列表。
        """
        logger.info("开始批量固化 %d 个模式", len(patterns))
        records = [self.consolidate(p) for p in patterns]
        logger.info("批量固化完成")
        return records

    def apply_pattern(self, pattern_id: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        应用已固化的模式。

        Args:
            pattern_id: 模式 ID。
            context: 应用上下文。

        Returns:
            应用结果字典。
        """
        pattern = self.storage_manager.get_store("active")
        if not pattern:
            # 尝试直接从 active_store 获取，假设 storage_manager 管理着这些 store
            # 这里假设 active_store 已注册或可直接访问，根据原代码逻辑，retrieve 可能是一个封装方法
            # 原代码: pattern=self.storage_manager.retrieve(pattern_id)
            # 由于 _EventMetricMixin 没有 retrieve 方法，我们需要适配或假设 storage_manager 具备此能力
            # 但为了保持兼容，我们检查 active_store 是否有 retrieve 方法
            if hasattr(self.active_store, 'retrieve'):
                pattern = self.active_store.retrieve(pattern_id)
            else:
                pattern = None
        else:
            # 如果 storage_manager 有 retrieve 方法，优先使用
            if hasattr(self.storage_manager, 'retrieve'):
                pattern = self.storage_manager.retrieve(pattern_id)
            else:
                pattern = None
        
        if not pattern:
            logger.warning("模式未找到: %s", pattern_id)
            return {"applied": False, "reason": "not_found"}
        
        pattern.record_usage(True)
        result = {"applied": True, "pattern": pattern.name, "context": context}
        logger.debug("模式已应用: %s", pattern.name)
        return result

    def get_stats(self) -> Dict[str, Any]:
        """
        获取当前统计快照。

        Returns:
            统计信息字典。
        """
        return {
            "validated": self.validated_store.get_stats(),
            "active": self.active_store.get_stats(),
            "deprecated": self.deprecated_store.get_stats(),
            "retired": self.retired_store.get_stats(),
            "validator": self.validator.get_stats()
        }


_default_pc: Optional[PatternConsolidator] = None
_pc_lock = threading.Lock()

def get_pattern_consolidator() -> PatternConsolidator:
    """
    获取全局模式固化器单例。

    Returns:
        PatternConsolidator 实例。
    """
    global _default_pc
    with _pc_lock:
        if _default_pc is None:
            _default_pc = PatternConsolidator()
            logger.debug("已创建全局模式固化器实例")
        return _default_pc

__all__ = [
    "LearningPhase", "LearningType", "ConsolidationPhase", "PatternStatus",
    "LearningItem", "Pattern", "ErrorRecord", "ConsolidationRecord",
    "ValidatedPatternStore", "ActivePatternStore", "DeprecatedPatternStore",
    "RetiredPatternStore", "ConsolidationQueueStore", "PatternIndexStore",
    "PatternVersionStore", "PatternApplicationStore", "PatternFeedbackStore",
    "PatternAuditStore", "PatternValidator", "PatternStorageManager",
    "PatternIndexer", "PatternLifecycleManager", "PatternApplicationEngine",
    "PatternConsolidator", "get_pattern_consolidator"
]
