import logging
import os
import json
import random
import re
import time
from datetime import datetime, timedelta
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
from collections import defaultdict, Counter
from threading import RLock
from bisect import bisect_right
from redis import Redis

# 配置日志
logger = logging.getLogger("src.ximu.core.learning._pattern_consolidation_parts.part3")

# 常量定义
DEFAULT_MAX_ITEMS = 10000
DEFAULT_CACHE_SIZE = 500
TIME_DECAY_DAYS = 365.0
TIME_DECAY_MIN = 0.1
REDIS_HOST = 'localhost'
REDIS_PORT = 6379
REDIS_DB = 0

@dataclass
class LearningItem:
    """
    学习项数据模型，用于存储和管理学习内容。

    Attributes:
        item_id (str): 项目唯一标识符。
        content (str): 内容文本。
        tags (List[str]): 标签列表。
        store_type (str): 存储类型。
        category (str): 分类。
        type (str): 类型。
        source (str): 来源。
        created_at (datetime): 创建时间。
        updated_at (datetime): 更新时间。
        is_expired (bool): 是否过期。
    """
    item_id: str
    content: str
    tags: List[str] = field(default_factory=list)
    store_type: str = "general"
    category: str = "general"
    type: str = "general"
    source: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    isExpired: bool = False

    def __post_init__(self) -> None:
        """数据验证和初始化后置处理。"""
        if not self.item_id:
            self.item_id = generate_id("item")
        if not self.created_at:
            self.created_at = datetime.now()
        if not self.updated_at:
            self.updated_at = datetime.now()

def generate_id(prefix: str) -> str:
    """
    生成唯一标识符。

    Args:
        prefix (str): 前缀。

    Returns:
        str: 生成的唯一标识符。
    """
    return f"{prefix}-{random.randint(100000, 999999)}"

def now_timestamp() -> datetime:
    """
    获取当前时间戳。

    Returns:
        datetime: 当前时间。
    """
    return datetime.now()

def text_similarity(a: str, b: str) -> float:
    """
    计算两个文本的相似度（基于词集的Jaccard相似系数）。

    Args:
        a (str): 文本A。
        b (str): 文本B。

    Returns:
        float: 相似度分数 (0.0-1.0)。
    """
    if not a or not b:
        return 0.0
    sa, sb = set(a.split()), set(b.split())
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)

def score_stored_item(item: LearningItem, query: str, q_words: List[str]) -> float:
    """
    计算存储项与查询的匹配分数。

    Args:
        item (LearningItem): 学习项。
        query (str): 查询字符串。
        q_words (List[str]): 查询关键词列表。

    Returns:
        float: 匹配分数。
    """
    if not query:
        return 0.0

    # 基于内容相似度的基础分数
    content_score = text_similarity(query, item.content.lower())

    # 标签匹配分数
    tag_score = 0.0
    if item.tags:
        tag_set = {t.lower() for t in item.tags}
        query_tags = set(query.lower().split())
        common_tags = tag_set & query_tags
        if common_tags:
            tag_score = 0.5 * len(common_tags) / len(query_tags)

    # 时间衰减因子
    time_decay = 1.0
    if item.created_at:
        age_days = (datetime.now() - item.created_at).total_seconds() / 86400
        time_decay = max(TIME_DECAY_MIN, 1.0 - (age_days / TIME_DECAY_DAYS))

    # 综合评分
    score = 0.6 * content_score + 0.4 * tag_score
    score *= time_decay

    return min(1.0, score)

class PatternIndexStore:
    """
    基于内存的学习模式索引存储系统。

    支持多维度索引（标签/类型/来源）、LRU缓存和时效性衰减机制，实现高效的学习内容存储、检索与过期管理，支持并发访问。

    Attributes:
        max_items (int): 最大存储项数。
    """

    def __init__(self, max_items: int = DEFAULT_MAX_ITEMS) -> None:
        """
        初始化模式索引存储。

        Args:
            max_items (int): 最大存储项数。
        """
        self._items: Dict[str, LearningItem] = {}
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._type_index: Dict[str, Set[str]] = defaultdict(set)
        self._source_index: Dict[str, Set[str]] = defaultdict(set)
        self._time_heap: List[Tuple[datetime, str]] = []
        self._max = max_items
        self._lock = RLock()
        self._redis = Redis(host=REDIS_HOST, port=REDIS_PORT, db=REDIS_DB)
        self._stats: Dict[str, Any] = {
            "added": 0,
            "reads": 0,
            "deleted": 0,
            "updated": 0,
            "searches": 0,
            "cache_hits": 0,
            "cache_misses": 0,
        }
        self._query_cache: Dict[str, List[Tuple[LearningItem, float]]] = {}
        self._max_cache = DEFAULT_CACHE_SIZE
        logger.info(f"Initialized PatternIndexStore with max_items={max_items}")

    def _add_item(self, item: LearningItem) -> None:
        """
        内部方法：将单个学习项添加到索引中。

        Args:
            item (LearningItem): 要添加的学习项。
        """
        iid = item.item_id
        self._items[iid] = item

        # 更新标签索引
        for tag in item.tags:
            self._tag_index[tag.lower()].add(iid)

        # 更新类型索引
        itype = item.store_type if item.store_type else item.category
        self._type_index[itype].add(iid)

        # 更新来源索引
        if item.source:
            self._source_index[item.source].add(iid)

        # 更新时间堆（BTreeSet）
        self._time_heap.append((item.created_at, iid))
        self._time_heap.sort(reverse=True)

        self._stats["added"] += 1

    def _invalidate_cache(self) -> None:
        """使缓存失效。"""
        self._query_cache.clear()
        self._redis.flushall()

    def _evict_weakest(self) -> None:
        """
        驱逐最弱的项（基于创建时间）。
        """
        with self._lock:
            if not self._items:
                return

            evictable = []
            for iid, item in self._items.items():
                if not item.isExpired:
                    evictable.append((item.created_at, iid))

            if evictable:
                evictable.sort()
                oldest_iid = evictable[0][1]
                self.remove(oldest_iid)
                logger.debug(f"Evicted item: {oldest_iid}")

    def add(self, item: LearningItem) -> LearningItem:
        """
        添加学习项到存储。

        Args:
            item (LearningItem): 要添加的学习项。

        Returns:
            LearningItem: 添加后的学习项。
        """
        with self._lock:
            if len(self._items) >= self._max:
                self._evict_weakest()

            self._add_item(item)
            self._invalidate_cache()
            logger.debug(f"Added item: {item.item_id}")
            return item

    def batch_add(self, items: List[LearningItem]) -> List[LearningItem]:
        """
        批量添加学习项。

        Args:
            items (List[LearningItem]): 学习项列表。

        Returns:
            List[LearningItem]: 添加后的学习项列表。
        """
        with self._lock:
            results = []
            for item in items:
                if len(self._items) >= self._max:
                    self._evict_weakest()
                self._add_item(item)
                results.append(item)

            self._invalidate_cache()
            logger.info(f"Batch added {len(results)} items")
            return results

    def get(self, iid: str) -> Optional[LearningItem]:
        """
        根据ID获取学习项。

        Args:
            iid (str): 学习项ID。

        Returns:
            LearningItem or None: 学习项或None。
        """
        with self._lock:
            item = self._items.get(iid)
            if item:
                self._stats["reads"] += 1
            return item

    def get_or_default(self, iid: str, default: Any = None) -> Any:
        """
        根据ID获取学习项，若不存在则返回默认值。

        Args:
            iid (str): 学习项ID。
            default (Any): 默认值。

        Returns:
            Any: 学习项或默认值。
        """
        item = self.get(iid)
        return item if item is not None else default

    def remove(self, iid: str) -> bool:
        """
        移除学习项。

        Args:
            iid (str): 学习项ID。

        Returns:
            bool: 是否成功移除。
        """
        with self._lock:
            item = self._items.pop(iid, None)
            if item:
                # 清理索引
                for tag in item.tags:
                    self._tag_index[tag.lower()].discard(iid)

                itype = item.store_type if item.store_type else item.category
                self._type_index[itype].discard(iid)

                if item.source:
                    self._source_index[item.source].discard(iid)

                self._stats["deleted"] += 1
                self._invalidate_cache()
                logger.debug(f"Removed item: {iid}")
                return True
            return False

    def batch_remove(self, iids: List[str]) -> int:
        """
        批量移除学习项。

        Args:
            iids (List[str]): 学习项ID列表。

        Returns:
            int: 成功移除的数量。
        """
        with self._lock:
            removed_count = 0
            for iid in iids:
                if self.remove(iid):
                    removed_count += 1

            if removed_count > 0:
                self._invalidate_cache()
                logger.info(f"Batch removed {removed_count} items")
            return removed_count

    def update(self, iid: str, **kwargs: Any) -> bool:
        """
        更新学习项属性。

        Args:
            iid (str): 学习项ID。
            **kwargs: 要更新的属性键值对。

        Returns:
            bool: 是否成功更新。
        """
        with self._lock:
            item = self._items.get(iid)
            if not item:
                logger.warning(f"Item not found for update: {iid}")
                return False

            # 保存旧标签、类型、来源
            old_tags = item.tags.copy()
            old_type = item.store_type if item.store_type else item.category
            old_source = item.source

            # 更新属性
            for k, v in kwargs.items():
                if hasattr(item, k):
                    setattr(item, k, v)
            item.updated_at = now_timestamp()

            # 更新标签索引
            for tag in old_tags:
                self._tag_index[tag.lower()].discard(iid)
            for tag in item.tags:
                self._tag_index[tag.lower()].add(iid)

            # 更新类型索引
            if old_type != (itype := item.store_type if item.store_type else item.category):
                self._type_index[old_type].discard(iid)
                self._type_index[itype].add(iid)

            # 更新来源索引
            if old_source != (source := item.source):
                if old_source:
                    self._source_index[old_source].discard(iid)
                if source:
                    self._source_index[source].add(iid)

            self._stats["updated"] += 1
            self._invalidate_cache()
            logger.debug(f"Updated item: {iid}")
            return True

    def contains(self, iid: str) -> bool:
        """
        检查学习项是否存在。

        Args:
            iid (str): 学习项ID。

        Returns:
            bool: 是否存在。
        """
        with self._lock:
            return iid in self._items

    def search(
        self,
        query: str,
        limit: int = 20,
        category: str = "",
        tags: Optional[List[str]] = None,
        min_score: float = 0.0,
    ) -> List[Tuple[LearningItem, float]]:
        """
        执行搜索。

        Args:
            query (str): 查询字符串。
            limit (int): 结果数量限制。
            category (str): 分类过滤。
            tags (List[str]): 标签过滤。
            min_score (float): 最小分数阈值。

        Returns:
            List[Tuple[LearningItem, float]]: 搜索结果列表，包含学习项和分数。
        """
        with self._lock:
            cache_key = f"{query}:{category}:{tuple(tags or [])}:{min_score}:{limit}"
            if cache_key in self._query_cache:
                self._stats["cache_hits"] += 1
                self._query_cache.move_to_end(cache_key)
                return self._query_cache[cache_key]

            self._stats["cache_misses"] += 1
            self._stats["searches"] += 1

            q = query.lower().strip()
            cids = set(self._items.keys())

            # 分类过滤
            if category:
                cids &= self._type_index.get(category, set())

            # 标签过滤
            if tags:
                tids = set()
                for t in tags:
                    tids.update(self._tag_index.get(t.lower(), set()))
                cids &= tids

            # 计算分数
            scored = []
            q_words = q.split()
            for iid in cids:
                item = self._items[iid]
                s = score_stored_item(item, q, q_words)
                if s > min_score:
                    scored.append((s, item))

            # 排序并限制结果
            scored.sort(key=lambda x: x[0], reverse=True)
            result = [(item, s) for s, item in scored[:limit]]

            # 更新缓存
            self._query_cache[cache_key] = result
            if len(self._query_cache) > self._max_cache:
                self._query_cache.popitem(last=False)

            logger.debug(f"Search query: {query}, results: {len(result)}")
            return result

    def fuzzy_search(self, query: str, threshold: float = 0.6, limit: int = 20) -> List[Tuple[LearningItem, float]]:
        """
        模糊搜索（基于文本相似度）。

        Args:
            query (str): 查询字符串。
            threshold (float): 相似度阈值。
            limit (int): 结果数量限制。

        Returns:
            List[Tuple[LearningItem, float]]: 搜索结果列表，包含学习项和分数。
        """
        with self._lock:
            q = query.lower()
            scored = []
            for iid, item in self._items.items():
                content = item.content.lower()
                s = text_similarity(q, content)
                if s >= threshold:
                    scored.append((s, item))

            scored.sort(key=lambda x: x[0], reverse=True)
            result = [(item, s) for s, item in scored[:limit]]
            logger.debug(f"Fuzzy search query: {query}, results: {len(result)}")
            return result

    def regex_search(self, pattern: str, limit: int = 20) -> List[LearningItem]:
        """
        正则表达式搜索。

        Args:
            pattern (str): 正则表达式。
            limit (int): 结果数量限制。

        Returns:
            List[LearningItem]: 匹配的学习项列表。
        """
        with self._lock:
            try:
                rx = re.compile(pattern, re.IGNORECASE)
            except re.error as e:
                logger.error(f"Invalid regex pattern: {pattern}, error: {e}")
                return []

            result = []
            for iid, item in self._items.items():
                content = item.content
                if rx.search(content):
                    result.append(item)
                    if len(result) >= limit:
                        break

            logger.debug(f"Regex search pattern: {pattern}, results: {len(result)}")
            return result

    def cleanupExpired(self) -> int:
        """
        清理过期项。

        Returns:
            int: 清理的项数。
        """
        with self._lock:
            now = now_timestamp()
            cutoff = now - timedelta(days=TIME_DECAY_DAYS)
            expired_count = 0

            # 使用BTreeSet按时间排序，快速删除过期项
            cutoff_ts = cutoff.timestamp()
            for ts, iid in self._time_heap:
                if ts <= cutoff_ts:
                    self._time_heap.remove((ts, iid))
                    self.remove(iid)
                    expired_count += 1
                else:
                    break  # BTreeSet按时间排序，后续均不过期

            logger.info(f"Cleaned up {expired_count} expired items")
            return expired_count

    def batch_get(self, iids: List[str]) -> List[LearningItem]:
        """
        批量获取学习项。

        Args:
            iids (List[str]): 学习项ID列表。

        Returns:
            List[LearningItem]: 学习项列表。
        """
        with self._lock:
            results = []
            for iid in iids:
                item = self._items.get(iid)
                if item:
                    self._stats["reads"] += 1
                    results.append(item)
            logger.debug(f"Batch got {len(results)} items")
            return results

    def filter_by(self, predicate: Callable[[LearningItem], bool], limit: int = 100) -> List[LearningItem]:
        """
        根据谓词过滤学习项。

        Args:
            predicate (Callable[[LearningItem], bool]): 过滤谓词。
            limit (int): 结果数量限制。

        Returns:
            List[LearningItem]: 过滤后的学习项列表。
        """
        with self._lock:
            result = []
            for iid, item in self._items.items():
                if predicate(item):
                    result.append(item)
                    if len(result) >= limit:
                        break

            logger.debug(f"Filtered {len(result)} items")
            return result

    def map_items(self, func: Callable[[LearningItem], Any]) -> Dict[str, Any]:
        """
        映射学习项。

        Args:
            func (Callable[[LearningItem], Any]): 映射函数。

        Returns:
            Dict[str, Any]: 映射结果字典。
        """
        with self._lock:
            result = {iid: func(item) for iid, item in self._items.items()}
            logger.debug(f"Mapped {len(result)} items")
            return result

    def reduce_items(self, func: Callable[[Any, LearningItem], Any], initial: Any = None) -> Any:
        """
        归约学习项。

        Args:
            func (Callable[[Any, LearningItem], Any]): 归约函数。
            initial (Any): 初始值。

        Returns:
            Any: 归约结果。
        """
        with self._lock:
            result = initial
            for item in self._items.values():
                if result is None:
                    result = item
                else:
                    result = func(result, item)
            logger.debug("Reduced items")
            return result

    def get_random(self, n: int = 1) -> List[LearningItem]:
        """
        获取随机学习项。

        Args:
            n (int): 数量。

        Returns:
            List[LearningItem]: 随机学习项列表。
        """
        with self._lock:
            items = list(self._items.values())
            if not items:
                return []
            result = random.sample(items, min(n, len(items)))
            logger.debug(f"Got {len(result)} random items")
            return result

    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息。

        Returns:
            Dict[str, Any]: 统计信息字典。
        """
        with self._lock:
            types = Counter(
                item.store_type if item.store_type else item.category
                for item in self._items.values()
            )
            total_cache = self._stats["cache_hits"] + self._stats["cache_misses"]
            stats = {
                "total": len(self._items),
                "max": self._max,
                "added": self._stats["added"],
                "reads": self._stats["reads"],
                "deleted": self._stats["deleted"],
                "updated": self._stats["updated"],
                "searches": self._stats["searches"],
                "cache_hits": self._stats["cache_hits"],
                "cache_misses": self._stats["cache_misses"],
                "cache_hit_rate": self._stats["cache_hits"] / max(1, total_cache),
                "types": dict(types),
                "tags": len(self._tag_index),
                "sources": len(self._source_index),
            }
            logger.debug(f"Got stats: {stats}")
            return stats

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典。

        Returns:
            Dict[str, Any]: 字典表示。
        """
        with self._lock:
            result = {iid: asdict(item) for iid, item in self._items.items()}
            logger.debug(f"Converted to dict, size: {len(result)}")
            return result

    def export_json(self, filepath: str) -> None:
        """
        导出为JSON文件。

        Args:
            filepath (str): 文件路径。
        """
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(self.to_dict(), f, ensure_ascii=False, default=str)
            logger.info(f"Exported to JSON: {filepath}")
        except Exception as e:
            logger.error(f"Failed to export JSON to {filepath}: {e}")
            raise

    def import_json(self, filepath: str) -> int:
        """
        从JSON文件导入。

        Args:
            filepath (str): 文件路径。

        Returns:
            int: 导入的项目数量。
        """
        if not os.path.exists(filepath):
            logger.warning(f"File not found: {filepath}")
            return 0

        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)

            count = 0
            for iid, item_data in data.items():
                if isinstance(item_data, dict):
                    item_data.setdefault("item_id", iid)
                    item = LearningItem(**item_data)
                    self.add(item)
                    count += 1

            logger.info(f"Imported {count} items from JSON: {filepath}")
            return count
        except Exception as e:
            logger.error(f"Failed to import JSON from {filepath}: {e}")
            raise


class PatternApplicationStore:
    """PatternApplicationStore。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)

    def delete(self, key):
        self._data.pop(key, None)


class PatternAuditStore:
    """PatternAuditStore - 模式审计存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)

    def delete(self, key):
        self._data.pop(key, None)


class PatternFeedbackStore:
    """PatternFeedbackStore - 模式反馈存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)

    def delete(self, key):
        self._data.pop(key, None)


class PatternVersionStore:
    """PatternVersionStore - 模式版本存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)

    def delete(self, key):
        self._data.pop(key, None)
