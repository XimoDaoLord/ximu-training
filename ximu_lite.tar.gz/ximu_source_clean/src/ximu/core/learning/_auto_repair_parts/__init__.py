"""
自动修复零部件学习模块。

该模块提供了自动修复零部件的学习功能，包括数据预处理、特征提取和模型训练。
"""

from typing import Dict, List, Optional
import logging
import os
import json
from src.ximu.core.learning.base import BaseLearningModule
from src.ximu.core.learning.utils import load_data, save_model

logger = logging.getLogger(__name__)

class AutoRepairParts(BaseLearningModule):
    """
    自动修复零部件学习模块。

    Attributes:
        model_path (str): 模型保存路径。
        data_path (str): 数据保存路径。
        feature_extractor (str): 特征提取器类型。
        model (str): 模型类型。
    """

    def __init__(self, model_path: str, data_path: str, feature_extractor: str, model: str):
        """
        初始化自动修复零部件学习模块。

        Args:
            model_path (str): 模型保存路径。
            data_path (str): 数据保存路径。
            feature_extractor (str): 特征提取器类型。
            model (str): 模型类型。
        """
        super().__init__()
        self.model_path = model_path
        self.data_path = data_path
        self.feature_extractor = feature_extractor
        self.model = model

    def load_data(self) -> Dict[str, List]:
        """
        加载数据。

        Returns:
            Dict[str, List]: 数据字典。
        """
        logger.info("Loading data...")
        data = load_data(self.data_path)
        logger.info("Data loaded successfully.")
        return data

    def extract_features(self, data: Dict[str, List]) -> Dict[str, List]:
        """
        提取特征。

        Args:
            data (Dict[str, List]): 数据字典。

        Returns:
            Dict[str, List]: 特征字典。
        """
        logger.info("Extracting features...")
        features = self.feature_extractor.extract_features(data)
        logger.info("Features extracted successfully.")
        return features

    def train_model(self, features: Dict[str, List]) -> None:
        """
        训练模型。

        Args:
            features (Dict[str, List]): 特征字典。
        """
        logger.info("Training model...")
        model = self.model.train(features)
        logger.info("Model trained successfully.")
        save_model(model, self.model_path)

    def predict(self, data: Dict[str, List]) -> Dict[str, List]:
        """
        预测。

        Args:
            data (Dict[str, List]): 数据字典。

        Returns:
            Dict[str, List]: 预测结果字典。
        """
        logger.info("Predicting...")
        features = self.extract_features(data)
        model = load_model(self.model_path)
        predictions = model.predict(features)
        logger.info("Predictions made successfully.")
        return predictions

def load_model(model_path: str) -> object:
    """
    加载模型。

    Args:
        model_path (str): 模型保存路径。

    Returns:
        object: 模型对象。
    """
    logger.info("Loading model...")
    with open(model_path, "r") as f:
        model = json.load(f)
    logger.info("Model loaded successfully.")
    return model

def save_model(model: object, model_path: str) -> None:
    """
    保存模型。

    Args:
        model (object): 模型对象。
        model_path (str): 模型保存路径。
    """
    logger.info("Saving model...")
    with open(model_path, "w") as f:
        json.dump(model, f)
    logger.info("Model saved successfully.")
