import re
import logging
from collections import defaultdict, Counter
from typing import Dict, Any, Optional, Callable
from math import log, sqrt

# 日志配置
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TextSimilarity:
    """文本相似度计算器，支持Jaccard和TF-IDF算法动态切换"""
    
    def __init__(self) -> None:
        """初始化相似度计算器，注册默认算法"""
        self._algorithm_registry: Dict[str, Callable[[str, str], float]] = {}
        self._current_algorithm = "jaccard"
        self._register_default_algorithms()
    
    def _register_default_algorithms(self) -> None:
        """注册默认的Jaccard和TF-IDF相似度算法"""
        self.register_algorithm("jaccard", self._jaccard_similarity)
        self.register_algorithm("tfidf", self._tfidf_similarity)
    
    def register_algorithm(self, algo_name: str, algo_func: Callable[[str, str], float]) -> None:
        """注册自定义相似度算法
        
        Args:
            algo_name: 算法名称
            algo_func: 算法函数，接受两个字符串参数并返回相似度分数
        Raises:
            ValueError: 当算法名已存在或函数不可调用时
        """
        if not callable(algo_func):
            raise ValueError("算法函数必须可调用")
        if algo_name in self._algorithm_registry:
            raise ValueError(f"算法 {algo_name} 已注册")
        
        logger.info(f"注册新算法: {algo_name}")
        self._algorithm_registry[algo_name] = algo_func
    
    def set_algorithm(self, algo: str) -> None:
        """设置当前使用的相似度算法
        
        Args:
            algo: 算法名称
        Raises:
            ValueError: 当算法未注册时
        """
        if algo not in self._algorithm_registry:
            raise ValueError(f"算法 {algo} 未注册")
        self._current_algorithm = algo
        logger.info(f"切换到算法: {algo}")
    
    def _preprocess_text(self, text: str) -> list:
        """统一文本预处理逻辑
        
        Args:
            text: 原始文本
        Returns:
            分词后的列表
        """
        if not text or not text.strip():
            return []
        # 匹配单词、数字和标点符号
        return re.findall(r'\b[\w\d]+\b|[\u4e00-\u9fff]', text)
    
    def _jaccard_similarity(self, a: str, b: str) -> float:
        """基于Jaccard系数的文本相似度计算
        
        Args:
            a: 第一个文本
            b: 第二个文本
        Returns:
            Jaccard相似度分数 [0, 1]
        """
        a_terms = set(self._preprocess_text(a))
        b_terms = set(self._preprocess_text(b))
        
        if not a_terms and not b_terms:
            return 0.0
            
        intersection = len(a_terms & b_terms)
        union = len(a_terms | b_terms)
        
        similarity = intersection / union if union != 0 else 0.0
        logger.debug(f"Jaccard相似度计算完成: {similarity:.4f}")
        return similarity
    
    def _tfidf_similarity(self, a: str, b: str) -> float:
        """基于TF-IDF的文本相似度计算
        
        Args:
            a: 第一个文本
            b: 第二个文本
        Returns:
            TF-IDF余弦相似度分数 [0, 1]
        """
        a_terms = self._preprocess_text(a)
        b_terms = self._preprocess_text(b)
        
        if not a_terms or not b_terms:
            return 0.0
        
        # 计算词频和文档频率
        total_docs = 2
        all_terms = a_terms + b_terms
        doc_freq = Counter(all_terms)
        
        # 计算IDF
        idf = {term: log(total_docs / (1 + doc_freq[term])) 
               for term in set(all_terms)}
        
        # 计算TF
        tf_a = Counter(a_terms)
        tf_b = Counter(b_terms)
        
        # 计算TF-IDF向量
        tfidf_a = {term: (tf_a[term] / len(a_terms)) * idf[term] for term in tf_a}
        tfidf_b = {term: (tf_b[term] / len(b_terms)) * idf[term] for term in tf_b}
        
        # 计算余弦相似度
        common_terms = set(tfidf_a.keys()) & set(tfidf_b.keys())
        
        # 点积
        dot_product = sum(tfidf_a[term] * tfidf_b[term] for term in common_terms)
        
        # 模长
        magnitude_a = sqrt(sum(val ** 2 for val in tfidf_a.values()))
        magnitude_b = sqrt(sum(val ** 2 for val in tfidf_b.values()))
        
        denominator = magnitude_a * magnitude_b
        similarity = dot_product / denominator if denominator != 0 else 0.0
        
        logger.debug(f"TF-IDF相似度计算完成: {similarity:.4f}")
        return similarity
    
    def calculate_similarity(self, text1: str, text2: str) -> float:
        """统一计算接口
        
        Args:
            text1: 第一个文本
            text2: 第二个文本
        Returns:
            相似度分数
        Raises:
            ValueError: 当算法未正确注册时
        """
        algo_func = self._algorithm_registry.get(self._current_algorithm)
        if not algo_func:
            raise ValueError(f"算法 {self._current_algorithm} 未正确注册")
        
        result = algo_func(text1, text2)
        logger.info(f"使用算法 {self._current_algorithm} 计算相似度: {result:.4f}")
        return result
