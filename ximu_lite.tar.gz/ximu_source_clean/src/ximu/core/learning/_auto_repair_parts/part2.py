import logging
from typing import Any, Callable, Dict, List
from collections import defaultdict, deque
from threading import RLock
import json
import os
from src.ximu.common.utils import generate_id, now_timestamp

logger = logging.getLogger(__name__)

class AbstractRegistry:
    """
    提供通用的注册管理框架，支持多存储注册、事件驱动、指标跟踪、自动维护和状态持久化
    """
    def __init__(self, **kwargs):
        """
        初始化注册管理器
        :param kwargs: 配置参数
        """
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = RLock()
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=500)
        self._initialized = False
        self._last_maintenance = 0.0
        self._maintenance_interval = 300.0

    def register_store(self, name: str, store_obj: Any) -> None:
        """
        注册存储对象
        :param name: 存储对象名称
        :param store_obj: 存储对象实例
        """
        with self._lock:
            self._stores[name] = store_obj
            self._emit("store_registered", {"name": name})

    def get_store(self, name: str) -> Any:
        """
        获取存储对象
        :param name: 存储对象名称
        :return: 存储对象实例
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """
        移除存储对象
        :param name: 存储对象名称
        :return: 是否成功移除
        """
        with self._lock:
            s = self._stores.pop(name, None)
            if s:
                self._emit("store_removed", {"name": name})
            return s is not None

    def on(self, event: str, handler: Callable) -> None:
        """
        添加事件处理程序
        :param event: 事件名称
        :param handler: 事件处理程序
        """
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable) -> None:
        """
        移除事件处理程序
        :param event: 事件名称
        :param handler: 事件处理程序
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Dict[str, Any] = None) -> None:
        """
        发送事件
        :param event: 事件名称
        :param data: 事件数据
        """
        handlers = self._event_handlers.get(event, [])
        for h in handlers:
            try:
                h(data or {})
            except Exception as e:
                logger.debug("Operation failed: %s", e, exc_info=True)

    def record_metric(self, name: str, value: float) -> None:
        """
        记录指标
        :param name: 指标名称
        :param value: 指标值
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({"metric": name, "value": value, "timestamp": now_timestamp()})

    def get_metric(self, name: str) -> float:
        """
        获取指标
        :param name: 指标名称
        :return: 指标值
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """
        获取所有指标
        :return: 指标字典
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        """
        重置指标
        """
        with self._lock:
            self._metrics.clear()

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取历史记录
        :param limit: 限制条数
        :return: 历史记录列表
        """
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """
        初始化注册管理器
        :return: 是否成功初始化
        """
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._emit("initialized", {})
            return True

    def shutdown(self) -> bool:
        """
        关闭注册管理器
        :return: 是否成功关闭
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            self._emit("shutdown", {})
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """
        进行维护
        :param force: 是否强制维护
        :return: 维护结果
        """
        with self._lock:
            now = now_timestamp()
            if not force and now - self._last_maintenance < self._maintenance_interval:
                return {"status": "skipped"}
            cleaned = 0
            for name, s in self._stores.items():
                if hasattr(s, "cleanup_expired"):
                    try:
                        cleaned += s.cleanup_expired()
                    except Exception as e:
                        logger.debug("Operation failed: %s", e, exc_info=True)
            self._last_maintenance = now
            self._emit("maintenance", {"cleaned": cleaned})
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息
        :return: 统计信息字典
        """
        with self._lock:
            store_stats = {}
            for name, s in self._stores.items():
                if hasattr(s, "get_stats"):
                    try:
                        store_stats[name] = s.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(s, "size"):
                    store_stats[name] = {"size": s.size()}
            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history)
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        序列化注册管理器状态
        :return: 序列化状态字典
        """
        with self._lock:
            return {
                "config": dict(self._config),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys())
            }

    def export_state(self, filepath: str) -> None:
        """
        导出注册管理器状态
        :param filepath: 导出文件路径
        """
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, default=str)

    def import_state(self, filepath: str) -> bool:
        """
        导入注册管理器状态
        :param filepath: 导入文件路径
        :return: 是否成功导入
        """
        if not os.path.exists(filepath):
            return False
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        with self._lock:
            if "config" in data:
                self._config.update(data["config"])
            if "metrics" in data:
                self._metrics.update(data["metrics"])
            return True


class RepairRegistry(AbstractRegistry):
    """
    修复注册管理器
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def register_planner(self, name: str, planner_obj: Any) -> None:
        """
        注册规划器
        :param name: 规划器名称
        :param planner_obj: 规划器实例
        """
        self.register_store(name, planner_obj)

    def get_planner(self, name: str) -> Any:
        """
        获取规划器
        :param name: 规划器名称
        :return: 规划器实例
        """
        return self.get_store(name)

    def remove_planner(self, name: str) -> bool:
        """
        移除规划器
        :param name: 规划器名称
        :return: 是否成功移除
        """
        return self.remove_store(name)

    def register_executor(self, name: str, executor_obj: Any) -> None:
        """
        注册执行器
        :param name: 执行器名称
        :param executor_obj: 执行器实例
        """
        self.register_store(name, executor_obj)

    def get_executor(self, name: str) -> Any:
        """
        获取执行器
        :param name: 执行器名称
        :return: 执行器实例
        """
        return self.get_store(name)

    def remove_executor(self, name: str) -> bool:
        """
        移除执行器
        :param name: 执行器名称
        :return: 是否成功移除
        """
        return self.remove_store(name)

    def register_verifier(self, name: str, verifier_obj: Any) -> None:
        """
        注册验证器
        :param name: 验证器名称
        :param verifier_obj: 验证器实例
        """
        self.register_store(name, verifier_obj)

    def get_verifier(self, name: str) -> Any:
        """
        获取验证器
        :param name: 验证器名称
        :return: 验证器实例
        """
        return self.get_store(name)

    def remove_verifier(self, name: str) -> bool:
        """
        移除验证器
        :param name: 验证器名称
        :return: 是否成功移除
        """
        return self.remove_store(name)

    def register_rollback(self, name: str, rollback_obj: Any) -> None:
        """
        注册回滚器
        :param name: 回滚器名称
        :param rollback_obj: 回滚器实例
        """
        self.register_store(name, rollback_obj)

    def get_rollback(self, name: str) -> Any:
        """
        获取回滚器
        :param name: 回滚器名称
        :return: 回滚器实例
        """
        return self.get_store(name)

    def remove_rollback(self, name: str) -> bool:
        """
        移除回滚器
        :param name: 回滚器名称
        :return: 是否成功移除
        """
        return self.remove_store(name)
