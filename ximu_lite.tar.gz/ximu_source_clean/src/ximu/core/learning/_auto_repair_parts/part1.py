import logging
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from threading import Lock
from typing import Any, Dict, List, Optional

logger = logging.getLogger("src.ximu.core.learning._auto_repair_parts.part1")

# ============================================================================ # 工具函数 # ============================================================================

def generate_id(prefix: str = "id") -> str:
    """
    生成具有唯一标识符的ID。

    Args:
    prefix: 前缀字符串，用于标识不同类别的ID。

    Returns:
    生成的唯一ID字符串。
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"

def now_timestamp() -> float:
    """
    获取当前时间戳。

    Returns:
    当前Unix时间戳（秒）。
    """
    return time.time()

def now_datetime() -> datetime:
    """
    获取当前带时区的时间对象。

    Returns:
    当前时间对象，时区为东八区。
    """
    return datetime.now(timezone(timedelta(hours=8)))

def format_datetime(dt: Optional[datetime] = None, fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    格式化时间对象为字符串。

    Args:
    dt: 时间对象，默认为当前时间。
    fmt: 格式化字符串，默认为标准格式。

    Returns:
    格式化后的时间字符串。
    """
    if dt is None:
        dt = now_datetime()
    return dt.strftime(fmt)

class Stopwatch:
    """
    简单的计时器类，支持上下文管理器模式。
    """

    def __init__(self) -> None:
        """
        初始化计时器。
        """
        self._start_time: float = 0.0

    def __enter__(self) -> "Stopwatch":
        """
        开始计时。

        Returns:
        自身实例，支持上下文管理器模式。
        """
        self._start_time = time.time()
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        """
        停止计时。

        Returns:
        自身实例，支持上下文管理器模式。
        """
        self._end_time = time.time()
        logger.debug("计时结束，耗时：%s毫秒", (self._end_time - self._start_time) * 1000)

    @property
    def elapsed_ms(self) -> float:
        """
        已耗时的毫秒数。

        Returns:
        从开始到结束（或当前）的毫秒数。
        """
        return (self._end_time - self._start_time) * 1000 if self._end_time else 0.0

# ============================================================================ # 枚举定义 # ============================================================================

class LearningPhase(Enum):
    """
    学习阶段枚举。
    """
    PERCEPTION = "perception"
    ENCODING = "encoding"
    CONSOLIDATION = "consolidation"
    APPLICATION = "application"
    FEEDBACK = "feedback"
    EVOLUTION = "evolution"

class LearningType(Enum):
    """
    学习类型枚举。
    """
    SUPERVISED = "supervised"
    UNSUPERVISED = "unsupervised"
    REINFORCEMENT = "reinforcement"
    ONLINE = "online"
    OFFLINE = "offline"
    TRANSFER = "transfer"
    META = "meta"

class RepairType(Enum):
    """
    修复类型枚举。
    """
    SELF_HEAL = "self_heal"
    PATCH = "patch"
    RECONFIGURE = "reconfigure"
    RESTART = "restart"
    ROLLBACK = "rollback"
    FALLBACK = "fallback"
    REBUILD = "rebuild"

class DiagnosisStatus(Enum):
    """
    诊断状态枚举。
    """
    PENDING = "pending"
    DIAGNOSING = "diagnosing"
    IDENTIFIED = "identified"
    REPAIRING = "repairing"
    VERIFIED = "verified"
    FAILED = "failed"

class RepairStatus(Enum):
    """
    修复状态枚举。
    """
    PLANNED = "planned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"
    VERIFIED = "verified"

# ============================================================================ # 数据模型 # ============================================================================

@dataclass
class LearningItemConfig:
    """
    学习项配置类，用于定义学习项的属性。
    属性：
    content: 学习内容
    store_type: 存储类型
    category: 分类
    source: 来源
    tags: 标签列表
    importance: 重要性（0-1）
    weight: 权重
    confidence: 置信度（0-1）
    metadata: 扩展元数据
    permanent: 是否永久存储
    expiration: 过期时间戳，None表示永不过期
    """
    content: str = ""
    store_type: str = "general"
    category: str = ""
    source: str = ""
    tags: List[str] = field(default_factory=list)
    importance: float = 0.5
    weight: float = 1.0
    confidence: float = 0.5
    metadata: Dict[str, Any] = field(default_factory=dict)
    permanent: bool = False
    expiration: Optional[float] = None

@dataclass
class LearningItem:
    """
    学习项数据模型，表示一个可被学习和存储的知识单元。
    属性：
    item_id: 唯一标识符
    config: 学习项配置
    created_at: 创建时间戳
    updated_at: 更新时间戳
    last_accessed: 最后访问时间戳
    access_count: 访问次数
    """
    item_id: str = field(default_factory=lambda: generate_id("item"))
    config: LearningItemConfig = field(default_factory=LearningItemConfig)
    created_at: float = field(default_factory=now_timestamp)
    updated_at: float = field(default_factory=now_timestamp)
    last_accessed: float = field(default_factory=now_timestamp)
    access_count: int = 0

    def access(self) -> None:
        """
        记录一次访问，更新访问时间和计数。
        """
        self.last_accessed = now_timestamp()
        self.access_count += 1

    def is_expired(self) -> bool:
        """
        检查学习项是否已过期。

        Returns:
        如果已过期返回True，否则返回False。
        """
        return now_timestamp() > self.config.expiration

    def set_expiration(self, expiration_time: Optional[float]) -> None:
        """
        设置过期时间。

        Args:
        expiration_time: 过期时间戳，None表示取消过期限制。
        """
        self.config.expiration = expiration_time
        logger.debug("学习项 %s 设置过期时间为 %s", self.item_id, expiration_time)

    def get_strength(self) -> float:
        """
        计算学习项的强度值。
        强度由访问频率、置信度和重要性综合计算得出，并乘以权重。

        Returns:
        强度值。
        """
        access_factor = min(1.0, self.access_count / 20.0)
        base = 0.3 + 0.3 * access_factor + 0.2 * self.config.confidence + 0.2 * self.config.importance
        return base * self.config.weight

    def to_dict(self) -> Dict[str, Any]:
        """
        将学习项转换为字典格式。

        Returns:
        包含所有字段的字典。
        """
        return asdict(self)

# ============================================================================ # LRU缓存实现 # ============================================================================

class _LRUNode:
    """
    LRU缓存链表节点，使用__slots__优化内存占用。
    """

    __slots__ = ["key", "value", "prev", "next"]

    def __init__(self, key: str, value: Any) -> None:
        """
        初始化节点。

        Args:
        key: 缓存键。
        value: 缓存值。
        """
        self.key = key
        self.value = value
        self.prev: Optional["_LRUNode"] = None
        self.next: Optional["_LRUNode"] = None

class _LRUCache:
    """
    线程安全的LRU（最近最少使用）缓存实现。
    使用双向链表和哈希表结合的方式实现O(1)的get和put操作。
    """

    def __init__(self, capacity: int) -> None:
        """
        初始化LRU缓存。

        Args:
        capacity: 缓存容量。
        """
        if capacity <= 0:
            raise ValueError("缓存容量必须为正整数")
        self.capacity: int = capacity
        self._cache: Dict[str, _LRUNode] = {}
        self._head: _LRUNode = _LRUNode("head", None)
        self._tail: _LRUNode = _LRUNode("tail", None)
        self._head.next = self._tail
        self._tail.prev = self._head
        self._lock: Lock = Lock()

    def _add_to_head(self, node: _LRUNode) -> None:
        """
        将节点添加到链表头部（最近使用端）。

        Args:
        node: 要添加的节点。
        """
        node.prev = self._head
        node.next = self._head.next
        self._head.next.prev = node
        self._head.next = node

    def _remove_node(self, node: _LRUNode) -> None:
        """
        从链表中移除节点。

        Args:
        node: 要移除的节点。
        """
        prev_node = node.prev
        next_node = node.next
        if prev_node:
            prev_node.next = next_node
        if next_node:
            next_node.prev = prev_node

    def get(self, key: str) -> Optional[Any]:
        """
        获取缓存值。

        Args:
        key: 缓存键。

        Returns:
        缓存值，如果不存在返回None。
        """
        with self._lock:
            if key not in self._cache:
                return None
            node = self._cache[key]
            self._remove_node(node)
            self._add_to_head(node)
            logger.debug("LRU缓存命中: key=%s", key)
            return node.value

    def put(self, key: str, value: Any) -> None:
        """
        设置缓存值。

        Args:
        key: 缓存键。
        value: 缓存值。
        """
        with self._lock:
            if key in self._cache:
                node = self._cache[key]
                node.value = value
                self._remove_node(node)
                self._add_to_head(node)
                logger.debug("LRU缓存更新: key=%s", key)
            else:
                if len(self._cache) >= self.capacity:
                    lru_node = self._tail.prev
                    if lru_node:
                        self._remove_node(lru_node)
                        del self._cache[lru_node.key]
                        logger.debug("LRU缓存淘汰: key=%s", lru_node.key)
                node = _LRUNode(key, value)
                self._cache[key] = node
                self._add_to_head(node)
                logger.debug("LRU缓存新增: key=%s", key)

    def clear(self) -> None:
        """
        清空缓存。
        """
        with self._lock:
            self._cache.clear()
            self._head.next = self._tail
            self._tail.prev = self._head
            logger.debug("LRU缓存已清空")

    def __len__(self) -> int:
        """
        返回缓存中的元素数量。

        Returns:
        当前缓存元素数量。
        """
        with self._lock:
            return len(self._cache)

    def __contains__(self, key: str) -> bool:
        """
        检查键是否存在于缓存中。

        Args:
        key: 要检查的键。

        Returns:
        如果存在返回True，否则返回False。
        """
        with self._lock:
            return key in self._cache
