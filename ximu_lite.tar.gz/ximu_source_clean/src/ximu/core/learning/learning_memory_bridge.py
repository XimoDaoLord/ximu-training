# -*- coding: utf-8 -*-
"""学习 ↔ 记忆联动桥接模块。

职责：
1. 学习系统学到的经验（成功/失败）自动写入长期记忆。
2. 记忆系统召回时自动带上学习到的经验。
3. 同类错误发生时，先从记忆召回历史错误避免重蹈覆辙。
4. 成功经验自动存入长期记忆供后续任务复用。

调用方式：
    from src.ximu.core.learning.learning_memory_bridge import LearningMemoryBridge
    bridge = LearningMemoryBridge()
    bridge.record_success(task_type, summary)
    bridge.record_failure(task_type, error)
    tips = bridge.recall_lessons(task_type)
"""
import logging
import os
import time
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

# 版本号
__version__ = "0.5"


class LearningMemoryBridge:
    """学习经验与记忆系统的双向桥接。"""

    def __init__(self, memory_engine=None):
        """
        初始化学习记忆桥接器。

        Args:
            memory_engine: 可选的记忆引擎实例，若为 None 则延迟初始化默认引擎。
        """
        self._mem = memory_engine
        self._initialized = False
        # 【第二轮性能优化·模块6】同步落盘节流：
        # 原实现每次 record_failure/record_success 都同步 flush_now() 全量原子 fsync。
        # 但 add_memory 内部已设置 dirty=True 并调度 500ms 防抖合并刷盘（外加定时兜底），
        # 连续失败时每次都强制 fsync 整库 → 实测单条 record_failure 达 ~669ms（fsync 风暴+锁竞争）。
        # 优化：时间窗口内首次写入仍立即 fsync（保持 kill-9 耐久语义），窗口内后续写入
        # 交给 add_memory 已调度的防抖刷盘合并落盘。耐久仅在窗口边界内略有回退（最坏丢失
        # 一个防抖周期），与 memory_engine 普通写入路径一致。
        self._last_sync_flush = 0.0
        self._sync_flush_interval = float(
            os.environ.get("XIMU_LEARN_FLUSH_THROTTLE_S", "2.0"))

    def _ensure_engine(self):
        """
        确保记忆引擎已初始化并可用。

        Returns:
            记忆引擎实例或 None（如果初始化失败）。
        """
        if self._initialized:
            return self._mem
        try:
            from src.ximu.core.memory.memory_engine import get_memory_engine
            self._mem = get_memory_engine()
        except Exception as e:
            logger.warning("learning-memory bridge: memory engine unavailable: %s", e)
        self._initialized = True
        return self._mem

    def _maybe_sync_flush(self, reason: str) -> None:
        """
        节流同步落盘：时间窗口内首次立即 fsync（保持 kill-9 耐久），
        窗口内后续写入交给 add_memory 已调度的 500ms 防抖刷盘合并落盘。

        这样连续失败/成功爆发时不再每条都全量 fsync 整库（消除 fsync 风暴），
        同时保证任意 2s 窗口内至少有一条关键经验被立即强制落盘。

        Args:
            reason: 触发刷盘的原因，用于日志记录。
        """
        eng = self._mem
        if eng is None:
            return
        try:
            now = time.time()
            if now - self._last_sync_flush >= self._sync_flush_interval:
                self._last_sync_flush = now
                eng.flush_now(reason)
                logger.debug("Sync flush triggered: %s", reason)
        except Exception:
            logger.warning("Sync flush failed: %s", reason)

    def record_success(self, task_type: str, summary: str,
                       context: str = "", importance: float = 0.7) -> Optional[str]:
        """
        记录成功经验到长期记忆。

        Args:
            task_type: 任务类型标识。
            summary: 成功经验摘要。
            context: 额外上下文信息。
            importance: 重要性权重 (0-1)。

        Returns:
            记忆ID，如果记录失败则返回 None。
        """
        eng = self._ensure_engine()
        if eng is None:
            return None
        content = f"[成功经验][{task_type}] {summary}"
        try:
            mid = eng.add_memory(
                content=content,
                memory_type="lesson_success",
                importance=importance,
                context=context,
                tags=["learning", "success", task_type],
            )
            # 关键节点：成功经验落盘（节流：窗口内首次立即 fsync，其余交防抖合并）
            self._maybe_sync_flush("learning_success")
            return mid
        except Exception as e:
            logger.warning("record_success failed: %s", e)
            return None

    def record_failure(self, task_type: str, error: str,
                       context: str = "", importance: float = 0.8) -> Optional[str]:
        """
        记录失败/错误经验到长期记忆（高重要性，避免重蹈覆辙）。

        P126 修复：原用 memory_type="lesson_failure" + 前缀"[失败教训]"，命中 P58
        过程记录黑名单被直接丢弃。改用 semantic（P58 保留的可复用知识类型）+
        前缀"[固化失败教训]"（非黑名单精确前缀）。不改 memory_engine.py。

        Args:
            task_type: 任务类型标识。
            error: 错误描述。
            context: 额外上下文信息。
            importance: 重要性权重 (0-1)。

        Returns:
            记忆ID，如果记录失败则返回 None。
        """
        eng = self._ensure_engine()
        if eng is None:
            return None
        content = f"[固化失败教训][{task_type}] {error}"
        try:
            mid = eng.add_memory(
                content=content,
                memory_type="semantic",
                importance=importance,
                context=context,
                tags=["learning", "failure", task_type, "avoid", "consolidated"],
            )
            # 错误是关键节点：落盘（节流：窗口内首次立即 fsync，其余交防抖合并，
            # 避免连续失败时每条都全量 fsync 整库）
            self._maybe_sync_flush("learning_failure")
            return mid
        except Exception as e:
            logger.warning("record_failure failed: %s", e)
            return None

    @staticmethod
    def _is_consolidated_failure(m) -> bool:
        """
        识别经学习系统固化的失败教训（新前缀 + 标签），与原始过程记录区分。

        Args:
            m: 记忆对象。

        Returns:
            是否为固化失败教训。
        """
        content = getattr(m, "content", "") or ""
        tags = getattr(m, "tags", None) or []
        return ("[固化失败教训]" in content) or ("consolidated" in tags)

    def _failure_similar(self, error_key: str, content: str) -> bool:
        """
        P126② 双通道相似判定：bge 语义(标定0.575) 或 关键词/签名词面重叠，
        删除原 error_key 子串硬匹配（同义不同字面必漏）。

        Args:
            error_key: 错误关键字。
            content: 记忆内容。

        Returns:
            是否相似。
        """
        # 通道一：确定性词面重叠（bigram 分词）
        try:
            from src.ximu.core.memory.memory_engine import tokenize_keywords
            a = set(tokenize_keywords(error_key))
            b = set(tokenize_keywords(content))
            if a and b:
                inter = len(a & b)
                if inter >= 2 or inter / max(1, len(a)) >= 0.6:
                    return True
        except Exception:
            pass
        # 通道二：bge 语义（不可用时降级纯词面，诚实不编造）
        try:
            from src.ximu.core.local_bge_embedder import (
                embed_text_local, is_local_embedding_available)
            if is_local_embedding_available():
                va = embed_text_local(error_key, as_query=True)
                vb = embed_text_local(content)
                if va and vb and len(va) == len(vb):
                    dot = sum(x * y for x, y in zip(va, vb))
                    na = sum(x * x for x in va) ** 0.5 or 1.0
                    nb = sum(y * y for y in vb) ** 0.5 or 1.0
                    if dot / (na * nb) >= 0.575:
                        return True
        except Exception:
            pass
        return False

    def check_known_failure(self, task_type: str, error_key: str) -> bool:
        """
        检查该类错误是否已知（任务前预检，避免重复踩坑）。

        P126②：删除 error_key 纯子串硬匹配；改为对固化失败教训做
        bge 语义 + 关键词/签名双通道判定，同义不同字面也能召回。

        Args:
            task_type: 任务类型。
            error_key: 错误关键字。

        Returns:
            是否为已知失败。
        """
        eng = self._ensure_engine()
        if eng is None:
            return False
        try:
            results = eng.retrieve_memory(
                f"{task_type} {error_key}", max_results=6)
            for m in results:
                if not self._is_consolidated_failure(m):
                    continue
                if self._failure_similar(error_key, getattr(m, "content", "") or ""):
                    return True
        except Exception:
            logger.warning("check_known_failure failed: task_type=%s, error_key=%s", task_type, error_key)
        return False

    def recall_lessons(self, task_type: str, query: str = "",
                       max_results: int = 5) -> List[Dict]:
        """
        召回与当前任务相关的历史经验（成功+失败）。

        Args:
            task_type: 任务类型。
            query: 额外查询关键词。
            max_results: 最大返回结果数。

        Returns:
            经验字典列表。
        """
        eng = self._ensure_engine()
        if eng is None:
            return []
        # 组合查询：任务类型 + 用户查询
        q = f"{task_type} {query}".strip()
        try:
            results = eng.retrieve_memory(q, max_results=max_results * 2)
        except Exception as e:
            logger.warning("recall_lessons failed: %s", e)
            return []
        lessons = []
        for m in results:
            if (m.memory_type in ("lesson_success", "lesson_failure")
                    or self._is_consolidated_failure(m)):
                lessons.append({
                    "type": m.memory_type,
                    "content": m.content,
                    "importance": m.importance,
                    "timestamp": m.timestamp,
                })
        return lessons[:max_results]


# 全局单例
_bridge: Optional[LearningMemoryBridge] = None


def get_bridge() -> LearningMemoryBridge:
    """
    获取全局学习记忆桥接单例。

    Returns:
        LearningMemoryBridge 实例。
    """
    global _bridge
    if _bridge is None:
        _bridge = LearningMemoryBridge()
    return _bridge
