"""
Re-export hub for auto_repair (split into 2 parts, original 3305 lines).
"""
import warnings as _w
_w.warn("auto_repair has been split, import from specific part", DeprecationWarning, stacklevel=2)

import importlib as _il
import logging as _logging

def _import_part(part_name: str) -> None:
    """Import a specific part of the auto_repair module."""
    try:
        module_name = f"._auto_repair_parts.{part_name}"
        module = _il.import_module(module_name, package=__package__)
        for attribute_name in dir(module):
            if not attribute_name.startswith("_"):
                globals()[attribute_name] = getattr(module, attribute_name)
    except Exception as _e:
        _logging.warning(f"Re-export {__name__}.{part_name} failed: {_e}")

_parts = ['part1', 'part2', 'part3']
for part in _parts:
    _import_part(part)
