"""
Re-export hub for error_prediction (split into 3 parts, original 3303 lines).
"""
import importlib as _il
import logging as _logging
import warnings as _w
from typing import Any

_w.warn("error_prediction has been split, import from specific part", DeprecationWarning, stacklevel=2)

def _import_error_prediction_part(part_name: str) -> None:
    """导入 error_prediction 模块的特定部分。"""
    try:
        part_module = _il.import_module(f"._error_prediction_parts.{part_name}", package=__package__)
        for attr_name in dir(part_module):
            if not attr_name.startswith("_"):
                globals()[attr_name] = getattr(part_module, attr_name)
    except Exception as _e:
        _logging.warning(f"Re-export {__name__}.{part_name} failed: {_e}")

# 导入所有部分
_parts: list[str] = ['part1', 'part2', 'part3']
for part in _parts:
    _import_error_prediction_part(part)