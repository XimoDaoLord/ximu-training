"""Re-export hub for pattern_extraction (split into 3 parts, original 3283 lines).

Lazy re-export: parts are loaded on first attribute access (PEP 562),
not at import time, to keep cold start fast.
"""
import importlib
import logging
import warnings
from typing import Any, Optional

logger = logging.getLogger(__name__)

_VERSION = "0.5"

_PARTS: tuple[str, ...] = ("part1", "part2", "part3")
_cache: Optional[dict[str, Any]] = None


def _load() -> dict[str, Any]:
    """加载并缓存所有部分；幂等。"""
    global _cache
    if _cache is not None:
        return _cache

    cache: dict[str, Any] = {}
    for part_name in _PARTS:
        try:
            module = importlib.import_module(
                f"._pattern_extraction_parts.{part_name}",
                package=__package__,
            )
            for attr_name in dir(module):
                if not attr_name.startswith("_"):
                    cache[attr_name] = getattr(module, attr_name)
        except Exception as e:
            logger.warning("Re-export %s.%s failed: %s", __name__, part_name, e)

    _cache = cache
    return _cache


def __getattr__(name: str) -> Any:
    """PEP 562: 延迟加载，直到实际请求公共名称时再加载部分。"""
    if name.startswith("_"):
        raise AttributeError(name)

    cache = _load()
    try:
        return cache[name]
    except KeyError:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from None


# 触发 DeprecationWarning，保持与原始行为一致
warnings.warn(
    "pattern_extraction has been split, import from specific part",
    DeprecationWarning,
    stacklevel=2,
)