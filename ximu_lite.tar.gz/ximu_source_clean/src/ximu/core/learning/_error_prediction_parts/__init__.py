"""Split parts of error_prediction."""

from __future__ import annotations

import logging

# 设置模块级别的日志记录器
_logger = logging.getLogger(__name__)

__version__ = "0.5"

# 公共API兼容：在此处重新导出模块中定义的子模块或符号
# 由于原始文件为空，此包主要作为命名空间容器，
# 我们在此显式声明其初始化状态并记录日志，以确保可追溯性。

def _initialize_module() -> None:
    """
    初始化模块的内部状态。

    该函数在模块导入时执行，用于记录初始化日志。

    Returns:
        None: 无返回值。
    """
    _logger.debug("初始化 error_prediction_parts 模块，版本: %s", __version__)

# 在模块加载时执行初始化
_initialize_module()

__all__ = [
    "__version__",
]
