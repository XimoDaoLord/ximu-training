import logging
import time
import uuid
import heapq
import threading
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Set, Tuple, TypeVar
from datetime import datetime, timezone, timedelta
from collections import OrderedDict, defaultdict

# 设置日志
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# 工具函数
def generate_id(prefix="id") -> str:
    """生成唯一标识符"""
    return f"{prefix}_{uuid.uuid4().hex[:16]}"

def now_timestamp() -> float:
    """获取当前时间戳"""
    return time.time()

def now_datetime() -> datetime:
    """获取当前日期时间"""
    return datetime.now(timezone(timedelta(hours=8)))

def format_datetime(dt=None, fmt="%Y-%m-%d %H:%M:%S") -> str:
    """格式化日期时间"""
    if dt is None:
        dt = now_datetime()
    return dt.strftime(fmt)

# 基础数据模型
@dataclass
class LearningItem:
    """学习项目基类"""
    item_id: str = field(default_factory=generate_id)
    content: str = ""
    store_type: str = "general"
    category: str = ""
    source: str = ""
    tags: List[str] = field(default_factory=list)
    created_at: float = now_timestamp()
    updated_at: float = 0.0
    last_accessed: float = 0.0
    access_count: int = 0
    importance: float = 0.5
    weight: float = 1.0
    confidence: float = 0.5
    metadata: Dict[str, Any] = field(default_factory=dict)
    permanent: bool = False

    def __post_init__(self):
        """初始化后执行逻辑"""
        self.updated_at = self.created_at
        self.last_accessed = self.created_at

    def access(self) -> None:
        """记录访问操作"""
        self.last_accessed = now_timestamp()
        self.access_count += 1

    def is_expired(self) -> bool:
        """实现过期策略（示例：24小时未访问）"""
        return (now_timestamp() - self.last_accessed) > 86400

    def get_strength(self) -> float:
        """计算项目强度（类型注解）"""
        return (0.3 + 0.3 * min(1.0, self.access_count / 20.0) +
                0.2 * self.confidence + 0.2 * self.importance) * self.weight

@dataclass
class Pattern:
    """模式识别模型"""
    pattern_id: str = field(default_factory=generate_id)
    name: str = ""
    pattern_type: str = "frequent"
    elements: List[str] = field(default_factory=list)
    support: float = 0.0
    confidence: float = 0.0
    lift: float = 1.0
    frequency: int = 0
    created_at: float = now_timestamp()
    updated_at: float = 0.0
    usage_count: int = 0
    success_count: int = 0
    status: str = "candidate"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.updated_at = self.created_at

    def record_usage(self, success: bool = True) -> None:
        """记录模式使用情况"""
        self.usage_count += 1
        if success:
            self.success_count += 1
        self.updated_at = now_timestamp()

    @property
    def success_rate(self) -> float:
        """成功率"""
        return self.success_count / max(1, self.usage_count)

# 核心业务模型
class ErrorRecord:
    """错误记录模型"""
    def __init__(self, error_id: str = "", error_type: str = "general", message: str = ""):
        self.error_id = error_id or generate_id("error")
        self.error_type = error_type
        self.message = message
        self.context = {}
        self.severity = "medium"
        self.created_at = now_timestamp()
        self.resolved = False
        self.resolution = ""
        self.resolved_at = 0.0
        self.recurrence_count = 0
        self.root_cause = ""
        self.predicted = False
        self.prediction_confidence = 0.0
        self.metadata = {}

    def resolve(self, resolution: str, root_cause: str = "") -> None:
        """错误解决方法"""
        self.resolved = True
        self.resolution = resolution
        self.resolved_at = now_timestamp()
        self.root_cause = root_cause

    def record_recurrence(self) -> None:
        """记录错误复发次数"""
        self.recurrence_count += 1

# 存储引擎
class PredictionStore:
    """预测数据存储引擎"""
    class _Index:
        """索引管理器"""
        def __init__(self, max_size: int = 20000):
            self.tag_index: Dict[str, Set[str]] = defaultdict(set)
            self.type_index: Dict[str, Set[str]] = defaultdict(set)
            self.source_index: Dict[str, Set[str]] = defaultdict(set)
            self.time_heap: List[Tuple[float, str]] = []
            self.cache: OrderedDict = OrderedDict()
            self.max_size = max_size
            self.cache_max = 500

        def update_indices(self, item: Dict[str, Any], iid: str) -> None:
            """更新索引"""
            for tag in item.get("tags", []):
                self.tag_index[tag.lower()].add(iid)
            self.type_index[item.get("store_type", "general")].add(iid)
            src = item.get("source", "")
            if src:
                self.source_index[src].add(iid)

        def search(self, query: str, category: str = "", tags: List[str] = None, min_score: float = 0.0) -> List[Tuple[Dict[str, Any], float]]:
            """改进后的搜索方法（含时间排序）"""
            with self._lock:
                cache_key = f"{query}:{category}:{tags}:{min_score}"
                if cache_key in self.cache:
                    self.cache_hits += 1
                    return self.cache[cache_key]
                self.cache.move_to_end(cache_key)
                q = query.lower().strip()
                cids = set()
                if category:
                    cids = self.type_index.get(category, set())
                if tags:
                    tids = set()
                    for t in tags:
                        tids.update(self.tag_index.get(t.lower(), set()))
                    cids &= tids
                scored = []
                q_words = q.split()
                for iid in cids:
                    item = self.items[iid]
                    score = self._score(item, q, q_words)
                    if score > min_score:
                        scored.append((score, iid))
                # 按时间排序
                scored.sort(key=lambda x: -self.items[x[1]].created_at, reverse=False)
                result = [(self.items[iid], score) for (score, iid) in scored[:20]]
                self.cache[cache_key] = result
                if len(self.cache) > self.cache_max:
                    self.cache.popitem(last=False)
                return result

        def _score(self, item: Dict[str, Any], query: str, words: List[str]) -> float:
            content = item.get("content", "").lower()
            content_words = content.split()
            common = len(set(words) & set(content_words))
            return common / max(1, len(words) + len(content_words) - common)

    def __init__(self, max_items: int = 20000):
        self._lock = threading.RLock()
        self._items: Dict[str, Dict[str, Any]] = {}
        self._index = self._Index()
        self._stats = {"total": 0, "reads": 0, "writes": 0, "deletes": 0}
        self._cache_hits = 0
        self._cache_misses = 0

    def _evict(self) -> None:
        """智能淘汰策略"""
        with self._lock:
            if len(self._items) >= self._index.max_size:
                evictable = sorted(
                    [(item.get("importance", 0.5), iid) for iid, item in self._items.items() if not item.get("permanent", False)],
                    reverse=True
                )
                if evictable:
                    iid, _ = evictable[0]
                    self.remove(iid)

    def add(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """添加新项目（带日志）"""
        with self._lock:
            iid = generate_id("item")
            self._items[iid] = item.copy()
            self._index.time_heap.append((item["created_at"], iid))
            self._index.update_indices(item, iid)
            self._evict()
            self._stats["writes"] += 1
            log_event("数据添加", {"item_id": iid, "size": len(self._items)})
            return self._items[iid]

    def get(self, iid: str) -> Dict[str, Any]:
        """获取项目（带访问计数）"""
        with self._lock:
            if iid not in self._items:
                return None
            item = self._items[iid].copy()
            item["access_count"] = item.get("access_count", 0) + 1
            self._stats["reads"] += 1
            log_event("数据访问", {"item_id": iid, "access_count": item["access_count"]})
            return item

    def remove(self, iid: str) -> None:
        """删除项目（带日志）"""
        with self._lock:
            if iid in self._items:
                del self._items[iid]
                self._stats["deletes"] += 1
                log_event("数据删除", {"item_id": iid})

    @property
    def cache_hits(self) -> int:
        return self._index.cache_hits

# 风险评估模块
class RiskAssessment:
    """风险评估模型"""
    def __init__(self, assessment_id: str = "", target: str = ""):
        self.assessment_id = assessment_id or generate_id("assessment")
        self.target = target
        self.risk_score = 0.0
        self.risk_level = "medium"
        self.factors = []
        self.recommendations = []
        self.created_at = now_timestamp()
        self.expires_at = 0.0

    def is_expired(self) -> bool:
        """过期检查（带缓存）"""
        if self.expires_at <= 0:
            return False
        return now_timestamp() > self.expires_at

# 日志与监控
def log_event(event: str, details: Dict) -> None:
    """统一日志记录"""
    logger.info(f"{event}: {details}")

# 性能统计
class SystemStats:
    """系统性能统计"""
    def __init__(self):
        self.search_hits = 0
        self.cache_hits = 0
        self.total_operations = 0

    def update_stats(self, op: str, count: int) -> None:
        """更新统计信息"""
        if op == "search":
            self.search_hits += count
        elif op == "cache":
            self.cache_hits += count
        self.total_operations += count

# 关键操作日志增强
def _log_add(item: Dict) -> None:
    logger.debug(f"添加项目: {asdict(item)}")

def _log_remove(iid: str) -> None:
    logger.debug(f"删除项目: {iid}")


# ===== 自动补全 =====

class Prediction:
    """Prediction - 预测结果。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)
