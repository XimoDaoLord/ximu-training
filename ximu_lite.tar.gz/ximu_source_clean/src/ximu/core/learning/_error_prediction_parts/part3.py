"""Part 3 of error_prediction system, containing WarningStore and related utilities."""
from __future__ import annotations

import logging
import os
import json
import heapq
import threading
import random
import re
import time
from dataclasses import asdict
from typing import Any, Callable, Dict, List, Set, Tuple, Optional, Union
from collections import OrderedDict, defaultdict, deque, Counter

from src.ximu.common.utils import score_stored_item, generate_id, now_timestamp
from .part1 import LearningItem, ErrorRecord, Prediction

logger = logging.getLogger("src.ximu.core.learning._error_prediction_parts.part3")

try:
    from config.settings import config
except ImportError:
    config = None


class WarningStore:
    """
    警告存储类，用于管理学习项的添加、检索、搜索和统计。
    支持标签、类型、来源索引，以及时间堆用于高效范围查询。
    """

    VERSION: str = "0.5"

    def __init__(self, max_items: int = 10000) -> None:
        """
        初始化WarningStore。

        Args:
            max_items: 最大存储项数量。
        """
        self._items: Dict[str, LearningItem] = {}
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._type_index: Dict[str, Set[str]] = defaultdict(set)
        self._source_index: Dict[str, Set[str]] = defaultdict(set)
        self._time_heap: List[Tuple[float, str]] = []
        self._max: int = max_items
        self._lock = threading.RLock()
        
        # 计数器
        self._added: int = 0
        self._reads: int = 0
        self._deleted: int = 0
        self._updated: int = 0
        self._searches: int = 0
        self._cache_hits: int = 0
        self._cache_misses: int = 0
        
        # 查询缓存
        self._query_cache: OrderedDict[str, List[Tuple[LearningItem, float]]] = OrderedDict()
        self._max_cache: int = 500

    def add(self, item: LearningItem) -> LearningItem:
        """
        添加一个学习项到存储中。
        如果存储已满，会自动驱逐最弱的项（非永久且重要性最低的项）。

        Args:
            item: 要添加的学习项。

        Returns:
            添加后的学习项。
        """
        with self._lock:
            if len(self._items) >= self._max:
                self._evict_weakest()
            
            iid = self._extract_id(item)
            self._items[iid] = item
            
            # 更新标签索引
            for tag in getattr(item, "tags", []):
                if tag:
                    self._tag_index[str(tag).lower()].add(iid)
            
            # 更新类型索引
            itype = self._extract_type(item)
            self._type_index[itype].add(iid)
            
            # 更新来源索引
            src = getattr(item, "source", "")
            if src:
                self._source_index[src].add(iid)
            
            # 更新时间堆
            created_at = getattr(item, "created_at", None)
            if created_at is None:
                created_at = now_timestamp()
            heapq.heappush(self._time_heap, (created_at, iid))
            
            self._added += 1
            self._invalidate_cache()
            logger.debug("Added item %s to WarningStore", iid)
            return item

    def get(self, iid: str) -> Optional[LearningItem]:
        """
        根据ID获取学习项。

        Args:
            iid: 学习项ID。

        Returns:
            对应的学习项，如果不存在则返回None。
        """
        with self._lock:
            item = self._items.get(iid)
            if item:
                if hasattr(item, "access"):
                    item.access()
                self._reads += 1
            return item

    def get_or_default(self, iid: str, default: Any = None) -> Any:
        """
        获取学习项，如果不存在则返回默认值。

        Args:
            iid: 学习项ID。
            default: 默认值。

        Returns:
            学习项或默认值。
        """
        item = self.get(iid)
        return item if item is not None else default

    def remove(self, iid: str) -> bool:
        """
        移除指定ID的学习项。

        Args:
            iid: 学习项ID。

        Returns:
            如果成功移除返回True，否则返回False。
        """
        with self._lock:
            item = self._items.pop(iid, None)
            if item:
                # 清理标签索引
                for tag in getattr(item, "tags", []):
                    if tag:
                        self._tag_index[str(tag).lower()].discard(iid)
                
                # 清理类型索引
                itype = self._extract_type(item)
                self._type_index[itype].discard(iid)
                
                # 清理来源索引
                src = getattr(item, "source", "")
                if src:
                    self._source_index[src].discard(iid)
                
                self._deleted += 1
                self._invalidate_cache()
                logger.debug("Removed item %s from WarningStore", iid)
                return True
            return False

    def update(self, iid: str, **kwargs: Any) -> bool:
        """
        更新学习项的属性。

        Args:
            iid: 学习项ID。
            **kwargs: 要更新的属性及其值。

        Returns:
            如果成功更新返回True，否则返回False。
        """
        with self._lock:
            item = self._items.get(iid)
            if item:
                for k, v in kwargs.items():
                    if hasattr(item, k):
                        setattr(item, k, v)
                if hasattr(item, "updated_at"):
                    item.updated_at = now_timestamp()
                self._updated += 1
                self._invalidate_cache()
                logger.debug("Updated item %s", iid)
                return True
            return False

    def contains(self, iid: str) -> bool:
        """
        检查指定ID的学习项是否存在。

        Args:
            iid: 学习项ID。

        Returns:
            如果存在返回True，否则返回False。
        """
        with self._lock:
            return iid in self._items

    def search(
        self,
        query: str,
        limit: int = 20,
        category: str = "",
        tags: Optional[List[str]] = None,
        min_score: float = 0.0
    ) -> List[Tuple[LearningItem, float]]:
        """
        搜索学习项，支持按类别、标签和最小分数过滤。

        Args:
            query: 搜索查询字符串。
            limit: 返回结果的最大数量。
            category: 类别过滤。
            tags: 标签过滤列表。
            min_score: 最小匹配分数。

        Returns:
            匹配项及其分数的列表，按分数降序排列。
        """
        with self._lock:
            cache_key = f"{query}:{category}:{tuple(tags or [])}:{min_score}:{limit}"
            if cache_key in self._query_cache:
                self._cache_hits += 1
                self._query_cache.move_to_end(cache_key)
                return self._query_cache[cache_key]
            
            self._cache_misses += 1
            self._searches += 1
            q = query.lower().strip()
            
            # 获取候选ID集合
            cids: Set[str] = set(self._items.keys())
            if category:
                cids &= self._type_index.get(category, set())
            
            if tags:
                tids: Set[str] = set()
                for t in tags:
                    tids.update(self._tag_index.get(str(t).lower(), set()))
                cids &= tids
            
            # 计算分数并排序
            scored: List[Tuple[float, LearningItem]] = []
            q_words = q.split()
            for iid in cids:
                item = self._items[iid]
                s = score_stored_item(item, q, q_words)
                if s > min_score:
                    scored.append((s, item))
            
            scored.sort(key=lambda x: x[0], reverse=True)
            result = [(item, s) for s, item in scored[:limit]]
            
            # 缓存结果
            self._query_cache[cache_key] = result
            if len(self._query_cache) > self._max_cache:
                self._query_cache.popitem(last=False)
            
            logger.debug("Search query '%s' returned %d results", query, len(result))
            return result

    def fuzzy_search(
        self,
        query: str,
        threshold: float = 0.6,
        limit: int = 20
    ) -> List[Tuple[LearningItem, float]]:
        """
        模糊搜索学习项，基于文本相似度。

        Args:
            query: 查询字符串。
            threshold: 相似度阈值。
            limit: 返回结果的最大数量。

        Returns:
            匹配项及其相似度分数的列表，按分数降序排列。
        """
        with self._lock:
            q = query.lower()
            scored: List[Tuple[float, LearningItem]] = []
            for iid, item in self._items.items():
                content = (getattr(item, "content") or "").lower()
                s = self._text_similarity(q, content)
                if s >= threshold:
                    scored.append((s, item))
            
            scored.sort(key=lambda x: x[0], reverse=True)
            result = [(item, s) for s, item in scored[:limit]]
            logger.debug("Fuzzy search '%s' returned %d results", query, len(result))
            return result

    def regex_search(self, pattern: str, limit: int = 20) -> List[LearningItem]:
        """
        正则表达式搜索学习项。

        Args:
            pattern: 正则表达式模式。
            limit: 返回结果的最大数量。

        Returns:
            匹配项的列表。
        """
        with self._lock:
            try:
                rx = re.compile(pattern, re.IGNORECASE)
            except re.error as e:
                logger.warning("Invalid regex pattern: %s", pattern)
                return []
            
            result: List[LearningItem] = []
            for iid, item in self._items.items():
                content = (getattr(item, "content") or "")
                if rx.search(content):
                    result.append(item)
                    if len(result) >= limit:
                        break
            
            logger.debug("Regex search '%s' returned %d results", pattern, len(result))
            return result

    def get_by_type(self, ctype: str, limit: int = 100) -> List[LearningItem]:
        """
        根据类型获取学习项。

        Args:
            ctype: 类型名称。
            limit: 返回结果的最大数量。

        Returns:
            按创建时间降序排列的学习项列表。
        """
        with self._lock:
            ids = self._type_index.get(ctype, set())
            items = [self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x: getattr(x, "created_at", 0), reverse=True)
            return items[:limit]

    def get_by_tag(self, tag: str, limit: int = 100) -> List[LearningItem]:
        """
        根据标签获取学习项。

        Args:
            tag: 标签名称。
            limit: 返回结果的最大数量。

        Returns:
            按创建时间降序排列的学习项列表。
        """
        with self._lock:
            ids = self._tag_index.get(tag.lower(), set())
            items = [self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x: getattr(x, "created_at", 0), reverse=True)
            return items[:limit]

    def get_by_source(self, src: str, limit: int = 100) -> List[LearningItem]:
        """
        根据来源获取学习项。

        Args:
            src: 来源名称。
            limit: 返回结果的最大数量。

        Returns:
            按创建时间降序排列的学习项列表。
        """
        with self._lock:
            ids = self._source_index.get(src, set())
            items = [self._items[i] for i in ids if i in self._items]
            items.sort(key=lambda x: getattr(x, "created_at", 0), reverse=True)
            return items[:limit]

    def get_time_range(
        self,
        start: float,
        end: float,
        limit: int = 100
    ) -> List[LearningItem]:
        """
        获取指定时间范围内的学习项。

        Args:
            start: 开始时间戳。
            end: 结束时间戳。
            limit: 返回结果的最大数量。

        Returns:
            时间范围内的学习项列表。
        """
        with self._lock:
            result: List[LearningItem] = []
            for ts, iid in sorted(self._time_heap):
                if ts < start:
                    continue
                if ts > end:
                    break
                if iid in self._items:
                    result.append(self._items[iid])
                    if len(result) >= limit:
                        break
            return result

    def get_recent(self, limit: int = 50) -> List[LearningItem]:
        """
        获取最近创建的学习项。

        Args:
            limit: 返回结果的最大数量。

        Returns:
            按创建时间降序排列的学习项列表。
        """
        with self._lock:
            items = list(self._items.values())
            items.sort(key=lambda x: getattr(x, "created_at", getattr(x, "timestamp", 0)), reverse=True)
            return items[:limit]

    def get_oldest(self, limit: int = 50) -> List[LearningItem]:
        """
        获取最早创建的学习项。

        Args:
            limit: 返回结果的最大数量。

        Returns:
            按创建时间升序排列的学习项列表。
        """
        with self._lock:
            items = list(self._items.values())
            items.sort(key=lambda x: getattr(x, "created_at", getattr(x, "timestamp", 0)))
            return items[:limit]

    def get_all(self) -> List[LearningItem]:
        """
        获取所有学习项。

        Returns:
            所有学习项的列表。
        """
        with self._lock:
            return list(self._items.values())

    def get_ids(self) -> List[str]:
        """
        获取所有学习项的ID。

        Returns:
            学习项ID的列表。
        """
        with self._lock:
            return list(self._items.keys())

    def size(self) -> int:
        """
        获取存储中的学习项数量。

        Returns:
            学习项数量。
        """
        with self._lock:
            return len(self._items)

    def is_empty(self) -> bool:
        """
        检查存储是否为空。

        Returns:
            如果为空返回True，否则返回False。
        """
        with self._lock:
            return len(self._items) == 0

    def clear(self) -> None:
        """
        清空存储中的所有项和索引。
        """
        with self._lock:
            self._items.clear()
            self._tag_index.clear()
            self._type_index.clear()
            self._source_index.clear()
            self._time_heap.clear()
            self._invalidate_cache()
            logger.info("WarningStore cleared")

    def cleanup_expired(self) -> int:
        """
        清理已过期的学习项。

        Returns:
            清理的项数量。
        """
        with self._lock:
            expired_ids = [
                iid for iid, i in self._items.items()
                if hasattr(i, "is_expired") and i.is_expired()
            ]
            count = 0
            for iid in expired_ids:
                if self.remove(iid):
                    count += 1
            if count > 0:
                logger.debug("Cleaned up %d expired items", count)
            return count

    def batch_add(self, items: List[LearningItem]) -> List[LearningItem]:
        """
        批量添加学习项。

        Args:
            items: 学习项列表。

        Returns:
            添加后的学习项列表。
        """
        return [self.add(item) for item in items]

    def batch_remove(self, iids: List[str]) -> int:
        """
        批量移除学习项。

        Args:
            iids: 学习项ID列表。

        Returns:
            成功移除的项数量。
        """
        return sum(1 for iid in iids if self.remove(iid))

    def batch_get(self, iids: List[str]) -> List[Optional[LearningItem]]:
        """
        批量获取学习项。

        Args:
            iids: 学习项ID列表。

        Returns:
            学习项列表，不存在的项为None。
        """
        return [self.get(iid) for iid in iids]

    def filter_by(
        self,
        predicate: Callable[[LearningItem], bool],
        limit: int = 100
    ) -> List[LearningItem]:
        """
        根据谓词函数过滤学习项。

        Args:
            predicate: 谓词函数。
            limit: 返回结果的最大数量。

        Returns:
            满足条件的学习项列表。
        """
        with self._lock:
            result: List[LearningItem] = []
            for iid, item in self._items.items():
                if predicate(item):
                    result.append(item)
                    if len(result) >= limit:
                        break
            return result

    def map_items(self, func: Callable[[LearningItem], Any]) -> Dict[str, Any]:
        """
        对每个学习项应用函数并返回结果映射。

        Args:
            func: 要应用的函数。

        Returns:
            ID到函数结果的映射。
        """
        with self._lock:
            return {iid: func(item) for iid, item in self._items.items()}

    def reduce_items(
        self,
        func: Callable[[Any, LearningItem], Any],
        initial: Any = None
    ) -> Any:
        """
        对每个学习项应用归约函数。

        Args:
            func: 归约函数。
            initial: 初始值。

        Returns:
            归约结果。
        """
        with self._lock:
            result = initial
            for iid, item in self._items.items():
                if result is None:
                    result = func(None, item)
                else:
                    result = func(result, item)
            return result

    def _text_similarity(self, a: str, b: str) -> float:
        """
        计算两个字符串的文本相似度（基于词集Jaccard系数）。

        Args:
            a: 第一个字符串。
            b: 第二个字符串。

        Returns:
            相似度分数（0.0到1.0之间）。
        """
        if not a or not b:
            return 0.0
        sa = set(a.split())
        sb = set(b.split())
        if not sa or not sb:
            return 0.0
        return len(sa & sb) / len(sa | sb)

    def _extract_id(self, item: LearningItem) -> str:
        """
        从学习项中提取ID。

        Args:
            item: 学习项。

        Returns:
            学习项ID。
        """
        return getattr(item, "item_id", getattr(item, "entry_id", getattr(item, "id", generate_id("item"))))

    def _extract_type(self, item: LearningItem) -> str:
        """
        从学习项中提取类型。

        Args:
            item: 学习项。

        Returns:
            类型字符串。
        """
        return getattr(item, "store_type", getattr(item, "category", getattr(item, "type", "general")))

    def _evict_weakest(self) -> None:
        """
        驱逐最弱的学习项（非永久且重要性最低的项）。
        """
        if not self._items:
            return
        
        evictable = [
            (getattr(i, "importance", getattr(i, "weight", 0.5)), iid)
            for iid, i in self._items.items()
            if not getattr(i, "permanent", False)
        ]
        if evictable:
            evictable.sort()
            self.remove(evictable[0][1])

    def _invalidate_cache(self) -> None:
        """
        使查询缓存失效。
        """
        self._query_cache.clear()


class WarningStoreManager:
    """
    警告存储管理器，协调多个WarningStore实例。
    """

    VERSION: str = "0.5"

    def __init__(self) -> None:
        """
        初始化WarningStoreManager。
        """
        self._stores: Dict[str, WarningStore] = {}
        self._lock = threading.RLock()
        self._initialized: bool = False
        self._metrics: Dict[str, float] = {}
        self._history: deque = deque(maxlen=1000)
        self._listeners: Dict[str, List[Callable]] = defaultdict(list)
        self._config: Dict[str, Any] = {}
        self._last_maintenance: float = 0

    def initialize(self, stores: Optional[Dict[str, WarningStore]] = None) -> None:
        """
        初始化管理器，注册存储实例。

        Args:
            stores: 存储实例字典。
        """
        with self._lock:
            if stores:
                self._stores.update(stores)
            self._initialized = True
            logger.info("WarningStoreManager initialized with %d stores", len(self._stores))

    def register_store(self, name: str, store: WarningStore) -> None:
        """
        注册一个WarningStore实例。

        Args:
            name: 存储名称。
            store: WarningStore实例。
        """
        with self._lock:
            self._stores[name] = store
            logger.debug("Registered store '%s'", name)

    def get_store(self, name: str) -> Optional[WarningStore]:
        """
        获取指定名称的WarningStore实例。

        Args:
            name: 存储名称。

        Returns:
            WarningStore实例或None。
        """
        with self._lock:
            return self._stores.get(name)

    def list_stores(self) -> List[str]:
        """
        列出所有注册的存储名称。

        Returns:
            存储名称列表。
        """
        with self._lock:
            return list(self._stores.keys())

    def add_listener(self, event: str, callback: Callable) -> None:
        """
        注册事件监听器。

        Args:
            event: 事件名称。
            callback: 回调函数。
        """
        with self._lock:
            self._listeners[event].append(callback)

    def _emit(self, event: str, data: Dict[str, Any]) -> None:
        """
        触发事件。

        Args:
            event: 事件名称。
            data: 事件数据。
        """
        with self._lock:
            for callback in self._listeners.get(event, []):
                try:
                    callback(data)
                except Exception as e:
                    logger.debug("Listener for event '%s' failed: %s", event, e, exc_info=True)

    def maintenance(self) -> Dict[str, Any]:
        """
        执行维护操作，清理过期项。

        Returns:
            维护结果字典。
        """
        with self._lock:
            now = time.time()
            if now - self._last_maintenance < 300:
                return {"status": "skipped", "reason": "recently maintained"}
            
            cleaned = 0
            for name, s in self._stores.items():
                if hasattr(s, "cleanup_expired"):
                    try:
                        cleaned += s.cleanup_expired()
                    except Exception as e:
                        logger.debug("Maintenance cleanup for store '%s' failed: %s", name, e, exc_info=True)
            
            self._last_maintenance = now
            self._emit("maintenance", {"cleaned": cleaned})
            logger.info("Maintenance completed, cleaned %d items", cleaned)
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        """
        获取当前统计快照。

        Returns:
            统计信息字典。
        """
        with self._lock:
            store_stats: Dict[str, Any] = {}
            for name, s in self._stores.items():
                if hasattr(s, "get_stats"):
                    try:
                        store_stats[name] = s.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(s, "size"):
                    store_stats[name] = {"size": s.size()}
            
            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history)
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        将对象转换为字典表示。

        Returns:
            包含公共属性的字典。
        """
        with self._lock:
            return {
                "config": dict(self._config),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys())
            }

    def export_state(self, filepath: str) -> None:
        """
        导出内部状态到文件。

        Args:
            filepath: 文件路径。
        """
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, default=str)
        logger.info("State exported to %s", filepath)

    def import_state(self, filepath: str) -> bool:
        """
        从文件导入状态。

        Args:
            filepath: 文件路径。

        Returns:
            如果成功导入返回True，否则返回False。
        """
        if not os.path.exists(filepath):
            logger.warning("Import file not found: %s", filepath)
            return False
        
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        with self._lock:
            if "config" in data:
                self._config.update(data["config"])
            if "metrics" in data:
                self._metrics.update(data["metrics"])
        
        logger.info("State imported from %s", filepath)
        return True

    def get_stats_snapshot(self) -> Dict[str, Any]:
        """
        获取统计快照，包含存储大小和指标。

        Returns:
            统计快照字典。
        """
        return self.get_stats()

    def record_metric(self, name: str, value: float) -> None:
        """
        记录一个指标值。

        Args:
            name: 指标名称。
            value: 指标值。
        """
        with self._lock:
            self._metrics[name] = value
            self._history.append({"time": now_timestamp(), "metric": name, "value": value})

    def reset_metrics(self) -> None:
        """
        重置所有指标。
        """
        with self._lock:
            self._metrics.clear()
            self._history.clear()
            logger.info("Metrics reset")
