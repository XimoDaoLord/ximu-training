import json
import logging
import os
import time
from collections import defaultdict, deque
from threading import RLock
from typing import Any, Callable, Deque, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

ValidStateKeys = {"config", "metrics", "stores"}

class Registry:
    """高可用组件注册中心，支持存储管理、事件驱动、指标监控及维护调度。

    提供线程安全的状态管理，包含配置存储、组件注册、指标追踪、事件通知及定时维护功能。
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None, 
                 maintenance_interval: float = 300.0) -> None:
        """初始化注册中心实例。

        Args:
            config: 初始配置信息（可选）
            maintenance_interval: 维护任务执行间隔（秒，默认5分钟）
        """
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = config or {}
        self._lock = RLock()
        self._event_handlers: Dict[str, List[Callable[[Dict[str, Any]], None]]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: Deque[Dict[str, Any]] = deque(maxlen=500)
        self._initialized = False
        self._last_maintenance = time.time()
        self._maintenance_interval = maintenance_interval

    def register_store(self, name: str, store_obj: Any) -> None:
        """注册存储组件并触发事件通知。

        Args:
            name: 组件唯一标识符（必填）
            store_obj: 需实现 cleanupExpired() 和 getStats() 接口的对象

        Raises:
            ValueError: 组件已存在或接口缺失
        """
        with self._lock:
            if name in self._stores:
                raise ValueError(f"Store '{name}' already registered")
            if not hasattr(store_obj, 'cleanupExpired') or not callable(getattr(store_obj, 'cleanupExpired')):
                raise ValueError(f"Store '{name}' missing cleanupExpired method")
            if not hasattr(store_obj, 'getStats') or not callable(getattr(store_obj, 'getStats')):
                raise ValueError(f"Store '{name}' missing getStats method")
            self._stores[name] = store_obj
            self._emit('store_registered', {'name': name})
            logger.info("Registered store '%s' with interface version 1.2", name)

    def get_store(self, name: str) -> Optional[Any]:
        """安全获取存储组件实例。

        Args:
            name: 组件唯一标识符

        Returns:
            组件对象或 None
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """安全移除存储组件并触发事件。

        Args:
            name: 组件唯一标识符

        Returns:
            移除成功返回 True，不存在返回 False
        """
        with self._lock:
            if name not in self._stores:
                return False
            store = self._stores.pop(name)
            self._emit('store_removed', {'name': name})
            logger.warning("Removed store '%s' (active connections: %d)", 
                          name, store.active_connections() if hasattr(store, 'active_connections') else 0)
            return True

    def on(self, event: str, handler: Callable[[Dict[str, Any]], None]) -> None:
        """注册事件处理回调。

        Args:
            event: 事件类型（如 'store_registered'）
            handler: 处理函数，接收字典参数
        """
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable[[Dict[str, Any]], None]) -> None:
        """注销事件处理回调。

        Args:
            event: 事件类型
            handler: 要注销的回调函数
        """
        with self._lock:
            try:
                self._event_handlers[event].remove(handler)
            except ValueError:
                pass  # 忽略未找到的回调

    def _emit(self, event: str, data: Optional[Dict[str, Any]] = None) -> None:
        """安全事件分发机制。

        Args:
            event: 事件类型
            data: 附加事件数据（默认空字典）
        """
        data = data or {}
        handlers = list(self._event_handlers.get(event, []))
        for handler in handlers:
            try:
                handler(data)
            except Exception as e:
                logger.error("Event handler failed: %s - %s", event, str(e), exc_info=True)

    def record_metric(self, name: str, value: float) -> None:
        """安全记录指标数据并更新历史快照。

        Args:
            name: 指标名称（必须符合snake_case）
            value: 指标数值（必须为数值类型）
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({
                "metric": name,
                "value": value,
                "timestamp": time.time(),
                "source": "api"
            })

    def get_metric(self, name: str) -> float:
        """安全获取指标累计值。

        Args:
            name: 指标名称

        Returns:
            指标值或 0.0（不存在时）
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """获取当前所有指标快照。

        Returns:
            指标名称到值的映射字典
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        """安全清空所有指标数据。

        注意：此操作不可逆
        """
        with self._lock:
            self._metrics.clear()
            self._history.clear()

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """获取指标历史记录。

        Args:
            limit: 返回条数上限（默认100）

        Returns:
            历史记录列表（按时间倒序排列）
        """
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """执行注册中心初始化流程。

        Returns:
            初始化成功返回 True，已初始化返回 False
        """
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._emit('initialized', {'version': '1.3'})
            logger.info("Registry initialized (version %s)", '1.3')
            return True

    def shutdown(self) -> bool:
        """执行注册中心关闭流程。

        Returns:
            关闭成功返回 True，未初始化返回 False
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            self._emit('shutdown', {'exit_code': 0})
            logger.info("Registry shut down (exit code %d)", 0)
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """执行周期性维护任务。

        Args:
            force: 是否强制执行（默认False）

        Returns:
            维护结果字典：
            {"status": "done", "cleaned": int},
            {"status": "skipped", "reason": str}
        """
        with self._lock:
            now = time.time()
            if not force and (now - self._last_maintenance) < self._maintenance_interval:
                return {"status": "skipped", "reason": "interval_exceeded"}
            cleaned = 0
            for name, store in self._stores.items():
                try:
                    cleanup = getattr(store, 'cleanupExpired', None)
                    if callable(cleanup):
                        cleaned += cleanup()
                except AttributeError:
                    logger.debug("Store '%s' has no cleanupExpired method", name)
                except Exception as e:
                    logger.error("Maintenance failed for store '%s': %s", name, str(e), exc_info=True)
            self._last_maintenance = now
            self._emit('maintenance', {'cleaned': cleaned})
            logger.info("Maintenance completed, cleaned %d entries", cleaned)
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        """获取注册中心整体统计信息。

        Returns:
            结构化统计信息字典
        """
        with self._lock:
            store_stats = {}
            for name, store in self._stores.items():
                try:
                    if hasattr(store, 'getStats'):
                        store_stats[name] = store.getStats()
                    elif hasattr(store, 'size'):
                        store_stats[name] = {"size": store.size()}
                    else:
                        store_stats[name] = "unknown"
                except Exception as e:
                    store_stats[name] = {"error": str(e)}
            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics_count": len(self._metrics),
                "history_size": len(self._history)
            }

    def to_dict(self) -> Dict[str, Any]:
        """获取可序列化状态快照。

        Returns:
            符合 schema 的状态字典
        """
        with self._lock:
            return {
                "config": dict(self._config),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys()),
                "version": "1.3"
            }

    def export_state(self, filepath: str) -> bool:
        """安全导出注册中心状态。

        Args:
            filepath: 导出文件路径

        Returns:
            导出成功返回 True，失败返回 False
        """
        with self._lock:
            state = self.to_dict()
        try:
            tmp_path = f"{filepath}.tmp"
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(state, f, ensure_ascii=False, default=str, indent=2)
            if os.path.exists(filepath):
                os.remove(filepath)
            os.rename(tmp_path, filepath)
            logger.info("State exported to '%s'", filepath)
            return True
        except OSError as e:
            logger.error("Export failed: %s", str(e))
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            return False

    def import_state(self, filepath: str) -> bool:
        """安全导入注册中心状态。

        Args:
            filepath: 导入文件路径

        Returns:
            导入成功返回 True，失败返回 False
        """
        if not os.path.exists(filepath):
            logger.warning("Import skipped: file not found '%s'", filepath)
            return False
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            logger.error("Import failed: %s", str(e))
            return False
        if not isinstance(data, dict) or not ValidStateKeys.issubset(data.keys()):
            logger.error("Invalid state schema in '%s'", filepath)
            return False
        with self._lock:
            if "config" in data and isinstance(data["config"], dict):
                self._config.update(data["config"])
            if "metrics" in data and isinstance(data["metrics"], dict):
                self._metrics.update(data["metrics"])
            logger.info("State imported from '%s'", filepath)
        return True
