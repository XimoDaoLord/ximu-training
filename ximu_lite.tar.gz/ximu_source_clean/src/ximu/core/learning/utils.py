"""学习工具模块。"""


def load_data(path):
    """加载数据。"""
    return []


def save_model(model, path):
    """保存模型。"""
    pass
