# -*- coding: utf-8 -*-
"""自进化系统：异步分析5个真实数据源，动态生成通用进化建议。

架构：
- learn_async(task_result) → 立即返回，后台daemon线程跑 _analyze()
- _analyze() 读取错误学习+记忆+训练数据+缓存+反思 → 动态发现规律 → 生成建议
- 全部异步+try/except，绝不阻塞主任务流程
"""
import json
import os
import time
import threading
from collections import defaultdict
from typing import Any, Dict, List, Optional

__version__ = "0.5"
__all__ = ["SelfEvolution"]


class SelfEvolution:
    """异步自进化引擎：从真实数据动态发现规律，生成通用优化建议。"""

    def __init__(self, storage_path: str = None,
                 error_storage=None, memory_tier=None,
                 vector_system=None, smart_cache=None, reflection=None):
        self.experiences: List[Dict] = []
        self.patterns = defaultdict(int)
        self.task_quality = defaultdict(list)
        self.evolution_suggestions: List[Dict] = []
        self.total_learned = 0
        self._lock = threading.Lock()
        self._error_storage = error_storage
        self._memory_tier = memory_tier
        self._vector_system = vector_system
        self._smart_cache = smart_cache
        self._reflection = reflection
        self.storage_path = storage_path or os.path.join(
            "data", "用户数据", "自进化", "evolution_history.json")
        self._load()

    # ---------- 公开异步接口 ----------

    def learn_async(self, task_result: dict) -> bool:
        """异步触发进化分析，立即返回不阻塞。后台daemon线程执行。"""
        try:
            t = threading.Thread(target=self._analyze, args=(task_result,), daemon=True)
            t.start()
            return True
        except Exception:
            return False

    def learn(self, task_type: str = "", result: dict = None, **kwargs) -> bool:
        """兼容接口：异步触发分析。"""
        if result is None:
            result = {"quality": kwargs.get("score", 0)}
            result.update(kwargs)
        if task_type:
            result["task_type"] = task_type
        return self.learn_async(result)

    def record(self, task_type: str = "", score: float = 0, **kwargs) -> bool:
        """兼容接口。"""
        return self.learn(task_type, {"quality": score, **kwargs})

    def get_evolution_suggestions(self, limit: int = 10) -> List[dict]:
        with self._lock:
            return list(self.evolution_suggestions[-limit:])

    def apply_evolution(self, suggestion_id: str) -> bool:
        try:
            with self._lock:
                for s in self.evolution_suggestions:
                    if s.get("id") == suggestion_id:
                        s["applied"] = True
                        self._save()
                        return True
            return False
        except Exception:
            return False

    def get_stats(self) -> dict:
        with self._lock:
            avg_q = {tt: round(sum(s) / len(s), 2) for tt, s in self.task_quality.items() if s}
            return {
                "total_experiences": len(self.experiences),
                "total_learned": self.total_learned,
                "patterns_count": len(self.patterns),
                "suggestions_count": len(self.evolution_suggestions),
                "avg_quality_by_type": avg_q,
            }

    # ---------- 后台分析（daemon线程执行） ----------

    def _analyze(self, task_result: dict):
        """后台线程：记录经验 + 拉取5个真实数据源 + 动态生成建议。"""
        try:
            quality = float(task_result.get("quality", 0))
            success = bool(task_result.get("success", True))
            tt = task_result.get("task_type", "general")
            with self._lock:
                entry = {
                    "task_type": tt,
                    "quality": quality,
                    "category": task_result.get("category", "unknown"),
                    "success": success,
                    "exec_time": float(task_result.get("exec_time", 0)),
                    "total_done": task_result.get("total_done"),
                    "timestamp": time.time(),
                }
                self.experiences.append(entry)
                self.task_quality[tt].append(quality)
                self.patterns[f"{tt}:{entry['category']}"] += 1
                self.total_learned += 1
            # 拉取5个数据源并动态分析
            self._ensure_sources()
            self._analyze_and_suggest(task_result)
            with self._lock:
                self._save()
        except Exception:
            pass

    def _ensure_sources(self):
        """延迟实例化未传入的数据源。全部try/except。"""
        try:
            if self._error_storage is None:
                from src.ximu.core.learning.error_learning import ErrorStorage
                self._error_storage = ErrorStorage()
        except Exception:
            self._error_storage = None
        try:
            if self._memory_tier is None:
                from src.ximu.core.memory.memory_system import LongTermMemory
                self._memory_tier = LongTermMemory()
        except Exception:
            self._memory_tier = None
        try:
            if self._smart_cache is None:
                from src.ximu.core.smart_cache import get_instance as _gc
                self._smart_cache = _gc()
        except Exception:
            self._smart_cache = None
        try:
            if self._reflection is None:
                from src.ximu.cognition.brain.reflection_engine import ReflectionEngine
                self._reflection = ReflectionEngine()
        except Exception:
            self._reflection = None

    # ---------- 5个数据源采集（全部try/except） ----------

    def _collect_errors(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"total": 0, "top_cats": []}
        try:
            if self._error_storage is not None:
                s = self._error_storage.get_statistics()
                out["total"] = s.get("total_records", 0)
                out["top_cats"] = s.get("top_categories", [])
        except Exception:
            pass
        try:
            p = os.path.join("data", "用户数据", "错误与学习", "错误学习", "error_library.json")
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8") as f:
                    d = json.load(f)
                recs = d.get("records", [])
                out["total"] = max(out["total"], len(recs))
                cats: Dict[str, int] = {}
                for r in recs:
                    c = r.get("error_category") or r.get("category") or "unknown"
                    cats[c] = cats.get(c, 0) + 1
                out["file_cats"] = sorted(cats.items(), key=lambda x: x[1], reverse=True)[:5]
        except Exception:
            pass
        return out

    def _collect_memory(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"entries": 0, "tags": []}
        try:
            if self._memory_tier is not None and hasattr(self._memory_tier, "_store"):
                store = self._memory_tier._store
                out["entries"] = len(store)
                tc: Dict[str, int] = {}
                for e in store.values():
                    for t in (e.tags if hasattr(e, "tags") else []):
                        tc[t] = tc.get(t, 0) + 1
                out["tags"] = sorted(tc.items(), key=lambda x: x[1], reverse=True)[:10]
        except Exception:
            pass
        return out

    def _collect_training_data(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"files": 0, "types": {}}
        try:
            td = os.path.join("data", "training_data")
            if os.path.isdir(td):
                files = [f for f in os.listdir(td) if f.endswith(".jsonl")]
                out["files"] = len(files)
                for fn in files[:20]:
                    name = fn.replace("train_", "").replace(".jsonl", "")
                    fp = os.path.join(td, fn)
                    try:
                        with open(fp, "r", encoding="utf-8") as f:
                            out["types"][name] = sum(1 for _ in f)
                    except Exception:
                        out["types"][name] = -1
        except Exception:
            pass
        return out

    def _collect_cache(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"hit_rate": None}
        try:
            if self._smart_cache is not None and hasattr(self._smart_cache, "stats"):
                s = self._smart_cache.stats()
                out.update(s if isinstance(s, dict) else {})
                if "hits" in s and "misses" in s:
                    t = s["hits"] + s["misses"]
                    out["hit_rate"] = round(s["hits"] / t, 3) if t > 0 else None
        except Exception:
            pass
        return out

    def _collect_reflection(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"available": False}
        try:
            if self._reflection is not None and hasattr(self._reflection, "stats"):
                out["available"] = True
                out["summary"] = self._reflection.stats()
        except Exception:
            pass
        return out

    # ---------- 动态分析生成建议（通用，不按任务类型） ----------

    def _analyze_and_suggest(self, task_result: dict):
        """基于5个数据源的真实数据动态发现规律，生成通用建议。去重。"""
        existing_types = {s.get("type") for s in self.evolution_suggestions}
        new_sugs: List[Dict] = []
        now = time.time()

        # 数据源1：错误趋势
        try:
            err = self._collect_errors()
            total_err = err.get("total", 0)
            recent_fails = sum(1 for e in self.experiences[-50:] if not e.get("success"))
            if total_err > 20 and recent_fails > 5:
                sug_type = "error_trend_warning"
                if sug_type not in existing_types:
                    new_sugs.append({
                        "id": f"sug_{int(now)}_{len(self.evolution_suggestions)}",
                        "type": sug_type,
                        "description": f"累计错误{total_err}条，近50次执行失败{recent_fails}次，建议关注输入质量与端点稳定性",
                        "confidence": 0.7, "source": "error_storage",
                        "created_at": now, "applied": False,
                    })
        except Exception:
            pass

        # 数据源2：记忆积累
        try:
            mem = self._collect_memory()
            if mem["entries"] > 50:
                sug_type = "memory_consolidation"
                if sug_type not in existing_types:
                    new_sugs.append({
                        "id": f"sug_{int(now)}_{len(self.evolution_suggestions)}",
                        "type": sug_type,
                        "description": f"长期记忆已积累{mem['entries']}条，建议执行记忆整理与策略提取",
                        "confidence": 0.5, "source": "long_term_memory",
                        "created_at": now, "applied": False,
                    })
        except Exception:
            pass

        # 数据源3：训练数据分布
        try:
            td = self._collect_training_data()
            if td["files"] > 0:
                sparse = {k: v for k, v in td.get("types", {}).items() if 0 < v < 5}
                if len(sparse) >= 2:
                    sug_type = "data_density_balance"
                    if sug_type not in existing_types:
                        new_sugs.append({
                            "id": f"sug_{int(now)}_{len(self.evolution_suggestions)}",
                            "type": sug_type,
                            "description": f"训练数据分布不均，{len(sparse)}类样本不足5条，建议均衡补充",
                            "confidence": 0.55, "source": "training_data",
                            "created_at": now, "applied": False,
                        })
        except Exception:
            pass

        # 数据源4：缓存命中率
        try:
            cache = self._collect_cache()
            hr = cache.get("hit_rate")
            if hr is not None and hr < 0.2:
                sug_type = "cache_policy_optimize"
                if sug_type not in existing_types:
                    new_sugs.append({
                        "id": f"sug_{int(now)}_{len(self.evolution_suggestions)}",
                        "type": sug_type,
                        "description": f"缓存命中率仅{hr*100:.1f}%，建议调整缓存key粒度或TTL策略",
                        "confidence": 0.75, "source": "smart_cache",
                        "created_at": now, "applied": False,
                    })
        except Exception:
            pass

        # 数据源5：反思系统在线状态
        try:
            refl = self._collect_reflection()
            if refl.get("available") and self.total_learned % 20 == 0:
                sug_type = "reflection_review"
                if sug_type not in existing_types:
                    new_sugs.append({
                        "id": f"sug_{int(now)}_{len(self.evolution_suggestions)}",
                        "type": sug_type,
                        "description": "反思系统在线，建议定期复盘反思结论以优化决策链路",
                        "confidence": 0.5, "source": "reflection_engine",
                        "created_at": now, "applied": False,
                    })
        except Exception:
            pass

        # 动态质量趋势（不按固定阈值，看整体趋势）
        try:
            if len(self.experiences) >= 10:
                recent = [e["quality"] for e in self.experiences[-10:]]
                older = [e["quality"] for e in self.experiences[-30:-10]] if len(self.experiences) >= 30 else recent
                if older:
                    avg_recent = sum(recent) / len(recent)
                    avg_older = sum(older) / len(older)
                    if avg_recent < avg_older - 5:
                        sug_type = "quality_decline"
                        if sug_type not in existing_types:
                            new_sugs.append({
                                "id": f"sug_{int(now)}_{len(self.evolution_suggestions)}",
                                "type": sug_type,
                                "description": f"整体质量趋势下降（{avg_older:.1f}→{avg_recent:.1f}），建议检查模型端点与输入",
                                "confidence": 0.65, "source": "internal_trend",
                                "created_at": now, "applied": False,
                            })
        except Exception:
            pass

        with self._lock:
            self.evolution_suggestions.extend(new_sugs)

    # ---------- 持久化 ----------

    def _load(self):
        try:
            if os.path.exists(self.storage_path):
                with open(self.storage_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.experiences = data.get("experiences", [])
                self.evolution_suggestions = data.get("suggestions", [])
                self.total_learned = data.get("total_learned", 0)
                for e in self.experiences:
                    tt = e.get("task_type", "")
                    self.task_quality[tt].append(e.get("quality", 0))
                    self.patterns[f"{tt}:{e.get('category', '')}"] += 1
        except Exception:
            pass

    def _save(self):
        try:
            d = os.path.dirname(self.storage_path)
            if d:
                os.makedirs(d, exist_ok=True)
            data = {
                "experiences": self.experiences[-500:],
                "suggestions": self.evolution_suggestions[-100:],
                "total_learned": self.total_learned,
                "version": __version__,
            }
            with open(self.storage_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
