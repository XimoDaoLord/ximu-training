"""Part 2 of pattern_extraction (lines 2775-3283 of 3283)."""
import logging
logger = logging.getLogger("src.ximu.core.learning._pattern_extraction_parts.part2")
import os
import json
import threading
from typing import Any, Callable, Dict, List
from collections import defaultdict, deque, Counter
from .part1 import BehaviorPattern
from .part1 import BehaviorPatternStore
from .part3 import CandidatePatternStore
from .part3 import CausalPatternStore
from .part1 import DialoguePatternStore
from .part1 import ErrorRecord
from .part1 import ExtractionAlgorithm
from .part3 import FilteredPatternStore
from .part1 import FrequentPatternStore
from .part1 import LearningItem
from .part1 import LearningPhase
from .part1 import LearningType
from .part1 import Pattern
from .part1 import PatternCategory
from .part3 import RawPatternStore
from .part1 import SequencePattern
from .part1 import SequencePatternStore
from .part1 import TemporalPatternStore
from .part3 import ValidatedPatternStore
from src.ximu.common.utils import generate_id
from src.ximu.common.utils import now_timestamp

class SequenceMinerRegistry:
    def __init__(self,**kwargs):
        self._stores:Dict[str,Any]={}
        self._config:Dict[str,Any]=dict(kwargs)
        self._lock=threading.RLock()
        self._event_handlers:Dict[str,List[Callable]]=defaultdict(list)
        self._metrics:Dict[str,float]=defaultdict(float)
        self._history:deque=deque(maxlen=500)
        self._initialized=False
        self._last_maintenance=0.0
        self._maintenance_interval=300.0
    def register_store(self,name,store_obj):
        """
        Register store (SequenceMinerRegistry).
        @param name: Input.
        @param store_obj: Input.
        """
        with self._lock:
            self._stores[name]=store_obj
            self._emit("store_registered",{"name":name})
    def get_store(self,name):
        """
        Get store.
        @param name: Input.
        @return: Value.
        """
        with self._lock:return self._stores.get(name)
    def remove_store(self,name):
        """
        Remove store.
        @param name: Input.
        """
        with self._lock:
            s=self._stores.pop(name,None)
            if s:self._emit("store_removed",{"name":name})
            return s is not None
    def on(self,event,handler):
        """
        On (SequenceMinerRegistry).
        @param event: Input.
        @param handler: Input.
        """
        with self._lock:self._event_handlers[event].append(handler)
    def off(self,event,handler):
        """
        Off (SequenceMinerRegistry).
        @param event: Input.
        @param handler: Input.
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)
    def _emit(self,event,data=None):
        handlers=self._event_handlers.get(event,[])
        for h in handlers:
            try:h(data or {})
            except Exception as e:  # 合理忽略：回调/可选操作失败不影响主流程
                logger.debug("操作失败: %s", e, exc_info=True)
    def record_metric(self,name,value):
        """
        Record metric (SequenceMinerRegistry).
        @param name: Input.
        @param value: Input.
        """
        with self._lock:
            self._metrics[name]+=value
            self._history.append({"metric":name,"value":value,"timestamp":now_timestamp()})
    def get_metric(self,name):
        """
        Get metric.
        @param name: Input.
        @return: Value.
        """
        with self._lock:return self._metrics.get(name,0.0)
    def get_all_metrics(self):
        """
        Get all metrics.
        @return: Value.
        """
        with self._lock:return dict(self._metrics)
    def reset_metrics(self):
        """Reset metrics method of SequenceMinerRegistry."""
        with self._lock:self._metrics.clear()
    def get_history(self,limit=100):
        """
        Get historical records.
        @param limit: Input.
        @return: List of records.
        """
        with self._lock:return list(self._history)[-limit:]
    def initialize(self):
        """Initialize method of SequenceMinerRegistry."""
        with self._lock:
            if self._initialized:return False
            self._initialized=True
            self._emit("initialized",{})
            return True
    def shutdown(self):
        """Shutdown method of SequenceMinerRegistry."""
        with self._lock:
            if not self._initialized:return False
            self._initialized=False
            self._emit("shutdown",{})
            return True
    def maintenance(self,force=False):
        """
        Maintenance (SequenceMinerRegistry).
        @param force: Input.
        """
        with self._lock:
            now=now_timestamp()
            if not force and now-self._last_maintenance<self._maintenance_interval:
                return {"status":"skipped"}
            cleaned=0
            for name,s in self._stores.items():
                if hasattr(s,"cleanup_expired"):
                    try:cleaned+=s.cleanup_expired()
                    except Exception as e:  # 合理忽略：回调/可选操作失败不影响主流程
                        logger.debug("操作失败: %s", e, exc_info=True)
            self._last_maintenance=now
            self._emit("maintenance",{"cleaned":cleaned})
            return {"status":"done","cleaned":cleaned}
    def get_stats(self):
        """
        Get current statistics snapshot.
        @return: Dict of statistics.
        """
        with self._lock:
            store_stats={}
            for name,s in self._stores.items():
                if hasattr(s,"get_stats"):
                    try:store_stats[name]=s.get_stats()
                    except Exception:store_stats[name]="error"
                elif hasattr(s,"size"):
                    store_stats[name]={"size":s.size()}
            return {"initialized":self._initialized,"stores":store_stats,
                "metrics":dict(self._metrics),"history":len(self._history)}
    def to_dict(self):
        """
        Convert the object to a dictionary representation.
        @return: Dict with public attributes.
        """
        with self._lock:
            return {"config":dict(self._config),"metrics":dict(self._metrics),
                "stores":list(self._stores.keys())}
    def export_state(self,filepath):
        """
        Export internal state.
        @param filepath: Input.
        @return: State dict.
        """
        with open(filepath,"w",encoding="utf-8") as f:
            json.dump(self.to_dict(),f,ensure_ascii=False,default=str)
    def import_state(self,filepath):
        """Import internal state from a dictionary."""
        if not os.path.exists(filepath):return False
        with open(filepath,"r",encoding="utf-8") as f:
            data=json.load(f)
        with self._lock:
            if "config" in data:self._config.update(data["config"])
            if "metrics" in data:self._metrics.update(data["metrics"])
        return True

class BehaviorAnalyzer:
    def __init__(self,**kwargs):
        self._stores:Dict[str,Any]={}
        self._config:Dict[str,Any]=dict(kwargs)
        self._lock=threading.RLock()
        self._event_handlers:Dict[str,List[Callable]]=defaultdict(list)
        self._metrics:Dict[str,float]=defaultdict(float)
        self._history:deque=deque(maxlen=500)
        self._initialized=False
        self._last_maintenance=0.0
        self._maintenance_interval=300.0
    def register_store(self,name,store_obj):
        """
        Register store (BehaviorAnalyzer).
        @param name: Input.
        @param store_obj: Input.
        """
        with self._lock:
            self._stores[name]=store_obj
            self._emit("store_registered",{"name":name})
    def get_store(self,name):
        """
        Get store.
        @param name: Input.
        @return: Value.
        """
        with self._lock:return self._stores.get(name)
    def remove_store(self,name):
        """
        Remove store.
        @param name: Input.
        """
        with self._lock:
            s=self._stores.pop(name,None)
            if s:self._emit("store_removed",{"name":name})
            return s is not None
    def on(self,event,handler):
        """
        On (BehaviorAnalyzer).
        @param event: Input.
        @param handler: Input.
        """
        with self._lock:self._event_handlers[event].append(handler)
    def off(self,event,handler):
        """
        Off (BehaviorAnalyzer).
        @param event: Input.
        @param handler: Input.
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)
    def _emit(self,event,data=None):
        handlers=self._event_handlers.get(event,[])
        for h in handlers:
            try:h(data or {})
            except Exception as e:  # 合理忽略：回调/可选操作失败不影响主流程
                logger.debug("操作失败: %s", e, exc_info=True)
    def record_metric(self,name,value):
        """
        Record metric (BehaviorAnalyzer).
        @param name: Input.
        @param value: Input.
        """
        with self._lock:
            self._metrics[name]+=value
            self._history.append({"metric":name,"value":value,"timestamp":now_timestamp()})
    def get_metric(self,name):
        """
        Get metric.
        @param name: Input.
        @return: Value.
        """
        with self._lock:return self._metrics.get(name,0.0)
    def get_all_metrics(self):
        """
        Get all metrics.
        @return: Value.
        """
        with self._lock:return dict(self._metrics)
    def reset_metrics(self):
        """Reset metrics method of BehaviorAnalyzer."""
        with self._lock:self._metrics.clear()
    def get_history(self,limit=100):
        """
        Get historical records.
        @param limit: Input.
        @return: List of records.
        """
        with self._lock:return list(self._history)[-limit:]
    def initialize(self):
        """Initialize method of BehaviorAnalyzer."""
        with self._lock:
            if self._initialized:return False
            self._initialized=True
            self._emit("initialized",{})
            return True
    def shutdown(self):
        """Shutdown method of BehaviorAnalyzer."""
        with self._lock:
            if not self._initialized:return False
            self._initialized=False
            self._emit("shutdown",{})
            return True
    def maintenance(self,force=False):
        """
        Maintenance (BehaviorAnalyzer).
        @param force: Input.
        """
        with self._lock:
            now=now_timestamp()
            if not force and now-self._last_maintenance<self._maintenance_interval:
                return {"status":"skipped"}
            cleaned=0
            for name,s in self._stores.items():
                if hasattr(s,"cleanup_expired"):
                    try:cleaned+=s.cleanup_expired()
                    except Exception as e:  # 合理忽略：回调/可选操作失败不影响主流程
                        logger.debug("操作失败: %s", e, exc_info=True)
            self._last_maintenance=now
            self._emit("maintenance",{"cleaned":cleaned})
            return {"status":"done","cleaned":cleaned}
    def get_stats(self):
        """
        Get current statistics snapshot.
        @return: Dict of statistics.
        """
        with self._lock:
            store_stats={}
            for name,s in self._stores.items():
                if hasattr(s,"get_stats"):
                    try:store_stats[name]=s.get_stats()
                    except Exception:store_stats[name]="error"
                elif hasattr(s,"size"):
                    store_stats[name]={"size":s.size()}
            return {"initialized":self._initialized,"stores":store_stats,
                "metrics":dict(self._metrics),"history":len(self._history)}
    def to_dict(self):
        """
        Convert the object to a dictionary representation.
        @return: Dict with public attributes.
        """
        with self._lock:
            return {"config":dict(self._config),"metrics":dict(self._metrics),
                "stores":list(self._stores.keys())}
    def export_state(self,filepath):
        """
        Export internal state.
        @param filepath: Input.
        @return: State dict.
        """
        with open(filepath,"w",encoding="utf-8") as f:
            json.dump(self.to_dict(),f,ensure_ascii=False,default=str)
    def import_state(self,filepath):
        """Import internal state from a dictionary."""
        if not os.path.exists(filepath):return False
        with open(filepath,"r",encoding="utf-8") as f:
            data=json.load(f)
        with self._lock:
            if "config" in data:self._config.update(data["config"])
            if "metrics" in data:self._metrics.update(data["metrics"])
        return True

class PatternFilter:
    def __init__(self,**kwargs):
        self._stores:Dict[str,Any]={}
        self._config:Dict[str,Any]=dict(kwargs)
        self._lock=threading.RLock()
        self._event_handlers:Dict[str,List[Callable]]=defaultdict(list)
        self._metrics:Dict[str,float]=defaultdict(float)
        self._history:deque=deque(maxlen=500)
        self._initialized=False
        self._last_maintenance=0.0
        self._maintenance_interval=300.0
    def register_store(self,name,store_obj):
        """
        Register store (PatternFilter).
        @param name: Input.
        @param store_obj: Input.
        """
        with self._lock:
            self._stores[name]=store_obj
            self._emit("store_registered",{"name":name})
    def get_store(self,name):
        """
        Get store.
        @param name: Input.
        @return: Value.
        """
        with self._lock:return self._stores.get(name)
    def remove_store(self,name):
        """
        Remove store.
        @param name: Input.
        """
        with self._lock:
            s=self._stores.pop(name,None)
            if s:self._emit("store_removed",{"name":name})
            return s is not None
    def on(self,event,handler):
        """
        On (PatternFilter).
        @param event: Input.
        @param handler: Input.
        """
        with self._lock:self._event_handlers[event].append(handler)
    def off(self,event,handler):
        """
        Off (PatternFilter).
        @param event: Input.
        @param handler: Input.
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)
    def _emit(self,event,data=None):
        handlers=self._event_handlers.get(event,[])
        for h in handlers:
            try:h(data or {})
            except Exception as e:  # 合理忽略：回调/可选操作失败不影响主流程
                logger.debug("操作失败: %s", e, exc_info=True)
    def record_metric(self,name,value):
        """
        Record metric (PatternFilter).
        @param name: Input.
        @param value: Input.
        """
        with self._lock:
            self._metrics[name]+=value
            self._history.append({"metric":name,"value":value,"timestamp":now_timestamp()})
    def get_metric(self,name):
        """
        Get metric.
        @param name: Input.
        @return: Value.
        """
        with self._lock:return self._metrics.get(name,0.0)
    def get_all_metrics(self):
        """
        Get all metrics.
        @return: Value.
        """
        with self._lock:return dict(self._metrics)
    def reset_metrics(self):
        """Reset metrics method of PatternFilter."""
        with self._lock:self._metrics.clear()
    def get_history(self,limit=100):
        """
        Get historical records.
        @param limit: Input.
        @return: List of records.
        """
        with self._lock:return list(self._history)[-limit:]
    def initialize(self):
        """Initialize method of PatternFilter."""
        with self._lock:
            if self._initialized:return False
            self._initialized=True
            self._emit("initialized",{})
            return True
    def shutdown(self):
        """Shutdown method of PatternFilter."""
        with self._lock:
            if not self._initialized:return False
            self._initialized=False
            self._emit("shutdown",{})
            return True
    def maintenance(self,force=False):
        """
        Maintenance (PatternFilter).
        @param force: Input.
        """
        with self._lock:
            now=now_timestamp()
            if not force and now-self._last_maintenance<self._maintenance_interval:
                return {"status":"skipped"}
            cleaned=0
            for name,s in self._stores.items():
                if hasattr(s,"cleanup_expired"):
                    try:cleaned+=s.cleanup_expired()
                    except Exception as e:  # 合理忽略：回调/可选操作失败不影响主流程
                        logger.debug("操作失败: %s", e, exc_info=True)
            self._last_maintenance=now
            self._emit("maintenance",{"cleaned":cleaned})
            return {"status":"done","cleaned":cleaned}
    def get_stats(self):
        """
        Get current statistics snapshot.
        @return: Dict of statistics.
        """
        with self._lock:
            store_stats={}
            for name,s in self._stores.items():
                if hasattr(s,"get_stats"):
                    try:store_stats[name]=s.get_stats()
                    except Exception:store_stats[name]="error"
                elif hasattr(s,"size"):
                    store_stats[name]={"size":s.size()}
            return {"initialized":self._initialized,"stores":store_stats,
                "metrics":dict(self._metrics),"history":len(self._history)}
    def to_dict(self):
        """
        Convert the object to a dictionary representation.
        @return: Dict with public attributes.
        """
        with self._lock:
            return {"config":dict(self._config),"metrics":dict(self._metrics),
                "stores":list(self._stores.keys())}
    def export_state(self,filepath):
        """
        Export internal state.
        @param filepath: Input.
        @return: State dict.
        """
        with open(filepath,"w",encoding="utf-8") as f:
            json.dump(self.to_dict(),f,ensure_ascii=False,default=str)
    def import_state(self,filepath):
        """Import internal state from a dictionary."""
        if not os.path.exists(filepath):return False
        with open(filepath,"r",encoding="utf-8") as f:
            data=json.load(f)
        with self._lock:
            if "config" in data:self._config.update(data["config"])
            if "metrics" in data:self._metrics.update(data["metrics"])
        return True

class PatternValidator:
    def __init__(self,**kwargs):
        self._stores:Dict[str,Any]={}
        self._config:Dict[str,Any]=dict(kwargs)
        self._lock=threading.RLock()
        self._event_handlers:Dict[str,List[Callable]]=defaultdict(list)
        self._metrics:Dict[str,float]=defaultdict(float)
        self._history:deque=deque(maxlen=500)
        self._initialized=False
        self._last_maintenance=0.0
        self._maintenance_interval=300.0
    def register_store(self,name,store_obj):
        """
        Register store (PatternValidator).
        @param name: Input.
        @param store_obj: Input.
        """
        with self._lock:
            self._stores[name]=store_obj
            self._emit("store_registered",{"name":name})
    def get_store(self,name):
        """
        Get store.
        @param name: Input.
        @return: Value.
        """
        with self._lock:return self._stores.get(name)
    def remove_store(self,name):
        """
        Remove store.
        @param name: Input.
        """
        with self._lock:
            s=self._stores.pop(name,None)
            if s:self._emit("store_removed",{"name":name})
            return s is not None
    def on(self,event,handler):
        """
        On (PatternValidator).
        @param event: Input.
        @param handler: Input.
        """
        with self._lock:self._event_handlers[event].append(handler)
    def off(self,event,handler):
        """
        Off (PatternValidator).
        @param event: Input.
        @param handler: Input.
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)
    def _emit(self,event,data=None):
        handlers=self._event_handlers.get(event,[])
        for h in handlers:
            try:h(data or {})
            except Exception as e:  # 合理忽略：回调/可选操作失败不影响主流程
                logger.debug("操作失败: %s", e, exc_info=True)
    def record_metric(self,name,value):
        """
        Record metric (PatternValidator).
        @param name: Input.
        @param value: Input.
        """
        with self._lock:
            self._metrics[name]+=value
            self._history.append({"metric":name,"value":value,"timestamp":now_timestamp()})
    def get_metric(self,name):
        """
        Get metric.
        @param name: Input.
        @return: Value.
        """
        with self._lock:return self._metrics.get(name,0.0)
    def get_all_metrics(self):
        """
        Get all metrics.
        @return: Value.
        """
        with self._lock:return dict(self._metrics)
    def reset_metrics(self):
        """Reset metrics method of PatternValidator."""
        with self._lock:self._metrics.clear()
    def get_history(self,limit=100):
        """
        Get historical records.
        @param limit: Input.
        @return: List of records.
        """
        with self._lock:return list(self._history)[-limit:]
    def initialize(self):
        """Initialize method of PatternValidator."""
        with self._lock:
            if self._initialized:return False
            self._initialized=True
            self._emit("initialized",{})
            return True
    def shutdown(self):
        """Shutdown method of PatternValidator."""
        with self._lock:
            if not self._initialized:return False
            self._initialized=False
            self._emit("shutdown",{})
            return True
    def maintenance(self,force=False):
        """
        Maintenance (PatternValidator).
        @param force: Input.
        """
        with self._lock:
            now=now_timestamp()
            if not force and now-self._last_maintenance<self._maintenance_interval:
                return {"status":"skipped"}
            cleaned=0
            for name,s in self._stores.items():
                if hasattr(s,"cleanup_expired"):
                    try:cleaned+=s.cleanup_expired()
                    except Exception as e:  # 合理忽略：回调/可选操作失败不影响主流程
                        logger.debug("操作失败: %s", e, exc_info=True)
            self._last_maintenance=now
            self._emit("maintenance",{"cleaned":cleaned})
            return {"status":"done","cleaned":cleaned}
    def get_stats(self):
        """
        Get current statistics snapshot.
        @return: Dict of statistics.
        """
        with self._lock:
            store_stats={}
            for name,s in self._stores.items():
                if hasattr(s,"get_stats"):
                    try:store_stats[name]=s.get_stats()
                    except Exception:store_stats[name]="error"
                elif hasattr(s,"size"):
                    store_stats[name]={"size":s.size()}
            return {"initialized":self._initialized,"stores":store_stats,
                "metrics":dict(self._metrics),"history":len(self._history)}
    def to_dict(self):
        """
        Convert the object to a dictionary representation.
        @return: Dict with public attributes.
        """
        with self._lock:
            return {"config":dict(self._config),"metrics":dict(self._metrics),
                "stores":list(self._stores.keys())}
    def export_state(self,filepath):
        """
        Export internal state.
        @param filepath: Input.
        @return: State dict.
        """
        with open(filepath,"w",encoding="utf-8") as f:
            json.dump(self.to_dict(),f,ensure_ascii=False,default=str)
    def import_state(self,filepath):
        """Import internal state from a dictionary."""
        if not os.path.exists(filepath):return False
        with open(filepath,"r",encoding="utf-8") as f:
            data=json.load(f)
        with self._lock:
            if "config" in data:self._config.update(data["config"])
            if "metrics" in data:self._metrics.update(data["metrics"])
        return True

class FrequentItemsetMiner:
    def __init__(self,min_support=0.01,min_confidence=0.3,min_count=1):
        # P127：min_count 为绝对最小共现次数（默认1=兼容旧行为）。
        # 仅当 count>=min_support*n 且 count>=min_count 才算频繁，
        # 避免 n 很小/单条事务时所有项集 support=1.0 噪声入模式库。
        self.min_support=min_support;self.min_confidence=min_confidence
        self.min_count=min_count
        self._transactions:List[List[str]]=[];self._lock=threading.Lock()
    def add_transaction(self,items):
        """
        Add a transaction.
        @param items: Input.
        """
        with self._lock:self._transactions.append(items)
    def mine(self,max_size=5):
        """
        Mine (FrequentItemsetMiner).
        @param max_size: Input.
        """
        with self._lock:
            if not self._transactions:return []
            n=len(self._transactions)
            item_counts=Counter()
            for t in self._transactions:
                for item in set(t):item_counts[item]+=1
            freq={item:c for item,c in item_counts.items()
                if c/n>=self.min_support and c>=self.min_count}
            patterns=[]
            for item,support in freq.items():
                patterns.append(Pattern(pattern_id=generate_id("p"),name=item,elements=[item],
                    support=support/n,confidence=1.0,frequency=support))
            current_level={frozenset([item]):c for item,c in freq.items()}
            for size in range(2,max_size+1):
                candidates=set()
                items_list=list(current_level.keys())
                for i in range(len(items_list)):
                    for j in range(i+1,len(items_list)):
                        union=items_list[i]|items_list[j]
                        if len(union)==size:candidates.add(union)
                next_level={}
                for cand in candidates:
                    count=sum(1 for t in self._transactions if cand.issubset(set(t)))
                    if count/n>=self.min_support and count>=self.min_count:
                        next_level[cand]=count
                        patterns.append(Pattern(pattern_id=generate_id("p"),
                            name="_".join(sorted(cand)),elements=sorted(cand),
                            support=count/n,confidence=count/n,frequency=count))
                if not next_level:break
                current_level=next_level
            patterns.sort(key=lambda p:p.support,reverse=True)
            return patterns[:1000]
    def get_stats(self):
        """
        Get current statistics snapshot.
        @return: Dict of statistics.
        """
        with self._lock:return {"transactions":len(self._transactions)}

class SequenceMiner:
    def __init__(self,min_support=0.01,max_gap=5):
        self.min_support=min_support;self.max_gap=max_gap
        self._sequences:List[List[str]]=[];self._lock=threading.Lock()
    def add_sequence(self,seq):
        """
        Add a sequence.
        @param seq: Input.
        """
        with self._lock:self._sequences.append(seq)
    def mine(self,max_length=5):
        """
        Mine (SequenceMiner).
        @param max_length: Input.
        """
        with self._lock:
            if not self._sequences:return []
            n=len(self._sequences)
            patterns=[]
            single=Counter()
            for seq in self._sequences:
                for item in set(seq):single[item]+=1
            for item,count in single.items():
                if count/n>=self.min_support:
                    patterns.append(SequencePattern(seq_id=generate_id("sp"),sequence=[item],
                        support=count/n,confidence=1.0))
            current={item:count for item,count in single.items() if count/n>=self.min_support}
            for length in range(2,max_length+1):
                next_patterns={}
                for prefix,count in current.items():
                    if isinstance(prefix,str):prefix=[prefix]
                    for seq in self._sequences:
                        for i in range(len(seq)):
                            if seq[i:i+len(prefix)]==prefix:
                                for j in range(i+len(prefix),min(i+len(prefix)+self.max_gap,len(seq))):
                                    new_seq=tuple(prefix+[seq[j]])
                                    next_patterns[new_seq]=next_patterns.get(new_seq,0)+1
                current={k:v for k,v in next_patterns.items() if v/n>=self.min_support}
                for seq_t,count in current.items():
                    patterns.append(SequencePattern(seq_id=generate_id("sp"),
                        sequence=list(seq_t),support=count/n,confidence=count/n))
            patterns.sort(key=lambda p:p.support,reverse=True)
            return patterns[:500]
    def get_stats(self):
        """
        Get current statistics snapshot.
        @return: Dict of statistics.
        """
        with self._lock:return {"sequences":len(self._sequences)}

class PatternExtractor:
    def __init__(self):
        self.frequent_store=FrequentPatternStore(20000)
        self.sequence_store=SequencePatternStore(10000)
        self.behavior_store=BehaviorPatternStore(10000)
        self.dialogue_store=DialoguePatternStore(10000)
        self.temporal_store=TemporalPatternStore(5000)
        self.causal_store=CausalPatternStore(5000)
        self.candidate_store=CandidatePatternStore(30000)
        self.validated_store=ValidatedPatternStore(10000)
        self.raw_store=RawPatternStore(50000)
        self.filtered_store=FilteredPatternStore(20000)
        # P127：生产侧用绝对最小共现次数 min_count=3，杜绝单条/少量事务噪声模式入模式库；
        # 直接构造 FrequentItemsetMiner 的单测仍走默认 min_count=1，行为不变。
        self.frequent_miner=FrequentItemsetMiner(min_count=3)
        self.sequence_miner=SequenceMiner()
        self.frequent_miner_mgr=FrequentItemsetMiner(min_count=3)
        self.sequence_miner_mgr=SequenceMiner()
        self.behavior_analyzer=BehaviorAnalyzer()
        self.pattern_filter=PatternFilter()
        self.pattern_validator=PatternValidator()
        self._lock=threading.RLock()
    def extract(self,transactions,sequences=None,behaviors=None):
        """
        Extract (PatternExtractor).
        @param transactions: Input.
        @param sequences: Input.
        @param behaviors: Input.
        """
        for t in transactions:self.frequent_miner.add_transaction(t)
        if sequences:
            for s in sequences:self.sequence_miner.add_sequence(s)
        freq_patterns=self.frequent_miner.mine()
        seq_patterns=self.sequence_miner.mine() if sequences else []
        for p in freq_patterns:self.candidate_store.add(p)
        for p in seq_patterns:self.sequence_store.add(p)
        return {"frequent":len(freq_patterns),"sequence":len(seq_patterns)}
    def get_stats(self):
        """
        Get current statistics snapshot.
        @return: Dict of statistics.
        """
        return {"frequent":self.frequent_store.get_stats(),"sequence":self.sequence_store.get_stats(),
            "behavior":self.behavior_store.get_stats(),"candidate":self.candidate_store.get_stats(),
            "validated":self.validated_store.get_stats()}

_default_pe=None;_pe_lock=threading.Lock()
def get_pattern_extractor():
    """
    Get pattern extractor.
    @return: Value.
    """
    global _default_pe
    with _pe_lock:
        if _default_pe is None:_default_pe=PatternExtractor()
        return _default_pe

__all__=["LearningPhase","LearningType","PatternCategory","ExtractionAlgorithm","LearningItem","Pattern","ErrorRecord","SequencePattern","BehaviorPattern","FrequentPatternStore","SequencePatternStore","BehaviorPatternStore","DialoguePatternStore","TemporalPatternStore","CausalPatternStore","CandidatePatternStore","ValidatedPatternStore","RawPatternStore","FilteredPatternStore","FrequentItemsetMiner","SequenceMiner","BehaviorAnalyzer","PatternFilter","PatternValidator","PatternExtractor","get_pattern_extractor"]
