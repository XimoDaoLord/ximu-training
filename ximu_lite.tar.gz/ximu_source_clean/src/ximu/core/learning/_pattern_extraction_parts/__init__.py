"""Split parts of pattern_extraction."""

__all__ = [
    "__version__",
]

__version__ = "0.5"
