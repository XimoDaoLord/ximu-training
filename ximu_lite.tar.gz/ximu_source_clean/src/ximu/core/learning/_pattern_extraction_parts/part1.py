"""
Part 1 of pattern_extraction (lines 2-2773 of 3283).
"""
from src.ximu.common.utils import score_stored_item
import logging
logger = logging.getLogger("src.ximu.core.learning._pattern_extraction_parts.part1")
import os
import json
import time
import uuid
import heapq
import threading
import random
import re
from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Set, Tuple, TypeVar
from collections import OrderedDict, defaultdict, Counter
from datetime import datetime, timedelta, timezone

"""
汐沫AI - 对话模式提取 Pattern Extraction System
"""

try:
    from config.settings import config
except ImportError:
    config = None

def generate_id(prefix: str = "id") -> str:
    """
    Generate a unique id.

    Args:
        prefix (str, optional): Prefix for the id. Defaults to "id".

    Returns:
        str: Unique id.
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"

def now_timestamp() -> float:
    """
    Get the current timestamp.

    Returns:
        float: Current timestamp.
    """
    return time.time()

def now_datetime() -> datetime:
    """
    Get the current datetime.

    Returns:
        datetime: Current datetime.
    """
    return datetime.now(timezone(timedelta(hours=8)))

def format_datetime(dt: datetime = None, fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    Format datetime.

    Args:
        dt (datetime, optional): Input datetime. Defaults to None.
        fmt (str, optional): Format string. Defaults to "%Y-%m-%d %H:%M:%S".

    Returns:
        str: Formatted datetime string.
    """
    if dt is None:
        dt = now_datetime()
    return dt.strftime(fmt)

class Stopwatch:
    def __init__(self):
        self._start_time = 0.0
        self._end_time = 0.0

    def start(self) -> 'Stopwatch':
        """
        Start the stopwatch.

        Returns:
            Stopwatch: Stopwatch instance.
        """
        self._start_time = time.time()
        return self

    def stop(self) -> 'Stopwatch':
        """
        Stop the stopwatch.

        Returns:
            Stopwatch: Stopwatch instance.
        """
        self._end_time = time.time()
        return self

    @property
    def elapsed_ms(self) -> float:
        """
        Get the elapsed time in milliseconds.

        Returns:
            float: Elapsed time in milliseconds.
        """
        return (self._end_time - self._start_time) * 1000

T = TypeVar("T")

class LearningPhase(str, Enum):
    """
    Learning phase.
    """
    PERCEPTION = "perception"
    ENCODING = "encoding"
    CONSOLIDATION = "consolidation"
    APPLICATION = "application"
    FEEDBACK = "feedback"
    EVOLUTION = "evolution"

class LearningType(str, Enum):
    """
    Learning type.
    """
    SUPERVISED = "supervised"
    UNSUPERVISED = "unsupervised"
    REINFORCEMENT = "reinforcement"
    ONLINE = "online"
    OFFLINE = "offline"
    TRANSFER = "transfer"
    META = "meta"

class PatternCategory(str, Enum):
    """
    Pattern category.
    """
    FREQUENT_ITEMSET = "frequent_itemset"
    SEQUENCE = "sequence"
    BEHAVIOR = "behavior"
    DIALOGUE = "dialogue"
    TEMPORAL = "temporal"
    SPATIAL = "spatial"
    CAUSAL = "causal"

class ExtractionAlgorithm(str, Enum):
    """
    Extraction algorithm.
    """
    APRIORI = "apriori"
    FP_GROWTH = "fp_growth"
    PREFIX_SPAN = "prefix_span"
    GSP = "gsp"
    MARKOV = "markov"
    NLP_BASED = "nlp_based"

@dataclass
class LearningItem:
    """
    Learning item.
    """
    item_id: str = ""
    content: str = ""
    store_type: str = "general"
    category: str = ""
    source: str = ""
    tags: List[str] = field(default_factory=list)
    created_at: float = 0.0
    updated_at: float = 0.0
    last_accessed: float = 0.0
    access_count: int = 0
    importance: float = 0.5
    weight: float = 1.0
    confidence: float = 0.5
    metadata: Dict[str, Any] = field(default_factory=dict)
    permanent: bool = False

    def __post_init__(self):
        """
        Post initialization.
        """
        now = now_timestamp()
        if self.created_at == 0.0:
            self.created_at = now
        if self.updated_at == 0.0:
            self.updated_at = now
        if self.last_accessed == 0.0:
            self.last_accessed = now

    def access(self):
        """
        Access the item.
        """
        self.last_accessed = now_timestamp()
        self.access_count += 1

    def is_expired(self) -> bool:
        """
        Check if the item is expired.

        Returns:
            bool: True if expired, False otherwise.
        """
        return False

    def get_strength(self) -> float:
        """
        Get the strength of the item.

        Returns:
            float: Strength of the item.
        """
        return (0.3 + 0.3 * min(1.0, self.access_count / 20.0) + 0.2 * self.confidence + 0.2 * self.importance) * self.weight

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the item to a dictionary.

        Returns:
            Dict[str, Any]: Dictionary representation of the item.
        """
        return asdict(self)

@dataclass
class Pattern:
    """
    Pattern.
    """
    pattern_id: str = ""
    name: str = ""
    pattern_type: str = "frequent"
    elements: List[str] = field(default_factory=list)
    support: float = 0.0
    confidence: float = 0.0
    lift: float = 1.0
    frequency: int = 0
    created_at: float = 0.0
    updated_at: float = 0.0
    usage_count: int = 0
    success_count: int = 0
    status: str = "candidate"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """
        Post initialization.
        """
        if self.created_at == 0.0:
            self.created_at = now_timestamp()
        if self.updated_at == 0.0:
            self.updated_at = now_timestamp()

    def record_usage(self, success: bool = True):
        """
        Record usage.

        Args:
            success (bool, optional): Success flag. Defaults to True.
        """
        self.usage_count += 1
        if success:
            self.success_count += 1
        self.updated_at = now_timestamp()

    @property
    def success_rate(self) -> float:
        """
        Get the success rate.

        Returns:
            float: Success rate.
        """
        return self.success_count / max(1, self.usage_count)

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the pattern to a dictionary.

        Returns:
            Dict[str, Any]: Dictionary representation of the pattern.
        """
        return asdict(self)

@dataclass
class ErrorRecord:
    """
    Error record.
    """
    error_id: str = ""
    error_type: str = "general"
    message: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    severity: str = "medium"
    created_at: float = 0.0
    resolved: bool = False
    resolution: str = ""
    resolved_at: float = 0.0
    recurrence_count: int = 0
    root_cause: str = ""
    predicted: bool = False
    prediction_confidence: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """
        Post initialization.
        """
        if self.created_at == 0.0:
            self.created_at = now_timestamp()

    def resolve(self, resolution: str, root_cause: str = ''):
        """
        Resolve the error.

        Args:
            resolution (str): Resolution.
            root_cause (str, optional): Root cause. Defaults to ''.
        """
        self.resolved = True
        self.resolution = resolution
        self.resolved_at = now_timestamp()
        if root_cause:
            self.root_cause = root_cause

    def record_recurrence(self):
        """
        Record recurrence.
        """
        self.recurrence_count += 1

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the error record to a dictionary.

        Returns:
            Dict[str, Any]: Dictionary representation of the error record.
        """
        return asdict(self)

@dataclass
class SequencePattern:
    """
    Sequence pattern.
    """
    seq_id: str = ""
    sequence: List[str] = field(default_factory=list)
    support: float = 0.0
    confidence: float = 0.0
    length: int = 0
    created_at: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """
        Post initialization.
        """
        if self.created_at == 0.0:
            self.created_at = now_timestamp()
        if self.length == 0 and self.sequence:
            self.length = len(self.sequence)

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the sequence pattern to a dictionary.

        Returns:
            Dict[str, Any]: Dictionary representation of the sequence pattern.
        """
        return asdict(self)

@dataclass
class BehaviorPattern:
    """
    Behavior pattern.
    """
    behavior_id: str = ""
    user_id: str = ""
    actions: List[str] = field(default_factory=list)
    frequency: int = 0
    time_distribution: Dict[str, int] = field(default_factory=dict)
    created_at: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """
        Post initialization.
        """
        if self.created_at == 0.0:
            self.created_at = now_timestamp()

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the behavior pattern to a dictionary.

        Returns:
            Dict[str, Any]: Dictionary representation of the behavior pattern.
        """
        return asdict(self)

class FrequentPatternStore:
    def __init__(self, max_items: int = 20000):
        """
        Initialize the frequent pattern store.

        Args:
            max_items (int, optional): Maximum number of items. Defaults to 20000.
        """
        self._items: Dict[str, Pattern] = {}
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._type_index: Dict[str, Set[str]] = defaultdict(set)
        self._source_index: Dict[str, Set[str]] = defaultdict(set)
        self._time_heap: List[Tuple[float, str]] = []
        self._max = max_items
        self._lock = threading.RLock()
        self._added = 0
        self._reads = 0
        self._deleted = 0
        self._updated = 0
        self._searches = 0
        self._cache_hits = 0
        self._cache_misses = 0
        self._query_cache: OrderedDict = OrderedDict()
        self._max_cache = 500

    def add(self, item: Pattern):
        """
        Add an item.

        Args:
            item (Pattern): Item to add.

        Returns:
            Pattern: Added item.
        """
        with self._lock:
            if len(self._items) >= self._max:
                self._evict_weakest()
            iid = getattr(item, "item_id", getattr(item, "entry_id", getattr(item, "id", generate_id("item"))))
            self._items[iid] = item
            for tag in getattr(item, "tags", []):
                self._tag_index[tag.lower()].add(iid)
            itype = getattr(item, "store_type", getattr(item, "category", getattr(item, "type", "general")))
            self._type_index[itype].add(iid)
            src = getattr(item, "source", "")
            if src:
                self._source_index[src].add(iid)
            heapq.heappush(self._time_heap, (getattr(item, "created_at", now_timestamp()), iid))
            self._added += 1
            self._invalidate_cache()
            return item

    def get(self, iid: str) -> Pattern:
        """
        Retrieve a value by key.

        Args:
            iid (str): Key.

        Returns:
            Pattern: Value or None.
        """
        with self._lock:
            item = self._items.get(iid)
            if item:
                if hasattr(item, "access"):
                    item.access()
                self._reads += 1
            return item

    def get_or_default(self, iid: str, default: Any = None) -> Pattern:
        """
        Get value or return default.

        Args:
            iid (str): Key.
            default (Any, optional): Default value. Defaults to None.

        Returns:
            Pattern: Value.
        """
        item = self.get(iid)
        return item if item is not None else default

    def remove(self, iid: str) -> bool:
        """
        Remove item by key.

        Args:
            iid (str): Key.

        Returns:
            bool: True if removed.
        """
        with self._lock:
            item = self._items.pop(iid, None)
            if item:
                for tag in getattr(item, "tags", []):
                    self._tag_index[tag.lower()].discard(iid)
                itype = getattr(item, "store_type", getattr(item, "category", getattr(item, "type", "general")))
                self._type_index[itype].discard(iid)
                src = getattr(item, "source", "")
                if src:
                    self._source_index[src].discard(iid)
                self._deleted += 1
                self._invalidate_cache()
            return True
        return False

    def update(self, iid: str, **kwargs) -> bool:
        """
        Update state with data.

        Args:
            iid (str): Key.
            **kwargs: Data to update.

        Returns:
            bool: True if updated.
        """
        with self._lock:
            item = self._items.get(iid)
            if item:
                for k, v in kwargs.items():
                    if hasattr(item, k):
                        setattr(item, k, v)
                if hasattr(item, "updated_at"):
                    item.updated_at = now_timestamp()
                self._updated += 1
                self._invalidate_cache()
                return True
            return False

    def contains(self, iid: str) -> bool:
        """
        Check if key exists.

        Args:
            iid (str): Key.

        Returns:
            bool: True if exists.
        """
        with self._lock:
            return iid in self._items

    def search(self, query: str, limit: int = 20, category: str = "", tags: List[str] = None, min_score: float = 0.0) -> List[Tuple[Pattern, float]]:
        """
        Search for items.

        Args:
            query (str): Search query.
            limit (int, optional): Limit. Defaults to 20.
            category (str, optional): Category. Defaults to "".
            tags (List[str], optional): Tags. Defaults to None.
            min_score (float, optional): Minimum score. Defaults to 0.0.

        Returns:
            List[Tuple[Pattern, float]]: List of matches.
        """
        with self._lock:
            cache_key = f"{query}:{category}:{tuple(tags or [])}:{min_score}:{limit}"
            if cache_key in self._query_cache:
                self._cache_hits += 1
                self._query_cache.move_to_end(cache_key)
                return self._query_cache[cache_key]
            self._cache_misses += 1
            self._searches += 1
            q = query.lower().strip()
            cids = set(self._items.keys())
            if category:
                cids &= self._type_index.get(category, set())
            if tags:
                tids = set()
                for t in tags:
                    tids.update(self._tag_index.get(t.lower(), set()))
                cids &= tids
            scored = []
            q_words = q.split()
            for iid in cids:
                item = self._items[iid]
                s = score_stored_item(item, q, q_words)
                if s > min_score:
                    scored.append((s, item))
            scored.sort(key=lambda x: x[0], reverse=True)
            result = [(item, s) for s, item in scored[:limit]]
            self._query_cache[cache_key] = result
            if len(self._query_cache) > self._max_cache:
                self._query_cache.popitem(last=False)
            return result

    def fuzzy_search(self, query: str, threshold: float = 0.6, limit: int = 20) -> List[Tuple[Pattern, float]]:
        """
        Fuzzy search items.

        Args:
            query (str): Query.
            threshold (float, optional): Threshold. Defaults to 0.6.
            limit (int, optional): Limit. Defaults to 20.

        Returns:
            List[Tuple[Pattern, float]]: List of matches.
        """
        with self._lock:
            q = query.lower()
            scored = []
            for iid, item in self._items.items():
                content = (getattr(item, "content") or "").lower()
                s = self._text_similarity(q, content)
                if s >= threshold:
                    scored.append((s, item))
            scored.sort(key=lambda x: x[0], reverse=True)
            return [(item, s) for s, item in scored[:limit]]

    def regex_search(self, pattern: str, limit: int = 20) -> List[Pattern]:
        """
        Regex search items.

        Args:
            pattern (str): Regex pattern.
            limit (int, optional): Limit. Defaults to 20.

        Returns:
            List[Pattern]: List of matches.
        """
        with self._lock:
            try:
                rx = re.compile(pattern, re.IGNORECASE)
            except re.error:
                return []
            result = []
            for iid, item in self._items.items():
                content = (getattr(item, "content") or "")
                if rx.search(content):
                    result.append(item)
                if len(result) >= limit:
                    break
            return result

    def _text_similarity(self, a: str, b: str) -> float:
        """
        Calculate text similarity.

        Args:
            a (str): Text A.
            b (str): Text B.

        Returns:
            float: Similarity.
        """
        if not a or not b:
            return 0.0
        sa, sb = set(a.split()), set(b.split())
        if not sa or not sb:
            return 0.0
        return len(sa & sb) / len(sa | sb)

    def get_by_type(self, ctype: str, limit: int = 100) -> List[Pattern]:
        """
        Get by type.

        Args:
            ctype (str): Type.
            limit (int, optional): Limit. Defaults to 100.

        Returns:
            List[Pattern]: List of matches.
        """
        with self._lock:
            items = list(self._items.values())
            if not items:
                return []
            return random.sample(items, min(limit, len(items)))

    def get_stats(self) -> Dict[str, Any]:
        """
        Get current statistics snapshot.

        Returns:
            Dict[str, Any]: Statistics.
        """
        with self._lock:
            types = Counter(getattr(i, "store_type", getattr(i, "category", getattr(i, "type", "general"))) for i in self._items.values())
            total_cache = self._cache_hits + self._cache_misses
            return {
                "total": len(self._items),
                "max": self._max,
                "added": self._added,
                "reads": self._reads,
                "deleted": self._deleted,
                "updated": self._updated,
                "searches": self._searches,
                "cache_hits": self._cache_hits,
                "cache_misses": self._cache_misses,
                "cache_hit_rate": self._cache_hits / max(1, total_cache),
                "types": dict(types),
                "tags": len(self._tag_index),
                "sources": len(self._source_index)
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the object to a dictionary representation.

        Returns:
            Dict[str, Any]: Dictionary representation.
        """
        with self._lock:
            return {iid: asdict(i) if hasattr(i, "__dataclass_fields__") else str(i) for iid, i in self._items.items()}

    def export_json(self, filepath: str):
        """
        Export json.

        Args:
            filepath (str): Filepath.
        """
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, default=str)

    def import_json(self, filepath: str) -> int:
        """
        Import json.

        Args:
            filepath (str): Filepath.

        Returns:
            int: Number of items imported.
        """
        if not os.path.exists(filepath):
            return 0
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        count = 0
        for iid, item_data in data.items():
            if isinstance(item_data, dict):
                item_data.setdefault("item_id", iid)
                count += 1
        return count


# ===== 自动补全 =====

class BehaviorPatternStore:
    """BehaviorPatternStore - 行为模式存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class DialoguePatternStore:
    """DialoguePatternStore。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class DeprecatedPatternStore:
    """DeprecatedPatternStore。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class SequencePatternStore:
    """SequencePatternStore - 序列模式存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class TemporalPatternStore:
    """TemporalPatternStore - 时间模式存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)
