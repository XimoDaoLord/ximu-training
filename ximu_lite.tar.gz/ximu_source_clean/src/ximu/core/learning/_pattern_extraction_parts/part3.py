"""汐沫AI - 对话模式提取 Pattern Extraction System - Part 3: 数据存储与检索核心模块"""
import os
import json
import heapq
import logging
import threading
import random
import re
import redis
from collections import OrderedDict, defaultdict, Counter
from dataclasses import asdict
from typing import Any, Callable, Dict, List, Set, Tuple, Optional
from difflib import SequenceMatcher
from sortedcontainers import SortedList

try:
    from config.settings import config
except ImportError:
    config = None

logger = logging.getLogger("src.ximu.core.learning._pattern_extraction_parts.part3")

class PatternStoreBase:
    """
    模式存储基类，提供通用的索引管理、缓存优化及批量操作能力。
    """
    def __init__(self, max_items: int, redis_config: Dict = None):
        self._items: Dict[str, Any] = {}
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._type_index: Dict[str, Set[str]] = defaultdict(set)
        self._source_index: Dict[str, Set[str]] = defaultdict(set)
        self._time_list: SortedList = SortedList()
        self._weight_heap: List[Tuple[float, str]] = []
        self._max = max_items
        self._lock = threading.RLock()
        self._max_cache = 500
        self._query_cache = OrderedDict()
        self._redis = redis.Redis(**redis_config) if redis_config else None

        self._added = 0
        self._reads = 0
        self._deleted = 0
        self._updated = 0
        self._searches = 0
        self._cache_hits = 0
        self._cache_misses = 0

    def add(self, item: Any) -> Any:
        """添加一个模式项，自动处理索引更新、容量限制和缓存失效。
        Args:
            item: 要添加的模式项对象。
        Returns:
            添加后的模式项对象。
        """
        with self._lock:
            if len(self._items) >= self._max:
                self._evict_weakest()
            
            iid = getattr(item, "item_id", 
                         getattr(item, "entry_id", 
                         getattr(item, "id", generate_id("item"))))
            
            self._items[iid] = item
            self._time_list.add((getattr(item, "created_at", now_timestamp()), iid))
            self._weight_heap.append((getattr(item, "importance", 0.5), iid))
            
            for tag in getattr(item, "tags", []):
                self._tag_index[tag.lower()].add(iid)
            
            itype = getattr(item, "store_type", 
                            getattr(item, "category", 
                            getattr(item, "type", "general")))
            self._type_index[itype].add(iid)
            
            src = getattr(item, "source", "")
            if src:
                self._source_index[src].add(iid)
            
            self._added += 1
            self._invalidate_cache()
            logger.debug(f"Added item {iid} to store.")
            return item

    def get(self, iid: str) -> Optional[Any]:
        """根据ID获取模式项。
        Args:
            iid: 模式项的唯一标识符。
        Returns:
            模式项对象，如果不存在则返回 None。
        """
        with self._lock:
            item = self._items.get(iid)
            if item:
                if hasattr(item, "access"):
                    item.access()
                self._reads += 1
            return item

    def remove(self, iid: str) -> bool:
        """移除指定的模式项，并清理相关索引。
        Args:
            iid: 要移除的模式项ID。
        Returns:
            如果成功移除返回 True，否则返回 False。
        """
        with self._lock:
            item = self._items.pop(iid, None)
            if item:
                for tag in getattr(item, "tags", []):
                    self._tag_index[tag.lower()].discard(iid)
                
                itype = getattr(item, "store_type", 
                                getattr(item, "category", 
                                getattr(item, "type", "general")))
                self._type_index[itype].discard(iid)
                
                src = getattr(item, "source", "")
                if src:
                    self._source_index[src].discard(iid)
                
                self._deleted += 1
                self._invalidate_cache()
                logger.debug(f"Removed item {iid} from store.")
                return True
            return False

    def update(self, iid: str, **kwargs) -> bool:
        """更新模式项的属性。
        Args:
            iid: 模式项ID。
            **kwargs: 要更新的属性键值对。
        Returns:
            如果更新成功返回 True。
        """
        with self._lock:
            item = self._items.get(iid)
            if item:
                for k, v in kwargs.items():
                    if hasattr(item, k):
                        setattr(item, k, v)
                if hasattr(item, "updated_at"):
                    item.updated_at = now_timestamp()
                self._updated += 1
                self._invalidate_cache()
                return True
            return False

    def contains(self, iid: str) -> bool:
        """检查ID是否存在。
        Returns:
            是否存在。
        """
        with self._lock:
            return iid in self._items

    def search(self, query: str, limit: int = 20, category: str = "", tags: Optional[List[str]] = None, min_score: float = 0.0) -> List[Tuple[Any, float]]:
        """执行高级搜索，支持分类、标签过滤和分数阈值。
        Args:
            query: 搜索关键词。
            limit: 返回结果数量限制。
            category: 分类过滤。
            tags: 标签列表过滤。
            min_score: 最低分数阈值。
        Returns:
            包含 (item, score) 元组的列表。
        """
        with self._lock:
            cache_key = f"{query}:{category}:{tuple(tags or [])}:{min_score}:{limit}"
            
            if cache_key in self._query_cache:
                self._cache_hits += 1
                self._query_cache.move_to_end(cache_key)
                return self._query_cache[cache_key]
            
            self._cache_misses += 1
            self._searches += 1
            
            q = query.lower().strip()
            cids = set(self._items.keys())
            
            if category:
                cids &= self._type_index.get(category, set())
            if tags:
                tids = set()
                for t in tags:
                    tids.update(self._tag_index.get(t.lower(), set()))
                cids &= tids
            
            scored = []
            q_words = q.split()
            
            for iid in cids:
                item = self._items[iid]
                s = score_stored_item(item, q, q_words)
                if s > min_score:
                    scored.append((s, item))
            
            scored.sort(key=lambda x: x[0], reverse=True)
            result = [(item, s) for s, item in scored[:limit]]
            
            if self._redis:
                self._redis.setex(cache_key, 3600, json.dumps(result))
            else:
                self._query_cache[cache_key] = result
                if len(self._query_cache) > self._max_cache:
                    self._query_cache.popitem(last=False)
                
            return result

    def fuzzy_search(self, query: str, threshold: float = 0.6, limit: int = 20) -> List[Tuple[Any, float]]:
        """执行模糊搜索，基于文本相似度。
        Args:
            query: 查询字符串。
            threshold: 相似度阈值。
            limit: 结果数量限制。
        Returns:
            包含 (item, similarity) 元组的列表。
        """
        with self._lock:
            q = query.lower()
            scored = []
            
            for iid, item in self._items.items():
                content = (getattr(item, "content") or "").lower()
                s = self._calculate_similarity(q, content)
                if s >= threshold:
                    scored.append((s, item))
            
            scored.sort(key=lambda x: x[0], reverse=True)
            return [(item, s) for s, item in scored[:limit]]

    def regex_search(self, pattern: str, limit: int = 20) -> List[Any]:
        """执行正则表达式搜索。
        Args:
            pattern: 正则表达式字符串。
            limit: 结果数量限制。
        Returns:
            匹配的模式项列表。
        """
        with self._lock:
            try:
                rx = re.compile(pattern, re.IGNORECASE)
            except re.error as e:
                logger.error(f"Invalid regex pattern: {pattern}. Error: {e}")
                return []
            
            result = []
            for iid, item in self._items.items():
                content = getattr(item, "content", "")
                if rx.search(content):
                    result.append(item)
                    if len(result) >= limit:
                        break
            return result

    def _calculate_similarity(self, text1: str, text2: str) -> float:
        """计算两个文本的相似度分数。
        Args:
            text1: 文本1。
            text2: 文本2。
        Returns:
            相似度分数 (0.0 - 1.0)。
        """
        if not text1 or not text2:
            return 0.0
        return SequenceMatcher(None, text1, text2).ratio()

    def _evict_weakest(self):
        """基于权重堆进行淘汰策略。"""
        while self._weight_heap:
            weight, iid = self._weight_heap[0]
            if iid not in self._items:
                heapq.heappop(self._weight_heap)
                continue
            item = self._items[iid]
            if not getattr(item, "permanent", False):
                self.remove(iid)
                heapq.heappop(self._weight_heap)
                break
            heapq.heappop(self._weight_heap)

    def _invalidate_cache(self):
        """清空查询缓存。"""
        self._query_cache.clear()
        if self._redis:
            self._redis.flushall()

    def cleanupExpired(self) -> int:
        """清理过期的项。"""
        with self._lock:
            expired = [iid for iid, item in self._items.items() 
                       if hasattr(item, "is_expired") and item.isexpired()]
            for iid in expired:
                self.remove(iid)
            return len(expired)

    def batchAdd(self, items: List[Any]) -> List[Any]:
        """批量添加项。"""
        return [self.add(item) for item in items]

    def batchRemove(self, iids: List[str]) -> int:
        """批量移除项。"""
        return sum(1 for iid in iids if self.remove(iid))

    def batchGet(self, iids: List[str]) -> List[Any]:
        """批量获取项。"""
        return [self.get(iid) for iid in iids]

    def getTimeRange(self, start: float, end: float, limit: int = 100) -> List[Any]:
        """获取指定时间范围内的项。
        Args:
            start: 开始时间戳。
            end: 结束时间戳。
            limit: 结果数量限制。
        Returns:
            模式项列表。
        """
        with self._lock:
            ts_list = self._time_list.bounded_range(start, end)
            return [self._items[iid] for ts, iid in ts_list[:limit]]

    def getRecent(self, limit: int = 50) -> List[Any]:
        """获取最近的项。"""
        with self._lock:
            items = list(self._items.values())
            items.sort(key=lambda x: getattr(x, "created_at", 0), reverse=True)
            return items[:limit]

    def getOldest(self, limit: int = 50) -> List[Any]:
        """获取最旧的项。"""
        with self._lock:
            items = list(self._items.values())
            items.sort(key=lambda x: getattr(x, "created_at", 0))
            return items[:limit]

    def getAll(self) -> List[Any]:
        """获取所有项。"""
        with self._lock:
            return list(self._items.values())

    def getIds(self) -> List[str]:
        """获取所有ID。"""
        with self._lock:
            return list(self._items.keys())

    def size(self) -> int:
        """获取项数量。"""
        with self._lock:
            return len(self._items)

    def isEmpty(self) -> bool:
        """检查是否为空。"""
        with self._lock:
            return len(self._items) == 0

    def clear(self) -> None:
        """清空所有内部状态。"""
        with self._lock:
            self._items.clear()
            self._tag_index.clear()
            self._type_index.clear()
            self._source_index.clear()
            self._time_list.clear()
            self._weight_heap.clear()
            self._invalidate_cache()
            logger.info("Store cleared.")

    def getRandom(self, n: int = 1) -> List[Any]:
        """获取随机项。"""
        with self._lock:
            items = list(self._items.values())
            if not items:
                return []
            return random.sample(items, min(n, len(items)))

    def getStats(self) -> Dict[str, Any]:
        """获取统计信息。"""
        with self._lock:
            types = Counter(
                getattr(i, "store_type", getattr(i, "category", getattr(i, "type", "general"))) 
                for i in self._items.values()
            )
            total_cache = self._cache_hits + self._cache_misses
            return {
                "total": len(self._items),
                "max": self._max,
                "added": self._added,
                "reads": self._reads,
                "deleted": self._deleted,
                "updated": self._updated,
                "searches": self._searches,
                "cache_hits": self._cache_hits,
                "cache_misses": self._cache_misses,
                "cache_hit_rate": self._cache_hits / max(1, total_cache),
                "types": dict(types),
                "tags": len(self._tag_index),
                "sources": len(self._source_index)
            }

    def toDict(self) -> Dict[str, Any]:
        """转换为字典表示。"""
        with self._lock:
            return {
                iid: asdict(i) if hasattr(i, "__dataclass_fields__") else str(i) 
                for iid, i in self._items.items()
            }

    def exportJson(self, filepath: str) -> None:
        """导出数据到JSON文件。"""
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.toDict(), f, ensure_ascii=False, default=str)

    def importJson(self, filepath: str) -> int:
        """从JSON文件导入数据。"""
        if not os.path.exists(filepath):
            return 0
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            count = 0
            for iid, item_data in data.items():
                if isinstance(item_data, dict):
                    item_data.setdefault("item_id", iid)
                    count += 1
            return count
        except Exception as e:
            logger.error(f"Failed to import JSON from {filepath}: {e}")
            return 0

class CausalPatternStore(PatternStoreBase):
    """
    因果模式存储类，用于存储对话模式中的因果链数据。
    """
    def __init__(self, max_items: int = 5000):
        super().__init__(max_items=max_items)

class CandidatePatternStore(PatternStoreBase):
    """
    候选模式存储类，用于存储高密度的候选模式数据。
    """
    def __init__(self, max_items: int = 30000):
        super().__init__(max_items=max_items)


class FilteredPatternStore:
    """FilteredPatternStore。"""
    def __init__(self):
        self._data = {}


class RawPatternStore(PatternStoreBase):
    """
    原始模式存储类，用于存储未经过滤的原始模式数据。
    """
    def __init__(self, max_items: int = 50000):
        super().__init__(max_items=max_items)


class ValidatedPatternStore:
    """ValidatedPatternStore - 已验证模式存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)
