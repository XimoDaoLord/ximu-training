"""
模型模块，提供基础 Model 抽象类。
"""
from __future__ import annotations

import abc
from typing import Any, Dict, Optional

from src.ximu.core.learning.dataset import Dataset


class Model(abc.ABC):
    """模型抽象基类，定义训练、评估、保存接口。"""

    def __init__(self, hyperparameters: Optional[Dict[str, Any]] = None) -> None:
        self.hyperparameters: Dict[str, Any] = hyperparameters or {}
        self._trained: bool = False

    @abc.abstractmethod
    def train(self, dataset: Dataset) -> None:
        """使用数据集训练模型。"""
        ...

    @abc.abstractmethod
    def evaluate(self) -> Dict[str, float]:
        """评估模型性能，返回指标字典。"""
        ...

    @abc.abstractmethod
    def save(self, path: str) -> None:
        """保存模型到指定路径。"""
        ...

    @property
    def is_trained(self) -> bool:
        return self._trained
