"""电路熔断器核心模块，采用分片懒加载设计，保持0.5版本兼容性。"""
from __future__ import annotations
import importlib as _il
import logging as _logging
from typing import Dict, Any, Optional
import warnings as _warnings
import sys

# 线程安全缓存容器
class _ThreadSafeCache:
    """确保多线程环境下模块缓存的线程安全性"""
    def __init__(self):
        self._cache: Dict[str, Any] = {}
        self._lock = _logging.Lock()

    def __getitem__(self, key: str) -> Any:
        with self._lock:
            if key not in self._cache:
                self._cache[key] = _load_part(key)
            return self._cache[key]

    def __contains__(self, key: str) -> bool:
        with self._lock:
            return key in self._cache

# 分片加载器
def _load_part(part: str) -> Any:
    """安全加载指定模块部分，记录详细加载日志"""
    _logging.info(f"开始加载分片模块: {_PARTS[part]}")
    try:
        module = _il.import_module(f"._{PARTS[part]}", package=__package__)
        _logging.debug(f"成功加载模块: {_PARTS[part]}")
        return module
    except SpecificModuleNotFoundError as e:
        _logging.error(f"模块加载失败: {_PARTS[part]}", exc_info=e)
        raise
    except Exception as e:
        _logging.error(f"未知错误加载模块: {_PARTS[part]}", exc_info=e)
        raise

# 核心加载逻辑
def _cache_init() -> Dict[str, Any]:
    """初始化模块缓存，支持多线程安全"""
    global _cache
    if _cache is None:
        _cache = _ThreadSafeCache()
        _cache.load_all()
    return _cache

def _cache_load_all() -> Dict[str, Any]:
    """批量加载所有模块部分"""
    loaded = {}
    for part in PARTS:
        loaded[part] = _load_part(part)
    return loaded

# 懒加载主入口
def __getattr__(name: str) -> Any:
    """PEP562规范下的延迟属性加载"""
    if name.startswith('_'):
        raise AttributeError(f"私有属性: {name}")

    cache = _cache_init()
    
    try:
        return cache[name]
    except KeyError:
        _logging.warning(f"未找到属性: {name!r}")
        raise AttributeError(f"模块 {__name__} 不包含属性 {name!r}") from None

# 分片元数据
PARTS: tuple[str, ...] = ('part1', 'part2', 'part3', 'part4', 'part5')
_CACHE: Optional[_ThreadSafeCache] = None

# 兼容性处理
def _try_import_paradigm() -> Optional[Any]:
    """尝试从子包导入核心类，记录兼容性日志"""
    try:
        _logging.info("尝试兼容Paradigm子包导入")
        from .paradigm.circuit_breaker import CircuitBreaker as _ParadigmCircuitBreaker
        return _ParadigmCircuitBreaker
    except (ImportError, ValueError) as e:
        _logging.error("Paradigm子包导入失败", exc_info=e)
        return None

# 初始化兼容性类
CircuitBreaker = _try_import_paradigm() or _default_circuit_breaker()

# 默认熔断器实现
def _default_circuit_breaker() -> Any:
    """默认熔断器实现，仅在兼容性失败时使用"""
    _logging.warning("主类未找到，使用默认实现")
    raise NotImplementedError("主类CircuitBreaker未找到")
