import importlib as _il
import logging as _logging
import warnings as _w

class L1ShortTermFacade:
    """L1短期记忆模块的向后兼容代理，重导出已拆分的部件。

    该类用于在拆分后保持导入路径不变，
    同时发出弃用警告。
    """
    def __init__(self):
        """初始化并触发相关模块的重导出。

        Raises:
            ImportError: 当无法导入相关部件时。
        """
        _w.warn("l1_short_term 已拆分，请从具体部件直接导入", DeprecationWarning, stacklevel=2)
        _reexport_parts(('part1', 'part2'), '_l1_short_term_parts', 'l1_short_term')

def _reexport_parts(parts, package_name, module_name):
    """重导出部件模块中的公开符号到当前命名空间。

    Args:
        parts (tuple[str]): 需导出的部件名列表。
        package_name (str): 部件包名称。
        module_name (str): 当前模块名（用于日志）。

    Raises:
        ImportError: 部件导入失败时。
    """
    logger = _logging.getLogger(__name__)
    for part in parts:
        try:
            mod = _il.import_module(f".{package_name}.{part}", package=__package__)
            for attr in dir(mod):
                if not attr.startswith('_'):
                    globals()[attr] = getattr(mod, attr)
        except Exception as e:
            logger.warning("重导出 %s.%s 失败: %s", module_name, part, e, exc_info=True)