"""
cog_tree — 认知轨迹树存储（P82 修复）

从 chat.db 的 topic_qa_tree 表读取某话题的思维树节点/边，
供 /api/v1/topics/<tid>/cog-tree 与 /cog-tree/<node_id> 端点使用。

P1 已将导图数据源从旧 cog_tree.db 迁移至 chat.db（与聊天主链路写入一致）；
本模块即为该迁移在 core 层的读取实现。

表结构（PRAGMA 确认，18 列）：
  node_id TEXT PRIMARY KEY
  topic_id TEXT NOT NULL
  parent_id TEXT
  message_id TEXT
  title TEXT
  summary TEXT
  node_type TEXT NOT NULL DEFAULT 'question'   -- root/question/answer/followup/branch
  model_used TEXT
  status TEXT NOT NULL DEFAULT 'active'         -- active/collapsed/archived/orphan
  depth INTEGER NOT NULL DEFAULT 0
  is_starred INTEGER NOT NULL DEFAULT 0
  is_edited INTEGER NOT NULL DEFAULT 0
  tags TEXT DEFAULT ''
  created_at TEXT NOT NULL
  updated_at TEXT NOT NULL
  is_error INTEGER DEFAULT 0
  personality_id TEXT DEFAULT ''
  personality_name TEXT DEFAULT ''
"""

from __future__ import annotations

import logging
import os
import sqlite3
import threading
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

# 模块级单连接（与 transit_hub._get_chat_db_conn 同模式；
# 不依赖 web_ui 层的线程局部连接，避免 core→ui 反向依赖）
_conn_lock = threading.Lock()
_conn: Optional[sqlite3.Connection] = None


def _resolve_chat_db_path() -> str:
    """解析 chat.db 路径。
    与 web_ui/app.py 的 CHAT_DB_PATH 解析逻辑对齐：
      1) XIMU_DATA_DIR 直连（最高优先级，与服务端 DATA_DIR 一致）
      2) data_root.chat_db_path()（用户数据/聊天与记忆/chat.db）
      3) data_root.get_user_data_dir() 兜底
    """
    # 1) XIMU_DATA_DIR 直连（服务端 DATA_DIR = XIMU_DATA_DIR or _CHAT_ROOT）
    #    CHAT_DB_PATH = os.path.join(DATA_DIR, 'chat.db')
    _env_dir = os.environ.get("XIMU_DATA_DIR", "").strip()
    if _env_dir:
        return os.path.join(_env_dir, "chat.db")
    # 2) data_root.chat_db_path()
    try:
        from src.ximu.core.data_root import chat_db_path as _cdbp
        return _cdbp()
    except Exception:
        pass
    # 3) data_root.get_user_data_dir() 兜底
    try:
        from src.ximu.core.data_root import get_user_data_dir
        return os.path.join(get_user_data_dir(), "聊天与记忆", "chat.db")
    except Exception:
        pass
    # 最终兜底
    return os.path.join(".", "chat.db")


def _get_conn() -> sqlite3.Connection:
    """获取 chat.db 连接（懒加载，模块级单连接，WAL 模式）。"""
    global _conn
    if _conn is not None:
        return _conn
    with _conn_lock:
        if _conn is not None:
            return _conn
        path = _resolve_chat_db_path()
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        c = sqlite3.connect(path, check_same_thread=False)
        c.row_factory = sqlite3.Row
        try:
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA busy_timeout=5000")
            c.execute("PRAGMA foreign_keys=ON")
        except sqlite3.Error:
            pass
        _conn = c
        logger.info("[cog_tree] chat.db 连接建立: %s", path)
        return _conn


def _row_to_node(row: sqlite3.Row, children_set: Set[str]) -> Dict[str, Any]:
    """将 topic_qa_tree 一行转为前端节点 dict。"""
    nid = row["node_id"]
    return {
        # 双 key 兼容：端点用 nodes[0]['id']，前端用 child.node_id
        "id": nid,
        "node_id": nid,
        "topic_id": row["topic_id"],
        "parent_id": row["parent_id"],
        "message_id": row["message_id"],
        "title": row["title"] or "",
        "summary": row["summary"] or "",
        "node_type": row["node_type"] or "question",
        "model_used": row["model_used"] or "",
        "status": row["status"] or "active",
        "depth": row["depth"] or 0,
        "is_starred": row["is_starred"] or 0,
        "is_edited": row["is_edited"] or 0,
        "tags": row["tags"] or "",
        "is_error": row["is_error"] or 0,
        "personality_id": row["personality_id"] or "",
        "personality_name": row["personality_name"] or "",
        "created_at": row["created_at"] or "",
        "updated_at": row["updated_at"] or "",
        # 前端用于判断是否可展开
        "has_children": 1 if nid in children_set else 0,
    }


class CogTreeStore:
    """某话题的认知轨迹树存储。"""

    def __init__(self, topic_id: str):
        self.topic_id = topic_id
        self._conn = _get_conn()

    # ------------------------------------------------------------------
    # 内部：批量取节点
    # ------------------------------------------------------------------
    def _query_nodes(self, where: str = "topic_id = ?", params: Tuple[str] = ()) -> List[sqlite3.Row]:
        sql = (
            "SELECT node_id, topic_id, parent_id, message_id, title, summary, "
            "node_type, model_used, status, depth, is_starred, is_edited, tags, "
            "is_error, personality_id, personality_name, created_at, updated_at "
            f"FROM topic_qa_tree WHERE {where} ORDER BY created_at ASC"
        )
        return list(self._conn.execute(sql, params or (self.topic_id,)).fetchall())

    # ------------------------------------------------------------------
    # 对外接口（端点已按这些方法调用）
    # ------------------------------------------------------------------
    def export_tree(self) -> Tuple[List[Dict[str, Any]], List[Dict[str, str]]]:
        """返回 (nodes, edges)。
        nodes: 该话题所有节点列表（含 has_children 标记）
        edges: 由 parent_id 推导的父子边 [{source, target}, ...]
        """
        try:
            rows = self._query_nodes()
        except sqlite3.OperationalError as e:
            logger.warning("[cog_tree] topic_qa_tree 表不存在或查询失败: %s", e)
            return [], []

        # 收集所有有子节点的 parent_id 集合，用于 has_children 标记
        children_set: Set[str] = set()
        for r in rows:
            pid = r["parent_id"]
            if pid:
                children_set.add(pid)

        nodes = [_row_to_node(r, children_set) for r in rows]

        edges: List[Dict[str, str]] = []
        for n in nodes:
            pid = n["parent_id"]
            if pid:
                edges.append({"source": pid, "target": n["node_id"]})

        return nodes, edges

    def get_children(self, node_id: str) -> List[Dict[str, Any]]:
        """返回某节点的直接子节点列表（按 created_at 升序）。"""
        try:
            rows = list(self._conn.execute(
                "SELECT node_id, topic_id, parent_id, message_id, title, summary, "
                "node_type, model_used, status, depth, is_starred, is_edited, tags, "
                "is_error, personality_id, personality_name, created_at, updated_at "
                "FROM topic_qa_tree WHERE parent_id = ? AND topic_id = ? "
                "ORDER BY created_at ASC",
                (node_id, self.topic_id),
            ).fetchall())
        except sqlite3.OperationalError as e:
            logger.warning("[cog_tree] get_children 查询失败: %s", e)
            return []

        # 子节点是否再拥有子节点
        child_ids = [r["node_id"] for r in rows]
        children_set: Set[str] = set()
        if child_ids:
            placeholders = ",".join("?" for _ in child_ids)
            try:
                pid_rows = self._conn.execute(
                    f"SELECT DISTINCT parent_id FROM topic_qa_tree "
                    f"WHERE parent_id IN ({placeholders}) AND topic_id = ?",
                    (*child_ids, self.topic_id),
                ).fetchall()
                children_set = {r[0] for r in pid_rows}
            except sqlite3.OperationalError:
                pass

        return [_row_to_node(r, children_set) for r in rows]

    def get_node(self, node_id: str) -> Optional[Dict[str, Any]]:
        """返回单个节点详情（无则 None）。"""
        try:
            r = self._conn.execute(
                "SELECT node_id, topic_id, parent_id, message_id, title, summary, "
                "node_type, model_used, status, depth, is_starred, is_edited, tags, "
                "is_error, personality_id, personality_name, created_at, updated_at "
                "FROM topic_qa_tree WHERE node_id = ? AND topic_id = ?",
                (node_id, self.topic_id),
            ).fetchone()
        except sqlite3.OperationalError as e:
            logger.warning("[cog_tree] get_node 查询失败: %s", e)
            return None
        if not r:
            return None
        return _row_to_node(r, set())


def get_cog_tree_store(topic_id: str) -> CogTreeStore:
    """工厂函数：返回某话题的 CogTreeStore 实例。
    端点调用：from src.ximu.core.memory.cog_tree import get_cog_tree_store
    """
    return CogTreeStore(topic_id)
