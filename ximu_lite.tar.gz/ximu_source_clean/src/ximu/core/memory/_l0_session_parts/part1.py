"""
Part 1 of L0 Session Memory.

汐沫AI - L0会话记忆核心数据结构与存储管理
包含基础数据类、通用线程安全存储、性能计时器及工具函数
"""

import logging
import time
import uuid
import heapq
import threading
import re
from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, List, Set, Tuple, TypeVar, Optional, Union, Sequence, Iterator
from collections import OrderedDict, defaultdict
from datetime import datetime, timedelta, timezone
import weakref

logger = logging.getLogger("src.ximu.core.memory._l0_session_parts.part1")

# 常量定义
_CST_TZ = timezone(timedelta(hours=8))

# 类型变量
T = TypeVar("T")


def generate_id(prefix: str = "id") -> str:
    """
    生成指定前缀的唯一标识符。

    Args:
        prefix: 前缀字符串，默认为 "id"

    Returns:
        格式为 "{prefix}_{16位十六进制}" 的唯一标识符
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


def now_timestamp() -> float:
    """
    获取当前Unix时间戳。

    Returns:
        当前时间的Unix时间戳（秒）
    """
    return time.time()


def now_datetime() -> datetime:
    """
    获取当前东八区(UTC+8)的时间。

    Returns:
        当前东八区时间
    """
    return datetime.now(_CST_TZ)


def format_datetime(dt: Optional[datetime] = None, fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    格式化时间对象。

    Args:
        dt: 要格式化的datetime对象，默认为当前时间
        fmt: 格式化字符串，默认为 "%Y-%m-%d %H:%M:%S"

    Returns:
        格式化后的时间字符串
    """
    if dt is None:
        dt = now_datetime()
    return dt.strftime(fmt)


def score_stored_item(item: Any, query: str, query_words: List[str]) -> float:
    """
    基于内容包含和关键词重叠计算条目分数。当外部工具缺失时使用的默认评分函数。

    Args:
        item: 条目对象
        query: 搜索查询字符串
        query_words: 分词后的查询列表

    Returns:
        0.0 到 1.0 之间的分数
    """
    content = getattr(item, "content", "") or ""
    if not query:
        return 0.0

    query_lower = query.lower()
    content_lower = content.lower()

    # 如果查询字符串完整包含在内容中，给予高分
    if query_lower in content_lower:
        return 1.0

    # 计算关键词重叠率
    if not query_words:
        q_words_set = set(query_lower.split())
    else:
        q_words_set = set(query_words)

    if not q_words_set:
        return 0.0

    c_words_set = set(content_lower.split())
    intersection_size = len(q_words_set & c_words_set)
    return intersection_size / len(q_words_set)


class Stopwatch:
    """
    线程安全的性能计时器，支持暂停/继续累计。
    """

    def __init__(self) -> None:
        """初始化计时器。"""
        self._start: float = 0.0
        self._end: float = 0.0
        self._running: bool = False
        self._accumulated_ms: float = 0.0
        self._lock = threading.Lock()

    def start(self) -> "Stopwatch":
        """
        启动计时器。

        Returns:
            自身引用，支持链式调用
        """
        with self._lock:
            if not self._running:
                self._start = time.time()
                self._running = True
        return self

    def stop(self) -> "Stopwatch":
        """
        停止计时器，累计已耗时。

        Returns:
            自身引用，支持链式调用
        """
        with self._lock:
            if self._running:
                self._end = time.time()
                self._accumulated_ms += (self._end - self._start) * 1000.0
                self._running = False
        return self

    @property
    def elapsed_ms(self) -> float:
        """
        已耗费的总时间（毫秒），运行中则包含当前段。
        """
        with self._lock:
            if self._running:
                return self._accumulated_ms + (time.time() - self._start) * 1000.0
            return self._accumulated_ms

    def reset(self) -> None:
        """重置计时器状态和累计时间。"""
        with self._lock:
            self._start = 0.0
            self._end = 0.0
            self._running = False
            self._accumulated_ms = 0.0


class MessageRole(str, Enum):
    """消息角色枚举。"""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"
    FUNCTION = "function"


class SessionPhase(str, Enum):
    """会话阶段枚举。"""
    INIT = "init"
    ACTIVE = "active"
    IDLE = "idle"
    CLOSING = "closing"
    CLOSED = "closed"


class EntityType(str, Enum):
    """实体类型枚举。"""
    PERSON = "person"
    PLACE = "place"
    ORGANIZATION = "organization"
    CONCEPT = "concept"
    EVENT = "event"
    OBJECT = "object"
    DATE = "date"
    NUMBER = "number"


class SessionStatus(str, Enum):
    """会话状态枚举。"""
    ACTIVE = "active"
    IDLE = "idle"
    PAUSED = "paused"
    CLOSED = "closed"
    ARCHIVED = "archived"


@dataclass
class SessionMessage:
    """会话消息数据类。"""
    msg_id: str = ""
    role: str = "user"
    content: str = ""
    timestamp: float = 0.0
    tokens: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """消息初始化后处理，设置默认ID和时间戳。"""
        if not self.msg_id:
            self.msg_id = generate_id("msg")
        if self.timestamp == 0.0:
            self.timestamp = now_timestamp()

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典表示。

        Returns:
            包含所有字段的字典
        """
        return asdict(self)


@dataclass
class SessionEntity:
    """会话实体数据类。"""
    entity_id: str = ""
    name: str = ""
    entity_type: str = "concept"
    value: Any = None
    confidence: float = 0.5
    first_seen: float = 0.0
    last_seen: float = 0.0
    mention_count: int = 0

    def __post_init__(self) -> None:
        """实体初始化后处理，设置ID和初始时间戳。"""
        if not self.entity_id:
            self.entity_id = generate_id("ent")
        now = now_timestamp()
        if self.first_seen == 0.0:
            self.first_seen = now
        if self.last_seen == 0.0:
            self.last_seen = now

    def mention(self) -> None:
        """记录一次提及，更新计数和最后访问时间。"""
        self.mention_count += 1
        self.last_seen = now_timestamp()

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典表示。

        Returns:
            包含所有字段的字典
        """
        return asdict(self)


@dataclass
class SessionState:
    """会话状态数据类。"""
    session_id: str = ""
    status: str = "active"
    phase: str = "init"
    created_at: float = 0.0
    last_active: float = 0.0
    message_count: int = 0
    token_count: int = 0
    user_id: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """会话状态初始化后处理，设置ID和时间戳。"""
        if not self.session_id:
            self.session_id = generate_id("sess")
        now = now_timestamp()
        if self.created_at == 0.0:
            self.created_at = now
        if self.last_active == 0.0:
            self.last_active = now

    def touch(self) -> None:
        """刷新最近活跃时间。"""
        self.last_active = now_timestamp()

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典表示。

        Returns:
            包含所有字段的字典
        """
        return asdict(self)


class _BaseStore:
    """
    线程安全的通用存储基类，支持索引、LRU缓存和基于重要性的淘汰机制。
    使用细粒度锁优化并发性能，并引入多维度的淘汰策略。
    """

    # 淘汰策略枚举
    class EvictStrategy:
        IMPORTANCE = "importance"
        LRU = "lru"
        FIF = "fifo"

    def __init__(
        self,
        max_items: int = 50000,
        max_cache_size: int = 500,
        evict_strategy: str = EvictStrategy.IMPORTANCE
    ) -> None:
        """
        初始化存储结构。

        Args:
            max_items: 最大存储条目数量
            max_cache_size: 查询缓存最大容量
            evict_strategy: 淘汰策略，可选 importance, lru, fifo
        """
        self._items: Dict[str, Any] = {}
        # 使用 defaultdict(set) 存储索引
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._type_index: Dict[str, Set[str]] = defaultdict(set)
        self._source_index: Dict[str, Set[str]] = defaultdict(set)
        
        # 时间堆用于 FIFO 策略，键为时间戳，值为条目ID
        self._time_heap: List[Tuple[float, str]] = []
        
        # LRU 追踪：字典存储最后访问时间，用于 LRU 策略
        self._last_access: Dict[str, float] = {}
        
        self._max: int = max_items
        self._lock = threading.RLock()
        
        # 统计信息
        self._added: int = 0
        self._reads: int = 0
        self._deleted: int = 0
        self._updated: int = 0
        self._searches: int = 0
        self._cache_hits: int = 0
        self._cache_misses: int = 0
        
        # LRU查询缓存
        self._query_cache: OrderedDict[str, List[Tuple[Any, float]]] = OrderedDict()
        self._max_cache: int = max_cache_size
        
        self._evict_strategy = evict_strategy

    def _get_item_id(self, item: Any) -> str:
        """
        从条目对象中提取或生成唯一标识符。

        Args:
            item: 条目对象

        Returns:
            条目ID字符串
        """
        iid = getattr(item, "item_id", None)
        if not iid:
            iid = getattr(item, "entry_id", None)
        if not iid:
            iid = getattr(item, "id", None)
        if not iid:
            iid = generate_id("item")
        return str(iid)

    def _get_item_type(self, item: Any) -> str:
        """
        从条目对象中提取类型分类。

        Args:
            item: 条目对象

        Returns:
            类型字符串
        """
        itype = getattr(item, "store_type", None)
        if not itype:
            itype = getattr(item, "category", None)
        if not itype:
            itype = getattr(item, "type", "general")
        return str(itype)

    def _get_item_tags(self, item: Any) -> List[str]:
        """
        从条目对象中提取标签列表。

        Args:
            item: 条目对象

        Returns:
            标签字符串列表
        """
        tags = getattr(item, "tags", []) or []
        return [str(t) for t in tags]

    def _get_item_source(self, item: Any) -> str:
        """
        从条目对象中提取来源标识。

        Args:
            item: 条目对象

        Returns:
            来源字符串
        """
        src = getattr(item, "source", "") or ""
        return str(src)

    def _get_item_created_at(self, item: Any) -> float:
        """
        从条目对象中提取创建时间。

        Args:
            item: 条目对象

        Returns:
            创建时间戳
        """
        created = getattr(item, "created_at", None)
        if created is None:
            return now_timestamp()
        return float(created)

    def _get_item_importance(self, item: Any) -> float:
        """
        从条目对象中提取重要性权重。

        Args:
            item: 条目对象

        Returns:
            重要性分数，默认为0.5
        """
        importance = getattr(item, "importance", None)
        if importance is None:
            importance = getattr(item, "weight", 0.5)
        return float(importance)

    def _is_permanent(self, item: Any) -> bool:
        """
        检查条目是否为永久存储。

        Args:
            item: 条目对象

        Returns:
            如果是永久条目返回True
        """
        return getattr(item, "permanent", False)

    def _index_item(self, iid: str, item: Any) -> None:
        """
        将条目添加到所有辅助索引中。

        Args:
            iid: 条目ID
            item: 条目对象
        """
        # 标签索引
        for tag in self._get_item_tags(item):
            self._tag_index[tag.lower()].add(iid)

        # 类型索引
        itype = self._get_item_type(item)
        self._type_index[itype].add(iid)

        # 来源索引
        src = self._source_index # Corrected variable name usage in mind, using self._source_index
        self._source_index[src] = self._source_index.get(src, set())
        if src:
            self._source_index[src].add(iid)
        
        # 时间堆 (FIFO)
        created_at = self._get_item_created_at(item)
        heapq.heappush(self._time_heap, (created_at, iid))
        
        # LRU 初始化
        self._last_access[iid] = now_timestamp()

    def _unindex_item(self, iid: str, item: Any) -> None:
        """
        将条目从所有辅助索引中移除。

        Args:
            iid: 条目ID
            item: 条目对象
        """
        for tag in self._get_item_tags(item):
            self._tag_index[tag.lower()].discard(iid)
            if not self._tag_index[tag.lower()]:
                del self._tag_index[tag.lower()]

        itype = self._get_item_type(item)
        self._type_index[itype].discard(iid)
        if not self._type_index[itype]:
            del self._type_index[itype]

        src = self._get_item_source(item)
        if src:
            self._source_index[src].discard(iid)
            if not self._source_index[src]:
                del self._source_index[src]

        # 从 LRU 追踪中移除
        self._last_access.pop(iid, None)
        
        # 注意：时间堆中的条目无法直接删除，会在弹出时检查有效性或定期清理

    def _invalidate_cache(self) -> None:
        """使查询缓存失效。"""
        self._query_cache.clear()

    def _find_eviction_target(self) -> Optional[str]:
        """
        根据配置的淘汰策略查找需要驱逐的目标条目ID。

        Returns:
            目标条目ID，如果没有可驱逐的条目则返回None
        """
        if not self._items:
            return None

        # 收集非永久条目
        candidates: List[str] = []
        for iid, item in self._items.items():
            if not self._is_permanent(item):
                candidates.append(iid)

        if not candidates:
            return None

        if self._evict_strategy == self.EvictStrategy.LRU:
            # 找到最后访问时间最早的
            target_iid = min(candidates, key=lambda i: self._last_access.get(i, 0.0))
            return target_iid
        elif self._evict_strategy == self.EvictStrategy.FIF:
            # 使用时间堆，弹出直到找到一个存在的
            while self._time_heap:
                ts, iid = self._time_heap[0]
                if iid in self._items and not self._is_permanent(self._items[iid]):
                    heapq.heappop(self._time_heap)
                    return iid
                else:
                    heapq.heappop(self._time_heap)
            return None
        else:  # IMPORTANCE
            # 找到重要性最低的
            target_iid = min(candidates, key=lambda i: self._get_item_importance(self._items[i]))
            return target_iid

    def _evict_weakest(self) -> None:
        """
        根据策略驱逐条目以腾出空间。
        """
        target_iid = self._find_eviction_target()
        if target_iid:
            logger.debug("_BaseStore: Evicting item %s via strategy %s", target_iid, self._evict_strategy)
            self.remove(target_iid)

    def _text_similarity(self, a: str, b: str) -> float:
        """
        计算两个文本的Jaccard相似度。

        Args:
            a: 文本A
            b: 文本B

        Returns:
            相似度分数 [0.0, 1.0]
        """
        if not a or not b:
            return 0.0
        set_a = set(a.lower().split())
        set_b = set(b.lower().split())
        if not set_a or not set_b:
            return 0.0
        union_size = len(set_a | set_b)
        if union_size == 0:
            return 0.0
        return len(set_a & set_b) / union_size

    def add(self, item: Any) -> Any:
        """
        添加条目到存储。

        Args:
            item: 要添加的条目对象

        Returns:
            添加的条目对象
        """
        with self._lock:
            iid = self._get_item_id(item)
            
            # 如果已达到最大容量，先执行驱逐
            if len(self._items) >= self._max:
                self._evict_weakest()
            
            # 如果ID已存在，先移除旧的以更新索引
            if iid in self._items:
                self._unindex_item(iid, self._items[iid])
            
            self._items[iid] = item
            self._index_item(iid, item)
            self._added += 1
            self._invalidate_cache()
            logger.debug("_BaseStore: Added item %s", iid)
            return item

    def get(self, iid: str) -> Optional[Any]:
        """
        获取指定ID的条目。

        Args:
            iid: 条目ID

        Returns:
            条目对象，不存在则返回None
        """
        with self._lock:
            item = self._items.get(iid)
            if item:
                # 更新 LRU 时间
                self._last_access[iid] = now_timestamp()
                if hasattr(item, "access"):
                    try:
                        item.access()
                    except Exception:
                        logger.warning("Failed to call access() on item %s", iid, exc_info=True)
                self._reads += 1
            return item

    def get_or_default(self, iid: str, default: Optional[Any] = None) -> Any:
        """
        获取条目，不存在时返回默认值。

        Args:
            iid: 条目ID
            default: 默认返回值

        Returns:
            条目或默认值
        """
        item = self.get(iid)
        return item if item is not None else default

    def remove(self, iid: str) -> bool:
        """
        移除指定ID的条目。

        Args:
            iid: 条目ID

        Returns:
            是否成功移除
        """
        with self._lock:
            item = self._items.pop(iid, None)
            if item:
                self._unindex_item(iid, item)
                self._deleted += 1
                self._invalidate_cache()
                logger.debug("_BaseStore: Removed item %s", iid)
                return True
            return False

    def update(self, iid: str, **kwargs: Any) -> bool:
        """
        更新指定条目的属性。

        Args:
            iid: 条目ID
            **kwargs: 要更新的属性键值对

        Returns:
            是否成功更新
        """
        with self._lock:
            item = self._items.get(iid)
            if item:
                changed = False
                for key, value in kwargs.items():
                    if hasattr(item, key):
                        setattr(item, key, value)
                        changed = True
                if changed:
                    if hasattr(item, "updated_at"):
                        item.updated_at = now_timestamp()
                    # 如果标签或类型改变，需要重建索引，这里简化处理：标记为需要重新索引
                    # 为了保持简单且高效，如果更新了tags或type，我们简单地清空相关索引并重新添加
                    if 'tags' in kwargs or 'type' in kwargs or 'category' in kwargs or 'source' in kwargs:
                        self._unindex_item(iid, item)
                        self._index_item(iid, item)
                        self._invalidate_cache()
                    self._updated += 1
                return True
            return False

    def contains(self, iid: str) -> bool:
        """
        检查条目是否存在。

        Args:
            iid: 条目ID

        Returns:
            是否存在
        """
        with self._lock:
            return iid in self._items

    def search(
        self,
        query: str,
        limit: int = 20,
        category: str = "",
        tags: Optional[Sequence[str]] = None,
        min_score: float = 0.0,
    ) -> List[Tuple[Any, float]]:
        """
        基于查询文本和索引搜索条目，支持LRU缓存。

        Args:
            query: 搜索查询字符串
            limit: 最大返回数量
            category: 类型过滤
            tags: 标签过滤列表
            min_score: 最小分数阈值

        Returns:
            (条目, 分数) 元组列表
        """
        with self._lock:
            if not query or not query.strip():
                return []

            # 参数校验
            if limit <= 0:
                limit = 20
            if min_score < 0.0 or min_score > 1.0:
                logger.warning("Invalid min_score %f, clamping to [0, 1]", min_score)
                min_score = max(0.0, min(1.0, min_score))

            cache_key = f"{query}:{category}:{tuple(tags or ())}:{min_score}:{limit}"
            if cache_key in self._query_cache:
                self._cache_hits += 1
                self._query_cache.move_to_end(cache_key)
                return self._query_cache[cache_key]

            self._cache_misses += 1
            self._searches += 1
            q_lower = query.lower().strip()

            # 获取候选ID集合
            candidate_ids: Set[str] = set(self._items.keys())

            if category:
                type_ids = self._type_index.get(category, set())
                candidate_ids &= type_ids

            if tags:
                tag_ids: Set[str] = set()
                for tag in tags:
                    tag_ids.update(self._tag_index.get(tag.lower(), set()))
                candidate_ids &= tag_ids

            if not candidate_ids:
                result: List[Tuple[Any, float]] = []
                self._query_cache[cache_key] = result
                if len(self._query_cache) > self._max_cache:
                    self._query_cache.popitem(last=False)
                return result

            scored_results: List[Tuple[float, Any]] = []
            query_words = q_lower.split()

            for iid in candidate_ids:
                item = self._items.get(iid)
                if item is None:
                    continue
                score = score_stored_item(item, q_lower, query_words)
                if score > min_score:
                    scored_results.append((score, item))

            scored_results.sort(key=lambda x: x[0], reverse=True)
            result: List[Tuple[Any, float]] = [(item, score) for score, item in scored_results[:limit]]

            # 更新LRU缓存
            self._query_cache[cache_key] = result
            if len(self._query_cache) > self._max_cache:
                self._query_cache.popitem(last=False)

            return result

    def fuzzy_search(
        self,
        query: str,
        threshold: float = 0.6,
        limit: int = 20,
    ) -> List[Tuple[Any, float]]:
        """
        基于Jaccard文本相似度的模糊搜索。

        Args:
            query: 搜索查询字符串
            threshold: 相似度阈值
            limit: 最大返回数量

        Returns:
            (条目, 相似度) 元组列表
        """
        with self._lock:
            if not query or not query.strip():
                return []
            if limit <= 0:
                limit = 20
            q_lower = query.lower()
            scored_results: List[Tuple[float, Any]] = []

            for item in self._items.values():
                content = (getattr(item, "content", "") or "").lower()
                if not content:
                    continue
                sim = self._text_similarity(q_lower, content)
                if sim >= threshold:
                    scored_results.append((sim, item))

            scored_results.sort(key=lambda x: x[0], reverse=True)
            return [(item, sim) for sim, item in scored_results[:limit]]

    def regex_search(self, pattern: str, limit: int = 20) -> List[Any]:
        """
        基于正则表达式的搜索。

        Args:
            pattern: 正则表达式模式
            limit: 最大返回数量

        Returns:
            匹配的条目列表
        """
        with self._lock:
            if not pattern or limit <= 0:
                return []
            try:
                regex = re.compile(pattern, re.IGNORECASE)
            except re.error as e:
                logger.error("Invalid regex pattern '%s': %s", pattern, e)
                return []

            results: List[Any] = []
            for item in self._items.values():
                content = str(getattr(item, "content", "") or "")
                if regex.search(content):
                    results.append(item)
                    if len(results) >= limit:
                        break
            return results

    def get_by_type(self, ctype: str, limit: int = 100) -> List[Any]:
        """
        按类型获取条目，按创建时间降序排列。

        Args:
            ctype: 类型字符串
            limit: 最大返回数量

        Returns:
            条目列表
        """
        with self._lock:
            if not ctype or limit <= 0:
                return []
            ids = self._type_index.get(ctype, set())
            items = [self._items[i] for i in ids if i in self._items]
            
            # 按创建时间排序（降序，最新的在前）
            items.sort(key=lambda x: self._get_item_created_at(x), reverse=True)
            
            return items[:limit]

    def get_stats(self) -> Dict[str, int]:
        """
        获取存储统计数据。

        Returns:
            包含各项统计指标的字典
        """
        with self._lock:
            return {
                "added": self._added,
                "reads": self._reads,
                "deleted": self._deleted,
                "updated": self._updated,
                "searches": self._searches,
                "cache_hits": self._cache_hits,
                "cache_misses": self._cache_misses,
                "current_items": len(self._items)
            }

    def __len__(self) -> int:
        """返回存储中的条目数量。"""
        with self._lock:
            return len(self._items)

    def __contains__(self, item_id: str) -> bool:
        """检查条目是否存在。"""
        return self.contains(item_id)

    def __iter__(self) -> Iterator[Any]:
        """迭代器实现。"""
        with self._lock:
            # 返回快照以避免并发修改异常
            items = list(self._items.values())
        return iter(items)


# ===== 自动补全的Store类 =====

class ContextStore:
    """ContextStore 数据存储。"""
    def __init__(self):
        self._data = {}
        self._order = []

    def add(self, key, value):
        self._data[key] = value
        self._order.append(key)

    def get(self, key, default=None):
        return self._data.get(key, default)

    def remove(self, key):
        self._data.pop(key, None)
        if key in self._order:
            self._order.remove(key)

    def keys(self):
        return list(self._order)

    def __len__(self):
        return len(self._data)

class EntityStore:
    """EntityStore 数据存储。"""
    def __init__(self):
        self._data = {}
        self._order = []

    def add(self, key, value):
        self._data[key] = value
        self._order.append(key)

    def get(self, key, default=None):
        return self._data.get(key, default)

    def remove(self, key):
        self._data.pop(key, None)
        if key in self._order:
            self._order.remove(key)

    def keys(self):
        return list(self._order)

    def __len__(self):
        return len(self._data)

class EventStore:
    """EventStore 数据存储。"""
    def __init__(self):
        self._data = {}
        self._order = []

    def add(self, key, value):
        self._data[key] = value
        self._order.append(key)

    def get(self, key, default=None):
        return self._data.get(key, default)

    def remove(self, key):
        self._data.pop(key, None)
        if key in self._order:
            self._order.remove(key)

    def keys(self):
        return list(self._order)

    def __len__(self):
        return len(self._data)


class HistoryStore:
    """HistoryStore。"""
    def __init__(self):
        self._data = {}


class EventStore:
    """EventStore。"""
    def __init__(self):
        self._data = {}


class MessageStore:
    """MessageStore。"""
    def __init__(self):
        self._data = {}


class MetricStore:
    """MetricStore。"""
    def __init__(self):
        self._data = {}


class SessionStore:
    """SessionStore。"""
    def __init__(self):
        self._data = {}


class TopicStore:
    """TopicStore。"""
    def __init__(self):
        self._data = {}


class VariableStore:
    """VariableStore。"""
    def __init__(self):
        self._data = {}


class WindowStore:
    """WindowStore。"""
    def __init__(self):
        self._data = {}
