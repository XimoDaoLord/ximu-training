"""
L0 会话内存，整合多个存储组件的顶层会话管理器。
"""
from __future__ import annotations

import logging
import os
import json
import threading
from typing import Any, Callable, Dict, List, Optional, Union
from collections import defaultdict, deque
from .part1 import (
    ContextStore,
    EntityStore,
    EntityType,
    EventStore,
    HistoryStore,
    MessageRole,
    MessageStore,
    MetricStore,
    SessionEntity,
    SessionMessage,
    SessionPhase,
    SessionState,
    SessionStatus,
    SessionStore,
    TopicStore,
    VariableStore,
    WindowStore,
)
from ...emotion._emotion_engine_parts.part1 import EmotionItem
from src.ximu.common.utils import generate_id, now_timestamp

# 模块级日志器
logger = logging.getLogger("src.ximu.core.memory._l0_session_parts.part2")


class _StoreMixin:
    """
    混合类，提供统一的 store 管理、事件发射、指标记录和生命周期功能。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化 _StoreMixin。

        :param kwargs: 可选参数
        """
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=500)
        self._initialized: bool = False
        self._last_maintenance: float = 0.0
        self._maintenance_interval: float = 300.0

    def register_store(self, name: str, store_obj: Any) -> None:
        """
        注册一个数据存储对象。

        :param name: 存储对象名称
        :param store_obj: 存储对象实例
        """
        with self._lock:
            self._stores[name] = store_obj
            self._emit("store_registered", {"name": name})
            logger.debug("已注册存储: %s", name)

    def get_store(self, name: str) -> Optional[Any]:
        """
        获取指定名称的存储对象。

        :param name: 存储对象名称
        :return: 存储对象实例或 None
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """
        移除指定名称的存储对象。

        :param name: 存储对象名称
        :return: 是否成功移除
        """
        with self._lock:
            s = self._stores.pop(name, None)
            if s:
                self._emit("store_removed", {"name": name})
                logger.debug("已移除存储: %s", name)
            return s is not None

    def on(self, event: str, handler: Callable[[Dict[str, Any]], None]) -> None:
        """
        注册事件处理器。

        :param event: 事件名称
        :param handler: 事件处理器函数
        """
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable[[Dict[str, Any]], None]) -> None:
        """
        注销事件处理器。

        :param event: 事件名称
        :param handler: 事件处理器函数
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Optional[Dict[str, Any]] = None) -> None:
        """
        内部方法，发射事件。

        :param event: 事件名称
        :param data: 事件数据
        """
        handlers = self._event_handlers.get(event, [])
        for h in handlers:
            try:
                h(data or {})
            except Exception as e:
                # 忽略回调失败，避免影响主流程
                logger.debug("操作失败: %s", e, exc_info=True)

    def record_metric(self, name: str, value: float) -> None:
        """
        记录一个指标值。

        :param name: 指标名称
        :param value: 指标值
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({"metric": name, "value": value, "timestamp": now_timestamp()})

    def get_metric(self, name: str) -> float:
        """
        获取指定指标的值。

        :param name: 指标名称
        :return: 指标值
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """
        获取所有指标。

        :return: 所有指标
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        """
        重置所有指标。
        """
        with self._lock:
            self._metrics.clear()

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取指标历史记录。

        :param limit: 历史记录限制
        :return: 历史记录
        """
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """
        初始化状态机。

        :return: 是否成功初始化
        """
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._emit("initialized", {})
            logger.debug("已初始化")
            return True

    def shutdown(self) -> bool:
        """
        关闭状态机。

        :return: 是否成功关闭
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            self._emit("shutdown", {})
            logger.debug("已关闭")
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """
        执行维护任务。

        :param force: 是否强制执行
        :return: 维护结果
        """
        with self._lock:
            now = now_timestamp()
            if not force and now - self._last_maintenance < self._maintenance_interval:
                return {"status": "skipped"}
            cleaned = 0
            for name, s in self._stores.items():
                if hasattr(s, "cleanup_expired"):
                    try:
                        cleaned += s.cleanup_expired()
                    except Exception as e:
                        logger.debug("维护失败: %s - %s", name, e, exc_info=True)
            self._last_maintenance = now
            self._emit("maintenance", {"cleaned": cleaned})
            logger.debug("维护完成, 清理数量: %d", cleaned)
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息。

        :return: 统计信息
        """
        with self._lock:
            store_stats: Dict[str, Any] = {}
            for name, s in self._stores.items():
                if hasattr(s, "get_stats"):
                    try:
                        store_stats[name] = s.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(s, "size"):
                    store_stats[name] = {"size": s.size()}
            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history),
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典表示。

        :return: 字典表示
        """
        with self._lock:
            return {
                "config": dict(self._config),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys()),
            }

    def export_state(self, filepath: str) -> None:
        """
        将状态导出到文件。

        :param filepath: 文件路径
        """
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, default=str)
        logger.debug("状态已导出到: %s", filepath)

    def import_state(self, filepath: str) -> bool:
        """
        从文件导入状态。

        :param filepath: 文件路径
        :return: 是否成功导入
        """
        if not os.path.exists(filepath):
            logger.warning("导入文件不存在: %s", filepath)
            return False
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        with self._lock:
            if "config" in data:
                self._config.update(data["config"])
            if "metrics" in data:
                self._metrics.update(data["metrics"])
        logger.debug("状态已从 %s 导入", filepath)
        return True


class ContextVariableStore(_StoreMixin):
    """
    上下文变量存储，提供基于 _StoreMixin 的统一管理。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化 ContextVariableStore。

        :param kwargs: 可选参数
        """
        super().__init__(**kwargs)
        logger.debug("ContextVariableStore 初始化完成")


class SessionMetrics(_StoreMixin):
    """
    会话指标管理器，提供基于 _StoreMixin 的统一管理。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化 SessionMetrics。

        :param kwargs: 可选参数
        """
        super().__init__(**kwargs)
        logger.debug("SessionMetrics 初始化完成")


class DialogueState(_StoreMixin):
    """
    对话状态管理器，提供基于 _StoreMixin 的统一管理。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化 DialogueState。

        :param kwargs: 可选参数
        """
        super().__init__(**kwargs)
        logger.debug("DialogueState 初始化完成")


class EntityTracker:
    """
    实体追踪器，用于跟踪会话中的实体信息。
    """

    def __init__(self, max_entities: int = 1000) -> None:
        """
        初始化实体追踪器。

        :param max_entities: 最大实体数量
        """
        self._entities: Dict[str, SessionEntity] = {}
        self._max_entities: int = max_entities
        self._lock = threading.RLock()
        logger.debug("EntityTracker 初始化, 最大实体数: %d", max_entities)

    def add(self, entity: SessionEntity) -> None:
        """
        添加一个实体。

        :param entity: 实体实例
        """
        with self._lock:
            if len(self._entities) >= self._max_entities:
                # 移除最早添加的实体
                oldest_key = next(iter(self._entities))
                del self._entities[oldest_key]
            self._entities[entity.entity_id] = entity

    def get(self, entity_id: str) -> Optional[SessionEntity]:
        """
        获取指定ID的实体。

        :param entity_id: 实体ID
        :return: 实体实例或 None
        """
        with self._lock:
            return self._entities.get(entity_id)

    def size(self) -> int:
        """
        获取实体数量。

        :return: 实体数量
        """
        with self._lock:
            return len(self._entities)

    def clear(self) -> None:
        """
        清空所有实体。
        """
        with self._lock:
            self._entities.clear()

    def get_all(self) -> List[SessionEntity]:
        """
        获取所有实体。

        :return: 所有实体
        """
        with self._lock:
            return list(self._entities.values())


class TopicManager:
    """
    主题管理器，用于管理会话中的主题。
    """

    def __init__(self, max_topics: int = 100) -> None:
        """
        初始化主题管理器。

        :param max_topics: 最大主题数量
        """
        self._topics: Dict[str, str] = {}
        self._max_topics: int = max_topics
        self._lock = threading.RLock()
        logger.debug("TopicManager 初始化, 最大主题数: %d", max_topics)

    def set_topic(self, topic_id: str, name: str) -> None:
        """
        设置主题。

        :param topic_id: 主题ID
        :param name: 主题名称
        """
        with self._lock:
            if len(self._topics) >= self._max_topics:
                # 移除最早添加的主题
                oldest_key = next(iter(self._topics))
                del self._topics[oldest_key]
            self._topics[topic_id] = name

    def get_topic(self, topic_id: str) -> Optional[str]:
        """
        获取主题名称。

        :param topic_id: 主题ID
        :return: 主题名称或 None
        """
        with self._lock:
            return self._topics.get(topic_id)

    def get_all(self) -> Dict[str, str]:
        """
        获取所有主题。

        :return: 所有主题
        """
        with self._lock:
            return dict(self._topics)

    def clear(self) -> None:
        """
        清空所有主题。
        """
        with self._lock:
            self._topics.clear()


class L0SessionMemory:
    """
    L0 会话内存，整合多个存储组件的顶层会话管理器。
    """

    def __init__(self, session_id: str = "") -> None:
        """
        初始化 L0SessionMemory。

        :param session_id: 会话ID，若为空则自动生成
        """
        self._lock = threading.RLock()
        self.session_id: str = session_id or generate_id()
        self.state: SessionState = SessionState()
        self.state.session_id = self.session_id
        self.state.status = SessionStatus.ACTIVE
        self.state.phase = SessionPhase.IDLE
        self.message_store: MessageStore = MessageStore(max_messages=1000)
        self.entity_tracker: EntityTracker = EntityTracker()
        self.topic_manager: TopicManager = TopicManager()
        self.variable_store_obj: VariableStore = VariableStore()
        self.history_store: HistoryStore = HistoryStore(max_history=500)
        self.state.message_count = 0
        self.state.token_count = 0
        logger.debug("L0SessionMemory 初始化, session_id: %s", self.session_id)

    def add_message(self, role: MessageRole, content: str, tokens: int = 0) -> None:
        """
        添加一条消息到会话。

        :param role: 消息角色
        :param content: 消息内容
        :param tokens: 消息的 token 数量
        """
        with self._lock:
            msg = SessionMessage(
                message_id=generate_id(),
                role=role,
                content=content,
                timestamp=now_timestamp(),
            )
            self.message_store.add(msg)
            self.state.message_count += 1
            self.state.token_count += tokens
            self.history_store.add(self.state)

    def add_entity(self, entity: SessionEntity) -> None:
        """
        添加一个实体到会话。

        :param entity: 实体实例
        """
        with self._lock:
            self.entity_tracker.add(entity)

    def add_topic(self, topic_id: str, name: str) -> None:
        """
        添加一个主题到会话。

        :param topic_id: 主题ID
        :param name: 主题名称
        """
        # ...[中间省略]...


def Memory(session_id: str = "") -> L0SessionMemory:
    """
    创建并注册一个新的会话。

    :param session_id: 会话ID，若为空则自动生成
    :return: 新创建的会话对象
    """
    with threading.RLock():
        sess = L0SessionMemory(session_id)
        # ...[中间省略]...


def get(session_id: str) -> Optional[L0SessionMemory]:
    """
    获取指定ID的会话。

    :param session_id: 会话ID
    :return: 会话对象或 None
    """
    with threading.RLock():
        return Memory._sessions.get(session_id)


def close(session_id: str) -> bool:
    """
    关闭并移除指定ID的会话。

    :param session_id: 会话ID
    :return: 是否成功关闭
    """
    with threading.RLock():
        s = Memory._sessions.pop(session_id, None)
        if s:
            s.close()
            logger.debug("会话已关闭并移除: %s", session_id)
        return s is not None


def get_active() -> List[L0SessionMemory]:
    """
    获取所有活跃状态的会话。

    :return: 活跃会话列表
    """
    with threading.RLock():
        return [s for s in Memory._sessions.values() if s.state.status == SessionStatus.ACTIVE]


def size() -> int:
    """
    获取会话数量。

    :return: 会话数量
    """
    with threading.RLock():
        return len(Memory._sessions)


_default_sm: Optional[SessionManager] = None
_sm_lock = threading.Lock()


def get_session_manager() -> SessionManager:
    """
    获取或创建默认的 SessionManager 实例（单例）。

    :return: SessionManager 实例
    """
    global _default_sm
    with _sm_lock:
        if _default_sm is None:
            _default_sm = SessionManager()
        return _default_sm


__all__ = [
    "MessageRole",
    "SessionPhase",
    "EntityType",
    "SessionStatus",
    "EmotionItem",
    "SessionMessage",
    "SessionEntity",
    "SessionState",
    "MessageStore",
    "EntityStore",
    "SessionStore",
    "ContextStore",
    "TopicStore",
    "VariableStore",
    "EventStore",
    "MetricStore",
    "WindowStore",
    "HistoryStore",
    "EntityTracker",
    "TopicManager",
    "ContextVariableStore",
    "SessionMetrics",
    "DialogueState",
    "L0SessionMemory",
    "get_l0_session",
    "SessionManager",
    "get_session_manager",
]
