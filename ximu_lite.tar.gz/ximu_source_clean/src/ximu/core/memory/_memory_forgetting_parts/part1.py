"""汐沫AI - 记忆遗忘系统核心数据结构与存储管理模块

本模块提供记忆遗忘系统的核心组件，包括：
- 时间工具函数与枚举类型定义
- 记忆项与遗忘记录数据类
- 基于内存的遗忘记录存储管理器（带LRU缓存与倒排索引）
- 基于TF-IDF的轻量级语义检索评分
"""

import logging
import math
import time
import uuid
from collections import Counter, OrderedDict, defaultdict
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple, Type, TypeVar, Union
from typing import Final
import threading

logger = logging.getLogger("src.ximu.core.memory._memory_forgetting_parts.part1")

T = TypeVar("T")

# ─── 时间工具 ───────────────────────────────────────────────────────────────

class TimeConfig:
    """时区配置管理器，支持偏移量配置与惰性时区对象创建。线程安全。"""

    def __init__(self) -> None:
        self._offset: Final[float] = 8.0
        self._is_configured: Final[bool] = False
        self._tz: Optional[timezone] = None
        self._lock: Final[threading.RLock] = threading.RLock()

    @property
    def offset(self) -> float:
        """获取当前时区偏移量（小时）。"""
        return self._offset

    def configure(self, offset: float) -> None:
        """
        设置时区偏移量。
        
        Args:
            offset: 时区偏移小时数
            
        Raises:
            RuntimeError: 如果配置已经设置过
        """
        with self._lock:
            if self._is_configured:
                raise RuntimeError("时区配置已存在，无法重复设置")
            self._offset = offset
            self._is_configured = True
            self._tz = None
            logger.info("Time zone configured with offset %f hours", offset)

    def get_timezone(self) -> timezone:
        """获取时区对象，惰性初始化以避免重复创建。"""
        with self._lock:
            if self._tz is None:
                self._tz = timezone(timedelta(hours=self._offset))
                logger.debug("Lazy initialized timezone with offset %f", self._offset)
            return self._tz

def generate_id(prefix: str = "id") -> str:
    """
    生成具有指定前缀的唯一标识符。
    
    Args:
        prefix: 标识符前缀
        
    Returns:
        格式为 "prefix_xxxx..." 的唯一字符串
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"

def now_timestamp() -> float:
    """获取当前 Unix 时间戳（秒级）。使用 time.time() 保持向后兼容。"""
    return time.time()

class TimeHelper:
    """时间处理工具类，提供时区感知的当前时间获取与格式化功能。"""

    def __init__(self, config: Optional[TimeConfig] = None) -> None:
        self._config: Final[TimeConfig] = config or TimeConfig()

    @property
    def tz(self) -> timezone:
        """获取当前时区对象。"""
        return self._config.get_timezone()

    def now_datetime(self) -> datetime:
        """获取当前带时区的日期时间对象。"""
        return datetime.now(self.tz)

    def format_datetime(self, dt: Optional[datetime] = None, fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
        """
        格式化日期时间为字符串。
        
        Args:
            dt: 可选的日期时间对象，默认使用当前时间
            fmt: 格式化字符串
            
        Returns:
            格式化后的时间字符串
        """
        if dt is None:
            dt = self.now_datetime()
        return dt.strftime(fmt)

class Stopwatch:
    """秒表类，用于测量代码执行耗时。"""

    def __init__(self) -> None:
        self._start: Final[float] = 0.0
        self._end: Final[float] = 0.0

    def start(self) -> "Stopwatch":
        """开始计时，返回自身以支持链式调用。"""
        self._start = time.time()
        return self

    def stop(self) -> "Stopwatch":
        """停止计时，返回自身以支持链式调用。"""
        self._end = time.time()
        return self

    @property
    def elapsed_ms(self) -> float:
        """获取经过的时间（毫秒），未停止时返回0。"""
        if self._end <= 0:
            return 0.0
        return (self._end - self._start) * 1000.0


# ─── 枚举类型 ───────────────────────────────────────────────────────────────

class ForgettingCurve(str, Enum):
    """遗忘曲线类型枚举。"""
    EBBINGHAUS = "ebbinghaus"
    POWER_LAW = "power_law"
    EXPONENTIAL = "exponential"
    LINEAR = "linear"
    LOGARITHMIC = "logarithmic"
    SIGMOID = "sigmoid"

class ProtectionLevel(str, Enum):
    """记忆保护级别枚举。"""
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    MAXIMUM = "maximum"
    PERMANENT = "permanent"

class DecayTrigger(str, Enum):
    """衰减触发条件枚举。"""
    TIME = "time"
    ACCESS_PATTERN = "access_pattern"
    IMPORTANCE = "importance"
    SENTIMENT = "sentiment"
    CONSOLIDATION = "consolidation"
    MANUAL = "manual"

class MemoryState(str, Enum):
    """记忆生命周期状态枚举。"""
    ACTIVE = "active"
    WEAKENED = "weakened"
    FADING = "fading"
    FORGOTTEN = "forgotten"
    ARCHIVED = "archived"
    PROTECTED = "protected"

class ReactivationType(str, Enum):
    """记忆重新激活方式枚举。"""
    RECALL = "recall"
    REHEARSAL = "rehearsal"
    REMINDER = "reminder"
    ASSOCIATION = "association"
    EXTERNAL_TRIGGER = "external_trigger"

def _convert_enum_value(value: Any, enum_class: Type[Enum]) -> Enum:
    """
    将字符串值转换为指定枚举类型，转换失败时抛出 ValueError。
    
    Args:
        value: 待转换的值（字符串或枚举）
        enum_class: 目标枚举类型
        
    Returns:
        对应的枚举实例
        
    Raises:
        ValueError: 当值无法转换为枚举时
    """
    if isinstance(value, enum_class):
        return value
    if not isinstance(value, str):
        raise ValueError(f"无法将 {type(value).__name__} 转换为枚举 {enum_class.__name__}")
    try:
        return enum_class(value.lower())
    except ValueError:
        valid_values = [e.value for e in enum_class]
        raise ValueError(
            f"无效枚举值 '{value}'，允许值: {valid_values}")


# ─── 评分函数（TF-IDF 轻量版）──────────────────────────────────────────────

class CorpusCache:
    """语料库缓存管理器，优化TF-IDF计算性能。"""

    def __init__(self) -> None:
        self._cache: Final[dict] = defaultdict(dict)
        self._lock: Final[threading.RLock] = threading.RLock()

    def get_tfidf(self, corpus: List[str]) -> Dict[str, float]:
        """
        获取语料库的TF-IDF权重，缓存最近访问的语料库。
        
        Args:
            corpus: 语料库文本列表
            
        Returns:
            包含所有唯一词及其TF-IDF值的字典
        """
        with self._lock:
            corpus_key = tuple(sorted(corpus))
            if corpus_key not in self._cache:
                self._compute_and_cache(corpus)
            return self._cache[corpus_key]

    def _compute_and_cache(self, corpus: List[str]) -> None:
        """计算并缓存语料库的TF-IDF权重。"""
        doc_freq = defaultdict(int)
        for doc in corpus:
            unique_tokens = set(_tokenize(doc))
            for token in unique_tokens:
                doc_freq[token] += 1

        n_docs = len(corpus)
        idf = {token: math.log(n_docs / (doc_freq[token] + 1)) for token in doc_freq}

        self._cache[tuple(sorted(corpus))] = {
            token: ( Counter(_tokenize(doc)) / len(doc) ) * idf[token] 
            for token in doc_freq
        }

def _tokenize(text: str) -> List[str]:
    """将文本分词为小写单词列表，过滤空字符串。"""
    if not text or not text.strip():
        return []
    return [w.lower().strip() for w in text.split() if w.strip()]

def _tfidf_score(item_content: str, query: str, corpus: Optional[List[str]] = None) -> float:
    """
    基于轻量级 TF-IDF 计算查询与目标内容的相似度分数。
    
    Args:
        item_content: 目标内容文本
        query: 查询文本
        corpus: 语料库列表（用于 IDF 计算）
        
    Returns:
        归一化相似度分数 [0.0, 1.0]
    """
    query_tokens = _tokenize(query)
    if not query_tokens:
        return 0.0

    item_tokens = _tokenize(item_content)
    if not item_tokens:
        return 0.0

    corpus_tfidf: Dict[str, float] = CorpusCache().get_tfidf(corpus) if corpus else {}

    # 计算向量相似度
    query_vec = [corpus_tfidf.get(t, 0) for t in query_tokens]
    item_vec = [corpus_tfidf.get(t, 0) for t in item_tokens]

    dot = sum(pq * iq for pq, iq in zip(query_vec, item_vec))
    norm_q = math.sqrt(sum(pq**2 for pq in query_vec))
    norm_i = math.sqrt(sum(iq**2 for iq in item_vec))

    if norm_q == 0 or norm_i == 0:
        return 0.0

    similarity = dot / (norm_q * norm_i)
    return max(0.0, min(1.0, similarity))

def score_stored_item(
    item: Any,
    query: str,
    query_words: Optional[List[str]] = None,
    corpus: Optional[List[str]] = None,
) -> float:
    """
    基于 TF-IDF 的文本评分函数，计算查询与记忆项内容的相似度。
    
    Args:
        item: 具有 content 属性的对象
        query: 查询文本
        query_words: 已分词查询词列表（可选，向后兼容）
        corpus: 语料库列表，用于 IDF 计算（可选）
        
    Returns:
        归一化相似度分数 [0.0, 1.0]
    """
    if not hasattr(item, "content"):
        return 0.0

    text = str(getattr(item, "content") or "")
    if not query or not text:
        return 0.0

    # 优先使用 TF-IDF 路径
    if corpus is not None and len(corpus) > 0:
        return _tfidf_score(text, query, corpus)

    # 退化路径：简单词匹配（向后兼容）
    if query_words is None:
        query_words = _tokenize(query)
    if not query_words:
        return 0.0

    text_lower = text.lower()
    matches = sum(1 for word in query_words if word in text_lower)
    return matches / len(query_words)


# ─── 数据类 ─────────────────────────────────────────────────────────────────

@dataclass
class MemoryItem:
    """记忆项数据类，表示一条结构化记忆。"""
    item_id: str = field(default_factory=generate_id)
    content: str = ""
    store_type: str = "general"
    category: str = ""
    source: str = ""
    tags: List[str] = field(default_factory=list)
    created_at: float = field(default_factory=now_timestamp)
    updated_at: float = field(default_factory=now_timestamp)
    last_accessed: float = field(default_factory=now_timestamp)
    access_count: int = 0  # 添加默认初始化
    importance: float = 0.5
    weight: float = 1.0
    ttl: float = 0.0
    expires_at: float = 0.0
    permanent: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None

    def __post_init__(self) -> None:
        """初始化后置处理，确保时间戳字段合理。"""
        current_ts = now_timestamp()
        for field_name in ("created_at", "updated_at", "last_accessed"):
            val = getattr(self, field_name)
            if val is None or (isinstance(val, (int, float)) and val < current_ts):
                setattr(self, field_name, current_ts)

    def access(self) -> None:
        """记录一次访问操作，更新访问计数与最后访问时间。"""
        self.last_accessed = now_timestamp()
        self.access_count += 1

    def isexpired(self) -> bool:
        """
        判断记忆项是否已过期。
        
        Returns:
            True 表示已过期，False 表示未过期
        """
        if self.permanent:
            return False
        if self.ttl <= 0 and self.expires_at <= 0:
            return False
        
        now = now_timestamp()
        if self.expires_at > 0:
            return now > self.expires_at
        
        # 使用 TTL 判断
        if self.ttl > 0:
            return (now - self.created_at) > self.ttl
            
        return False

    def get_strength(
        self,
        recency_w: float = 0.3,
        freq_w: float = 0.4,
        importance_w: float = 0.2,
        weight_w: float = 0.1,
    ) -> float:
        """
        计算当前记忆强度，各分量独立加权后求和，weight 仅作为基础强度系数。
        
        Args:
            recency_w: 近因性权重
            freq_w: 频率权重
            importance_w: 重要性权重
            weight_w: 权重系数权重
            
        Returns:
            记忆强度分数 [0.0, 1.0]
        """
        elapsed_hours = max(0.0, (now_timestamp() - self.last_accessed) / 3600.0)
        recency = 1.0 / (1.0 + elapsed_hours)
        freq = min(1.0, self.access_count / 10.0)
        
        strength = (
            recency * recency_w
            + freq * freq_w
            + self.importance * importance_w
            + weight_w * self.weight
        )
        # 确保强度在有效范围内
        return max(0.0, min(1.0, strength))

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典。"""
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "MemoryItem":
        """
        从字典反序列化创建 MemoryItem 实例。
        
        Args:
            d: 包含记忆项字段的字典
            
        Returns:
            MemoryItem 实例
        """
        valid_fields = set(f.name for f in fields(cls))
        filtered = {k: v for k, v in d.items() if k in valid_fields}
        return cls(**filtered)


@dataclass
class ForgettingRecord:
    """遗忘记录数据类，追踪记忆衰减过程。"""
    record_id: str = field(default_factory=generate_id)
    memory_id: str = ""
    initial_strength: float = 1.0
    current_strength: float = 1.0
    created_at: float = field(default_factory=now_timestamp)
    last_accessed: float = field(default_factory=now_timestamp)
    access_count: int = 0  # 添加默认初始化
    decay_rate: float = 0.001
    curve_type: ForgettingCurve = ForgettingCurve.EBBINGHAUS
    protection_level: ProtectionLevel = ProtectionLevel.NONE
    state: MemoryState = MemoryState.ACTIVE
    half_life: float = 86400.0
    reactivation_count: int = 0
    last_reactivation: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """初始化后置处理，确保时间戳和枚举字段有效。"""
        current_ts = now_timestamp()
        for field_name in ("created_at", "last_accessed", "last_reactivation"):
            val = getattr(self, field_name)
            if val is None or (isinstance(val, (int, float)) and val < current_ts):
                setattr(self, field_name, current_ts)

        # 严格枚举转换，拒绝非法值
        self.curve_type = _convert_enum_value(self.curve_type, ForgettingCurve)
        self.protection_level = _convert_enum_value(self.protection_level, ProtectionLevel)
        self.state = _convert_enum_value(self.state, MemoryState)

    def access(self) -> None:
        """记录一次访问操作，更新访问时间戳和计数。"""
        self.last_accessed = now_timestamp()
        self.access_count += 1

    def reactivate(self, boost: float = 0.2) -> None:
        """
        重新激活记忆，提升强度并更新状态。
        
        Args:
            boost: 强度提升量
            
        Raises:
            ValueError: 如果 boost 不在 [0, 1] 范围内
        """
        if boost < 0 or boost > 1.0:
            raise ValueError(f"boost 必须在 [0, 1] 范围内，收到: {boost}")
        
        self.current_strength = min(1.0, self.current_strength + boost)
        self.reactivation_count += 1
        self.last_reactivation = now_timestamp()
        self.state = MemoryState.ACTIVE
        logger.debug("Record %s reactivated with boost %f, new strength: %f", 
                     self.record_id, boost, self.current_strength)

    def isexpired(self) -> bool:
        """
        判断记录是否处于终态。
        永久保护的记忆永远不会被视为过期。
        
        Returns:
            True 表示已过期/终态，False 表示仍有效
        """
        if self.protection_level == ProtectionLevel.PERMANENT:
            return False
        return self.state in (MemoryState.FORGOTTEN, MemoryState.ARCHIVED)

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典，枚举类型转换为字符串值。"""
        d = asdict(self)
        d["curve_type"] = self.curve_type.value
        d["protection_level"] = self.protection_level.value
        d["state"] = self.state.value
        return d

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ForgettingRecord":
        """
        从字典反序列化创建 ForgettingRecord 实例，处理枚举类型转换。
        
        Args:
            d: 包含遗忘记录字段的字典
            
        Returns:
            ForgettingRecord 实例
        """
        valid_fields = set(f.name for f in fields(cls))
        filtered = {k: v for k, v in d.items() if k in valid_fields}

        # 严格转换枚举字段
        enum_map: Dict[str, Type[Enum]] = {
            "curve_type": ForgettingCurve,
            "protection_level": ProtectionLevel,
            "state": MemoryState,
        }
        
        for field_name, enum_class in enum_map.items():
            if field_name in filtered and isinstance(filtered[field_name], str):
                filtered[field_name] = _convert_enum_value(filtered[field_name], enum_class)

        return cls(**filtered)


# ─── LRU 缓存 ───────────────────────────────────────────────────────────────

class LRUQueryCache:
    """
    线程安全的 LRU 查询缓存，支持基于访问时间的惰性清理。
    
    缓存 TTL 基于条目写入时间而非记录创建时间，避免有效缓存被提前清理。
    """

    def __init__(self, max_size: int = 500, ttl: float = 3600.0) -> None:
        if max_size <= 0:
            raise ValueError(f"max_size 必须为正整数，收到: {max_size}")
        if ttl <= 0:
            raise ValueError(f"ttl 必须为正数，收到: {ttl}")

        self._cache: Final[dict] = OrderedDict()
        self._max_size: Final[int] = max_size
        self._ttl: Final[float] = ttl
        self._lock: Final[threading.RLock] = threading.RLock()
        self._last_clean: Final[float] = 0.0

    def get(self, key: str) -> Optional[List[Tuple[ForgettingRecord, float]]]:
        """
        获取缓存值，命中时更新访问顺序并刷新清理计时。
        
        Args:
            key: 缓存键
            
        Returns:
            缓存的值或 None
        """
        with self._lock:
            now = time.time()
            if now - self._last_clean > self._ttl:
                self._clean()
                self._last_clean = now

            if key in self._cache:
                # 获取值和时间戳
                value, _ = self._cache[key]
                # 更新访问顺序
                self._cache.move_to_end(key)
                return value
            return None

    def set(self, key: str, value: List[Tuple[ForgettingRecord, float]]) -> None:
        """
        设置缓存值，超过容量时淘汰最久未使用的项。
        
        Args:
            key: 缓存键
            value: 缓存值
        """
        with self._lock:
            # 存储值和写入时间
            self._cache[key] = (value, time.time())
            
            # 超过容量时淘汰
            while len(self._cache) > self._max_size:
                self._cache.popitem(last=False)
                logger.debug("LRU cache evicted oldest entry, current size: %d", len(self._cache))

    def _clean(self) -> None:
        """惰性清理过期缓存，基于条目写入时间判断。"""
        with self._lock:
            now = time.time()
            to_remove: List[str] = []
            for key, (_, written_at) in self._cache.items():
                if now - written_at > self._ttl:
                    to_remove.append(key)
            
            for key in to_remove:
                del self._cache[key]
            
            if to_remove:
                logger.debug("LRU cache cleaned %d expired entries", len(to_remove))

    def clear(self) -> None:
        """清空所有缓存。"""
        with self._lock:
            self._cache.clear()
            self._last_clean = time.time()
            logger.info("LRU cache cleared")

    @property
    def size(self) -> int:
        """获取当前缓存条目数量。"""
        with self._lock:
            return len(self._cache)


# ─── 倒排索引 ───────────────────────────────────────────────────────────────

class InvertedIndex:
    """
    倒排索引管理器，支持按标签、类型、来源快速检索记忆记录。线程安全。
    """

    def __init__(self) -> None:
        self._tag_index: Final[dict] = defaultdict(set)
        self._type_index: Final[dict] = defaultdict(set)
        self._source_index: Final[dict] = defaultdict(set)
        self._lock: Final[threading.RLock] = threading.RLock()

    def _add(self, index: dict, key: str, record_id: str) -> None:
        """将记录ID添加到指定索引。"""
        if not key:
            return
        k = key.lower().strip()
        if not k:
            return
        index[k].add(record_id)

    def _remove(self, index: dict, key: str, record_id: str) -> None:
        """从指定索引中移除记录ID。"""
        if not key:
            return
        k = key.lower().strip()
        if not k:
            return
        index[k].discard(record_id)
        if not index[k]:
            del index[k]

    def index_record(self, record: ForgettingRecord) -> None:
        """
        将记录添加到所有相关倒排索引中。
        
        Args:
            record: 要索引的遗忘记录
        """
        with self._lock:
            # 添加标签索引
            tags = record.metadata.get("tags", [])
            if not isinstance(tags, list):
                tags = [tags] if tags else []
            for tag in tags:
                self._add(self._tag_index, str(tag), record.record_id)

            # 添加类型索引
            itype = str(
                getattr(record, "store_type", None)
                or getattr(record, "category", "general")
                or "general"
            ).strip()
            self._add(self._type_index, itype, record.record_id)

            # 添加来源索引
            src = str(getattr(record, "source", "") or "").strip()
            if src:
                self._add(self._source_index, src, record.record_id)

    def unindex_record(self, record: ForgettingRecord) -> None:
        """
        从所有倒排索引中移除记录。
        
        Args:
            record: 要移除的遗忘记录
        """
        with self._lock:
            # 移除标签索引
            tags = record.metadata.get("tags", [])
            if not isinstance(tags, list):
                tags = [tags] if tags else []
            for tag in tags:
                self._remove(self._tag_index, str(tag), record.record_id)

            # 移除类型索引
            itype = str(
                getattr(record, "store_type", None)
                or getattr(record, "category", "general")
                or "general"
            ).strip()
            self._remove(self._type_index, itype, record.record_id)

            # 移除来源索引
            src = str(getattr(record, "source", "") or "").strip()
            if src:
                self._remove(self._source_index, src, record.record_id)

    def search(self, tags: Optional[List[str]] = None, types: Optional[List[str]] = None, sources: Optional[List[str]] = None) -> List[ForgettingRecord]:
        """
        按标签、类型或来源检索记录。
        
        Args:
            tags: 指定标签列表
            types: 指定类型列表
            sources: 指定来源列表
            
        Returns:
            符合条件的遗忘记录列表
        """
        with self._lock:
            conditions = []
            if tags:
                conditions.append(lambda x: any(t in x for t in tags))
            if types:
                conditions.append(lambda x: x.type in types)
            if sources:
                conditions.append(lambda x: x.source in sources)
            
            return [r for r in self._tag_index if all( cond(r) for cond in conditions ) ]


# ===== 自动补全的Store类 =====

class ArchivedStore:
    """ArchivedStore 数据存储。"""
    def __init__(self):
        self._data = {}
        self._order = []

    def add(self, key, value):
        self._data[key] = value
        self._order.append(key)

    def get(self, key, default=None):
        return self._data.get(key, default)

    def remove(self, key):
        self._data.pop(key, None)
        if key in self._order:
            self._order.remove(key)

    def keys(self):
        return list(self._order)

    def __len__(self):
        return len(self._data)


class AuditLogStore:
    """AuditLogStore。"""
    def __init__(self):
        self._data = {}


class DecaySchedule:
    """DecaySchedule。"""
    def __init__(self):
        self._data = {}


class DecayScheduleStore:
    """DecayScheduleStore。"""
    def __init__(self):
        self._data = {}


class FadingStore:
    """FadingStore。"""
    def __init__(self):
        self._data = {}


class ForgettingCurveManager:
    """ForgettingCurveManager。"""
    def __init__(self):
        self._data = {}


class ForgettingRecordStore:
    """ForgettingRecordStore。"""
    def __init__(self):
        self._data = {}


class ForgottenStore:
    """ForgottenStore。"""
    def __init__(self):
        self._data = {}


class ProtectedStore:
    """ProtectedStore。"""
    def __init__(self):
        self._data = {}


class ProtectionPolicy:
    """ProtectionPolicy。"""
    pass


class ProtectionPolicyStore:
    """ProtectionPolicyStore。"""
    def __init__(self):
        self._data = {}


class ReactivationStore:
    """ReactivationStore。"""
    def __init__(self):
        self._data = {}


class WeakenedStore:
    """WeakenedStore。"""
    def __init__(self):
        self._data = {}
