"""
memory_forgetting Part 2 模块
包含保护管理器、重激活管理器、衰减调度器等核心组件。
版本: 0.5
"""
import logging
import os
import json
import math
import threading
from typing import Any, Callable, Dict, List, Optional, Union, Deque
from collections import defaultdict, deque

from .part1 import (
    ArchivedStore,
    AuditLogStore,
    DecaySchedule,
    DecayScheduleStore,
    DecayTrigger,
    FadingStore,
    ForgettingCurve,
    ForgettingCurveManager,
    ForgettingRecord,
    ForgettingRecordStore,
    ForgottenStore,
    MemoryItem,
    MemoryState,
    ProtectedStore,
    ProtectionLevel,
    ProtectionPolicy,
    ProtectionPolicyStore,
    ReactivationStore,
    ReactivationType,
    WeakenedStore,
)
from src.ximu.common.utils import generate_id
from src.ximu.common.utils import now_timestamp

logger = logging.getLogger("src.ximu.core.memory._memory_forgetting_parts.part2")

__version__ = "0.5"


class _ManagerBase:
    """管理器基类，提供通用的存储注册、事件处理、指标记录和维护功能。"""

    def __init__(self, **kwargs):
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: Deque[Dict[str, Any]] = deque(maxlen=500)
        self._initialized = False
        self._last_maintenance = 0.0
        self._maintenance_interval = 300.0

    def register_store(self, name: str, store_obj: Any) -> None:
        """注册存储对象。

        Args:
            name: 存储名称
            store_obj: 存储对象实例
        """
        with self._lock:
            self._stores[name] = store_obj
            self._emit("store_registered", {"name": name})
            logger.debug(f"已注册存储: {name}")

    def get_store(self, name: str) -> Optional[Any]:
        """获取存储对象。

        Args:
            name: 存储名称

        Returns:
            存储对象或 None
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """移除存储对象。

        Args:
            name: 存储名称

        Returns:
            是否成功移除
        """
        with self._lock:
            s = self._stores.pop(name, None)
            if s:
                self._emit("store_removed", {"name": name})
                logger.debug(f"已移除存储: {name}")
            return s is not None

    def on(self, event: str, handler: Callable) -> None:
        """注册事件处理器。

        Args:
            event: 事件名称
            handler: 处理器函数
        """
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable) -> None:
        """移除事件处理器。

        Args:
            event: 事件名称
            handler: 处理器函数
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Optional[Dict[str, Any]] = None) -> None:
        """触发事件。

        Args:
            event: 事件名称
            data: 事件数据
        """
        handlers = self._event_handlers.get(event, [])
        for h in handlers:
            try:
                h(data or {})
            except Exception as e:
                logger.debug(f"事件处理器失败: {event}, 错误: {e}", exc_info=True)

    def record_metric(self, name: str, value: float) -> None:
        """记录指标。

        Args:
            name: 指标名称
            value: 指标增量值
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({"metric": name, "value": value, "timestamp": now_timestamp()})

    def get_metric(self, name: str) -> float:
        """获取指标值。

        Args:
            name: 指标名称

        Returns:
            指标累计值
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """获取所有指标。

        Returns:
            指标字典
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        """重置所有指标。"""
        with self._lock:
            self._metrics.clear()

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """获取指标历史记录。

        Args:
            limit: 最大返回条数

        Returns:
            历史记录列表
        """
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """初始化管理器。

        Returns:
            是否成功初始化（若已初始化则返回 False）
        """
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._emit("initialized", {})
            logger.debug("管理器已初始化")
            return True

    def shutdown(self) -> bool:
        """关闭管理器。

        Returns:
            是否成功关闭（若未初始化则返回 False）
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            self._emit("shutdown", {})
            logger.debug("管理器已关闭")
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """执行维护操作。

        Args:
            force: 是否强制维护

        Returns:
            维护结果字典
        """
        with self._lock:
            now = now_timestamp()
            if not force and now - self._last_maintenance < self._maintenance_interval:
                return {"status": "skipped"}

            cleaned = 0
            for name, s in self._stores.items():
                if hasattr(s, "cleanup_expired"):
                    try:
                        cleaned += s.cleanup_expired()
                    except Exception as e:
                        logger.debug(f"存储清理失败: {name}, 错误: {e}", exc_info=True)

            self._last_maintenance = now
            self._emit("maintenance", {"cleaned": cleaned})
            logger.debug(f"维护完成，清理数量: {cleaned}")
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息。

        Returns:
            统计字典
        """
        with self._lock:
            store_stats = {}
            for name, s in self._stores.items():
                if hasattr(s, "get_stats"):
                    try:
                        store_stats[name] = s.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(s, "size"):
                    store_stats[name] = {"size": s.size()}
            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history),
            }

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典。

        Returns:
            序列化字典
        """
        with self._lock:
            return {
                "config": dict(self._config),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys()),
            }

    def export_state(self, filepath: str) -> None:
        """导出状态到文件。

        Args:
            filepath: 文件路径
        """
        data = self.to_dict()
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, default=str)
            logger.debug(f"状态已导出: {filepath}")
        except IOError as e:
            logger.error(f"导出状态失败: {filepath}, 错误: {e}")

    def import_state(self, filepath: str) -> bool:
        """从文件导入状态。

        Args:
            filepath: 文件路径

        Returns:
            是否成功导入
        """
        if not os.path.exists(filepath):
            return False

        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (IOError, json.JSONDecodeError) as e:
            logger.error(f"导入状态失败: {filepath}, 错误: {e}")
            return False

        with self._lock:
            if "config" in data:
                self._config.update(data["config"])
            if "metrics" in data:
                self._metrics.update(data["metrics"])
        logger.debug(f"状态已导入: {filepath}")
        return True


class ProtectionManager(_ManagerBase):
    """保护管理器，负责内存保护策略的管理。"""

    def __init__(self, policy_store: ProtectionPolicyStore, protected_store: ProtectedStore):
        """初始化保护管理器。

        Args:
            policy_store: 保护策略存储
            protected_store: 受保护存储
        """
        super().__init__()
        self._policy_store = policy_store
        self._protected_store = protected_store
        self.register_store("policy", policy_store)
        self.register_store("protected", protected_store)

    def add_policy(self, record: ForgettingRecord) -> bool:
        """添加保护策略。

        Args:
            record: 记录对象

        Returns:
            是否添加成功
        """
        if not record or not record.memory_id:
            return False
        try:
            self._policy_store.put(record.memory_id, record)
            logger.debug(f"添加保护策略: {record.memory_id}")
            return True
        except Exception as e:
            logger.error(f"添加保护策略失败: {record.memory_id}, 错误: {e}")
            return False

    def remove_policy(self, memory_id: str) -> bool:
        """移除保护策略。

        Args:
            memory_id: 内存ID

        Returns:
            是否移除成功
        """
        if not self._policy_store.get(memory_id):
            return False
        try:
            self._policy_store.delete(memory_id)
            logger.debug(f"移除保护策略: {memory_id}")
            return True
        except Exception as e:
            logger.error(f"移除保护策略失败: {memory_id}, 错误: {e}")
            return False

    def get_policy(self, memory_id: str) -> Optional[ForgettingRecord]:
        """获取保护策略。

        Args:
            memory_id: 内存ID

        Returns:
            记录对象或 None
        """
        return self._policy_store.get(memory_id)


class ReactivationManager(_ManagerBase):
    """重激活管理器，负责内存重激活策略的管理。"""

    def __init__(self, reactivation_store: ReactivationStore):
        """初始化重激活管理器。

        Args:
            reactivation_store: 重激活存储
        """
        super().__init__()
        self._reactivation_store = reactivation_store
        self.register_store("reactivation", reactivation_store)

    def record_reactivation(self, memory_id: str, boost: float, reactivation_type: str) -> bool:
        """记录重激活事件。

        Args:
            memory_id: 内存ID
            boost: 提升值
            reactivation_type: 重激活类型

        Returns:
            是否记录成功
        """
        try:
            self._reactivation_store.record_reactivation(memory_id, boost, reactivation_type)
            self.record_metric("reactivation_count", 1.0)
            return True
        except Exception as e:
            logger.error(f"记录重激活失败: {memory_id}, 错误: {e}")
            return False


class DecayScheduler(_ManagerBase):
    """衰减调度器，负责内存衰减周期的调度。"""

    def __init__(self, schedule_store: DecayScheduleStore):
        """初始化衰减调度器。

        Args:
            schedule_store: 衰减调度存储
        """
        super().__init__()
        self._schedule_store = schedule_store
        self.register_store("schedule", schedule_store)

    def schedule_decay(self, memory_id: str, trigger: DecayTrigger) -> bool:
        """调度衰减。

        Args:
            memory_id: 内存ID
            trigger: 触发器

        Returns:
            是否调度成功
        """
        try:
            schedule = DecaySchedule(memory_id, trigger)
            self._schedule_store.put(memory_id, schedule)
            logger.debug(f"调度衰减: {memory_id}, 触发器: {trigger}")
            return True
        except Exception as e:
            logger.error(f"调度衰减失败: {memory_id}, 错误: {e}")
            return False

    def get_schedule(self, memory_id: str) -> Optional[DecaySchedule]:
        """获取调度。

        Args:
            memory_id: 内存ID

        Returns:
            调度对象或 None
        """
        return self._schedule_store.get(memory_id)


class MemoryPruningManager(_ManagerBase):
    """内存修剪管理器，负责内存剪枝操作的管理。"""

    def __init__(self, forgotten_store: ForgottenStore):
        """初始化内存修剪管理器。

        Args:
            forgotten_store: 已遗忘存储
        """
        super().__init__()
        self._forgotten_store = forgotten_store
        self.register_store("forgotten", forgotten_store)

    def prune(self) -> Dict[str, int]:
        """执行修剪操作。

        Returns:
            修剪结果统计
        """
        count = 0
        try:
            records = self._forgotten_store.get_all()
            for record in records:
                if self._forgotten_store.delete(record.memory_id):
                    count += 1
            logger.debug(f"修剪完成，移除 {count} 条记录")
            return {"pruned": count}
        except Exception as e:
            logger.error(f"修剪操作失败: {e}")
            return {"pruned": 0, "error": str(e)}


class ForgettingCurveEngine:
    """遗忘曲线引擎，计算和评估遗忘曲线。"""

    def __init__(self, curve_manager: ForgettingCurveManager):
        """初始化遗忘曲线引擎。

        Args:
            curve_manager: 遗忘曲线管理器
        """
        self._curve_manager = curve_manager

    def calculate_forgetting(self, memory_id: str, elapsed_time: float) -> float:
        """计算遗忘程度。

        Args:
            memory_id: 内存ID
            elapsed_time: 经过的时间

        Returns:
            遗忘程度值 (0.0 - 1.0)
        """
        curve = self._curve_manager.get_curve(memory_id)
        if curve is None:
            return 0.0
        return curve.calculate_forgetting(elapsed_time)

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息。

        Returns:
            统计字典
        """
        return self._curve_manager.get_stats()


class ProtectionEngine:
    """保护引擎，执行保护策略。"""

    def __init__(self, policy_store: ProtectionPolicyStore, protected_store: ProtectedStore):
        """初始化保护引擎。

        Args:
            policy_store: 保护策略存储
            protected_store: 受保护存储
        """
        self._policy_store = policy_store
        self._protected_store = protected_store
        self._lock = threading.RLock()

    def protect(self, memory_id: str, level: str = "high") -> Optional[ForgettingRecord]:
        """保护内存。

        Args:
            memory_id: 内存ID
            level: 保护级别

        Returns:
            保护后的记录，若不存在则返回 None
        """
        with self._lock:
            record = self._policy_store.get(memory_id)
            if record is None:
                logger.warning(f"尝试保护不存在的内存: {memory_id}")
                return None

            record.protection_level = level
            if level == "permanent":
                record.state = "protected"
                record.decay_rate = 0.0
                self._protected_store.put(memory_id, record)
                logger.info(f"永久保护内存: {memory_id}")
            else:
                record.state = "protected"
                self._protected_store.put(memory_id, record)
                logger.debug(f"保护内存: {memory_id}, 级别: {level}")

            return record

    def unprotect(self, memory_id: str) -> bool:
        """解除保护。

        Args:
            memory_id: 内存ID

        Returns:
            是否成功解除
        """
        with self._lock:
            record = self._policy_store.get(memory_id)
            if record is None:
                return False

            if record.protection_level == "permanent":
                logger.warning(f"无法解除永久保护的内存: {memory_id}")
                return False

            record.protection_level = "none"
            record.state = "active"
            logger.info(f"解除保护: {memory_id}")
            return True

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息。

        Returns:
            统计字典
        """
        return {
            "policies": self._policy_store.get_stats(),
            "protected": self._protected_store.get_stats(),
        }


class ReactivationEngine:
    """重激活引擎，执行内存重激活操作。"""

    def __init__(self, reactivation_store: ReactivationStore):
        """初始化重激活引擎。

        Args:
            reactivation_store: 重激活存储
        """
        self._reactivation_store = reactivation_store
        self._lock = threading.RLock()

    def reactivate(self, record: ForgettingRecord, boost: float = 0.2, reactivation_type: str = "recall") -> ForgettingRecord:
        """重激活内存记录。

        Args:
            record: 内存记录
            boost: 提升值
            reactivation_type: 重激活类型

        Returns:
            重激活后的记录
        """
        with self._lock:
            if not record:
                return None

            record.reactivation_count += 1
            record.last_reactivation_time = now_timestamp()
            record.reactivation_type = reactivation_type

            # 应用提升效果
            if record.decay_rate > 0:
                record.decay_rate = max(0.0, record.decay_rate - boost)
            record.strength = min(1.0, record.strength + boost)
            record.state = "active"

            self._reactivation_store.record_reactivation(record.memory_id, boost, reactivation_type)
            logger.debug(f"内存已重激活: {record.memory_id}, 类型: {reactivation_type}, 提升: {boost}")

            return record

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息。

        Returns:
            统计字典
        """
        return self._reactivation_store.get_stats()


class MemoryForgetting:
    """内存遗忘系统核心类，协调所有遗忘相关组件。"""

    def __init__(
        self,
        curve_manager: ForgettingCurveManager,
        record_store: ForgettingRecordStore,
        policy_store: ProtectionPolicyStore,
        protected_store: ProtectedStore,
        schedule_store: DecayScheduleStore,
        forgotten_store: ForgottenStore,
        reactivation_store: ReactivationStore,
        archived_store: ArchivedStore,
        audit_log_store: AuditLogStore,
    ):
        """初始化内存遗忘系统。

        Args:
            curve_manager: 遗忘曲线管理器
            record_store: 记录存储
            policy_store: 策略存储
            protected_store: 受保护存储
            schedule_store: 调度存储
            forgotten_store: 已遗忘存储
            reactivation_store: 重激活存储
            archived_store: 归档存储
            audit_log_store: 审计日志存储
        """
        self._curve_manager = curve_manager
        self._record_store = record_store
        self._policy_store = policy_store
        self._protected_store = protected_store
        self._schedule_store = schedule_store
        self._forgotten_store = forgotten_store
        self._reactivation_store = reactivation_store
        self._archived_store = archived_store
        self._audit_log_store = audit_log_store

        # 初始化引擎
        self._curve_engine = ForgettingCurveEngine(curve_manager)
        self._protection_engine = ProtectionEngine(policy_store, protected_store)
        self._reactivation_engine = ReactivationEngine(reactivation_store)

        # 初始化管理器
        self._protection_manager = ProtectionManager(policy_store, protected_store)
        self._reactivation_manager = ReactivationManager(reactivation_store)
        self._decay_scheduler = DecayScheduler(schedule_store)
        self._pruning_manager = MemoryPruningManager(forgotten_store)

        # 线程锁
        self._lock = threading.RLock()

    def decay_memory(self, memory_id: str, elapsed_time: float) -> Dict[str, Any]:
        """衰减内存。

        Args:
            memory_id: 内存ID
            elapsed_time: 经过的时间

        Returns:
            衰减结果字典
        """
        with self._lock:
            record = self._record_store.get(memory_id)
            if not record:
                return {"status": "not_found"}

            if record.state == "forgotten":
                return {"status": "already_forgotten"}

            # 计算遗忘
            forgetting_factor = self._curve_engine.calculate_forgetting(memory_id, elapsed_time)
            record.strength -= forgetting_factor
            record.decay_rate = forgetting_factor

            if record.strength <= 0:
                record.state = "forgotten"
                self._forgotten_store.put(memory_id, record)
                self._record_store.delete(memory_id)
                logger.info(f"内存已遗忘: {memory_id}")
                return {"status": "forgotten", "strength": 0.0}
            else:
                self._record_store.put(memory_id, record)
                return {"status": "decayed", "strength": record.strength}

    def protect_memory(self, memory_id: str, level: str = "high") -> Optional[ForgettingRecord]:
        """保护内存。

        Args:
            memory_id: 内存ID
            level: 保护级别

        Returns:
            记录对象或 None
        """
        record = self._record_store.get(memory_id)
        if not record:
            return None
        return self._protection_engine.protect(memory_id, level)

    def unprotect_memory(self, memory_id: str) -> bool:
        """解除内存保护。

        Args:
            memory_id: 内存ID

        Returns:
            是否成功
        """
        return self._protection_engine.unprotect(memory_id)

    def reactivate_memory(self, memory_id: str, boost: float = 0.2, reactivation_type: str = "recall") -> Optional[ForgettingRecord]:
        """重激活内存。

        Args:
            memory_id: 内存ID
            boost: 提升值
            reactivation_type: 重激活类型

        Returns:
            记录对象或 None
        """
        with self._lock:
            record = self._record_store.get(memory_id)
            if not record:
                return None
            return self._reactivation_engine.reactivate(record, boost, reactivation_type)

    def schedule_decay(self, memory_id: str, trigger: DecayTrigger) -> bool:
        """调度衰减。

        Args:
            memory_id: 内存ID
            trigger: 触发器

        Returns:
            是否成功
        """
        return self._decay_scheduler.schedule_decay(memory_id, trigger)

    def run_decay_cycle(self) -> Dict[str, Any]:
        """运行衰减周期。

        Returns:
            周期结果
        """
        with self._lock:
            records = self._record_store.get_all()
            decayed = 0
            forgotten = 0

            for r in records:
                if r.protection_level != "permanent":
                    self.decay_memory(r.memory_id, now_timestamp() - r.last_access_time)
                    decayed += 1
                    if r.state == "forgotten":
                        forgotten += 1

            result = {"decayed": decayed, "forgotten": forgotten, "total": len(records)}
            logger.debug(f"衰减周期完成: {result}")
            return result

    def get_stats(self) -> Dict[str, Any]:
        """获取系统统计信息。

        Returns:
            统计字典
        """
        return {
            "records": self._record_store.get_stats(),
            "schedules": self._schedule_store.get_stats(),
            "policies": self._policy_store.get_stats(),
            "archived": self._archived_store.get_stats(),
            "forgotten": self._forgotten_store.get_stats(),
            "reactivation": self._reactivation_engine.get_stats(),
            "curve": self._curve_engine.get_stats(),
        }

    def initialize(self) -> bool:
        """初始化系统。

        Returns:
            是否成功
        """
        return self._protection_manager.initialize() and self._reactivation_manager.initialize()

    def shutdown(self) -> bool:
        """关闭系统。

        Returns:
            是否成功
        """
        return self._protection_manager.shutdown() and self._reactivation_manager.shutdown()


_default_fg: Optional[MemoryForgetting] = None
_fg_lock = threading.Lock()


def get_memory_forgetting() -> MemoryForgetting:
    """获取默认的内存遗忘系统实例（单例）。

    Returns:
        MemoryForgetting 单例
    """
    global _default_fg
    with _fg_lock:
        if _default_fg is None:
            _default_fg = MemoryForgetting(
                curve_manager=ForgettingCurveManager(),
                record_store=ForgettingRecordStore(),
                policy_store=ProtectionPolicyStore(),
                protected_store=ProtectedStore(),
                schedule_store=DecayScheduleStore(),
                forgotten_store=ForgottenStore(),
                reactivation_store=ReactivationStore(),
                archived_store=ArchivedStore(),
                audit_log_store=AuditLogStore(),
            )
        return _default_fg


__all__ = [
    "ForgettingCurve",
    "ProtectionLevel",
    "DecayTrigger",
    "MemoryState",
    "ReactivationType",
    "MemoryItem",
    "ForgettingRecord",
    "DecaySchedule",
    "ProtectionPolicy",
    "ForgettingRecordStore",
    "DecayScheduleStore",
    "ProtectionPolicyStore",
    "ArchivedStore",
    "ForgottenStore",
    "ReactivationStore",
    "WeakenedStore",
    "FadingStore",
    "ProtectedStore",
    "AuditLogStore",
    "ForgettingCurveManager",
    "ProtectionManager",
    "ReactivationManager",
    "DecayScheduler",
    "MemoryPruningManager",
    "ForgettingCurveEngine",
    "ProtectionEngine",
    "ReactivationEngine",
    "MemoryForgetting",
    "get_memory_forgetting",
]
