"""Memory forgetting modular components.

This package contains split parts of the memory_forgetting module,
organized into submodules for clarity and maintainability.
"""

# 版本号
__version__ = "0.5"

# 公共API兼容性：导出核心组件（如有需要可根据实际子模块调整）
# 当前为空实现，保留模块结构以支持后续扩展
