"""
汐沫AI - L1短期记忆系统 Part 1: 核心数据结构与内存存储基类

本模块定义L1短期记忆的数据模型、枚举类型、工具类及内存存储基类。
提供基于多维索引、LRU查询缓存与强度淘汰机制的线程安全内存存储基础设施。
"""

import copy
import logging
import threading
import time
import uuid
from collections import OrderedDict, defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple, TypeVar, Union
import heapq

# 配置中心初始化
class Config:
    """记忆系统配置类，集中管理阈值和权重参数"""
    MAX_HISTORY_VERSIONS: int = 50
    MAX_CACHE_SIZE: int = 500
    MAX_ITEMS: int = 10000
    MIN_SCORE: float = 0.0
    SEARCH_LIMIT: int = 20
    WEAKNESS_THRESHOLD: float = 0.1
    BEIJING_TZ_OFFSET_HOURS: int = 8
    TIME_FORMAT: str = "%Y-%m-%d %H:%M:%S"

    # 动态加载评分配置
    @property
    def score_config(self) -> Dict[str, Any]:
        """外部依赖评分配置"""
        return {}

# ========================
# 工具函数
# ========================

def generate_id(prefix: str = "id") -> str:
    """生成带有前缀的唯一标识符"""
    return f"{prefix}_{uuid.uuid4().hex[:16]}"

def now_timestamp() -> float:
    """获取当前Unix时间戳"""
    return time.time()

def now_datetime() -> datetime:
    """获取当前北京时间(UTC+8)"""
    tz_bj = timezone(timedelta(hours=Config.BEIJING_TZ_OFFSET_HOURS))
    return datetime.now(tz_bj)

def format_datetime(dt: Optional[datetime] = None, fmt: Optional[str] = None) -> str:
    """格式化日期时间"""
    if dt is None:
        dt = now_datetime()
    if fmt is None:
        fmt = Config.TIME_FORMAT
    return dt.strftime(fmt)

class Stopwatch:
    """性能监控秒表，支持链式调用"""
    def __init__(self) -> None:
        self._start_time: float = 0.0
        self._end_time: float = 0.0

    def start(self) -> "Stopwatch":
        self._start_time = time.time()
        return self

    def stop(self) -> "Stopwatch":
        self._end_time = time.time()
        return self

    @property
    def elapsed_ms(self) -> float:
        return (self._end_time - self._start_time) * 1000.0 if self._end_time else 0.0

# ========================
# 枚举定义
# ========================

class ShortTermType(str, Enum):
    """短期记忆类型枚举"""
    CONVERSATION = "conversation"
    WORKING = "working"
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"
    EMOTIONAL = "emotional"
    TEMPORARY = "temporary"
    CONTEXT = "context"
    INTENT = "intent"
    ENTITY = "entity"

class MemoryPriority(str, Enum):
    """记忆优先级枚举"""
    LOWEST = "lowest"
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"
    PERMANENT = "permanent"

class ConsolidationStatus(str, Enum):
    """记忆固化状态枚举"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"

class RehearsalPhase(str, Enum):
    """复习阶段枚举"""
    ENCODING = "encoding"
    STORAGE = "storage"
    RETRIEVAL = "retrieval"
    CONSOLIDATION = "consolidation"
    FORGETTING = "forgetting"

class TransferDirection(str, Enum):
    """记忆转移方向枚举"""
    L0_TO_L1 = "l0_to_l1"
    L1_TO_L2 = "l1_to_l2"
    L2_TO_L1 = "l2_to_l1"
    L1_TO_L0 = "l1_to_l0"
    CROSS_SESSION = "cross_session"

# ========================
# 数据模型
# ========================

@dataclass
class MemoryItem:
    """
    核心记忆项，包含内容、元数据、权重与TTL

    该数据结构封装了L1短期记忆中最小的原子单元，
    支持基于时间的过期检查、访问计数及基于遗忘曲线的强度计算。
    """
    item_id: str = field(default_factory=generate_id)
    content: str = ""
    store_type: str = "general"
    category: str = ""
    source: str = ""
    tags: List[str] = field(default_factory=list)
    created_at: float = 0.0
    updated_at: float = 0.0
    last_accessed: float = 0.0
    access_count: int = 0
    importance: float = 0.5
    weight: float = 1.0
    ttl: float = 0.0
    expires_at: float = 0.0
    permanent: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None

    def __post_init__(self) -> None:
        """初始化后处理：填充默认时间戳"""
        now = now_timestamp()
        if self.created_at == 0.0:
            self.created_at = now
        if self.updated_at == 0.0:
            self.updated_at = now
        if self.last_accessed == 0.0:
            self.last_accessed = now
        if not self.item_id:
            self.item_id = generate_id("mem")

    def access(self) -> None:
        """标记访问并更新计数和时间戳"""
        self.last_accessed = now_timestamp()
        self.access_count += 1

    def is_expired(self) -> bool:
        """检查是否过期"""
        if self.permanent or self.ttl <= 0:
            return False
        now = now_timestamp()
        return now > self.expires_at

    def get_strength(self, base: float = 0.3) -> float:
        """基于简化遗忘曲线计算记忆强度"""
        now = now_timestamp()
        age_hours = max(0.0, (now - self.last_accessed) / 3600.0)
        recency = 1.0 / (1.0 + age_hours)
        freq = min(1.0, self.access_count / 10.0)
        return base + (recency * Config.score_config.get("recency_weight", 0.4)) + (freq * Config.score_config.get("freq_weight", 0.2))

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

# ========================
# 内存存储基类
# ========================

class BaseMemoryStore:
    """
    通用记忆存储基类，封装索引、缓存与淘汰逻辑

    特性:
        - 线程安全（RLock）
        - 多级索引（标签、类型、来源、内容词）
        - 查询缓存（LRU）
        - 强度淘汰机制（基于堆优化）
        - 统计指标监控
    """
    def __init__(self, max_items: int = Config.MAX_ITEMS, max_cache: int = Config.MAX_CACHE_SIZE) -> None:
        self._items: Dict[str, MemoryItem] = {}
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._type_index: Dict[str, Set[str]] = defaultdict(set)
        self._source_index: Dict[str, Set[str]] = defaultdict(set)
        self._content_words: Dict[str, Set[str]] = {}
        self._strength_heap = []
        self._time_heap = []
        self._max = max_items
        self._max_cache = max_cache
        self._lock = threading.RLock()
        self._stats = {"added":0, "reads":0, "deleted":0, "updated":0, "searches":0, "cache_hits":0, "cache_misses":0}
        self._query_cache = OrderedDict()
        logger.debug("BaseMemoryStore initialized: max_items=%d, max_cache=%d", max_items, max_cache)

    @property
    def size(self) -> int:
        with self._lock:
            return len(self._items)

    @property
    def stats(self) -> Dict[str, int]:
        with self._lock:
            return self._stats.copy()

    def _get_content_words(self, item: MemoryItem) -> Set[str]:
        return set(item.content.lower().split()) if item.content else set()

    def _add_to_indices(self, iid: str, item: MemoryItem) -> None:
        self._content_words[iid] = self._get_content_words(item)
        for tag in item.tags:
            self._tag_index[tag.lower()].add(iid)
        self._type_index[item.store_type].add(iid)
        self._source_index[item.source].add(iid)
        heapq.heappush(self._strength_heap, (self.get_strength(item), iid))
        heapq.heappush(self._time_heap, (item.created_at, iid))

    def _evict_weakest(self) -> None:
        if not self._items:
            return
        try:
            strength, iid = heapq.heappop(self._strength_heap)
            if iid not in self._items or self._items[iid].permanent:
                self._evict_weakest()
                return
            self._items.pop(iid)
            self._remove_from_indices(iid)
            self._stats["deleted"] += 1
            self._invalidate_cache()
        except IndexError:
            logger.warning("Eviction failed: heap underflow")

    def _remove_from_indices(self, iid: str, item: MemoryItem) -> None:
        self._content_words.pop(iid, None)
        for tag in item.tags:
            self._tag_index[tag.lower()].discard(iid)
        self._type_index[item.store_type].discard(iid)
        self._source_index[item.source].discard(iid)

    def _invalidate_cache(self) -> None:
        self._query_cache.clear()

    def _cache_put(self, key: str, value: List[Tuple[MemoryItem, float]]) -> None:
        if key in self._query_cache:
            self._query_cache.move_to_end(key)
        self._query_cache[key] = value
        if len(self._query_cache) > self._max_cache:
            self._query_cache.popitem(last=False)

    def _cache_get(self, key: str) -> Optional[List[Tuple[MemoryItem, float]]]:
        if key in self._query_cache:
            self._query_cache.move_to_end(key)
            return self._query_cache[key]
        return None

    def add(self, item: MemoryItem) -> MemoryItem:
        with self._lock:
            if len(self._items) >= self._max:
                self._evict_weakest()
            iid = item.item_id
            self._items[iid] = item
            self._add_to_indices(iid, item)
            self._stats["added"] += 1
            self._invalidate_cache()
            return item

    def get(self, iid: str) -> Optional[MemoryItem]:
        with self._lock:
            return self._items.get(iid)


# ===== 自动补全的Store类 =====

class ContextBufferStore:
    """ContextBufferStore 数据存储。"""
    def __init__(self):
        self._data = {}
        self._order = []

    def add(self, key, value):
        self._data[key] = value
        self._order.append(key)

    def get(self, key, default=None):
        return self._data.get(key, default)

    def remove(self, key):
        self._data.pop(key, None)
        if key in self._order:
            self._order.remove(key)

    def keys(self):
        return list(self._order)

    def __len__(self):
        return len(self._data)

class ConversationStore:
    """ConversationStore 数据存储。"""
    def __init__(self):
        self._data = {}
        self._order = []

    def add(self, key, value):
        self._data[key] = value
        self._order.append(key)

    def get(self, key, default=None):
        return self._data.get(key, default)

    def remove(self, key):
        self._data.pop(key, None)
        if key in self._order:
            self._order.remove(key)

    def keys(self):
        return list(self._order)

    def __len__(self):
        return len(self._data)


class EmotionalMemoryStore:
    """EmotionalMemoryStore。"""
    def __init__(self):
        self._data = {}


class EntityMemoryStore:
    """EntityMemoryStore。"""
    def __init__(self):
        self._data = {}


class EpisodicMemory:
    """EpisodicMemory。"""
    pass


class EpisodicStore:
    """EpisodicStore。"""
    def __init__(self):
        self._data = {}


class IntentMemoryStore:
    """IntentMemoryStore。"""
    def __init__(self):
        self._data = {}


class ProceduralMemoryStore:
    """ProceduralMemoryStore。"""
    def __init__(self):
        self._data = {}


class RecentContextStore:
    """RecentContextStore。"""
    def __init__(self):
        self._data = {}


class TemporaryBufferStore:
    """TemporaryBufferStore。"""
    def __init__(self):
        self._data = {}


class WorkingMemoryManager:
    """WorkingMemoryManager。"""
    def __init__(self):
        self._data = {}


class WorkingSlot:
    """WorkingSlot。"""
    pass
