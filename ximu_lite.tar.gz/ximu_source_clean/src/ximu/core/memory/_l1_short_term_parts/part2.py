import logging
from typing import Any, Callable, Dict, List
from collections import defaultdict, deque
from threading import RLock
from datetime import datetime
import json
import os
from .part1 import (
    ConsolidationStatus, ContextBufferStore, ConversationStore,
    EmotionalMemoryStore, EntityMemoryStore, EpisodicMemory,
    EpisodicStore, IntentMemoryStore, MemoryItem, MemoryPriority,
    ProceduralMemoryStore, RecentContextStore, RehearsalPhase,
    ShortTermType, TemporaryBufferStore, TransferDirection,
    WorkingMemoryManager, WorkingSlot
)
from src.ximu.common.utils import generate_id, now_timestamp

logger = logging.getLogger("src.ximu.core.memory._l1_short_term_parts.part2")

class BaseManager:
    def __init__(self, **kwargs):
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = RLock()
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=500)
        self._initialized = False
        self._last_maintenance = 0.0
        self._maintenance_interval = 300.0

    def register_store(self, name: str, store_obj: Any) -> None:
        with self._lock:
            self._stores[name] = store_obj
            self._emit("store_registered", {"name": name})

    def get_store(self, name: str) -> Any:
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        with self._lock:
            s = self._stores.pop(name, None)
            if s:
                self._emit("store_removed", {"name": name})
            return s is not None

    def on(self, event: str, handler: Callable) -> None:
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable) -> None:
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Dict[str, Any] = None) -> None:
        handlers = self._event_handlers.get(event, [])
        for h in handlers:
            try:
                h(data or {})
            except Exception as e:
                logger.debug("Operation failed: %s", e, exc_info=True)

    def record_metric(self, name: str, value: float) -> None:
        with self._lock:
            self._metrics[name] += value
            self._history.append({"metric": name, "value": value, "timestamp": now_timestamp()})

    def get_metric(self, name: str) -> float:
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        with self._lock:
            self._metrics.clear()

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._emit("initialized", {})
            return True

    def shutdown(self) -> bool:
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            self._emit("shutdown", {})
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        with self._lock:
            now = now_timestamp()
            if not force and now - self._last_maintenance < self._maintenance_interval:
                return {"status": "skipped"}
            cleaned = 0
            for name, s in self._stores.items():
                if hasattr(s, "cleanup_expired"):
                    try:
                        cleaned += s.cleanup_expired()
                    except Exception as e:
                        logger.debug("Operation failed: %s", e, exc_info=True)
            self._last_maintenance = now
            self._emit("maintenance", {"cleaned": cleaned})
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            store_stats = {}
            for name, s in self._stores.items():
                if hasattr(s, "get_stats"):
                    try:
                        store_stats[name] = s.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(s, "size"):
                    store_stats[name] = {"size": s.size()}
            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history)
            }

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "config": dict(self._config),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys())
            }

    def export_state(self, filepath: str) -> None:
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, default=str)

    def import_state(self, filepath: str) -> bool:
        if not os.path.exists(filepath):
            return False
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        with self._lock:
            if "config" in data:
                self._config.update(data["config"])
            if "metrics" in data:
                self._metrics.update(data["metrics"])
        return True

class RehearsalManager(BaseManager):
    pass

class ConsolidationManager(BaseManager):
    pass

class CrossSessionManager(BaseManager):
    pass

class L1ShortTermMemory(WorkingMemoryManager):
    def __init__(self):
        super().__init__()
        self._working_slots: Dict[str, WorkingSlot] = {}

    def set_working(self, key: str, value: Any, **kwargs) -> WorkingSlot:
        with self._lock:
            self._working_slots[key] = WorkingSlot(
                slot_id=generate_id("wms"), key=key, value=value, **kwargs
            )
            return self._working_slots[key]

    def get_working(self, key: str, default: Any = None) -> Any:
        with self._lock:
            s = self._working_slots.get(key)
            return s.read() if s else default

    def delete_working(self, key: str) -> bool:
        with self._lock:
            return self._working_slots.pop(key, None) is not None

    def cleanup(self) -> Dict[str, int]:
        return {
            "conv": self.conversation_store.cleanup_expired(),
            "temp": self.temp_buffer.cleanup_expired(),
            "context": self.context_buffer.cleanup_expired()
        }

    def get_stats(self) -> Dict[str, Any]:
        return {
            "conversation": self.conversation_store.get_stats(),
            "episodic": self.episodic_store.get_stats(),
            "semantic": self.semantic_cache.get_stats(),
            "emotional": self.emotional_store.get_stats(),
            "procedural": self.procedural_store.get_stats(),
            "context": self.context_buffer.get_stats(),
            "intent": self.intent_store.get_stats(),
            "entity": self.entity_store.get_stats(),
            "temp": self.temp_buffer.get_stats(),
            "recent": self.recent_context.get_stats(),
            "working_slots": len(self._working_slots)
        }

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "conversation": self.conversation_store.to_dict(),
                "stats": self.get_stats()
            }

_default_l1 = None
_l1_lock = RLock()

def get_l1_memory() -> L1ShortTermMemory:
    global _default_l1
    with _l1_lock:
        if _default_l1 is None:
            _default_l1 = L1ShortTermMemory()
        return _default_l1

__all__ = [
    "ShortTermType", "MemoryPriority", "ConsolidationStatus", "RehearsalPhase",
    "TransferDirection", "MemoryItem", "WorkingSlot", "EpisodicMemory",
    "ConversationStore", "EpisodicStore", "SemanticCacheStore",
    "EmotionalMemoryStore", "ProceduralMemoryStore", "ContextBufferStore",
    "IntentMemoryStore", "EntityMemoryStore", "TemporaryBufferStore",
    "RecentContextStore", "WorkingMemoryManager", "RehearsalManager",
    "ConsolidationManager", "CrossSessionManager", "TransferManager",
    "L1ShortTermMemory", "get_l1_memory"
]
