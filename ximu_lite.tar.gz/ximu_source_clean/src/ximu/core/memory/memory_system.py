"""三级记忆系统 - 瞬时缓存记忆 + 中期行为记忆 + 长期核心记忆。"""
import logging
import json
import os
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger("src.ximu.core.memory.memory_system")


class MemoryLevel:
    """记忆层级定义。"""
    EPHEMERAL = "ephemeral"
    MIDDLE = "middle"
    LONG_TERM = "long_term"


@dataclass
class MemoryEntry:
    """记忆条目数据类。"""
    entry_id: str
    memory_level: str
    content: Any
    timestamp: float
    weight: float = 1.0
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式用于序列化。"""
        return {
            "entry_id": self.entry_id,
            "memory_level": self.memory_level,
            "content": self.content,
            "content_type": type(self.content).__name__,
            "timestamp": self.timestamp,
            "weight": self.weight,
            "tags": self.tags,
            "metadata": self.metadata,
        }


class EphemeralMemory:
    """瞬时缓存记忆，默认10秒 TTL，无关联调用自动清除。"""

    def __init__(self, ttl_seconds: float = 10.0) -> None:
        self._store: Dict[str, MemoryEntry] = {}
        self._ttl = ttl_seconds
        self._lock = threading.Lock()

    def store(self, key: str, content: Any, tags: Optional[List[str]] = None) -> None:
        """存储临时记忆。"""
        with self._lock:
            entry = MemoryEntry(
                entry_id=key,
                memory_level=MemoryLevel.EPHEMERAL,
                content=content,
                timestamp=time.time(),
                tags=tags or [],
            )
            self._store[key] = entry
            logger.debug(f"瞬时记忆存储: {key}")

    def retrieve(self, key: str) -> Optional[Any]:
        """检索临时记忆，过期返回 None。"""
        with self._lock:
            entry = self._store.get(key)
            if entry and self._is_valid(entry):
                return entry.content
            return None

    def _is_valid(self, entry: MemoryEntry) -> bool:
        """检查记忆是否过期。"""
        return time.time() - entry.timestamp < self._ttl

    def cleanup(self) -> int:
        """清理过期记忆，返回清理数量。"""
        with self._lock:
            now = time.time()
            to_remove = [k for k, v in self._store.items() if now - v.timestamp > self._ttl]
            for k in to_remove:
                del self._store[k]
            return len(to_remove)

    def get_all(self) -> Dict[str, Any]:
        """获取所有有效记忆。"""
        with self._lock:
            return {k: v.content for k, v in self._store.items() if self._is_valid(v)}


class MiddleMemory:
    """中期行为记忆，支持持久化和渐进式权重衰减。"""

    def __init__(self, storage_path: Optional[str] = None) -> None:
        self._store_data: Dict[str, MemoryEntry] = {}
        self._storage_path = storage_path or str(Path.home() / '.ximu' / 'middle_memory.json')
        self._half_life_days = 7.0
        self._forget_days = 30.0
        self._lock = threading.Lock()
        self._loaded = False

    @property
    def _store(self) -> Dict[str, MemoryEntry]:
        """懒加载属性，首次访问时读盘。"""
        self._load()
        return self._store_data

    @_store.setter
    def _store(self, value: Dict[str, MemoryEntry]) -> None:
        """设置存储数据。"""
        self._store_data = value

    def store(self, key: str, content: Any, tags: Optional[List[str]] = None,
              weight: float = 1.0) -> None:
        """存储中期记忆并持久化。"""
        with self._lock:
            self._load()
            entry = MemoryEntry(
                entry_id=key,
                memory_level=MemoryLevel.MIDDLE,
                content=content,
                timestamp=time.time(),
                weight=weight,
                tags=tags or [],
            )
            self._store[key] = entry
            self._save()
            logger.debug(f"中期记忆存储: {key}, 权重: {weight}")

    def retrieve(self, key: str) -> Optional[Any]:
        """检索中期记忆，更新访问时间和权重。"""
        with self._lock:
            self._load()
            entry = self._store.get(key)
            if entry and not self._is_expired(entry):
                entry.timestamp = time.time()
                self._save()
                return entry.content
            return None

    def search(self, keywords: List[str], limit: int = 5) -> List[Dict]:
        """搜索记忆，按关键词匹配并返回前 N 条。"""
        with self._lock:
            self._load()
            results: List[Dict] = []
            for entry in self._store.values():
                if self._is_expired(entry):
                    continue
                _c = entry.content
                parts = [json.dumps(_c, ensure_ascii=False) if isinstance(_c, (dict, list)) else str(_c)]
                if entry.tags:
                    parts.append(" ".join(str(t) for t in entry.tags))
                content_str = " ".join(parts)
                if any(kw and kw in content_str for kw in keywords):
                    results.append(entry.to_dict())
            results.sort(key=lambda x: x.get('weight', 0), reverse=True)
            return results[:limit]

    def _is_expired(self, entry: MemoryEntry) -> bool:
        """检查记忆是否过期或权重过低。"""
        age_days = (time.time() - entry.timestamp) / 86400
        if age_days > self._forget_days:
            return True
        if age_days > self._half_life_days:
            entry.weight *= 0.5
        return entry.weight < 0.01

    def _load(self) -> None:
        """幂等懒加载持久化数据。"""
        if self._loaded:
            return
        self._loaded = True
        try:
            if os.path.exists(self._storage_path):
                with open(self._storage_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for item in data:
                        entry = MemoryEntry(
                            entry_id=item['entry_id'],
                            memory_level=item['memory_level'],
                            content=item.get('content'),
                            timestamp=item['timestamp'],
                            weight=item.get('weight', 1.0),
                            tags=item.get('tags', []),
                        )
                        self._store[entry.entry_id] = entry
                logger.info(f"中期记忆加载完成: {len(self._store)}条")
        except Exception as e:
            logger.error(f"加载中期记忆失败: {e}")

    def _save(self) -> None:
        """原子保存持久化数据。"""
        try:
            os.makedirs(os.path.dirname(self._storage_path), exist_ok=True)
            tmp_path = self._storage_path + ".tmp"
            data = [entry.to_dict() for entry in self._store.values()]
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, self._storage_path)
        except Exception as e:
            logger.error(f"保存中期记忆失败: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """获取记忆统计信息。"""
        with self._lock:
            self._load()
            valid_count = sum(1 for e in self._store.values() if not self._is_expired(e))
            return {
                "total": len(self._store),
                "valid": valid_count,
                "expired": len(self._store) - valid_count,
                "path": self._storage_path,
            }


class LongTermMemory:
    """长期核心记忆，支持语义检索和元数据管理。"""

    def __init__(self, storage_path: Optional[str] = None) -> None:
        self._store_data: Dict[str, MemoryEntry] = {}
        self._storage_path = storage_path or str(Path.home() / '.ximu' / 'long_term_memory.json')
        self._lock = threading.Lock()
        self._loaded = False

    @property
    def _store(self) -> Dict[str, MemoryEntry]:
        """懒加载属性。"""
        self._load()
        return self._store_data

    def _load(self) -> None:
        """幂等懒加载持久化数据。"""
        if self._loaded:
            return
        self._loaded = True
        try:
            if os.path.exists(self._storage_path):
                with open(self._storage_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for item in data:
                        entry = MemoryEntry(
                            entry_id=item['entry_id'],
                            memory_level=MemoryLevel.LONG_TERM,
                            content=item.get('content'),
                            timestamp=item['timestamp'],
                            weight=item.get('weight', 1.0),
                            tags=item.get('tags', []),
                        )
                        self._store[entry.entry_id] = entry
                logger.info(f"长期记忆加载完成: {len(self._store)}条")
        except Exception as e:
            logger.error(f"加载长期记忆失败: {e}")

    def _save(self) -> None:
        """原子保存持久化数据。"""
        try:
            os.makedirs(os.path.dirname(self._storage_path), exist_ok=True)
            tmp_path = self._storage_path + ".tmp"
            data = [entry.to_dict() for entry in self._store.values()]
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, self._storage_path)
        except Exception as e:
            logger.error(f"保存长期记忆失败: {e}")

    def store(self, key: str, content: Any, weight: float = 1.0,
              tags: Optional[List[str]] = None) -> None:
        """存储长期记忆。"""
        with self._lock:
            self._load()
            entry = MemoryEntry(
                entry_id=key,
                memory_level=MemoryLevel.LONG_TERM,
                content=content,
                timestamp=time.time(),
                weight=weight,
                tags=tags or [],
            )
            self._store[key] = entry
            self._save()

    def retrieve(self, key: str) -> Optional[Any]:
        """检索长期记忆。"""
        with self._lock:
            self._load()
            entry = self._store.get(key)
            if entry:
                return entry.content
            return None

    def search(self, keywords: List[str], limit: int = 10) -> List[Dict]:
        """按关键词搜索长期记忆。"""
        with self._lock:
            self._load()
            results: List[Dict] = []
            for entry in self._store.values():
                content_str = json.dumps(entry.content, ensure_ascii=False) if isinstance(entry.content, (dict, list)) else str(entry.content)
                if any(kw and kw in content_str for kw in keywords):
                    results.append(entry.to_dict())
            results.sort(key=lambda x: x.get('weight', 0), reverse=True)
            return results[:limit]
