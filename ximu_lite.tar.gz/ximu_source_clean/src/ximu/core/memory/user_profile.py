# -*- coding: utf-8 -*-
"""L3 用户画像（全局公共画像，跨话题 / 跨人格共享）。"""
from __future__ import annotations

import os
import re
import json
import time
import threading
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)
MAX_ENTRIES = 100
_MAX_VALUE = 40
_MAX_EVIDENCE = 80
_lock = threading.RLock()
_FIELDS = ("职业", "技术栈", "长期目标", "技术倾向", "表达习惯", "喜好", "禁忌")
_MERGE_MODE = {
    "职业": "overwrite",
    "长期目标": "overwrite",
    "表达习惯": "overwrite",
    "技术栈": "merge_set",
    "技术倾向": "overwrite",
    "喜好": "append",
    "禁忌": "append",
}

_RE_JOB = re.compile(r"(?:我|用户)(?:是|的职业是|的工作是)(?:一名|一位)?(.{1,20}?)(工程师|开发工程师|开发者|开发|设计师|产品经理|项目经理|架构师|学生|教师|医生|研究员|分析师|运营|测试|自由职业者)")
_RE_STACK = re.compile(r"(?:我(?:主要)?用|主要用|我的技术栈(?:是|包括)|技术栈是)(.{1,50}?)(?:[。，,.；;！!？?]|$)")
_RE_GOAL = re.compile(r"(?:我的目标(?:是|想|要)?|我想做|我计划(?:做|搞|实现)?|我想要做)(.{1,40}?)(?:[。，,.；;！!？?]|$)")
_RE_TECH_PREF = re.compile(r"(?:我|用户)(?:偏好|倾向|喜欢用|习惯用|爱用)(.{1,30}?)(?:[。，,.；;！!？?]|$)")
_RE_HATE = re.compile(r"(?:我|用户)(?:讨厌|不喜欢|反感|不想)(.{1,30}?)(?:[。，,.；;！!？?]|$)")
_RE_LIKE = re.compile(r"(?:我|用户)喜欢(?!用)(.{1,30}?)(?:[。，,.；;！!？?]|$)")
_RE_STYLE_SHORT = re.compile(r"(简洁一点|简短一点|简短一些|简洁一些|别啰嗦|不要(?:太)?啰嗦|短一点|详细一点|详细一些|正式一点|口语一点|不要太长|别太长|别太详细|不要太详细)")
_STYLE_WORDS = ("简洁", "简短", "详细", "正式", "口语", "啰嗦", "太长", "太长了", "复杂", "展开")
_STYLE_CONTEXT = ("回复", "回答", "风格", "聊天", "语气")


def _profile_path() -> str:
    """获取画像文件路径。"""
    try:
        from src.ximu.core.data_root import memory_layers_dir
        d = memory_layers_dir()
    except Exception:
        d = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "..", "..", "..", "data", "用户数据", "聊天与记忆", "各层记忆")
        d = os.path.abspath(d)
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        pass
    return os.path.join(d, "user_profile.json")


def _clean(text: str) -> str:
    """归一化片段：去首尾标点空白，截断长度。"""
    if not text:
        return ""
    t = str(text).strip().strip("，。！!？?；;、,. \n\t的了啊吧呢是有")
    return t[:_MAX_VALUE]


def _norm_style(text: str) -> str:
    """表达习惯归一化：把啰嗦说法收敛成标准标签。"""
    t = _clean(text)
    if any(k in t for k in ("简洁", "简短", "简短点", "简洁点", "别啰嗦", "不要啰嗦", "短一点", "简短一些")):
        return "简洁"
    if any(k in t for k in ("详细", "详细点", "详细一些", "多写点", "展开", "具体点")):
        return "详细"
    if any(k in t for k in ("正式", "书面", "严谨")):
        return "正式"
    if any(k in t for k in ("口语", "轻松", "随便点", "随意")):
        return "口语"
    return t


def _looks_like_style(clause: str) -> bool:
    """判断片段是否在描述回复风格。"""
    if not clause:
        return False
    has_word = any(w in clause for w in _STYLE_WORDS)
    has_ctx = any(c in clause for c in _STYLE_CONTEXT)
    return has_word and (has_ctx or any(k in clause for k in ("偏好", "喜欢", "不要", "别", "要", "一点", "一些")))


def _rule_extract(user_text: str) -> List[Dict[str, Any]]:
    """规则抽取：从用户消息抽出候选画像条目。"""
    if not user_text or not user_text.strip():
        return []
    text = user_text.strip()
    hits: List[Dict[str, Any]] = []

    def add(field: str, raw: str, conf: float, evidence: str, norm: Optional[str] = None) -> None:
        val = norm(raw) if norm else _clean(raw)
        if not val:
            return
        hits.append({
            "field": field,
            "value": val,
            "confidence": float(min(1.0, conf)),
            "evidence": (evidence or raw)[:_MAX_EVIDENCE],
        })

    style_hit = False
    m = _RE_STYLE_SHORT.search(text)
    if m:
        add("表达习惯", m.group(1), 0.85, text, norm=_norm_style)
        style_hit = True
    else:
        m = re.search(r"(?:回复(?:风格)?(?:要|是|要(?:不)?太)?|回答(?:要|风格)?)|(.{0,12}?)(?:[。，,.；;！!？?]|$)", text)
        if m and _looks_like_style(m.group(1) or ""):
            add("表达习惯", m.group(1) or "", 0.8, text, norm=_norm_style)
            style_hit = True

    m = _RE_JOB.search(text)
    if m:
        add("职业", m.group(1) + (m.group(2) or ""), 0.9, text)

    m = _RE_STACK.search(text)
    if m:
        add("技术栈", m.group(1), 0.85, text)

    m = _RE_GOAL.search(text)
    if m:
        add("长期目标", m.group(1), 0.85, text)

    if not style_hit:
        m = _RE_TECH_PREF.search(text)
        if m and not _looks_like_style(m.group(1) or ""):
            add("技术倾向", m.group(1), 0.8, text)
        m = _RE_HATE.search(text)
        if m and not _looks_like_style(m.group(1) or ""):
            add("禁忌", m.group(1), 0.8, text)
        m = _RE_LIKE.search(text)
        if m and not _looks_like_style(m.group(1) or ""):
            add("喜好", m.group(1), 0.75, text)

    return hits


def _split_stack_values(raw: str) -> List[str]:
    """技术栈串拆分。"""
    parts = re.split(r"和|与|以及|、|,|，|；|;", raw)
    return [_clean(p) for p in parts if _clean(p)]


class UserProfileStore:
    """L3 用户画像存储（线程安全，原子落盘）。"""

    def __init__(self, path: Optional[str] = None) -> None:
        self._path = path or _profile_path()
        self._entries: List[Dict[str, Any]] = []
        self._loaded = False

    def _load(self) -> None:
        """懒加载画像数据。"""
        if self._loaded:
            return
        self._loaded = True
        try:
            if os.path.exists(self._path):
                with open(self._path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    self._entries = [e for e in data if isinstance(e, dict) and e.get("field")]
        except Exception as e:
            logger.debug("[L3 profile] 读取失败，按空画像处理: %s", e)
            self._entries = []

    def save(self) -> None:
        """原子保存画像数据。"""
        try:
            os.makedirs(os.path.dirname(self._path), exist_ok=True)
            tmp_path = self._path + ".tmp"
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(self._entries, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, self._path)
        except Exception as e:
            logger.error(f"[L3 profile] 保存失败: {e}")

    def get_entries(self) -> List[Dict[str, Any]]:
        """获取所有画像条目。"""
        with _lock:
            self._load()
            return list(self._entries)

    def get_field(self, field: str) -> Optional[str]:
        """获取指定字段的当前值。"""
        with _lock:
            self._load()
            entries = [e for e in self._entries if e.get("field") == field]
            if entries:
                return entries[-1].get("value")
            return None

    def update_from_message(self, user_text: str, topic_id: str = "") -> int:
        """从用户消息增量更新画像，返回新增条目数。"""
        with _lock:
            self._load()
            new_count = 0
            now = time.time()
            for hit in _rule_extract(user_text):
                field = hit["field"]
                value = hit["value"]
                mode = _MERGE_MODE.get(field, "overwrite")
                existing = [e for e in self._entries if e.get("field") == field]
                if mode == "overwrite" or not existing:
                    if existing:
                        self._entries.remove(existing[-1])
                    self._entries.append({
                        "field": field,
                        "value": value,
                        "confidence": hit["confidence"],
                        "source_topic": topic_id,
                        "updated_at": now,
                        "evidence": hit["evidence"],
                    })
                    new_count += 1
                elif mode == "merge_set":
                    current_val = existing[-1].get("value", "") if existing else ""
                    all_vals = _split_stack_values(current_val + "," + value)
                    if all_vals:
                        existing[-1]["value"] = "、".join(all_vals)
                        existing[-1]["updated_at"] = now
                        existing[-1]["confidence"] = min(1.0, existing[-1].get("confidence", 0) + 0.1)
                        new_count += 1
                elif mode == "append":
                    self._entries.append({
                        "field": field,
                        "value": value,
                        "confidence": hit["confidence"],
                        "source_topic": topic_id,
                        "updated_at": now,
                        "evidence": hit["evidence"],
                    })
                    new_count += 1
            if len(self._entries) > MAX_ENTRIES:
                self._entries.sort(key=lambda e: (e.get("confidence", 0), e.get("updated_at", 0)))
                self._entries = self._entries[-MAX_ENTRIES:]
            self.save()
            return new_count

    def clear(self) -> None:
        """清空画像数据。"""
        with _lock:
            self._entries = []
            self.save()
