"""Part 2 of l2_long_term (lines 2781-3415 of 3415)."""
import logging
import os
import json
import threading
from typing import Any, Callable, Dict, List, Optional, Tuple

from collections import defaultdict, deque

from src.ximu.common.utils import generate_id
from src.ximu.common.utils import now_timestamp

# Import local dependencies
from .part1 import (
    ConceptStore,
    ConfidenceLevel,
    EventStore,
    ExperienceStore,
    FactStore,
    KnowledgeEdge,
    KnowledgeEntry,
    KnowledgeGraphManager,
    KnowledgeNode,
    KnowledgeSource,
    KnowledgeStatus,
    KnowledgeType,
    MemoryItem,
    PreferenceStore,
    ProcedureStore,
    RelationshipStore,
    RuleStore,
    SchemaStore,
    SkillStore,
    StorageTier,
)

# Version control
__version__ = "0.5"

logger = logging.getLogger("src.ximu.core.memory._l2_long_term_parts.part2")


class BaseManager:
    """
    基础管理器类，提供通用的存储注册、事件处理、指标记录和状态维护功能。
    """

    def __init__(self, **kwargs):
        """
        初始化基础管理器。

        Args:
            **kwargs: 配置参数字典。
        """
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=500)
        self._initialized: bool = False
        self._last_maintenance: float = 0.0
        self._maintenance_interval: float = 300.0

    def register_store(self, name: str, store_obj: Any) -> None:
        """
        注册存储对象。

        Args:
            name: 存储名称。
            store_obj: 存储对象实例。
        """
        with self._lock:
            self._stores[name] = store_obj
            logger.info("注册存储: %s", name)
            self._emit("store_registered", {"name": name})

    def get_store(self, name: str) -> Optional[Any]:
        """
        获取存储对象。

        Args:
            name: 存储名称。

        Returns:
            存储对象实例，如果不存在则返回 None。
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """
        移除存储对象。

        Args:
            name: 存储名称。

        Returns:
            是否成功移除。
        """
        with self._lock:
            s = self._stores.pop(name, None)
            if s:
                logger.info("移除存储: %s", name)
                self._emit("store_removed", {"name": name})
            return s is not None

    def on(self, event: str, handler: Callable) -> None:
        """
        注册事件处理器。

        Args:
            event: 事件名称。
            handler: 处理函数。
        """
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable) -> None:
        """
        注销事件处理器。

        Args:
            event: 事件名称。
            handler: 处理函数。
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Optional[Dict[str, Any]] = None) -> None:
        """
        触发事件并通知所有注册的处理器。

        Args:
            event: 事件名称。
            data: 事件数据。
        """
        handlers = self._event_handlers.get(event, [])
        for h in handlers:
            try:
                h(data or {})
            except Exception as e:
                # 合理忽略：回调/可选操作失败不影响主流程
                logger.debug("事件处理器执行失败: %s, 错误: %s", event, e, exc_info=True)

    def record_metric(self, name: str, value: float) -> None:
        """
        记录指标值。

        Args:
            name: 指标名称。
            value: 指标值。
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append(
                {"metric": name, "value": value, "timestamp": now_timestamp()}
            )

    def get_metric(self, name: str) -> float:
        """
        获取指标值。

        Args:
            name: 指标名称。

        Returns:
            指标值，默认为 0.0。
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """
        获取所有指标。

        Returns:
            指标字典。
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        """重置所有指标。"""
        with self._lock:
            self._metrics.clear()

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取指标历史记录。

        Args:
            limit: 返回的最大记录数。

        Returns:
            历史记录列表。
        """
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """
        初始化管理器。

        Returns:
            是否初始化成功。
        """
        with self._lock:
            if self._initialized:
                logger.warning("管理器已初始化，跳过重复初始化")
                return False
            self._initialized = True
            logger.info("管理器初始化完成")
            self._emit("initialized", {})
            return True

    def shutdown(self) -> bool:
        """
        关闭管理器。

        Returns:
            是否关闭成功。
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            logger.info("管理器关闭中")
            self._emit("shutdown", {})
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """
        执行维护操作（清理过期数据）。

        Args:
            force: 是否强制执行。

        Returns:
            维护结果字典。
        """
        with self._lock:
            now = now_timestamp()
            if not force and now - self._last_maintenance < self._maintenance_interval:
                return {"status": "skipped", "reason": "interval_not_reached"}

            cleaned = 0
            for name, s in self._stores.items():
                if hasattr(s, "cleanup_expired"):
                    try:
                        cleaned += s.cleanup_expired()
                    except Exception as e:
                        logger.debug("清理存储 %s 失败: %s", name, e, exc_info=True)

            self._last_maintenance = now
            logger.info("维护完成，清理了 %d 项数据", cleaned)
            self._emit("maintenance", {"cleaned": cleaned})
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        """
        获取管理器统计信息。

        Returns:
            统计信息字典。
        """
        with self._lock:
            store_stats = {}
            for name, s in self._stores.items():
                if hasattr(s, "get_stats"):
                    try:
                        store_stats[name] = s.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(s, "size"):
                    store_stats[name] = {"size": s.size()}

            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history),
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        将状态转换为字典。

        Returns:
            状态字典。
        """
        with self._lock:
            return {
                "config": dict(self._config),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys()),
            }

    def export_state(self, filepath: str) -> None:
        """
        导出状态到文件。

        Args:
            filepath: 文件路径。
        """
        with self._lock:
            state = self.to_dict()
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(state, f, ensure_ascii=False, default=str)
            logger.info("状态已导出到: %s", filepath)

    def import_state(self, filepath: str) -> bool:
        """
        从文件导入状态。

        Args:
            filepath: 文件路径。

        Returns:
            是否导入成功。
        """
        if not os.path.exists(filepath):
            logger.error("导入文件不存在: %s", filepath)
            return False

        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            logger.error("解析导入文件失败: %s", e)
            return False

        with self._lock:
            if "config" in data:
                self._config.update(data["config"])
            if "metrics" in data:
                self._metrics.update(data["metrics"])
            logger.info("状态已从 %s 导入", filepath)
            return True


class StorageTierManager(BaseManager):
    """
    存储层级管理器，负责管理不同层级的存储对象。
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class KnowledgeConsolidator(BaseManager):
    """
    知识整合管理器，负责知识的合并与去重。
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class KnowledgeVerifier(BaseManager):
    """
    知识验证管理器，负责验证知识的有效性和一致性。
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class L2_long_termEnhanced:
    """
    增强型长期记忆核心类（占位符，用于工厂模式）。
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self._config = config or {}

    def execute(self, *args, **kwargs) -> Any:
        """执行核心逻辑（占位符）。"""
        pass


class L2_long_termFactory:
    """
    l2_long_term 工厂类，提供单例模式创建实例。
    """

    _instances: Dict[str, L2_long_termEnhanced] = {}
    _lock = threading.Lock()

    @classmethod
    def get_instance(cls, name: str = "default", config: Optional[Dict[str, Any]] = None) -> L2_long_termEnhanced:
        """
        获取单例实例（线程安全：双重检查锁定）。

        Args:
            name: 实例名称。
            config: 配置参数。

        Returns:
            实例对象。
        """
        if name not in cls._instances:
            with cls._lock:
                if name not in cls._instances:
                    cls._instances[name] = L2_long_termEnhanced(config)
        return cls._instances[name]

    @classmethod
    def create(cls, config: Optional[Dict[str, Any]] = None) -> L2_long_termEnhanced:
        """
        创建新实例。

        Args:
            config: 配置参数。

        Returns:
            新实例对象。
        """
        return L2_long_termEnhanced(config)

    @classmethod
    def reset_all(cls) -> None:
        """重置所有实例。"""
        cls._instances.clear()


class L2_long_termManager:
    """
    l2_long_term 管理器，负责实例的生命周期管理。
    """

    def __init__(self):
        self._instances: Dict[str, L2_long_termEnhanced] = {}
        self._default_config: Dict[str, Any] = {}

    def register(self, name: str, instance: L2_long_termEnhanced) -> None:
        """
        注册实例。

        Args:
            name: 实例名称。
            instance: 实例对象。
        """
        self._instances[name] = instance

    def unregister(self, name: str) -> Optional[L2_long_termEnhanced]:
        """
        注销实例。

        Args:
            name: 实例名称。

        Returns:
            被注销的实例，如果不存在则返回 None。
        """
        return self._instances.pop(name, None)

    def get(self, name: str) -> Optional[L2_long_termEnhanced]:
        """
        获取实例。

        Args:
            name: 实例名称。

        Returns:
            实例对象，如果不存在则返回 None。
        """
        return self._instances.get(name)

    def list_all(self) -> List[str]:
        """
        列出所有已注册的实例名称。

        Returns:
            实例名称列表。
        """
        return list(self._instances.keys())

    def health_check(self) -> Dict[str, bool]:
        """
        执行健康检查。

        Returns:
            健康检查结果字典。
        """
        results = {}
        for name, inst in self._instances.items():
            results[name] = hasattr(inst, "execute")
        return results


# 全局管理器实例
l2_long_term_manager = L2_long_termManager()
