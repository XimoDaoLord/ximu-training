"""
L2长期记忆部分模块，用于分割和合并l2_long_term数据。
"""

import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)

def _split_l2_long_term_parts(data: bytes) -> List[bytes]:
    """
    分割l2_long_term数据。

    使用特定分隔符将数据分割为多个部分，并过滤掉空数据。

    Args:
        data: 输入的字节数据。

    Returns:
        分割后的数据列表。
    """
    if not data:
        return []

    logger.info("开始分割l2_long_term数据")
    parts = data.split(b'\x00')
    filtered_parts = [part for part in parts if part]

    logger.info("分割完成，共分割出 %d 部分", len(filtered_parts))
    return filtered_parts

def _merge_l2_long_term_parts(parts: List[bytes]) -> bytes:
    """
    合并分割后的l2_long_term数据。

    使用特定分隔符将多个数据部分合并为一个字节串。

    Args:
        parts: 要合并的数据部分列表。

    Returns:
        合并后的字节数据。
    """
    if not parts:
        logger.info("开始合并分割后的数据，无数据需要合并")
        return b''

    logger.info("开始合并分割后的数据，共 %d 部分", len(parts))
    data = b'\x00'.join(parts)

    logger.info("合并完成，合并后数据大小为 %d bytes", len(data))
    return data

class L2LongTermParts:
    """
    L2长期记忆部分管理类，用于管理l2_long_term数据的分割和合并操作。
    """

    def __init__(self, data: bytes):
        """
        初始化L2长期记忆部分管理类。

        Args:
            data: 初始的字节数据。
        """
        self.data = data

    def split(self) -> List[bytes]:
        """
        分割当前存储的l2_long_term数据。

        Returns:
            分割后的数据列表。
        """
        return _split_l2_long_term_parts(self.data)

    def merge(self, parts: List[bytes]) -> bytes:
        """
        合并数据部分为单个字节串。

        Args:
            parts: 要合并的数据部分列表。

        Returns:
            合并后的字节数据。
        """
        return _merge_l2_long_term_parts(parts)

__all__ = ["L2LongTermParts", "_split_l2_long_term_parts", "_merge_l2_long_term_parts"]
