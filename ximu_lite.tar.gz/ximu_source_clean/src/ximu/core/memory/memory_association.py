"""
内存关联模块入口点，提供内存关联功能的重导出能力。
"""
import importlib as _il
import logging as _logging
from typing import Any, Optional

__version__: str = "0.5"


def _import_module(module_name: str, package: str) -> Optional[Any]:
    """
    导入指定模块。

    Args:
        module_name: 模块名称。
        package: 包名称。

    Returns:
        导入成功返回模块对象，否则返回 None。
    """
    try:
        return _il.import_module(f"._memory_association_parts.{module_name}", package=package)
    except Exception as e:
        _logging.warning(f"导入模块 {module_name} 失败：{e}")
        return None


def _re_export(module: Any) -> None:
    """
    重导出模块中的非私有成员。

    Args:
        module: 模块对象。
    """
    for name in dir(module):
        if not name.startswith("_"):
            globals()[name] = getattr(module, name)


def _re_export_parts() -> None:
    """重导出内存关联模块的两个部分。"""
    for part in ["part1", "part2"]:
        module = _import_module(part, __package__)
        if module is not None:
            _re_export(module)


def main() -> None:
    """主函数，导入和重导出内存关联模块。"""
    _re_export_parts()


if __name__ == "__main__":
    main()