"""XimuAI 记忆引擎核心模块。

无外部硬依赖的本地记忆检索引擎，支持多层级分类、指数遗忘曲线时效加权、
轻量级词面匹配（中文 bigram/unigram + 英文/数字 token）以及倒排索引加速检索。
"""

from __future__ import annotations
import json
import logging
import math
import re
import threading
import time
import uuid
from collections import OrderedDict, defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, FrozenSet, List, Optional, Sequence, Set, Tuple

logger = logging.getLogger(__name__)

# 记忆类型常量
SEMANTIC: str = "semantic"
EPISODIC: str = "episodic"
PROCEDURAL: str = "procedural"
EMOTIONAL: str = "emotional"

# 记忆层级常量
SHORT_TERM: str = "short_term"
MID_TERM: str = "mid_term"
LONG_TERM: str = "long_term"

# 默认配置参数
DEFAULT_SIMILARITY_THRESHOLD: float = 0.3
DEFAULT_FORGETTING_HALF_LIFE_HOURS: float = 168.0
DEFAULT_MAX_MEMORY_CAP: int = 10000
DEFAULT_QUERY_CACHE_SIZE: int = 1024
CONFIG_VERSION: int = 1

# 词权重大小
BIGRAM_WEIGHT: float = 1.0
UNIGRAM_WEIGHT: float = 0.5

# 正则表达式预编译
WHITESPACE_RE = re.compile(r"\s+")
ALNUM_RE = re.compile(r"[a-z0-9]+")
CJK_RE = re.compile(r"[\u4e00-\u9fff]+")

__all__ = [
    "SEMANTIC", "EPISODIC", "PROCEDURAL", "EMOTIONAL",
    "SHORT_TERM", "MID_TERM", "LONG_TERM",
    "normalize_text", "tokenize_keywords",
    "cosine_similarity", "sparse_cosine", "recency_factor",
    "MemoryConfig", "Memory", "InvertedIndex", "LRUCache", "MemoryEngine"
]

def normalize_text(text: str) -> str:
    """归一化文本：折叠空白、去首尾、转小写。

    Args:
        text: 输入文本（str）。

    Returns:
        归一化后的字符串（str），空输入返回空串。
    """
    if not text:
        return ""
    try:
        normalized = WHITESPACE_RE.sub(" ", str(text)).strip().lower()
        return normalized
    except Exception as e:
        logger.warning("文本归一化失败: %s", str(e))
        return ""

def tokenize_keywords(
    text: str,
    stopwords_unigram: Optional[FrozenSet[str]] = None,
    stopwords_bigram: Optional[FrozenSet[str]] = None,
) -> List[str]:
    """提取英文单词及中文 bigram/unigram 作为关键词。

    英文/数字 token 直接保留；中文片段生成所有相邻 bigram 和单字 unigram。
    命中停用词集的 token 被过滤。

    Args:
        text: 输入文本（str）。
        stopwords_unigram: unigram 停用词集合（Frozenset[str]）。
        stopwords_bigram: bigram 停用词集合（Frozenset[str]）。

    Returns:
        去重后的 token 列表（List[str]）。
    """
    if not text:
        return []
    try:
        stopwords = (stopwords_unigram or frozenset()) | (stopwords_bigram or frozenset())
        tokens: Set[str] = set()
        # 处理中文分词边界条件
        segments = CJK_RE.findall(text.lower())
        for seg in segments:
            for i in range(len(seg)):
                token = seg[i]
                if token not in stopwords and len(token) == 1:
                    tokens.add(token)
            for i in range(len(seg)-1):
                bigram = seg[i:i+2]
                if bigram not in stopwords:
                    tokens.add(bigram)
        # 处理英文/数字
        alnum_tokens = ALNUM_RE.findall(text.lower())
        for token in alnum_tokens:
            if token not in stopwords:
                tokens.add(token)
        return list(tokens)
    except Exception as e:
        logger.warning("关键词提取失败: %s", str(e))
        return []

def cosine_similarity(a: Sequence[float], b: Sequence[float]) -> float:
    """计算两个稠密向量的余弦相似度。

    Args:
        a: 向量 a（Sequence[float]）。
        b: 向量 b（Sequence[float]）。

    Returns:
        余弦相似度值（float），任一向量为空或零向量时返回 0.0。
    """
    if not a or not b:
        return 0.0
    try:
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = sum(x ** 2 for x in a)
        norm_b = sum(y ** 2 for y in b)
        if norm_a * norm_b == 0:
            return 0.0
        return dot / (math.sqrt(norm_a) * math.sqrt(norm_b))
    except Exception as e:
        logger.warning("余弦相似度计算失败: %s", str(e))
        return 0.0

def sparse_cosine(a: Dict[str, float], b: Dict[str, float]) -> float:
    """计算两个稀疏向量的余弦相似度。

    Args:
        a: 稀疏向量 a（Dict[str, float]）。
        b: 稀疏向量 b（Dict[str, float]）。

    Returns:
        余弦相似度，任一方为空或模长为 0 时返回 0.0。
    """
    if not a or not b:
        return 0.0
    try:
        common = a.keys() & b.keys()
        if not common:
            return 0.0
        dot = sum(a[key] * b[key] for key in common)
        norm_a = sum(v ** 2 for v in a.values())
        norm_b = sum(v ** 2 for v in b.values())
        if norm_a * norm_b == 0:
            return 0.0
        return dot / (math.sqrt(norm_a) * math.sqrt(norm_b))
    except Exception as e:
        logger.warning("稀疏余弦相似度计算失败: %s", str(e))
        return 0.0

def recency_factor(
    timestamp: float,
    now: Optional[float] = None,
    half_life_hours: float = DEFAULT_FORGETTING_HALF_LIFE_HOURS,
) -> float:
    """基于指数遗忘曲线计算时效因子。

    Args:
        timestamp: 记忆写入时间戳（秒）。
        now: 当前时间戳（秒），默认取 time.time()。
        half_life_hours: 半衰期（小时），<= 0 时返回 1.0。

    Returns:
        (0, 1] 区间的时效因子（float）。
    """
    if half_life_hours <= 0:
        return 1.0
    try:
        current = now or time.time()
        age = max(0.0, (current - timestamp) / 3600.0)
        return 0.5 ** (age / half_life_hours)
    except Exception as e:
        logger.warning("时效因子计算失败: %s", str(e))
        return 1.0


class MemoryConfig:
    """记忆引擎配置管理器，支持从 JSON 文件加载停用词及版本控制。"""

    def __init__(self, config_path: Optional[str] = None) -> None:
        """初始化配置，可选从 JSON 文件加载。

        Args:
            config_path: JSON 配置文件路径（str | None）。
        """
        self._lock = threading.RLock()
        self._config_path = Path(config_path or __file__.parent / "memory_config.json")
        self._version = CONFIG_VERSION
        self._stopwords_unigram = frozenset()
        self._stopwords_bigram = frozenset()

        self._load_config()

    def _load_config(self) -> None:
        """加载配置文件，处理异常情况。"""
        with self._lock:
            try:
                if self._config_path.exists():
                    with open(self._config_path, "r", encoding="utf-8") as fp:
                        data = json.load(fp)
                    stored_version = data.get("version", self._version)
                    if stored_version != self._version:
                        logger.warning("配置版本不匹配: 期望 %d，实际 %d", self._version, stored_version)
                    self._stopwords_unigram = frozenset(data.get("stopwords_unigram", []))
                    self._stopwords_bigram = frozenset(data.get("stopwords_bigram", []))
                else:
                    logger.info("配置文件不存在: %s，使用默认配置", self._config_path)
            except json.JSONDecodeError as e:
                logger.error("配置文件 JSON 解析失败: %s", str(e))
            except Exception as e:
                logger.error("配置加载失败: %s", str(e))

    @property
    def version(self) -> int:
        """获取当前配置版本号（线程安全）。"""
        with self._lock:
            return self._version

    @property
    def stopwords_unigram(self) -> FrozenSet[str]:
        """获取当前 unigram 停用词集合（线程安全）。"""
        with self._lock:
            return self._stopwords_unigram

    @property
    def stopwords_bigram(self) -> FrozenSet[str]:
        """获取当前 bigram 停用词集合（线程安全）。"""
        with self._lock:
            return self._stopwords_bigram

    def reload(self) -> None:
        """重新加载配置文件，支持版本控制。"""
        with self._lock:
            try:
                with open(self._config_path, "r", encoding="utf-8") as fp:
                    data = json.load(fp)
                stored_version = data.get("version", self._version)
                if stored_version != self._version:
                    logger.info("配置版本更新: %d → %d", stored_version, self._version)
                self._stopwords_unigram = frozenset(data.get("stopwords_unigram", []))
                self._stopwords_bigram = frozenset(data.get("stopwords_bigram", []))
            except json.JSONDecodeError as e:
                logger.error("配置文件 JSON 解析失败: %s", str(e))
            except Exception as e:
                logger.error("配置重载失败: %s", str(e))


class Memory:
    """单条记忆数据模型。"""

    def __init__(
        self,
        content: str,
        memory_type: str = SEMANTIC,
        level: str = SHORT_TERM,
        importance: float = 0.5,
        tags: Optional[List[str]] = None,
        origin: str = "user",
        timestamp: Optional[float] = None,
        last_accessed: Optional[float] = None,
        dense_embedding: Optional[List[float]] = None,
        stopwords_unigram: Optional[FrozenSet[str]] = None,
        stopwords_bigram: Optional[FrozenSet[str]] = None,
    ) -> None:
        """初始化记忆数据模型。

        Args:
            content: 记忆内容（str）。
            memory_type: 记忆类型（str）。
            level: 记忆层级（str）。
            importance: 重要度（float），范围 [0.0, 1.0]。
            tags: 标签列表（Optional[List[str]]）。
            origin: 来源（str）。
            timestamp: 时间戳（float | None），默认当前时间。
            last_accessed: 最后访问时间（float | None），默认当前时间。
            dense_embedding: 稠密向量（Optional[List[float]]）。
            stopwords_unigram: unigram 停用词集合（Optional[Frozenset[str]]）。
            stopwords_bigram: bigram 停用词集合（Optional[Frozenset[str]]）。
        """
        self.id = str(uuid.uuid4())
        self.content = content
        self.memory_type = memory_type
        self.level = level
        self.importance = float(max(0.0, min(1.0, importance)))
        self.tags = list(tags or [])
        self.origin = origin
        self.timestamp = timestamp or time.time()
        self.last_accessed = last_accessed or time.time()
        self.dense_embedding = dense_embedding
        self.sparse_embedding = self._generate_embedding(content, stopwords_unigram, stopwords_bigram)

    def _generate_embedding(
        self,
        text: str,
        stopwords_unigram: Optional[FrozenSet[str]] = None,
        stopwords_bigram: Optional[FrozenSet[str]] = None,
    ) -> Dict[str, float]:
        """生成词面匹配稀疏向量。

        Args:
            text: 输入文本（str）。
            stopwords_unigram: unigram 停用词集合（Optional[Frozenset[str]]）。
            stopwords_bigram: bigram 停用词集合（Optional[Frozenset[str]]）。

        Returns:
            稀疏向量表示（Dict[str, float]）。
        """
        try:
            tokens = tokenize_keywords(text, stopwords_unigram, stopwords_bigram)
            embedding = defaultdict(float)
            for token in tokens:
                if len(token) == 2 and CJK_RE.match(token):
                    embedding[token] += BIGRAM_WEIGHT
                elif CJK_RE.match(token):
                    embedding[token] += UNIGRAM_WEIGHT
                else:
                    embedding[token] += BIGRAM_WEIGHT
            return dict(embedding)
        except Exception as e:
            logger.warning("稀疏向量生成失败: %s", str(e))
            return {}

    def touch(self) -> None:
        """更新最近访问时间。"""
        self.last_accessed = time.time()

    @property
    def score(self) -> float:
        """计算记忆综合得分（内部使用）。"""
        return self.importance * recency_factor(self.timestamp)

    def to_dict(self) -> Dict[str, Any]:
        """转换为 JSON 序列化字典。"""
        allowed = {
            "id", "content", "memory_type", "level", "importance",
            "tags", "origin", "timestamp", "last_accessed",
            "dense_embedding", "sparse_embedding"
        }
        return {k: v for k, v in asdict(self).items() if k in allowed}


class InvertedIndex:
    """倒排索引：维护 token -> set(memory_id) 映射，支持直接 ID 删除。"""

    def __init__(self) -> None:
        """初始化空索引。"""
        self._lock = threading.RLock()
        self._index: Dict[str, Set[str]] = defaultdict(set)
        self._memory_map: Dict[str, List[str]] = defaultdict(list)

    def add(self, memory_id: str, content: str) -> None:
        """添加记忆到索引。

        Args:
            memory_id: 记忆 ID（str）。
            content: 记忆内容（str）。
        """
        with self._lock:
            tokens = tokenize_keywords(content)
            self._memory_map[memory_id] = tokens
            for token in tokens:
                self._index[token].add(memory_id)
            logger.debug("索引添加记忆 %s，token 数: %d", memory_id, len(tokens))

    def remove(self, memory_id: str) -> bool:
        """通过记忆 ID 直接删除索引项。

        Args:
            memory_id: 记忆 ID（str）。

        Returns:
            是否成功删除（bool）。
        """
        with self._lock:
            tokens = self._memory_map.pop(memory_id, [])
            for token in tokens:
                self._index[token].discard(memory_id)
                if not self._index[token]:
                    del self._index[token]
            logger.debug("索引移除记忆 %s，token 数: %d", memory_id, len(tokens))
            return True

    def lookup(self, query: str) -> Set[str]:
        """查询匹配任意 token 的记忆 ID。

        Args:
            query: 查询文本（str）。

        Returns:
            匹配的记忆 ID 集合（Set[str]）。
        """
        with self._lock:
            tokens = tokenize_keywords(query)
            result = set()
            for token in tokens:
                result.update(self._index.get(token, set()))
            logger.debug("索引查询 '%s'，匹配记忆数: %d", query, len(result))
            return result

    def clear(self) -> None:
        """清空索引。"""
        with self._lock:
            self._index.clear()
            self._memory_map.clear()
            logger.debug("索引已清空")


class LRUCache:
    """线程安全 LRU 缓存，支持批量操作。"""

    def __init__(self, max_size: int) -> None:
        """初始化缓存。

        Args:
            max_size: 缓存容量（int）。
        """
        if max_size <= 0:
            raise ValueError("max_size 必须大于 0")
        self._cache = OrderedDict()
        self._max_size = max_size
        self._lock = threading.RLock()

    def get(self, key: str) -> Optional[Dict[str, float]]:
        """获取缓存值。

        Args:
            key: 缓存键（str）。

        Returns:
            缓存值（Optional[Dict[str, float]]）。
        """
        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
                return self._cache[key]
            return None

    def put(self, key: str, value: Dict[str, float]) -> None:
        """写入缓存值。

        Args:
            key: 缓存键（str）。
            value: 缓存值（Dict[str, float]）。
        """
        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
            self._cache[key] = value
            while len(self._cache) > self._max_size:
                self._cache.popitem(last=False)

    def bulk_get(self, keys: Sequence[str]) -> Dict[str, Optional[Dict[str, float]]]:
        """批量获取缓存。

        Args:
            keys: 缓存键序列（Sequence[str]）。

        Returns:
            键值对字典（Dict[str, Optional[Dict[str, float]]]）。
        """
        with self._lock:
            return {k: self._cache.get(k) for k in keys}

    def bulk_put(self, items: Dict[str, Dict[str, float]]) -> None:
        """批量写入缓存。

        Args:
            items: 键值对字典（Dict[str, Dict[str, float]]）。
        """
        with self._lock:
            for key, value in items.items():
                if key in self._cache:
                    self._cache.move_to_end(key)
                self._cache[key] = value
            while len(self._cache) > self._max_size:
                self._cache.popitem(last=False)


class MemoryEngine:
    """记忆引擎核心类，负责记忆存储、倒排索引维护与检索。"""

    def __init__(
        self,
        max_memory_cap: int = DEFAULT_MAX_MEMORY_CAP,
        cache_size: int = DEFAULT_QUERY_CACHE_SIZE,
        config_path: Optional[str] = None,
        similarity_threshold: float = DEFAULT_SIMILARITY_THRESHOLD,
        forgetting_half_life_hours: float = DEFAULT_FORGETTING_HALF_LIFE_HOURS,
        recency_weight: float = 0.0,
        importance_weight: float = 0.0,
    ) -> None:
        """初始化记忆引擎。

        Args:
            max_memory_cap: 记忆条数上限（int）。
            cache_size: 查询缓存容量（int）。
            config_path: 配置文件路径（str | None）。
            similarity_threshold: 检索相似度阈值（float）。
            forgetting_half_life_hours: 遗忘曲线半衰期（小时）（float）。
            recency_weight: 时效权重（float）。
            importance_weight: 重要度权重（float）。
        """
        self._lock = threading.RLock()
        self._memories: Dict[str, Memory] = {}
        self._memory_list: List[Tuple[float, str]] = []
        self._index = InvertedIndex()
        self._query_cache = LRUCache(cache_size)
        self._max_memory_cap = max_memory_cap
        self._similarity_threshold = similarity_threshold
        self._forgetting_half_life = forgetting_half_life_hours
        self._recency_weight = recency_weight
        self._importance_weight = importance_weight
        self.config = MemoryConfig(config_path)
        self._log_prefix = f"MemoryEngine[{id(self)}]"

    def _update_memory_state(self, memory: Memory) -> None:
        """更新记忆状态（内部使用）。

        Args:
            memory: 记忆对象（Memory）。
        """
        with self._lock:
            self._memories[memory.id] = memory
            self._memory_list.append((memory.timestamp, memory.id))
            self._index.add(memory.id, memory.content)
            if len(self._memory_list) > self._max_memory_cap:
                oldest = self._memory_list.pop(0)
                self._index.remove(oldest[1])
                del self._memories[oldest[1]]
                logger.debug("记忆达到上限，移除最旧记忆 %s", oldest[1])

    def add(
        self,
        content: str,
        memory_type: str = SEMANTIC,
        level: str = SHORT_TERM,
        importance: float = 0.5,
        tags: Optional[List[str]] = None,
        origin: str = "user",
        **kwargs: Any,
    ) -> str:
        """添加新记忆。

        Args:
            content: 记忆内容（str）。
            memory_type: 记忆类型（str）。
            level: 记忆层级（str）。
            importance: 重要度（float）。
            tags: 标签列表（Optional[List[str]]）。
            origin: 来源（str）。
            **kwargs: 其他可选参数。

        Returns:
            新记忆 ID（str）。
        """
        with self._lock:
            memory = Memory(
                content=content,
                memory_type=memory_type,
                level=level,
                importance=importance,
                tags=tags,
                origin=origin,
                stopwords_unigram=self.config.stopwords_unigram,
                stopwords_bigram=self.config.stopwords_bigram,
                **kwargs,
            )
            self._update_memory_state(memory)
            logger.info("%s 添加记忆: %s", self._log_prefix, memory.id)
            return memory.id

    def remove(self, memory_id: str) -> bool:
        """移除记忆。

        Args:
            memory_id: 记忆 ID（str）。

        Returns:
            是否成功删除（bool）。
        """
        with self._lock:
            if memory_id in self._memories:
                del self._memories[memory_id]
                self._index.remove(memory_id)
                logger.info("%s 移除记忆: %s", self._log_prefix, memory_id)
                return True
            return False

    def get(self, memory_id: str) -> Optional[Memory]:
        """按 ID 获取记忆。

        Args:
            memory_id: 记忆 ID（str）。

        Returns:
            记忆对象（Optional[Memory]）。
        """
        with self._lock:
            return self._memories.get(memory_id)

    def search(
        self,
        query: str,
        limit: int = 10,
        now: Optional[float] = None,
    ) -> List[Memory]:
        """检索匹配的记忆。

        Args:
            query: 查询文本（str）。
            limit: 结果数量上限（int）。
            now: 当前时间戳（float | None）。

        Returns:
            匹配的记忆列表（List[Memory]）。
        """
        with self._lock:
            now = now or time.time()
            normalized_query = normalize_text(query)
            query_vec = self._query_cache.get(normalized_query)
            if not query_vec:
                query_vec = Memory(
                    content="",
                    stopwords_unigram=self.config.stopwords_unigram,
                    stopwords_bigram=self.config.stopwords_bigram,
                )._generate_embedding(normalized_query)
                self._query_cache.put(normalized_query, query_vec)

            candidates = self._index.lookup(query)
            scored = []
            for mid in candidates:
                memory = self._memories.get(mid)
                if not memory:
                    continue
                # 计算相似度
                sim = sparse_cosine(memory.sparse_embedding, query_vec)
                # 综合评分
                score = (sim * self._similarity_threshold +
                         self._recency_weight * memory.score +
                         self._importance_weight * memory.importance)
                if score >= self._similarity_threshold:
                    scored.append((score, memory))
            # 按得分排序
            scored.sort(reverse=True, key=lambda x: x[0])
            # 返回前 limit 个结果
            return [m for s, m in scored[:limit]]


class MemoryItem:
    """记忆项。"""
    def __init__(self, key="", value=None):
        self.key = key
        self.value = value


def get_memory_engine():
    """获取记忆引擎实例。"""
    return None
