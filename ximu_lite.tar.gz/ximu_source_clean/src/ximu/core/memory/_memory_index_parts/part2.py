"""
Memory Index Part 2.

本模块提供内存索引第二部分的具体实现，包括索引更新、合并、压缩、查询管理，
以及向量、倒排、混合索引和统一内存索引接口。
"""

import json
import logging
import os
import threading
from collections import defaultdict, deque
from typing import Any, Callable, Dict, List, Optional, Tuple

from .part1 import (
    CompositeIndexStore,
    FieldIndexStore,
    FuzzyIndexStore,
    GraphIndexStore,
    IndexBuildManager,
    IndexEntry,
    IndexPrecision,
    IndexStatus,
    IndexType,
    InvertedIndexStore,
    InvertedPosting,
    KeywordIndexStore,
    MemoryItem,
    PrefixIndexStore,
    SemanticIndexStore,
    TemporalIndexStore,
    VectorIndexStore,
    VectorMetric,
    VectorRecord,
)
from src.ximu.common.utils import now_timestamp

logger = logging.getLogger("src.ximu.core.memory._memory_index_parts.part2")

__version__ = "0.5"


class IndexBaseManager:
    """
    索引管理基类。

    封装存储注册、事件分发、指标记录、历史追踪及通用生命周期方法，
    供索引更新、合并、压缩、查询等管理器继承，以降低重复代码。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化索引管理基类。

        :param kwargs: 配置参数，将保存为管理器内部配置。
        """
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._event_handlers: Dict[str, List[Callable[[Dict[str, Any]], None]]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=500)
        self._initialized: bool = False
        self._last_maintenance: float = 0.0
        self._maintenance_interval: float = 300.0

    # ------------------------------------------------------------------
    # 存储注册与查询
    # ------------------------------------------------------------------
    def register_store(self, name: str, store_obj: Any) -> None:
        """
        注册一个存储实例。

        :param name: 存储名称。
        :param store_obj: 存储对象。
        """
        with self._lock:
            self._stores[name] = store_obj
            self._emit("store_registered", {"name": name})
            logger.debug("注册存储: %s", name)

    def get_store(self, name: str) -> Optional[Any]:
        """
        获取指定名称的存储实例。

        :param name: 存储名称。
        :return: 存储对象；若不存在则返回 None。
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """
        移除指定名称的存储实例。

        :param name: 存储名称。
        :return: 若成功移除返回 True，否则返回 False。
        """
        with self._lock:
            store = self._stores.pop(name, None)
            if store is not None:
                self._emit("store_removed", {"name": name})
                logger.debug("移除存储: %s", name)
            return store is not None

    # ------------------------------------------------------------------
    # 事件系统
    # ------------------------------------------------------------------
    def on(self, event: str, handler: Callable[[Dict[str, Any]], None]) -> None:
        """
        注册事件处理器。

        :param event: 事件名称。
        :param handler: 事件回调函数，接受字典参数。
        """
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable[[Dict[str, Any]], None]) -> None:
        """
        移除事件处理器。

        :param event: 事件名称。
        :param handler: 要移除的事件回调函数。
        """
        with self._lock:
            if handler in self._event_handlers.get(event, []):
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Optional[Dict[str, Any]] = None) -> None:
        """
        触发事件，调用所有注册的处理函数。

        :param event: 事件名称。
        :param data: 事件数据。
        """
        handlers = self._event_handlers.get(event, [])
        for handler in handlers:
            try:
                handler(data or {})
            except Exception as exc:
                logger.warning("事件 '%s' 处理失败: %s", event, exc, exc_info=True)

    # ------------------------------------------------------------------
    # 指标与历史
    # ------------------------------------------------------------------
    def record_metric(self, name: str, value: float) -> None:
        """
        记录一个累加型指标。

        :param name: 指标名称。
        :param value: 本次增量值。
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({"metric": name, "value": value, "timestamp": now_timestamp()})

    def get_metric(self, name: str) -> float:
        """
        获取指定名称指标的累计值。

        :param name: 指标名称。
        :return: 累计值，不存在时为 0.0。
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """
        获取所有指标。

        :return: 指标名称到累计值的映射副本。
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        """
        清空所有指标记录。
        """
        with self._lock:
            self._metrics.clear()

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取最近的历史记录。

        :param limit: 最大返回条数。
        :return: 历史记录列表。
        """
        with self._lock:
            return list(self._history)[-limit:]

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------
    def initialize(self) -> bool:
        """
        初始化管理器。

        :return: 若成功初始化返回 True，已初始化或初始化失败返回 False。
        """
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._emit("initialized", {})
            logger.info("管理器初始化完成")
            return True

    def shutdown(self) -> bool:
        """
        关闭管理器。

        :return: 若成功关闭返回 True，未初始化或关闭失败返回 False。
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            self._emit("shutdown", {})
            logger.info("管理器已关闭")
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """
        执行维护操作，包括调用各存储的过期清理方法。

        :param force: 是否强制维护，忽略时间间隔。
        :return: 维护结果字典。
        """
        with self._lock:
            now = now_timestamp()
            if not force and now - self._last_maintenance < self._maintenance_interval:
                return {"status": "skipped"}

            cleaned = 0
            for name, store in self._stores.items():
                if hasattr(store, "cleanup_expired"):
                    try:
                        cleaned += store.cleanup_expired()
                    except Exception as exc:
                        logger.warning("维护时存储 '%s' 清理失败: %s", name, exc, exc_info=True)
            self._last_maintenance = now
            self._emit("maintenance", {"cleaned": cleaned})
            return {"status": "done", "cleaned": cleaned}

    # ------------------------------------------------------------------
    # 统计与序列化
    # ------------------------------------------------------------------
    def get_stats(self) -> Dict[str, Any]:
        """
        获取管理器统计信息。

        :return: 包含初始化状态、各存储统计、指标和历史的字典。
        """
        with self._lock:
            store_stats: Dict[str, Any] = {}
            for name, store in self._stores.items():
                if hasattr(store, "get_stats"):
                    try:
                        store_stats[name] = store.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(store, "size"):
                    try:
                        store_stats[name] = {"size": store.size()}
                    except Exception as exc:
                        logger.warning("获取存储 '%s' 大小时出错: %s", name, exc, exc_info=True)
            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history),
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        将管理器状态转换为字典。

        :return: 包含配置、指标和存储名称列表的字典。
        """
        with self._lock:
            return {
                "config": dict(self._config),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys()),
            }

    def export_state(self, filepath: str) -> None:
        """
        将当前状态导出到 JSON 文件。

        :param filepath: 目标文件路径。
        """
        data = self.to_dict()
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, default=str)
        logger.info("状态已导出到: %s", filepath)

    def import_state(self, filepath: str) -> bool:
        """
        从 JSON 文件导入状态。

        :param filepath: 源文件路径。
        :return: 若导入成功返回 True，文件不存在或解析失败返回 False。
        """
        if not os.path.exists(filepath):
            logger.warning("导入失败，文件不存在: %s", filepath)
            return False
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
        except json.JSONDecodeError as exc:
            logger.error("导入失败，JSON 解析错误: %s", exc, exc_info=True)
            return False

        with self._lock:
            if "config" in data:
                self._config.update(data["config"])
            if "metrics" in data:
                self._metrics.update(data["metrics"])
        logger.info("状态已从 %s 导入", filepath)
        return True


class IndexUpdateManager(IndexBaseManager):
    """
    索引更新管理器。

    负责索引存储的注册、事件分发、指标追踪及周期性维护。
    """


class IndexMergeManager(IndexBaseManager):
    """
    索引合并管理器。

    提供索引合并操作的存储管理与生命周期控制。
    """

    def merge(self, store_names: List[str]) -> Dict[str, Any]:
        """
        执行索引合并操作。

        :param store_names: 参与合并的存储名称列表。
        :return: 合并结果字典。
        """
        with self._lock:
            if not store_names:
                return {"status": "skipped", "reason": "no stores"}
            stores = []
            for name in store_names:
                store = self._stores.get(name)
                if store is None:
                    return {"status": "error", "reason": f"store '{name}' not found"}
                stores.append(store)
            merged = {}
            for store in stores:
                if hasattr(store, "merge_into"):
                    for other in stores:
                        if other is not store and hasattr(other, "merge_into"):
                            try:
                                other.merge_into(store)
                            except Exception as exc:
                                logger.warning("合并存储失败: %s", exc, exc_info=True)
                merged.update(store.get_stats() if hasattr(store, "get_stats") else {})
            return {"status": "done", "stores": len(stores), "merged": merged}


class IndexCompressionManager(IndexBaseManager):
    """
    索引压缩管理器。

    提供索引压缩操作的存储管理与生命周期控制。
    """

    def compress(self, store_name: str, level: int = 1) -> Dict[str, Any]:
        """
        对指定存储执行压缩操作。

        :param store_name: 存储名称。
        :param level: 压缩级别，越大压缩率越高。
        :return: 压缩结果字典。
        """
        with self._lock:
            store = self._stores.get(store_name)
            if store is None:
                return {"status": "error", "reason": f"store '{store_name}' not found"}
            if hasattr(store, "compress"):
                try:
                    result = store.compress(level)
                    logger.info("存储 '%s' 压缩完成", store_name)
                    return {"status": "done", "result": result}
                except Exception as exc:
                    logger.error("存储 '%s' 压缩失败: %s", store_name, exc, exc_info=True)
                    return {"status": "error", "reason": str(exc)}
            logger.warning("存储 '%s' 不支持压缩操作", store_name)
            return {"status": "skipped", "reason": "store does not support compression"}


class IndexQueryManager(IndexBaseManager):
    """
    索引查询管理器。

    提供多存储联合查询的存储管理与生命周期控制。
    """

    def query(self, store_name: str, query: Dict[str, Any]) -> Any:
        """
        在指定存储中执行查询。

        :param store_name: 存储名称。
        :param query: 查询条件字典。
        :return: 查询结果，存储不存在或查询失败时返回 None。
        """
        with self._lock:
            store = self._stores.get(store_name)
            if store is None:
                logger.warning("查询失败，存储 '%s' 不存在", store_name)
                return None
            if hasattr(store, "query"):
                try:
                    result = store.query(query)
                    logger.debug("存储 '%s' 查询成功", store_name)
                    return result
                except Exception as exc:
                    logger.error("存储 '%s' 查询异常: %s", store_name, exc, exc_info=True)
                    return None
            logger.warning("存储 '%s' 不支持查询操作", store_name)
            return None


class VectorIndex:
    """
    向量索引。

    封装向量存储，支持向量插入、查询及统计。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化向量索引。

        :param kwargs: 配置参数。
        """
        self._config: Dict[str, Any] = dict(kwargs)
        self._store: VectorIndexStore = VectorIndexStore(**kwargs)
        self._lock = threading.RLock()

    def insert(self, vector: List[float], payload: Dict[str, Any]) -> None:
        """
        插入一个向量及关联数据。

        :param vector: 向量值。
        :param payload: 关联数据。
        """
        with self._lock:
            record = VectorRecord(vector=vector, payload=payload)
            self._store.insert(record)
            logger.debug("向量已插入")

    def query(self, vector: List[float], top_k: int = 10) -> List[Tuple[float, Dict[str, Any]]]:
        """
        查询最接近给定向量的 top_k 条记录。

        :param vector: 查询向量。
        :param top_k: 返回结果数量。
        :return: (距离, 关联数据) 列表。
        """
        with self._lock:
            results = self._store.query(vector, top_k)
            return [(dist, rec.payload) for dist, rec in results]

    def get_stats(self) -> Dict[str, Any]:
        """
        获取向量索引统计信息。

        :return: 统计字典。
        """
        with self._lock:
            return {"size": self._store.size(), "config": dict(self._config)}

    def to_dict(self) -> Dict[str, Any]:
        """
        将向量索引状态转换为字典。

        :return: 状态字典。
        """
        with self._lock:
            return {"config": dict(self._config), "size": self._store.size()}


class InvertedIndex:
    """
    倒排索引。

    封装倒排存储，支持关键词插入与查询。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化倒排索引。

        :param kwargs: 配置参数。
        """
        self._config: Dict[str, Any] = dict(kwargs)
        self._store: InvertedIndexStore = InvertedIndexStore(**kwargs)
        self._lock = threading.RLock()

    def insert(self, doc_id: str, terms: List[str]) -> None:
        """
        将文档标识及词条插入倒排索引。

        :param doc_id: 文档标识。
        :param terms: 词条列表。
        """
        with self._lock:
            posting = InvertedPosting(doc_id, terms)
            self._store.insert(posting)
            logger.debug("文档 '%s' 已插入倒排索引", doc_id)

    def query(self, terms: List[str]) -> List[str]:
        """
        查询包含指定词条的文档列表。

        :param terms: 词条列表。
        :return: 文档标识列表。
        """
        with self._lock:
            return self._store.query(terms)

    def get_stats(self) -> Dict[str, Any]:
        """
        获取倒排索引统计信息。

        :return: 统计字典。
        """
        with self._lock:
            return {"size": self._store.size(), "config": dict(self._config)}

    def to_dict(self) -> Dict[str, Any]:
        """
        将倒排索引状态转换为字典。

        :return: 状态字典。
        """
        with self._lock:
            return {"config": dict(self._config), "size": self._store.size()}


class HybridIndex:
    """
    混合索引。

    组合向量索引和倒排索引，提供联合查询能力。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化混合索引。

        :param kwargs: 配置参数。
        """
        self._config: Dict[str, Any] = dict(kwargs)
        self._vector_index: VectorIndex = VectorIndex(**kwargs)
        self._inverted_index: InvertedIndex = InvertedIndex(**kwargs)
        self._lock = threading.RLock()

    def insert(self, doc_id: str, terms: List[str], vector: List[float]) -> None:
        """
        同时插入倒排索引和向量索引。

        :param doc_id: 文档标识。
        :param terms: 词条列表。
        :param vector: 向量值。
        """
        with self._lock:
            self._inverted_index.insert(doc_id, terms)
            self._vector_index.insert(vector, {"doc_id": doc_id})
            logger.debug("文档 '%s' 已插入混合索引", doc_id)

    def query(self, terms: List[str], vector: List[float], top_k: int = 10) -> List[Tuple[str, float]]:
        """
        联合倒排和向量查询，返回文档及综合分数。

        :param terms: 词条列表。
        :param vector: 查询向量。
        :param top_k: 返回结果数量。
        :return: (文档标识, 分数) 列表。
        """
        with self._lock:
            inverted_docs = self._inverted_index.query(terms)
            vector_results = self._vector_index.query(vector, top_k)
            score_map: Dict[str, float] = defaultdict(float)
            for doc in inverted_docs:
                score_map[doc] += 1.0
            for dist, payload in vector_results:
                doc_id = payload.get("doc_id", "")
                score_map[doc_id] += 1.0 / (1.0 + dist)
            sorted_docs = sorted(score_map.items(), key=lambda x: x[1], reverse=True)[:top_k]
            return [(doc, score) for doc, score in sorted_docs]

    def get_stats(self) -> Dict[str, Any]:
        """
        获取混合索引统计信息。

        :return: 统计字典。
        """
        with self._lock:
            return {
                "inverted": self._inverted_index.get_stats(),
                "vector": self._vector_index.get_stats(),
                "config": dict(self._config),
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        将混合索引状态转换为字典。

        :return: 状态字典。
        """
        with self._lock:
            return {
                "inverted": self._inverted_index.to_dict(),
                "vector": self._vector_index.to_dict(),
                "config": dict(self._config),
            }


class MemoryIndex:
    """
    统一内存索引。

    组合倒排索引、向量索引和混合索引，提供统一的内存索引接口。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化内存索引。

        :param kwargs: 配置参数。
        """
        self._config: Dict[str, Any] = dict(kwargs)
        self._inverted_index: InvertedIndex = InvertedIndex(**kwargs)
        self._vector_index: VectorIndex = VectorIndex(**kwargs)
        self._hybrid_index: HybridIndex = HybridIndex(**kwargs)
        self._lock = threading.RLock()

    def insert(self, doc_id: str, terms: List[str], vector: List[float]) -> None:
        """
        插入文档到所有索引。

        :param doc_id: 文档标识。
        :param terms: 词条列表。
        :param vector: 向量值。
        """
        with self._lock:
            self._inverted_index.insert(doc_id, terms)
            self._vector_index.insert(vector, {"doc_id": doc_id})
            self._hybrid_index.insert(doc_id, terms, vector)
            logger.debug("文档 '%s' 已插入内存索引", doc_id)

    def query(self, terms: List[str], vector: List[float], top_k: int = 10) -> List[Tuple[str, float]]:
        """
        在内存索引中执行联合查询。

        :param terms: 词条列表。
        :param vector: 查询向量。
        :param top_k: 返回结果数量。
        :return: (文档标识, 分数) 列表。
        """
        with self._lock:
            return self._hybrid_index.query(terms, vector, top_k)

    def get_stats(self) -> Dict[str, Any]:
        """
        获取内存索引统计信息。

        :return: 统计字典。
        """
        with self._lock:
            return {
                "inverted_index": self._inverted_index.get_stats(),
                "vector_index": self._vector_index.get_stats(),
                "hybrid_index": self._hybrid_index.get_stats(),
                "config": dict(self._config),
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        将内存索引状态转换为字典。

        :return: 状态字典。
        """
        with self._lock:
            return {
                "inverted_index": self._inverted_index.to_dict(),
                "vector_index": self._vector_index.to_dict(),
                "hybrid_index": self._hybrid_index.to_dict(),
                "config": dict(self._config),
            }

    def export_state(self, filepath: str) -> None:
        """
        将内存索引状态导出到 JSON 文件。

        :param filepath: 目标文件路径。
        """
        data = self.to_dict()
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, default=str)
        logger.info("内存索引状态已导出到: %s", filepath)

    def import_state(self, filepath: str) -> bool:
        """
        从 JSON 文件导入内存索引状态。

        :param filepath: 源文件路径。
        :return: 若导入成功返回 True，否则返回 False。
        """
        if not os.path.exists(filepath):
            logger.warning("导入失败，文件不存在: %s", filepath)
            return False
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
        except json.JSONDecodeError as exc:
            logger.error("导入失败，JSON 解析错误: %s", exc, exc_info=True)
            return False
        # 实际导入逻辑需要根据子索引的导入能力扩展，此处保持接口兼容
        with self._lock:
            pass
        logger.info("内存索引状态已从 %s 导入", filepath)
        return True


# ----------------------------------------------------------------------
# 单例获取
# ----------------------------------------------------------------------
_default_memory_index: Optional[MemoryIndex] = None
_memory_index_lock = threading.Lock()


def get_memory_index() -> MemoryIndex:
    """
    获取默认的内存索引单例。

    :return: 默认的 MemoryIndex 实例。
    """
    global _default_memory_index
    with _memory_index_lock:
        if _default_memory_index is None:
            _default_memory_index = MemoryIndex()
            logger.info("默认内存索引已创建")
        return _default_memory_index


__all__ = [
    "IndexType",
    "IndexStatus",
    "VectorMetric",
    "IndexPrecision",
    "MemoryItem",
    "IndexEntry",
    "VectorRecord",
    "InvertedPosting",
    "VectorIndexStore",
    "InvertedIndexStore",
    "KeywordIndexStore",
    "SemanticIndexStore",
    "TemporalIndexStore",
    "GraphIndexStore",
    "CompositeIndexStore",
    "FieldIndexStore",
    "PrefixIndexStore",
    "FuzzyIndexStore",
    "IndexBuildManager",
    "IndexBaseManager",
    "IndexUpdateManager",
    "IndexMergeManager",
    "IndexCompressionManager",
    "IndexQueryManager",
    "VectorIndex",
    "InvertedIndex",
    "HybridIndex",
    "MemoryIndex",
    "get_memory_index",
    "__version__",
]
