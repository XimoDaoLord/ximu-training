"""内存索引拆分部分模块。

本模块提供了内存索引的拆分部分管理功能，支持对索引数据的分片存储与检索。
版本: 0.5
"""

import logging
from typing import Any, Dict

# 设置模块级日志记录器
logger = logging.getLogger(__name__)

__version__ = "0.5"
__all__ = ["MemoryIndexParts"]


class MemoryIndexParts:
    """
    内存索引拆分部分管理类。

    该类负责维护内存索引中各个拆分部分的存储、检索和移除操作。
    """

    def __init__(self) -> None:
        """
        初始化内存索引部分容器。

        创建一个空字典用于存储索引部分。
        """
        self._parts: Dict[str, Any] = {}
        logger.debug("MemoryIndexParts instance initialized.")

    def add_part(self, part_id: str, data: Any) -> None:
        """
        添加一个新的索引部分。

        :param part_id: 索引部分的唯一标识符。
        :param data: 要存储的数据对象。
        :raises ValueError: 当指定的 part_id 已存在时抛出。
        """
        if part_id in self._parts:
            raise ValueError(f"Part with id '{part_id}' already exists.")
        self._parts[part_id] = data
        logger.info(f"Added part '{part_id}' to memory index.")

    def get_part(self, part_id: str) -> Any:
        """
        获取指定 ID 的索引部分。

        :param part_id: 要检索的索引部分的唯一标识符。
        :return: 与 part_id 关联的数据对象。
        :raises KeyError: 当指定的 part_id 不存在时抛出。
        """
        if part_id not in self._parts:
            raise KeyError(f"Part with id '{part_id}' not found.")
        logger.debug(f"Retrieved part '{part_id}'.")
        return self._parts[part_id]

    def remove_part(self, part_id: str) -> None:
        """
        移除指定的索引部分。

        :param part_id: 要移除的索引部分的唯一标识符。
        :raises KeyError: 当指定的 part_id 不存在时抛出。
        """
        if part_id not in self._parts:
            raise KeyError(f"Part with id '{part_id}' not found.")
        del self._parts[part_id]
        logger.info(f"Removed part '{part_id}' from memory index.")

    def has_part(self, part_id: str) -> bool:
        """
        检查指定的索引部分是否存在。

        :param part_id: 要检查的索引部分的唯一标识符。
        :return: 如果存在则返回 True，否则返回 False。
        """
        exists = part_id in self._parts
        logger.debug(f"Checked existence of part '{part_id}': {exists}")
        return exists

    def get_all_parts(self) -> Dict[str, Any]:
        """
        获取所有索引部分的副本。

        :return: 包含所有部分 ID 和数据的字典副本。
        """
        logger.debug("Retrieved all parts.")
        return self._parts.copy()
