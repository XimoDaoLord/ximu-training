"""Part 2 of memory_association (lines 2767-3334 of 3334)."""
import logging
logger = logging.getLogger("src.ximu.core.memory._memory_association_parts.part2")
import os
import json
import threading
from typing import Any, Callable, Dict, List, Optional, Tuple
from collections import defaultdict, deque, Counter
from .part1 import AssociationDirection
from .part1 import AssociationLink
from .part1 import AssociationLinkStore
from .part1 import AssociationMiningManager
from .part1 import AssociationRule
from .part1 import AssociationStrength
from .part1 import AssociationType
from .part1 import CategoricalStore
from .part1 import CausalStore
from .part1 import EmotionalStore
from .part1 import FunctionalStore
from .part1 import InferencePath
from .part1 import InferencePathStore
from .part1 import InferenceType
from .part1 import MemoryItem
from .part1 import NetworkType
from .part1 import RuleStore
from .part1 import SemanticStore
from .part1 import SpatialStore
from .part1 import TemporalStore
from src.ximu.common.utils import generate_id
from src.ximu.common.utils import now_timestamp


class _BaseManagerMixin:
    """
    基础管理器混入类，提供通用的存储管理、事件系统、指标记录和状态维护功能。
    用于消除 NetworkBuilder、InferenceEngineManager 等类之间的重复代码。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化基础管理器。

        Args:
            **kwargs: 配置参数。
        """
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=500)
        self._initialized = False
        self._last_maintenance = 0.0
        self._maintenance_interval = 300.0

    def register_store(self, name: str, store_obj: Any) -> None:
        """
        注册一个存储对象。

        Args:
            name: 存储名称。
            store_obj: 存储实例。
        """
        with self._lock:
            self._stores[name] = store_obj
            self._emit("store_registered", {"name": name})
            logger.debug("存储 %s 已注册", name)

    def get_store(self, name: str) -> Optional[Any]:
        """
        获取指定名称的存储对象。

        Args:
            name: 存储名称。

        Returns:
            存储实例，如果不存在则返回 None。
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """
        移除指定名称的存储对象。

        Args:
            name: 存储名称。

        Returns:
            如果存储存在并被移除则返回 True，否则返回 False。
        """
        with self._lock:
            s = self._stores.pop(name, None)
            if s:
                self._emit("store_removed", {"name": name})
                logger.debug("存储 %s 已移除", name)
            return s is not None

    def on(self, event: str, handler: Callable) -> None:
        """
        注册事件处理器。

        Args:
            event: 事件名称。
            handler: 处理函数。
        """
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable) -> None:
        """
        注销事件处理器。

        Args:
            event: 事件名称。
            handler: 处理函数。
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Optional[Dict[str, Any]] = None) -> None:
        """
        触发事件。

        Args:
            event: 事件名称。
            data: 事件数据。
        """
        handlers = self._event_handlers.get(event, [])
        for h in handlers:
            try:
                h(data or {})
            except Exception as e:
                # 合理忽略：回调/可选操作失败不影响主流程
                logger.debug("操作失败: %s", e, exc_info=True)

    def record_metric(self, name: str, value: float) -> None:
        """
        记录指标值。

        Args:
            name: 指标名称。
            value: 指标增量。
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({
                "metric": name,
                "value": value,
                "timestamp": now_timestamp()
            })

    def get_metric(self, name: str) -> float:
        """
        获取指定指标的累计值。

        Args:
            name: 指标名称。

        Returns:
            指标值，默认 0.0。
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """
        获取所有指标。

        Returns:
            包含所有指标名称和值的字典。
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self) -> None:
        """重置所有指标。"""
        with self._lock:
            self._metrics.clear()
            logger.debug("指标已重置")

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取指标历史记录。

        Args:
            limit: 返回的最大记录数。

        Returns:
            历史记录列表。
        """
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """
        初始化管理器。

        Returns:
            如果成功初始化返回 True，否则返回 False。
        """
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._emit("initialized", {})
            logger.info("管理器已初始化")
            return True

    def shutdown(self) -> bool:
        """
        关闭管理器。

        Returns:
            如果成功关闭返回 True，否则返回 False。
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            self._emit("shutdown", {})
            logger.info("管理器已关闭")
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """
        执行维护任务。

        Args:
            force: 是否强制执行维护，忽略间隔时间。

        Returns:
            维护结果字典。
        """
        with self._lock:
            now = now_timestamp()
            if not force and now - self._last_maintenance < self._maintenance_interval:
                return {"status": "skipped"}
            cleaned = 0
            for name, s in self._stores.items():
                if hasattr(s, "cleanup_expired"):
                    try:
                        cleaned += s.cleanup_expired()
                    except Exception as e:
                        # 合理忽略：回调/可选操作失败不影响主流程
                        logger.debug("操作失败: %s", e, exc_info=True)
            self._last_maintenance = now
            self._emit("maintenance", {"cleaned": cleaned})
            logger.debug("维护完成，清理 %d 项", cleaned)
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息。

        Returns:
            包含初始化状态、存储统计、指标和历史记录的字典。
        """
        with self._lock:
            store_stats: Dict[str, Any] = {}
            for name, s in self._stores.items():
                if hasattr(s, "get_stats"):
                    try:
                        store_stats[name] = s.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(s, "size"):
                    store_stats[name] = {"size": s.size()}
            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history)
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        将管理器状态转换为字典。

        Returns:
            包含配置、指标和存储名称的字典。
        """
        with self._lock:
            return {
                "config": dict(self._config),
                "metrics": dict(self._metrics),
                "stores": list(self._stores.keys())
            }

    def export_state(self, filepath: str) -> None:
        """
        导出管理器状态到文件。

        Args:
            filepath: 目标文件路径。
        """
        with self._lock:
            state = self.to_dict()
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, default=str)
        logger.info("状态已导出至 %s", filepath)

    def import_state(self, filepath: str) -> bool:
        """
        从文件导入管理器状态。

        Args:
            filepath: 源文件路径。

        Returns:
            如果导入成功返回 True，否则返回 False。
        """
        if not os.path.exists(filepath):
            logger.warning("文件不存在: %s", filepath)
            return False
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        with self._lock:
            if "config" in data:
                self._config.update(data["config"])
            if "metrics" in data:
                self._metrics.update(data["metrics"])
        logger.info("状态已从 %s 导入", filepath)
        return True


class NetworkBuilder(_BaseManagerMixin):
    """
    网络构建器，负责管理关联网络中的各个存储组件。
    """

    pass


class InferenceEngineManager(_BaseManagerMixin):
    """
    推理引擎管理器，负责管理推理相关的存储组件。
    """

    pass


class AssociationPruningManager(_BaseManagerMixin):
    """
    关联剪枝管理器，负责管理关联剪枝相关的存储组件。
    """

    pass


class SpreadingActivationManager(_BaseManagerMixin):
    """
    扩散激活管理器，负责管理扩散激活相关的存储组件。
    """

    pass


class AssociationNetwork:
    """
    关联网络，管理记忆项之间的关联结构。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化关联网络。

        Args:
            **kwargs: 配置参数。
        """
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._nodes: Dict[str, MemoryItem] = {}
        self._edges: Dict[Tuple[str, str], List[AssociationLink]] = defaultdict(list)
        self._node_index: Dict[str, str] = {}
        self._stats: Dict[str, float] = defaultdict(float)

    def add_node(self, item: MemoryItem) -> None:
        """
        添加节点。

        Args:
            item: 记忆项。
        """
        with self._lock:
            if item.id not in self._nodes:
                self._nodes[item.id] = item
                self._node_index[item.id] = item.id
                self._stats["node_added"] += 1
                logger.debug("节点 %s 已添加", item.id)

    def add_edge(self, link: AssociationLink) -> None:
        """
        添加边。

        Args:
            link: 关联链接。
        """
        with self._lock:
            key = (link.source_id, link.target_id)
            self._edges[key].append(link)
            # 确保节点存在
            if link.source_id not in self._nodes:
                logger.warning("源节点 %s 不存在", link.source_id)
            if link.target_id not in self._nodes:
                logger.warning("目标节点 %s 不存在", link.target_id)
            self._stats["edge_added"] += 1
            logger.debug("边 %s -> %s 已添加", link.source_id, link.target_id)

    def get_neighbors(self, node_id: str, association_type: str = "", limit: int = 20) -> List[MemoryItem]:
        """
        获取邻居节点。

        Args:
            node_id: 节点ID。
            association_type: 关联类型过滤。
            limit: 最大返回数量。

        Returns:
            邻居节点列表。
        """
        with self._lock:
            neighbors = set()
            for (src, tgt), links in self._edges.items():
                if src == node_id or tgt == node_id:
                    for link in links:
                        if not association_type or link.association_type == association_type:
                            if src == node_id:
                                neighbors.add(tgt)
                            else:
                                neighbors.add(src)
            result = []
            for nid in list(neighbors)[:limit]:
                if nid in self._nodes:
                    result.append(self._nodes[nid])
            return result

    def spreading_activation(self, start_nodes: List[str], **kwargs: Any) -> Dict[str, float]:
        """
        执行扩散激活算法。

        Args:
            start_nodes: 起始节点ID列表。
            **kwargs: 其他参数。

        Returns:
            节点激活值字典。
        """
        with self._lock:
            activation: Dict[str, float] = {nid: 0.0 for nid in start_nodes}
            decay = kwargs.get("decay", 0.8)
            strength_threshold = kwargs.get("strength_threshold", 0.1)
            queue = deque(start_nodes)
            while queue:
                current = queue.popleft()
                for (src, tgt), links in self._edges.items():
                    if src == current:
                        for link in links:
                            if link.strength > strength_threshold:
                                new_val = activation[current] * link.strength * decay
                                old_val = activation.get(tgt, 0.0)
                                if new_val > old_val:
                                    activation[tgt] = new_val
                                    queue.append(tgt)
                    elif tgt == current:
                        for link in links:
                            if link.strength > strength_threshold:
                                new_val = activation[current] * link.strength * decay
                                old_val = activation.get(src, 0.0)
                                if new_val > old_val:
                                    activation[src] = new_val
                                    queue.append(src)
            logger.debug("扩散激活完成，共 %d 个节点被激活", len(activation))
            return activation

    def get_stats(self) -> Dict[str, Any]:
        """
        获取网络统计信息。

        Returns:
            统计信息字典。
        """
        with self._lock:
            return {
                "nodes": len(self._nodes),
                "edges": sum(len(v) for v in self._edges.values()),
                "metrics": dict(self._stats)
            }


class AssociationMiner:
    """
    关联挖掘器，负责从网络中发现规则。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化关联挖掘器。

        Args:
            **kwargs: 配置参数。
        """
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._stats: Dict[str, float] = defaultdict(float)

    def mine(self, network: AssociationNetwork) -> List[AssociationRule]:
        """
        从网络中挖掘规则。

        Args:
            network: 关联网络实例。

        Returns:
            发现的规则列表。
        """
        with self._lock:
            rules = []
            stats = network.get_stats()
            self._stats["mined_rules"] += 0
            logger.debug("开始挖掘规则，网络节点数: %d", stats.get("nodes", 0))
            return rules

    def get_stats(self) -> Dict[str, Any]:
        """
        获取挖掘器统计信息。

        Returns:
            统计信息字典。
        """
        with self._lock:
            return dict(self._stats)


class InferenceEngine:
    """
    推理引擎，基于网络进行推理。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化推理引擎。

        Args:
            **kwargs: 配置参数。
        """
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._stats: Dict[str, float] = defaultdict(float)

    def infer(self, context: Dict[str, Any], top_k: int = 10) -> List[InferencePath]:
        """
        执行推理。

        Args:
            context: 推理上下文。
            top_k: 返回的路径数量。

        Returns:
            推理路径列表。
        """
        with self._lock:
            self._stats["inferences"] += 1
            logger.debug("执行推理，top_k=%d", top_k)
            return []

    def get_stats(self) -> Dict[str, Any]:
        """
        获取推理引擎统计信息。

        Returns:
            统计信息字典。
        """
        with self._lock:
            return dict(self._stats)


class MemoryAssociation:
    """
    记忆关联主类，整合所有组件。
    """

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化记忆关联系统。

        Args:
            **kwargs: 配置参数。
        """
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self.link_store = AssociationLinkStore()
        self.rule_store = RuleStore()
        self.inference_path_store = InferencePathStore()
        self.causal_store = CausalStore()
        self.temporal_store = TemporalStore()
        self.semantic_store = SemanticStore()
        self.emotional_store = EmotionalStore()
        self.categorical_store = CategoricalStore()
        self.functional_store = FunctionalStore()
        self.spatial_store = SpatialStore()
        self.network = AssociationNetwork()
        self.miner = AssociationMiner()
        self.inference_engine = InferenceEngine()
        self.builtin_stores = {
            "causal": self.causal_store,
            "temporal": self.temporal_store,
            "semantic": self.semantic_store,
            "emotional": self.emotional_store,
            "categorical": self.categorical_store,
            "functional": self.functional_store,
            "spatial": self.spatial_store
        }

    def add_association(
        self,
        source_id: str,
        target_id: str,
        association_type: AssociationType,
        strength: float = 1.0,
        **kwargs: Any
    ) -> AssociationLink:
        """
        添加关联。

        Args:
            source_id: 源节点ID。
            target_id: 目标节点ID。
            association_type: 关联类型。
            strength: 关联强度。
            **kwargs: 其他参数。

        Returns:
            创建的关联链接对象。
        """
        link = AssociationLink(
            id=generate_id("al"),
            source_id=source_id,
            target_id=target_id,
            association_type=association_type,
            strength=strength,
            **kwargs
        )
        self.link_store.add(link)
        self.network.add_edge(link)
        store = self.builtin_stores.get(association_type.value if hasattr(association_type, 'value') else association_type)
        if store:
            store.add(link)
        logger.debug("关联 %s 已添加", link.id)
        return link

    def get_associations(self, node_id: str, association_type: str = "", limit: int = 20) -> List[MemoryItem]:
        """
        获取节点的关联。

        Args:
            node_id: 节点ID。
            association_type: 关联类型过滤。
            limit: 最大数量。

        Returns:
            关联节点列表。
        """
        return self.network.get_neighbors(node_id, association_type, limit)

    def infer(self, context: Dict[str, Any], top_k: int = 10) -> List[InferencePath]:
        """
        执行推理。

        Args:
            context: 推理上下文。
            top_k: 返回路径数。

        Returns:
            推理路径列表。
        """
        return self.inference_engine.infer(context, top_k)

    def spreading_activation(self, start_nodes: List[str], **kwargs: Any) -> Dict[str, float]:
        """
        执行扩散激活。

        Args:
            start_nodes: 起始节点。
            **kwargs: 其他参数。

        Returns:
            激活值字典。
        """
        return self.network.spreading_activation(start_nodes, **kwargs)

    def mine_rules(self) -> List[AssociationRule]:
        """
        挖掘规则。

        Returns:
            规则列表。
        """
        rules = self.miner.mine(self.network)
        for r in rules:
            self.rule_store.add(r)
        return rules

    def get_stats(self) -> Dict[str, Any]:
        """
        获取整体统计信息。

        Returns:
            统计信息字典。
        """
        return {
            "links": self.link_store.get_stats(),
            "rules": self.rule_store.get_stats(),
            "network": self.network.get_stats(),
            "miner": self.miner.get_stats()
        }


_default_asc: Optional[MemoryAssociation] = None
_asc_lock = threading.Lock()


def get_memory_association() -> MemoryAssociation:
    """
    获取全局记忆关联实例。

    Returns:
        全局 MemoryAssociation 实例。
    """
    global _default_asc
    with _asc_lock:
        if _default_asc is None:
            _default_asc = MemoryAssociation()
        return _default_asc


__all__ = [
    "AssociationType",
    "AssociationStrength",
    "AssociationDirection",
    "InferenceType",
    "NetworkType",
    "MemoryItem",
    "AssociationLink",
    "AssociationRule",
    "InferencePath",
    "AssociationLinkStore",
    "RuleStore",
    "InferencePathStore",
    "CausalStore",
    "TemporalStore",
    "SemanticStore",
    "EmotionalStore",
    "CategoricalStore",
    "FunctionalStore",
    "SpatialStore",
    "AssociationMiningManager",
    "NetworkBuilder",
    "InferenceEngineManager",
    "AssociationPruningManager",
    "SpreadingActivationManager",
    "AssociationNetwork",
    "AssociationMiner",
    "InferenceEngine",
    "MemoryAssociation",
    "get_memory_association"
]
