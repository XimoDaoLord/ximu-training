"""汐沫AI - 记忆关联系统枚举定义模块

本模块定义了记忆关联系统中使用的各类语义枚举，包括关联类型、关联强度、关联方向、推理类型和网络类型等。这些枚举为上层记忆网络、推理引擎和检索服务提供标准化的语义标识，并支持与外部系统的交互接口。
"""

import logging
from enum import Enum
from typing import Type, TypeVar, Any, Dict, Optional

_logger = logging.getLogger(__name__)

EnumType = TypeVar("EnumType", bound="BaseEnum")

class BaseEnum(str, Enum):
    """基础枚举类，提供通用方法供所有枚举继承。

    该类继承自str和Enum，确保枚举值为字符串，并提供from_value()工厂方法用于从字符串反查枚举实例，
    以及获取枚举值列表的便捷方法。支持序列化和反序列化操作，便于与外部系统进行数据交换。
    """

    def to_dict(self) -> Dict[str, Any]:
        """将枚举实例转换为字典格式，便于JSON序列化。

        Returns:
            包含'value'和'name'键的字典。
        """
        return {"value": self.value, "name": self.name}

    @classmethod
    def from_dict(cls: Type[EnumType], data: Dict[str, Any]) -> Optional[EnumType]:
        """从字典格式反查枚举实例。

        Args:
            data: 包含'value'或'name'键的字典

        Returns:
            对应的枚举实例或None（当未找到匹配项时）

        Raises:
            ValueError: 当数据无法映射到任何枚举成员时
        """
        if not isinstance(data, dict):
            _logger.error("Expected dict, got %s", type(data).__name__)
            raise ValueError(f"Expected dict, got {type(data).__name__}")

        value = data.get("value") or data.get("name")
        if not value:
            _logger.error("Missing 'value' or 'name' in data: %s", data)
            raise ValueError("Data must contain 'value' or 'name'")

        try:
            return cls(value)
        except ValueError:
            _logger.error("Invalid value '%s' for enum %s", value, cls.__name__)
            raise

    @classmethod
    def from_value(cls: Type[EnumType], value: str) -> Optional[EnumType]:
        """从字符串值反查枚举实例。

        Args:
            value: 字符串形式的枚举值，用于匹配枚举成员

        Returns:
            对应的枚举实例或None（当未找到匹配项时）

        Raises:
            ValueError: 当值无法映射到任何枚举成员时
        """
        try:
            return cls(value)
        except ValueError:
            _logger.error("Invalid value '%s' for enum %s", value, cls.__name__)
            raise

    @classmethod
    def get_values(cls: Type[EnumType]) -> list[str]:
        """获取所有枚举成员的字符串值列表。

        Returns:
            枚举值列表，按成员定义顺序排列
        """
        return [member.value for member in cls]

    @classmethod
    def get_names(cls: Type[EnumType]) -> list[str]:
        """获取所有枚举成员的名称列表。

        Returns:
            枚举名称列表，按成员定义顺序排列
        """
        return [member.name for member in cls]

    @classmethod
    def contains(cls: Type[EnumType], value: str) -> bool:
        """检查指定值是否存在于枚举中。

        Args:
            value: 待检查的字符串值

        Returns:
            如果值存在于枚举中则返回True，否则返回False
        """
        return value in {member.value for member in cls}


class AssociationType(BaseEnum):
    """关联类型枚举：描述两条记忆之间的语义关系类别。

    该枚举定义了记忆条目之间可能存在的九种基本语义关联类型（含未知类型），
    用于刻画记忆网络中边的语义性质。
    """

    CAUSAL = "causal"
    TEMPORAL = "temporal"
    SPATIAL = "spatial"
    SEMANTIC = "semantic"
    EMOTIONAL = "emotional"
    PROCEDURAL = "procedural"
    CATEGORICAL = "categorical"
    FUNCTIONAL = "functional"
    UNKNOWN = "unknown"

    @classmethod
    def __missing__(cls, value):
        raise ValueError(f"Unknown association type: {value}")


class AssociationStrength(BaseEnum):
    """关联强度枚举：对关联强弱的分级描述。

    定义了六个级别的关联强度（含未分级），从非常弱到非常强，
    用于量化记忆条目之间关联的紧密程度。强度级别便于记忆检索和排序操作。
    """

    VERY_WEAK = "very_weak"
    WEAK = "weak"
    MODERATE = "moderate"
    STRONG = "strong"
    VERY_STRONG = "very_strong"
    UNKNOWN = "unknown"

    @classmethod
    def __missing__(cls, value):
        raise ValueError(f"Unknown strength level: {value}")


class AssociationDirection(BaseEnum):
    """关联方向枚举：描述关联边的方向性。

    定义了五种基本方向模式：正向、反向、双向、无向和未知，
    用于表示记忆关联是有向还是无向关系。方向信息有助于记忆网络的遍历和推理。
    """

    FORWARD = "forward"
    BACKWARD = "backward"
    BIDIRECTIONAL = "bidirectional"
    UNDIRECTED = "undirected"
    UNKNOWN = "unknown"

    @classmethod
    def __missing__(cls, value):
        raise ValueError(f"Unknown direction: {value}")


class InferenceType(BaseEnum):
    """推理类型枚举：描述推理路径所依循的逻辑形式。

    定义了六种推理类型：演绎推理、归纳推理、溯因推理、类比推理、
    因果推理和未知推理，用于分类不同的记忆推理过程。
    推理类型与AssociationType存在映射关系，例如演绎推理可能涉及因果关联。
    """

    DEDUCTIVE = "deductive"
    INDUCTIVE = "inductive"
    ABDUCTIVE = "abductive"
    ANALOGICAL = "analogical"
    CAUSAL = "causal"
    UNKNOWN = "unknown"

    @classmethod
    def __missing__(cls, value):
        raise ValueError(f"Unknown inference type: {value}")


class NetworkType(BaseEnum):
    """网络类型枚举：描述关联网络所建模的记忆子系统。

    定义了六种记忆网络类型：联想网络、语义网络、情节网络、
    程序网络、情感网络和未知网络，用于区分不同性质的记忆系统。
    网络类型与AssociationType、InferenceType相互关联，共同构建记忆模型。
    """

    ASSOCIATIVE = "associative"
    SEMANTIC = "semantic"
    EPISODIC = "episodic"
    PROCEDURAL = "procedural"
    EMOTIONAL = "emotional"
    UNKNOWN = "unknown"

    @classmethod
    def __missing__(cls, value):
        raise ValueError(f"Unknown network type: {value}")


# ===== 自动补全的Store类 =====

class AssociationLink:
    """AssociationLink 数据存储。"""
    def __init__(self):
        self._data = {}
        self._order = []

    def add(self, key, value):
        self._data[key] = value
        self._order.append(key)

    def get(self, key, default=None):
        return self._data.get(key, default)

    def remove(self, key):
        self._data.pop(key, None)
        if key in self._order:
            self._order.remove(key)

    def keys(self):
        return list(self._order)

    def __len__(self):
        return len(self._data)


class AssociationLinkStore:
    """AssociationLinkStore。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class AssociationMiningManager:
    """AssociationMiningManager。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class AssociationRule:
    """AssociationRule - 关联规则。"""
    def __init__(self, antecedent=None, consequent=None, confidence=0.0, support=0.0):
        self.antecedent = antecedent
        self.consequent = consequent
        self.confidence = confidence
        self.support = support


class MemoryItem:
    """MemoryItem - 记忆项。"""
    def __init__(self, item_id=None, content=None, item_type=None, metadata=None):
        self.item_id = item_id
        self.content = content
        self.item_type = item_type
        self.metadata = metadata or {}


class InferencePath:
    """InferencePath - 推理路径。"""
    def __init__(self, path_id=None, nodes=None, edges=None, confidence=0.0):
        self.path_id = path_id
        self.nodes = nodes or []
        self.edges = edges or []
        self.confidence = confidence


class CategoricalStore:
    """CategoricalStore - 分类存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class CausalStore:
    """CausalStore - 因果存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class EmotionalStore:
    """EmotionalStore - 情感存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class FunctionalStore:
    """FunctionalStore - 功能存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class InferencePathStore:
    """InferencePathStore - 推理路径存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class RuleStore:
    """RuleStore - 规则存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class SemanticStore:
    """SemanticStore - 语义存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class SpatialStore:
    """SpatialStore - 空间存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)


class TemporalStore:
    """TemporalStore - 时间存储。"""
    def __init__(self):
        self._data = {}

    def add(self, key, value):
        self._data[key] = value

    def get(self, key, default=None):
        return self._data.get(key, default)

    def all(self):
        return dict(self._data)
