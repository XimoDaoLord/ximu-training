"""
Split parts of memory_association.
"""

from typing import Any

class MemoryAssociationParts:
    """
    MemoryAssociationParts类用于分割内存关联部分。
    """
    
    def __init__(self) -> None:
        """
        初始化MemoryAssociationParts实例。
        """
        pass
    
    def split_memory_parts(self, memory_data: str) -> list[str]:
        """
        将内存数据分割成多个部分。

        :param memory_data: 字符串形式的内存数据
        :return: 分割后的内存部分列表
        """
        parts = memory_data.split(',')
        return parts
