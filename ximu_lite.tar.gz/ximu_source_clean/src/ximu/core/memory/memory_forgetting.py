"""
内存遗忘模块入口点，提供内存遗忘功能的重导出能力。
"""
import importlib as _il
import logging as _logging
from typing import Optional


def _reexport_module(module_name: str) -> Optional[bool]:
    """
    尝试导入指定模块，并将模块中的非私有成员导出到当前命名空间。

    Args:
        module_name: 模块名称，格式为 '._memory_forgetting_parts.part1'。

    Returns:
        导入成功返回 True，否则返回 False。
    """
    try:
        module = _il.import_module(module_name, package=__package__)
        for attr_name in dir(module):
            if not attr_name.startswith("_"):
                globals()[attr_name] = getattr(module, attr_name)
        return True
    except Exception as e:
        _logging.warning(f"Re-export {module_name} failed: {e}")
        return False


def reexport_memory_forgetting() -> None:
    """
    重导出内存遗忘模块中的功能。
    """
    for part in ["part1", "part2"]:
        module_name = f"._memory_forgetting_parts.{part}"
        _reexport_module(module_name)