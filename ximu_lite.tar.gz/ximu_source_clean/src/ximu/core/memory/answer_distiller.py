# -*- coding: utf-8 -*-
"""P91: AI 回答提炼为 semantic 长期记忆。

在 AI 完整回复保存后，从回复中提取可复用知识命题（定义/结论/事实），
去除问答口语和过程噪声，作为 semantic 类型记忆写入记忆引擎。

设计原则：
- 规则提炼为主（零成本、零延迟、确定性）
- 可选免费小模型提炼（仅长回复且规则效果差时，5s 超时，失败回退规则）
- 保守门槛：空/太短/过程噪声 → 不写入
- 去重与上限沿用 P58（memory_engine.add_memory 内部已处理 bigram≥0.85 去重、500 条上限）
"""

from __future__ import annotations

import re
import logging
from typing import List

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 噪声过滤：问候/客套/过程性语句——不构成可复用知识命题
# ---------------------------------------------------------------------------
_NOISE_PHRASES = (
    "好的", "好的，", "好的。", "没问题", "让我", "我来", "我来帮你",
    "希望这", "希望对你", "对你有帮助", "以上就是", "以上是", "总结一下",
    "总之", "简而言之", "首先", "其次", "最后", "接下来", "您好", "你好",
    "谢谢", "不客气", "已完成", "完成了", "子任务", "步骤", "正在",
    "请稍等", "请等待", "稍等", "我理解了", "明白了", "收到",
    "根据你的问题", "针对你的问题", "关于你的问题", "以下是",
    "以下回答", "下面是", "我们来", "我们现在", "现在我",
    "这是", "这就是", "这就是说", "也就是说",
    "有什么可以", "可以帮你", "有什么能", "我能帮你",
    "推荐你", "建议你", "你可以试试", "不妨试试",
    # 过程性标记
    "任务完成", "执行完成", "处理完成", "已处理", "已保存",
    "缓存命中", "模型调用", "工具调用", "审查通过",
)

# 定义句式：包含这些标记的句子更可能是可复用知识
_DEFINITION_MARKERS = (
    "是指", "指的是", "定义为", "定义是", "就是指",
    "：", ":",  # "递归：..." 这种冒号定义
)

# 纯口语/无信息句子的正则
_PURE_CHAT_RE = re.compile(
    r"^(好的|嗯|啊|哦|对的|是的|可以|行|没问题|当然|你好|您好|谢谢|不客气|"
    r"已完成|完成了|收到|明白|了解|懂了|是的|对|没错|正是)[，。！!？?\s]*$"
)

# Markdown 代码块/标题/列表符号清理
_MD_HEADER_RE = re.compile(r"^#{1,6}\s*")
_MD_CODE_FENCE_RE = re.compile(r"```.*?```", re.DOTALL)
_MD_BOLD_RE = re.compile(r"\*\*(.+?)\*\*")
_MD_ITALIC_RE = re.compile(r"\*(.+?)\*")
_NUMBERED_ITEM_RE = re.compile(r"^\s*(?:\d+[.、)]|[-*•])\s*")


def _split_sentences(text: str) -> List[str]:
    """按中英文句末标点切分句子。"""
    if not text:
        return []
    # 统一换行
    text = text.replace("\r", "\n")
    # 按句末标点切分（保留标点在句子末尾）
    parts = re.split(r"(?<=[。！？!?；;])\s*", text)
    # 再按换行切分（每行可能是列表项）
    result: List[str] = []
    for p in parts:
        for line in p.split("\n"):
            line = line.strip()
            if line:
                result.append(line)
    return result


def _clean_sentence(s: str) -> str:
    """清理单句：去 markdown 符号、首尾空白。"""
    s = s.strip()
    # 去代码块
    s = _MD_CODE_FENCE_RE.sub("", s)
    # 去标题符号
    s = _MD_HEADER_RE.sub("", s)
    # 去列表编号
    s = _NUMBERED_ITEM_RE.sub("", s)
    # 去粗体/斜体标记
    s = _MD_BOLD_RE.sub(r"\1", s)
    s = _MD_ITALIC_RE.sub(r"\1", s)
    # 去首尾标点空白
    s = s.strip().strip("。.！!？?；;，, \n\t")
    return s


def _is_noise(s: str) -> bool:
    """判断一句话是否为过程噪声/口语，不值得沉淀为 semantic。"""
    if not s:
        return True
    if len(s) < 5:
        return True
    if len(s) > 200:
        return True
    # 纯口语短句
    if _PURE_CHAT_RE.match(s):
        return True
    # 开头是噪声短语
    for ph in _NOISE_PHRASES:
        if s.startswith(ph):
            return True
    # 纯标点/符号
    if not re.search(r"[\u4e00-\u9fff a-zA-Z0-9]", s):
        return True
    return False


def _is_definition(s: str) -> bool:
    """判断一句话是否像定义/结论（有"X是Y"、"X指Y"、冒号定义等结构）。"""
    if _is_noise(s):
        return False
    # 包含定义标记
    for marker in _DEFINITION_MARKERS:
        if marker in s:
            return True
    # 包含"X是Y"结构（短定义句）
    if "是" in s and len(s) <= 80:
        # 排除"这是""那是"等纯指代
        if not s.startswith(("这是", "那是", "那就是", "这就是")):
            return True
    return False


def _truncate(s: str, max_len: int = 80) -> str:
    """截断过长命题，保留完整语义单元。"""
    if len(s) <= max_len:
        return s
    # 尝试在逗号/分号处截断
    for sep in ["，", "；", ",", ";", "。", " "]:
        idx = s.find(sep, 20, max_len + 20)
        if 20 <= idx <= max_len:
            return s[:idx]
    return s[:max_len].rstrip("，,；;。.、 ")


def distill_answer(reply: str, topic_hint: str = "") -> List[str]:
    """从 AI 回复中提炼可复用知识命题（规则版）。

    返回值：命题列表，每条 <=80 字，已去噪、去重（句级）。
    若回复无值得沉淀的内容，返回空列表。
    """
    if not reply or not reply.strip():
        return []

    raw = reply.strip()
    # 清理代码块整块（代码示例不作为知识命题）
    raw_no_code = _MD_CODE_FENCE_RE.sub("", raw)

    sentences = _split_sentences(raw_no_code)
    propositions: List[str] = []
    seen: set = set()

    for sent in sentences:
        cleaned = _clean_sentence(sent)
        if not cleaned or len(cleaned) < 5:
            continue
        if _is_noise(cleaned):
            continue
        # 优先保留定义句
        if _is_definition(cleaned):
            prop = _truncate(cleaned)
            if prop and prop not in seen:
                seen.add(prop)
                propositions.append(prop)

    # 保守策略：只有明确的定义句才沉淀。
    # 短回复但无定义标记（闲聊/推荐/问候）→ 不沉淀，避免膨胀。
    # 最多保留 3 条
    return propositions[:3]


def distill_answer_with_model(reply: str, model: str = None) -> List[str]:
    """用项目统一 live_model_gateway 提炼知识命题（15s 超时，自动故障转移）。

    走 chat() 统一通道：自动选择可用供应商、多 key tier 故障转移、
    smart_cache 结果缓存、P41 已知坏模型预检跳过。失败回退规则提炼。
    """
    try:
        from src.ximu.core.live_model_gateway import chat as _gw_chat
        prompt = (
            "把以下AI回答提炼成1-3条可复用知识命题，每条不超过30字，"
            "去掉口语、客套和过程描述，只保留结论/定义/事实：\n\n"
            f"回答：{reply[:800]}\n\n命题（每行一条）："
        )
        result = _gw_chat(prompt, model=model, timeout=15.0, skip_inject=True)
        if not result.get("ok"):
            return distill_answer(reply)
        text = (result.get("content") or "").strip()
        if not text:
            return distill_answer(reply)
        results = []
        for line in text.split("\n"):
            line = re.sub(r"^\s*\d+[.、)]\s*", "", line).strip("。.！!？?；;，, ")
            if line and len(line) >= 5 and not _is_noise(line):
                results.append(_truncate(line, 60))
        if results:
            return results[:3]
        return distill_answer(reply)
    except Exception as e:
        logger.debug("模型提炼失败，回退规则提炼: %s", e)
        return distill_answer(reply)


def distill_and_store_semantic(reply: str, topic_id: str = "",
                               tags: list = None) -> List[str]:
    """P91 主入口：提炼 AI 回复并写入 semantic 记忆。

    - 调用规则提炼（或可选模型提炼）
    - 与已有记忆去重（memory_engine 内部 P58 已处理 bigram≥0.85）
    - 失败不抛异常，不阻断主流程
    - 返回实际写入的命题列表（空列表表示未写入）

    P101：提炼出的 semantic 结论额外走 trainability_filter.route_record()
    分流到干净数据/知识结论 或 废弃数据/记录：
    - 可训练的 AI 知识结论落干净数据（mask_pii 二次脱敏 + audit.jsonl）
    - 不可训练的（含 PII/敏感/低质/恶意）落废弃数据并记录判定原因
    - semantic 记忆仍写入用户数据记忆库（long_term.json），跨话题召回不受影响
    """
    try:
        props = distill_answer(reply)
        if not props:
            logger.debug("[P91] 未提炼到有价值命题，跳过 semantic 写入")
            return []

        from src.ximu.core.memory.memory_engine import get_memory_engine
        eng = get_memory_engine()
        written = []
        for prop in props:
            try:
                mid = eng.add_memory(
                    content=prop,
                    memory_type="semantic",
                    importance=0.7,
                    tags=list(tags or ["chat", "ai_answer"]),
                    origin="answer",
                )
                if mid:
                    written.append(prop)
                    logger.info("[P91] semantic 沉淀: %s", prop[:50])
            except Exception as e:
                logger.debug("[P91] 单条 semantic 写入失败（惰性）: %s", e)
        # 写入后立即刷盘（关键节点，与用户消息写入一致）
        if written:
            try:
                eng.flush_now("p91_answer_distill")
            except Exception:
                pass

        # P101/P130：semantic 结论走统一入口 ingest（准入→预处理→过滤提纯→精华→
        # 可训练分流→统一审计）。可训练 → 干净数据/知识结论；不可训练 → 废弃数据/记录。
        if written:
            try:
                from src.ximu.core.transit.ingest import ingest as _ximu_ingest
                for prop in written:
                    try:
                        _ximu_ingest(
                            prop,
                            source="model_output",
                            category="knowledge_conclusion",
                            route_to_clean=True,
                            source_path="answer_distiller.distill_and_store_semantic",
                        )
                    except Exception:
                        pass  # 单条分流失败不影响其他条
            except Exception as _e:
                logger.debug("[P101] semantic 结论分流到干净数据失败（惰性）: %s", _e)

        return written
    except Exception as e:
        logger.debug("[P91] 回答提炼整体失败（惰性，非致命）: %s", e)
        return []
