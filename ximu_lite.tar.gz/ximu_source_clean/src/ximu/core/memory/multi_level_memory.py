import json
import time
import math
import os
import re
import uuid
import threading
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Set, Any, Union
from dataclasses import dataclass, field
from enum import Enum
import logging

logger = logging.getLogger("src.ximu.core.memory.multi_level_memory")


class MemoryLevel(Enum):
    """
    记忆层级枚举。
    """
    L0_WORKING = "L0_working"
    L1_SHORT = "L1_short"
    L2_LONG = "L2_long"
    L3_SEMANTIC = "L3_semantic"


@dataclass
class MemoryItem:
    """
    记忆条目数据结构，包含内容、层级、重要性、时间戳及关联信息。
    """
    id: str
    content: str
    level: MemoryLevel
    importance: float
    timestamp: float
    access_count: int = 0
    last_accessed: float = 0
    associations: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    context: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """
        将记忆条目转换为字典格式。

        :return: 包含记忆所有字段的字典。
        """
        return {
            "id": self.id,
            "content": self.content,
            "level": self.level.value,
            "importance": self.importance,
            "timestamp": self.timestamp,
            "access_count": self.access_count,
            "last_accessed": self.last_accessed,
            "associations": self.associations,
            "tags": self.tags,
            "context": self.context
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MemoryItem":
        """
        从字典构建记忆条目。

        :param data: 包含记忆字段的字典。
        :return: 构建好的 MemoryItem 实例。
        :raises KeyError: 缺少必需键时抛出。
        """
        required_keys = ["id", "content", "level", "importance", "timestamp"]
        for key in required_keys:
            if key not in data:
                raise KeyError(f"Missing required key: {key}")

        return cls(
            id=data["id"],
            content=data["content"],
            level=MemoryLevel(data["level"]),
            importance=float(data["importance"]),
            timestamp=float(data["timestamp"]),
            access_count=int(data.get("access_count", 0)),
            last_accessed=float(data.get("last_accessed", 0)),
            associations=list(data.get("associations", [])),
            tags=list(data.get("tags", [])),
            context=str(data.get("context", ""))
        )


class MultiLevelMemoryService:
    """
    多层级记忆服务，提供记忆的添加、检索、持久化和关联分析功能。
    支持 L0-L3 四个层级，具备遗忘曲线模拟和并发安全机制。
    """

    LEVEL_LIMITS: Dict[MemoryLevel, int] = {
        MemoryLevel.L0_WORKING: 50,
        MemoryLevel.L1_SHORT: 200,
        MemoryLevel.L2_LONG: 10000,
        MemoryLevel.L3_SEMANTIC: 5000
    }

    FORGETTING_CURVE: Dict[MemoryLevel, Dict[str, float]] = {
        MemoryLevel.L0_WORKING: {"half_life": 300.0},
        MemoryLevel.L1_SHORT: {"half_life": 3600.0},
        MemoryLevel.L2_LONG: {"half_life": 86400.0},
        MemoryLevel.L3_SEMANTIC: {"half_life": 604800.0}
    }

    _LEVEL_FILE_NAMES: Dict[MemoryLevel, str] = {
        MemoryLevel.L0_WORKING: "working.json",
        MemoryLevel.L1_SHORT: "short.json",
        MemoryLevel.L2_LONG: "long.json",
        MemoryLevel.L3_SEMANTIC: "semantic.json"
    }

    _RE_ASCII_WORD = re.compile(r"[a-z0-9]+")
    _RE_CJK_RUN = re.compile(r"[\u4e00-\u9fff]")

    def __init__(self, base_dir: Path) -> None:
        """
        初始化多层级记忆服务。

        :param base_dir: 记忆数据存储的基础目录。
        """
        self.base_dir: Path = base_dir
        self.memories: Dict[str, MemoryItem] = {}
        self.index_by_level: Dict[MemoryLevel, List[str]] = {
            level: [] for level in MemoryLevel
        }
        self.index_by_tag: Dict[str, List[str]] = {}
        self.index_by_time: List[Tuple[float, str]] = []
        self._lock = threading.RLock()

        self._load_memories()
        self._build_indexes()

    def _get_memory_file_path(self, level: MemoryLevel) -> Path:
        """
        获取指定层级记忆文件的完整路径。

        :param level: 记忆层级。
        :return: 记忆文件路径。
        """
        filename = self._LEVEL_FILE_NAMES[level]
        return self.base_dir / "memory" / level.name / filename

    def _load_memories(self) -> None:
        """
        从磁盘加载所有层级的记忆文件到内存。
        跳过损坏的条目并记录警告日志。
        """
        for level in MemoryLevel:
            file_path = self._get_memory_file_path(level)
            if not file_path.exists():
                continue

            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for item_data in data.get("memories", []):
                        try:
                            item = MemoryItem.from_dict(item_data)
                        except (KeyError, ValueError, TypeError) as ve:
                            logger.warning("跳过损坏的记忆条目(%s): %s", level.value, ve)
                            continue

                        if item.id in self.memories:
                            continue

                        self.memories[item.id] = item
                        self.index_by_level[level].append(item.id)
            except Exception as e:
                logger.warning("加载%s记忆失败: %s", level.value, e)

    def _build_indexes(self) -> None:
        """
        重建标签索引和时间索引。
        用于加速检索和关联查找。
        """
        self.index_by_tag = {}
        self.index_by_time = []

        for memory in self.memories.values():
            for tag in memory.tags:
                if tag not in self.index_by_tag:
                    self.index_by_tag[tag] = []
                self.index_by_tag[tag].append(memory.id)

            self.index_by_time.append((memory.timestamp, memory.id))

        self.index_by_time.sort(key=lambda x: -x[0])

    def _save_memories(self, level: MemoryLevel) -> None:
        """
        原子化保存指定层级的记忆到磁盘。
        先写入临时文件再替换，防止进程崩溃导致 JSON 截断。

        :param level: 需要保存的记忆层级。
        :raises OSError: 文件操作失败时抛出。
        """
        file_path = self._get_memory_file_path(level)
        file_path.parent.mkdir(parents=True, exist_ok=True)

        level_memories = [
            self.memories[mid].to_dict()
            for mid in self.index_by_level[level]
            if mid in self.memories
        ]

        data = {
            "memories": level_memories,
            "count": len(level_memories),
            "updated_at": time.time()
        }

        tmp_path = file_path.with_name(file_path.name + ".tmp")
        try:
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, file_path)
        except OSError as e:
            logger.error("保存%s记忆失败: %s", level.value, e)
            if tmp_path.exists():
                try:
                    tmp_path.unlink()
                except OSError:
                    pass
            raise

    def add_memory(self, 
                   content: str, 
                   level: MemoryLevel = MemoryLevel.L2_LONG,
                   importance: float = 0.5,
                   tags: Optional[List[str]] = None,
                   context: str = "") -> str:
        """
        添加新的记忆条目。

        :param content: 记忆内容。
        :param level: 记忆层级，默认为 L2。
        :param importance: 重要性评分 (0-1)。
        :param tags: 标签列表。
        :param context: 上下文信息。
        :return: 新创建的记忆 ID。
        :raises TypeError: 如果 level 不是 MemoryLevel 枚举。
        """
        if not isinstance(level, MemoryLevel):
            raise TypeError(
                f"level 必须是 MemoryLevel 枚举，收到 {type(level)}"
            )

        mem_id = str(uuid.uuid4())
        item = MemoryItem(
            id=mem_id,
            content=content,
            level=level,
            importance=importance,
            timestamp=time.time(),
            tags=tags or [],
            context=context
        )

        with self._lock:
            self.memories[mem_id] = item
            self.index_by_level[level].append(mem_id)
            for tag in item.tags:
                if tag not in self.index_by_tag:
                    self.index_by_tag[tag] = []
                self.index_by_tag[tag].append(mem_id)
            self.index_by_time.append((item.timestamp, mem_id))
            self.index_by_time.sort(key=lambda x: -x[0])

        self._save_memories(level)
        return mem_id
