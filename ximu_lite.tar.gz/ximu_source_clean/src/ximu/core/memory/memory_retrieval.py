"""
Re-export hub for memory_retrieval (split into 2 parts, original 3336 lines).
"""

import warnings as _w
_w.warn("memory_retrieval has been split, import from specific part", DeprecationWarning, stacklevel=2)

import importlib as _il
import logging as _logging

def _import_module(module_name):
    """Import a module safely and return it."""
    try:
        module = _il.import_module(f"._memory_retrieval_parts.{module_name}", package=__package__)
        return module
    except Exception as _e:
        _logging.warning(f"Re-export {__name__}.{module_name} failed: {_e}")
        return None

def _reexport_module(module_name):
    """Re-export the specified module's attributes that do not start with an underscore."""
    module = _import_module(module_name)
    if module is not None:
        for attr_name in dir(module):
            if not attr_name.startswith("_"):
                globals()[attr_name] = getattr(module, attr_name)

def reexport_memory_retrieval_parts():
    """Re-export all attributes from the memory_retrieval parts."""
    for part in ['part1', 'part2']:
        _reexport_module(part)
