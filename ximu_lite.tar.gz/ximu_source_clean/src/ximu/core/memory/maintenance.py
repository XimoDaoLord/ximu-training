import asyncio
import json
import logging
import sqlite3
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .memory_engine import (
    get_memory_engine,
    SHORT_TERM,
    MID_TERM,
    LONG_TERM,
    SEMANTIC,
    PROCEDURAL,
    MemoryEngine,
)

logger = logging.getLogger("src.ximu.core.memory.maintenance")

_INTERVAL_REFLECT_SEC = 3600
_INTERVAL_MERGE_SEC = 7200
_INTERVAL_FORGET_SEC = 86400
_INTERVAL_EXTRACT_SEC = 3600

_MERGE_LOOKBACK_SEC = 86400
_FORGET_IMPORTANCE_THRESHOLD = 0.15
_FORGET_MAX_AGE_DAYS = 30
_EXTRACT_IMPORTANCE_MIN = 0.7
_EXTRACT_BATCH_LIMIT = 20
_REFLECT_IMPORTANCE = 0.6
_PROFILE_UPDATE_IMPORTANCE = 0.9

_STRUCTURABLE_KEYWORDS: Tuple[str, ...] = ("知道", "学习", "掌握", "了解")


class MemoryMaintenanceTask:
    """
    记忆系统维护任务。

    提供反思、融合、遗忘、知识提取四类周期性维护操作，
    每次调用均检查是否满足最小运行间隔，避免无效高频执行。
    """

    def __init__(self) -> None:
        """
        初始化维护任务。
        """
        self.engine: MemoryEngine = get_memory_engine()
        self.last_run: Dict[str, float] = {
            "reflect": 0.0,
            "merge": 0.0,
            "forget": 0.0,
            "extract": 0.0,
        }

    def _should_run(self, task_key: str, interval_sec: int) -> bool:
        """
        检查指定任务是否满足最小运行间隔。

        :param task_key: 任务标识。
        :param interval_sec: 最小运行间隔（秒）。
        :return: 是否满足间隔。
        """
        now = time.time()
        if now - self.last_run[task_key] < interval_sec:
            logger.debug("%s 任务未达到最小间隔，跳过", task_key)
            return False
        return True

    def _mark_run(self, task_key: str) -> None:
        """
        标记指定任务已执行。

        :param task_key: 任务标识。
        """
        self.last_run[task_key] = time.time()

    async def run_all(self) -> None:
        """
        并发运行全部维护任务。
        """
        logger.info("开始记忆系统维护 (时间: %s)", datetime.now().strftime("%H:%M:%S"))

        try:
            await asyncio.gather(
                self.reflect(),
                self.merge_similar(),
                self.forget_unimportant(),
                self.extract_knowledge(),
            )
        except Exception as exc:
            logger.error("记忆维护任务执行失败: %s", exc, exc_info=True)
            raise
        finally:
            logger.info("维护任务完成")

    async def reflect(self) -> None:
        """
        自我反思任务。
        """
        if not self._should_run("reflect", _INTERVAL_REFLECT_SEC):
            return

        logger.info("执行自我反思...")
        try:
            reflections = self.engine.reflect()
        except Exception as exc:
            logger.error("自我反思执行失败: %s", exc, exc_info=True)
            self._mark_run("reflect")
            return

        if reflections:
            for r in reflections:
                r_type: str = r.get("type", "unknown")
                r_keyword: str = r.get("keyword", "")
                logger.info("洞察: %s - %s", r_type, r_keyword)
                try:
                    self.engine.save_memory(
                        content=f"从反思中发现: {json.dumps(r, ensure_ascii=False)}",
                        memory_type=PROCEDURAL,
                        level=MID_TERM,
                        importance=_REFLECT_IMPORTANCE,
                    )
                except Exception as exc:
                    logger.error("保存反思记忆失败: %s", exc, exc_info=True)

        self._mark_run("reflect")
        logger.info("完成 %d 条反思", len(reflections))

    async def merge_similar(self) -> None:
        """
        记忆融合任务。
        """
        if not self._should_run("merge", _INTERVAL_MERGE_SEC):
            return

        logger.info("执行记忆融合...")
        query_sql = """
            SELECT memory_type, id, content, timestamp
            FROM memories
            WHERE timestamp > ? AND level = ?
            ORDER BY timestamp DESC
        """
        params: Tuple[float, str] = (time.time() - _MERGE_LOOKBACK_SEC, SHORT_TERM)

        try:
            with sqlite3.connect(self.engine.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute(query_sql, params)
                recent: List[Tuple[str, int, str, float]] = cursor.fetchall()
        except sqlite3.Error as exc:
            logger.error("查询短时记忆失败: %s", exc, exc_info=True)
            self._mark_run("merge")
            return
        except Exception as exc:
            logger.error("打开数据库失败: %s", exc, exc_info=True)
            self._mark_run("merge")
            return

        merged_count = 0
        for i in range(len(recent)):
            for j in range(i + 1, len(recent)):
                if recent[i][0] != recent[j][0]:
                    continue
                try:
                    self.engine.merge_memories([recent[i][1], recent[j][1]])
                    merged_count += 1
                except Exception as exc:
                    logger.error("合并相似记忆失败，中止本次合并: %s", exc, exc_info=True)
                    break
            else:
                continue
            break

        self._mark_run("merge")
        logger.info("合并 %d 组相似记忆", merged_count)

    async def forget_unimportant(self) -> None:
        """
        主动遗忘任务。
        """
        if not self._should_run("forget", _INTERVAL_FORGET_SEC):
            return

        logger.info("执行主动遗忘...")

        try:
            deleted: int = self.engine.forget_unimportant(
                threshold=_FORGET_IMPORTANCE_THRESHOLD,
                max_age_days=_FORGET_MAX_AGE_DAYS,
            )
        except Exception as exc:
            logger.error("主动遗忘执行失败: %s", exc, exc_info=True)
            self._mark_run("forget")
            return

        self._mark_run("forget")
        logger.info("清理 %d 条过期记忆", deleted)

    async def extract_knowledge(self) -> None:
        """
        知识提取任务。
        """
        if not self._should_run("extract", _INTERVAL_EXTRACT_SEC):
            return

        logger.info("执行知识提取...")

        query_sql = """
            SELECT id, content FROM memories
            WHERE level = ? AND importance > ?
            ORDER BY timestamp DESC
            LIMIT ?
        """
        params: Tuple[str, float, int] = (
            LONG_TERM,
            _EXTRACT_IMPORTANCE_MIN,
            _EXTRACT_BATCH_LIMIT,
        )

        try:
            with sqlite3.connect(self.engine.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute(query_sql, params)
                knowledge_items: List[Tuple[int, str]] = cursor.fetchall()
        except sqlite3.Error as exc:
            logger.error("查询长期记忆失败: %s", exc, exc_info=True)
            self._mark_run("extract")
            return
        except Exception as exc:
            logger.error("打开数据库失败: %s", exc, exc_info=True)
            self._mark_run("extract")
            return

        extracted = 0
        for item_id, content in knowledge_items:
            try:
                if any(kw in content for kw in _STRUCTURABLE_KEYWORDS):
                    self.engine.extract_knowledge(item_id)
                    extracted += 1
            except Exception as exc:
                logger.error("提取知识失败 (ID: %d): %s", item_id, exc, exc_info=True)

        self._mark_run("extract")
        logger.info("提取 %d 条知识", extracted)
