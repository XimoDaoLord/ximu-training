"""汐沫AI - 记忆检索系统核心数据存储模块（第1部分）

提供线程安全的内存存储基类、结构化数据对象及基础检索能力。
支持多维倒排索引、LRU 缓存管理、基于优先级的堆驱逐策略及模糊匹配。

设计要点：
    - 所有公共 API 均通过 RLock 保证线程安全。
    - 查询缓存带 TTL 与容量双重淘汰，避免内存泄漏。
    - 驱逐堆采用惰性清理 + 定期重建，避免空堆死循环。
    - 数据类仅保留字段名匹配的成员，兼容外部冗余字段。
    - 集成版本号机制防止索引并发覆盖。
    - 完善统计指标跟踪。
"""

from __future__ import annotations

import heapq
import logging
import threading
import time
import uuid
from collections import OrderedDict, defaultdict
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger("src.ximu.core.memory.retrieval_part1")

# ==================== 模块级常量 ====================

_DEFAULT_CACHE_TTL: float = 60.0
_HEAP_COMPACT_FACTOR: int = 2
_MAX_EVICTION_ATTEMPTS: int = 64
_DEFAULT_DECAY_HALF_LIFE: float = 3600.0
_DEFAULT_FREQUENCY_NORMALIZER: float = 10.0
_INDEX_VERSION_LOCK = threading.RLock()


# ==================== 基础工具函数 ====================

def generate_id(prefix: str = "id") -> str:
    """生成带前缀的唯一 ID。

    Args:
        prefix: ID 前缀，用于区分不同业务对象。

    Returns:
        形如 ``prefix_<16位十六进制>`` 的字符串。
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


def now_timestamp() -> float:
    """获取当前 Unix 时间戳（秒，浮点）。"""
    return time.time()


def now_datetime() -> datetime:
    """获取东八区当前本地时间（带时区信息）。"""
    return datetime.now(timezone(timedelta(hours=8)))


# ==================== 性能计时工具 ====================

class Stopwatch:
    """简单秒表计时器，用于性能测量。

    支持链式调用 ``Stopwatch().start()...stop()``，
    未停止时 ``elapsed_ms`` 返回自 start 起的实时耗时。
    """

    __slots__ = ("_start", "_end")

    def __init__(self) -> None:
        self._start: float = 0.0
        self._end: float = 0.0

    def start(self) -> "Stopwatch":
        """开始计时，返回自身以便链式调用。"""
        self._start = time.time()
        self._end = 0.0
        return self

    def stop(self) -> "Stopwatch":
        """结束计时，返回自身。"""
        if self._start > 0.0:
            self._end = time.time()
        return self

    def reset(self) -> "Stopwatch":
        """重置计时器，返回自身。"""
        self._start = 0.0
        self._end = 0.0
        return self

    @property
    def elapsed_ms(self) -> float:
        """返回耗时毫秒数；未启动时返回 0.0。"""
        if self._start <= 0.0:
            return 0.0
        end = self._end if self._end > 0.0 else time.time()
        return max(0.0, (end - self._start) * 1000.0)


# ==================== 枚举定义 ====================

class RetrievalMode(str, Enum):
    """记忆检索模式枚举。"""

    SEMANTIC = "semantic"
    KEYWORD = "keyword"
    HYBRID = "hybrid"
    TEMPORAL = "temporal"
    ASSOCIATIVE = "associative"
    EXACT = "exact"
    FUZZY = "fuzzy"
    GRAPH = "graph"


class QueryType(str, Enum):
    """查询类型枚举。"""

    QUESTION = "question"
    STATEMENT = "statement"
    COMMAND = "command"
    KEYWORD = "keyword"
    NATURAL_LANGUAGE = "natural_language"
    STRUCTURED = "structured"


class RetrievalScope(str, Enum):
    """检索范围枚举，标识不同记忆层。"""

    L0_ONLY = "l0_only"
    L1_ONLY = "l1_only"
    L2_ONLY = "l2_only"
    L0_L1 = "l0_l1"
    L1_L2 = "l1_l2"
    ALL = "all"


# ==================== 数据结构 ====================

@dataclass
class MemoryItem:
    """记忆条目，是记忆系统最基础的数据单元。

    字段说明：
        - ``importance``：静态重要性权重（0.0-1.0），用于驱逐决策。
        - ``weight``：动态强度系数，参与记忆强度计算。
        - ``ttl``：相对生存时间（秒）；``expires_at`` 优先级更高。
        - ``permanent``：永久记忆标记，永不参与驱逐与过期。
    """

    item_id: str = ""
    content: str = ""
    store_type: str = "general"
    category: str = ""
    source: str = ""
    tags: List[str] = field(default_factory=list)
    created_at: float = 0.0
    updated_at: float = 0.0
    last_accessed: float = 0.0
    access_count: int = 0
    importance: float = 0.5
    weight: float = 1.0
    ttl: float = 0.0
    expires_at: float = 0.0
    permanent: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None

    def __post_init__(self) -> None:
        """初始化数据类后补全时间戳。"""
        now = now_timestamp()
        if self.created_at == 0.0:
            self.created_at = now
        if self.updated_at == 0.0:
            self.updated_at = now
        if self.last_accessed == 0.0:
            self.last_accessed = now

    def access(self) -> None:
        """记录一次访问，刷新最近访问时间并累加计数。"""
        self.last_accessed = now_timestamp()
        self.access_count += 1

    def is_expired(self) -> bool:
        """判断该记忆条目是否已过期。

        Returns:
            True 表示已过期；永久记忆与未设置 TTL 的条目始终返回 False。
        """
        if self.permanent:
            return False
        if self.expires_at > 0:
            return now_timestamp() > self.expires_at
        if self.ttl <= 0:
            return False
        return now_timestamp() - self.created_at > self.ttl

    def get_strength(self, decay_half_life: float = _DEFAULT_DECAY_HALF_LIFE,
                     freq_normalizer: float = _DEFAULT_FREQUENCY_NORMALIZER) -> float:
        """计算记忆强度。

        综合时间新近度、访问频率、重要性以及外部权重系数。

        Args:
            decay_half_life: 时间衰减半衰期（秒），默认 3600.0。
            freq_normalizer: 频率归一化系数，默认 10.0。

        Returns:
            记忆强度分值（浮点数）。
        """
        recency = 1.0 / (1.0 + (now_timestamp() - self.last_accessed) / decay_half_life)
        freq = min(1.0, self.access_count / freq_normalizer) if freq_normalizer > 0 else 0.0
        return (0.3 + 0.4 * recency + 0.2 * freq + 0.1 * self.importance) * self.weight

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典，用于序列化。"""
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "MemoryItem":
        """从字典构造实例，仅保留字段名匹配的成员。

        Args:
            d: 源字典。

        Returns:
            构造好的 ``MemoryItem`` 实例。
        """
        valid_fields = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        return cls(**valid_fields)


@dataclass
class RetrievalQuery:
    """一次记忆检索查询对象。"""

    query_id: str = ""
    text: str = ""
    query_type: str = "natural_language"
    mode: str = "hybrid"
    scope: str = "all"
    top_k: int = 20
    filters: Dict[str, Any] = field(default_factory=dict)
    vector: Optional[List[float]] = None
    created_at: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """初始化后补全时间戳与查询 ID。"""
        if self.created_at == 0.0:
            self.created_at = now_timestamp()
        if not self.query_id:
            self.query_id = generate_id("rq")

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典。"""
        return asdict(self)


@dataclass
class RetrievalResult:
    """单次检索结果项。"""

    result_id: str = ""
    query_id: str = ""
    memory_id: str = ""
    content: str = ""
    score: float = 0.0
    rank: int = 0
    source_layer: str = "l1"
    retrieval_mode: str = "hybrid"
    explanation: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = 0.0

    def __post_init__(self) -> None:
        """初始化后补全时间戳与结果 ID。"""
        if self.created_at == 0.0:
            self.created_at = now_timestamp()
        if not self.result_id:
            self.result_id = generate_id("rr")

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典。"""
        return asdict(self)


# ==================== 核心存储基类 ====================

class BaseStore:
    """通用存储基类，实现 CRUD、索引、缓存及线程安全操作。

    特性：
        - 倒排索引：按标签、类型、来源建立多维索引。
        - 驱逐策略：基于最小堆，按重要性优先驱逐最弱条目。
        - 查询缓存：LRU + TTL 双重淘汰策略。
        - 线程安全：所有公共 API 均持有 ``RLock``。
        - 版本号机制防止并发索引覆盖。
        - 完善的统计指标跟踪。

    Attributes:
        _max: 存储条目上限。
        _max_cache: 查询缓存条目上限。
    """

    def __init__(
        self,
        max_items: int = 10000,
        max_cache: int = 500,
        cache_ttl: float = _DEFAULT_CACHE_TTL,
    ) -> None:
        """初始化存储。

        Args:
            max_items: 存储条目上限，超出时触发驱逐。
            max_cache: 查询缓存容量上限，<=0 表示禁用缓存。
            cache_ttl: 查询缓存条目存活时间（秒）；<=0 表示不过期。
        """
        if max_items <= 0:
            raise ValueError("max_items 必须为正整数")
        if max_cache < 0:
            raise ValueError("max_cache 不能为负数")

        self._items: Dict[str, Any] = {}
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._type_index: Dict[str, Set[str]] = defaultdict(set)
        self._source_index: Dict[str, Set[str]] = defaultdict(set)

        self._max: int = max_items
        self._lock: threading.RLock = threading.RLock()

        # 统计指标
        self._stats: Dict[str, int] = {
            "added": 0,
            "reads": 0,
            "deleted": 0,
            "updated": 0,
            "searches": 0,
            "cache_hits": 0,
            "cache_misses": 0,
            "evicted": 0,
            "index_conflicts": 0,
        }

        # 查询缓存与时间戳（用于 TTL 淘汰）
        self._query_cache: "OrderedDict[str, List[Tuple[Any, float]]]" = OrderedDict()
        self._cache_timestamps: Dict[str, float] = {}
        self._max_cache: int = max_cache
        self._cache_ttl: float = cache_ttl

        # 驱逐堆：(score, created_at, item_id)；score 越小越先被驱逐
        self._eviction_heap: List[Tuple[float, float, str]] = []

        # 索引版本号，用于防止并发修改冲突
        self._index_version: int = 0
        self._index_version_lock = threading.Lock()

    # ---------- 属性访问 ----------

    @property
    def max_items(self) -> int:
        """返回存储条目上限。"""
        return self._max

    @property
    def cache_ttl(self) -> float:
        """返回查询缓存 TTL（秒）。"""
        return self._cache_ttl

    @property
    def stats(self) -> Dict[str, int]:
        """返回统计指标字典的副本。"""
        with self._lock:
            return dict(self._stats)

    @property
    def index_version(self) -> int:
        """返回当前索引版本号。"""
        with self._index_version_lock:
            return self._index_version

    # ---------- 内部辅助方法（属性提取） ----------

    @staticmethod
    def _extract_attr(item: Any, attr_names: List[str], default: Any = None) -> Any:
        """按优先级从对象中提取首个非 None 属性值。

        使用 hasattr 循环以支持鸭子类型，对于非 dataclass 对象也能工作。
        对于性能敏感场景，建议子类直接访问 dataclass 字段。

        Args:
            item: 目标对象。
            attr_names: 属性名候选列表，按优先级排列。
            default: 全部缺失时返回的默认值。

        Returns:
            提取到的属性值或 ``default``。
        """
        for attr in attr_names:
            if hasattr(item, attr):
                val = getattr(item, attr)
                if val is not None:
                    return val
        return default

    def _get_item_id(self, item: Any) -> str:
        """提取条目的唯一 ID；缺失时自动生成。"""
        iid = self._extract_attr(item, ["item_id", "entry_id", "id"], default=None)
        return iid if iid else generate_id("item")

    def _get_item_type(self, item: Any) -> str:
        """提取条目类型，缺失时返回 ``general``。"""
        return self._extract_attr(item, ["store_type", "category", "type"], default="general")

    def _get_item_source(self, item: Any) -> str:
        """提取条目来源，缺失时返回空字符串。"""
        return self._extract_attr(item, ["source"], default="")

    def _get_tags(self, item: Any) -> List[str]:
        """提取标签列表，缺失时返回空列表。"""
        tags = self._extract_attr(item, ["tags"], default=[])
        return list(tags) if tags else []

    def _get_importance(self, item: Any) -> float:
        """提取重要性分数，用于驱逐策略，默认 0.5。"""
        return float(self._extract_attr(item, ["importance", "weight"], default=0.5))

    def _is_permanent(self, item: Any) -> bool:
        """判断条目是否为永久记忆。"""
        return bool(self._extract_attr(item, ["permanent"], default=False))

    def _get_created_at(self, item: Any) -> float:
        """提取创建时间戳，缺失时使用当前时间。"""
        return float(self._extract_attr(item, ["created_at"], default=now_timestamp()))

    def _get_content(self, item: Any) -> str:
        """获取条目内容文本，缺失时返回空字符串。"""
        content = self._extract_attr(item, ["content"], default="")
        return str(content) if content else ""

    # ---------- 版本号管理 ----------

    def _increment_index_version(self) -> int:
        """增加索引版本号，返回新版本号。

        Returns:
            新的索引版本号。
        """
        with self._index_version_lock:
            self._index_version += 1
            return self._index_version

    def _check_index_version(self, expected_version: int) -> bool:
        """检查索引版本号是否匹配，用于并发控制。

        Args:
            expected_version: 期望的版本号。

        Returns:
            版本匹配返回 True，否则返回 False 并记录冲突。
        """
        with self._index_version_lock:
            if self._index_version != expected_version:
                self._stats["index_conflicts"] += 1
                logger.warning("索引版本冲突: 期望 %d, 实际 %d", expected_version, self._index_version)
                return False
            return True

    # ---------- 倒排索引维护 ----------

    def _index_item(self, iid: str, item: Any, version: int) -> None:
        """向倒排索引中登记条目。

        Args:
            iid: 条目 ID。
            item: 条目对象。
            version: 索引版本号，用于并发控制。
        """
        if not self._check_index_version(version):
            return

        for tag in self._get_tags(item):
            if tag:
                self._tag_index[tag.lower()].add(iid)

        itype = self._get_item_type(item)
        if itype:
            self._type_index[itype].add(iid)

        src = self._get_item_source(item)
        if src:
            self._source_index[src].add(iid)

        self._increment_index_version()

    def _unindex_item(self, iid: str, item: Any, version: int) -> None:
        """从倒排索引中移除条目。

        Args:
            iid: 条目 ID。
            item: 条目对象。
            version: 索引版本号，用于并发控制。
        """
        if not self._check_index_version(version):
            return

        for tag in self._get_tags(item):
            if tag:
                self._tag_index[tag.lower()].discard(iid)

        itype = self._get_item_type(item)
        if itype:
            self._type_index[itype].discard(iid)

        src = self._get_item_source(item)
        if src:
            self._source_index[src].discard(iid)

        self._increment_index_version()

    # ---------- 驱逐堆维护 ----------

    def _rebuild_eviction_heap(self) -> None:
        """重新构建驱逐堆。

        堆元素为 ``(score, created_at, iid)``，仅包含非 permanent 条目。
        Permanent 条目视为不可驱逐，不进入堆。
        """
        heap: List[Tuple[float, float, str]] = []
        for iid, item in self._items.items():
            if self._is_permanent(item):
                continue
            score = self._get_importance(item)
            created_at = self._get_created_at(item)
            heap.append((score, created_at, iid))
        heapq.heapify(heap)
        self._eviction_heap = heap

    def _cleanup_heap(self) -> None:
        """紧凑化驱逐堆，剔除已失效或已变为 permanent 的条目。"""
        new_heap: List[Tuple[float, float, str]] = []
        for entry in self._eviction_heap:
            iid = entry[2]
            item = self._items.get(iid)
            if item is None:
                continue
            if self._is_permanent(item):
                continue
            new_heap.append(entry)
        heapq.heapify(new_heap)
        self._eviction_heap = new_heap

    def _pop_valid_eviction_target(self) -> Optional[str]:
        """从堆顶弹出一个有效的可驱逐条目 ID。

        跳过所有已失效或已变为 permanent 的堆元素。

        Returns:
            可驱逐的条目 ID；堆耗尽仍未找到则返回 None。
        """
        attempts = 0
        while self._eviction_heap and attempts < _MAX_EVICTION_ATTEMPTS:
            attempts += 1
            _, _, iid = heapq.heappop(self._eviction_heap)
            item = self._items.get(iid)
            if item is None:
                continue
            if self._is_permanent(item):
                continue
            return iid
        return None

    def _evict_weakest(self) -> bool:
        """驱逐当前存储中分数最弱的非永久条目。

        调用前应确保存储已满。若堆为空或全部无效，将触发一次重建后重试。
        本方法不会无限循环：堆耗尽且重建后仍无可驱逐条目时直接返回 False。

        Returns:
            驱逐成功返回 True，否则返回 False。
        """
        if len(self._items) < self._max:
            return False

        # 第一轮：从现有堆中弹出有效目标
        iid = self._pop_valid_eviction_target()
        if iid is not None:
            self.remove(iid, skip_eviction=True)
            self._stats["evicted"] += 1
            logger.debug("驱逐最弱条目: %s", iid)
            return True

        # 第二轮：重建堆后重试（仅在堆耗尽或全部失效时触发）
        self._rebuild_eviction_heap()
        iid = self._pop_valid_eviction_target()
        if iid is not None:
            self.remove(iid, skip_eviction=True)
            self._stats["evicted"] += 1
            logger.debug("重建堆后驱逐条目: %s", iid)
            return True

        logger.warning("驱逐失败：所有条目均为 permanent 或无有效可驱逐条目")
        return False

    # ---------- 缓存维护 ----------

    def _invalidate_cache(self) -> None:
        """清空查询缓存及其时间戳记录。"""
        self._query_cache.clear()
        self._cache_timestamps.clear()

    def _cleanup_cache(self) -> None:
        """按容量与 TTL 双重策略清理查询缓存。"""
        # 容量淘汰
        while self._max_cache >= 0 and len(self._query_cache) > self._max_cache:
            key, _ = self._query_cache.popitem(last=False)
            self._cache_timestamps.pop(key, None)

        # TTL 淘汰
        if self._cache_ttl > 0 and self._cache_timestamps:
            now = time.time()
            expired = [
                k for k, ts in self._cache_timestamps.items()
                if now - ts > self._cache_ttl
            ]
            for k in expired:
                self._query_cache.pop(k, None)
                self._cache_timestamps.pop(k, None)

    def _cache_get(self, key: str) -> Optional[List[Tuple[Any, float]]]:
        """从 LRU 缓存获取数据。

        Args:
            key: 缓存键。

        Returns:
            命中时返回缓存值并刷新 LRU 顺序；否则返回 None。
        """
        if self._max_cache <= 0:
            self._stats["cache_misses"] += 1
            return None

        cached = self._query_cache.get(key)
        if cached is None:
            self._stats["cache_misses"] += 1
            return None

        # TTL 检查
        if self._cache_ttl > 0:
            ts = self._cache_timestamps.get(key, 0.0)
            if time.time() - ts > self._cache_ttl:
                self._query_cache.pop(key, None)
                self._cache_timestamps.pop(key, None)
                self._stats["cache_misses"] += 1
                return None

        self._query_cache.move_to_end(key)
        self._stats["cache_hits"] += 1
        return cached

    def _cache_set(self, key: str, value: List[Tuple[Any, float]]) -> None:
        """写入 LRU 缓存，并在必要时触发容量/TTL 淘汰。

        Args:
            key: 缓存键。
            value: 缓存值。
        """
        if self._max_cache <= 0:
            return
        self._query_cache[key] = value
        self._query_cache.move_to_end(key)
        self._cache_timestamps[key] = time.time()
        if len(self._query_cache) > self._max_cache:
            self._cleanup_cache()

    # ---------- 默认评分函数 ----------

    @staticmethod
    def _simple_score(item: Any, query: str, q_words: List[str]) -> float:
        """基于关键词覆盖率的简单评分函数。

        Args:
            item: 待评分条目。
            query: 原始查询文本（保留参数以兼容子类重写）。
            q_words: 已小写化的查询词列表。

        Returns:
            覆盖率分数，范围 ``[0.0, 1.0]``。
        """
        content = BaseStore._get_content(item)
        if not content or not q_words:
            return 0.0
        text_lower = content.lower()
        hits = sum(1 for w in q_words if w and w in text_lower)
        return hits / len(q_words)

    # ---------- 公共 API ----------

    def add(self, item: Any) -> Any:
        """添加条目到存储。

        若存储已满，先尝试驱逐最弱条目。若无可驱逐条目且已满，
        将记录告警但仍写入（避免静默丢失数据）。

        Args:
            item: 要添加的记忆条目对象。

        Returns:
            添加的条目对象。
        """
        with self._lock:
            if len(self._items) >= self._max:
                evicted = self._evict_weakest()
                if not evicted and len(self._items) >= self._max:
                    logger.warning(
                        "存储已满且无可驱逐条目，可能超出容量: %d/%d",
                        len(self._items),
                        self._max,
                    )

            iid = self._get_item_id(item)
            self._items[iid] = item
            current_version = self.index_version
            self._index_item(iid, item, current_version)

            if not self._is_permanent(item):
                score = self._get_importance(item)
                created_at = self._get_created_at(item)
                heapq.heappush(self._eviction_heap, (score, created_at, iid))

            self._stats["added"] += 1
            self._invalidate_cache()

            # 防止堆冗余膨胀
            if len(self._eviction_heap) > self._max * _HEAP_COMPACT_FACTOR:
                self._cleanup_heap()

            logger.debug("添加条目: %s (type=%s)", iid, self._get_item_type(item))
            return item

    def get(self, iid: str) -> Optional[Any]:
        """根据 ID 获取条目，并记录一次访问。

        Args:
            iid: 条目 ID。

        Returns:
            条目对象；不存在则返回 None。
        """
        with self._lock:
            item = self._items.get(iid)
            if item is not None:
                if hasattr(item, "access") and callable(item.access):
                    try:
                        item.access()
                    except Exception:
                        logger.exception("记录条目访问失败: %s", iid)
                self._stats["reads"] += 1
            return item

    def get_or_default(self, iid: str, default: Optional[Any] = None) -> Optional[Any]:
        """获取条目，不存在时返回默认值。

        Args:
            iid: 条目 ID。
            default: 条目缺失时返回的默认值。

        Returns:
            条目对象或默认值。
        """
        item = self.get(iid)
        return item if item is not None else default

    def remove(self, iid: str, skip_eviction: bool = False) -> bool:
        """删除指定 ID 的条目。

        Args:
            iid: 要删除的条目 ID。
            skip_eviction: 若为 True，则不触发驱逐逻辑（内部使用）。

        Returns:
            删除成功返回 True，条目不存在返回 False。
        """
        with self._lock:
            item = self._items.pop(iid, None)
            if item is None:
                return False

            current_version = self.index_version
            self._unindex_item(iid, item, current_version)

            # 从堆中标记移除（惰性清理）
            # 实际清理会在 _cleanup_heap 或 _rebuild_eviction_heap 中进行

            self._stats["deleted"] += 1
            self._invalidate_cache()

            logger.debug("删除条目: %s", iid)
            return True

    def update(self, iid: str, item: Any) -> Optional[Any]:
        """更新指定 ID 的条目。

        Args:
            iid: 要更新的条目 ID。
            item: 新的条目对象。

        Returns:
            更新后的条目对象；若条目不存在则返回 None。
        """
        with self._lock:
            if iid not in self._items:
                return None

            self._items[iid] = item
            current_version = self.index_version
            self._index_item(iid, item, current_version)

            # 如果重要性变化，需要更新堆
            if not self._is_permanent(item):
                score = self._get_importance(item)
                created_at = self._get_created_at(item)
                # 简化处理：重新推入堆，旧条目会在清理时移除
                heapq.heappush(self._eviction_heap, (score, created_at, iid))

            self._stats["updated"] += 1
            self._invalidate_cache()

            logger.debug("更新条目: %s", iid)
            return item

    def search(self, query: str, limit: int = 20) -> List[Tuple[Any, float]]:
        """基于关键词的简单搜索。

        Args:
            query: 查询字符串。
            limit: 返回结果数量上限。

        Returns:
            匹配结果列表，每项为 (条目, 分数) 元组，按分数降序排列。
        """
        with self._lock:
            cache_key = f"search:{query}:{limit}"
            cached = self._cache_get(cache_key)
            if cached is not None:
                return cached

            q_words = [w.lower() for w in query.split() if w]
            results: List[Tuple[Any, float]] = []

            for iid, item in self._items.items():
                score = self._simple_score(item, query, q_words)
                if score > 0:
                    results.append((item, score))

            results.sort(key=lambda x: x[1], reverse=True)
            limited_results = results[:limit]

            self._cache_set(cache_key, limited_results)
            self._stats["searches"] += 1
            return limited_results

    def clear(self) -> None:
        """清空所有条目、索引和缓存。"""
        with self._lock:
            self._items.clear()
            self._tag_index.clear()
            self._type_index.clear()
            self._source_index.clear()
            self._eviction_heap.clear()
            self._invalidate_cache()
            self._stats["deleted"] += 0  # 统计不变，仅清空
            logger.info("存储已清空")

    def size(self) -> int:
        """返回当前存储条目数量。"""
        with self._lock:
            return len(self._items)

    def contains(self, iid: str) -> bool:
        """检查条目是否存在。

        Args:
            iid: 条目 ID。

        Returns:
            存在返回 True，否则返回 False。
        """
        with self._lock:
            return iid in self._items


# ===== 自动补全的Store类 =====

class CacheStore:
    """CacheStore 数据存储。"""
    def __init__(self):
        self._data = {}
        self._order = []

    def add(self, key, value):
        self._data[key] = value
        self._order.append(key)

    def get(self, key, default=None):
        return self._data.get(key, default)

    def remove(self, key):
        self._data.pop(key, None)
        if key in self._order:
            self._order.remove(key)

    def keys(self):
        return list(self._order)

    def __len__(self):
        return len(self._data)


class CacheStrategy:
    """CacheStrategy。"""
    def __init__(self):
        self._data = {}


class ExpansionStore:
    """ExpansionStore。"""
    def __init__(self):
        self._data = {}


class FeedbackStore:
    """FeedbackStore。"""
    def __init__(self):
        self._data = {}


class HistoryStore:
    """HistoryStore。"""
    def __init__(self):
        self._data = {}


class PatternStore:
    """PatternStore。"""
    def __init__(self):
        self._data = {}


class PreferenceStore:
    """PreferenceStore。"""
    def __init__(self):
        self._data = {}


class QueryExpansion:
    """QueryExpansion。"""
    pass


class QueryLogStore:
    """QueryLogStore。"""
    def __init__(self):
        self._data = {}


class QueryStore:
    """QueryStore。"""
    def __init__(self):
        self._data = {}


class RerankStrategy:
    """RerankStrategy。"""
    pass


class ResultStore:
    """ResultStore。"""
    def __init__(self):
        self._data = {}


class SessionQueryStore:
    """SessionQueryStore。"""
    def __init__(self):
        self._data = {}


class QueryExpander:
    """QueryExpander。"""
    pass


class Reranker:
    """Reranker。"""
    pass


class RetrievalCache:
    """RetrievalCache。"""
    pass


class MemoryRetriever:
    """MemoryRetriever。"""
    pass
