"""
Memory Retrieval部分2（2762-3336行）。
"""

import logging
import os
import json
import threading
import re
from typing import Any, Callable, Dict, List, Set
from collections import OrderedDict, defaultdict, deque, Counter
from .part1 import (
    CacheStore,
    CacheStrategy,
    ExpansionStore,
    FeedbackStore,
    HistoryStore,
    MemoryItem,
    PatternStore,
    PreferenceStore,
    QueryExpansion,
    QueryLogStore,
    QueryStore,
    QueryType,
    RerankStrategy,
    ResultStore,
    RetrievalMode,
    RetrievalQuery,
    RetrievalResult,
    RetrievalScope,
    SessionQueryStore,
    QueryExpander,
    Reranker,
    RetrievalCache,
    MemoryRetriever,
)

from src.ximu.common.utils import generate_id, now_timestamp

class QueryExpansionManager:
    """
    查询扩展管理器。
    """

    def __init__(self, **kwargs):
        """
        初始化。

        :param kwargs: 配置参数。
        """
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=500)
        self._initialized = False
        self._last_maintenance = 0.0
        self._maintenance_interval = 300.0

    def register_store(self, name: str, store_obj: Any):
        """
        注册存储器。

        :param name: 存储器名称。
        :param store_obj: 存储器对象。
        """
        with self._lock:
            self._stores[name] = store_obj
            self._emit("store_registered", {"name": name})

    def get_store(self, name: str) -> Any:
        """
        获取存储器。

        :param name: 存储器名称。
        :return: 存储器对象。
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """
        移除存储器。

        :param name: 存储器名称。
        :return: 是否成功移除。
        """
        with self._lock:
            s = self._stores.pop(name, None)
            if s:
                self._emit("store_removed", {"name": name})
            return s is not None

    def on(self, event: str, handler: Callable):
        """
        注册事件处理器。

        :param event: 事件名称。
        :param handler: 事件处理器。
        """
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable):
        """
        移除事件处理器。

        :param event: 事件名称。
        :param handler: 事件处理器。
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Any = None):
        """
        发送事件。

        :param event: 事件名称。
        :param data: 事件数据。
        """
        handlers = self._event_handlers.get(event, [])
        for h in handlers:
            try:
                h(data or {})
            except Exception as e:
                # 合理忽略：回调/可选操作失败不影响主流程
                logger.debug("操作失败: %s", e, exc_info=True)

    def record_metric(self, name: str, value: float):
        """
        记录指标。

        :param name: 指标名称。
        :param value: 指标值。
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({"metric": name, "value": value, "timestamp": now_timestamp()})

    def get_metric(self, name: str) -> float:
        """
        获取指标。

        :param name: 指标名称。
        :return: 指标值。
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """
        获取所有指标。

        :return: 指标字典。
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self):
        """
        重置指标。
        """
        with self._lock:
            self._metrics.clear()

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取历史记录。

        :param limit: 记录数量。
        :return: 历史记录列表。
        """
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """
        初始化。

        :return: 是否成功初始化。
        """
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._emit("initialized", {})
            return True

    def shutdown(self) -> bool:
        """
        关闭。

        :return: 是否成功关闭。
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            self._emit("shutdown", {})
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """
        维护。

        :param force: 是否强制维护。
        :return: 维护结果。
        """
        with self._lock:
            now = now_timestamp()
            if not force and now - self._last_maintenance < self._maintenance_interval:
                return {"status": "skipped"}
            cleaned = 0
            for name, s in self._stores.items():
                if hasattr(s, "cleanup_expired"):
                    try:
                        cleaned += s.cleanup_expired()
                    except Exception as e:
                        # 合理忽略：回调/可选操作失败不影响主流程
                        logger.debug("操作失败: %s", e, exc_info=True)
            self._last_maintenance = now
            self._emit("maintenance", {"cleaned": cleaned})
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息。

        :return: 统计信息字典。
        """
        with self._lock:
            store_stats = {}
            for name, s in self._stores.items():
                if hasattr(s, "get_stats"):
                    try:
                        store_stats[name] = s.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(s, "size"):
                    store_stats[name] = {"size": s.size()}
            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history),
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典。

        :return: 字典。
        """
        with self._lock:
            return {"config": dict(self._config), "metrics": dict(self._metrics), "stores": list(self._stores.keys())}

    def export_state(self, filepath: str):
        """
        导出状态。

        :param filepath: 文件路径。
        """
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, default=str)

    def import_state(self, filepath: str) -> bool:
        """
        导入状态。

        :param filepath: 文件路径。
        :return: 是否成功导入。
        """
        if not os.path.exists(filepath):
            return False
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        with self._lock:
            if "config" in data:
                self._config.update(data["config"])
            if "metrics" in data:
                self._metrics.update(data["metrics"])
            return True


class RerankManager:
    """
    重新排序管理器。
    """

    def __init__(self, **kwargs):
        """
        初始化。

        :param kwargs: 配置参数。
        """
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=500)
        self._initialized = False
        self._last_maintenance = 0.0
        self._maintenance_interval = 300.0

    def register_store(self, name: str, store_obj: Any):
        """
        注册存储器。

        :param name: 存储器名称。
        :param store_obj: 存储器对象。
        """
        with self._lock:
            self._stores[name] = store_obj
            self._emit("store_registered", {"name": name})

    def get_store(self, name: str) -> Any:
        """
        获取存储器。

        :param name: 存储器名称。
        :return: 存储器对象。
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """
        移除存储器。

        :param name: 存储器名称。
        :return: 是否成功移除。
        """
        with self._lock:
            s = self._stores.pop(name, None)
            if s:
                self._emit("store_removed", {"name": name})
            return s is not None

    def on(self, event: str, handler: Callable):
        """
        注册事件处理器。

        :param event: 事件名称。
        :param handler: 事件处理器。
        """
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable):
        """
        移除事件处理器。

        :param event: 事件名称。
        :param handler: 事件处理器。
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Any = None):
        """
        发送事件。

        :param event: 事件名称。
        :param data: 事件数据。
        """
        handlers = self._event_handlers.get(event, [])
        for h in handlers:
            try:
                h(data or {})
            except Exception as e:
                # 合理忽略：回调/可选操作失败不影响主流程
                logger.debug("操作失败: %s", e, exc_info=True)

    def record_metric(self, name: str, value: float):
        """
        记录指标。

        :param name: 指标名称。
        :param value: 指标值。
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({"metric": name, "value": value, "timestamp": now_timestamp()})

    def get_metric(self, name: str) -> float:
        """
        获取指标。

        :param name: 指标名称。
        :return: 指标值。
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """
        获取所有指标。

        :return: 指标字典。
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self):
        """
        重置指标。
        """
        with self._lock:
            self._metrics.clear()

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取历史记录。

        :param limit: 记录数量。
        :return: 历史记录列表。
        """
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """
        初始化。

        :return: 是否成功初始化。
        """
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._emit("initialized", {})
            return True

    def shutdown(self) -> bool:
        """
        关闭。

        :return: 是否成功关闭。
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            self._emit("shutdown", {})
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """
        维护。

        :param force: 是否强制维护。
        :return: 维护结果。
        """
        with self._lock:
            now = now_timestamp()
            if not force and now - self._last_maintenance < self._maintenance_interval:
                return {"status": "skipped"}
            cleaned = 0
            for name, s in self._stores.items():
                if hasattr(s, "cleanup_expired"):
                    try:
                        cleaned += s.cleanup_expired()
                    except Exception as e:
                        # 合理忽略：回调/可选操作失败不影响主流程
                        logger.debug("操作失败: %s", e, exc_info=True)
            self._last_maintenance = now
            self._emit("maintenance", {"cleaned": cleaned})
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息。

        :return: 统计信息字典。
        """
        with self._lock:
            store_stats = {}
            for name, s in self._stores.items():
                if hasattr(s, "get_stats"):
                    try:
                        store_stats[name] = s.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(s, "size"):
                    store_stats[name] = {"size": s.size()}
            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history),
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典。

        :return: 字典。
        """
        with self._lock:
            return {"config": dict(self._config), "metrics": dict(self._metrics), "stores": list(self._stores.keys())}

    def export_state(self, filepath: str):
        """
        导出状态。

        :param filepath: 文件路径。
        """
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, default=str)

    def import_state(self, filepath: str) -> bool:
        """
        导入状态。

        :param filepath: 文件路径。
        :return: 是否成功导入。
        """
        if not os.path.exists(filepath):
            return False
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        with self._lock:
            if "config" in data:
                self._config.update(data["config"])
            if "metrics" in data:
                self._metrics.update(data["metrics"])
            return True


class RetrievalCacheManager:
    """
    检索缓存管理器。
    """

    def __init__(self, **kwargs):
        """
        初始化。

        :param kwargs: 配置参数。
        """
        self._stores: Dict[str, Any] = {}
        self._config: Dict[str, Any] = dict(kwargs)
        self._lock = threading.RLock()
        self._event_handlers: Dict[str, List[Callable]] = defaultdict(list)
        self._metrics: Dict[str, float] = defaultdict(float)
        self._history: deque = deque(maxlen=500)
        self._initialized = False
        self._last_maintenance = 0.0
        self._maintenance_interval = 300.0

    def register_store(self, name: str, store_obj: Any):
        """
        注册存储器。

        :param name: 存储器名称。
        :param store_obj: 存储器对象。
        """
        with self._lock:
            self._stores[name] = store_obj
            self._emit("store_registered", {"name": name})

    def get_store(self, name: str) -> Any:
        """
        获取存储器。

        :param name: 存储器名称。
        :return: 存储器对象。
        """
        with self._lock:
            return self._stores.get(name)

    def remove_store(self, name: str) -> bool:
        """
        移除存储器。

        :param name: 存储器名称。
        :return: 是否成功移除。
        """
        with self._lock:
            s = self._stores.pop(name, None)
            if s:
                self._emit("store_removed", {"name": name})
            return s is not None

    def on(self, event: str, handler: Callable):
        """
        注册事件处理器。

        :param event: 事件名称。
        :param handler: 事件处理器。
        """
        with self._lock:
            self._event_handlers[event].append(handler)

    def off(self, event: str, handler: Callable):
        """
        移除事件处理器。

        :param event: 事件名称。
        :param handler: 事件处理器。
        """
        with self._lock:
            if event in self._event_handlers and handler in self._event_handlers[event]:
                self._event_handlers[event].remove(handler)

    def _emit(self, event: str, data: Any = None):
        """
        发送事件。

        :param event: 事件名称。
        :param data: 事件数据。
        """
        handlers = self._event_handlers.get(event, [])
        for h in handlers:
            try:
                h(data or {})
            except Exception as e:
                # 合理忽略：回调/可选操作失败不影响主流程
                logger.debug("操作失败: %s", e, exc_info=True)

    def record_metric(self, name: str, value: float):
        """
        记录指标。

        :param name: 指标名称。
        :param value: 指标值。
        """
        with self._lock:
            self._metrics[name] += value
            self._history.append({"metric": name, "value": value, "timestamp": now_timestamp()})

    def get_metric(self, name: str) -> float:
        """
        获取指标。

        :param name: 指标名称。
        :return: 指标值。
        """
        with self._lock:
            return self._metrics.get(name, 0.0)

    def get_all_metrics(self) -> Dict[str, float]:
        """
        获取所有指标。

        :return: 指标字典。
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self):
        """
        重置指标。
        """
        with self._lock:
            self._metrics.clear()

    def get_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        获取历史记录。

        :param limit: 记录数量。
        :return: 历史记录列表。
        """
        with self._lock:
            return list(self._history)[-limit:]

    def initialize(self) -> bool:
        """
        初始化。

        :return: 是否成功初始化。
        """
        with self._lock:
            if self._initialized:
                return False
            self._initialized = True
            self._emit("initialized", {})
            return True

    def shutdown(self) -> bool:
        """
        关闭。

        :return: 是否成功关闭。
        """
        with self._lock:
            if not self._initialized:
                return False
            self._initialized = False
            self._emit("shutdown", {})
            return True

    def maintenance(self, force: bool = False) -> Dict[str, Any]:
        """
        维护。

        :param force: 是否强制维护。
        :return: 维护结果。
        """
        with self._lock:
            now = now_timestamp()
            if not force and now - self._last_maintenance < self._maintenance_interval:
                return {"status": "skipped"}
            cleaned = 0
            for name, s in self._stores.items():
                if hasattr(s, "cleanup_expired"):
                    try:
                        cleaned += s.cleanup_expired()
                    except Exception as e:
                        # 合理忽略：回调/可选操作失败不影响主流程
                        logger.debug("操作失败: %s", e, exc_info=True)
            self._last_maintenance = now
            self._emit("maintenance", {"cleaned": cleaned})
            return {"status": "done", "cleaned": cleaned}

    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息。

        :return: 统计信息字典。
        """
        with self._lock:
            store_stats = {}
            for name, s in self._stores.items():
                if hasattr(s, "get_stats"):
                    try:
                        store_stats[name] = s.get_stats()
                    except Exception:
                        store_stats[name] = "error"
                elif hasattr(s, "size"):
                    store_stats[name] = {"size": s.size()}
            return {
                "initialized": self._initialized,
                "stores": store_stats,
                "metrics": dict(self._metrics),
                "history": len(self._history),
            }

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典。

        :return: 字典。
        """
        with self._lock:
            return {"config": dict(self._config), "metrics": dict(self._metrics), "stores": list(self._stores.keys())}

    def export_state(self, filepath: str):
        """
        导出状态。

        :param filepath: 文件路径。
        """
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, default=str)

    def import_state(self, filepath: str) -> bool:
        """
        导入状态。

        :param filepath: 文件路径。
        :return: 是否成功导入。
        """
        if not os.path.exists(filepath):
            return False
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        with self._lock:
            if "config" in data:
                self._config.update(data["config"])
            if "metrics" in data:
                self._metrics.update(data["metrics"])
            return True


class MemoryRetriever:
    """
    内存检索器。
    """

    def __init__(self):
        """
        初始化。
        """
        self._query_store = QueryStore()
        self._result_store = ResultStore()
        self._expansion_store = ExpansionStore()
        self._reranker = Reranker()
        self._cache = RetrievalCache()

    def retrieve(self, query: RetrievalQuery, mode: RetrievalMode, top_k: int) -> List[RetrievalResult]:
        """
        检索。

        :param query: 检索查询。
        :param mode: 检索模式。
        :param top_k: 检索数量。
        :return: 检索结果列表。
        """
        processed = self._preprocess(query)
        expansion = self._expander.expand(query)
        self._expansion_store.add(expansion)
        results = []
        if mode in ("semantic", "hybrid"):
            results.extend(self._semantic_search(processed["cleaned"], top_k))
        if mode in ("keyword", "hybrid"):
            results.extend(self._keyword_search(processed["tokens"], top_k))
        if mode == "fuzzy":
            results.extend(self._fuzzy_search(query, top_k))
        reranked = self._reranker.rerank(results, query)
        final = []
        for i, (item, score) in enumerate(reranked[:top_k]):
            rr = RetrievalResult(
                result_id=generate_id("rr"),
                query_id=query.query_id,
                memory_id=getattr(item, "item_id", getattr(item, "entry_id", "")),
                content=(getattr(item, "content") or ""),
                score=score,
                rank=i + 1,
                retrieval_mode=mode,
            )
            self._result_store.add(rr)
            final.append(rr)
        self._cache.put(cache_key, final)
        return final

    def _preprocess(self, query: RetrievalQuery) -> Dict[str, Any]:
        """
        预处理。

        :param query: 检索查询。
        :return: 预处理结果字典。
        """
        # todo: 实现预处理逻辑
        return {}

    def _semantic_search(self, query: str, top_k: int) -> List[RetrievalResult]:
        """
        模糊检索。

        :param query: 检索查询。
        :param top_k: 检索数量。
        :return: 检索结果列表。
        """
        # todo: 实现模糊检索逻辑
        return []

    def _keyword_search(self, tokens: List[str], top_k: int) -> List[RetrievalResult]:
        """
        关键字检索。

        :param tokens: 关键字列表。
        :param top_k: 检索数量。
        :return: 检索结果列表。
        """
        # todo: 实现关键字检索逻辑
        return []

    def _fuzzy_search(self, query: RetrievalQuery, top_k: int) -> List[RetrievalResult]:
        """
        模糊检索。

        :param query: 检索查询。
        :param top_k: 检索数量。
        :return: 检索结果列表。
        """
        # todo: 实现模糊检索逻辑
        return []

    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息。

        :return: 统计信息字典。
        """
        return {
            "queries": self._query_store.get_stats(),
            "results": self._result_store.get_stats(),
            "cache": self._cache.get_stats(),
            "expansions": self._expansion_store.get_stats(),
        }

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典。

        :return: 字典。
        """
        return {
            "query_store": self._query_store.to_dict(),
            "result_store": self._result_store.to_dict(),
            "expansion_store": self._expansion_store.to_dict(),
            "reranker": self._reranker.to_dict(),
            "cache": self._cache.to_dict(),
        }

    def export_state(self, filepath: str):
        """
        导出状态。

        :param filepath: 文件路径。
        """
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, default=str)

    def import_state(self, filepath: str) -> bool:
        """
        导入状态。

        :param filepath: 文件路径。
        :return: 是否成功导入。
        """
        if not os.path.exists(filepath):
            return False
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        # todo: 实现导入状态逻辑
        return True
