"""Split parts of memory_retrieval."""

__all__: list[str] = []
__version__: str = "0.5"
