"""
XimuAI 记忆检索器 - 多路召回 + 精准排序
"""
from __future__ import annotations

import logging
import math
import sqlite3
import sys
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Type

from .memory_engine import (
    EPISODIC,
    PROCEDURAL,
    SEMANTIC,
    MemoryItem,
    get_memory_engine,
)

logger = logging.getLogger("src.ximu.core.memory.retriever")

# 第13轮: 见 r13_syspath 说明——独立脚本/动态插件引导，包方式运行时冗余（保留并说明）
sys.path.insert(0, str(Path(__file__).parent))

RELEVANCE_THRESHOLD = 0.3

class SearchResult:
    """
    搜索结果
    """

    __slots__ = ("memory", "score", "source", "rank")

    def __init__(
        self,
        memory: MemoryItem,
        score: float,
        source: str,
        rank: int,
    ) -> None:
        """
        初始化

        :param memory: MemoryItem
        :param score: float
        :param source: str
        :param rank: int
        """
        self.memory = memory
        self.score = score
        self.source = source
        self.rank = rank

    def __repr__(self) -> str:
        """
        返回字符串表示

        :return: str
        """
        return (
            f"SearchResult(memory_id={self.memory.id!r}, "
            f"score={self.score:.3f}, source={self.source!r}, rank={self.rank})"
        )


class MemoryRetriever:
    """
    记忆检索器 - 多路召回 + 精准排序
    """

    def __init__(self, engine: Type[MemoryItem]) -> None:
        """
        初始化

        :param engine: Type[MemoryItem]
        """
        self.engine = engine
        self.max_results = 20
        self._conn: Optional[sqlite3.Connection] = None
        self._conn_lock: Optional[threading.Lock] = None
        self._conn_lock_created = threading.Lock()

    def _get_conn(self) -> sqlite3.Connection:
        """
        懒建并复用一条只读 SQLite 连接

        :return: sqlite3.Connection
        """
        if self._conn_lock is None:
            with self._conn_lock_created:
                if self._conn_lock is None:
                    self._conn_lock = threading.Lock()
                with self._conn_lock:
                    if self._conn is None:
                        db_path = self.engine.db_path
                        self._conn = sqlite3.connect(
                            db_path, check_same_thread=False
                        )
                        self._conn.row_factory = sqlite3.Row
                    return self._conn

    def retrieve(
        self,
        query: str,
        context: Optional[Dict] = None,
        memory_types: Optional[List[str]] = None,
        levels: Optional[List[str]] = None,
    ) -> List[SearchResult]:
        """
        多路召回检索

        :param query: str
        :param context: Optional[Dict]
        :param memory_types: Optional[List[str]]
        :param levels: Optional[List[str]]
        :return: List[SearchResult]
        """
        if not query or not query.strip():
            return []

        results: List[SearchResult] = []

        # 路1: SQLite关键词搜索
        keyword_results = self._keyword_search(query, memory_types, levels)
        for mem in keyword_results:
            results.append(
                SearchResult(
                    memory=mem,
                    score=0.8,
                    source="keyword",
                    rank=0,
                )
            )

        # 路2: 向量搜索（如果可用）
        chroma_client = getattr(self.engine, "chroma_client", None)
        if chroma_client:
            vector_results = self._vector_search(query, memory_types, levels)
            self._merge_results(results, vector_results, 0.9, "vector", 0.1)

        # 路3: 图关系搜索
        graph_results = self._graph_search(query, levels)
        self._merge_results(results, graph_results, 0.6, "graph", 0.05)

        # 新鲜度加权——对每条结果按写入时间戳乘时间衰减增益。
        now = time.time()
        for r in results:
            delta_hours = max(0.0, (now - r.memory.timestamp) / 3600.0)
            r.score *= (1.0 + 0.25 * math.exp(-delta_hours / 24.0))

        # 排序和过滤
        results.sort(key=lambda x: x.score, reverse=True)
        filtered = [r for r in results if r.score >= RELEVANCE_THRESHOLD]
        for i, r in enumerate(filtered):
            r.rank = i + 1
        return filtered[: self.max_results]

    def _merge_results(
        self,
        results: List[SearchResult],
        new_results: List[MemoryItem],
        score: float,
        source: str,
        boost: float,
    ) -> None:
        """
        合并新搜索结果到已有结果列表（去重+加分）

        :param results: List[SearchResult]
        :param new_results: List[MemoryItem]
        :param score: float
        :param source: str
        :param boost: float
        """
        seen_ids = {r.memory.id for r in results}
        for mem in new_results:
            if mem.id in seen_ids:
                continue
            results.append(
                SearchResult(
                    memory=mem,
                    score=score,
                    source=source,
                    rank=0,
                )
            )
            seen_ids.add(mem.id)
        for r in results:
            if r.memory.id in {m.id for m in new_results}:
                r.score = min(1.0, r.score + boost)

    def _keyword_search(
        self,
        query: str,
        memory_types: Optional[List[str]] = None,
        levels: Optional[List[str]] = None,
    ) -> List[MemoryItem]:
        """
        BM25风格关键词搜索

        :param query: str
        :param memory_types: Optional[List[str]]
        :param levels: Optional[List[str]]
        :return: List[MemoryItem]
        """
        conn = self._get_conn()
        cursor = conn.cursor()
        conditions: List[str] = []
        params: List[str] = []
        if memory_types:
            placeholders = ",".join(["?" for _ in memory_types])
            conditions.append(f"memory_type IN ({placeholders})")
            params.extend(memory_types)
        if levels:
            placeholders = ",".join(["?" for _ in levels])
            conditions.append(f"level IN ({placeholders})")
            params.extend(levels)
        where = (" WHERE " + " AND ".join(conditions)) if conditions else ""
        # E039：where 仅为固定片段与 ? 占位，值走 params 参数化
        sql = f"SELECT * FROM memories{where} ORDER BY importance DESC, timestamp DESC LIMIT 20"
        cursor.execute(sql, params)
        results: List[MemoryItem] = []
        for row in cursor.fetchall():
            mem = MemoryItem(
                id=row[0],
                content=row[1],
                memory_type=row[2],
                timestamp=row[4],
                importance=row[5],
                context=row[6] or "",
            )
            results.append(mem)
        return results

    def _vector_search(
        self,
        query: str,
        memory_types: Optional[List[str]] = None,
        levels: Optional[List[str]] = None,
    ) -> List[MemoryItem]:
        """
        向量语义搜索

        :param query: str
        :param memory_types: Optional[List[str]]
        :param levels: Optional[List[str]]
        :return: List[MemoryItem]
        """
        results: List[MemoryItem] = []
        try:
            types_to_search = memory_types or [SEMANTIC, EPISODIC, PROCEDURAL]
            collections = getattr(self.engine, "collections", None)
            if not collections:
                return results
            for mem_type in types_to_search:
                collection = collections.get(mem_type)
                if collection:
                    docs = collection.query(query_texts=[query], n_results=10)
                    ids = docs.get("ids")
                    if not ids:
                        continue
                    for doc_id in ids[0]:
                        mem = self.engine.get_memory(doc_id)
                        if mem and (not levels or getattr(mem, "level", None) in levels):
                            results.append(mem)
        except Exception as e:
            logger.info(f"[WARN] 向量搜索失败: {e}")
        return results

    def _graph_search(
        self,
        query: str,
        levels: Optional[List[str]] = None,
    ) -> List[MemoryItem]:
        """
        图关系搜索

        :param query: str
        :param levels: Optional[List[str]]
        :return: List[MemoryItem]
        """
        conn = self._get_conn()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT m.id, m.content, m.level, m.importance
            FROM memories m
            JOIN memory_links ml ON m.id = ml.to_id
            JOIN memories ref ON ref.id = ml.from_id
            WHERE ref.content LIKE ?
            AND (m.importance > 0.5 OR ref.importance > 0.7)
            LIMIT 10
            """,
            (f"%{query[:20]}%",),
        )
        results: List[MemoryItem] = []
        now = time.time()
        for row in cursor.fetchall():
            level = row[2]
            if levels and level not in levels:
                continue
            mem = MemoryItem(
                id=row[0],
                content=row[1],
                memory_type="",
                timestamp=now,
                importance=row[3],
                context="",
            )
            results.append(mem)
        return results

    @staticmethod
    def create_retriever() -> MemoryRetriever:
        """
        创建检索器

        :return: MemoryRetriever
        """
        engine = get_memory_engine()
        return MemoryRetriever(engine)


if __name__ == "__main__":
    logger.info("[LOOK] XimuAI 记忆检索器测试")
    logger.info("=" * 50)
    retriever = MemoryRetriever.create_retriever()
    query = "编程"
    results = retriever.retrieve(query)
    logger.info(f"\n检索 '{query}' 找到 {len(results)} 条相关记忆:")
    for r in results:
        logger.info(f" #{r.rank} [{r.source}] 分数: {r.score:.2f}")
        content = r.memory.content or ""
        logger.info(f" {content[:60]}...")
        mem_type = getattr(r.memory, "type", None) or getattr(r.memory, "memory_type", "")
        mem_level = getattr(r.memory, "level", "")
        logger.info(f" 类型: {mem_type}, 级别: {mem_level}")
    logger.info("\n[OK] 检索器测试完成")


class MemoryRetriever:
    """记忆检索器。"""
    def __init__(self):
        self._index = {}
