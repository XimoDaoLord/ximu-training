# -*- coding: utf-8 -*-
"""汐沫AI 0.5 · 模型下载中心来源注册表。

提供多来源枚举、换源决策和平替推荐功能。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

__version__ = "0.5"
NO_PROGRESS_TIMEOUT_S: int = 30


@dataclass(frozen=True)
class ModelSource:
    """表示一个模型下载来源的数据类。"""
    id: str
    name: str
    base: str
    kind: str
    region: str
    note: str
    supported: bool = True

    def to_dict(self) -> Dict[str, str]:
        """将数据类实例转换为字典，保持接口兼容。"""
        return {
            "id": self.id,
            "name": self.name,
            "base": self.base,
            "kind": self.kind,
            "region": self.region,
            "note": self.note,
            "supported": str(self.supported),
        }


MODEL_SOURCES: List[ModelSource] = [
    ModelSource(
        id="modelscope", name="ModelScope",
        base="https://www.modelscope.cn/models", kind="hosting",
        region="cn", note="国内首选", supported=True
    ),
    ModelSource(
        id="huggingface", name="HuggingFace",
        base="https://huggingface.co", kind="hosting",
        region="global", note="官方源", supported=True
    ),
    ModelSource(
        id="hf-mirror", name="HF Mirror",
        base="https://hf-mirror.com", kind="mirror",
        region="cn", note="HuggingFace 国内镜像", supported=True
    ),
    ModelSource(
        id="ollama", name="Ollama Registry",
        base="https://registry.ollama.ai", kind="registry",
        region="global", note="Ollama 模型库", supported=True
    ),
    ModelSource(
        id="wisemodel", name="Wisemodel 魔乐",
        base="https://wisemodel.cn/models", kind="hosting",
        region="cn", note="暂不支持本地直连下载", supported=False
    ),
    ModelSource(
        id="modelers", name="Modelers OpenMind",
        base="https://openmind.modelers.cn/models", kind="hosting",
        region="cn", note="暂不支持本地直连下载", supported=False
    ),
    ModelSource(
        id="github", name="GitHub Releases",
        base="https://github.com", kind="release",
        region="global", note="GGUF 等发布件托管", supported=True
    ),
]


def list_sources() -> List[Dict[str, str]]:
    """返回全部下载来源的字典列表。"""
    return [source.to_dict() for source in MODEL_SOURCES]


def source_count() -> int:
    """返回已注册下载来源数量。"""
    return len(MODEL_SOURCES)


def get_source(source_id: str) -> Optional[Dict[str, str]]:
    """按 id 获取来源条目；未注册返回 None。"""
    for source in MODEL_SOURCES:
        if source.id == source_id:
            return source.to_dict()
    return None


def is_supported(source_id: str) -> bool:
    """判断该源当前是否可本地真实下载。"""
    for source in MODEL_SOURCES:
        if source.id == source_id:
            return source.supported
    return True


def build_url(source_id: str, org: str, filename: str) -> str:
    """按来源构造真实下载 URL。"""
    for source in MODEL_SOURCES:
        if source.id == source_id:
            base = source.base.rstrip("/")
            if source_id == "github":
                return f"{base}/{org}/releases/download/{filename}"
            return f"{base}/{org}/resolve/main/{filename}"
    raise ValueError(f"未知下载来源: {source_id}")


def next_failed_source(used: List[str]) -> Optional[Dict[str, str]]:
    """按顺序返回一个尚未使用的来源；全部用完返回 None。"""
    for source in MODEL_SOURCES:
        if source.id not in used:
            return source.to_dict()
    return None


def recommend_alternatives(failed_id: str,
                            original_region: str = "global") -> List[Dict[str, str]]:
    """推荐替代来源：同 region 优先，其余按原顺序。"""
    others = [source for source in MODEL_SOURCES if source.id != failed_id]
    same_region = [source.to_dict() for source in others if source.region == original_region]
    other_region = [source.to_dict() for source in others if source.region != original_region]
    return same_region + other_region
