# -*- coding: utf-8 -*-
"""
模型下载管理器 - 多源、断点续传、完整性校验及本地注册。
"""

import asyncio
import hashlib
import json
import logging
import os
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

try:
    import httpx
except ImportError:
    httpx = None

logger = logging.getLogger(__name__)

# 常量
CHUNK_SIZE = 64 * 1024
PROGRESS_UPDATE_INTERVAL = 0.5
HTTP_TIMEOUT = 30.0
USER_AGENT = "XiMuAI-ModelDownloader/1.0"
MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 2.0
SOURCE_ALIASES: Dict[str, str] = {"hf-mirror": "hfmirror"}
MARKET_ID_PREFIXES: Tuple[str, ...] = ("hfmirror/", "hf/", "ms/")

class DownloadStatus(Enum):
    """
    下载任务状态枚举。
    """
    PENDING = "pending"
    DOWNLOADING = "downloading"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PAUSED = "paused"

class SourceType(Enum):
    """
    模型源类型枚举。
    """
    HUGGING_FACE = "huggingface"
    MODELScope = "modelscope"
    OLLAMA = "ollama"
    GITEE = "gitee"
    CUSTOM = "custom"

@dataclass
class DownloadTask:
    """
    下载任务数据结构。
    """
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    model_name: str = ""
    source_type: SourceType = SourceType.CUSTOM
    url: str = ""
    local_path: str = ""
    status: DownloadStatus = DownloadStatus.PENDING
    progress: float = 0.0
    downloaded_bytes: int = 0
    total_bytes: int = 0
    error_message: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    sha256_checksum: Optional[str] = None
    cancel_event: threading.Event = field(default_factory=threading.Event)
    lock: threading.Lock = field(default_factory=threading.Lock)

    def is_cancelled(self) -> bool:
        """
        检查任务是否被取消。
        """
        return self.cancel_event.is_set()

    def mark_cancelled(self) -> None:
        """
        标记任务为已取消。
        """
        with self.lock:
            self.status = DownloadStatus.CANCELLED
            self.cancel_event.set()

class SourceStrategy:
    """
    源策略基类，定义URL构建和校验接口。
    """
    def __init__(self, source_type: SourceType) -> None:
        """
        初始化策略。
        Args:
            source_type: 源类型。
        """
        self.source_type = source_type

    def build_url(self, model_id: str, filename: str = "") -> str:
        """
        构建下载URL。
        Args:
            model_id: 模型ID。
            filename: 文件名，可选。
        Returns:
            构建好的URL字符串。
        Raises:
            NotImplementedError: 子类未实现时抛出。
        """
        raise NotImplementedError

    def validate_checksum(self, filepath: str, expected_sha256: str) -> bool:
        """
        校验文件SHA256。
        Args:
            filepath: 文件路径。
            expected_sha256: 期望的SHA256值。
        Returns:
            校验通过返回True，否则返回False。
        """
        actual_hash = self._calculate_sha256(filepath)
        return actual_hash == expected_sha256.lower()

    @staticmethod
    def _calculate_sha256(filepath: str) -> str:
        """
        计算文件SHA256校验和。
        Args:
            filepath: 文件路径。
        Returns:
            SHA256十六进制字符串。
        """
        hash_sha256 = hashlib.sha256()
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(CHUNK_SIZE), b""):
                hash_sha256.update(chunk)
        return hash_sha256.hexdigest()

class HuggingFaceStrategy(SourceStrategy):
    """
    HuggingFace源策略。
    """
    def __init__(self) -> None:
        """
        初始化HuggingFace策略。
        """
        super().__init__(SourceType.HUGGING_FACE)
        self.base_url = "https://huggingface.co/{model_id}/resolve/main/{filename}"

    def build_url(self, model_id: str, filename: str = "") -> str:
        """
        构建HuggingFace下载URL。
        Args:
            model_id: 模型ID。
            filename: 文件名。
        Returns:
            构建好的URL。
        Raises:
            ValueError: 如果model_id为空。
        """
        if not model_id:
            raise ValueError("model_id不能为空")
        if filename:
            return self.base_url.format(model_id=model_id, filename=filename)
        return f"https://huggingface.co/{model_id}"

class ModelScopeStrategy(SourceStrategy):
    """
    ModelScope源策略。
    """
    def __init__(self) -> None:
        """
        初始化ModelScope策略。
        """
        super().__init__(SourceType.MODELScope)
        self.base_url = "https://www.modelscope.cn/models/{model_id}/resolve/master/{filename}"

    def build_url(self, model_id: str, filename: str = "") -> str:
        """
        构建ModelScope下载URL。
        Args:
            model_id: 模型ID。
            filename: 文件名。
        Returns:
            构建好的URL。
        Raises:
            ValueError: 如果model_id为空。
        """
        if not model_id:
            raise ValueError("model_id不能为空")
        if filename:
            return self.base_url.format(model_id=model_id, filename=filename)
        return f"https://www.modelscope.cn/models/{model_id}"

class OllamaStrategy(SourceStrategy):
    """
    Ollama源策略。
    """
    def __init__(self) -> None:
        """
        初始化Ollama策略。
        """
        super().__init__(SourceType.OLLAMA)
        self.base_url = "https://registry.ollama.ai/v2/library/{model_id}/blobs/{filename}"

    def build_url(self, model_id: str, filename: str = "") -> str:
        """
        构建Ollama下载URL。
        Args:
            model_id: 模型ID。
            filename: 文件名。
        Returns:
            构建好的URL。
        Raises:
            ValueError: 如果model_id或filename为空。
        """
        if not model_id:
            raise ValueError("model_id不能为空")
        if not filename:
            raise ValueError("Ollama源需要指定blob filename")
        return self.base_url.format(model_id=model_id, filename=filename)

class GiteeStrategy(SourceStrategy):
    """
    Gitee源策略。
    """
    def __init__(self) -> None:
        """
        初始化Gitee策略。
        """
        super().__init__(SourceType.GITEE)
        self.base_url = "https://gitee.com/{model_id}/raw/master/{filename}"

    def build_url(self, model_id: str, filename: str = "") -> str:
        """
        构建Gitee下载URL。
        Args:
            model_id: 模型ID。
            filename: 文件名。
        Returns:
            构建好的URL。
        Raises:
            ValueError: 如果model_id或filename为空。
        """
        if not model_id:
            raise ValueError("model_id不能为空")
        if not filename:
            raise ValueError("Gitee源需要指定filename")
        return self.base_url.format(model_id=model_id, filename=filename)

class CustomStrategy(SourceStrategy):
    """
    自定义源策略。
    """
    def __init__(self, base_url: str = "") -> None:
        """
        初始化自定义策略。
        Args:
            base_url: 基础URL。
        """
        super().__init__(SourceType.CUSTOM)
        self.base_url = base_url

    def build_url(self, model_id: str, filename: str = "") -> str:
        """
        构建自定义下载URL。
        Args:
            model_id: 模型ID。
            filename: 文件名。
        Returns:
            构建好的URL。
        Raises:
            ValueError: 如果base_url未设置。
        """
        if not self.base_url:
            raise ValueError("自定义源需要base_url")
        url = f"{self.base_url}/{model_id}"
        if filename:
            url += f"/{filename}"
        return url

class ModelDownloader:
    """
    模型下载管理器。
    """
    def __init__(self, base_dir: str = "./models") -> None:
        """
        初始化下载管理器。
        Args:
            base_dir: 模型本地存储根目录。
        """
        self.base_dir = Path(base_dir).resolve()
        if not self.base_dir.exists():
            self.base_dir.mkdir(parents=True, exist_ok=True)
        self._strategies: Dict[SourceType, SourceStrategy] = {
            SourceType.HUGGING_FACE: HuggingFaceStrategy(),
            SourceType.MODELScope: ModelScopeStrategy(),
            SourceType.OLLAMA: OllamaStrategy(),
            SourceType.GITEE: GiteeStrategy(),
            SourceType.CUSTOM: CustomStrategy(),
        }
        self._tasks: Dict[str, DownloadTask] = {}
        self._lock = threading.Lock()
        self._http_client: Optional[httpx.Client] = None

    def __del__(self) -> None:
        """
        析构函数，清理HTTP客户端。
        """
        if self._http_client:
            self._http_client.close()

    def _get_http_client(self) -> httpx.Client:
        """
        获取或创建HTTP客户端实例。
        Returns:
            httpx.Client实例。
        """
        if not httpx:
            raise ImportError("httpx未安装，请执行: pip install httpx")
        if self._http_client is None:
            self._http_client = httpx.Client(timeout=HTTP_TIMEOUT)
        return self._http_client

    def safe_join(self, *paths: str) -> str:
        """
        安全路径拼接，防止目录遍历攻击。
        Args:
            *paths: 路径片段。
        Returns:
            拼接后的安全路径。
        Raises:
            ValueError: 路径不合法时抛出。
        """
        if not paths:
            raise ValueError("路径不能为空")
        joined = self.base_dir.joinpath(*paths)
        try:
            resolved = joined.resolve()
            # 使用 is_relative_to 确保路径在 base_dir 内 (Python 3.9+)
            # 对于兼容性和严格性，检查 resolved 是否等于 base_dir 或以 base_dir 为前缀
            # 注意：resolve() 会处理 .. 和符号链接，is_relative_to 在 Path 中可用
            if not resolved.is_relative_to(self.base_dir):
                raise ValueError(f"非法路径: {joined}")
            return str(resolved)
        except Exception as e:
            raise ValueError(f"路径校验失败: {e}")

    def create_task(
        self,
        model_name: str,
        source_type: SourceType,
        url: Optional[str] = None,
        local_path: Optional[str] = None,
        sha256_checksum: Optional[str] = None,
    ) -> DownloadTask:
        """
        创建下载任务。
        Args:
            model_name: 模型名称。
            source_type: 源类型。
            url: 直接指定URL（可选，若提供则忽略源类型构建逻辑）。
            local_path: 本地保存路径（可选，默认为base_dir/model_name）。
            sha256_checksum: 期望的SHA256校验和。
        Returns:
            创建的任务对象。
        Raises:
            ValueError: 当URL和本地路径都无法确定时。
        """
        # 确定本地路径
        if local_path:
            p = Path(local_path)
            if p.is_absolute():
                # 绝对路径也需要校验，确保没有注入恶意路径跳出逻辑（虽然绝对路径通常直接信任，但为了统一安全模型，这里强制校验）
                # 如果允许绝对路径，必须确保它也是安全的。为了简化，我们强制所有路径都通过 safe_join 或者在 create_task 中处理
                # 原逻辑中绝对路径直接返回是风险点。我们改为：如果提供绝对路径，直接使用该绝对路径，但需确保其存在性由调用者保证。
                # 但为了安全，我们假设 local_path 是相对于 base_dir 的。如果用户传入绝对路径，我们将其视为相对于根目录？
                # 根据需求：“对绝对路径的local_path也强制通过安全校验”。
                # 方案：如果 local_path 是绝对路径，直接解析并检查是否在允许范围内（这里假设只允许在 base_dir 下或者系统根下，但通常模型在 base_dir）。
                # 最简单的安全策略：只接受相对于 base_dir 的路径。如果传入绝对路径，抛出异常或强制转换为相对？
                # 根据“禁止用网上代码，基于现有代码理解”，原代码对绝对路径是直接透传。
                # 修正：如果 local_path 是绝对路径，我们直接使用该路径，但不再进行 safe_join。
                # 但是，如果绝对路径是 /etc/passwd，这也是危险的。
                # 因此，最佳实践是：模型下载只能存储在 base_dir 下。
                # 所以，无论 local_path 是相对还是绝对，我们都应该将其解析，并确保结果在 base_dir 内。
                # 如果 local_path 是绝对路径，我们将其视为相对于 base_dir 的相对路径是错误的。
                # 让我们修改逻辑：local_path 必须是相对于 base_dir 的路径。如果用户传入绝对路径，我们抛出 ValueError。
                raise ValueError("local_path 必须是相对于 base_dir 的路径")
            final_local_path = self.safe_join(str(p))
        else:
            final_local_path = self.safe_join(model_name)
        task = DownloadTask(
            model_name=model_name,
            source_type=source_type,
            url=url or "",
            local_path=final_local_path,
            sha256_checksum=sha256_checksum,
        )
        if not task.url:
            strategy = self._get_strategy(source_type)
            try:
                task.url = strategy.build_url(model_name)
            except ValueError as ve:
                logger.warning("无法构建URL，可能需要手动指定: %s", ve)
        with self._lock:
            self._tasks[task.task_id] = task
        logger.info("创建下载任务: task_id=%s, model=%s, url=%s", task.task_id, model_name, task.url)
        return task

    def _get_strategy(self, source_type: SourceType) -> SourceStrategy:
        """
        获取源策略实例。
        Args:
            source_type: 源类型。
        Returns:
            策略实例。
        Raises:
            KeyError: 源类型未知。
        """
        return self._strategies[source_type]

    async def download(
        self,
        task_id: str,
        progress_callback: Optional[Callable[[DownloadTask], None]] = None,
    ) -> bool:
        """
        执行下载任务。
        Args:
            task_id: 任务ID。
            progress_callback: 进度回调函数。
        Returns:
            下载是否成功。
        Raises:
            ValueError: 任务不存在。
        """
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                raise ValueError(f"任务不存在: {task_id}")
            task.status = DownloadStatus.DOWNLOADING
            task.error_message = None
        try:
            return await self._execute_download(task, progress_callback)
        except Exception as e:
            with task.lock:
                task.status = DownloadStatus.FAILED
                task.error_message = str(e)
            logger.error("下载任务失败: task_id=%s, error=%s", task_id, e, exc_info=True)
            return False

    async def _execute_download(
        self,
        task: DownloadTask,
        progress_callback: Optional[Callable[[DownloadTask], None]],
    ) -> bool:
        """
        执行实际下载逻辑。
        Args:
            task: 下载任务。
            progress_callback: 进度回调。
        Returns:
            下载是否成功。
        Raises:
            ImportError: 如果 httpx 未安装。
            ValueError: 如果本地路径未指定。
        """
        if not task.url:
            raise ValueError("下载URL未指定")
        filepath = task.local_path
        if not filepath:
            raise ValueError("本地路径未指定")
        # 确保目录存在
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        # 检查是否已存在且校验通过
        if os.path.exists(filepath):
            if task.sha256_checksum:
                strategy = self._get_strategy(task.source_type)
                if strategy.validate_checksum(filepath, task.sha256_checksum):
                    logger.info("文件已存在且校验通过: %s", filepath)
                    with task.lock:
                        task.status = DownloadStatus.COMPLETED
                    file_size = os.path.getsize(filepath)
                    task.downloaded_bytes = file_size
                    task.total_bytes = file_size
                    task.progress = 1.0
                    return True
                else:
                    logger.warning("文件存在但校验失败，删除并重新下载: %s", filepath)
                    os.remove(filepath)
        # 下载流开始
        start_pos = 0
        if os.path.exists(filepath):
            start_pos = os.path.getsize(filepath)
        logger.info("尝试断点续传: %s, start_pos=%d", filepath, start_pos)
        success = False
        retry_count = 0
        while retry_count < MAX_RETRIES and not success:
            if task.is_cancelled():
                task.mark_cancelled()
                if os.path.exists(filepath):
                    try:
                        os.remove(filepath)
                    except OSError:
                        pass
                logger.info("下载任务被取消: %s", task.task_id)
                return False
            headers = {"User-Agent": USER_AGENT}
            if start_pos > 0:
                headers["Range"] = f"bytes={start_pos}-"
            try:
                client = self._get_http_client()
                with client.stream("GET", task.url, headers=headers) as response:
                    response.raise_for_status()
                    if response.status_code == 206:
                        content_length = int(response.headers.get("content-length", 0))
                        total_bytes = start_pos + content_length
                    elif response.status_code == 200:
                        # 服务器不支持断点续传或从头开始
                        start_pos = 0
                        total_bytes = int(response.headers.get("content-length", 0))
                    else:
                        raise ConnectionError(f"意外HTTP状态码: {response.status_code}")
                    mode = "ab" if start_pos > 0 else "wb"
                    downloaded = start_pos
                    last_update_time = time.monotonic()
                    with open(filepath, mode) as f:
                        for chunk in response.iter_bytes(CHUNK_SIZE):
                            if task.is_cancelled():
                                task.mark_cancelled()
                                return False
                            f.write(chunk)
                            downloaded += len(chunk)
                            current_time = time.monotonic()
                            if current_time - last_update_time >= PROGRESS_UPDATE_INTERVAL:
                                last_update_time = current_time
                                with task.lock:
                                    task.downloaded_bytes = downloaded
                                    task.total_bytes = total_bytes
                                    if total_bytes > 0:
                                        task.progress = min(1.0, downloaded / total_bytes)
                                    else:
                                        task.progress = 0.0
                                if progress_callback:
                                    progress_callback(task)
                    success = True
            except httpx.HTTPError as e:
                retry_count += 1
                logger.warning(
                    "下载失败 (重试 %d/%d): task_id=%s, error=%s",
                    retry_count,
                    MAX_RETRIES,
                    task.task_id,
                    e,
                )
                if retry_count < MAX_RETRIES:
                    wait_time = RETRY_BACKOFF_BASE ** retry_count
                    time.sleep(wait_time)
                else:
                    raise e
            except Exception as e:
                # 非网络错误或其他异常，直接抛出
                raise e
        # 下载完成，校验
        if task.sha256_checksum:
            strategy = self._get_strategy(task.source_type)
            if not strategy.validate_checksum(filepath, task.sha256_checksum):
                logger.error("SHA256校验失败: %s", filepath)
                with task.lock:
                    task.status = DownloadStatus.FAILED
                    task.error_message = "SHA256校验失败"
                try:
                    os.remove(filepath)
                except OSError:
                    pass
                return False
        with task.lock:
            task.status = DownloadStatus.COMPLETED
            task.progress = 1.0
        final_size = os.path.getsize(filepath)
        task.downloaded_bytes = final_size
        task.total_bytes = final_size
        logger.info("下载完成: task_id=%s, file=%s", task.task_id, filepath)
        return True

    def cancel(self, task_id: str) -> bool:
        """
        取消下载任务。
        Args:
            task_id: 任务ID。
        Returns:
            是否成功取消。
        """
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return False
            if task.status in (DownloadStatus.COMPLETED, DownloadStatus.FAILED, DownloadStatus.CANCELLED):
                return False
            task.mark_cancelled()
            logger.info("取消下载任务: task_id=%s", task_id)
            return True

    def get_task(self, task_id: str) -> Optional[DownloadTask]:
        """
        获取任务状态。
        Args:
            task_id: 任务ID
        """
        with self._lock:
            task = self._tasks.get(task_id)
            if task:
                return task
            return None
