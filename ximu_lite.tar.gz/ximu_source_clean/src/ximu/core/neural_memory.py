# -*- coding: utf-8 -*-
"""神经记忆系统。

支持向量搜索、语义记忆、记忆融合、遗忘曲线等功能，
模拟人脑记忆机制实现高效记忆存储与检索。
"""
from __future__ import annotations

import json
import logging
import math
import os
import threading
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Tuple

from ..common.constants import DefaultValues

logger = logging.getLogger("src.ximu.core.neural_memory")

# === 神经记忆系统参数常量 ===
NEURAL_MEMORY_MAX_ITEMS: int = 999999
NEURAL_MEMORY_RETENTION_THRESHOLD: float = 0.1
NEURAL_MEMORY_DECAY_BASE: float = 0.95

# P88: 常见中文单字停用词
_P88_COMMON_UNIGRAMS: frozenset = frozenset({
    "的", "了", "吗", "呢", "吧", "啊", "呀", "哦", "嗯", "嘛", "呗", "嘞",
    "是", "不", "和", "与", "或", "等", "也", "都", "就", "还", "又", "再", "已",
    "将", "被", "把", "让", "给", "向", "从", "到", "对", "为", "以", "及",
    "在", "一", "个", "们", "这", "那",
    "自", "己", "你", "我", "他", "她", "它", "无", "没", "会", "能", "可",
    "要", "想", "知", "道", "说", "看", "听", "做", "搞", "弄", "走", "来",
    "去", "上", "下", "里", "外", "中", "间", "前", "后", "左", "右", "大",
    "小", "多", "少", "好", "坏", "新", "旧", "高", "低", "长", "短", "快",
    "慢", "早", "晚", "先", "哪", "什", "么", "怎", "样", "如", "果", "因",
    "所", "但", "然", "虽", "即", "使", "假", "万", "只", "除", "非", "另",
    "其", "实", "毕", "竟", "究", "底", "有", "并", "而",
})

# P89 泛化 bigram 黑名单
_P89_GENERIC_BIGRAMS: frozenset = frozenset({
    "自己", "两个", "什么", "怎么", "没有", "我们", "你们", "他们",
    "这个", "那个", "现在", "然后", "因为", "所以", "但是", "可以",
    "知道", "觉得", "一下", "一样", "一些", "这种", "那种", "这样",
    "那样", "其实", "已经", "还是", "或者", "不是", "就是", "还有",
})

# 纯神经匹配阈值
_P88_PURE_NEURAL_THRESHOLD: float = 0.52


@dataclass
class MemoryItem:
    """记忆条目数据类。

    存储单个记忆项的所有属性，包括内容、类型、重要性、
    时间戳、向量表示和相关记忆索引。
    """
    memory_id: str
    content: str
    memory_type: str
    importance: float
    created_at: float
    last_accessed: float
    access_count: int
    decay_rate: float
    embeddings: List[float]
    tags: List[str] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)
    related_memories: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """序列化为可 JSON 化字典。

        Returns:
            包含所有必要字段的字典，content 超长时截断。
        """
        return {
            "memory_id": self.memory_id,
            "content": (
                self.content[:DefaultValues.AE_CONTENT_TRUNCATE_LEN] + "..."
                if len(self.content) > DefaultValues.AE_CONTENT_TRUNCATE_LEN
                else self.content
            ),
            "memory_type": self.memory_type,
            "importance": self.importance,
            "created_at": self.created_at,
            "last_accessed": self.last_accessed,
            "access_count": self.access_count,
            "decay_rate": self.decay_rate,
            "embeddings": self.embeddings,
            "tags": self.tags,
            "context": self.context,
            "related_memories": self.related_memories,
        }

    @property
    def strength(self) -> float:
        """计算记忆强度（考虑遗忘曲线）。

        Returns:
            当前记忆强度值，范围 0-1。
        """
        age_days: float = (time.time() - self.created_at) / 86400
        ebbinghaus: float = math.exp(-self.decay_rate * age_days)
        recency_bonus: float = min(self.access_count * 0.1, 0.5)
        return self.importance * (ebbinghaus + recency_bonus)


class NeuralMemorySystem:
    """神经记忆系统 - 模拟人脑记忆机制。

    提供记忆的存储、检索、遗忘和融合功能，
    支持向量相似度搜索和语义匹配。
    """

    def __init__(self, storage_dir: Path) -> None:
        """初始化神经记忆系统。

        Args:
            storage_dir: 记忆存储目录路径。
        """
        self.storage_dir: Path = storage_dir
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        self.memories: Dict[str, MemoryItem] = {}
        self.index_by_type: defaultdict[str, List[str]] = defaultdict(list)
        self.index_by_tag: defaultdict[str, List[str]] = defaultdict(list)
        self.index_by_time: List[str] = []

        self.lock: threading.RLock = threading.RLock()
        self._load_memories()

        self.max_memories: int = NEURAL_MEMORY_MAX_ITEMS
        self.retention_threshold: float = NEURAL_MEMORY_RETENTION_THRESHOLD
        self.decay_base: float = NEURAL_MEMORY_DECAY_BASE

    def _load_memories(self) -> None:
        """从磁盘加载所有记忆数据。

        读取 neural_memory.json 文件并重建所有索引结构。
        """
        mem_file: Path = self.storage_dir / "neural_memory.json"
        if not mem_file.exists():
            return

        try:
            with open(mem_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                for item in data.get("memories", []):
                    self.memories[item["memory_id"]] = MemoryItem(**item)
                for mid, mem in self.memories.items():
                    self.index_by_type[mem.memory_type].append(mid)
                    for tag in mem.tags:
                        self.index_by_tag[tag].append(mid)
                self.index_by_time = sorted(
                    self.memories.keys(),
                    key=lambda x: self.memories[x].created_at,
                    reverse=True,
                )
        except Exception as exc:
            logger.info("加载记忆失败: %s", exc)

    def save_memories(self) -> None:
        """原子方式保存所有记忆数据。

        使用临时文件 + 重命名策略，确保崩溃不会损坏主文件。
        """
        mem_file: Path = self.storage_dir / "neural_memory.json"
        data: Dict[str, Any] = {
            "memories": [m.to_dict() for m in self.memories.values()],
            "stats": self.get_stats(),
        }
        tmp_file: Path = mem_file.with_suffix(".tmp")
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_file, mem_file)

    def remember(
        self,
        content: str,
        memory_type: str = "episodic",
        importance: float = 0.5,
        tags: List[str] | None = None,
        context: Dict[str, Any] | None = None,
    ) -> str:
        """记录新记忆。

        Args:
            content: 记忆内容文本。
            memory_type: 记忆类型，默认 episodic。
            importance: 重要性分数 0-1。
            tags: 关联标签列表。
            context: 上下文信息字典。

        Returns:
            生成的记忆 ID。
        """
        with self.lock:
            memory_id: str = f"mem_{int(time.time())}_{uuid.uuid4().hex[:8]}"
            now: float = time.time()
            embeddings: List[float] = self._generate_embedding(content)

            memory_item: MemoryItem = MemoryItem(
                memory_id=memory_id,
                content=content,
                memory_type=memory_type,
                importance=importance,
                created_at=now,
                last_accessed=now,
                access_count=1,
                decay_rate=self.decay_base,
                embeddings=embeddings,
                tags=tags or [],
                context=context or {},
            )
            self.memories[memory_id] = memory_item
            self.index_by_type[memory_type].append(memory_id)
            for tag in (tags or []):
                self.index_by_tag[tag].append(memory_id)
            self.index_by_time.insert(0, memory_id)
            self.save_memories()
            return memory_id

    def recall(
        self,
        query: str,
        top_k: int = 5,
        min_similarity: float = 0.3,
    ) -> List[Tuple[str, float]]:
        """根据查询检索相关记忆。

        Args:
            query: 查询文本。
            top_k: 返回最大结果数。
            min_similarity: 最低相似度阈值。

        Returns:
            (记忆ID, 相似度分数) 列表，按相似度降序排列。
        """
        with self.lock:
            query_embedding: List[float] = self._generate_embedding(query)
            results: List[Tuple[str, float]] = []

            for mid, mem in self.memories.items():
                similarity: float = self._cosine_similarity(
                    query_embedding, mem.embeddings
                )
                if similarity >= min_similarity:
                    results.append((mid, similarity))

            results.sort(key=lambda x: x[1], reverse=True)
            return results[:top_k]

    def forget(self, memory_id: str) -> bool:
        """删除指定记忆。

        Args:
            memory_id: 要删除的记忆 ID。

        Returns:
            是否成功删除。
        """
        with self.lock:
            if memory_id not in self.memories:
                return False
            mem = self.memories[memory_id]
            del self.memories[memory_id]
            if memory_id in self.index_by_type.get(mem.memory_type, []):
                self.index_by_type[mem.memory_type].remove(memory_id)
            for tag in mem.tags:
                if memory_id in self.index_by_tag[tag]:
                    self.index_by_tag[tag].remove(memory_id)
            if memory_id in self.index_by_time:
                self.index_by_time.remove(memory_id)
            self.save_memories()
            return True

    def get_stats(self) -> Dict[str, Any]:
        """获取记忆系统统计信息。

        Returns:
            包含总数、各类别计数、平均强度等统计数据的字典。
        """
        with self.lock:
            total: int = len(self.memories)
            type_counts: Dict[str, int] = {k: len(v) for k, v in self.index_by_type.items()}
            avg_strength: float = (
                sum(m.strength for m in self.memories.values()) / total
                if total > 0
                else 0.0
            )
            return {
                "total": total,
                "by_type": type_counts,
                "avg_strength": avg_strength,
            }

    def timeline(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取最近记忆的时间线。

        Args:
            limit: 返回的最大条目数。

        Returns:
            记忆摘要列表。
        """
        with self.lock:
            result: List[Dict[str, Any]] = []
            for mid in self.index_by_time[:limit]:
                if mid in self.memories:
                    mem = self.memories[mid]
                    result.append({
                        "id": mem.memory_id,
                        "content": mem.content[:100],
                        "type": mem.memory_type,
                        "time": mem.created_at,
                        "strength": mem.strength,
                    })
            return result

    def _generate_embedding(self, text: str) -> List[float]:
        """生成简化版文本向量。

        Args:
            text: 输入文本。

        Returns:
            32 维归一化向量。
        """
        import hashlib
        hash_obj = hashlib.md5(text.encode("utf-8"))
        raw: List[float] = [float(b) / 255.0 for b in hash_obj.digest()[:32]]
        norm: float = math.sqrt(sum(x * x for x in raw))
        if norm > 0:
            raw = [x / norm for x in raw]
        return raw

    def _cosine_similarity(self, v1: List[float], v2: List[float]) -> float:
        """计算两个向量的余弦相似度。

        Args:
            v1: 第一个向量。
            v2: 第二个向量。

        Returns:
            相似度分数 0-1。
        """
        dot: float = sum(a * b for a, b in zip(v1, v2))
        norm1: float = math.sqrt(sum(a * a for a in v1))
        norm2: float = math.sqrt(sum(b * b for b in v2))
        if norm1 == 0 or norm2 == 0:
            return 0.0
        return dot / (norm1 * norm2)
