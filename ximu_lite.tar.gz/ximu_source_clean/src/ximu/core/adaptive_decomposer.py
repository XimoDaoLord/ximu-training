from __future__ import annotations
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

__version__ = "0.5"

# 护栏常量（自适应，不写死档位数量）
MAX_RECURSION_DEPTH: int = 5  # 最大递归深度 <=5
MAX_DIRECT_CHILDREN: int = 40  # 单节点直接子任务数 <=40
MAX_TOTAL_SUBTASKS: int = 200  # 总子任务数软上限（触顶转聚合/人工澄清）
TOKEN_BUDGET_HINT: int = 120_000  # Token 预算提示（粗略：每子任务约 1k token）

# 复杂度区间提示（仅提示，不强制硬档位）
COMPLEXITY_HINT: Dict[str, Tuple[int, int]] = {
    "simple": (1, 3),
    "medium": (3, 7),
    "complex": (6, 15),
    "extreme": (10, 40),
}

# 阶段关键词（中文）：用于阶段切分
_STAGE_KEYWORDS: List[Tuple[str, List[str]]] = [
    ("调研", ["调研", "收集", "搜集", "分析现状", "research"]),
    ("实现", ["实现", "开发", "编码", "code", "implement"]),
    ("测试", ["测试", "验证", "test", "verify"]),
    ("文档", ["文档", "撰写文档", "doc", "readme"]),
    ("汇总", ["汇总", "对比", "总结", "最终", "对比表", "summary"]),
]

# 交付物关键词
_DELIVERABLE_HINTS: List[str] = ["代码", "测试", "文档", "报告", "表格", "对比表", "原型", "清单"]

# P103：自然语言交付物识别表。 (显示名, [关键词...])。按文本中关键词首次出现位置排序，保序去重；关键词越长越优先匹配（在 _find_deliverables 内对每组关键词按长度降序）。
_NL_DELIVERABLES: List[Tuple[str, List[str]]] = [
    (
        "登录注册与鉴权",
        ["登录注册", "登录", "注册", "鉴权", "认证", "登陆", "sign up", "signin", "login", "auth", "oauth", "权限认证"],
    ),
    (
        "前端页面开发",
        ["前端页面", "前端", "页面", "界面", "网页", "ui", "UI", "视图", "前端开发", "页面开发", "h5", "H5"],
    ),
    (
        "后端接口开发",
        ["后端接口", "后端", "接口", "api", "API", "服务端", "后台", "后端开发", "服务开发", "微服务", "接口开发"],
    ),
    (
        "数据库表结构设计",
        ["数据库表", "数据库", "数据表", "表结构", "schema", "Schema", "数据存储", "建表", "设计表", "db", "MySQL", "mysql", "Redis"],
    ),
    (
        "代码实现",
        ["写代码", "代码实现", "编码", "代码", "编程", "实现", "开发功能", "写功能", "code", "function", "函数实现"],
    ),
    (
        "测试编写",
        ["测试用例", "写测试", "单元测试", "测试代码", "测试", "验证", "test", "QA", "qa", "回归测试"],
    ),
    (
        "文档编写",
        ["写文档", "说明文档", "文档", "readme", "README", "doc", "使用说明", "接口文档"],
    ),
    (
        "部署与运维",
        ["部署", "运维", "上线", "发布", "docker", "Docker", "容器", "CI/CD"],
    ),
]

# P160·P1：工具需求关键词表（按工具名 → [关键词列表]）。用于 decompose 时根据任务文本推断子任务所需工具，填入 tools 字段。每个工具至少匹配一个关键词才会被分配；纯聊天/问候类任务不匹配任何工具。
_TOOL_KEYWORDS: List[Tuple[str, List[str]]] = [
    (
        "file_read",
        [
            "读取",
            "读文件",
            "读配置",
            "查看文件",
            "打开文件",
            "读一下",
            "看一下文件",
            "read",
            "read_file",
            "open file",
            "查看配置",
            "配置文件",
            "读配置文件",
            "检查格式",
            "检查文件",
            "读取配置",
            "parse config",
        ],
    ),
    (
        "file_write",
        [
            "写入",
            "写文件",
            "保存",
            "写入文件",
            "创建文件",
            "保存文件",
            "write",
            "save",
            "create file",
            "输出文件",
            "生成文件",
            "落盘",
        ],
    ),
    (
        "file_search",
        [
            "搜索文件",
            "查找文件",
            "找文件",
            "glob",
            "find file",
            "检索文件",
            "搜索目录",
            "查找目录",
            "找目录",
            "搜索文件夹",
        ],
    ),
    (
        "file_copy",
        ["复制", "拷贝", "复制文件", "copy", "copy file"],
    ),
    (
        "file_delete",
        ["删除", "删文件", "删除文件", "delete", "remove file", "清理文件"],
    ),
    (
        "code_execute",
        [
            "写代码",
            "编码",
            "函数",
            "排序函数",
            "写一个",
            "实现函数",
            "code",
            "python",
            "Python",
            "编程",
            "写功能",
            "开发功能",
            "算法",
            "排序",
            "function",
            "implement",
            "代码实现",
            "写脚本",
            "写程序",
            "写函数",
        ],
    ),
    (
        "code_review",
        ["代码审查", "review", "review code", "审查代码", "检查代码", "code review"],
    ),
    (
        "code_refactor",
        ["重构", "refactor", "重构代码", "优化代码"],
    ),
    (
        "code_test",
        ["写测试", "单元测试", "测试用例", "test", "写测试用例", "pytest", "测试代码", "验证测试"],
    ),
    (
        "web_search",
        [
            "搜索",
            "最新",
            "新闻",
            "查找",
            "search",
            "research",
            "搜索最新",
            "查一下",
            "查资料",
            "调研",
            "搜集",
            "收集信息",
            "web search",
            "google",
            "百度",
            "网上搜",
        ],
    ),
    (
        "web_scrape",
        ["抓取", "爬取", "scrape", "crawl", "采集网页", "网页内容"],
    ),
    (
        "web_download",
        ["下载", "download", "下载文件", "下载数据"],
    ),
    (
        "http_get",
        ["请求", "http", "HTTP", "调用接口", "获取数据", "GET", "api请求"],
    ),
    (
        "http_post",
        ["提交", "post", "POST", "发送请求", "提交数据"],
    ),
    (
        "shell_exec",
        ["执行命令", "运行命令", "shell", "命令行", "terminal", "bash", "执行脚本", "运行脚本", "cmd"],
    ),
    (
        "database_query",
        [
            "数据库",
            "查询",
            "SQL",
            "sql",
            "表结构",
            "查询数据",
            "db",
            "MySQL",
            "mysql",
            "Redis",
            "redis",
            "建表",
            "schema",
        ],
    ),
    (
        "data_transform",
        ["转换", "清洗", "format", "转换格式", "数据处理", "处理数据"],
    ),
    (
        "data_aggregate",
        ["聚合", "统计", "汇总数据", "sum", "average", "count"],
    ),
    (
        "json_parse",
        ["json", "JSON", "解析json", "json解析"],
    ),
    (
        "csv_parse",
        ["csv", "CSV", "读csv", "csv文件"],
    ),
    (
        "text_summarize",
        ["总结", "摘要", "概括", "summarize", "summary", "提炼"],
    ),
    (
        "text_translate",
        ["翻译", "translate", "translation"],
    ),
    (
        "text_classify",
        ["分类", "classification", "归类"],
    ),
    (
        "text_extract",
        ["提取", "抽取", "extract", "提取信息"],
    ),
    (
        "image_read",
        ["图片", "图像", "image", "查看图片", "读图"],
    ),
    (
        "image_convert",
        ["图片转换", "格式转换", "convert image"],
    ),
    (
        "image_analyze",
        ["分析图片", "图像分析", "analyze image"],
    ),
    (
        "image_ocr",
        ["OCR", "ocr", "文字识别"],
    ),
    (
        "audio_transcribe",
        ["音频转写", "语音转文字", "transcribe", "录音转写"],
    ),
    (
        "video_analyze",
        ["视频分析", "video", "分析视频"],
    ),
    (
        "email_send",
        ["发邮件", "邮件", "email", "send email"],
    ),
    (
        "message_push",
        ["推送", "通知", "push", "发消息"],
    ),
    (
        "webhook_trigger",
        ["webhook", "Webhook", "触发webhook"],
    ),
    (
        "memory_store",
        ["记忆", "存储记忆", "记住", "memory store"],
    ),
    (
        "memory_recall",
        ["回忆", "记忆召回", "recall", "回想"],
    ),
    (
        "task_schedule",
        ["调度", "定时", "schedule", "排期"],
    ),
    (
        "task_monitor",
        ["监控", "monitor", "监视"],
    ),
    (
        "flow_create",
        ["工作流", "flow", "流程", "workflow"],
    ),
    (
        "llm_invoke",
        ["大模型", "LLM", "llm", "调用模型", "模型调用"],
    ),
]

# 纯聊天/问候类关键词 → 不分配任何工具（tools=[]）
_CHAT_ONLY_KEYWORDS: List[str] = [
    "你好",
    "您好",
    "hi",
    "Hello",
    "hello",
    "嗨",
    "在吗",
    "在么",
    "谢谢",
    "感谢",
    "再见",
    "拜拜",
    "好的",
    "ok",
    "OK",
]

# 编号阶段正则：阶段一 / 阶段二 ... 第N阶段 / 阶段1 / 第1阶段
_CN_NUM: str = "一二三四五六七八九十"
_NUMBERED_STAGE_RE: re.Pattern[str] = re.compile(
    rf"阶段\s*[{_CN_NUM}0-9]+|第\s*[{_CN_NUM}0-9]+\s*阶段"
)

# 阶段标签清洗：去掉首尾顿号/逗号/冒号/空白
_STAGE_LABEL_CLEAN_RE: re.Pattern[str] = re.compile(r"^[、，,；;：:\s\-–—]+|[、，,；;。\s]+$")


@dataclass
class DecompNode:
    """分解树节点 / DAG 节点。"""

    node_id: str
    name: str
    description: str
    depth: int = 0
    parent_id: Optional[str] = None
    children: List[str] = field(default_factory=list)
    parents: List[str] = field(default_factory=list)
    rationale: str = ""
    atomic: bool = False
    deliverable: str = ""
    stage: str = ""
    tools: List[str] = field(default_factory=list)
    est_tokens: int = 0
    status: str = "pending"
    wave: int = 0
    terminal: bool = False


class AdaptiveDecomposer:
    """自适应递归任务分解器（确定性规则回退 + 可选 LLM 增强）。"""

    def __init__(
        self,
        llm_caller: Optional[Any] = None,
        max_depth: int = MAX_RECURSION_DEPTH,
        max_children: int = MAX_DIRECT_CHILDREN,
        total_budget: int = MAX_TOTAL_SUBTASKS,
    ) -> None:
        self._llm = llm_caller
        self._max_depth = max_depth
        self._max_children = max_children
        self._total_budget = total_budget
        self._nodes: Dict[str, DecompNode] = {}
        self._counter = 0
        self.replan_events: List[Dict[str, Any]] = []
        self._schemes: List[str] = []
        self._artifacts: List[str] = []
        self._need_summary = False
        self._root_used_schemes: bool = False
        self._experience_hint: str = ""

    def decompose(self, task_text: str, task_id: str = "root") -> Dict[str, Any]:
        """对原始任务做自适应递归分解，返回可观测结果 dict。"""
        self._nodes.clear()
        self._counter = 0
        self.replan_events = []
        task_text = str(task_text or "").strip()
        complexity = self._estimate_complexity(task_text)
        self._schemes = self._find_schemes(task_text)
        self._artifacts = self._find_artifacts(task_text)
        self._need_summary = (
            "汇总" in task_text or "对比表" in task_text or "总结" in task_text
        )
        self._experience_hint = ""
        try:
            from src.ximu.core.experience_library import lookup_experience_context

            self._experience_hint = lookup_experience_context(task_text) or ""
        except Exception:
            pass
        root = self._mk_node(task_text[:60] or "root", task_text, depth=0, rationale="根任务：按交付物/阶段/工具边界自适应递归下钻")
        root.deliverable = "整体"
        self._drill(root, task_text, complexity)
        if self._need_summary and self._schemes:
            self._add_summary_node(root)
        self._merge_fragmented(root)
        self._infer_dependencies(root)
        waves = self._compute_waves()
        valid, reason = self._has_cycle()
        return self._observable(root, complexity, waves, valid, reason)

    def _estimate_complexity(self, text: str) -> str:
        """启发式复杂度：simple/medium/complex/extreme（仅给区间提示）。"""
        score = 0
        score += min(30, len(self._find_schemes(text)) * 10)
        score += min(15, len(self._find_artifacts(text)) * 5)
        score += min(36, len(self._find_deliverables(text)) * 12)
        score += min(24, len(self._find_numbered_stages(text)) * 6)
        score += min(30, len(self._find_stages(text)) * 8)
        score += min(20, len(re.findall(r"[，,；;、]|和|与|及|每个|各", text)) * 2)
        if score >= 70:
            return "extreme"
        if score >= 45:
            return "complex"
        if score >= 20:
            return "medium"
        return "simple"

    def _mk_node(self, name: str, description: str, depth: int, rationale: str = "") -> DecompNode:
        self._counter += 1
        nid = f"n{self._counter:04d}"
        n = DecompNode(node_id=nid, name=name, description=description, depth=depth, rationale=rationale)
        self._nodes[nid] = n
        return n

    def _estimate_tokens(self, text: str) -> int:
        """粗略 token 估算：中文约 1.5 字/token，封顶。"""
        return min(8000, max(200, len(text) // 2))

    # ...[中间省略]...

    def _find_deliverables(self, text: str) -> List[str]:
        """识别自然语言交付物。"""
        if not text:
            return []
        t = str(text).strip()
        if len(t) <= 12 and any(kw.lower() in t.lower() for kw in _CHAT_ONLY_KEYWORDS):
            return []
        found: List[str] = []
        seen = set()
        for tool_name, kws in _TOOL_KEYWORDS:
            if tool_name in seen:
                continue
            for kw in kws:
                if kw.lower() in t.lower():
                    found.append(tool_name)
                    seen.add(tool_name)
                    break
        return found

    def _estimate_tokens_complexity(self, text: str, complexity: str = "simple", tools: Optional[List[str]] = None) -> int:
        """估算 token 需求：基础长度 + 工具加成 + 复杂度加成。"""
        base = len(text) // 2
        tool_bonus = (len(tools) if tools else 0) * 150
        mult = {"simple": 1.0, "medium": 1.5, "complex": 2.0, "extreme": 3.0}.get(complexity, 1.0)
        val = int((base + tool_bonus) * mult)
        return min(8000, max(200, val))

    # ...[中间省略]...

    def _observable(self, root: DecompNode, complexity: str, waves: int, valid: bool, reason: str) -> Dict[str, Any]:
        """返回可观测结果 dict。"""
        return {
            "planned_count": len(self._nodes),
            "tree_depth": root.depth,
            "rationale": root.rationale,
            "replan_events": self.replan_events,
        }
