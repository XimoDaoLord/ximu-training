"""
重写的forgetting_logic模块，提供忘记逻辑的核心功能。
"""
from __future__ import annotations
import importlib as _il
import logging as _logging
from typing import Dict, Any

_PARTS: tuple[str, ...] = ("part1", "part2", "part3")
_cache: Dict[str, Any] | None = None

def _load() -> Dict[str, Any]:
    """
    加载部分逻辑模块，并缓存公共名称。
    
    :return: 模块名称与模块实例的字典
    """
    global _cache
    if _cache is not None:
        return _cache
    
    try:
        # 加载部分逻辑模块
        modules: Dict[str, Any] = {}
        for part in _PARTS:
            module = _il.import_module(f"._forgetting_logic_parts.{part}", package=__package__)
            for name in dir(module):
                if not name.startswith("_"):
                    modules[name] = getattr(module, name)
        _cache = modules
        return modules
    except Exception as e:
        # 日志记录异常
        _logging.warning(f"加载部分逻辑模块失败：{e}")
        return {}

def __getattr__(name: str) -> Any:
    """
    获取模块属性。
    
    :param name: 属性名称
    :return: 属性值
    :raises AttributeError: 属性不存在
    """
    if name.startswith("_"):
        raise AttributeError(name)
    
    # 加载部分逻辑模块
    modules = _load()
    
    try:
        # 获取属性值
        return modules[name]
    except KeyError:
        # 日志记录异常
        _logging.warning(f"模块{__name__}没有属性'{name}'")
        raise AttributeError(f"模块{__name__}没有属性'{name}'")

# 重写的公共API
__all__ = ["_load", "__getattr__"]
