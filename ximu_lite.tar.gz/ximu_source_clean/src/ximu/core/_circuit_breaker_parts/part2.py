"""带TTL和LRU淘汰机制的线程安全键值存储模块。

提供可配置的本地内存缓存解决方案，支持数据过期、软删除和统计指标收集。
包含多种存储实现以满足不同场景需求。
"""

import logging
from collections import OrderedDict
from threading import RLock,RLock
from time import monotonic
from typing import Any, Dict, List, Optional, Tuple, TypeVar, Union
from dataclasses import dataclass, field

logger = logging.getLogger("src.ximu.core._circuit_breaker_parts.part2")

K = TypeVar("K")
V = TypeVar("V")

@dataclass
class Statistic:
    """统计指标数据结构"""
    hit_count: int = 0
    miss_count: int = 0
    eviction_count: int = 0
    write_count: int = 0
    cleanup_count: int = 0

class BaseTtlLruStore:
    """线程安全的基础存储基类，提供锁管理、统计指标收集和LRU淘汰逻辑。

    该类实现了基本的并发控制和统计数据跟踪功能，
    并将LRU淘汰逻辑下沉到基类以减少子类重复代码。
    """
    
    def __init__(self, max_size: int = 10000, ttl: float = 3600.0, name: str = "") -> None:
        """初始化存储基类。

        :param max_size: 最大存储数量限制，超过此值触发LRU淘汰
        :param ttl: 数据有效期（秒），0表示永不过期
        :param name: 存储名称，用于日志标识
        """
        self._lock = RLock()
        self._max_size = max_size
        self._ttl = ttl
        self._name = name or self.__class__.__name__
        self._data: OrderedDict[K, Tuple[V, float]] = OrderedDict()
        self._stats = Statistic()
        self._version = 0

    def _check_expiration(self, timestamp: float) -> bool:
        """检查指定时间戳的数据是否已过期。

        :param timestamp: 数据写入时的monotonic时间戳
        :return: 如果已过期返回True，否则返回False
        """
        if self._ttl <= 0:
            return False
        return monotonic() - timestamp > self._ttl

    def _update_stats(self, event: str) -> None:
        """更新统计指标计数器。

        :param event: 事件类型，可选值为hit/miss/eviction/write/cleanup
        :raises KeyError: 当事件类型无效时
        """
        stat_map = {
            'hit': 'hit_count',
            'miss': 'miss_count',
            'eviction': 'eviction_count',
            'write': 'write_count',
            'cleanup': 'cleanup_count'
        }
        if event in stat_map:
            setattr(self._stats, stat_map[event], getattr(self._stats, stat_map[event]) + 1)

    @property
    def stats(self) -> Statistic:
        """获取当前统计指标副本。

        :return: 包含各项统计计数的Statistic对象
        """
        return self._stats

    @property
    def size(self) -> int:
        """获取当前存储中的数据数量。

        :return: 当前存储的键值对数量
        """
        return len(self._data)

    def _snapshot(self) -> Dict[K, V]:
        """生成当前数据的快照（不锁定）。

        :return: 包含所有有效数据的浅拷贝字典
        """
        return {k: v[0] for k, v in self._data.items()}

    def _move_to_end_or_evict(self, key: K) -> None:
        """移动键到末尾或执行LRU淘汰。

        :param key: 新插入或访问的键
        """
        self._data.move_to_end(key)
        if len(self._data) > self._max_size:
            self._evict_lru()

    def _evict_lru(self) -> None:
        """执行LRU淘汰，移除最久未使用的条目。

        OrderedDict的迭代顺序保持插入/访问顺序，
        第一个元素即为最久未使用的条目。
        """
        try:
            evicted_key, _ = self._data.popitem(last=False)
            self._update_stats('eviction')
            logger.debug(f"存储'{self._name}'淘汰LRU键: {evicted_key}")
        except Exception as e:
            logger.error(f"存储'{self._name}'淘汰失败: {e}")

    def cleanup(self) -> int:
        """清理所有过期数据（由子类实现具体逻辑）。

        :return: 清理的过期数据数量
        """
        raise NotImplementedError("子类必须实现cleanup方法")

class TtlLruStore(BaseTtlLruStore):
    """带TTL和LRU淘汰的字典存储实现。

    数据同时受时间过期和LRU顺序约束，
    适用于需要自动清理过期数据的缓存场景。
    """

    def put(self, key: K, value: V) -> None:
        """插入或更新数据。

        :param key: 存储键
        :param value: 存储值
        :raises Exception: 当存储操作失败时抛出
        """
        with self._lock:
            try:
                self._version += 1
                self._data[key] = (value, monotonic())
                self._update_stats('write')
                self._move_to_end_or_evict(key)
            except Exception as e:
                logger.error(f"存储'{self._name}'插入失败: {e}")
                raise

    def get(self, key: K, default: Optional[V] = None) -> Union[V, Any]:
        """获取数据（含过期检查）。

        :param key: 查询键
        :param default: 键不存在或过期时的默认返回值
        :return: 存储的值或默认值
        """
        with self._lock:
            if key not in self._data:
                self._update_stats('miss')
                return default
            value, timestamp = self._data[key]
            if self._check_expiration(timestamp):
                self._data.pop(key)
                self._update_stats('miss')
                return default
            self._update_stats('hit')
            self._data.move_to_end(key)
            return value

    def contains(self, key: K) -> bool:
        """检查数据是否存在且未过期。

        :param key: 查询键
        :return: 如果数据存在且未过期返回True
        """
        with self._lock:
            if key not in self._data:
                return False
            _, timestamp = self._data[key]
            return not self._check_expiration(timestamp)

    def cleanup(self) -> int:
        """清理所有过期数据。

        :return: 清理的过期数据数量
        """
        with self._lock:
            expired_count = 0
            keys_to_remove = []
            for key in list(self._data.keys()):
                _, timestamp = self._data[key]
                if self._check_expiration(timestamp):
                    keys_to_remove.append(key)
            for key in keys_to_remove:
                self._data.pop(key)
                expired_count += 1
            if expired_count > 0:
                self._update_stats('cleanup')
                logger.debug(f"存储'{self._name}'清理{expired_count}条过期数据")
            return expired_count

class SoftDeleteTtlLruStore(BaseTtlLruStore):
    """带软删除机制的存储实现。

    通过版本号控制删除状态，支持延迟清理。
    软删除后数据仍保留直到显式清理或下次写入覆盖。
    """

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0, name: str = "") -> None:
        """初始化软删除存储。

        :param max_size: 最大存储数量限制
        :param ttl: 数据有效期（秒）
        :param name: 存储名称
        """
        super().__init__(max_size=max_size, ttl=ttl, name=name)
        self._version: int = 1  # 初始化版本号，防止put时未定义错误

    def put(self, key: K, value: V) -> None:
        """插入或更新数据（清除软删除状态）。

        :param key: 存储键
        :param value: 存储值
        """
        with self._lock:
            try:
                self._version += 1
                self._data[key] = (value, self._version)
                self._update_stats('write')
                self._move_to_end_or_evict(key)
            except Exception as e:
                logger.error(f"存储'{self._name}'插入失败: {e}")
                raise

    def remove(self, key: K) -> bool:
        """标记数据为软删除状态。

        :param key: 要删除的键
        :return: 如果键存在且成功标记删除返回True
        """
        with self._lock:
            if key not in self._data:
                return False
            _, current_version = self._data[key]
            if current_version != self._version:
                return False
            self._data[key] = (self._data[key][0], self._version + 1)
            return True

    def contains(self, key: K) -> bool:
        """检查数据是否存在且未被软删除。

        :param key: 查询键
        :return: 如果数据存在且未删除返回True
        """
        with self._lock:
            if key not in self._data:
                return False
            _, version = self._data[key]
            return version == self._version

    def cleanup(self) -> int:
        """清理所有软删除的数据。

        :return: 清理的已删除数据数量
        """
        with self._lock:
            deleted_count = 0
            keys_to_remove = []
            for key in list(self._data.keys()):
                _, version = self._data[key]
                if version > self._version:
                    keys_to_remove.append(key)
            for key in keys_to_remove:
                self._data.pop(key)
                deleted_count += 1
            if deleted_count > 0:
                self._update_stats('cleanup')
                logger.debug(f"存储'{self._name}'清理{deleted_count}条软删除数据")
            return deleted_count

class ConfigurableStore(BaseTtlLruStore):
    """支持动态配置参数的存储基类。

    可通过configure方法动态修改max_size和ttl参数。
    """

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        """初始化可配置存储。

        :param max_size: 最大存储数量
        :param ttl: 数据有效期（秒）
        """
        super().__init__(max_size=max_size, ttl=ttl)
        self._config: Dict[str, Any] = {
            'max_size': max_size,
            'ttl': ttl
        }

    def configure(self, **kwargs: Any) -> None:
        """动态配置存储器参数。

        :param kwargs: 配置参数键值对，支持max_size和ttl
        :raises ValueError: 当配置参数无效时
        """
        with self._lock:
            try:
                for k, v in kwargs.items():
                    if k in self._config:
                        if k == 'max_size' and v <= 0:
                            raise ValueError(f"max_size必须为正数，当前值: {v}")
                        elif k == 'ttl' and v < 0:
                            raise ValueError(f"ttl不能为负数，当前值: {v}")
                        self._config[k] = v
                        setattr(self, f"_{k}", v)
                        logger.info(f"存储'{self._name}'配置更新: {k}={v}")
            except Exception as e:
                logger.error(f"存储'{self._name}'配置更新失败: {e}")
                raise

class SnapshotStore(ConfigurableStore):
    """快照存储实现，使用较大容量和较长TTL。

    默认配置：max_size=100000, ttl=86400秒（24小时）
    """

    def __init__(self, max_size: int = 100000, ttl: float = 86400.0) -> None:
        """初始化快照存储。

        :param max_size: 最大存储数量，默认100000
        :param ttl: 数据有效期（秒），默认86400
        """
        super().__init__(max_size=max_size, ttl=ttl, name="SnapshotStore")

class IndexStore(ConfigurableStore):
    """索引存储实现，使用较大容量和超长TTL。

    默认配置：max_size=100000, ttl=2592000秒（30天）
    """

    def __init__(self, max_size: int = 100000, ttl: float = 2592000.0) -> None:
        """初始化索引存储。

        :param max_size: 最大存储数量，默认100000
        :param ttl: 数据有效期（秒），默认2592000
        """
        super().__init__(max_size=max_size, ttl=ttl, name="IndexStore")

def create_store(
    store_type: str,
    max_size: int = 10000,
    ttl: float = 3600.0,
    use_soft_delete: bool = False
) -> Union[TtlLruStore, SoftDeleteTtlLruStore, SnapshotStore, IndexStore]:
    """创建并返回相应类型的存储实例。

    :param store_type: 存储类型，可选值为'ttl'、'soft_delete'、'snapshot'、'index'
    :param max_size: 最大存储数量
    :param ttl: 数据有效期（秒）
    :param use_soft_delete: 是否启用软删除（仅对ttl类型有效）
    :return: 创建的存储实例
    :raises ValueError: 当store_type无效时
    """
    if store_type == 'snapshot':
        return SnapshotStore(max_size=max_size, ttl=ttl)
    elif store_type == 'index':
        return IndexStore(max_size=max_size, ttl=ttl)
    elif store_type == 'soft_delete':
        return SoftDeleteTtlLruStore(max_size=max_size, ttl=ttl, name="SoftDeleteStore")
    elif store_type == 'ttl':
        return TtlLruStore(max_size=max_size, ttl=ttl, name="TtlStore")
    else:
        raise ValueError(f"未知的存储类型: {store_type}")
