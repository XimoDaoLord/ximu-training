"""
熔断器指标采集模块 - Part 4

提供线程安全的指标采集、滑动窗口统计与熔断状态管理。
基于时间戳的分段环形缓冲区优化了查询性能，统一了锁模型以避免竞态条件，
并引入基于数据变更的缓存失效机制以提升缓存有效性。
"""

import logging
import threading
import time
from collections import OrderedDict, deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Deque, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_DEFAULT_WINDOW_SECONDS: float = 60.0
_MAX_CACHE_SIZE: int = 100
_MIN_SEGMENT_SIZE: float = 0.5
_MAX_SEGMENT_SIZE: float = 5.0


class CircuitState(Enum):
    """熔断器状态枚举。"""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass(frozen=True)
class WindowStats:
    """滑动窗口统计数据。"""

    count: int = 0
    sum_val: float = 0.0
    avg: float = 0.0
    min_val: float = float("inf")
    max_val: float = float("-inf")
    timestamp: float = 0.0


class _SegmentedHistory:
    """分段环形历史记录器。"""

    def __init__(self, segment_size: float = 1.0, max_segments: int = 3600) -> None:
        if segment_size <= 0:
            raise ValueError("segment_size 必须为正数")
        if max_segments <= 0:
            raise ValueError("max_segments 必须为正数")

        self._segment_size: float = segment_size
        self._max_segments: int = max_segments
        self._segments: Dict[int, List[Tuple[float, str, float]]] = {}
        self._oldest_index: int = 0
        self._newest_index: int = -1
        self._lock: threading.RLock = threading.RLock()

    def _to_index(self, timestamp: float) -> int:
        return int(timestamp / self._segment_size)

    def append(self, timestamp: float, metric: str, value: float) -> None:
        with self._lock:
            idx = self._to_index(timestamp)

            if idx < self._oldest_index:
                self._reset_internal(idx)
            elif idx == self._oldest_index:
                self._segments.setdefault(idx, []).append((timestamp, metric, value))
            else:
                self._newest_index = idx
                self._segments[idx] = [(timestamp, metric, value)]

                while (self._newest_index - self._oldest_index + 1) > self._max_segments:
                    del self._segments[self._oldest_index]
                    self._oldest_index += 1

    def _reset_internal(self, current_idx: int) -> None:
        self._segments.clear()
        self._oldest_index = current_idx
        self._newest_index = current_idx
        self._segments[current_idx] = []

    def reset(self) -> None:
        with self._lock:
            self._segments.clear()
            self._oldest_index = 0
            self._newest_index = -1

    def query(self, metric: str, cutoff: float, now: float) -> List[float]:
        with self._lock:
            start_idx = self._to_index(cutoff)
            end_idx = self._to_index(now)
            results: List[float] = []

            for idx in range(start_idx, end_idx + 1):
                bucket = self._segments.get(idx)
                if bucket is None:
                    continue
                for t, m, v in bucket:
                    if m == metric and cutoff <= t <= now:
                        results.append(v)
            return results

    def count(self, metric: str, cutoff: float, now: float) -> int:
        with self._lock:
            start_idx = self._to_index(cutoff)
            end_idx = self._to_index(now)
            count = 0

            for idx in range(start_idx, end_idx + 1):
                bucket = self._segments.get(idx)
                if bucket is None:
                    continue
                for t, m, _ in bucket:
                    if m == metric and cutoff <= t <= now:
                        count += 1
            return count

    def clear(self) -> None:
        self.reset()


class MetricCollector:
    """线程安全的指标采集器。"""

    def __init__(self, name: str, window_seconds: float = _DEFAULT_WINDOW_SECONDS) -> None:
        if window_seconds <= 0:
            raise ValueError(f"窗口时间必须为正数，当前值: {window_seconds}")

        self.name: str = name
        self._window: float = window_seconds
        self._lock: threading.RLock = threading.RLock()
        self._data: Dict[str, float] = {}
        self._history: _SegmentedHistory = self._create_history(window_seconds)
        self._cache: OrderedDict[Tuple[str, float], Tuple[WindowStats, float]] = OrderedDict()
        self._MAX_CACHE_AGE: float = 30.0

    def _create_history(self, window_seconds: float) -> _SegmentedHistory:
        segment_size = min(max(window_seconds / 60.0, _MIN_SEGMENT_SIZE), _MAX_SEGMENT_SIZE)
        max_segments = max(10, int(window_seconds / segment_size) + 1)
        logger.debug("创建历史记录器: segment_size=%.2f, max_segments=%d", segment_size, max_segments)
        return _SegmentedHistory(segment_size, max_segments)

    def _now_timestamp(self) -> float:
        return time.time()

    def _evict_stale_cache(self, now: float) -> None:
        stale_keys = [
            key for key, (stats, timestamp) in self._cache.items()
            if now - timestamp > self._MAX_CACHE_AGE
        ]

        for key in stale_keys:
            del self._cache[key]

        while len(self._cache) > _MAX_CACHE_SIZE:
            self._cache.popitem(last=False)

    def record(self, metric: str, value: float = 1.0) -> None:
        with self._lock:
            old_value = self._data.get(metric, 0.0)
            self._data[metric] = old_value + value
            current_time = self._now_timestamp()
            self._history.append(current_time, metric, value)
            if old_value != self._data[metric]:
                self._cache.clear()

    def get(self, metric: str) -> float:
        with self._lock:
            return self._data.get(metric, 0.0)

    def reset(self, metric: str) -> None:
        with self._lock:
            if metric in self._data:
                del self._data[metric]
                self._cache.clear()

    def get_all(self) -> Dict[str, float]:
        with self._lock:
            return dict(self._data)

    def get_rate(self, metric: str, window: Optional[float] = None) -> float:
        effective_window = window if window is not None else self._window
        if effective_window <= 0:
            return 0.0

        with self._lock:
            now = self._now_timestamp()
            cutoff = now - effective_window
            count = self._history.count(metric, cutoff, now)
            return count / effective_window

    def get_window_stats(self, metric: str, window: Optional[float] = None) -> WindowStats:
        effective_window = window if window is not None else self._window
        if effective_window <= 0:
            return WindowStats(timestamp=self._now_timestamp())

        with self._lock:
            cache_key = (metric, effective_window)
            now = self._now_timestamp()
            cutoff = now - effective_window

            if cache_key in self._cache:
                cached_stats, cached_timestamp = self._cache[cache_key]
                if now - cached_timestamp <= self._MAX_CACHE_AGE:
                    self._cache.move_to_end(cache_key)
                    return cached_stats

            values = self._history.query(metric, cutoff, now)
            stats = self._build_stats_from_values(values, now)

            self._cache[cache_key] = (stats, now)
            self._evict_stale_cache(now)

            return stats

    def _build_stats_from_values(self, values: List[float], timestamp: float) -> WindowStats:
        if not values:
            return WindowStats(timestamp=timestamp)

        total = sum(values)
        count = len(values)
        return WindowStats(
            count=count,
            sum_val=total,
            avg=total / count,
            min_val=min(values),
            max_val=max(values),
            timestamp=timestamp,
        )

    def reset_all(self) -> None:
        with self._lock:
            self._data.clear()
            self._history.reset()
            self._cache.clear()

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "name": self.name,
                "metrics": dict(self._data),
                "window": self._window,
                "cache_size": len(self._cache),
            }


class BaseMetrics:
    """熔断器核心指标基类。"""

    def __init__(self, name: str, window_seconds: float = _DEFAULT_WINDOW_SECONDS) -> None:
        if not name:
            raise ValueError("指标名称不能为空")

        self._collector: MetricCollector = MetricCollector(name, window_seconds)
        self._state: CircuitState = CircuitState.CLOSED
        self._state_changed_at: float = self._collector._now_timestamp()
        self._lock: threading.RLock = threading.RLock()
        self._failure_threshold: float = 0.5
        self._success_threshold: float = 0.8
        self._half_open_max_calls: int = 10
        self._half_open_success_count: int = 0
        self._open_duration: float = 30.0

    @property
    def state(self) -> CircuitState:
        with self._lock:
            return self._state

    @state.setter
    def state(self, new_state: CircuitState) -> None:
        with self._lock:
            if new_state != self._state:
                old_state = self._state
                self._state = new_state
                self._state_changed_at = self._collector._now_timestamp()
                if new_state == CircuitState.HALF_OPEN:
                    self._half_open_success_count = 0
                logger.info(
                    "熔断状态变更: %s -> %s | metrics: %s",
                    old_state.value,
                    new_state.value,
                    self._collector.name,
                )

    def record(self, event: str, value: float = 1.0) -> None:
        self._collector.record(event, value)

    def get(self, metric: str) -> float:
        return self._collector.get(metric)

    def reset(self, metric: str) -> None:
        self._collector.reset(metric)

    def get_window_stats(self, metric: str, window: Optional[float] = None) -> WindowStats:
        return self._collector.get_window_stats(metric, window)

    def get_rate(self, metric: str, window: Optional[float] = None) -> float:
        return self._collector.get_rate(metric, window)

    def reset_all(self) -> None:
        self._collector.reset_all()
        with self._lock:
            self._state = CircuitState.CLOSED
            self._state_changed_at = self._collector._now_timestamp()
            self._half_open_success_count = 0

    def can_proceed(self) -> bool:
        with self._lock:
            if self._state == CircuitState.CLOSED:
                return True
            if self._state == CircuitState.OPEN:
                elapsed = self._collector._now_timestamp() - self._state_changed_at
                return elapsed >= self._open_duration
            return self._half_open_success_count < self._half_open_max_calls

    def evaluate_state_transition(self) -> None:
        with self._lock:
            if self._state == CircuitState.CLOSED:
                self._evaluate_closed()
            elif self._state == CircuitState.HALF_OPEN:
                self._evaluate_half_open()

    def _evaluate_closed(self) -> None:
        stats = self._collector.get_window_stats("success")
        failure_stats = self._collector.get_window_stats("failure")
        total = stats.count + failure_stats.count

        if total == 0:
            return

        failure_rate = failure_stats.count / total
        if failure_rate >= self._failure_threshold:
            self._state = CircuitState.OPEN
            self._state_changed_at = self._collector._now_timestamp()
            logger.warning(
                "熔断器打开: 失败率 %.2f >= 阈值 %.2f (总数: %d)",
                failure_rate,
                self._failure_threshold,
                total,
            )

    def _evaluate_half_open(self) -> None:
        if self._half_open_success_count >= self._success_threshold * self._half_open_max_calls:
            self._state = CircuitState.CLOSED
            self._state_changed_at = self._collector._now_timestamp()
            logger.info("熔断器关闭: 半开探测成功")
        elif self._half_open_success_count == 0:
            self._state = CircuitState.OPEN
            self._state_changed_at = self._collector._now_timestamp()
            logger.warning("熔断器重新打开: 半开探测失败")

    def on_success(self) -> None:
        self.record("success")
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                self._half_open_success_count += 1

    def on_failure(self) -> None:
        self.record("failure")

    def get_state_changed_at(self) -> float:
        with self._lock:
            return self._state_changed_at

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "name": self._collector.name,
                "state": self._state.value,
                "state_changed_at": self._state_changed_at,
                "metrics": self._collector.to_dict(),
            }


class BusinessMetrics(BaseMetrics):
    """业务指标采集器。"""

    def __init__(self, name: str, window_seconds: float = _DEFAULT_WINDOW_SECONDS) -> None:
        super().__init__(f"{name}_business", window_seconds)

    def record_success(self, latency: float = 0.0) -> None:
        if latency < 0:
            raise ValueError("延迟不能为负数")
        self.on_success()
        if latency > 0:
            self.record("latency", latency)

    def record_failure(self, reason: str = "unknown") -> None:
        self.on_failure()
        if reason:
            self.record(f"failure_{reason}", 1.0)

    def record_timeout(self) -> None:
        self.on_failure()
        self.record("timeout", 1.0)

    def get_success_count(self) -> float:
        return self.get("success")

    def get_failure_rate(self) -> float:
        failure = self.get("failure")
        timeout = self.get("timeout")
        total = failure + timeout
        if total == 0:
            return 0.0
        return min(failure / total, 1.0)

    def get_avg_latency(self) -> float:
        latency_sum = self.get("latency")
        success_count = self.get("success")
        if success_count == 0:
            return 0.0
        return latency_sum / success_count


class SecurityMetrics(BaseMetrics):
    """安全指标采集器。"""

    def __init__(self, name: str, window_seconds: float = _DEFAULT_WINDOW_SECONDS) -> None:
        super().__init__(f"{name}_security", window_seconds)

    def record_threat(self, blocked: bool = False) -> None:
        self.record("threat", 1.0)
        if blocked:
            self.record("blocked", 1.0)

    def get_block_rate(self) -> float:
        blocked = self.get("blocked")
        threat = self.get("threat")
        if threat == 0:
            return 0.0
        return min(blocked / threat, 1.0)


class StorageMetrics(BaseMetrics):
    """存储指标采集器。"""

    def __init__(self, name: str, window_seconds: float = _DEFAULT_WINDOW_SECONDS) -> None:
        super().__init__(f"{name}_storage", window_seconds)

    def record_read(self) -> None:
        self.record("read", 1.0)

    def record_write(self) -> None:
        self.record("write", 1.0)

    def record_update(self) -> None:
        self.record("update", 1.0)

    def get_read_write_ratio(self) -> float:
        read_count = self.get("read")
        write_count = self.get("write")
        update_count = self.get("update")
        denominator = write_count + update_count
        if denominator == 0:
            return 0.0
        return read_count / denominator
