"""
汐沫AI - 熔断器核心数据模型与工具函数模块
提供熔断器基础数据结构、通用工具函数及配置管理。
支持动态配置加载、指数退避重试、高精度计时等功能。
"""

import logging
import json
import os
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from enum import Enum
from functools import wraps
from typing import (
    Any,
    Callable,
    Deque,
    Dict,
    List,
    Optional,
    Tuple,
    Type,
    TypeVar,
    Union,
)

logger = logging.getLogger("src.ximu.core._circuit_breaker_parts.part1")

T = TypeVar("T")

LOCAL_WORKSPACE = os.environ.get("XIMU_WORKSPACE", "./local_workspace")

# 配置缓存
_config_cache: Optional[Dict[str, Any]] = None
_config_lock = threading.Lock()


def _load_config() -> None:
    """
    加载配置模块，支持重试机制。
    尝试从配置文件加载配置，失败时使用空配置并记录警告。
    使用线程锁保证配置只加载一次。
    """
    global _config_cache
    with _config_lock:
        if _config_cache is not None:
            return
    try:
        from config.settings import config as cfg, get_config as gc
        _config_cache = cfg if isinstance(cfg, dict) else {}
        logger.debug("配置加载成功，共 %d 个配置项", len(_config_cache))
    except Exception as e:
        logger.warning("配置模块加载失败，使用默认空配置: %s", e)
        _config_cache = {}
    logger.info("配置加载完成")


def generate_id(prefix: str = "id") -> str:
    """
    生成带有前缀的唯一标识符。

    Args:
        prefix: 标识符前缀，默认为'id'。

    Returns:
        唯一标识符字符串。
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


def now_timestamp() -> float:
    """
    获取当前秒级时间戳。

    Returns:
        当前秒级时间戳。
    """
    return time.time()


def now_timestamp_ms() -> int:
    """
    获取当前毫秒级时间戳。

    Returns:
        当前毫秒级时间戳。
    """
    return int(time.time() * 1000)


class Stopwatch:
    """
    线程安全的高精度计时器。
    使用monotonic时钟避免系统时间调整的影响，支持链式调用。
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._start: float = 0.0
        self._end: float = 0.0
        self._running: bool = False

    def start(self) -> "Stopwatch":
        """
        开始计时。

        Returns:
            自身引用以支持链式调用。
        """
        with self._lock:
            self._start = time.monotonic()
            self._running = True
        return self

    def stop(self) -> float:
        """
        停止计时。

        Returns:
            本次计时的总耗时（秒）。
        """
        with self._lock:
            if self._running:
                self._end = time.monotonic() - self._start
                self._running = False
                logger.debug("Stopwatch停止，耗时 %.4f 秒", self._end)
            return self._end

    def elapsed(self) -> float:
        """
        获取已耗时的累计时间（秒）。

        Returns:
            已耗时，如果正在运行则返回当前累计时间。
        """
        with self._lock:
            if self._running:
                return self._end + (time.monotonic() - self._start)
            return self._end


def retry_on_failure(max_retries: int = 3, delay: float = 0.1) -> Callable[[T], T]:
    """
    指数退避重试装饰器。
    支持从全局配置动态获取重试参数，优先使用函数参数，其次使用配置。

    Args:
        max_retries: 最大重试次数，可为None表示从配置读取。
        delay: 基础等待时间（秒），可为None表示从配置读取。

    Returns:
        装饰器函数。
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exception: Optional[Exception] = None
            retries = max_retries if max_retries is not None else 3
            wait_delay = delay if delay is not None else 0.1
            for attempt in range(retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < retries - 1:
                        wait_time = wait_delay * (2**attempt)
                        logger.debug(
                            "重试 %s (尝试 %d/%d)，等待 %.2f 秒: %s",
                            func.__name__,
                            attempt + 1,
                            retries,
                            wait_time,
                            str(e)[:100],
                        )
                        time.sleep(wait_time)
            if last_exception:
                logger.error("重试耗尽，最终错误: %s", str(last_exception)[:200])
                raise last_exception
            return None
        return wrapper
    return decorator


def safe_json_dumps(obj: Any, **kwargs: Any) -> str:
    """
    健壮的JSON序列化。

    Args:
        obj: 要序列化的对象。
        **kwargs: 传递给json.dumps的其他参数。

    Returns:
        JSON字符串。
    """
    kwargs.setdefault("ensure_ascii", False)
    kwargs.setdefault("default", str)
    try:
        return json.dumps(obj, **kwargs)
    except (TypeError, ValueError) as e:
        logger.error("JSON序列化失败: %s", e)
        raise


def safe_json_loads(json_str: str, **kwargs: Any) -> Optional[Union[Dict[str, Any], List[Any], Any]]:
    """
    健壮的JSON反序列化。

    Args:
        json_str: JSON字符串。
        **kwargs: 传递给json.loads的其他参数。

    Returns:
        解析后的字典、列表或其他类型，失败时返回None。
    """
    if not isinstance(json_str, str):
        logger.debug("JSON输入不是字符串: %s", type(json_str))
        return None
    try:
        result = json.loads(json_str, **kwargs)
        return result
    except (json.JSONDecodeError, TypeError) as e:
        logger.debug("JSON解析失败: %s", e)
        return None


# ============================================================================= #
# 核心枚举定义 #
# ============================================================================= #
class StatusType(Enum):
    """
    熔断器状态类型。
    枚举值说明:
        IDLE: 空闲状态，系统正常。
        ACTIVE: 活跃状态，处理请求。
        DEGRADED: 降级状态，性能下降但仍可服务。
        BROKEN: 熔断状态，请求被阻断。
        RECOVERING: 恢复状态，正在尝试恢复正常。
    """

    IDLE = "idle"
    ACTIVE = "active"
    DEGRADED = "degraded"
    BROKEN = "broken"
    RECOVERING = "recovering"


class PriorityLevel(Enum):
    """
    请求优先级级别。
    枚举值说明:
        LOW: 低优先级。
        MEDIUM: 中等优先级。
        HIGH: 高优先级。
        CRITICAL: 关键优先级。
        URGENT: 紧急优先级。
    """

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"
    URGENT = "urgent"


class OperationMode(Enum):
    """
    熔断器操作模式。
    枚举值说明:
        PASS_THROUGH: 透传模式，直接处理请求。
        OPEN: 熔断打开模式，拒绝所有请求。
        HALF_OPEN: 半开模式，允许部分请求测试。
        CLOSED: 熔断关闭模式，正常处理请求。
    """

    PASS_THROUGH = "pass_through"
    OPEN = "open"
    HALF_OPEN = "half_open"
    CLOSED = "closed"


class ErrorCodeCategory(Enum):
    """
    错误代码分类。
    枚举值说明:
        TIMEOUT: 超时错误。
        CONNECTION: 连接错误。
        VALIDATION: 验证错误。
        AUTHENTICATION: 认证错误。
        INTERNAL: 内部错误。
    """

    TIMEOUT = "timeout"
    CONNECTION = "connection"
    VALIDATION = "validation"
    AUTHENTICATION = "authentication"
    INTERNAL = "internal"


# ============================================================================= #
# 基础数据模型 #
# ============================================================================= #
@dataclass
class BaseCircuitMessage:
    """
    熔断器消息基类，消除数据类重复。
    字段说明:
        id: 唯一标识符，自动生成。
        timestamp: 消息时间戳（秒）。
        data: 消息数据字典。
        metadata: 元数据字典。
        status: 状态字符串，默认"pending"。
        priority: 优先级（1-10），数字越大优先级越高。
        retry_count: 已重试次数。
        max_retries: 最大重试次数。
        timeout_ms: 超时时间（毫秒）。
        created_at: 创建时间戳。
        updated_at: 更新时间戳。
        version: 消息版本。
        tags: 标签列表。
        extra: 扩展字段字典。
    所有熔断器相关的数据结构都应继承此类以保持一致性。
    """

    id: str = field(default_factory=generate_id)
    timestamp: float = field(default_factory=now_timestamp)
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    status: str = "pending"
    priority: int = 1
    retry_count: int = 0
    max_retries: int = 3
    timeout_ms: int = 30000
    created_at: float = field(default_factory=now_timestamp)
    updated_at: float = field(default_factory=now_timestamp)
    version: str = "1.0.0"
    tags: List[str] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """
        将对象转换为字典。

        Returns:
            包含所有字段的字典。
        """
        return asdict(self)

    def update_timestamp(self) -> None:
        """
        更新消息的时间戳。
        """
        self.updated_at = now_timestamp()
        logger.debug("更新消息时间戳，id=%s", self.id)


# 定义优先级映射表
_PRIORITY_MAP: Dict[str, int] = {
    "request_context": 1,
    "response_metadata": 2,
    "processing_result": 3,
    "error_detail": 4,
    "event_record": 5,
    "metric_snapshot": 6,
    "config_snapshot": 7,
    "status_report": 8,
    "performance_stats": 9,
    "resource_usage": 10,
    "quality_metrics": 11,
    "latency_stats": 12,
    "cache_stats": 13,
    "retry_stats": 14,
    "load_stats": 15,
    "health_report": 16,
    "risk_assessment": 17,
    "confidence_score": 18,
    "time_window": 19,
    "aggregated_data": 20,
}

def _create_circuit_class(class_name: str, default_priority: int) -> Type[BaseCircuitMessage]:
    """
    动态创建熔断器消息子类。

    Args:
        class_name: 类名。
        default_priority: 默认优先级。

    Returns:
        新的数据类。
    """
    # 使用 field(default=...) 在类定义中注入默认值，避免手动覆盖 __init__
    @dataclass
    class CircuitClass(BaseCircuitMessage):
        """
        熔断器消息子类。
        """

        priority: int = field(default=default_priority)

    CircuitClass.__name__ = class_name
    return CircuitClass

# 动态生成所有消息类
for _name, _priority in _PRIORITY_MAP.items():
    _cls = _create_circuit_class(_name, _priority)
    globals()[_name] = _cls


# ============================================================================= #
# 线程安全的指标收集器 #
# ============================================================================= #
class RequestMetrics:
    """
    线程安全的请求指标收集器。
    用于跟踪熔断器内部的请求状态计数，支持并发访问。
    包含滑动窗口统计功能，可基于时间窗口计算成功率等指标。
    """

    METRIC_KEYS: Tuple[str, ...] = (
        "total",
        "success",
        "failure",
        "timeout",
        "retry",
        "cancelled",
        "queued",
        "completed",
        "active",
        "waiting",
    )

    def __init__(self, name: str = "") -> None:
        """
        初始化指标收集器。

        Args:
            name: 收集器名称，用于日志和调试。
        """
        self.name = name
        self._lock = threading.RLock()
        self._data: Dict[str, float] = defaultdict(float)
        self._history: Deque[Tuple[float, str, float]] = deque(maxlen=10000)
        self._window: float = 60.0
        self._last_reset: float = now_timestamp()
        for key in self.METRIC_KEYS:
            self._data[key] = 0.0
        logger.info("RequestMetrics初始化完成: %s", name)

    def record(self, metric_key: str, value: float = 1.0) -> None:
        """
        记录指定指标的增量。

        Args:
            metric_key: 指标名称，如'total','success'等。
            value: 增量值，默认为1.0。
        """
        if metric_key not in self.METRIC_KEYS:
            logger.warning("未知指标类型: %s", metric_key)
            return
        with self._lock:
            self._data[metric_key] += value
            self._history.append((now_timestamp(), metric_key, value))
            logger.debug("记录指标: %s=%s (累计: %.1f)", metric_key, value, self._data[metric_key])

    def get(self, metric_key: str) -> float:
        """
        获取指定指标的当前累计值。

        Args:
            metric_key: 指标名称。

        Returns:
            当前累计值，不存在时返回0.0。
        """
        with self._lock:
            return self._data.get(metric_key, 0.0)

    def get_all(self) -> Dict[str, float]:
        """
        获取所有指标的当前累计值。

        Returns:
            包含所有指标名称及对应累计值的字典。
        """
        with self._lock:
            return {key: self._data.get(key, 0.0) for key in self.METRIC_KEYS}

    def reset(self, metric_key: Optional[str] = None) -> None:
        """
        重置指标值。

        Args:
            metric_key: 指定重置的指标，为None时重置所有指标。
        """
        with self._lock:
            if metric_key is None:
                for key in self.METRIC_KEYS:
                    self._data[key] = 0.0
                self._history.clear()
                self._last_reset = now_timestamp()
                logger.info("指标全部重置: %s", self.name)

    def access_rate_window(self, window_seconds: float) -> float:
        """
        计算滑动窗口内的成功率百分比。
        基于最近window_seconds秒内的历史记录计算成功率。

        Args:
            window_seconds: 时间窗口长度（秒）。

        Returns:
            窗口内成功率百分比，无数据时返回0.0。
        """
        if window_seconds <= 0:
            logger.warning("无效的时间窗口: %s", window_seconds)
            return 0.0
        current_time = now_timestamp()
        window_start = current_time - window_seconds
        with self._lock:
            window_total = 0.0
            window_success = 0.0
            for timestamp, metric_key, value in self._history:
                if timestamp < window_start:
                    continue
                if metric_key == "total":
                    window_total += value
                elif metric_key == "success":
                    window_success += value
            if window_total <= 0:
                return 0.0
            rate = (window_success / window_total) * 100.0
            logger.debug(
                "窗口成功率: %.2f%% (窗口:%.1f秒, 总:%.0f, 成功:%.0f)",
                rate,
                window_seconds,
                window_total,
                window_success,
            )
            return rate

    def reset_window(self, new_window: float) -> None:
        """
        重置时间窗口。

        Args:
            new_window: 新的窗口大小（秒）。
        """
        if new_window <= 0:
            logger.warning("无效的时间窗口: %s", new_window)
            return
        with self._lock:
            self._window = new_window
            self._last_reset = now_timestamp()
            # 清理过期的历史记录
            cutoff = now_timestamp() - new_window
            while self._history and self._history[0][0] < cutoff:
                self._history.popleft()
            logger.info("重置时间窗口: %.1f秒", new_window)

    def __repr__(self) -> str:
        return (
            f"RequestMetrics(name={self.name!r}, total={self.total:.1f}, "
            f"success={self.success:.1f}, failure={self.failure:.1f})"
        )
