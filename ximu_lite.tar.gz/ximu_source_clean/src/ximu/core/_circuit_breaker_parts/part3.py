"""电路断路器扩展处理器模块。

提供线程安全、可观测、支持统计与历史追踪的处理器实现，
通过配置化方式消除代码冗余，支持动态步骤处理、批量操作、
序列化/反序列化、算法模型训练与评估等功能。
"""
import logging
import hashlib
import math
import threading
import time
from collections import defaultdict, deque
from typing import Any, Optional, Dict, List, Tuple, Union, Callable, Sequence, Iterator, Deque
from dataclasses import dataclass, field
from json import JSONDecodeError, dumps, loads

logger = logging.getLogger("src.ximu.core._circuit_breaker_parts.part3")


@dataclass
class CircuitBreakerConfig:
    """电路断路器配置参数数据类。

    封装断路器的基本配置信息，包括名称、版本、历史大小及动态配置项。
    """
    name: str = "circuitbreaker"
    version: str = "1.0.0"
    history_size: int = 5000
    _config: Dict[str, Any] = field(default_factory=dict, init=False)

    def get(self, key: str, default: Any = None) -> Any:
        """获取动态配置项。

        Args:
            key: 配置键名
            default: 当键不存在时返回的默认值

        Returns:
            配置值或默认值
        """
        return self._config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """设置动态配置项。

        Args:
            key: 配置键名
            value: 配置值
        """
        self._config[key] = value

    def to_dict(self) -> Dict[str, Any]:
        """将配置转换为字典表示。

        Returns:
            包含所有配置字段的字典
        """
        result: Dict[str, Any] = {
            "name": self.name,
            "version": self.version,
            "history_size": self.history_size,
        }
        result.update(self._config)
        return result


class CircuitBreakerBase:
    """电路断路器基础类。

    封装线程安全的统计、历史、配置与核心处理逻辑，
    提供类型感知的转换、批量处理、序列化/反序列化等功能。
    """

    def __init__(self, **kwargs: Any) -> None:
        """初始化断路器基础类。

        Args:
            **kwargs: 传递给CircuitBreakerConfig的配置参数
        """
        self._lock = threading.RLock()
        self._stats: Dict[str, Union[int, float]] = self._create_stats()
        self._history: Dict[int, Deque[Tuple[float, bool, float]]] = defaultdict(deque)
        self._state: str = "idle"
        self._initialized: bool = False
        self._config = CircuitBreakerConfig(**kwargs)
        for step_key in list(self._history.keys()):
            if step_key not in self._history:
                continue
            dq = self._history[step_key]
            dq.maxlen = self._config.history_size
        logger.debug("Initialized %s with history_size=%d", self._config.name, self._config.history_size)

    def _create_stats(self) -> Dict[str, Union[int, float]]:
        """创建统计结构字典。

        Returns:
            包含processed, success, failed, total_time的字典
        """
        return {
            "processed": 0,
            "success": 0,
            "failed": 0,
            "total_time": 0.0,
        }

    def process_step(self, data: Any, step: int, **kwargs: Any) -> Optional[Any]:
        """处理指定步骤的数据，并更新统计与历史记录。

        Args:
            data: 输入数据
            step: 步骤编号
            **kwargs: 额外参数

        Returns:
            转换后的结果，若输入为None则返回None
        """
        with self._lock:
            self._state = "processing"
            start_time = time.perf_counter()
            result = self._transform(data, step)
            elapsed = time.perf_counter() - start_time

            self._update_stats(result, elapsed)
            self._history[step].append((time.time(), result is not None, elapsed))
            self._history[step].maxlen = self._config.history_size
            self._state = "idle"
            return result

    def _transform(self, data: Any, step: int) -> Any:
        """对数据进行类型感知的转换处理。

        Args:
            data: 输入数据
            step: 当前步骤

        Returns:
            转换后的数据
        """
        if data is None:
            return None

        if isinstance(data, dict):
            result = dict(data)
            result["_processed_by"] = self._config.name
            result["_step"] = step
            result["_ts"] = time.time()
            result["_hash"] = hashlib.md5(
                str(result).encode(), usedforsecurity=False
            ).hexdigest()[:16]
            return result

        if isinstance(data, (list, tuple)):
            return [self._transform(item, step) for item in data]

        if isinstance(data, (int, float)):
            return data * (1.0 + step * 0.01)

        if isinstance(data, str):
            return f"{data}_processed_{step}"

        return data

    def _update_stats(self, result: Any, elapsed: float) -> None:
        """更新统计数据。

        Args:
            result: 处理结果
            elapsed: 耗时（秒）
        """
        self._stats["processed"] += 1
        self._stats["total_time"] += elapsed
        if result is not None:
            self._stats["success"] += 1
        else:
            self._stats["failed"] += 1

    def batch_process(self, items: Sequence[Any], batch_size: int = 12, **kwargs: Any) -> List[Any]:
        """批量处理数据，对每个元素执行指定轮数的转换。

        Args:
            items: 输入数据序列
            batch_size: 每个元素执行的转换轮数
            **kwargs: 额外参数

        Returns:
            处理后的结果列表

        Raises:
            ValueError: 当batch_size非正数时
        """
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        results: List[Any] = []
        for item in items:
            current = item
            for j in range(batch_size):
                current = self._transform(current, j)
            results.append(current)
        return results

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取当前统计快照。

        Returns:
            统计字典副本
        """
        with self._lock:
            return dict(self._stats)

    def get_history(self, step: int, limit: int = 100) -> List[Tuple[float, bool, float]]:
        """获取指定步骤的历史记录。

        Args:
            step: 步骤编号
            limit: 返回记录数量上限

        Returns:
            历史记录列表
        """
        with self._lock:
            records = list(self._history.get(step, deque()))
            return records[-limit:]

    def reset(self) -> None:
        """重置统计数据和历史记录。"""
        with self._lock:
            self._stats = self._create_stats()
            for key in list(self._history.keys()):
                self._history.pop(key, None)
            self._state = "idle"
            logger.debug("CircuitBreakerBase %s reset", self._config.name)

    def validate(self, data: Any) -> Tuple[bool, str]:
        """验证数据合法性。

        Args:
            data: 待验证数据

        Returns:
            (是否有效, 原因说明)
        """
        if data is None:
            return False, "data_is_none"
        if isinstance(data, dict) and not data:
            return False, "empty_dict"
        if isinstance(data, (list, tuple)) and len(data) == 0:
            return False, "empty_collection"
        return True, "valid"

    def serialize(self, data: Any) -> str:
        """将数据序列化为JSON字符串。

        Args:
            data: 待序列化数据

        Returns:
            JSON字符串

        Raises:
            TypeError: 当数据无法序列化时
        """
        try:
            return dumps(data, default=str)
        except Exception as e:
            logger.warning("Serialization failed for data type %s: %s", type(data).__name__, str(e))
            raise

    def deserialize(self, text: str) -> Any:
        """将JSON字符串反序列化为对象。

        Args:
            text: JSON字符串

        Returns:
            反序列化后的对象

        Raises:
            JSONDecodeError: 当JSON格式无效时
        """
        try:
            return loads(text)
        except JSONDecodeError as e:
            logger.error("Deserialization failed: %s", str(e))
            raise

    def get_config(self, key: str, default: Any = None) -> Any:
        """获取配置项。

        Args:
            key: 配置键
            default: 默认值

        Returns:
            配置值
        """
        return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """设置配置项。

        Args:
            key: 配置键
            value: 配置值
        """
        self._config.set(key, value)

    def to_dict(self) -> Dict[str, Any]:
        """将对象转换为字典表示。

        Returns:
            包含名称、版本、状态、统计、配置的字典
        """
        return {
            "name": self._config.name,
            "version": self._config.version,
            "state": self._state,
            "stats": self.get_stats(),
            "config": self._config.to_dict(),
        }

    def __getattr__(self, name: str) -> Any:
        """动态属性访问，支持 process_step_N 形式的调用。

        Args:
            name: 属性名

        Returns:
            对应的处理函数或抛出AttributeError

        Raises:
            AttributeError: 当属性名不匹配时
        """
        if name.startswith("process_step_") and name[13:].isdigit():
            step = int(name[13:])
            def wrapper(data: Any, **kw: Any) -> Optional[Any]:
                return self.process_step(data, step, **kw)
            return wrapper
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")


class CircuitBreakerExtProcessor(CircuitBreakerBase):
    """电路断路器扩展处理器，通过版本号区分不同实现。"""

    def __init__(self, version: str = "1.0.1", name: Optional[str] = None,
                 **kwargs: Any) -> None:
        """初始化扩展处理器。

        Args:
            version: 处理器版本，如 '1.0.1', '1.0.2' 等
            name: 处理器名称，若为None则根据版本自动生成
            **kwargs: 额外配置
        """
        default_name = f"circuitbreakerextprocessor_{version.split('.')[-1]}"
        super().__init__(name=name or default_name, version=version, **kwargs)
        self._version = version
        logger.debug("Initialized %s with version %s", self._config.name, self._version)


class CircuitBreakerAlgorithm:
    """电路断路器算法模型，支持训练、预测、评分与交叉验证。

    提供基于模拟损失的模型训练框架，支持参数化配置、
    批量预测、交叉验证等核心机器学习功能。
    """

    def __init__(self, algo_name: str = "circuitbreakeralgoalgorithm",
                 lr: float = 0.01,
                 iterations: int = 100,
                 tolerance: float = 1e-6,
                 batch_size: int = 32,
                 **kwargs: Any) -> None:
        """初始化算法模型。

        Args:
            algo_name: 算法名称
            lr: 学习率
            iterations: 最大迭代次数
            tolerance: 收敛容差
            batch_size: 批次大小
            **kwargs: 额外参数
        """
        self.algo_name = algo_name
        self._params: Dict[str, Any] = {
            "lr": lr,
            "iterations": iterations,
            "tolerance": tolerance,
            "batch_size": batch_size,
        }
        self._params.update(kwargs)
        self._trained: bool = False
        self._weights: List[float] = []
        self._loss_history: Deque[float] = deque(maxlen=1000)
        self._lock = threading.RLock()
        self._training_time: float = 0.0
        logger.debug("Initialized algorithm %s with params %s", self.algo_name, self._params)

    def fit(self, X: Any, y: Optional[Any] = None, **kwargs: Any) -> Dict[str, Any]:
        """训练模型。

        Args:
            X: 训练数据
            y: 标签
            **kwargs: 额外参数

        Returns:
            包含训练轮数、最终损失、是否训练成功的字典
        """
        with self._lock:
            start_time = time.perf_counter()
            lr: float = self._params["lr"]
            max_iter: int = self._params["iterations"]
            tol: float = self._params["tolerance"]

            if hasattr(X, "__len__") and not isinstance(X, str):
                n_features: int = len(X[0]) if X and hasattr(X[0], "__len__") else 1
            else:
                n_features = 1

            self._weights = [0.0] * max(1, n_features)
            prev_loss: float = float("inf")
            epoch: int = 0

            for epoch in range(max_iter):
                loss: float = max(0.01, prev_loss * math.exp(-lr * epoch))
                self._loss_history.append(loss)
                if abs(prev_loss - loss) < tol:
                    break
                prev_loss = loss

            self._trained = True
            self._training_time = time.perf_counter() - start_time
            result: Dict[str, Any] = {
                "epochs": epoch + 1,
                "final_loss": prev_loss,
                "trained": True,
            }
            logger.debug("Training completed: %s", result)
            return result

    def predict(self, X: Any) -> Any:
        """进行预测。

        Args:
            X: 输入数据

        Returns:
            预测结果（单个值或列表）
        """
        if not self._trained:
            if hasattr(X, "__len__") and not isinstance(X, str):
                return [0.0] * len(X)
            return 0.0

        if hasattr(X, "__len__") and not isinstance(X, str):
            results: List[float] = []
            for item in X:
                if isinstance(item, (list, tuple)):
                    pred: float = sum(w * x for w, x in zip(self._weights, item))
                else:
                    pred = self._weights[0] * item if self._weights else 0.0
                results.append(pred)
            return results
        else:
            return self._weights[0] * X if self._weights else 0.0

    def get_loss_history(self) -> List[float]:
        """获取损失历史记录。

        Returns:
            损失值列表
        """
        return list(self._loss_history)

    def get_params(self) -> Dict[str, Any]:
        """获取当前参数。

        Returns:
            参数字典副本
        """
        return dict(self._params)

    def set_params(self, **kwargs: Any) -> None:
        """更新参数。

        Args:
            **kwargs: 要更新的参数
        """
        with self._lock:
            self._params.update(kwargs)
            logger.debug("Algorithm %s params updated: %s", self.algo_name, kwargs)

    def reset(self) -> None:
        """重置模型状态。"""
        with self._lock:
            self._trained = False
            self._weights = []
            self._loss_history.clear()
            self._training_time = 0.0
            logger.debug("Algorithm %s reset", self.algo_name)

    def score(self, X: Any, y: Any) -> float:
        """计算模型评分。

        Args:
            X: 输入数据
            y: 真实标签

        Returns:
            评分值（0到1之间）
        """
        preds: Any = self.predict(X)
        if not isinstance(preds, (list, tuple)) or not isinstance(y, (list, tuple)):
            return 0.0
        correct: int = sum(1 for p, t in zip(preds, y) if abs(p - t) < 0.5)
        total: int = max(1, len(y))
        return correct / total

    def cross_validate(self, X: Sequence[Any], y: Sequence[Any], folds: int = 5) -> List[float]:
        """执行K折交叉验证。

        Args:
            X: 数据序列
            y: 标签序列
            folds: 折数

        Returns:
            每折的评分列表

        Raises:
            ValueError: 当folds大于样本数时
        """
        n: int = len(X)
        if n == 0:
            return []
        if folds > n:
            raise ValueError("Number of folds cannot exceed number of samples")
        if folds <= 0:
            raise ValueError("Number of folds must be positive")

        fold_size: int = n // folds
        remainder: int = n % folds
        scores: List[float] = []
        split_idx: int = 0

        for f in range(folds):
            current_fold_size: int = fold_size + (1 if f < remainder else 0)
            start: int = split_idx
            end: int = start + current_fold_size
            split_idx = end

            val_X: Sequence[Any] = X[start:end]
            val_y: Sequence[Any] = y[start:end]
            train_X: Sequence[Any] = X[:start] + X[end:]
            train_y: Sequence[Any] = y[:start] + y[end:]

            if len(train_X) > 0:
                self.fit(list(train_X), list(train_y))
                score: float = self.score(val_X, val_y)
            else:
                score = 0.0
            scores.append(score)

        logger.debug("Cross validation scores: %s", scores)
        return scores


def create_processor(version: str = "1.0.1", name: Optional[str] = None,
                     **kwargs: Any) -> CircuitBreakerExtProcessor:
    """工厂函数，创建指定版本的电路断路器扩展处理器。

    Args:
        version: 处理器版本
        name: 处理器名称，若为None则自动生成
        **kwargs: 额外配置

    Returns:
        配置好的处理器实例
    """
    return CircuitBreakerExtProcessor(version=version, name=name, **kwargs)


def create_algorithm(**kwargs: Any) -> CircuitBreakerAlgorithm:
    """工厂函数，创建电路断路器算法模型。

    Args:
        **kwargs: 算法参数

    Returns:
        配置好的算法模型实例
    """
    return CircuitBreakerAlgorithm(**kwargs)
