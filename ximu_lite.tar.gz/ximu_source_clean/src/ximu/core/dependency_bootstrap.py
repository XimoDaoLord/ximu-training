import concurrent.futures
import importlib
import json
import logging
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("ximu.dependency_bootstrap")

CORE_DEPS = {
    'flask': 'flask',
    'flask_cors': 'flask-cors',
    'requests': 'requests',
}

MIRROR_CANDIDATES = [
    ('清华', 'https://pypi.tuna.tsinghua.edu.cn/simple'),
    ('阿里', 'https://mirrors.aliyun.com/pypi/simple'),
    ('中科大', 'https://pypi.mirrors.ustc.edu.cn/simple'),
    ('pypi', 'https://pypi.org/simple'),
]

_PROBE_PER_TIMEOUT = 2.5
_PROBE_TOTAL_TIMEOUT = 5.0

def _probe_one(name_url: Tuple[str, str]) -> Tuple[str, str, Optional[float], Optional[str]]:
    """探测单个镜像"""
    name, url = name_url
    t0 = time.time()
    try:
        req = urllib.request.Request(
            url + '/',
            headers={
                'User-Agent': 'ximu-dep-bootstrap/1.0',
                'Accept-Encoding': 'identity',
            },
        )
        with urllib.request.urlopen(req, timeout=_PROBE_PER_TIMEOUT) as r:
            status = getattr(r, 'status', 200) or 200
            if 200 <= status < 300:
                return name, url, (time.time() - t0) * 1000.0, None
        return name, url, None, f'http {status}'
    except Exception as e:
        return name, url, None, type(e).__name__

def _pick_fastest_source() -> Optional[Tuple[str, str, float]]:
    """选择最快镜像源"""
    results = []
    fut_map = {}
    ex = concurrent.futures.ThreadPoolExecutor(
        max_workers=len(MIRROR_CANDIDATES),
        thread_name_prefix='mirror-probe',
    )
    try:
        for mu in MIRROR_CANDIDATES:
            fut_map[ex.submit(_probe_one, mu)] = mu
        deadline = time.time() + _PROBE_TOTAL_TIMEOUT
        while fut_map:
            remaining = deadline - time.time()
            if remaining <= 0:
                break
            done, _ = concurrent.futures.wait(
                list(fut_map.keys()),
                timeout=remaining,
                return_when=concurrent.futures.FIRST_COMPLETED,
            )
            for fut in done:
                mu = fut_map.pop(fut)
                try:
                    results.append(fut.result())
                except Exception as e:
                    results.append((mu[0], mu[1], None, f'future:{e}'))
        
        ok = [(ms, name, url) for name, url, ms, _err in results if ms is not None]
        if not ok:
            logger.info("所有镜像不可达")
            return None
        ok.sort()
        ms, name, url = ok[0]
        logger.info("选用源: %s (%.0fms)", url, ms)
        return name, url, ms
    finally:
        ex.shutdown(wait=False)

def _check_deps() -> List[Tuple[str, str]]:
    """检测缺失依赖"""
    missing = []
    for mod, pkg in CORE_DEPS.items():
        try:
            importlib.import_module(mod)
        except ImportError:
            missing.append((mod, pkg))
    return missing

def _install(pkg: str, source_url: str, timeout: int = 120) -> Tuple[bool, str]:
    """安装单个包"""
    try:
        cmd = [sys.executable, '-m', 'pip', 'install', '--disable-pip-version-check', '-q', '-i', source_url, pkg]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        ok = proc.returncode == 0
        return ok, ('' if ok else (proc.stderr or proc.stdout)[-300:])
    except subprocess.TimeoutExpired:
        return False, '安装超时'
    except Exception as e:
        return False, str(e)

def _state_file(data_dir: str) -> str:
    """获取状态文件路径"""
    return os.path.join(data_dir, '.deps_ready')

def ensure_dependencies(data_dir: str, force: bool = False, silent: bool = True) -> Dict[str, Any]:
    """确保依赖就绪"""
    os.makedirs(data_dir, exist_ok=True)
    st = _state_file(data_dir)
    first_run = force or not os.path.isfile(st)
    missing = _check_deps()
    
    if not missing:
        try:
            with open(st, 'w', encoding='utf-8') as f:
                json.dump({'checked_at': time.time(), 'deps': list(CORE_DEPS.keys())}, f)
        except Exception:
            pass
        return {
            'checked': True,
            'first_run': first_run,
            'installed': [],
            'missing': [],
            'source': '齐备',
            'skipped': False,
            'error': None,
        }
    
    repaired = (not first_run)
    picked = _pick_fastest_source()
    if picked is None:
        return {
            'checked': True,
            'first_run': first_run,
            'repaired': repaired,
            'installed': [],
            'missing': [m for m, _ in missing],
            'source': None,
            'skipped': True,
            'error': 'all mirrors unreachable',
        }
    
    name, url, _latency = picked
    installed = []
    failed = []
    for mod, pkg in missing:
        ok, detail = _install(pkg, url)
        if ok:
            installed.append(pkg)
        else:
            failed.append({'pkg': pkg, 'detail': detail})
    
    still_missing = [m for m, _ in _check_deps()]
    
    try:
        with open(st, 'w', encoding='utf-8') as f:
            json.dump({
                'checked_at': time.time(),
                'source': name,
                'installed': installed,
                'missing': still_missing,
                'repaired': repaired,
            }, f)
    except Exception:
        pass
    
    return {
        'checked': True,
        'first_run': first_run,
        'repaired': repaired,
        'installed': installed,
        'missing': still_missing,
        'source': name,
        'skipped': False,
        'error': None if not failed else f'安装失败: {failed}',
    }

def repair_runtime(data_dir: str) -> Dict[str, Any]:
    """修复运行环境"""
    report = ensure_dependencies(data_dir, force=True, silent=True)
    workdir_rebuilt = False
    try:
        sandbox_work = os.path.join(data_dir, 'sandbox_work')
        os.makedirs(sandbox_work, exist_ok=True)
        for sub in ('tmp', 'runs'):
            p = os.path.join(sandbox_work, sub)
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
                os.makedirs(p, exist_ok=True)
        workdir_rebuilt = True
    except Exception:
        workdir_rebuilt = False
    
    report['workdir_rebuilt'] = workdir_rebuilt
    return report
