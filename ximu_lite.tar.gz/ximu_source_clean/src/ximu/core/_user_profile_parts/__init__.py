"""用户配置文件的拆分部分模块."""

__version__: str = "0.5"
__all__: list[str] = []
