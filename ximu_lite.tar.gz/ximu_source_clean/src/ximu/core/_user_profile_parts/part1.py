"""用户画像系统基础设施模块。

提供标准化的数据结构、状态定义、高性能计时器、线程安全指标收集器
以及通用工具函数，为上层业务提供统一的类型定义和基础功能支持。
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, Tuple, Type, TypeVar

logger = logging.getLogger("src.ximu.core._user_profile_parts.part1")

T = TypeVar("T")
F = TypeVar("F", bound=Callable[..., Any])

LOCAL_WORKSPACE: str = os.environ.get("XIMU_WORKSPACE", "./local_workspace")
MAX_HISTORY_SIZE: int = 10000
DEFAULT_WINDOW_SECONDS: float = 60.0
DEFAULT_TIMEOUT_MS: int = 30000
DEFAULT_VERSION: str = "1.0.0"


# ============================== # 通用工具函数 # ==============================

def generate_id(prefix: str = "id") -> str:
    """生成带有前缀的唯一标识符。

    Args:
        prefix: 标识符前缀，默认为"id"

    Returns:
        格式为"{prefix}_{16位十六进制}"的唯一字符串
    """
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


def now_timestamp() -> float:
    """获取当前 Unix 时间戳（秒）。

    Returns:
        当前时间的浮点表示
    """
    return time.time()


def now_timestamp_ms() -> int:
    """获取当前 Unix 时间戳（毫秒）。

    Returns:
        当前时间的整型毫秒表示
    """
    return int(time.time() * 1000)


def safe_json_dumps(obj: Any, **kwargs: Any) -> str:
    """安全地将对象序列化为 JSON 字符串。

    Args:
        obj: 要序列化的对象
        **kwargs: 传递给 json.dumps 的其他参数

    Returns:
        JSON 格式的字符串
    """
    kwargs.setdefault("ensure_ascii", False)
    kwargs.setdefault("default", str)
    return json.dumps(obj, **kwargs)


def safe_json_loads(s: str, **kwargs: Any) -> Optional[Any]:
    """安全地从 JSON 字符串反序列化对象。

    Args:
        s: JSON 字符串
        **kwargs: 传递给 json.loads 的其他参数

    Returns:
        反序列化后的 Python 对象，失败时返回 None
    """
    try:
        return json.loads(s, **kwargs)
    except (json.JSONDecodeError, TypeError) as e:
        logger.warning("JSON 反序列化失败: %s", e)
        return None


def retry_on_failure(
    max_retries: int = 3,
    delay: float = 0.1,
    exponential_backoff: bool = True
) -> Callable[[F], F]:
    """同步装饰器：在函数执行失败时进行指数退避重试。

    优化点：引入最大延迟上限防止无限增长，避免潜在的死循环或过长的等待时间。

    Args:
        max_retries: 最大重试次数，默认为3
        delay: 初始延迟时间（秒），默认为0.1
        exponential_backoff: 是否使用指数退避，默认为True

    Returns:
        装饰器函数
    """
    MAX_DELAY_CAP: float = 60.0  # 最大延迟上限

    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries - 1:
                        logger.error(
                            "函数 %s 在 %d 次重试后仍然失败: %s",
                            func.__name__,
                            max_retries,
                            e,
                        )
                        raise
                    sleep_time = delay * (2 ** attempt) if exponential_backoff else delay
                    sleep_time = min(sleep_time, MAX_DELAY_CAP)
                    logger.warning(
                        "函数 %s 第 %d 次执行失败，%.2f 秒后重试: %s",
                        func.__name__,
                        attempt + 1,
                        sleep_time,
                        e,
                    )
                    time.sleep(sleep_time)
            raise RuntimeError("重试逻辑执行异常，不应到达此处")

        return wrapper

    return decorator


async def async_retry_on_failure(
    func: Callable[..., T],
    *args: Any,
    max_retries: int = 3,
    delay: float = 0.1,
    exponential_backoff: bool = True,
    **kwargs: Any,
) -> T:
    """异步装饰器辅助函数：在协程执行失败时进行指数退避重试。

    优化点：引入最大延迟上限防止无限增长，避免潜在的死循环或过长的等待时间。

    Args:
        func: 要执行的异步函数
        *args: 位置参数
        max_retries: 最大重试次数，默认为3
        delay: 初始延迟时间（秒），默认为0.1
        exponential_backoff: 是否使用指数退避，默认为True
        **kwargs: 关键字参数

    Returns:
        函数执行结果
    Raises:
        Exception: 重试耗尽后抛出最后一次异常
    """
    MAX_DELAY_CAP: float = 60.0  # 最大延迟上限

    for attempt in range(max_retries):
        try:
            return await func(*args, **kwargs)
        except Exception as e:
            if attempt == max_retries - 1:
                logger.error(
                    "异步函数 %s 在 %d 次重试后仍然失败: %s",
                    func.__name__ if hasattr(func, "__name__") else str(func),
                    max_retries,
                    e,
                )
                raise
            sleep_time = delay * (2 ** attempt) if exponential_backoff else delay
            sleep_time = min(sleep_time, MAX_DELAY_CAP)
            logger.warning(
                "异步函数 %s 第 %d 次执行失败，%.2f 秒后重试: %s",
                func.__name__ if hasattr(func, "__name__") else str(func),
                attempt + 1,
                sleep_time,
                e,
            )
            await asyncio.sleep(sleep_time)
    raise RuntimeError("异步重试逻辑执行异常，不应到达此处")


# ============================== # 计时工具 # ==============================

class Stopwatch:
    """高性能计时器，支持启动、停止和查询经过时间。

    线程安全，支持链式调用，在计时器未启动时调用 stop 会抛出异常。
    """

    def __init__(self) -> None:
        self._start_time: float = 0.0
        self._total_elapsed: float = 0.0
        self._running: bool = False
        self._lock = threading.Lock()

    def start(self) -> "Stopwatch":
        """启动计时器。

        Returns:
            自身实例以支持链式调用
        Raises:
            RuntimeError: 如果计时器已在运行中
        """
        with self._lock:
            if self._running:
                raise RuntimeError("计时器已在运行中，请勿重复启动")
            self._start_time = time.monotonic()
            self._running = True
        return self

    def stop(self) -> float:
        """停止计时器并返回本次段的耗时。

        Returns:
            从 start 到 stop 的秒数
        Raises:
            RuntimeError: 如果计时器未在运行中
        """
        with self._lock:
            if not self._running:
                raise RuntimeError("计时器未在运行中，无法停止")
            segment = time.monotonic() - self._start_time
            self._total_elapsed += segment
            self._running = False
        return segment

    def elapsed(self) -> float:
        """获取总经过时间（包括已停止的段和当前运行段）。

        Returns:
            总经过秒数
        """
        with self._lock:
            if self._running:
                return self._total_elapsed + (time.monotonic() - self._start_time)
            return self._total_elapsed

    def reset(self) -> None:
        """重置计时器状态。"""
        with self._lock:
            self._start_time = 0.0
            self._total_elapsed = 0.0
            self._running = False


# ============================== # 基础数据模型 # ==============================

class BaseRecordMeta(type):
    """元类用于管理子类优先级和默认属性"""

    _default_priority: int = 1

    def __call__(cls, name: str, priority: int, **kwargs) -> Type[BaseRecord]:
        new_class = super().__call__(name, **kwargs)
        new_class._default_priority = priority
        return new_class


@dataclass
class BaseRecord(metaclass=BaseRecordMeta):
    """通用记录基类，包含标准字段。

    提供统一的数据结构规范，所有衍生记录类基于此扩展。
    通过 _default_priority 支持子类自定义默认优先级。
    """

    record_id: str = field(default_factory=lambda: generate_id())
    timestamp: float = field(default_factory=now_timestamp)
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    status: str = "pending"
    priority: int = field(default=1, init=False)
    retry_count: int = 0
    max_retries: int = 3
    timeout_ms: int = DEFAULT_TIMEOUT_MS
    created_at: float = field(default_factory=now_timestamp)
    updated_at: float = field(default_factory=now_timestamp)
    version: str = DEFAULT_VERSION
    tags: List[str] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """初始化后钩子：应用子类定义的默认优先级。"""
        if self.priority == 1 and hasattr(type(self), "_default_priority"):
            self.priority = type(self)._default_priority


def create_record_subclass(
    name: str,
    priority: int,
    doc: str = "",
    extra_fields: Optional[Dict[str, Any]] = None
) -> Type[BaseRecord]:
    """动态创建 BaseRecord 的子类。

    Args:
        name: 生成的类名
        priority: 记录的默认优先级
        doc: 类的文档字符串
        extra_fields: 额外字段定义，键为字段名，值为 dataclass.field 对象

    Returns:
        新创建的 BaseRecord 子类
    """
    cls_attrs = {
        "__doc__": doc or f"{name} 记录类",
        "_default_priority": priority,
    }
    if extra_fields:
        for field_name, field_def in extra_fields.items():
            cls_attrs[field_name] = field_def
    return type(name, (BaseRecord,), cls_attrs)


# 预定义记录类型
RequestContext = create_record_subclass("RequestContext", 1, "请求上下文记录")
ResponseMetadata = create_record_subclass("ResponseMetadata", 2, "响应元数据记录")
ProcessingResult = create_record_subclass("ProcessingResult", 3, "处理结果记录")
ErrorDetail = create_record_subclass("ErrorDetail", 4, "错误详情记录")
EventRecord = create_record_subclass("EventRecord", 5, "事件记录")
MetricSnapshot = create_record_subclass("MetricSnapshot", 6, "指标快照记录")
ConfigSnapshot = create_record_subclass("ConfigSnapshot", 7, "配置快照记录")
StatusReport = create_record_subclass("StatusReport", 8, "状态报告记录")
PerformanceStats = create_record_subclass("PerformanceStats", 9, "性能统计记录")
ResourceUsage = create_record_subclass("ResourceUsage", 10, "资源使用记录")
QualityMetrics = create_record_subclass("QualityMetrics", 11, "质量指标记录")
LatencyStats = create_record_subclass("LatencyStats", 12, "延迟统计记录")
CacheStats = create_record_subclass("CacheStats", 13, "缓存统计记录")
RetryStats = create_record_subclass("RetryStats", 14, "重试统计记录")
LoadStats = create_record_subclass("LoadStats", 15, "负载统计记录")
HealthReport = create_record_subclass("HealthReport", 16, "健康报告记录")
RiskAssessment = create_record_subclass("RiskAssessment", 17, "风险评估记录")
ConfidenceScore = create_record_subclass("ConfidenceScore", 18, "置信度分数记录")
TimeWindow = create_record_subclass("TimeWindow", 19, "时间窗口记录")
AggregatedData = create_record_subclass("AggregatedData", 20, "聚合数据记录")


# ============================== # 指标收集器 # ==============================

class MetricsCollector:
    """线程安全的指标收集器基类。

    使用滑动窗口优化时间复杂度，支持累计值、速率和窗口统计查询。
    优化：通过局部变量访问减少锁竞争下的全局查找开销，并优化窗口统计逻辑。
    """

    def __init__(self, name: str = "") -> None:
        self.name = name
        self._lock = threading.RLock()
        self._data: Dict[str, float] = defaultdict(float)
        self._counters: Dict[str, float] = defaultdict(float)
        self._histories: Dict[str, deque] = defaultdict(lambda: deque(maxlen=MAX_HISTORY_SIZE))
        self._window: float = DEFAULT_WINDOW_SECONDS
        self._last_record_time: Dict[str, float] = defaultdict(now_timestamp)

    def _record(self, metric_name: str, value: float = 1.0) -> None:
        """记录单个指标值。

        Args:
            metric_name: 指标名称
            value: 指标增量值
        """
        now = now_timestamp()
        with self._lock:
            self._counters[metric_name] += value
            self._data[metric_name] += value
            self._last_record_time[metric_name] = now
            self._histories[metric_name].append((now, value))

    def _get_counter(self, metric_name: str) -> float:
        """获取指定指标的累计值。

        Args:
            metric_name: 指标名称

        Returns:
            累计值
        """
        with self._lock:
            return self._counters.get(metric_name, 0.0)

    def _reset_counter(self, metric_name: str) -> None:
        """重置指定指标的累计值。

        Args:
            metric_name: 指标名称
        """
        with self._lock:
            self._counters[metric_name] = 0.0
            self._data[metric_name] = 0.0
            self._histories[metric_name].clear()

    def get_all_metrics(self) -> Dict[str, float]:
        """获取所有指标的当前累计值。

        Returns:
            指标名称到累计值的映射
        """
        with self._lock:
            return dict(self._data)

    def get_rate(self, metric_name: str) -> float:
        """计算指定指标的平均速率（每秒）。

        Args:
            metric_name: 指标名称

        Returns:
            每秒指标增量
        """
        with self._lock:
            last_time = self._last_record_time.get(metric_name, now_timestamp())
            elapsed = max(1e-9, now_timestamp() - last_time)
            return self._data.get(metric_name, 0.0) / elapsed

    def get_window_stats(
        self, metric_name: str, window_seconds: float = DEFAULT_WINDOW_SECONDS
    ) -> Dict[str, float]:
        """获取指定指标在时间窗口内的统计数据。

        使用双端队列尾部扫描，避免线性遍历全部历史。

        Args:
            metric_name: 指标名称
            window_seconds: 时间窗口（秒）

        Returns:
            包含 count, sum, avg, min, max 的字典
        """
        with self._lock:
            now = now_timestamp()
            cutoff = now - window_seconds
            history = self._histories.get(metric_name)
            if not history:
                return {"count": 0, "sum": 0.0, "avg": 0.0, "min": 0.0, "max": 0.0}

            count = 0
            total_sum = 0.0
            min_val = float("inf")
            max_val = float("-inf")

            # 优化：直接在迭代中计算统计量，避免创建中间列表
            for ts, val in reversed(history):
                if ts >= cutoff:
                    count += 1
                    total_sum += val
                    if val < min_val:
                        min_val = val
                    if val > max_val:
                        max_val = val
                else:
                    break

            if count == 0:
                return {"count": 0, "sum": 0.0, "avg": 0.0, "min": 0.0, "max": 0.0}

            return {
                "count": count,
                "sum": total_sum,
                "avg": total_sum / count,
                "min": min_val,
                "max": max_val,
            }

    def reset_all(self) -> None:
        """重置所有指标和历史记录。"""
        with self._lock:
            self._data.clear()
            self._counters.clear()
            for history in self._histories.values():
                history.clear()
            self._last_record_time.clear()

    def to_dict(self) -> Dict[str, Any]:
        """将收集器状态转换为字典。

        Returns:
            包含名称、指标数据和窗口的字典
        """
        with self._lock:
            return {
                "name": self.name,
                "metrics": dict(self._data),
                "window": self._window,
            }


class RequestMetrics(MetricsCollector):
    """请求指标收集器，追踪 total/success/failure 等指标。

    优化：使用统一的动态属性生成机制，减少重复代码。
    """

    METRIC_NAMES: Tuple[str, ...] = (
        "total",
        "success",
        "failure",
        "timeout",
        "retry",
        "cancelled",
        "queued",
        "completed",
        "active",
        "waiting",
    )

    def __init__(self, name: str = "") -> None:
        super().__init__(name)
        for metric in self.METRIC_NAMES:
            self._counters[metric] = 0.0

        # 动态生成 record_X 和 get_X 方法
        for metric in self.METRIC_NAMES:
            setattr(self, f"record_{metric}", self._make_recorder(metric))
            setattr(self, f"get_{metric}", self._make_getter(metric))

    def _make_recorder(self, metric_name: str) -> Callable[[float], None]:
        """生成记录方法的闭包。"""
        def recorder(value: float = 1.0) -> None:
            self._record_metric(metric_name, value)
        recorder.__doc__ = f"记录 {metric_name} 指标值。"
        return recorder

    def _make_getter(self, metric_name: str) -> Callable[[], float]:
        """生成获取方法的闭包。"""
        def getter() -> float:
            return self._get_metric(metric_name)
        getter.__doc__ = f"获取 {metric_name} 指标值。"
        return getter

    def _record_metric(self, metric: str, value: float = 1.0) -> None:
        """记录指定请求指标。

        Args:
            metric: 指标名称
            value: 增量值
        """
        self._record(metric, value)

    def _get_metric(self, metric: str) -> float:
        """获取指定请求指标值。

        Args:
            metric: 指标名称

        Returns:
            指标累计值
        """
        return self._get_counter(metric)


class LatencyMetrics(MetricsCollector):
    """延迟指标收集器，追踪 min/max/avg/percentile 等统计量。

    优化：使用 Welford 算法在线更新均值，减少历史数据遍历需求。
    """

    def __init__(self, name: str = "") -> None:
        super().__init__(name)
        self._counters.update(
            {
                "min": float("inf"),
                "max": float("-inf"),
                "avg": 0.0,
                "_count": 0.0,
                "_sum_sq": 0.0,  # 用于标准差计算的辅助变量
            }
        )

    def record_latency(self, value: float) -> None:
        """记录单次延迟值并更新在线统计量。

        使用 Welford 算法增量更新均值和标准差，同时维护历史用于百分位计算。

        Args:
            value: 延迟值
        """
        with self._lock:
            count = self._counters.get("_count", 0.0) + 1
            self._counters["_count"] = count

            current_min = self._counters.get("min", float("inf"))
            current_max = self._counters.get("max", float("-inf"))
            self._counters["min"] = min(current_min, value)
            self._counters["max"] = max(current_max, value)

            # Welford 算法更新均值和平方和
            current_avg = self._counters.get("avg", 0.0)
            current_sum_sq = self._counters.get("_sum_sq", 0.0)

            if count == 1:
                new_avg = value
            else:
                new_avg = current_avg + (value - current_avg) / count

            delta = value - current_avg
            delta_avg = value - new_avg
            self._counters["_sum_sq"] = current_sum_sq + delta * delta_avg
            self._counters["avg"] = new_avg

            now = now_timestamp()
            self._histories["latency"].append((now, value))
            self._last_record_time["latency"] = now

    def get_percentile(self, percentile: float) -> float:
        """计算延迟的指定百分位值。

        Args:
            percentile: 百分位数（0-100），如 95 表示 P95

        Returns:
            对应百分位的延迟值
        """
        with self._lock:
            values = sorted(v for _, v in self._histories.get("latency", []))
            if not values:
                return 0.0
            idx = min(int(len(values) * percentile / 100), len(values) - 1)
            return values[idx]

    def get_stddev(self) -> float:
        """计算延迟的标准差。

        使用在线计算的平方和，避免遍历历史记录。

        Returns:
            标准差值
        """
        with self._lock:
            count = self._counters.get("_count", 0.0)
            if count < 2:
                return 0.0
            avg = self._counters.get("avg", 0.0)
            sum_sq = self._counters.get("_sum_sq", 0.0)
            # 样本方差公式：(sum_sq / count) - (avg^2)
            variance = (sum_sq / count) - (avg * avg)
            variance = max(0.0, variance)  # 防止浮点误差导致负值
            return variance ** 0.5

    def get_min(self) -> float:
        """获取最小延迟值。"""
        with self._lock:
            return self._counters.get("min", float("inf"))

    def get_max(self) -> float:
        """获取最大延迟值。"""
        with self._lock:
            return self._counters.get("max", float("-inf"))

    def get_avg(self) -> float:
        """获取平均延迟值。"""
        with self._lock:
            return self._counters.get("avg", 0.0)

    def get_count(self) -> float:
        """获取样本数量。"""
        with self._lock:
            return self._counters.get("_count", 0.0)
