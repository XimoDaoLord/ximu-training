"""Part 3 of user_profile: 用户资料扩展处理器与算法模块。"""
import logging
import hashlib
import math
import random
import threading
from collections import OrderedDict, deque
from typing import Any, Dict, List, Optional, Tuple, Union, Set, Deque, Callable, ClassVar

from src.ximu.common.utils import Stopwatch, now_timestamp, safe_json_dumps, safe_json_loads

logger = logging.getLogger("src.ximu.core._user_profile_parts.part3")


def _transform_data(data: Any, step: int, name: str) -> Any:
    """
    执行数据变换逻辑。

    Args:
        data: 待转换的数据
        step: 转换步骤标识
        name: 处理器名称

    Returns:
        转换后的数据
    """
    if data is None:
        return None
    if isinstance(data, dict):
        result = dict(data)
        result['_processed_by'] = name
        result['_step'] = step
        result['_ts'] = now_timestamp()
        result['_hash'] = hashlib.md5(str(result).encode(), usedforsecurity=False).hexdigest()[:16]
        return result
    if isinstance(data, (list, tuple)):
        return [_transform_data(item, step, name) for item in data]
    if isinstance(data, (int, float)):
        return data * (1.0 + step * 0.01)
    if isinstance(data, str):
        return data + '_processed_' + str(step)
    return data


class UserProfileExtProcessorBase:
    """用户资料扩展处理器基类，封装通用逻辑。"""

    _batch_iterations: ClassVar[int] = 12

    def __init__(self, name: str = 'userprofileextprocessor_base', **kwargs: Any) -> None:
        """
        初始化处理器。

        Args:
            name: 处理器名称
            **kwargs: 配置参数
        """
        self.name = name
        self._config: Dict[str, Any] = kwargs
        self._lock = threading.RLock()
        self._cache: OrderedDict[str, Any] = OrderedDict()
        self._stats: Dict[str, Union[int, float]] = {
            'processed': 0,
            'success': 0,
            'failed': 0,
            'total_time': 0.0
        }
        self._history: Deque[Tuple[float, str, bool, float]] = deque(maxlen=5000)
        self._state: str = 'idle'
        self._initialized: bool = False
        self._version: str = '0.5'

    def process_step(self, data: Any, step: int, **kwargs: Any) -> Any:
        """
        处理单个步骤。

        Args:
            data: 待处理数据
            step: 步骤号
            **kwargs: 额外参数

        Returns:
            处理结果
        """
        with self._lock:
            self._state = 'processing'
            sw = Stopwatch().start()
            result = _transform_data(data, step, self.name)
            elapsed = sw.stop().elapsed
            self._stats['processed'] += 1
            self._stats['total_time'] += elapsed
            if result is not None:
                self._stats['success'] += 1
            else:
                self._stats['failed'] += 1
            self._history.append((now_timestamp(), f'process_step_{step}', result is not None, elapsed))
            self._state = 'idle'
            return result

    def __getattr__(self, name: str) -> Any:
        """
        动态属性访问。

        Args:
            name: 属性名

        Returns:
            动态生成的方法或抛出异常
        """
        if name.startswith('process_step_') and name[13:].isdigit():
            step = int(name[13:])
            return lambda data, **kw: self.process_step(data, step, **kw)
        raise AttributeError(name)

    def batch_process(self, items: List[Any], **kwargs: Any) -> List[Any]:
        """
        批量处理。

        Args:
            items: 数据项列表
            **kwargs: 额外参数

        Returns:
            处理后的结果列表
        """
        results: List[Any] = []
        for item in items:
            r = item
            for j in range(self._batch_iterations):
                r = _transform_data(r, j, self.name)
            results.append(r)
        return results

    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息。

        Returns:
            统计字典
        """
        with self._lock:
            return dict(self._stats)

    def get_history(self, limit: int = 100) -> List[Any]:
        """
        获取历史。

        Args:
            limit: 返回的最大记录数

        Returns:
            历史记录列表
        """
        with self._lock:
            return list(self._history)[-limit:]

    def reset(self) -> None:
        """重置状态。"""
        with self._lock:
            self._stats = {'processed': 0, 'success': 0, 'failed': 0, 'total_time': 0.0}
            self._history.clear()

    def validate(self, data: Any) -> Tuple[bool, str]:
        """
        验证数据。

        Args:
            data: 待验证数据

        Returns:
            (是否有效, 原因说明)
        """
        if data is None:
            return False, 'data_is_none'
        if isinstance(data, dict) and not data:
            return False, 'empty_dict'
        if isinstance(data, (list, tuple)) and len(data) == 0:
            return False, 'empty_collection'
        return True, 'valid'

    def serialize(self, data: Any) -> str:
        """
        序列化数据。

        Args:
            data: 待序列化数据

        Returns:
            JSON字符串或原始字符串表示
        """
        try:
            return safe_json_dumps(data)
        except Exception:
            return str(data)

    def deserialize(self, text: str) -> Any:
        """
        反序列化数据。

        Args:
            text: 序列化文本

        Returns:
            反序列化后的对象
        """
        return safe_json_loads(text)

    def get_config(self, key: str, default: Any = None) -> Any:
        """
        获取配置。

        Args:
            key: 配置键
            default: 默认值

        Returns:
            配置值
        """
        return self._config.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """
        设置配置。

        Args:
            key: 配置键
            value: 配置值
        """
        self._config[key] = value

    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典。

        Returns:
            包含处理器信息的字典
        """
        return {
            'name': self.name,
            'version': self._version,
            'state': self._state,
            'stats': self.get_stats(),
            'config': dict(self._config)
        }


class UserProfileExtProcessor_1(UserProfileExtProcessorBase):
    """用户资料扩展处理器 1。"""
    pass


class UserProfileExtProcessor_2(UserProfileExtProcessorBase):
    """用户资料扩展处理器 2。"""
    pass


class UserProfileExtProcessor_3(UserProfileExtProcessorBase):
    """用户资料扩展处理器 3。"""
    pass


class UserProfileExtProcessor_4(UserProfileExtProcessorBase):
    """用户资料扩展处理器 4。"""
    pass


class UserProfileAlgoAlgorithm_0:
    """用户资料算法 0：基础参数化学习模型。"""

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化算法。

        Args:
            **kwargs: 算法参数覆盖
        """
        self.algo_name: str = 'userprofilealgoalgorithm_0'
        self._params: Dict[str, Any] = {'lr': 0.01, 'iterations': 100, 'tolerance': 1e-6, 'batch_size': 32}
        self._params.update(kwargs)
        self._trained: bool = False
        self._weights: List[float] = []
        self._loss_history: Deque[float] = deque(maxlen=1000)
        self._lock = threading.Lock()
        self._training_time: float = 0.0

    def fit(self, X: Any, y: Optional[Any] = None, **kwargs: Any) -> None:
        """
        训练模型。

        Args:
            X: 训练数据
            y: 标签数据（可选）
            **kwargs: 额外参数
        """
        with self._lock:
            sw = Stopwatch().start()
            lr = self._params['lr']
            max_iter = self._params['iterations']
            tol = self._params['tolerance']
            n = len(X) if hasattr(X, '__len__') else 1
            self._weights = [random.gauss(0, 0.1) for _ in range(max(1, n))]
            prev_loss = float('inf')
            for epoch in range(max_iter):
                loss = max(0.01, prev_loss * math.exp(-lr * epoch))
                self._loss_history.append(loss)
                if abs(prev_loss - loss) < tol:
                    break
                prev_loss = loss
            self._training_time = sw.stop().elapsed
            self._trained = True

    def predict(self, X: Any) -> List[float]:
        """
        模型预测。

        Args:
            X: 输入数据

        Returns:
            预测值列表
        """
        if not self._trained:
            raise RuntimeError("Model not trained.")
        return [w * (1.0 if x > 0 else -1.0) for w, x in zip(self._weights, X)]
