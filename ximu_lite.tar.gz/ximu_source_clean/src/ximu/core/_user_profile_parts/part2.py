import logging
import hashlib
import threading
from collections import OrderedDict, deque, defaultdict
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Union, Set
import time

try:
    from src.ximu.common.utils import Stopwatch, now_timestamp, safe_json_dumps, safe_json_loads
except ImportError:
    def now_timestamp() -> float:
        return time.time()
    def safe_json_dumps(obj: Any) -> str:
        import json
        return json.dumps(obj, ensure_ascii=False)
    def safe_json_loads(s: str) -> Any:
        import json
        try:
            return json.loads(s)
        except Exception:
            return None
    class Stopwatch:
        pass

__version__ = "0.5"
logger = logging.getLogger(__name__)


class StoreBase:
    """基础存储类"""

    def __init__(self, max_size: int = 10000, ttl: float = 3600.0) -> None:
        """初始化"""
        self._store: "OrderedDict[str, Tuple[Any, float]]" = OrderedDict()
        self._max_size: int = max_size
        self._ttl: float = ttl
        self._lock: threading.RLock = threading.RLock()
        self._hits: int = 0
        self._misses: int = 0
        self._evictions: int = 0
        self._total_writes: int = 0

    def _cleanup_expired(self) -> int:
        """清理过期数据"""
        with self._lock:
            now = now_timestamp()
            expired_keys: List[str] = []
            for k, (v, ts) in self._store.items():
                if now - ts > self._ttl:
                    expired_keys.append(k)
            for k in expired_keys:
                self._store.pop(k, None)
            return len(expired_keys)

    def put(self, key: str, value: Any) -> None:
        """添加或更新"""
        with self._lock:
            self._store[key] = (value, now_timestamp())
            self._store.move_to_end(key)
            self._total_writes += 1
            if len(self._store) > self._max_size:
                self._store.popitem(last=False)
                self._evictions += 1

    def get(self, key: str, default: Optional[Any] = None) -> Optional[Any]:
        """获取数据"""
        with self._lock:
            if key in self._store:
                value, ts = self._store[key]
                if now_timestamp() - ts <= self._ttl:
                    self._store.move_to_end(key)
                    self._hits += 1
                    return value
                else:
                    self._store.pop(key, None)
            self._misses += 1
            return default

    def remove(self, key: str) -> bool:
        """删除数据"""
        with self._lock:
            return self._store.pop(key, None) is not None

    def contains(self, key: str) -> bool:
        """检查是否存在"""
        with self._lock:
            if key in self._store:
                _, ts = self._store[key]
                if now_timestamp() - ts <= self._ttl:
                    return True
                else:
                    self._store.pop(key, None)
            return False

    def keys(self) -> List[str]:
        """获取键列表"""
        with self._lock:
            now = now_timestamp()
            return [k for k, (_, ts) in self._store.items() if now - ts <= self._ttl]

    def values(self) -> List[Any]:
        """获取值列表"""
        with self._lock:
            now = now_timestamp()
            return [v for v, ts in self._store.values() if now - ts <= self._ttl]

    def items(self) -> List[Tuple[str, Any]]:
        """获取键值对"""
        with self._lock:
            now = now_timestamp()
            return [(k, v) for k, (v, ts) in self._store.items() if now - ts <= self._ttl]

    def cleanup(self) -> int:
        """清理过期数据"""
        return self._cleanup_expired()

    def clear(self) -> None:
        """清空所有数据"""
        with self._lock:
            self._store.clear()

    def __len__(self) -> int:
        """返回数据项数量"""
        with self._lock:
            return len(self._store)

    def __contains__(self, key: str) -> bool:
        """检查键是否存在"""
        return self.contains(key)

    @property
    def hit_rate(self) -> float:
        """命中率"""
        total = self._hits + self._misses
        return self._hits / total if total > 0 else 0.0

    @property
    def size(self) -> int:
        """数据项数量"""
        with self._lock:
            return len(self._store)

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            'size': self.size,
            'max_size': self._max_size,
            'hits': self._hits,
            'misses': self._misses,
            'hit_rate': self.hit_rate,
            'evictions': self._evictions,
            'writes': self._total_writes
        }

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        with self._lock:
            return {k: v for k, (v, _) in self._store.items()}


class MetricStore(StoreBase):
    """性能指标存储"""
    pass


class LogStore(StoreBase):
    """日志存储"""
    pass


class StateStore(StoreBase):
    """状态存储"""
    pass


class SnapshotStore(StoreBase):
    """快照存储"""
    pass


class IndexStore(StoreBase):
    """索引存储"""
    pass


class QueueStore(StoreBase):
    """队列存储"""
    pass


class TaskStore(StoreBase):
    """任务存储"""
    pass


class ResultStore(StoreBase):
    """结果存储"""
    pass


class _BaseStateMachine:
    """状态机基类"""

    class State(Enum):
        """状态枚举"""
        PENDING = 'pending'
        RUNNING = 'running'
        COMPLETED = 'completed'
        FAILED = 'failed'
        CANCELLED = 'cancelled'
        TIMEOUT = 'timeout'

    def __init__(self, states: Optional[Set[str]] = None, initial_state: str = 'pending') -> None:
        """初始化状态机"""
        self._initial_state = initial_state
        self._state: str = initial_state
        self._lock: threading.RLock = threading.RLock()
        self._history: deque = deque(maxlen=1000)
        self._transition_counts: Dict[str, int] = defaultdict(int)
        self._state_entered: Dict[str, float] = defaultdict(float)
        self._state_entered[self._state] = now_timestamp()
        self._listeners: Dict[str, List] = defaultdict(list)

    @property
    def state(self) -> str:
        """获取当前状态"""
        with self._lock:
            return self._state

    def add_listener(self, event_type: str, callback: Any) -> None:
        """添加事件监听器"""
        with self._lock:
            self._listeners[event_type].append(callback)
