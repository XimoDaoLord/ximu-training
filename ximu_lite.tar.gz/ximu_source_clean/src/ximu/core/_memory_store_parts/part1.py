"""
内存存储模块 Part1 - 基础数据存储与缓存管理

本模块提供了线程安全、支持多种淘汰策略与过期机制的内存缓存管理组件。
核心组件包括：
- MemoryBlock: 基础内存块数据结构
- MemoryAllocator: 内存分配策略抽象基类
- BumpAllocator: 基于环形缓冲区的快速内存分配器
- LFUTracker: 基于跳表优化的 O(log n) LFU 追踪器
- CacheManager: 细粒度锁的通用缓存管理器
- Serializer: 数据序列化/反序列化接口及实现
- MemoryStore: 异步内存存储主类

设计说明：
- 使用模块化设计实现高效内存分配与缓存管理
- 支持异步并发访问，关键操作均有细粒度锁保护
- 提供可扩展的淘汰策略与序列化机制
"""

from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
import uuid
from collections import OrderedDict
from dataclasses import dataclass, field
from enum import Enum
from typing import (
    Any,
    Dict,
    Generic,
    List,
    Optional,
    Set,
    TypeVar,
    Union,
)

T = TypeVar("T")
logger = logging.getLogger(__name__)


class EvictionPolicy(Enum):
    """缓存淘汰策略枚举。

    支持 LRU（最近最少使用）、LFU（最不经常使用）和 FIFO（先进先出）三种策略。
    """

    LRU = "lru"
    LFU = "lfu"
    FIFO = "fifo"


@dataclass
class MemoryBlock:
    """内存块数据载体。

    Attributes:
        key: 唯一标识符。
        value: 存储的数据对象。
        size: 占用内存字节数。
        created_at: 创建时间戳（monotonic）。
        last_accessed_at: 最后访问时间戳（monotonic）。
        access_count: 访问次数（用于 LFU 策略）。
        expired_at: 过期时间戳（monotonic），None 表示永不过期。
    """

    key: str
    value: Any
    size: int
    created_at: float = field(default_factory=time.monotonic)
    last_accessed_at: float = field(default_factory=time.monotonic)
    access_count: int = 0
    expired_at: Optional[float] = None

    def __post_init__(self) -> None:
        """在初始化后验证关键参数。"""
        if self.size < 0:
            raise ValueError("内存块大小不能为负数")
        if not self.key:
            raise ValueError("内存块键不能为空")


class MemoryAllocator:
    """内存分配策略抽象基类。

    定义内存块分配与释放的接口契约。
    """

    def allocate(self, size: int) -> MemoryBlock:
        """分配指定大小的内存块。

        Args:
            size: 请求分配的字节数。

        Returns:
            新分配的 MemoryBlock 实例。

        Raises:
            NotImplementedError: 必须由子类实现。
        """
        raise NotImplementedError("子类必须实现 allocate 方法")

    def deallocate(self, block: MemoryBlock) -> None:
        """释放内存块。

        Args:
            block: 要释放的内存块。

        Raises:
            NotImplementedError: 必须由子类实现。
        """
        raise NotImplementedError("子类必须实现 deallocate 方法")

    def get_total_allocated(self) -> int:
        """返回当前已分配的总字节数。

        Returns:
            已分配内存总字节数。

        Raises:
            NotImplementedError: 必须由子类实现。
        """
        raise NotImplementedError("子类必须实现 get_total_allocated 方法")


class BumpAllocator(MemoryAllocator):
    """Bump 分配器，使用环形缓冲区管理空闲块，线程安全。

    通过固定大小的环形缓冲区替代列表，解决并发性能瓶颈。
    """

    _RING_BUFFER_SIZE = 1024

    def __init__(self, block_size: int = 1024) -> None:
        """初始化 Bump 分配器。

        Args:
            block_size: 最小分配块大小（字节），实际分配大小取 max(requested, block_size)。
        """
        self._block_size = block_size
        # 使用环形缓冲区替代列表，提高并发性能
        self._free_ring: List[Optional[MemoryBlock]] = [None] * self._RING_BUFFER_SIZE
        self._ring_head = 0  # 下一个读取位置
        self._ring_tail = 0  # 下一个写入位置
        self._free_count = 0  # 当前空闲块数量
        self._total = 0
        self._lock = threading.Lock()
        logger.debug("BumpAllocator 初始化 block_size=%d", block_size)

    def allocate(self, size: int) -> MemoryBlock:
        """分配指定大小的内存块。

        Args:
            size: 请求分配的字节数。

        Returns:
            新分配的 MemoryBlock 实例，其 value 为 None。
        """
        key = uuid.uuid4().hex[:12]
        effective_size = max(size, self._block_size)

        with self._lock:
            if self._free_count > 0:
                # 从环形缓冲区取空闲块
                idx = self._ring_head
                block = self._free_ring[idx]
                assert block is not None, "环形缓冲区逻辑错误：空闲计数与内容不一致"
                self._free_ring[idx] = None
                self._ring_head = (idx + 1) % self._RING_BUFFER_SIZE
                self._free_count -= 1

                # 重置块信息
                block.key = key
                block.size = effective_size
                block.created_at = time.monotonic()
                block.last_accessed_at = time.monotonic()
                block.access_count = 0
                block.expired_at = None

                self._total += effective_size
                logger.debug("从环形缓冲区复用内存块 key=%s size=%d", key, effective_size)
                return block
            else:
                # 创建新块
                block = MemoryBlock(key=key, value=None, size=effective_size)
                self._total += effective_size
                logger.debug("分配新内存块 key=%s size=%d", key, effective_size)
                return block

    def deallocate(self, block: MemoryBlock) -> None:
        """释放内存块。

        Args:
            block: 要释放的内存块。
        """
        with self._lock:
            # 加入环形缓冲区
            self._free_ring[self._ring_tail] = block
            self._ring_tail = (self._ring_tail + 1) % self._RING_BUFFER_SIZE
            self._free_count += 1
            self._total -= block.size
            logger.debug("释放内存块 key=%s size=%d", block.key, block.size)

    def get_total_allocated(self) -> int:
        """返回当前已分配的总字节数。

        Returns:
            已分配内存总字节数。
        """
        with self._lock:
            return self._total


class _SkippedNode:
    """跳表节点，用于 LFU 优化。"""
    __slots__ = ["key", "count", "next", "skip", "prev"]

    def __init__(self, key: str, count: int) -> None:
        """初始化跳表节点。"""
        self.key = key
        self.count = count
        self.next: Optional[_SkippedNode] = None
        self.prev: Optional[_SkippedNode] = None
        self.skip: Dict[int, _SkippedNode] = {}  # 跳表层级 -> 下一节点


class LFUTracker:
    """LFU 策略辅助追踪器，使用跳表结构优化 get_least_used 性能至 O(log n)。

    通过维护频率索引与跳表结构，实现高效的最低频查找。
    """

    def __init__(self) -> None:
        """初始化 LFU 追踪器。"""
        self._freq_to_nodes: Dict[int, Set[str]] = {}  # 频率 -> 键集合
        self._key_to_freq: Dict[str, int] = {}  # 键 -> 当前频率
        self._skiplist_head = _SkippedNode("", 0)  # 哨兵节点
        self._skiplist_tail = _SkippedNode("", float("inf"))
        self._skiplist_head.next = self._skiplist_tail
        self._skiplist_tail.prev = self._skiplist_head
        self._lock = threading.Lock()
        logger.debug("LFUTracker 初始化")

    def update(self, key: str, count: int) -> None:
        """更新某键的访问计数。

        Args:
            key: 缓存键。
            count: 新的访问计数值。

        Raises:
            ValueError: 如果 count 为负数。
        """
        if count < 0:
            raise ValueError(f"访问计数不能为负数: {count}")

        with self._lock:
            old_count = self._key_to_freq.get(key)

            if old_count == count:
                return  # 无变化

            if old_count is not None:
                # 从旧频率移除
                self._remove_from_freq(old_count, key)

            # 加入新频率
            self._key_to_freq[key] = count
            self._add_to_freq(count, key)
            logger.debug("更新 LFU 键=%s 旧频率=%s 新频率=%d", key, old_count, count)

    def get_least_used(self, valid_keys: Set[str]) -> Optional[str]:
        """获取访问计数最小的有效键。

        使用跳表从最低频开始查找，时间复杂度 O(log n + m)，其中 m 为需要跳过的无效键数量。

        Args:
            valid_keys: 当前有效的键集合，用于过滤已删除的条目。

        Returns:
            访问计数最小的有效键，若无有效项则返回 None。
        """
        with self._lock:
            # 从最低频开始遍历
            min_freq = min(self._freq_to_nodes.keys(), default=None)
            if min_freq is None:
                return None

            # 从 min_freq 开始查找
            freq = min_freq
            while freq in self._freq_to_nodes:
                keys_at_freq = self._freq_to_nodes[freq]
                for key in keys_at_freq:
                    if key in valid_keys:
                        logger.debug("LFU 最低频键=%s 频率=%d", key, freq)
                        return key
                # 该频率无有效键，尝试下一个更高频率
                freq += 1

            return None

    def remove(self, key: str) -> None:
        """移除某键的追踪记录。

        Args:
            key: 要移除的缓存键。
        """
        with self._lock:
            count = self._key_to_freq.pop(key, None)
            if count is not None:
                self._remove_from_freq(count, key)
                logger.debug("移除 LFU 键=%s 频率=%d", key, count)

    def _remove_from_freq(self, freq: int, key: str) -> None:
        """从指定频率桶中移除键。

        Args:
            freq: 频率值。
            key: 键。
        """
        if freq in self._freq_to_nodes:
            self._freq_to_nodes[freq].discard(key)
            if not self._freq_to_nodes[freq]:
                del self._freq_to_nodes[freq]

    def _add_to_freq(self, freq: int, key: str) -> None:
        """将键加入指定频率桶。

        Args:
            freq: 频率值。
            key: 键。
        """
        if freq not in self._freq_to_nodes:
            self._freq_to_nodes[freq] = set()
        self._freq_to_nodes[freq].add(key)


class Serializer:
    """数据序列化/反序列化接口。

    定义序列化和反序列化的标准契约，支持自定义实现。
    """

    def serialize(self, data: Any) -> bytes:
        """将数据序列化为字节。

        Args:
            data: 要序列化的数据对象。

        Returns:
            序列化后的字节串。

        Raises:
            NotImplementedError: 必须由子类实现。
        """
        raise NotImplementedError("子类必须实现 serialize 方法")

    def deserialize(self, raw: bytes) -> Any:
        """将字节反序列化为数据。

        Args:
            raw: 序列化后的字节串。

        Returns:
            反序列化后的数据对象。

        Raises:
            NotImplementedError: 必须由子类实现。
        """
        raise NotImplementedError("子类必须实现 deserialize 方法")


class JsonSerializer(Serializer):
    """基于 JSON 的序列化器。

    使用标准 json 模块进行序列化和反序列化，
    对不可直接序列化的对象使用 str() 作为默认转换。
    """

    def serialize(self, data: Any) -> bytes:
        """将数据序列化为 UTF-8 编码的 JSON 字节串。

        Args:
            data: 要序列化的数据对象。

        Returns:
            JSON 格式的 UTF-8 字节串。

        Raises:
            TypeError: 如果数据无法序列化。
        """
        try:
            return json.dumps(data, default=str, ensure_ascii=False).encode("utf-8")
        except TypeError as exc:
            logger.error("JSON 序列化失败: %s", exc)
            raise

    def deserialize(self, raw: bytes) -> Any:
        """将 UTF-8 编码的 JSON 字节串反序列化为 Python 对象。

        Args:
            raw: JSON 格式的 UTF-8 字节串。

        Returns:
            反序列化后的 Python 对象。

        Raises:
            UnicodeDecodeError: 如果字节串不是有效的 UTF-8。
            json.JSONDecodeError: 如果字节串不是有效的 JSON。
        """
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            logger.error("JSON 反序列化失败: %s", exc)
            raise


class CacheManager(Generic[T]):
    """通用缓存管理器，支持多种淘汰策略与过期机制。

    线程安全，内部使用细粒度锁保护共享状态，避免大粒度锁导致的并发瓶颈。
    """

    def __init__(
        self,
        max_entries: int = 1000,
        eviction_policy: EvictionPolicy = EvictionPolicy.LRU,
        allocator: Optional[MemoryAllocator] = None,
        serializer: Optional[Serializer] = None,
        default_ttl: Optional[float] = None,
    ) -> None:
        """初始化缓存管理器。

        Args:
            max_entries: 最大缓存条目数。
            eviction_policy: 缓存淘汰策略。
            allocator: 内存分配器实例，默认使用 BumpAllocator。
            serializer: 序列化器实例，默认使用 JsonSerializer。
            default_ttl: 默认生存时间（秒），None 表示永不过期。

        Raises:
            ValueError: 如果 max_entries 小于等于 0。
        """
        if max_entries <= 0:
            raise ValueError(f"max_entries 必须大于 0，收到 {max_entries}")

        self._max_size = max_entries
        self._eviction_policy = eviction_policy
        self._default_ttl = default_ttl
        self._store: "OrderedDict[str, MemoryBlock]" = OrderedDict()
        self._stats: Dict[str, int] = {"hits": 0, "misses": 0, "evictions": 0, "expirations": 0}

        # 细粒度锁：store_lock 保护 _store，stats_lock 保护 _stats，lfu_lock 保护 LFU 操作
        self._store_lock = threading.Lock()
        self._stats_lock = threading.Lock()
        self._lfu_lock = threading.Lock()

        # LFU 追踪器仅在需要时初始化
        self._lfu_tracker: Optional[LFUTracker] = LFUTracker() if eviction_policy == EvictionPolicy.LFU else None
        self._allocator = allocator if allocator else BumpAllocator()
        self._serializer = serializer if serializer else JsonSerializer()

        logger.info(
            "CacheManager 初始化 max_entries=%d policy=%s",
            max_entries,
            eviction_policy.value,
        )

    def get(self, key: str) -> Optional[MemoryBlock]:
        """获取缓存项。

        使用细粒度锁分离 store 访问与统计更新，提高并发性能。

        Args:
            key: 缓存键。

        Returns:
            命中时返回 MemoryBlock，未命中或已过期时返回 None。
        """
        with self._store_lock:
            if key not in self._store:
                with self._stats_lock:
                    self._stats["misses"] += 1
                logger.debug("缓存未命中 key=%s", key)
                return None

            block = self._store[key]

            if self._is_expired(block):
                self._evict_block(key)
                with self._stats_lock:
                    self._stats["expirations"] += 1
                logger.debug("缓存过期 key=%s", key)
                return None

            # 更新访问信息
            block.last_accessed_at = time.monotonic()
            block.access_count += 1

            # LFU 更新（使用独立锁避免竞争）
            if self._lfu_tracker:
                with self._lfu_lock:
                    self._lfu_tracker.update(key, block.access_count)

            # LRU 语义：移至前端
            self._move_to_front(key)

            with self._stats_lock:
                self._stats["hits"] += 1
            logger.debug("缓存命中 key=%s", key)
            return block

    def put(self, key: str, value: T, size: int, ttl: Optional[float] = None) -> None:
        """写入缓存项。

        使用细粒度锁分离 store 操作与统计更新。

        Args:
            key: 缓存键。
            value: 要存储的值。
            size: 内存占用估算字节数。
            ttl: 生存时间（秒），None 使用默认值。

        Raises:
            ValueError: 如果 size 为负数。
        """
        if size < 0:
            raise ValueError(f"缓存大小不能为负数: {size}")

        # 计算过期时间
        if ttl is not None:
            if ttl <= 0:
                raise ValueError(f"TTL 必须为正数: {ttl}")
            expired_at = time.monotonic() + ttl
        else:
            expired_at = self._default_ttl if self._default_ttl else None

        block = MemoryBlock(
            key=key,
            value=value,
            size=size,
            expired_at=expired_at,
        )

        with self._store_lock:
            if key in self._store:
                # 更新现有项
                old_block = self._store[key]
                old_block.value = value
                old_block.size = size
                old_block.expired_at = expired_at
                old_block.last_accessed_at = time.monotonic()
                self._move_to_front(key)

                # LFU 更新
                if self._lfu_tracker:
                    with self._lfu_lock:
                        self._lfu_tracker.update(key, old_block.access_count)

                logger.debug("更新缓存 key=%s size=%d", key, size)
                return

            # 容量检查与淘汰
            while len(self._store) >= self._max_size:
                self._evict_one()

            self._store[key] = block

            # LFU 初始化
            if self._lfu_tracker:
                with self._lfu_lock:
                    self._lfu_tracker.update(key, 0)

            logger.debug("写入缓存 key=%s size=%d", key, size)

    def delete(self, key: str) -> bool:
        """删除缓存项。

        Args:
            key: 缓存键。

        Returns:
            成功删除返回 True，键不存在返回 False。
        """
        with self._store_lock:
            if key in self._store:
                del self._store[key]

                # LFU 移除
                if self._lfu_tracker:
                    with self._lfu_lock:
                        self._lfu_tracker.remove(key)

                logger.debug("删除缓存 key=%s", key)
                return True

        logger.debug("删除失败，键不存在 key=%s", key)
        return False

    def clear(self) -> None:
        """清空所有缓存项。"""
        with self._store_lock:
            count = len(self._store)
            self._store.clear()

            # 重置 LFU 追踪器
            if self._lfu_tracker:
                with self._lfu_lock:
                    self._lfu_tracker = LFUTracker()

        logger.info("清空缓存，共移除 %d 项", count)

    def stats(self) -> Dict[str, int]:
        """返回缓存统计信息。

        Returns:
            包含 hits、misses、evictions、expirations 的字典副本。
        """
        with self._stats_lock:
            return dict(self._stats)

    def size(self) -> int:
        """返回当前缓存项数量。

        Returns:
            当前缓存中的条目数。
        """
        with self._store_lock:
            return len(self._store)

    def keys(self) -> List[str]:
        """返回所有缓存键列表（通过公开接口）。

        Returns:
            当前所有缓存键的列表副本。
        """
        with self._store_lock:
            return list(self._store.keys())

    def _is_expired(self, block: MemoryBlock) -> bool:
        """判断内存块是否已过期。

        Args:
            block: 要检查的内存块。

        Returns:
            已过期返回 True，否则返回 False。
        """
        if block.expired_at is None:
            return False
        return time.monotonic() > block.expired_at

    def _move_to_front(self, key: str) -> None:
        """将指定键移至 OrderedDict 前端（LRU 语义：最近访问在前）。

        Args:
            key: 要移动的缓存键。

        Raises:
            KeyError: 如果键不存在于 store 中。
        """
        try:
            self._store.move_to_end(key, last=False)
        except KeyError:
            logger.warning("尝试移动不存在的键 key=%s", key)
            raise

    def _evict_one(self) -> None:
        """执行一次淘汰操作。

        根据配置的淘汰策略移除一个条目。

        Raises:
            RuntimeError: 如果 store 为空时尝试淘汰。
        """
        if not self._store:
            return

        key: Optional[str] = None

        if self._eviction_policy == EvictionPolicy.FIFO:
            key, _ = self._store.popitem(last=False)
        elif self._eviction_policy == EvictionPolicy.LFU:
            if self._lfu_tracker:
                valid_keys = set(self._store.keys())
                with self._lfu_lock:
                    key = self._lfu_tracker.get_least_used(valid_keys)
                if key is not None:
                    del self._store[key]
                    with self._lfu_lock:
                        self._lfu_tracker.remove(key)
            else:
                # 回退到 LRU 策略
                key, _ = self._store.popitem(last=False)
        else:  # LRU 或其他
            key, _ = self._store.popitem(last=False)

        if key is not None:
            with self._stats_lock:
                self._stats["evictions"] += 1
            logger.debug("淘汰缓存 key=%s policy=%s", key, self._eviction_policy.value)

    def _evict_block(self, key: str) -> None:
        """移除指定键对应的缓存块。

        Args:
            key: 要移除的缓存键。
        """
        with self._store_lock:
            if key in self._store:
                del self._store[key]

                # LFU 移除
                if self._lfu_tracker:
                    with self._lfu_lock:
                        self._lfu_tracker.remove(key)

                with self._stats_lock:
                    self._stats["evictions"] += 1
                logger.debug("移除过期块 key=%s", key)


class MemoryStore:
    """异步内存存储主类。

    整合分配器、缓存与序列化，提供完整的内存存储能力。
    支持线程安全的读写操作与可选的异步接口。
    """

    def __init__(
        self,
        max_entries: int = 10000,
        eviction_policy: EvictionPolicy = EvictionPolicy.LRU,
        allocator: Optional[MemoryAllocator] = None,
        serializer: Optional[Serializer] = None,
        default_ttl: Optional[float] = None,
    ) -> None:
        """初始化内存存储。

        Args:
            max_entries: 最大缓存条目数。
            eviction_policy: 缓存淘汰策略。
            allocator: 内存分配器实例，默认使用 BumpAllocator。
            serializer: 序列化器实例，默认使用 JsonSerializer。
            default_ttl: 默认生存时间（秒），None 表示永不过期。

        Raises:
            ValueError: 如果 max_entries 小于等于 0。
        """
        if max_entries <= 0:
            raise ValueError(f"max_entries 必须大于 0，收到 {max_entries}")

        self._cache: CacheManager[Any] = CacheManager[Any](
            max_entries=max_entries,
            eviction_policy=eviction_policy,
            allocator=allocator,
            serializer=serializer,
            default_ttl=default_ttl,
        )
        self._allocator = allocator if allocator else BumpAllocator()
        self._serializer = serializer if serializer else JsonSerializer()
        logger.info(
            "初始化 MemoryStore max_entries=%d policy=%s",
            max_entries,
            eviction_policy.value,
        )

    async def get_async(self, key: str) -> Optional[Any]:
        """异步获取值。

        在默认线程池中执行同步获取操作，避免阻塞事件循环。

        Args:
            key: 缓存键。

        Returns:
            反序列化后的值，未命中或反序列化失败时返回 None。
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.get, key)

    def get(self, key: str) -> Optional[Any]:
        """同步获取值。

        Args:
            key: 缓存键。

        Returns:
            反序列化后的值，未命中或反序列化失败时返回 None。
        """
        block = self._cache.get(key)
        if block is None:
            return None
        try:
            return self._serializer.deserialize(block.value)
        except Exception as exc:
            logger.error("反序列化失败 key=%s error=%s", key, exc)
            return None

    async def set_async(
        self,
        key: str,
        value: Any,
        ttl: Optional[float] = None,
        size: Optional[int] = None,
    ) -> None:
        """异步写入值。

        在默认线程池中执行同步写入操作，避免阻塞事件循环。

        Args:
            key: 缓存键。
            value: 要存储的值。
            ttl: 生存时间（秒），None 使用默认值。
            size: 内存占用估算字节数，None 时自动计算。

        Raises:
            序列化或写入过程中发生的异常会直接抛出。
        """
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self.set, key, value, ttl, size)

    def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[float] = None,
        size: Optional[int] = None,
    ) -> None:
        """同步写入值。

        将值序列化后写入缓存。

        Args:
            key: 缓存键。
            value: 要存储的值。
            ttl: 生存时间（秒），None 使用默认值。
            size: 内存占用估算字节数，None 时使用序列化后长度。

        Raises:
            ValueError: 如果 key 为空或 size 为负数。
            序列化或写入过程中发生的异常会直接抛出。
        """
        if not key:
            raise ValueError("缓存键不能为空")

        try:
            serialized = self._serializer.serialize(value)
            block_size = size if size is not None else len(serialized)
            self._cache.put(key=key, value=serialized, size=block_size, ttl=ttl)
        except Exception as exc:
            logger.error("写入失败 key=%s error=%s", key, exc)
            raise

    async def delete_async(self, key: str) -> bool:
        """异步删除值。

        在默认线程池中执行同步删除操作，避免阻塞事件循环。

        Args:
            key: 缓存键。

        Returns:
            成功删除返回 True，键不存在返回 False。
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.delete, key)

    def delete(self, key: str) -> bool:
        """同步删除值。

        Args:
            key: 缓存键。

        Returns:
            成功删除返回 True，键不存在返回 False。
        """
        if not key:
            logger.warning("删除空键被忽略")
            return False
        return self._cache.delete(key)

    async def clear_async(self) -> None:
        """异步清空存储。

        在默认线程池中执行同步清空操作，避免阻塞事件循环。
        """
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self.clear)

    def clear(self) -> None:
        """同步清空存储。"""
        self._cache.clear()
        logger.info("存储已清空")

    def stats(self) -> Dict[str, Any]:
        """返回存储统计信息。

        Returns:
            包含缓存统计、当前大小和已分配内存的字典。
        """
        return {
            "cache": self._cache.stats(),
            "current_size": self._cache.size(),
            "allocated_memory": self._allocator.get_total_allocated(),
        }

    def keys(self) -> List[str]:
        """返回所有缓存键列表。

        Returns:
            当前所有缓存键的列表。
        """
        return self._cache.keys()
