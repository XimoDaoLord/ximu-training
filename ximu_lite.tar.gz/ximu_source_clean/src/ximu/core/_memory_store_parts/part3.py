"""内存存储扩展处理器与轻量级线性回归模块。

提供线程安全的内存存储处理器（MemoryStoreProcessor）和轻量级线性回归算法（LinearRegressionAlgorithm），支持数据转换、统计追踪、历史管理和配置管理功能。
"""

from __future__ import annotations
import json
import logging
import math
import hashlib
import threading
import time
from abc import ABC, abstractmethod
from collections import deque
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any, Deque, Dict, List, Optional, Tuple, Union
import numpy as np

# 数据类型别名
DataLike = Union[Dict[str, Any], List[Any], Tuple[Any, ...], int, float, str, None]

# 日志记录器
logger = logging.getLogger(__name__)

@dataclass
class ProcessorConfig:
    """处理器配置数据类，用于定义处理器的基本参数。

    Attributes:
        name: 处理器名称。
        version: 版本号。
        history_limit: 历史记录最大长度。
        hash_algorithm: 哈希算法名称。
        extra: 额外配置项。
    """

    name: str = "memory_store_processor"
    version: str = "1.0.0"
    history_limit: int = 5000
    hash_algorithm: str = "sha256"
    extra: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """初始化后验证配置有效性。"""
        if not isinstance(self.history_limit, int) or self.history_limit <= 0:
            raise ValueError("history_limit must be a positive integer")
        if not isinstance(self.hash_algorithm, str):
            raise ValueError("hash_algorithm must be a string")
        try:
            hashlib.new(self.hash_algorithm, b"").digest()
        except ValueError as e:
            raise ValueError(f"Unsupported hash algorithm: {self.hash_algorithm}") from e

    @staticmethod
    def _validate_config(self: 'ProcessorConfig') -> None:
        """配置有效性验证（保留接口兼容性）。"""
        pass  # 验证逻辑已移至 __post_init__

@lru_cache(maxsize=1)
def get_default_config() -> ProcessorConfig:
    """获取默认配置实例（缓存以保证单例）。

    Returns:
        ProcessorConfig: 默认配置对象。
    """
    return ProcessorConfig()

class SafeJSON:
    """安全序列化工具类，提供防异常的 JSON 编解码方法。"""

    @staticmethod
    def dumps(obj: Any) -> str:
        """安全序列化为 JSON 字符串。

        Args:
            obj: 待序列化的对象。

        Returns:
            序列化后的 JSON 字符串。
        """
        try:
            return json.dumps(obj, default=lambda x: str(x), ensure_ascii=False)
        except (TypeError, ValueError) as e:
            logger.warning("JSON serialization failed for object: %s", e)
            return str(obj)

    @staticmethod
    def loads(text: str) -> Any:
        """安全反序列化为 Python 对象。

        Args:
            text: JSON 字符串。

        Returns:
            反序列化后的 Python 对象，失败时返回原始字符串。
        """
        if not isinstance(text, str):
            raise TypeError(f"Expected string, got {type(text).__name__}")
        try:
            return json.loads(text)
        except (json.JSONDecodeError, TypeError) as e:
            logger.warning("JSON deserialization failed: %s", e)
            return text

class _Stopwatch:
    """轻量级计时器，用于测量代码执行时间。"""

    def __init__(self) -> None:
        """初始化计时器。"""
        self._start: Optional[float] = None

    def start(self) -> '_Stopwatch':
        """启动计时。

        Returns:
            计时器实例本身，支持链式调用。
        """
        self._start = time.time()
        return self

    def stop(self) -> float:
        """停止计时并返回耗时（秒）。

        Returns:
            耗时秒数，若未启动则返回 0.0。
        """
        if self._start is None:
            return 0.0
        elapsed = time.time() - self._start
        self._start = None
        return elapsed

def _now() -> float:
    """获取当前时间戳。

    Returns:
        当前时间戳（秒）。
    """
    return time.time()

class MemoryStoreProcessor(ABC):
    """线程安全的内存存储处理器抽象基类。

    提供数据转换、统计追踪、历史管理等核心功能，并通过锁保证线程安全。
    """

    def __init__(self, config: Optional[ProcessorConfig] = None) -> None:
        """初始化处理器。

        Args:
            config: 处理器配置，若为 None 则使用默认配置。
        """
        self._config = config or get_default_config()
        self._lock = threading.RLock()
        self._cache: Dict[str, Any] = {}
        self._stats: Dict[str, Union[int, float]] = {
            "processed": 0,
            "success": 0,
            "failed": 0,
            "total_time": 0.0
        }
        self._history: Deque[Tuple[float, str, bool, float]] = deque(maxlen=self._config.history_limit)
        self._state: str = "idle"
        self._init_log()

    @abstractmethod
    def _transform(self, data: Any, step: int) -> Any:
        """数据转换方法抽象，子类需实现具体逻辑。

        Args:
            data: 待转换的数据。
            step: 当前步骤编号。

        Returns:
            转换后的数据。
        """
        ...

    @property
    def name(self) -> str:
        """获取处理器名称。

        Returns:
            处理器名称。
        """
        return self._config.name

    @property
    def version(self) -> str:
        """获取版本号。

        Returns:
            版本号。
        """
        return self._config.version

    def _compute_hash(self, data: Any) -> str:
        """计算数据哈希值。

        Args:
            data: 待计算哈希的数据。

        Returns:
            哈希字符串。
        """
        if data is None:
            data_bytes = b""
        elif isinstance(data, bytes):
            data_bytes = data
        else:
            data_bytes = str(data).encode("utf-8")
        hash_func = hashlib.new(self._config.hash_algorithm, data_bytes)
        return hash_func.hexdigest()

    def _transform(self, data: Any, step: int) -> Any:
        """通用数据转换逻辑，实现基类抽象方法。

        Args:
            data: 待转换的数据。
            step: 当前步骤编号。

        Returns:
            转换后的数据。
        """
        if data is None:
            return None

        # 深拷贝字典以避免修改原始数据
        if isinstance(data, dict):
            result = dict(data)
            result["_processed_by"] = self.name
            result["_step"] = step
            result["_ts"] = _now()
            result["_hash"] = self._compute_hash(result)
            return result

        if isinstance(data, (list, tuple)):
            transformed = [self._transform(item, step) for item in data]
            return tuple(transformed) if isinstance(data, tuple) else transformed

        if isinstance(data, (int, float)) and not isinstance(data, bool):
            if step > 1000:
                raise ValueError("Step exceeds safe range")
            return data * (1.0 + step * 0.01)

        if isinstance(data, str):
            return f"{data}_processed_{step}"

        return data

    def process_step(self, data: DataLike, step: int, **kwargs: Any) -> Optional[Any]:
        """执行单步数据处理。

        Args:
            data: 待处理的数据。
            step: 步骤编号。
            **kwargs: 额外参数。

        Returns:
            处理后的数据，若失败则返回 None。
        """
        with self._lock:
            self._state = "processing"
            stopwatch = _Stopwatch().start()
            result: Optional[Any] = None
            success = False

            try:
                result = self._transform(data, step)
                success = True
            except Exception as e:
                logger.exception("Exception during process_step=%s in %s", step, self.name)
                result = None
                success = False
            finally:
                elapsed = stopwatch.stop()

            self._stats["processed"] += 1
            self._stats["total_time"] += elapsed
            self._stats["success"] += 1 if success else 0
            self._stats["failed"] += 1 if not success else 0

            self._history.append((_now(), f"process_step_{step}", success, elapsed))
            self._state = "idle"

            logger.debug("process_step(%s) in %s success=%s elapsed=%.6fs",
                         step, self.name, success, elapsed)
            return result

    def batch_process(self, items: List[DataLike], steps: int = 12) -> List[Any]:
        """批量处理数据，每次调用一个步骤并聚合结果。

        Args:
            items: 待批量处理的数据列表。
            steps: 处理步骤数，默认为 12。

        Returns:
            处理后的数据列表。
        """
        if steps <= 0:
            raise ValueError("steps must be positive")
        if not items:
            return []

        results: List[Any] = []
        with self._lock:
            for item in items:
                transformed = item
                for j in range(steps):
                    transformed = self._transform(transformed, j)
                results.append(transformed)
            logger.debug("batch_process in %s: %d items, %d steps", self.name, len(items), steps)
        return results

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取统计快照。

        Returns:
            统计数据字典。
        """
        with self._lock:
            return dict(self._stats)

    def get_history(self, limit: int = 100) -> List[Tuple[float, str, bool, float]]:
        """获取历史记录。

        Args:
            limit: 返回记录数量限制。

        Returns:
            历史记录列表，每项为 (时间戳, 事件, 成功标志, 耗时)。
        """
        if limit <= 0:
            raise ValueError("limit must be positive")
        with self._lock:
            history_list = list(self._history)
            return history_list[-limit:] if limit < len(history_list) else history_list

    def reset(self) -> None:
        """重置处理器状态。"""
        with self._lock:
            self._stats = {"processed": 0, "success": 0, "failed": 0, "total_time": 0.0}
            self._history.clear()
            self._state = "idle"
            logger.debug("Reset %s to initial state", self.name)

    def validate(self, data: Any) -> Tuple[bool, str]:
        """验证数据有效性。

        Args:
            data: 待验证的数据。

        Returns:
            (是否有效, 错误原因) 元组。
        """
        if data is None:
            return (False, "DATA_IS_NONE")
        if isinstance(data, dict) and not data:
            return (False, "EMPTY_DICT")
        if isinstance(data, (list, tuple)) and len(data) == 0:
            return (False, "EMPTY_COLLECTION")
        return (True, "VALID")

    def serialize(self) -> str:
        """序列化为 JSON 字符串。

        Returns:
            JSON 字符串。
        """
        return SafeJSON.dumps(self.to_dict())

    def deserialize(self, text: str) -> 'MemoryStoreProcessor':
        """从 JSON 字符串反序列化。

        Args:
            text: JSON 字符串。

        Returns:
            新的处理器实例。
        """
        with self._lock:
            config_dict = SafeJSON.loads(text)
            config = self.from_dict(config_dict)
            return self.__class__(config)

    def get_config(self, key: str, default: Optional[Any] = None) -> Any:
        """获取配置项。

        Args:
            key: 配置键。
            default: 默认值。

        Returns:
            配置值或默认值。
        """
        return self._config.extra.get(key, default)

    def set_config(self, key: str, value: Any) -> None:
        """设置配置项。

        Args:
            key: 配置键。
            value: 配置值。
        """
        with self._lock:
            self._config.extra[key] = value
            logger.debug("Config updated in %s: %s=%s", self.name, key, value)

    def to_dict(self) -> Dict[str, Any]:
        """导出状态为字典。

        Returns:
            状态字典。
        """
        return {
            "name": self.name,
            "version": self.version,
            "state": self._state,
            "stats": self.get_stats(),
            "config": dict(self._config.extra)
        }

    @classmethod
    def from_dict(cls, config: Dict[str, Any]) -> 'MemoryStoreProcessor':
        """从字典创建处理器实例。

        Args:
            config: 配置字典。

        Returns:
            处理器实例。
        """
        config = ProcessorConfig(**config.get("config", {}))
        return cls(config)

    def _init_log(self) -> None:
        """初始化日志记录器。"""
        logger.debug("Initialized %s with version %s", self.name, self.version)

# 线性回归模块已拆分至 part3_linear_regression.py
