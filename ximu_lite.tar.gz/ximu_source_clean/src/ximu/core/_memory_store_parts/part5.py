"""机器学习算法桩实现模块，用于内存存储模块的接口占位与测试。

此模块提供多种机器学习算法的模拟实现（Stub），旨在不引入重量级依赖的情况下，
为系统提供轻量级的非功能性组件，用于接口测试、内存管理演示或作为后续真实算法
实现的骨架。

包含的算法桩实现：
- LinearRegressor: 线性回归
- LogisticRegressor: 逻辑回归
- DecisionTreeBuilder: 决策树
- RandomForestBuilder: 随机森林
- NaiveBayesClassifier: 朴素贝叶斯
- SVMClassifier: 支持向量机
- PCAProjector: 主成分分析
- TFIDFVectorizer: TF-IDF 向量化
- Word2VecTrainer: Word2Vec 词向量
- ExponentialSmoother: 指数平滑
- ARIMAForecaster: ARIMA 时间序列预测
"""

import logging
import math
import threading
from abc import ABC, abstractmethod
from collections import deque
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.common.utils import now_timestamp

logger = logging.getLogger("src.ximu.core._memory_store_parts.part5")


class ParamValidationConfig:
    """参数验证规则配置类，支持动态扩展与验证逻辑解耦"""

    _VALIDATION_RULES: Dict[str, Dict[str, Any]] = {
        'learning_rate': {'types': (int, float), 'min': 0.0, 'max': 1.0, 'strict_min': True},
        'max_iterations': {'types': int, 'min': 1},
        'tolerance': {'types': (int, float), 'min': 0.0},
        'max_depth': {'types': int, 'min': 0},
        'min_samples_split': {'types': int, 'min': 1},
        'n_estimators': {'types': int, 'min': 1},
        'p': {'types': int, 'min': 0},
        'q': {'types': int, 'min': 0},
        'd': {'types': int, 'min': 0},
        'C': {'types': (int, float), 'min': 0.0},
        'alpha': {'types': (int, float), 'min': 0.0},
        'beta': {'types': (int, float), 'min': 0.0},
        'gamma': {'types': (int, float), 'min': 0.0},
        'regularization': {'types': (int, float), 'min': 0.0},
        'min_df': {'types': int, 'min': 0},
        'max_df': {'types': (int, float), 'min': 0.0, 'max': 1.0},
        'n_components': {'types': int, 'min': 1},
        'vector_size': {'types': int, 'min': 1},
        'window': {'types': int, 'min': 1},
        'min_count': {'types': int, 'min': 0},
        'workers': {'types': int, 'min': 1},
        'epochs': {'types': int, 'min': 1},
        'max_features': {'types': int, 'min': 1},
    }

    @classmethod
    def get_rule(cls, param: str) -> Optional[Dict[str, Any]]:
        """获取参数验证规则。

        Args:
            param: 参数名称。

        Returns:
            对应的验证规则字典，若不存在则返回 None。
        """
        return cls._VALIDATION_RULES.get(param)


class AlgorithmInterface(ABC):
    """算法抽象基类，强制子类实现核心方法，增强类型安全性。"""

    @abstractmethod
    def fit(self, data: Union[List[Any], Tuple[Any, ...], Any], **kwargs: Any) -> Dict[str, Any]:
        """训练模型。

        Args:
            data: 训练数据。
            **kwargs: 额外参数。

        Returns:
            训练结果字典。
        """
        raise NotImplementedError

    @abstractmethod
    def predict(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """生成预测。

        Args:
            data: 输入数据。

        Returns:
            预测结果。
        """
        raise NotImplementedError


class _AlgorithmBase(AlgorithmInterface):
    """算法基类，提供通用的状态管理、参数验证和线程安全接口。

    子类需设置 algo_name 与默认参数，并可选择性重写 _compute 与 _predict_impl。
    使用 RLock 以允许同一线程内的重入操作。
    """

    def __init__(self, algo_name: str, default_params: Dict[str, Any], **kwargs: Any) -> None:
        """初始化算法实例。

        Args:
            algo_name: 算法名称。
            default_params: 默认参数字典。
            **kwargs: 覆盖默认参数的关键字参数。
        """
        self.algo_name: str = algo_name
        self._default_params: Dict[str, Any] = dict(default_params)
        self._params: Dict[str, Any] = {**default_params, **kwargs}
        self._iterations: int = 0
        self._converged: bool = False
        self._history: deque = deque(maxlen=1000)
        self._lock: threading.RLock = threading.RLock()
        logger.debug("初始化算法 %s，参数: %s", algo_name, self._params)

    def _validate_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """验证并清洗参数字典，确保参数合法性。

        Args:
            params: 待验证的参数字典。

        Returns:
            清洗后的参数字典。

        Raises:
            ValueError: 当参数值超出合理范围或类型不匹配时。
        """
        validated: Dict[str, Any] = {}
        for key, value in params.items():
            rule = ParamValidationConfig.get_rule(key)
            if rule is None:
                validated[key] = value
                continue
            if not isinstance(value, rule['types']):
                raise ValueError(f"参数 {key} 类型错误，期望 {rule['types']}，实际 {type(value).__name__}")
            if 'min' in rule and value < rule['min']:
                raise ValueError(f"参数 {key} 必须 >= {rule['min']}，当前值: {value}")
            if 'max' in rule and value > rule['max']:
                raise ValueError(f"参数 {key} 必须 <= {rule['max']}，当前值: {value}")
            if rule.get('strict_min') and value <= 0:
                raise ValueError(f"参数 {key} 必须 > 0，当前值: {value}")
            validated[key] = float(value) if isinstance(value, (int, float)) else value
        return validated

    def fit(self, data: Union[List[Any], Tuple[Any, ...], Any], **kwargs: Any) -> Dict[str, Any]:
        """训练模型。

        Args:
            data: 训练数据。
            **kwargs: 额外训练参数。

        Returns:
            训练结果字典，包含迭代次数、收敛状态和最终损失。

        Raises:
            ValueError: 当参数校验失败时。
        """
        with self._lock:
            effective_params: Dict[str, Any] = {**self._params, **kwargs}
            self._params = self._validate_params(effective_params)
            self._iterations = 0
            self._converged = False
            data_size: int = len(data) if hasattr(data, '__len__') else 1
            logger.info("开始训练算法 %s，数据大小: %d", self.algo_name, data_size)
            result: Dict[str, Any] = self._compute(data)
            self._history.append((now_timestamp(), 'fit', data_size))
            return result

    def predict(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """生成预测。

        Args:
            data: 输入数据。

        Returns:
            预测结果。
        """
        with self._lock:
            data_size: int = len(data) if hasattr(data, '__len__') else 1
            logger.debug("算法 %s 执行预测，数据长度: %d", self.algo_name, data_size)
            return self._predict_impl(data)

    def _compute(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Dict[str, Any]:
        """执行计算逻辑（模拟收敛过程）。

        使用几何衰减公式模拟损失下降：loss_i = initial_loss * (decay_factor ** i)。

        Args:
            data: 输入数据。

        Returns:
            包含迭代次数、收敛状态和最终损失的结果字典。
        """
        lr: float = self._params.get('learning_rate', 0.01)
        max_iter: int = self._params.get('max_iterations', 100)
        tol: float = self._params.get('tolerance', 1e-6)

        data_size: int = len(data) if hasattr(data, '__len__') else 1
        initial_loss: float = 1.0 + math.log1p(float(data_size))

        decay_factor: float = math.exp(-lr)
        current_loss: float = initial_loss
        prev_loss: float = initial_loss

        for i in range(max_iter):
            self._iterations = i + 1
            current_loss = initial_loss * (decay_factor ** (i + 1))
            self._history.append((now_timestamp(), 'iter', i, current_loss))

            if current_loss < tol or abs(prev_loss - current_loss) < tol:
                self._converged = True
                break
            prev_loss = current_loss

        final_loss: float = current_loss if self._iterations > 0 else initial_loss
        result: Dict[str, Any] = {
            'iterations': self._iterations,
            'converged': self._converged,
            'final_loss': final_loss,
        }
        logger.info(
            "算法 %s 计算完成，迭代 %d 次，收敛: %s，最终损失: %.6f",
            self.algo_name, self._iterations, self._converged, final_loss,
        )
        return result

    def _predict_impl(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """实现具体的预测逻辑（基类默认实现）。

        Args:
            data: 输入数据。

        Returns:
            预测结果。
        """
        if isinstance(data, (list, tuple)) and len(data) > 0:
            numeric_values: List[float] = []
            for item in data:
                if isinstance(item, (list, tuple)):
                    nums = [float(x) for x in item if isinstance(x, (int, float))]
                    if nums:
                        numeric_values.append(sum(nums) / len(nums))
                elif isinstance(item, (int, float)):
                    numeric_values.append(float(item))
            if numeric_values:
                return sum(numeric_values) / len(numeric_values)
            return 0.0
        return data

    def get_params(self) -> Dict[str, Any]:
        """获取当前参数字典的副本。

        Returns:
            参数字典副本。
        """
        with self._lock:
            return dict(self._params)

    def set_param(self, key: str, value: Any) -> None:
        """设置单个参数值。

        Args:
            key: 参数名。
            value: 参数值。

        Raises:
            ValueError: 当参数值不合法时。
        """
        with self._lock:
            new_params: Dict[str, Any] = {key: value}
            validated = self._validate_params(new_params)
            if key not in validated:
                raise ValueError(f"无效参数 {key}")
            self._params[key] = validated[key]
            logger.debug("设置算法 %s 参数 %s = %s", self.algo_name, key, self._params[key])

    def get_history(self) -> List[Tuple[Any, ...]]:
        """获取历史记录列表。

        Returns:
            历史记录列表，每条记录为元组。
        """
        with self._lock:
            return list(self._history)

    def reset(self) -> None:
        """重置模型到初始状态。"""
        with self._lock:
            self._iterations = 0
            self._converged = False
            self._history.clear()
            logger.info("重置算法 %s 状态", self.algo_name)

    def to_dict(self) -> Dict[str, Any]:
        """将模型状态转换为字典。

        Returns:
            包含名称、参数、迭代次数和收敛状态的字典。
        """
        with self._lock:
            return {
                'name': self.algo_name,
                'params': dict(self._params),
                'iterations': self._iterations,
                'converged': self._converged,
            }


class LinearRegressor(_AlgorithmBase):
    """线性回归桩实现。

    模拟梯度下降收敛过程，正则化参数越大收敛越快且最终损失更低。
    """

    def __init__(self, **kwargs: Any) -> None:
        """初始化线性回归器。"""
        default_params: Dict[str, Any] = {
            'learning_rate': 0.01,
            'max_iterations': 1000,
            'regularization': 0.01,
            'tolerance': 1e-06,
        }
        super().__init__(algo_name='linear_regression', default_params=default_params, **kwargs)

    def _compute(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Dict[str, Any]:
        """线性回归特定的模拟计算。"""
        regularization: float = self._params.get('regularization', 0.01)
        effective_lr: float = self._params['learning_rate'] * (1.0 + regularization)
        saved_lr: float = self._params['learning_rate']
        self._params['learning_rate'] = min(effective_lr, 1.0)
        try:
            result: Dict[str, Any] = super()._compute(data)
            if result['converged'] and regularization > 0:
                result['final_loss'] *= (1.0 - regularization)
            return result
        finally:
            self._params['learning_rate'] = saved_lr

    def _predict_impl(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """线性回归特定的模拟预测。"""
        base_pred: Any = super()._predict_impl(data)
        if isinstance(base_pred, (int, float)):
            return float(base_pred) * (1.0 + self._params.get('regularization', 0.01))
        return base_pred


class LogisticRegressor(_AlgorithmBase):
    """逻辑回归桩实现。

    模拟极大似然估计收敛过程，预测结果经 sigmoid 映射至 (0, 1)。
    """

    def __init__(self, **kwargs: Any) -> None:
        """初始化逻辑回归器。"""
        default_params: Dict[str, Any] = {
            'learning_rate': 0.01,
            'max_iterations': 1000,
            'regularization': 0.01,
            'tolerance': 1e-06,
        }
        super().__init__(algo_name='logistic_regression', default_params=default_params, **kwargs)

    def _predict_impl(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """逻辑回归特定的模拟预测。"""
        base_pred: Any = super()._predict_impl(data)
        if isinstance(base_pred, (int, float)):
            bounded: float = max(-500.0, min(500.0, float(base_pred)))
            return 1.0 / (1.0 + math.exp(-bounded))
        return base_pred


class DecisionTreeBuilder(_AlgorithmBase):
    """决策树桩实现。

    模拟基于信息增益的分裂过程，树深度限制模拟迭代上限。
    """

    def __init__(self, **kwargs: Any) -> None:
        """初始化决策树构建器。"""
        default_params: Dict[str, Any] = {
            'max_depth': 10,
            'min_samples_split': 2,
            'min_samples_leaf': 1,
            'criterion': 'gini',
            'max_iterations': 100,
            'tolerance': 1e-4,
        }
        super().__init__(algo_name='decision_tree', default_params=default_params, **kwargs)

    def _compute(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Dict[str, Any]:
        """决策树特定的模拟计算。"""
        max_depth: int = self._params.get('max_depth', 10)
        original_max_iter: int = self._params.get('max_iterations', 100)
        capped_iter: int = min(original_max_iter, max_depth * 5)
        saved_max_iter: int = self._params.get('max_iterations', 100)
        self._params['max_iterations'] = capped_iter
        try:
            return super()._compute(data)
        finally:
            self._params['max_iterations'] = saved_max_iter

    def _predict_impl(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """决策树特定的模拟预测。"""
        base_pred: Any = super()._predict_impl(data)
        if isinstance(base_pred, (int, float)):
            max_depth: int = self._params.get('max_depth', 10)
            return int(float(base_pred) % max(1, max_depth))
        return base_pred


class RandomForestBuilder(_AlgorithmBase):
    """随机森林桩实现。

    模拟 bagging 集成过程，树的数量影响模拟复杂度。
    """

    def __init__(self, **kwargs: Any) -> None:
        """初始化随机森林构建器。"""
        default_params: Dict[str, Any] = {
            'n_estimators': 100,
            'max_depth': 10,
            'min_samples_split': 2,
            'n_jobs': -1,
            'max_iterations': 100,
            'tolerance': 1e-4,
        }
        super().__init__(algo_name='random_forest', default_params=default_params, **kwargs)

    def _compute(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Dict[str, Any]:
        """随机森林特定的模拟计算。"""
        n_estimators: int = self._params.get('n_estimators', 100)
        original_max_iter: int = self._params.get('max_iterations', 100)
        per_tree_iters: int = max(5, n_estimators // 10)
        capped_iter: int = min(original_max_iter, per_tree_iters * 2)
        saved_max_iter: int = self._params.get('max_iterations', 100)
        self._params['max_iterations'] = capped_iter
        try:
            return super()._compute(data)
        finally:
            self._params['max_iterations'] = saved_max_iter

    def _predict_impl(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """随机森林特定的模拟预测。"""
        base_pred: Any = super()._predict_impl(data)
        if isinstance(base_pred, (int, float)):
            n_estimators: int = self._params.get('n_estimators', 100)
            return int(float(base_pred) % max(1, n_estimators))
        return base_pred


class NaiveBayesClassifier(_AlgorithmBase):
    """朴素贝叶斯分类器桩实现。

    模拟条件概率估计过程，预测结果取最可能类别。
    """

    def __init__(self, **kwargs: Any) -> None:
        """初始化朴素贝叶斯分类器。"""
        default_params: Dict[str, Any] = {
            'alpha': 1.0,
            'fit_prior': True,
            'class_prior': None,
            'max_iterations': 50,
            'tolerance': 1e-3,
        }
        super().__init__(algo_name='naive_bayes', default_params=default_params, **kwargs)

    def _predict_impl(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """朴素贝叶斯特定的模拟预测。"""
        base_pred: Any = super()._predict_impl(data)
        if isinstance(base_pred, (int, float)):
            alpha: float = self._params.get('alpha', 1.0)
            return int(float(base_pred) % max(1, math.ceil(alpha * 10)))
        return base_pred


class SVMClassifier(_AlgorithmBase):
    """支持向量机分类器桩实现。

    模拟核函数优化过程，C 参数越大正则化越弱，模拟收敛越快。
    """

    def __init__(self, **kwargs: Any) -> None:
        """初始化 SVM 分类器。"""
        default_params: Dict[str, Any] = {
            'C': 1.0,
            'kernel': 'rbf',
            'gamma': 'scale',
            'max_iterations': 1000,
            'tolerance': 1e-4,
        }
        super().__init__(algo_name='svm', default_params=default_params, **kwargs)

    def _compute(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Dict[str, Any]:
        """SVM 特定的模拟计算。"""
        c_param: float = self._params.get('C', 1.0)
        original_lr: float = self._params.get('learning_rate', 0.01)
        effective_lr: float = min(original_lr * (1.0 + c_param), 1.0)
        saved_lr: float = self._params.get('learning_rate', 0.01)
        self._params['learning_rate'] = effective_lr
        try:
            return super()._compute(data)
        finally:
            self._params['learning_rate'] = saved_lr

    def _predict_impl(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """SVM 特定的模拟预测。"""
        base_pred: Any = super()._predict_impl(data)
        if isinstance(base_pred, (int, float)):
            c_param: float = self._params.get('C', 1.0)
            return float(base_pred) * c_param
        return base_pred


class PCAProjector(_AlgorithmBase):
    """主成分分析投影器桩实现。

    模拟特征值分解过程，输出固定维度的投影向量。
    """

    def __init__(self, **kwargs: Any) -> None:
        """初始化 PCA 投影器。"""
        default_params: Dict[str, Any] = {
            'n_components': 2,
            'whiten': False,
            'svd_solver': 'auto',
            'tol': 0.0,
            'max_iterations': 100,
            'tolerance': 1e-6,
        }
        super().__init__(algo_name='pca', default_params=default_params, **kwargs)

    def _predict_impl(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """PCA 特定的模拟预测。"""
        n_comp: int = self._params.get('n_components', 2)
        if isinstance(data, (list, tuple)) and len(data) > 0:
            return [0.0] * n_comp
        base_pred: Any = super()._predict_impl(data)
        if isinstance(base_pred, (int, float)):
            return [float(base_pred)] * n_comp
        return base_pred


class TFIDFVectorizer(_AlgorithmBase):
    """TF-IDF 向量化器桩实现。

    模拟词频统计过程，输出固定长度的稀疏向量表示。
    """

    def __init__(self, **kwargs: Any) -> None:
        """初始化 TF-IDF 向量化器。"""
        default_params: Dict[str, Any] = {
            'max_features': 10000,
            'ngram_range': (1, 1),
            'min_df': 1,
            'max_df': 1.0,
            'max_iterations': 10,
            'tolerance': 1e-4,
        }
        super().__init__(algo_name='tfidf', default_params=default_params, **kwargs)

    def _predict_impl(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """TF-IDF 特定的模拟预测。"""
        max_features: int = self._params.get('max_features', 10000)
        if isinstance(data, (list, tuple)) and len(data) > 0:
            vector_len: int = min(max_features, 10)
            return [0.1] * vector_len
        return super()._predict_impl(data)


class Word2VecTrainer(_AlgorithmBase):
    """Word2Vec 训练器桩实现。

    模拟 skip-gram/CBOW 训练过程，嵌入维度和窗口大小影响模拟复杂度。
    """

    def __init__(self, **kwargs: Any) -> None:
        """初始化 Word2Vec 训练器。"""
        default_params: Dict[str, Any] = {
            'vector_size': 100,
            'window': 5,
            'min_count': 5,
            'workers': 4,
            'epochs': 5,
            'max_iterations': 500,
            'tolerance': 1e-4,
        }
        super().__init__(algo_name='word2vec', default_params=default_params, **kwargs)

    def _compute(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Dict[str, Any]:
        """Word2Vec 特定的模拟计算。"""
        vector_size: int = self._params.get('vector_size', 100)
        window: int = self._params.get('window', 5)
        complexity: int = vector_size * window
        original_max_iter: int = self._params.get('max_iterations', 500)
        capped_iter: int = min(original_max_iter, max(10, complexity // 100))
        saved_max_iter: int = self._params.get('max_iterations', 500)
        self._params['max_iterations'] = capped_iter
        try:
            return super()._compute(data)
        finally:
            self._params['max_iterations'] = saved_max_iter

    def _predict_impl(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """Word2Vec 特定的模拟预测。"""
        vector_size: int = self._params.get('vector_size', 100)
        if isinstance(data, (list, tuple)) and len(data) > 0:
            return [0.0] * vector_size
        base_pred: Any = super()._predict_impl(data)
        if isinstance(base_pred, (int, float)):
            return [float(base_pred)] * vector_size
        return base_pred


class ExponentialSmoother(_AlgorithmBase):
    """指数平滑预测器桩实现。

    模拟时间序列平滑处理，alpha 参数控制平滑程度。
    """

    def __init__(self, **kwargs: Any) -> None:
        """初始化指数平滑预测器。"""
        default_params: Dict[str, Any] = {
            'alpha': 0.1,
            'max_iterations': 100,
            'tolerance': 1e-4,
        }
        super().__init__(algo_name='exponential_smoother', default_params=default_params, **kwargs)

    def _compute(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Dict[str, Any]:
        """指数平滑特定的模拟计算。"""
        alpha: float = self._params.get('alpha', 0.1)
        original_lr: float = self._params.get('learning_rate', 0.01)
        effective_lr: float = min(original_lr * (1.0 + alpha), 1.0)
        saved_lr: float = self._params.get('learning_rate', 0.01)
        self._params['learning_rate'] = effective_lr
        try:
            return super()._compute(data)
        finally:
            self._params['learning_rate'] = saved_lr

    def _predict_impl(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """指数平滑特定的模拟预测。"""
        alpha: float = self._params.get('alpha', 0.1)
        base_pred: Any = super()._predict_impl(data)
        if isinstance(base_pred, (int, float)):
            return float(base_pred) * (1.0 - alpha)
        return base_pred


class ARIMAForecaster(_AlgorithmBase):
    """ARIMA 时间序列预测器桩实现。

    模拟自回归积分滑动平均模型，p, d, q 参数影响复杂度。
    """

    def __init__(self, **kwargs: Any) -> None:
        """初始化 ARIMA 预测器。"""
        default_params: Dict[str, Any] = {
            'p': 1,
            'd': 0,
            'q': 1,
            'max_iterations': 200,
            'tolerance': 1e-4,
        }
        super().__init__(algo_name='arima', default_params=default_params, **kwargs)

    def _compute(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Dict[str, Any]:
        """ARIMA 特定的模拟计算。"""
        p: int = self._params.get('p', 1)
        d: int = self._params.get('d', 0)
        q: int = self._params.get('q', 1)
        complexity: int = p + d + q
        original_max_iter: int = self._params.get('max_iterations', 200)
        capped_iter: int = min(original_max_iter, max(10, complexity * 10))
        saved_max_iter: int = self._params.get('max_iterations', 200)
        self._params['max_iterations'] = capped_iter
        try:
            return super()._compute(data)
        finally:
            self._params['max_iterations'] = saved_max_iter

    def _predict_impl(self, data: Union[List[Any], Tuple[Any, ...], Any]) -> Any:
        """ARIMA 特定的模拟预测。"""
        p: int = self._params.get('p', 1)
        q: int = self._params.get('q', 1)
        base_pred: Any = super()._predict_impl(data)
        if isinstance(base_pred, (int, float)):
            return int(float(base_pred) % max(1, p + q + 1))
        return base_pred
