"""线程安全的 TTL-LRU 内存缓存模块。

提供带自动过期和 LRU 淘汰策略的键值对存储，支持统计跟踪和后台定时清理。
采用 OrderedDict 维护访问顺序，双索引结构支持 O(1) 的过期检测与 LRU 操作。
通过独立的统计锁和后台守护线程实现高效的并发性能与资源管理。
"""

import copy
import logging
import time
import weakref
from collections import OrderedDict
from typing import Any, Dict, List, Optional, Tuple, TypeVar
from threading import RLock, Event, Thread

logger = logging.getLogger(__name__)

StatsManager = TypeVar("StatsManager")

class _Stats:
    """统计指标管理器。

    独立锁保护，避免主缓存锁争用。
    """

    def __init__(self) -> None:
        """初始化统计指标管理器。"""
        self._lock: RLock = RLock()
        self._hits: int = 0
        self._misses: int = 0
        self._evictions: int = 0
        self._writes: int = 0

    def record_hit(self) -> None:
        """记录一次命中。"""
        with self._lock:
            self._hits += 1

    def record_miss(self) -> None:
        """记录一次缺失。"""
        with self._lock:
            self._misses += 1

    def record_eviction(self) -> None:
        """记录一次淘汰。"""
        with self._lock:
            self._evictions += 1

    def record_write(self) -> None:
        """记录一次写入。"""
        with self._lock:
            self._writes += 1

    @property
    def hit_rate(self) -> float:
        """计算命中率。

        Returns:
            命中率（0.0 到 1.0 之间）。
        """
        with self._lock:
            total: int = self._hits + self._misses
            return self._hits / total if total > 0 else 0.0

    def snapshot(self) -> Dict[str, Any]:
        """获取统计快照。

        Returns:
            包含各项指标的字典。
        """
        with self._lock:
            return {
                "hits": self._hits,
                "misses": self._misses,
                "evictions": self._evictions,
                "writes": self._writes,
                "hit_rate": self.hit_rate,
            }

class _BaseStore:
    """TTL-LRU 缓存基础实现。

    抽象存储接口，包含核心数据结构和锁机制。
    """

    def __init__(
        self,
        max_size: int = 10000,
        ttl: float = 3600.0,
        cleanup_interval: float = 1.0,
        name: str = "BaseStore"
    ) -> None:
        """初始化 TTL-LRU 存储实例。

        Args:
            max_size: 缓存最大容量（必须 > 0）。
            ttl: 条目生存时间（秒，必须 > 0）。
            cleanup_interval: 后台清理线程间隔（秒，必须 > 0）。
            name: 实例名称，用于日志标识。

        Raises:
            ValueError: 当 max_size 或 ttl 或 cleanup_interval 小于等于 0 时抛出。
        """
        if max_size <= 0:
            raise ValueError(f"max_size 必须 > 0，收到: {max_size}")
        if ttl <= 0:
            raise ValueError(f"ttl 必须 > 0，收到: {ttl}")
        if cleanup_interval <= 0:
            raise ValueError(f"cleanup_interval 必须 > 0，收到: {cleanup_interval}")

        self._name: str = name
        self._max_size: int = max_size
        self._ttl: float = ttl
        self._cleanup_interval: float = cleanup_interval

        self._cache: OrderedDict = OrderedDict()
        self._index: Dict = {}
        self._stats: StatsManager = _Stats()
        self._lock: RLock = RLock()
        self._shutdown_event: Event = Event()
        self._cleanup_thread: Optional[Thread] = None
        self._start_cleanup_loop()

    def _start_cleanup_loop(self) -> None:
        """启动后台清理守护线程。"""
        self._shutdown_event.clear()
        self._cleanup_thread = Thread(
            target=self._cleanup_loop,
            name=f"{self._name}-cleanup",
            daemon=True
        )
        self._cleanup_thread.start()
        logger.debug("%s: 后台清理线程已启动，间隔 %.1fs", self._name, self._cleanup_interval)

    def _cleanup_loop(self) -> None:
        """后台清理循环，定期执行过期条目清理。"""
        while not self._shutdown_event.is_set():
            self._shutdown_event.wait(self._cleanup_interval)
            if not self._shutdown_event.is_set():
                try:
                    self._do_cleanup()
                except Exception as e:
                    logger.warning("%s: 后台清理执行异常: %s", self._name, e)

    def _do_cleanup(self) -> None:
        """执行过期清理操作（必须持有锁）。"""
        now = time.time()
        expired = [k for k, v in self._index.items() if v <= now]
        for k in expired:
            self._purge_key(k)
        if expired:
            logger.debug("%s: 清理 %d 个过期条目", self._name, len(expired))

    def put(self, key: Any, value: Any) -> None:
        """写入或更新键值对，自动处理 LRU 淘汰。

        Args:
            key: 缓存键。
            value: 缓存值。
        """
        with self._lock:
            now = time.time()
            expire_time = now + self._ttl
            self._stats.record_write()

            if key in self._cache:
                self._cache.move_to_end(key)
            else:
                while len(self._cache) >= self._max_size:
                    self._evict_lru()

            self._cache[key] = value
            self._index[key] = expire_time

    def _evict_lru(self) -> None:
        """淘汰最久未使用的条目（必须持有锁）。"""
        if not self._cache:
            return
        evicted_key = self._cache.popitem(last=False)[0]
        del self._index[evicted_key]
        self._stats.record_eviction()
        logger.debug("%s: LRU 淘汰键 '%s'", self._name, evicted_key)

    def get(self, key: Any, default: Optional[Any] = None, deep_copy: bool = False) -> Optional[Any]:
        """获取键值对，自动处理过期和 LRU 刷新。

        Args:
            key: 目标键。
            default: 未命中时的默认值。
            deep_copy: 是否返回值的深拷贝。

        Returns:
            命中值或默认值。
        """
        with self._lock:
            if key not in self._cache:
                self._stats.record_miss()
                return default

            expire_time = self._index.get(key, 0.0)
            now = time.time()
            if now >= expire_time:
                self._purge_key(key)
                self._stats.record_miss()
                return default

            self._cache.move_to_end(key)
            self._stats.record_hit()
            value = self._cache[key]
            return deep_copy_value(value) if deep_copy else value

    def contains(self, key: Any) -> bool:
        """检查键是否存在且未过期。

        Args:
            key: 目标键。

        Returns:
            存在且未过期的布尔值。
        """
        with self._lock:
            if key not in self._cache:
                return False

            expire_time = self._index.get(key, 0.0)
            now = time.time()
            return now < expire_time

    def keys(self) -> List[Any]:
        """获取所有有效键列表。

        注意: O(N) 复杂度，高并发下可能影响性能。
        """
        with self._lock:
            now = time.time()
            return [k for k, v in self._index.items() if v > now]

    def _purge_key(self, key: Any) -> None:
        """从 store 和 index 中移除单个键（必须持有锁）。"""
        self._cache.pop(key, None)
        del self._index[key]

    def _do_cleanup(self) -> int:
        """执行过期清理操作（必须持有锁）。

        Returns:
            清理数量。
        """
        now = time.time()
        expired = [k for k, v in self._index.items() if v <= now]
        for k in expired:
            self._purge_key(k)
        return len(expired)

    def cleanup(self) -> int:
        """手动清理过期条目。

        Returns:
            清理数量。
        """
        with self._lock:
            return self._do_cleanup()

    def clear(self) -> None:
        """安全清空缓存。"""
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
            self._index.clear()
            logger.debug("%s: 清空缓存，清除 %d 个条目", self._name, count)

    @property
    def size(self) -> int:
        """当前缓存大小。"""
        with self._lock:
            return len(self._cache)

    @property
    def hit_rate(self) -> float:
        """计算命中率。"""
        return self._stats.hit_rate

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息。

        Returns:
            包含大小、命中率、淘汰次数等的字典。
        """
        stats = self._stats.snapshot()
        with self._lock:
            stats["size"] = len(self._cache)
        return stats

    def to_dict(self) -> Dict[Any, Any]:
        """导出有效键值对。

        注意: O(N) 复杂度，高并发下可能影响性能。
        """
        with self._lock:
            now = time.time()
            return {
                k: deep_copy_value(v)
                for k, v in self._cache.items()
                if self._index.get(k, 0.0) > now
            }

    def shutdown(self) -> None:
        """关闭存储实例，停止后台清理线程。"""
        self._shutdown_event.set()
        if self._cleanup_thread is not None:
            self._cleanup_thread.join(timeout=5.0)
            if self._cleanup_thread.is_alive():
                logger.warning("%s: 清理线程未正常退出，强制终止", self._name)
                self._cleanup_thread.terminate()
            self._cleanup_thread = None
            logger.debug("%s: 存储实例已关闭", self._name)

    def __enter__(self) -> "_BaseStore":
        """上下文管理器进入。"""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """上下文管理器退出。"""
        self.shutdown()

def deep_copy_value(value: Any) -> Any:
    """智能深拷贝函数。

    仅对可序列化对象进行深拷贝。
    """
    if isinstance(value, (dict, list, str, bytes, bytearray)):
        return copy.deepcopy(value)
    return value

def create_store(
    name: str = "TTLStore",
    max_size: int = 10000,
    ttl: float = 3600.0,
    cleanup_interval: float = 1.0,
) -> _BaseStore:
    """工厂函数创建存储实例。

    Args:
        name: 实例名称。
        max_size: 缓存最大容量。
        ttl: 条目生存时间（秒）。
        cleanup_interval: 后台清理线程间隔（秒）。

    Returns:
        配置好的 _BaseStore 实例。
    """
    return _BaseStore(
        name=name,
        max_size=max_size,
        ttl=ttl,
        cleanup_interval=cleanup_interval
    )

__all__ = ["create_store", "_BaseStore"]
