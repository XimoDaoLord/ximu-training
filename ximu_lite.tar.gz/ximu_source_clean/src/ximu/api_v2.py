# -*- coding: utf-8 -*-
"""汐沫AI v2 统一 API 接口层

基于 LinkedList 基础结构实现会话令牌管理、限流与兼容性保障。
路由路径与响应格式与 v1 完全兼容，内部逻辑强化稳定性。

依赖:
    - src/ximu/common/config_manager.py  (ConfigManager)
    - src/ximu/common/user_db.py         (UserDB, User)
    - main.py                            (XIMUApplication, health)
"""

from __future__ import annotations

import functools
import logging
import time
from datetime import datetime, timedelta
from typing import Any, Dict, Optional, Tuple

import bcrypt
import jwt
from flask import Flask, Request, g, jsonify, request

from main import XIMUApplication
from src.ximu.common.config_manager import ConfigManager
from src.ximu.common.user_db import UserDB, User

logger = logging.getLogger(__name__)


class DataNode:
    """LinkedList 节点，存储键值对。"""

    def __init__(self, key: str, value: Dict[str, Any]) -> None:
        self.key = key
        self.value = value
        self.next: Optional[DataNode] = None


class TokenSessionList:
    """使用 LinkedList 管理活跃令牌会话，O(n) 查找可接受（令牌量有限）。"""

    def __init__(self, max_size: int = 10000) -> None:
        self.head: Optional[DataNode] = None
        self._max_size = max_size

    def insert(self, key: str, value: Dict[str, Any]) -> None:
        """插入或更新令牌会话。"""
        new_node = DataNode(key, value)
        if self.head is None:
            self.head = new_node
            return
        current = self.head
        while current:
            if current.key == key:
                current.value = value
                return
            if current.next is None:
                current.next = new_node
                break
            current = current.next
        self._evict_if_overflow()

    def find(self, key: str) -> Optional[Dict[str, Any]]:
        """按 key 查找会话值。"""
        current = self.head
        while current:
            if current.key == key:
                return current.value
            current = current.next
        return None

    def delete(self, key: str) -> bool:
        """删除指定会话，成功返回 True。"""
        current = self.head
        previous: Optional[DataNode] = None
        while current and current.key != key:
            previous = current
            current = current.next
        if current is None:
            return False
        if previous is None:
            self.head = current.next
        else:
            previous.next = current.next
        return True

    def size(self) -> int:
        """返回链表大小。"""
        count = 0
        current = self.head
        while current:
            count += 1
            current = current.next
        return count

    def _evict_if_overflow(self) -> None:
        """超出 max_size 时从头部（最旧）驱逐节点。"""
        if self.size() > self._max_size and self.head:
            self.head = self.head.next
            logger.warning("TokenSessionList 溢出，已驱逐最旧会话")


class RateLimiter:
    """基于滑动窗口的简单限流器，每 user_id 独立计数。"""

    def __init__(self, window_seconds: int = 60, max_requests: int = 60) -> None:
        self._window = window_seconds
        self._max = max_requests
        self._hits: Dict[str, list] = {}

    def allow(self, user_id: str) -> bool:
        """检查是否允许请求。"""
        now = time.time()
        self._hits.setdefault(user_id, [])
        self._hits[user_id] = [t for t in self._hits[user_id] if now - t < self._window]
        if len(self._hits[user_id]) >= self._max:
            return False
        self._hits[user_id].append(now)
        return True


app = Flask(__name__)
config = ConfigManager.get_instance()
user_db = UserDB()

JWT_SECRET: str = config.get("security.jwt_secret_key", "ximu-dev-secret-change-me")
JWT_ALG: str = "HS256"
JWT_EXPIRY_HOURS: int = int(config.get("security.jwt_expiration_hours", 1))
JWT_EXPIRY: timedelta = timedelta(hours=JWT_EXPIRY_HOURS)

token_sessions = TokenSessionList(max_size=20000)
rate_limiter = RateLimiter(window_seconds=60, max_requests=120)

ximu_app = XIMUApplication()
try:
    ximu_app.build_cognition()
except Exception:
    logger.exception("XIMUApplication 启动失败，降级运行")


def _json_error(status_code: int, message: str, **extra: Any) -> Tuple[Any, int]:
    """构造 JSON 错误响应。"""
    payload = {"success": False, "message": message, **extra}
    return jsonify(payload), status_code


def token_required(f):
    """JWT 鉴权装饰器，兼容 v1 行为。"""

    @functools.wraps(f)
    def decorated(*args: Any, **kwargs: Any) -> Any:
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return _json_error(401, "缺少认证令牌")

        raw_token = auth_header.split(" ", 1)[1].strip()
        if not raw_token:
            return _json_error(401, "令牌格式错误")

        try:
            payload = jwt.decode(raw_token, JWT_SECRET, algorithms=[JWT_ALG])
        except jwt.ExpiredSignatureError:
            return _json_error(401, "令牌已过期")
        except jwt.InvalidTokenError:
            return _json_error(401, "无效的令牌")

        user_id = payload.get("user_id")
        if user_id is None:
            return _json_error(401, "令牌缺少 user_id")

        user = user_db.get_user_by_id(user_id)
        if not user or not user.get("is_active", True):
            return _json_error(401, "用户不存在或已被禁用")

        if not rate_limiter.allow(str(user_id)):
            return _json_error(429, "请求过于频繁，请稍后再试")

        token_sessions.insert(raw_token, {
            "user_id": user_id,
            "username": user.get("username"),
            "issued_at": payload.get("iat"),
        })

        g.current_user = user
        g.current_user_id = user_id
        g.token = raw_token
        return f(*args, **kwargs)

    return decorated


def _hash_password(plain: str) -> str:
    """对密码进行 bcrypt 哈希。"""
    return bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt(12)).decode("utf-8")


def _verify_password(plain: str, hashed: str) -> bool:
    """验证明文密码与哈希密码是否匹配。"""
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


def _issue_token(user: Dict[str, Any]) -> Tuple[str, int]:
    """签发 JWT 访问令牌。"""
    now = datetime.utcnow()
    payload = {
        "user_id": user["id"],
        "username": user.get("username"),
        "exp": now + JWT_EXPIRY,
        "iat": now,
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)
    expires_in = int(JWT_EXPIRY.total_seconds())
    return token, expires_in


@app.route("/api/login", methods=["POST"])
def login() -> Tuple[Any, int]:
    """用户登录接口（兼容 v1）。"""
    try:
        data = request.get_json(silent=True) or {}
        username = (data.get("username") or "").strip()
        password = data.get("password") or ""

        if not username or not password:
            return _json_error(400, "用户名和密码不能为空")

        user = user_db.get_user_by_username(username)
        if not user:
            logger.warning("登录失败：用户不存在 - %s", username)
            return _json_error(401, "用户名或密码错误")

        if not user.get("is_active", True):
            return _json_error(401, "用户账户已被禁用")

        if not _verify_password(password, user.get("password", "")):
            logger.warning("登录失败：密码错误 - %s", username)
            return _json_error(401, "用户名或密码错误")

        token, expires_in = _issue_token(user)
        return jsonify({
            "success": True,
            "token": token,
            "expires_in": expires_in,
            "user": {
                "id": user["id"],
                "username": user.get("username"),
            },
        }), 200

    except Exception as e:
        logger.error("登录异常: %s", e, exc_info=True)
        return _json_error(500, "服务器内部错误")


@app.route("/api/register", methods=["POST"])
def register() -> Tuple[Any, int]:
    """用户注册接口。"""
    try:
        data = request.get_json(silent=True) or {}
        username = (data.get("username") or "").strip()
        password = data.get("password") or ""
        email = (data.get("email") or "").strip()

        if not username or not password or not email:
            return _json_error(400, "用户名、密码和邮箱不能为空")

        if user_db.get_user_by_username(username):
            return _json_error(400, "用户名已存在")

        hashed = _hash_password(password)
        user_id = user_db.create_user(username, hashed, email)
        if not user_id:
            return _json_error(500, "用户创建失败")

        return jsonify({"success": True, "user_id": user_id}), 201

    except Exception as e:
        logger.error("注册异常: %s", e, exc_info=True)
        return _json_error(500, "服务器内部错误")


@app.route("/api/change_password", methods=["POST"])
@token_required
def change_password() -> Tuple[Any, int]:
    """修改密码接口。"""
    try:
        data = request.get_json(silent=True) or {}
        old_password = data.get("old_password") or ""
        new_password = data.get("new_password") or ""

        if not old_password or not new_password:
            return _json_error(400, "旧密码和新密码不能为空")

        user = g.current_user
        if not _verify_password(old_password, user.get("password", "")):
            return _json_error(401, "旧密码错误")

        hashed = _hash_password(new_password)
        user_db.update_password(user["id"], hashed)
        return jsonify({"success": True}), 200

    except Exception as e:
        logger.error("修改密码异常: %s", e, exc_info=True)
        return _json_error(500, "服务器内部错误")


@app.route("/api/user/profile", methods=["GET"])
@token_required
def get_profile() -> Tuple[Any, int]:
    """获取用户资料接口。"""
    try:
        user = g.current_user
        return jsonify({
            "success": True,
            "user": {
                "id": user["id"],
                "username": user.get("username"),
                "email": user.get("email"),
                "created_at": user.get("created_at"),
            },
        }), 200

    except Exception as e:
        logger.error("获取资料异常: %s", e, exc_info=True)
        return _json_error(500, "服务器内部错误")


@app.route("/api/health", methods=["GET"])
def health() -> Tuple[Any, int]:
    """健康检查接口。"""
    return jsonify({
        "success": True,
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
    }), 200


@app.route("/api/logout", methods=["POST"])
@token_required
def logout() -> Tuple[Any, int]:
    """登出接口：使令牌失效。"""
    try:
        token_sessions.delete(g.token)
        return jsonify({"success": True}), 200

    except Exception as e:
        logger.error("登出异常: %s", e, exc_info=True)
        return _json_error(500, "服务器内部错误")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
