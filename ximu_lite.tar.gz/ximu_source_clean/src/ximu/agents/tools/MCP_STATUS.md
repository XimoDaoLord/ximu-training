# 汐沫AI - MCP服务器状态管理工具

## 1. 使用说明

使用以下命令管理MCP服务器生命周期：

```bash
# 查看MCP状态
bash src/ximu/agents/tools/mcp_status.sh

# 启动所有MCP服务
bash src/ximu/agents/tools/mcp_manage.sh start

# 停止MCP服务器
bash src/ximu/agents/tools/mcp_manage.sh stop

# 实时查看日志
tail -f logs/mcp_server.log
```

> 注意：路径基于项目根目录，可通过环境变量 `XIMU_BASE_DIR` 覆盖基础路径。

## 2. 已配置的MCP服务器清单

| 名称 | 功能描述 | 配置详情 | 状态 |
|------|----------|----------|------|
| **open-websearch** | 搜索服务 | 支持 DuckDuckGo, Bing, Baidu 搜索引擎；最大返回结果数：10条 | 通过 `check_tools.sh` 验证 |
| **custom-mcp** | 自定义MCP服务器 | PID文件: logs/mcp_server.pid；日志路径: logs/mcp_server.log | 通过 `mcp_status.sh` 检查 |
| **filesystem** | 文件系统操作 | 根路径由 `XIMU_BASE_DIR` 环境变量决定 | 通过 `check_tools.sh` 验证 |
| **browser-automation** | 浏览器自动化 | 执行路径: skills/browser-automation/dist/index.js | 通过 `check_tools.sh` 验证 |

## 3. 技能包状态

- **browser-automation**: 检查文件 `skills/browser-automation/dist/index.js` 是否存在
- **custom-mcp-server**: 检查PID文件 `logs/mcp_server.pid` 及对应进程是否存活

## 4. 开机自启动机制

建议将以下命令添加至 `.bashrc` 或系统服务中：

```bash
# 启动MCP服务
bash $HOME/ximu_ai/src/ximu/agents/tools/mcp_manage.sh start
```

**行为说明**：每次启动终端时，系统将自动执行上述命令，确保MCP服务处于运行状态。