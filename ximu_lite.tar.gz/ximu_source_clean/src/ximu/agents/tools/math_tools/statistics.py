"""统计分析工具，支持描述统计、假设检验。"""

from __future__ import annotations

import logging
import math
import statistics
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class StatisticsTool(BaseTool):
    """统计分析工具，支持描述统计、假设检验。"""

    name: str = "statistics"
    description: str = "统计分析工具，支持描述统计、假设检验"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculation", "science"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化统计工具。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Any] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """设置工具参数定义。"""
        self.add_parameter("data", list, required=True, description="数据列表")
        self.add_parameter(
            "action",
            str,
            required=False,
            default="describe",
            choices=["describe", "mean", "median", "mode", "variance", "std", "percentile", "correlation", "ttest"],
            description="操作",
        )
        self.add_parameter("data2", list, required=False, default=[], description="第二组数据")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行统计操作。

        Args:
            **kwargs: 包含 data, action, data2, percentile 等参数。

        Returns:
            包含统计结果的字典。

        Raises:
            ToolError: 数据为空或参数不合法时抛出。
        """
        data: List[Union[int, float]] = kwargs.get("data", [])
        action: str = kwargs.get("action", "describe")

        if not data:
            raise ToolError("数据为空", code=1002)

        handlers: Dict[str, Any] = {
            "mean": lambda: {"mean": statistics.mean(data)},
            "median": lambda: {"median": statistics.median(data)},
            "mode": lambda: self._handle_mode(data),
            "variance": lambda: self._handle_variance(data),
            "std": lambda: self._handle_std(data),
            "percentile": lambda: self._handle_percentile(data, kwargs),
            "correlation": lambda: self._handle_correlation(data, kwargs),
            "ttest": lambda: self._handle_ttest(data, kwargs),
        }

        handler = handlers.get(action)
        if handler is not None:
            return handler()
        return self._handle_describe(data)

    def _handle_mode(self, data: List[Union[int, float]]) -> Dict[str, Any]:
        """处理众数计算。

        Args:
            data: 数据列表。

        Returns:
            众数及备注信息字典。
        """
        try:
            return {"mode": statistics.mode(data)}
        except statistics.StatisticsError:
            return {"mode": None, "note": "无唯一众数"}

    def _handle_variance(self, data: List[Union[int, float]]) -> Dict[str, Any]:
        """处理方差计算。

        Args:
            data: 数据列表。

        Returns:
            样本方差和总体方差字典。
        """
        sample_var: float = statistics.variance(data) if len(data) > 1 else 0
        pop_var: float = statistics.pvariance(data)
        return {"variance": sample_var, "population_variance": pop_var}

    def _handle_std(self, data: List[Union[int, float]]) -> Dict[str, Any]:
        """处理标准差计算。

        Args:
            data: 数据列表。

        Returns:
            样本标准差和总体标准差字典。
        """
        sample_std: float = statistics.stdev(data) if len(data) > 1 else 0
        pop_std: float = statistics.pstdev(data)
        return {"std": sample_std, "population_std": pop_std}

    def _handle_percentile(self, data: List[Union[int, float]], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理百分位数计算。

        Args:
            data: 数据列表。
            kwargs: 包含 percentile 参数。

        Returns:
            百分位数值及对应百分比特性字典。
        """
        sorted_data = sorted(data)
        p: int = kwargs.get("percentile", 50)
        k = (len(sorted_data) - 1) * p / 100
        f = int(k)
        c = f + 1 if f + 1 < len(sorted_data) else f
        percentile_value = sorted_data[f] + (k - f) * (sorted_data[c] - sorted_data[f])
        return {"percentile": percentile_value, "p": p}

    def _handle_correlation(self, data: List[Union[int, float]], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理相关系数计算。

        Args:
            data: 第一组数据。
            kwargs: 包含 data2 参数。

        Returns:
            相关系数和协方差字典。

        Raises:
            ToolError: 当 data2 为空或长度不匹配时抛出。
        """
        data2: List[Union[int, float]] = kwargs.get("data2", [])
        if not data2 or len(data2) != len(data):
            raise ToolError("需要等长data2", code=1002)

        n = len(data)
        mean1, mean2 = statistics.mean(data), statistics.mean(data2)
        cov = sum((data[i] - mean1) * (data2[i] - mean2) for i in range(n)) / n
        std1, std2 = statistics.pstdev(data), statistics.pstdev(data2)
        corr = cov / (std1 * std2) if std1 and std2 else 0
        return {"correlation": round(corr, 4), "covariance": round(cov, 4)}

    def _handle_ttest(self, data: List[Union[int, float]], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理T检验计算。

        Args:
            data: 第一组数据。
            kwargs: 包含 data2 参数。

        Returns:
            T统计量、自由度和两组均值字典。

        Raises:
            ToolError: 当 data2 为空时抛出。
        """
        data2: List[Union[int, float]] = kwargs.get("data2", [])
        if not data2:
            raise ToolError("需要data2", code=1002)

        mean1, mean2 = statistics.mean(data), statistics.mean(data2)
        var1, var2 = statistics.variance(data), statistics.variance(data2)
        n1, n2 = len(data), len(data2)
        se = math.sqrt(var1 / n1 + var2 / n2)
        t = (mean1 - mean2) / se if se else 0
        df = n1 + n2 - 2
        return {"t_statistic": round(t, 4), "degrees_of_freedom": df, "mean1": mean1, "mean2": mean2}

    def _handle_describe(self, data: List[Union[int, float]]) -> Dict[str, Any]:
        """生成描述性统计结果。

        Args:
            data: 数据列表。

        Returns:
            包含各项描述统计量的字典。
        """
        has_mode: bool = len(set(data)) < len(data)
        return {
            "count": len(data),
            "mean": round(statistics.mean(data), 4),
            "median": statistics.median(data),
            "mode": statistics.mode(data) if has_mode else None,
            "variance": round(statistics.variance(data), 4) if len(data) > 1 else 0,
            "std": round(statistics.stdev(data), 4) if len(data) > 1 else 0,
            "min": min(data),
            "max": max(data),
            "range": max(data) - min(data),
            "sum": sum(data),
            "skewness": round(self._skew(data), 4),
        }

    def _skew(self, data: List[Union[int, float]]) -> float:
        """计算偏度系数。

        Args:
            data: 数据列表。

        Returns:
            偏度系数值。
        """
        n = len(data)
        if n < 3:
            return 0.0
        mean = statistics.mean(data)
        std = statistics.pstdev(data)
        if std == 0:
            return 0.0
        m3 = sum((x - mean) ** 3 for x in data) / n
        return m3 / (std ** 3)

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具运行入口。

        Args:
            params: 参数字典。

        Returns:
            包含成功状态、数据、错误信息、执行时间等的结果字典。
        """
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(v), 1002, start)

            result = self.execute(**v)
            el = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += el
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": el})
            if len(self._history) > 100:
                self._history.pop(0)

            return {
                "success": True,
                "data": result,
                "error": None,
                "execution_time": el,
                "tool": self.name,
                "version": self.version,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception as exc:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=exc)
            return self._err("工具内部错误", 1006, start)

    def _err(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构建错误返回结构。

        Args:
            msg: 错误消息。
            code: 错误代码。
            start: 开始时间戳。
            details: 额外错误详情。

        Returns:
            标准错误响应字典。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def get_stats(self) -> Dict[str, Any]:
        """获取工具统计信息。

        Returns:
            包含调用次数、成功率、平均耗时等统计信息的字典。
        """
        avg = self._stats["time"] / self._stats["ok"] if self._stats["ok"] > 0 else 0
        return {
            **self._stats,
            "avg": round(avg, 4),
            "rate": round(self._stats["ok"] / max(1, self._stats["calls"]), 4),
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近执行历史。

        Args:
            limit: 返回的最大记录数。

        Returns:
            历史记录列表。
        """
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。

        Returns:
            包含工具元数据、参数定义和统计信息的描述符字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }

    def validate_input(self, params: Dict[str, Any]) -> Tuple[bool, str]:
        """验证输入参数。

        Args:
            params: 待验证的参数字典。

        Returns:
            元组 (是否有效, 错误消息或空字符串)。
        """
        ok, result = self.validate_parameters(params)
        return ok, "" if ok else str(result)
