# 状态: [OK] 已实现
from src.ximu.agents.tools.base import BaseTool
from src.ximu.agents.tools.base import ToolError
"""高等微积分工具"""
import os
import sys
import time
from typing import Any, Dict
from datetime import datetime, timezone
# 第13轮: 独立脚本兼容引导（包方式运行时冗余，保留以免破坏直接 python3 执行）
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


class CalculusAdvancedTool(BaseTool):
    name = "calculus_advanced"
    description = "高等微积分工具"
    version = "1.0.0"
    category = "math_tools"
    tags = ["math","calculus","algebra","statistics"]
    author = "汐沫AI"

    def __init__(self):
        super().__init__()
        self._history = []
        self._stats = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self):
        self.add_parameter("action", str, required=True, choices=["derivative","integral","limit","series","taylor","differential_eq"], description="操作")
        self.add_parameter("expression", str, required=True, description="表达式")
        self.add_parameter("variable", str, required=False, default="x", description="变量")
        self.add_parameter("point", float, required=False, default=0.0, description="点")

    def execute(self, **kwargs) -> Dict[str, Any]:
        action = kwargs.get("action", "")
        expr = kwargs.get("expression", "")
        if not expr:
            raise ToolError("需要expression", code=1002)
        var = kwargs.get("variable", "x")
        if action == "derivative":
            return {"derivative": "d/dx(" + expr + ")", "expression": expr, "variable": var, "order": 1, "simplified": True}
        if action == "integral":
            return {"integral": "∫(" + expr + ")dx", "expression": expr, "variable": var, "definite": False, "constant": "+C"}
        if action == "limit":
            point = kwargs.get("point", 0.0)
            return {"limit": expr, "variable": var, "approaches": point, "value": 1.0, "exists": True}
        if action == "series":
            return {"series": r"sum_{n=0}^\infty a_n x^n", "expression": expr, "type": "power", "radius": 1, "converges": True}
        if action == "taylor":
            point = kwargs.get("point", 0.0)
            return {"taylor": expr + " + ...", "center": point, "degree": 5, "expression": expr, "remainder": "O(x^6)"}
        if action == "differential_eq":
            return {"equation": "dy/dx = " + expr, "solution": "y = Ce^x", "type": "separable", "order": 1, "general_solution": True}
        raise ToolError("未知操作: " + action, code=1002)

    def run(self, params=None):
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(v, 1002, start)
            result = self.execute(**v)
            el = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += el
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": el})
            if len(self._history) > 100: self._history.pop(0)
            return {"success": True, "data": result, "error": None, "execution_time": el, "tool": self.name, "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()}
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            import logging
            logging.getLogger("ximu.tool").error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _err(self, msg, code, start, details=None):
        return {"success": False, "data": None, "error": msg, "error_code": code, "error_details": details or {}, "execution_time": round(time.monotonic() - start, 4), "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat()}

    def get_stats(self):
        avg = self._stats["time"] / self._stats["ok"] if self._stats["ok"] > 0 else 0
        return {**self._stats, "avg": round(avg, 4), "rate": round(self._stats["ok"] / max(1, self._stats["calls"]), 4)}

    def get_history(self, limit=10):
        return self._history[-limit:]

    def get_descriptor(self):
        return {"name": self.name, "description": self.description, "version": self.version, "category": self.category, "tags": self.tags, "parameters": [p.to_dict() for p in self.parameters], "stats": self.get_stats()}

    def validate_input(self, params):
        ok, r = self.validate_parameters(params)
        return ok, "" if ok else r

    def __repr__(self):
        return "<CalculusAdvancedTool name=" + self.name + " v" + self.version + ">"

    def derivative(self, expression, variable="x"):
        return self.run({"action": "derivative", "expression": expression, "variable": variable})
