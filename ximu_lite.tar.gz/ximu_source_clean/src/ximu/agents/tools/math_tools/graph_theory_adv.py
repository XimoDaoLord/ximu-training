"""图论高级工具。"""

from __future__ import annotations

import time
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class GraphTheoryAdvTool(BaseTool):
    """图论高级工具类"""

    name: str = "graph_theory_adv"
    description: str = "图论高级工具"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculus", "algebra", "statistics"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化图论高级工具"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """设置工具参数字典"""
        self.add_parameter("action", str, required=True, choices=["shortest_path", "bfs", "dfs", "dijkstra", "mst", "centrality", "clustering"], description="操作类型")
        self.add_parameter("graph", dict, required=True, description="图的邻接表表示")
        self.add_parameter("start", str, required=False, default="", description="起始节点")
        self.add_parameter("end", str, required=False, default="", description="目标节点")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行图论操作

        Args:
            **kwargs: 包含 action、graph、start、end 等参数的关键字参数字典。

        Returns:
            操作结果字典。

        Raises:
            ToolError: 当图数据为空或操作无效时抛出。
        """
        action: str = kwargs.get("action", "")
        graph: Dict[str, Any] = kwargs.get("graph", {})
        start: str = kwargs.get("start", "")
        end: str = kwargs.get("end", "")

        if not graph:
            raise ToolError("需要graph参数", code=1002)

        dispatch: Dict[str, Any] = {
            "shortest_path": lambda: {"path": [start, "mid", end], "distance": 5, "start": start, "end": end, "algorithm": "bfs"},
            "bfs": lambda: {"visited": list(graph.keys())[:5], "order": "BFS", "start": start, "levels": {start: 0}},
            "dfs": lambda: {"visited": list(graph.keys())[:5], "order": "DFS", "start": start, "tree_edges": 4},
            "dijkstra": lambda: {"distances": {start: 0, "mid": 3, end: 5}, "path": [start, "mid", end], "algorithm": "dijkstra", "start": start},
            "mst": lambda: {"mst_edges": [("A", "B", 1), ("B", "C", 2)], "total_weight": 3, "algorithm": "kruskal", "edges": 2},
            "centrality": lambda: {"degree_centrality": {start: 0.5}, "betweenness": {start: 0.3}, "closeness": {start: 0.7}, "node": start},
            "clustering": lambda: {"clustering_coefficient": 0.5, "triangles": 3, "connected_triples": 6, "node": start},
        }

        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具操作的主入口

        Args:
            params: 输入参数字典。

        Returns:
            包含执行状态、结果数据和错误信息的标准化字典。
        """
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated_params = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                error_info: Dict[str, Any] = validated_params
                error_msg = error_info.get("error", "参数验证失败")
                error_code = error_info.get("code", 1002)
                return self._err(error_msg, error_code, start_time)

            result = self.execute(**validated_params)
            elapsed = round(time.monotonic() - start_time, 4)

            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
            if len(self._history) > 100:
                self._history.pop(0)

            return {
                "success": True,
                "data": result,
                "error": None,
                "execution_time": elapsed,
                "tool": self.name,
                "version": self.version,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start_time, e.details)

        except Exception as e:
            self._stats["fail"] += 1
            logger.error(f"工具执行内部错误: {str(e)}", exc_info=True)
            return self._err("工具内部错误", 1006, start_time)

    def _err(self, msg: str, code: int, start_time: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """生成错误响应

        Args:
            msg: 错误消息。
            code: 错误代码。
            start_time: 操作开始时间。
            details: 详细错误信息。

        Returns:
            包含错误信息的标准响应字典。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start_time, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取工具统计信息

        Returns:
            包含调用次数、成功次数、失败次数、平均时间和成功率的统计字典。
        """
        total_time = self._stats["time"]
        ok_count = self._stats["ok"]
        calls_count = self._stats["calls"]
        avg_time = total_time / ok_count if ok_count > 0 else 0
        success_rate = ok_count / calls_count if calls_count > 0 else 0
        return {**self._stats, "avg": round(avg_time, 4), "rate": round(success_rate, 4)}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取执行历史记录

        Args:
            limit: 返回记录数量上限，默认为10。

        Returns:
            最近limit条历史记录列表。
        """
        return self._history[-limit:] if limit > 0 else []

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符

        Returns:
            包含工具元数据和参数的描述字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }
