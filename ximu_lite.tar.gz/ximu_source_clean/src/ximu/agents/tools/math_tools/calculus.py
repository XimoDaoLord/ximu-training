"""微积分工具，支持导数、积分、极限、级数和求根计算。"""

import logging
import math
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

from src.ximu.agents.tools.base import BaseTool, ToolError
from src.ximu.security.safe_expression import safe_eval_expression

logger = logging.getLogger("ximu.tool")

# 常量定义
_DEFAULT_H: float = 0.0001
_MIN_STEP_SIZE: float = 1e-10
_DEFAULT_INTEGRAL_SUBDIVISIONS: int = 1000
_DEFAULT_SERIES_TERMS: int = 10
_ROOT_SEARCH_RANGE: Tuple[float, float] = (-100.0, 100.0)
_ROOT_TOLERANCE: float = 1e-9
_MAX_ITERATIONS: int = 100
_APPROX_EPSILONS: List[float] = [1e-1, 1e-2, 1e-3, 1e-4, 1e-5]
_ROUND_PRECISION: int = 6


class CalculusTool(BaseTool):
    """提供数值微积分操作的工具类。"""

    name: str = "calculus"
    description: str = "Calculus tool supporting derivative, integral, limit, series, and root"
    version: str = "0.5.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculation", "science"]
    author: str = "汐沫AI"
    _MAX_HISTORY: int = 100

    def __init__(self) -> None:
        """初始化工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Any] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()
        self._logger: logging.Logger = logger

    def _setup_parameters(self) -> None:
        """定义工具参数。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=["derivative", "integral", "limit", "series", "root"],
            description="The calculus operation to perform",
        )
        self.add_parameter(
            "expression",
            str,
            required=False,
            default="",
            description="Mathematical expression as a string",
        )
        self.add_parameter(
            "x",
            float,
            required=False,
            default=0.0,
            description="Value of x for evaluation",
        )
        self.add_parameter(
            "a",
            float,
            required=False,
            default=0.0,
            description="Lower bound for integral or initial guess for root",
        )
        self.add_parameter(
            "b",
            float,
            required=False,
            default=1.0,
            description="Upper bound for integral or initial guess for root",
        )
        self.add_parameter(
            "h",
            float,
            required=False,
            default=_DEFAULT_H,
            description="Step size for numerical differentiation",
        )

    def _build_safe_namespace(self) -> Dict[str, Any]:
        """构建安全的表达式求值命名空间。

        Returns:
            包含 math 模块所有公开函数的字典。
        """
        return {key: getattr(math, key) for key in dir(math) if not key.startswith("_")}

    @staticmethod
    def _evaluate_expression(expression: str, x_val: float, safe_dict: Dict[str, Any]) -> float:
        """安全地评估数学表达式。

        Args:
            expression: 数学表达式字符串。
            x_val: 变量 x 的当前值。
            safe_dict: 包含安全函数的命名空间。

        Returns:
            表达式在 x_val 处的值。

        Raises:
            ToolError: 当表达式无法解析或求值时。
        """
        try:
            return safe_eval_expression(expression, {**safe_dict, "x": x_val})
        except Exception as exc:
            logger.debug("表达式求值失败: %s, 错误: %s", expression, exc)
            raise ToolError(f"Failed to evaluate expression: {exc}", code=1003) from exc

    def _create_function(
        self, expression: str, safe_dict: Dict[str, Any]
    ) -> Callable[[float], float]:
        """创建接受 x 值并返回表达式求值结果的函数。

        Args:
            expression: 数学表达式字符串。
            safe_dict: 安全命名空间。

        Returns:
            一个接受浮点数并返回浮点数的函数。
        """
        def f(x: float) -> float:
            return self._evaluate_expression(expression, x, safe_dict)
        return f

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行指定的微积分操作。

        Args:
            **kwargs: 包含 action, expression, x, a, b, h 等参数的关键字参数。

        Returns:
            包含计算结果的字典。

        Raises:
            ToolError: 当参数无效或操作未知时。
        """
        start_time = time.time()
        action: str = kwargs.get("action", "")
        expression: str = str(kwargs.get("expression", ""))
        x_val: float = float(kwargs.get("x", 0.0))
        h: float = float(kwargs.get("h", _DEFAULT_H))

        self._stats["calls"] += 1
        logger.debug("执行微积分操作: action=%s, expression=%s", action, expression)

        if h <= _MIN_STEP_SIZE:
            raise ToolError("Step size h must be positive and greater than 1e-10", code=1004)

        safe_dict = self._build_safe_namespace()
        f: Callable[[float], float] = self._create_function(expression, safe_dict)

        result: Dict[str, Any]
        if action == "derivative":
            result = self._compute_derivative(expression, x_val, h, f)
        elif action == "integral":
            a: float = float(kwargs.get("a", 0.0))
            b: float = float(kwargs.get("b", 1.0))
            if a == b:
                raise ToolError("Lower and upper bounds must differ", code=1005)
            result = self._compute_integral(expression, a, b, f)
        elif action == "limit":
            result = self._compute_limit(expression, x_val, f)
        elif action == "series":
            result = self._compute_series(expression, f)
        elif action == "root":
            result = self._find_root(expression, f)
        else:
            raise ToolError(f"Unknown action: {action}", code=1002)

        elapsed = time.time() - start_time
        self._stats["ok"] += 1
        self._stats["time"] += elapsed
        logger.debug("操作成功完成，耗时: %.4fs", elapsed)
        return result

    def _compute_derivative(
        self, expression: str, x_val: float, h: float, f: Callable[[float], float]
    ) -> Dict[str, Any]:
        """计算一阶和二阶导数（中心差分法）。

        Args:
            expression: 数学表达式字符串。
            x_val: 求导点的 x 值。
            h: 差分步长。
            f: 函数求值 callable。

        Returns:
            包含导数值、二阶导数值、x 值和表达式信息的字典。

        Raises:
            ToolError: 当表达式为空时。
        """
        if not expression:
            raise ToolError("expression is required for derivative", code=1002)

        f_plus = f(x_val + h)
        f_minus = f(x_val - h)
        f_center = f(x_val)
        derivative = (f_plus - f_minus) / (2 * h)
        second_derivative = (f_plus - 2 * f_center + f_minus) / (h * h)
        logger.debug("导数计算: f'(%.4f)=%.6f, f''(%.4f)=%.6f", x_val, derivative, x_val, second_derivative)

        return {
            "derivative": round(derivative, _ROUND_PRECISION),
            "second_derivative": round(second_derivative, _ROUND_PRECISION),
            "x": x_val,
            "expression": expression,
        }

    def _compute_integral(
        self, expression: str, a: float, b: float, f: Callable[[float], float]
    ) -> Dict[str, Any]:
        """计算定积分（黎曼和法）。

        Args:
            expression: 数学表达式字符串。
            a: 积分下限。
            b: 积分上限。
            f: 函数求值 callable。

        Returns:
            包含积分值、上下限、表达式和方法信息的字典。

        Raises:
            ToolError: 当表达式为空时。
        """
        if not expression:
            raise ToolError("expression is required for integral", code=1002)

        n: int = _DEFAULT_INTEGRAL_SUBDIVISIONS
        dx = (b - a) / n
        integral = sum(f(a + i * dx) * dx for i in range(n))
        logger.debug("积分计算: ∫[%s,%s] = %.6f", a, b, integral)

        return {
            "integral": round(integral, _ROUND_PRECISION),
            "a": a,
            "b": b,
            "expression": expression,
            "method": "riemann",
        }

    def _compute_limit(
        self, expression: str, x_val: float, f: Callable[[float], float]
    ) -> Dict[str, Any]:
        """计算极限（从右侧趋近）。

        Args:
            expression: 数学表达式字符串。
            x_val: 求极限点的 x 值。
            f: 函数求值 callable。

        Returns:
            包含极限近似值、x 值、表达式和近似序列的字典。

        Raises:
            ToolError: 当表达式为空时。
        """
        if not expression:
            raise ToolError("expression is required for limit", code=1002)

        values: List[float] = [f(x_val + e) for e in _APPROX_EPSILONS]
        logger.debug("极限近似值: %s", values)

        return {
            "limit": values[-1] if values else 0.0,
            "x": x_val,
            "expression": expression,
            "approximations": values,
        }

    def _compute_series(
        self, expression: str, f: Callable[[float], float]
    ) -> Dict[str, Any]:
        """计算级数前10项。

        Args:
            expression: 数学表达式字符串。
            f: 函数求值 callable。

        Returns:
            包含各项值、总和和表达式的字典。

        Raises:
            ToolError: 当表达式为空时。
        """
        if not expression:
            raise ToolError("expression is required for series", code=1002)

        terms: List[float] = [f(i) for i in range(1, _DEFAULT_SERIES_TERMS + 1)]
        series_sum = sum(terms)
        logger.debug("级数计算: 前%d项之和 = %.6f", _DEFAULT_SERIES_TERMS, series_sum)

        return {
            "terms": terms,
            "sum": series_sum,
            "expression": expression,
        }

    def _find_root(
        self, expression: str, f: Callable[[float], float]
    ) -> Dict[str, Any]:
        """使用二分法在[-100, 100]区间内寻找根。

        Args:
            expression: 数学表达式字符串。
            f: 函数求值 callable。

        Returns:
            包含根的值或错误信息的字典。

        Raises:
            ToolError: 当表达式为空时。
        """
        if not expression:
            raise ToolError("expression is required for root", code=1002)

        lo, hi = _ROOT_SEARCH_RANGE
        flo, fhi = f(lo), f(hi)

        if flo * fhi > 0:
            logger.warning("根不在搜索区间 %s 内", _ROOT_SEARCH_RANGE)
            return {"root": None, "expression": expression, "error": "根不在区间内"}

        for _ in range(_MAX_ITERATIONS):
            mid = (lo + hi) / 2
            fmid = f(mid)
            if abs(fmid) < _ROOT_TOLERANCE or (hi - lo) < _ROOT_TOLERANCE:
                logger.debug("找到根: %.6f", mid)
                return {"root": mid, "expression": expression}
            if flo * fmid < 0:
                hi = mid
                fhi = fmid
            else:
                lo = mid
                flo = fmid

        root = (lo + hi) / 2
        logger.debug("达到最大迭代次数，根近似值: %.6f", root)
        return {"root": root, "expression": expression}
