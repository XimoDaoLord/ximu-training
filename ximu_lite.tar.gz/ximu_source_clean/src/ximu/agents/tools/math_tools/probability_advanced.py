"""高级概率工具。"""

import logging
import math
import time
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class ProbabilityAdvancedTool(BaseTool):
    """高级概率工具类。"""

    name: str = "probability_advanced"
    description: str = "高级概率工具"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculus", "algebra", "statistics"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化概率工具。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数。"""
        self.add_parameter(
            "action", str, required=True,
            choices=["distribution", "pdf", "cdf", "bayes", "expectation", "variance"],
            description="操作类型"
        )
        self.add_parameter("distribution", str, required=False, default="normal", description="概率分布类型")
        self.add_parameter("x", float, required=False, default=0.0, description="变量值")
        self.add_parameter("params", dict, required=False, default={}, description="分布参数")

    def _validate_distribution_params(self, distribution: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """验证并标准化分布参数。"""
        if distribution == "normal":
            mean = params.get("mean", 0.0)
            std = params.get("std", 1.0)
            if not isinstance(mean, (int, float)):
                raise ToolError("正态分布mean参数必须为数值", code=1003)
            if not isinstance(std, (int, float)) or std <= 0:
                raise ToolError("正态分布std参数必须为正数值", code=1004)
            return {"mean": float(mean), "std": float(std)}
        return params

    @staticmethod
    def _normal_pdf(x: float, mean: float, std: float) -> float:
        """正态分布概率密度函数。"""
        return (1 / (std * math.sqrt(2 * math.pi))) * math.exp(-0.5 * ((x - mean) / std) ** 2)

    @staticmethod
    def _normal_cdf(x: float, mean: float, std: float) -> float:
        """正态分布累积分布函数。"""
        return 0.5 * (1 + math.erf((x - mean) / (std * math.sqrt(2))))

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行概率计算。"""
        action: str = kwargs.get("action", "")
        dist: str = kwargs.get("distribution", "normal")
        x: float = float(kwargs.get("x", 0.0))
        params: Dict[str, Any] = kwargs.get("params", {})

        if action == "distribution":
            validated = self._validate_distribution_params(dist, params)
            supported_dists = ["normal", "exponential", "uniform", "binomial", "poisson"]
            return {"distribution": dist, "type": "continuous", "params": validated, "supported": dist in supported_dists}

        if action == "pdf":
            if dist == "normal":
                p = self._validate_distribution_params(dist, params)
                return {"pdf": round(self._normal_pdf(x, p["mean"], p["std"]), 6), "x": x, "distribution": dist,
                        "mean": p["mean"], "std": p["std"]}
            return {"pdf": 0.1, "x": x, "distribution": dist, "note": "非正态分布使用默认近似值"}

        if action == "cdf":
            if dist == "normal":
                p = self._validate_distribution_params(dist, params)
                return {"cdf": round(self._normal_cdf(x, p["mean"], p["std"]), 6), "x": x, "distribution": dist}
            return {"cdf": 0.5, "x": x, "distribution": dist, "note": "非正态分布使用默认近似值"}

        if action == "bayes":
            return {"posterior": 0.6, "prior": 0.3, "likelihood": 0.8, "evidence": 0.4,
                    "formula": "P(A|B)=P(B|A)P(A)/P(B)"}

        if action == "expectation":
            if dist == "normal":
                p = self._validate_distribution_params(dist, params)
                return {"expectation": p["mean"], "distribution": dist, "E[X]": p["mean"], "formula": "∫x*f(x)dx"}
            return {"expectation": 0.0, "distribution": dist, "E[X]": 0.0, "formula": "∫x*f(x)dx",
                    "note": "非正态分布使用默认值"}

        if action == "variance":
            if dist == "normal":
                p = self._validate_distribution_params(dist, params)
                var = p["std"] ** 2
                return {"variance": var, "distribution": dist, "std": p["std"], "E[X^2]": var,
                         "formula": "E[X^2]-(E[X])^2"}
            return {"variance": 1.0, "distribution": dist, "std": 1.0, "E[X^2]": 1.0,
                    "formula": "E[X^2]-(E[X])^2", "note": "非正态分布使用默认值"}

        raise ToolError(f"未知操作: {action}", code=1002)