from __future__ import annotations

import math
import logging
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class NumberTheoryTool(BaseTool):
    """数论工具类，提供多种数论计算功能。"""
    
    name: str = "number_theory"
    description: str = "数论工具，支持素数、因数、模运算"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculation", "science"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化数论工具"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数。"""
        self.add_parameter("action", str, required=True, choices=["is_prime", "prime_factors", "factors", "gcd", "lcm", "modular_inverse", "euler_phi", "fibonacci"], description="操作类型")
        self.add_parameter("n", int, required=False, default=0, description="数值")
        self.add_parameter("m", int, required=False, default=1, description="第二个数值")
        self.add_parameter("k", int, required=False, default=0, description="索引或次数")

    @staticmethod
    def _is_prime(n: int) -> bool:
        """判断素数。"""
        if n < 2:
            return False
        if n % 2 == 0:
            return n == 2
        for i in range(3, int(math.isqrt(n)) + 1, 2):
            if n % i == 0:
                return False
        return True

    @staticmethod
    def _prime_factors(n: int) -> List[int]:
        """质因数分解。"""
        factors = []
        d = 2
        while d * d <= n:
            while n % d == 0:
                factors.append(d)
                n //= d
            d += 1
        if n > 1:
            factors.append(n)
        return factors

    @staticmethod
    def _factors(n: int) -> List[int]:
        """枚举所有因数。"""
        if n <= 0:
            return []
        result = []
        for i in range(1, int(math.isqrt(n)) + 1):
            if n % i == 0:
                result.append(i)
                if i != n // i:
                    result.append(n // i)
        return sorted(result)

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行数论计算。"""
        action = kwargs.get("action", "")
        n = int(kwargs.get("n", 0))
        m = int(kwargs.get("m", 1))
        k = int(kwargs.get("k", 0))

        if action == "is_prime":
            return {"n": n, "is_prime": NumberTheoryTool._is_prime(n)}
        if action == "prime_factors":
            return {"n": n, "factors": NumberTheoryTool._prime_factors(n)}
        if action == "factors":
            return {"n": n, "factors": NumberTheoryTool._factors(n)}
        if action == "gcd":
            return {"gcd": math.gcd(n, m), "n": n, "m": m}
        if action == "lcm":
            return {"lcm": n * m // math.gcd(n, m), "n": n, "m": m}
        if action == "modular_inverse":
            return {"inverse": pow(n, -1, m), "n": n, "m": m}
        if action == "euler_phi":
            return {"phi": NumberTheoryTool._euler_phi(n), "n": n}
        if action == "fibonacci":
            return {"index": k, "value": NumberTheoryTool._fibonacci(k)}

        raise ToolError(f"未知操作: {action}", code=1002)

    @staticmethod
    def _euler_phi(n: int) -> int:
        """欧拉函数。"""
        if n <= 1:
            return 1
        result = n
        p = 2
        while p * p <= n:
            if n % p == 0:
                while n % p == 0:
                    n //= p
                result -= result // p
            p += 1
        if n > 1:
            result -= result // n
        return result

    @staticmethod
    def _fibonacci(n: int) -> int:
        """斐波那契数。"""
        if n <= 0:
            return 0
        a, b = 0, 1
        for _ in range(n):
            a, b = b, a + b
        return a