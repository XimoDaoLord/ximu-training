"""货币转换工具。"""

import logging
from typing import Any, Dict, List, Optional

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class CurrencyConverterTool(BaseTool):
    """货币转换工具。"""

    name: str = "currency_converter"
    description: str = "货币转换工具"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculation", "science"]
    author: str = "汐沫AI"

    _RATES: Dict[str, float] = {
        "USD": 1.0, "EUR": 0.92, "GBP": 0.79, "JPY": 149.5, "CNY": 7.24,
        "AUD": 1.53, "CAD": 1.36, "CHF": 0.88, "HKD": 7.82, "SGD": 1.34,
        "NZD": 1.64, "INR": 83.2, "KRW": 1320.0, "MXN": 17.1, "BRL": 4.95,
        "RUB": 92.5, "ZAR": 18.6, "SEK": 10.4, "NOK": 10.6, "DKK": 6.86,
        "PLN": 4.0, "THB": 35.2, "TWD": 31.5,
    }

    def __init__(self) -> None:
        """初始化货币转换工具。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, float] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._max_history_size: int = 100
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具输入参数。"""
        self.add_parameter("amount", float, required=True, description="金额")
        self.add_parameter("from_currency", str, required=True, description="源货币")
        self.add_parameter("to_currency", str, required=True, description="目标货币")
        self.add_parameter("action", str, required=False, default="convert", choices=["convert", "rates", "list"], description="操作类型")

    def _get_rates(self) -> Dict[str, float]:
        """获取汇率表。"""
        return self._RATES

    def _validate_currency(self, currency: str, role: str) -> str:
        """验证并规范化货币代码。"""
        rates = self._get_rates()
        cur = currency.upper()
        if cur not in rates:
            supported = ", ".join(sorted(rates.keys()))
            raise ToolError(f"不支持的{role}货币: {currency}，支持的货币: {supported}", code=1002)
        return cur

    def _action_list(self) -> Dict[str, Any]:
        """获取支持币种列表。"""
        rates = self._get_rates()
        return {"currencies": list(rates.keys()), "count": len(rates), "base": "USD"}

    def _action_rates(self, from_currency: str) -> Dict[str, Any]:
        """获取以指定货币为基准的汇率。"""
        rates = self._get_rates()
        base = self._validate_currency(from_currency, "基准")
        base_rate = rates[base]
        relative: Dict[str, float] = {k: round(v / base_rate, 6) for k, v in rates.items()}
        return {"base": base, "rates": relative}

    def _action_convert(self, amount: float, from_currency: str, to_currency: str) -> Dict[str, Any]:
        """执行货币转换。"""
        if amount < 0:
            raise ToolError("金额不能为负数", code=1001)
        from_cur = self._validate_currency(from_currency, "源")
        to_cur = self._validate_currency(to_currency, "目标")
        rates = self._get_rates()
        usd_amount = amount / rates[from_cur]
        result = usd_amount * rates[to_cur]
        rate = rates[to_cur] / rates[from_cur]
        return {"amount": amount, "from": from_cur, "to": to_cur, "result": round(result, 4), "rate": round(rate, 6)}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行货币转换工具逻辑。"""
        action: str = str(kwargs.get("action", "convert")).lower()

        if action == "list":
            return self._action_list()
        if action == "rates":
            return self._action_rates(str(kwargs.get("from_currency", "USD")))
        if action == "convert":
            return self._action_convert(
                float(kwargs.get("amount", 0.0)),
                str(kwargs.get("from_currency", "USD")),
                str(kwargs.get("to_currency", "USD")),
            )

        raise ToolError(f"不支持的操作: {action}", code=1003)
