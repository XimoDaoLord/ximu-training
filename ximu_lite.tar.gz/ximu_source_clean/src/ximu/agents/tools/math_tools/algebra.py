"""代数工具，支持多项式运算、因式分解。"""

import logging
import math
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class AlgebraTool(BaseTool):
    """代数工具，支持多项式运算、因式分解。"""

    name: str = "algebra"
    description: str = "代数工具，支持多项式运算、因式分解"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculation", "science"]
    author: str = "汐沫AI"
    _MAX_HISTORY: int = 100

    def __init__(self) -> None:
        """初始化代数工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """定义工具接受的参数。"""
        self.add_parameter("action", str, required=True, choices=["polynomial_add", "polynomial_multiply", "polynomial_evaluate", "gcd", "lcm", "simplify"], description="操作类型")
        self.add_parameter("poly1", list, required=False, default=[], description="多项式1系数（升序排列，索引0为常数项）")
        self.add_parameter("poly2", list, required=False, default=[], description="多项式2系数（升序排列，索引0为常数项）")
        self.add_parameter("a", int, required=False, default=0, description="整数a，用于gcd/lcm操作")
        self.add_parameter("b", int, required=False, default=0, description="整数b，用于gcd/lcm操作")
        self.add_parameter("x", float, required=False, default=0.0, description="求值点x，用于polynomial_evaluate操作")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行代数运算。"""
        action: str = kwargs.get("action", "")
        handlers: Dict[str, Any] = {
            "polynomial_add": lambda k: self._add_polynomials(k),
            "polynomial_multiply": lambda k: self._multiply_polynomials(k),
            "polynomial_evaluate": lambda k: self._evaluate_polynomial(k),
            "gcd": lambda k: self._compute_gcd(k),
            "lcm": lambda k: self._compute_lcm(k),
            "simplify": lambda k: self._simplify_polynomial(k),
        }
        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler(kwargs)

    def _add_polynomials(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """执行多项式加法。"""
        p1: List[Union[int, float]] = list(kwargs.get("poly1", []))
        p2: List[Union[int, float]] = list(kwargs.get("poly2", []))
        self._validate_coefficients(p1, "poly1")
        self._validate_coefficients(p2, "poly2")
        max_len: int = max(len(p1), len(p2))
        p1_extended: List[Union[int, float]] = p1 + [0] * (max_len - len(p1))
        p2_extended: List[Union[int, float]] = p2 + [0] * (max_len - len(p2))
        result: List[Union[int, float]] = [p1_extended[i] + p2_extended[i] for i in range(max_len)]
        return {"result": result, "operation": "add"}

    def _multiply_polynomials(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """执行多项式乘法。"""
        p1: List[Union[int, float]] = list(kwargs.get("poly1", []))
        p2: List[Union[int, float]] = list(kwargs.get("poly2", []))
        self._validate_coefficients(p1, "poly1")
        self._validate_coefficients(p2, "poly2")
        if not p1 or not p2:
            return {"result": [0], "operation": "multiply"}
        result: List[Union[int, float]] = [0] * (len(p1) + len(p2) - 1)
        for i, c1 in enumerate(p1):
            for j, c2 in enumerate(p2):
                result[i + j] += c1 * c2
        return {"result": result, "operation": "multiply"}

    def _evaluate_polynomial(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """执行多项式求值。"""
        poly: List[Union[int, float]] = list(kwargs.get("poly1", []))
        x: float = float(kwargs.get("x", 0.0))
        self._validate_coefficients(poly, "poly1")
        result: float = sum(c * (x ** i) for i, c in enumerate(poly))
        return {"result": result, "polynomial": poly, "x": x}

    def _compute_gcd(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """计算最大公约数。"""
        a: int = int(kwargs.get("a", 0))
        b: int = int(kwargs.get("b", 0))
        return {"gcd": math.gcd(a, b), "a": a, "b": b}

    def _compute_lcm(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """计算最小公倍数。"""
        a: int = int(kwargs.get("a", 0))
        b: int = int(kwargs.get("b", 0))
        if a == 0 or b == 0:
            lcm_val: int = 0
        else:
            lcm_val = abs(a * b) // math.gcd(a, b)
        return {"lcm": lcm_val, "a": a, "b": b}

    def _simplify_polynomial(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """化简多项式，去除尾部零系数。"""
        poly: List[Union[int, float]] = list(kwargs.get("poly1", []))
        self._validate_coefficients(poly, "poly1")
        while len(poly) > 1 and poly[-1] == 0:
            poly.pop()
        degree: int = len(poly) - 1 if poly else -1
        return {"simplified": poly, "degree": degree}

    @staticmethod
    def _validate_coefficients(coeffs: List[Any], param_name: str) -> None:
        """校验多项式系数是否为数字。"""
        for i, c in enumerate(coeffs):
            if not isinstance(c, (int, float)):
                raise ValueError(f"多项式系数 '{param_name}[{i}]' 必须是数字，收到 {type(c).__name__}")

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具主入口，处理参数校验、执行、计时与错误捕获。"""
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._build_error_response(str(validated), 1002, start)
            result = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed)
            return self._build_success_response(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._build_error_response(e.message, e.code, start, e.details)
        except (TypeError, ValueError) as e:
            self._stats["fail"] += 1
            logger.error("参数类型或值错误: %s", e, exc_info=True)
            return self._build_error_response(f"参数错误: {e}", 1003, start)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._build_error_response("工具内部错误", 1006, start)

    def _append_history(self, elapsed: float) -> None:
        """将执行记录追加到历史中，保持有界长度。"""
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
        if len(self._history) > self._MAX_HISTORY:
            self._history.pop(0)

    def _build_success_response(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """构建成功响应字典。"""
        return {"success": True, "data": data, "error": None, "execution_time": elapsed, "tool": self.name, "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()}

    def _build_error_response(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构建错误响应字典。"""
        elapsed: float = round(time.monotonic() - start, 4)
        return {"success": False, "data": None, "error": msg, "error_code": code, "error_details": details or {}, "execution_time": elapsed, "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat()}
