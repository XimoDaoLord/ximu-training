"""随机数生成工具，支持整数、浮点数、选择、洗牌、采样等多种操作。"""

from __future__ import annotations

import logging
import secrets
import string
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from src.ximu.agents.tools.base import BaseTool, ToolError

logger: logging.Logger = logging.getLogger("ximu.tool")

_ASCII_ALPHANUM: str = string.ascii_letters + string.digits
_PASSWORD_CHARS: str = _ASCII_ALPHANUM + "!@#$%^&*"
_ALLOWED_ACTIONS: Tuple[str, ...] = ("integer", "float", "choice", "shuffle", "sample", "string", "uuid", "password")


class RandomGeneratorTool(BaseTool):
    """随机数生成工具，支持多种随机生成操作。"""

    name: str = "random_generator"
    description: str = "随机数生成工具"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculation", "science"]
    author: str = "汐沫AI"
    _HISTORY_LIMIT: int = 100

    def __init__(self) -> None:
        """初始化工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Any] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """注册工具参数。"""
        self.add_parameter("action", str, required=True, choices=list(_ALLOWED_ACTIONS), description="操作类型")
        self.add_parameter("min", int, required=False, default=0, description="最小值")
        self.add_parameter("max", int, required=False, default=100, description="最大值")
        self.add_parameter("count", int, required=False, default=1, description="数量")
        self.add_parameter("choices", list, required=False, default=[], description="选项列表")
        self.add_parameter("length", int, required=False, default=10, description="长度")

    def _validate_ranges(self, min_val: int, max_val: int) -> None:
        """验证 min <= max。

        Args:
            min_val: 最小值
            max_val: 最大值

        Raises:
            ToolError: 当 min 大于 max 时抛出
        """
        if min_val > max_val:
            raise ToolError("min 不能大于 max", code=1002)

    def _validate_positive(self, value: int, name: str) -> None:
        """验证值是否大于0。

        Args:
            value: 待校验的值
            name: 参数名称

        Raises:
            ToolError: 当值小于1时抛出
        """
        if value < 1:
            raise ToolError(f"{name} 必须大于等于 1", code=1002)

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行随机生成操作。

        Args:
            **kwargs: 包含 action 及相关参数的关键字参数字典

        Returns:
            生成结果字典

        Raises:
            ToolError: 当操作未知时抛出
        """
        action: str = str(kwargs.get("action", ""))

        handlers: Dict[str, Any] = {
            "integer": lambda: self._gen_integer(kwargs),
            "float": lambda: self._gen_float(kwargs),
            "choice": lambda: self._gen_choice(kwargs),
            "shuffle": lambda: self._gen_shuffle(kwargs),
            "sample": lambda: self._gen_sample(kwargs),
            "string": lambda: self._gen_string(kwargs),
            "uuid": lambda: self._gen_uuid(),
            "password": lambda: self._gen_password(kwargs),
        }

        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _gen_integer(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """生成随机整数。

        Args:
            kwargs: 包含 min、max、count 的参数字典

        Returns:
            包含随机结果、边界和数量的字典

        Raises:
            ToolError: 当参数不合法时抛出
        """
        mn: int = int(kwargs.get("min", 0))
        mx: int = int(kwargs.get("max", 100))
        count: int = int(kwargs.get("count", 1))
        self._validate_ranges(mn, mx)
        self._validate_positive(count, "count")
        result: List[int] = [secrets.randbelow(mx - mn + 1) + mn for _ in range(count)]
        return {"random": result[0] if count == 1 else result, "min": mn, "max": mx, "count": count}

    def _gen_float(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """生成随机浮点数。

        Args:
            kwargs: 包含 min、max、count 的参数字典

        Returns:
            包含随机结果和边界的字典

        Raises:
            ToolError: 当参数不合法时抛出
        """
        mn: float = float(kwargs.get("min", 0))
        mx: float = float(kwargs.get("max", 100))
        count: int = int(kwargs.get("count", 1))
        if mn > mx:
            raise ToolError("min 不能大于 max", code=1002)
        self._validate_positive(count, "count")
        int_range: int = int((mx - mn) * 10000)
        result: List[float] = [
            round(secrets.randbelow(int_range) / 10000 + mn, 4) for _ in range(count)
        ]
        return {"random": result[0] if count == 1 else result, "min": mn, "max": mx}

    def _gen_choice(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """从选项中随机选择一个。

        Args:
            kwargs: 包含 choices 的参数字典

        Returns:
            包含选中项和选项列表的字典

        Raises:
            ToolError: 当选项列表为空时抛出
        """
        choices: List[Any] = kwargs.get("choices", [])
        if not choices:
            raise ToolError("需要非空 choices", code=1002)
        return {"choice": secrets.choice(choices), "choices": choices}

    def _gen_shuffle(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """打乱列表顺序。

        Args:
            kwargs: 包含 choices 的参数字典

        Returns:
            包含打乱后列表和原始列表的字典
        """
        choices: List[Any] = kwargs.get("choices", [])
        shuffled: List[Any] = choices[:]
        secrets.SystemRandom().shuffle(shuffled)
        return {"shuffled": shuffled, "original": choices}

    def _gen_sample(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """无放回采样。

        Args:
            kwargs: 包含 choices 和 count 的参数字典

        Returns:
            包含采样结果和数量的字典

        Raises:
            ToolError: 当选项不足时抛出
        """
        choices: List[Any] = kwargs.get("choices", [])
        count: int = int(kwargs.get("count", 1))
        self._validate_positive(count, "count")
        if len(choices) < count:
            raise ToolError("选项不足", code=1002)
        return {"sample": secrets.SystemRandom().sample(choices, count), "count": count}

    def _gen_string(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """生成随机字符串。

        Args:
            kwargs: 包含 length 的参数字典

        Returns:
            包含生成的字符串和长度的字典

        Raises:
            ToolError: 当长度不合法时抛出
        """
        length: int = int(kwargs.get("length", 10))
        self._validate_positive(length, "length")
        s: str = "".join(secrets.choice(_ASCII_ALPHANUM) for _ in range(length))
        return {"string": s, "length": length}

    def _gen_uuid(self) -> Dict[str, str]:
        """生成UUID v4。

        Returns:
            包含 UUID 字符串和十六进制表示的字典
        """
        u: uuid.UUID = uuid.uuid4()
        return {"uuid": str(u), "uuid4_hex": u.hex}

    def _gen_password(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """生成随机密码。

        Args:
            kwargs: 包含 length 的参数字典

        Returns:
            包含密码、长度和强度评估的字典

        Raises:
            ToolError: 当长度不合法时抛出
        """
        length: int = int(kwargs.get("length", 12))
        self._validate_positive(length, "length")
        password: str = "".join(secrets.choice(_PASSWORD_CHARS) for _ in range(length))
        strength: str = "strong" if length >= 12 else "medium"
        return {"password": password, "length": length, "strength": strength}

    def _err(
        self,
        msg: str,
        code: int,
        start: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """构造错误响应。

        Args:
            msg: 错误消息
            code: 错误代码
            start: 起始时间戳
            details: 可选错误详情

        Returns:
            错误响应字典
        """
        elapsed: float = round(time.monotonic() - start, 4)
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": elapsed,
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具主入口。"""
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated_params = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(validated_params), 1002, start_time)

            result = self.execute(**validated_params)
            elapsed: float = round(time.monotonic() - start_time, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed)
            return self._build_success_response(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start_time, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start_time)

    def _append_history(self, elapsed: float) -> None:
        """将执行记录追加到历史中。"""
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
        if len(self._history) > self._HISTORY_LIMIT:
            self._history.pop(0)

    def _build_success_response(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """构造成功响应。"""
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def get_stats(self) -> Dict[str, Any]:
        """获取工具统计数据。"""
        ok: int = self._stats["ok"]
        avg: float = self._stats["time"] / ok if ok > 0 else 0.0
        rate: float = ok / max(1, self._stats["calls"])
        return {**self._stats, "avg": round(avg, 4), "rate": round(rate, 4)}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史记录。"""
        return self._history[-limit:]
