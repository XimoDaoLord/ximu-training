"""数论高级工具模块。

提供GCD、LCM、素因子分解、模运算、欧拉函数、斐波那契和卡特兰数等计算功能。
"""

from __future__ import annotations

import logging
import math
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class NumberTheoryAdvTool(BaseTool):
    """数论高级工具类，提供GCD、LCM、素因子分解、模运算、欧拉函数、斐波那契和卡特兰数等计算功能。"""

    name: str = "number_theory_adv"
    description: str = "数论高级工具"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculus", "algebra", "statistics"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化数论高级工具实例，重置历史和统计信息。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """设置工具参数定义。

        定义 action、a、b、n 等参数及其约束。
        """
        self.add_parameter("action", str, required=True, choices=["gcd", "lcm", "prime_factors", "modular", "euler_phi", "fibonacci", "catalan"], description="操作类型")
        self.add_parameter("a", int, required=True, description="数A")
        self.add_parameter("b", int, required=False, default=0, description="数B")
        self.add_parameter("n", int, required=False, default=10, description="参数n")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行具体的数论操作。

        Args:
            **kwargs: 包含操作所需参数的关键字参数字典。

        Returns:
            包含计算结果的字典。

        Raises:
            ToolError: 当执行未知操作或参数无效时抛出。
        """
        action: str = kwargs.get("action", "")
        a: int = int(kwargs.get("a", 0))

        dispatch: Dict[str, Any] = {
            "gcd": lambda: self._gcd(a, kwargs),
            "lcm": lambda: self._lcm(a, kwargs),
            "prime_factors": lambda: self._prime_factors(a),
            "modular": lambda: self._modular(a, kwargs),
            "euler_phi": lambda: self._euler_phi(a),
            "fibonacci": lambda: self._fibonacci(a, kwargs),
            "catalan": lambda: self._catalan(a, kwargs),
        }

        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _gcd(self, a: int, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """计算最大公约数。

        Args:
            a: 第一个整数。
            kwargs: 包含 b 的参数字典。

        Returns:
            包含GCD和输入值的字典。
        """
        b: int = int(kwargs.get("b", 0))
        return {"gcd": math.gcd(a, b), "a": a, "b": b, "method": "euclidean"}

    def _lcm(self, a: int, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """计算最小公倍数。

        Args:
            a: 第一个整数。
            kwargs: 包含 b 的参数字典。

        Returns:
            包含LCM和输入值的字典。
        """
        b: int = int(kwargs.get("b", 0))
        if b == 0:
            lcm_val: int = a
        else:
            lcm_val = abs(a * b) // math.gcd(a, b)
        return {"lcm": lcm_val, "a": a, "b": b}

    def _prime_factors(self, n: int) -> Dict[str, Any]:
        """对正整数进行素因子分解。

        Args:
            n: 待分解的整数。

        Returns:
            包含素因子字典和唯一因子数量的字典。
        """
        if n < 2:
            return {"number": n, "prime_factors": {}, "unique": 0}
        factors: Dict[int, int] = {}
        d: int = 2
        temp: int = n
        while d * d <= temp:
            while temp % d == 0:
                factors[d] = factors.get(d, 0) + 1
                temp //= d
            d += 1
        if temp > 1:
            factors[temp] = factors.get(temp, 0) + 1
        return {"number": n, "prime_factors": factors, "unique": len(factors)}

    def _modular(self, a: int, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """执行模运算。

        Args:
            a: 底数。
            kwargs: 包含指数 b 和模数 m 的参数字典。

        Returns:
            包含模运算结果的字典。

        Raises:
            ToolError: 当模数为非正整数时抛出。
        """
        b: int = int(kwargs.get("b", 7))
        m: int = int(kwargs.get("n", 10))
        if m <= 0:
            raise ToolError("模数必须为正整数", code=1004)
        return {"modular_exponent": pow(a, b, m), "base": a, "exponent": b, "modulus": m}

    def _euler_phi(self, n: int) -> Dict[str, Any]:
        """计算欧拉函数 φ(n)。

        Args:
            n: 正整数。

        Returns:
            包含欧拉函数值的字典。

        Raises:
            ToolError: 当 n 小于1时抛出。
        """
        if n < 1:
            raise ToolError("欧拉函数仅对正整数定义", code=1005)
        result: int = n
        p: int = 2
        temp: int = n
        while p * p <= temp:
            if temp % p == 0:
                while temp % p == 0:
                    temp //= p
                result -= result // p
            p += 1
        if temp > 1:
            result -= result // temp
        return {"euler_phi": result, "n": n}

    def _fibonacci(self, a: int, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """计算斐波那契数列。

        Args:
            a: 未使用的占位参数（保持签名一致）。
            kwargs: 包含 n 的参数字典，表示要计算的项数。

        Returns:
            包含斐波那契数列和指定项值的字典。

        Raises:
            ToolError: 当 n 为负数时抛出。
        """
        _ = a
        n: int = int(kwargs.get("n", 10))
        if n < 0:
            raise ToolError("斐波那契数索引不能为负", code=1006)
        fib: List[int] = [0, 1]
        for _ in range(2, n + 1):
            fib.append(fib[-1] + fib[-2])
        return {"fibonacci": fib[n], "n": n, "sequence": fib[:n + 1]}

    def _catalan(self, a: int, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """计算卡特兰数。

        Args:
            a: 未使用的占位参数（保持签名一致）。
            kwargs: 包含 n 的参数字典。

        Returns:
            包含卡特兰数和计算公式的字典。

        Raises:
            ToolError: 当 n 为负数时抛出。
        """
        _ = a
        n: int = int(kwargs.get("n", 5))
        if n < 0:
            raise ToolError("卡特兰数索引不能为负", code=1007)
        c: int = math.comb(2 * n, n) // (n + 1)
        return {"catalan": c, "n": n, "formula": "C(2n,n)/(n+1)"}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具并返回标准化结果。

        Args:
            params: 输入参数字典。

        Returns:
            包含执行状态、数据、错误信息的标准化字典。
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated_params = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(validated_params), 1002, start)
            result: Dict[str, Any] = self.execute(**validated_params)
            el: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += el
            self._record_history(el)
            return {
                "success": True,
                "data": result,
                "error": None,
                "execution_time": el,
                "tool": self.name,
                "version": self.version,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _record_history(self, elapsed: float) -> None:
        """记录执行历史，最多保留100条。

        Args:
            elapsed: 执行耗时（秒）。
        """
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
        if len(self._history) > 100:
            self._history.pop(0)

    def _err(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """生成错误响应字典。

        Args:
            msg: 错误消息。
            code: 错误代码。
            start: 开始时间戳。
            details: 详细错误信息。

        Returns:
            包含错误信息的字典。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取工具统计信息。

        Returns:
            包含调用次数、成功次数、失败次数、总执行时间和平均执行时间的统计字典。
        """
        ok_count: int = self._stats["ok"]
        calls_count: int = self._stats["calls"]
        avg: float = round(self._stats["time"] / ok_count, 4) if ok_count > 0 else 0.0
        rate: float = round(ok_count / max(1, calls_count), 4)
        return {**self._stats, "avg": avg, "rate": rate}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史调用记录。

        Args:
            limit: 返回记录数量上限，默认为10。

        Returns:
            最近limit条历史记录列表。
        """
        if limit <= 0:
            return []
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。

        Returns:
            包含工具元数据和参数的描述字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }
