from __future__ import annotations

import logging
import math
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger: logging.Logger = logging.getLogger("ximu.tool")


class ProbabilityTool(BaseTool):
    """概率计算工具，支持分布计算、组合排列。"""

    name: str = "probability"
    description: str = "概率计算工具，支持分布计算、组合排列"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculation", "science"]
    author: str = "汐沫AI"
    _HISTORY_LIMIT: int = 100

    def __init__(self) -> None:
        """初始化概率工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """配置工具参数。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=[
                "combination",
                "permutation",
                "factorial",
                "binomial",
                "normal",
                "poisson",
                "bayes",
            ],
            description="操作类型",
        )
        self.add_parameter("n", int, required=False, default=0, description="样本量或总数 n")
        self.add_parameter("k", int, required=False, default=0, description="选取数或事件次数 k")
        self.add_parameter("p", float, required=False, default=0.5, description="概率 p")
        self.add_parameter("mean", float, required=False, default=0.0, description="均值 mean")
        self.add_parameter("std", float, required=False, default=1.0, description="标准差 std")
        self.add_parameter("x", float, required=False, default=0.0, description="x 值")
        self.add_parameter(
            "lambda_", float, required=False, default=1.0, description="泊松分布参数 lambda"
        )

    def _factorial(self, n: int) -> Dict[str, Any]:
        """计算阶乘。"""
        if n < 0:
            raise ToolError("阶乘仅支持非负整数", code=1001, details={"n": n})
        return {"factorial": math.factorial(n), "n": n}

    def _combination(self, n: int, k: int) -> Dict[str, Any]:
        """计算组合数。"""
        if n < 0 or k < 0:
            raise ToolError("组合数参数必须非负", code=1001, details={"n": n, "k": k})
        if k > n:
            return {"combination": 0, "n": n, "k": k, "formula": "C(n,k)"}
        return {"combination": math.comb(n, k), "n": n, "k": k, "formula": "C(n,k)"}

    def _permutation(self, n: int, k: int) -> Dict[str, Any]:
        """计算排列数。"""
        if n < 0 or k < 0:
            raise ToolError("排列数参数必须非负", code=1001, details={"n": n, "k": k})
        if k > n:
            return {"permutation": 0, "n": n, "k": k, "formula": "P(n,k)"}
        return {"permutation": math.perm(n, k), "n": n, "k": k, "formula": "P(n,k)"}

    def _binomial(self, n: int, k: int, p: float) -> Dict[str, Any]:
        """计算二项分布概率。"""
        if n < 0 or k < 0 or k > n:
            raise ToolError(
                "二项分布参数无效: 需要 0 <= k <= n", code=1001, details={"n": n, "k": k}
            )
        if not (0.0 <= p <= 1.0):
            raise ToolError("概率 p 必须在 [0, 1] 范围内", code=1001, details={"p": p})
        prob: float = math.comb(n, k) * (p ** k) * ((1.0 - p) ** (n - k))
        return {
            "probability": round(prob, 6),
            "n": n,
            "k": k,
            "p": p,
            "distribution": "binomial",
        }

    def _normal(self, mean: float, std: float, x: float) -> Dict[str, Any]:
        """计算正态分布PDF和CDF。"""
        if std <= 0:
            raise ToolError("标准差 std 必须为正数", code=1001, details={"std": std})
        pdf: float = (1.0 / (std * math.sqrt(2.0 * math.pi))) * math.exp(
            -0.5 * ((x - mean) / std) ** 2
        )
        cdf: float = 0.5 * (1.0 + math.erf((x - mean) / (std * math.sqrt(2.0))))
        return {
            "pdf": round(pdf, 6),
            "cdf": round(cdf, 6),
            "mean": mean,
            "std": std,
            "x": x,
            "distribution": "normal",
        }

    def _poisson(self, lam: float, k: int) -> Dict[str, Any]:
        """计算泊松分布概率。"""
        if lam < 0:
            raise ToolError("泊松分布参数 lambda 必须非负", code=1001, details={"lambda_": lam})
        if k < 0:
            raise ToolError("泊松分布事件次数 k 必须非负", code=1001, details={"k": k})
        prob: float = (lam ** k) * math.exp(-lam) / math.factorial(k)
        return {
            "probability": round(prob, 6),
            "lambda": lam,
            "k": k,
            "distribution": "poisson",
        }

    def _bayes(self, p_a: float, p_b_given_a: float, p_b: float) -> Dict[str, Any]:
        """计算贝叶斯后验概率。"""
        if not (0.0 <= p_a <= 1.0):
            raise ToolError("P(A) 必须在 [0, 1] 范围内", code=1001, details={"p_a": p_a})
        if not (0.0 <= p_b_given_a <= 1.0):
            raise ToolError(
                "P(B|A) 必须在 [0, 1] 范围内", code=1001, details={"p_b_given_a": p_b_given_a}
            )
        if not (0.0 <= p_b <= 1.0):
            raise ToolError("P(B) 必须在 [0, 1] 范围内", code=1001, details={"p_b": p_b})
        if p_b == 0:
            return {
                "posterior": 0,
                "p_a": p_a,
                "p_b_given_a": p_b_given_a,
                "p_b": p_b,
                "distribution": "bayes",
            }
        posterior: float = (p_b_given_a * p_a) / p_b
        return {
            "posterior": round(min(max(posterior, 0.0), 1.0), 6),
            "p_a": p_a,
            "p_b_given_a": p_b_given_a,
            "p_b": p_b,
            "distribution": "bayes",
        }

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行概率计算。"""
        action: str = kwargs.get("action", "")
        n: int = int(kwargs.get("n", 0))
        k: int = int(kwargs.get("k", 0))

        dispatch: Dict[str, Any] = {
            "factorial": lambda: self._factorial(n),
            "combination": lambda: self._combination(n, k),
            "permutation": lambda: self._permutation(n, k),
            "binomial": lambda: self._binomial(n, k, float(kwargs.get("p", 0.5))),
            "normal": lambda: self._normal(
                float(kwargs.get("mean", 0.0)),
                float(kwargs.get("std", 1.0)),
                float(kwargs.get("x", 0.0)),
            ),
            "poisson": lambda: self._poisson(float(kwargs.get("lambda_", 1.0)), k),
            "bayes": lambda: self._bayes(
                float(kwargs.get("p_a", 0.5)),
                float(kwargs.get("p_b_given_a", 0.5)),
                float(kwargs.get("p_b", 0.5)),
            ),
        }

        if action not in dispatch:
            raise ToolError(f"未知操作: {action}", code=1002)

        return dispatch[action]()

    def _make_success_response(self, data: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """创建成功响应。"""
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _make_error_response(
        self,
        message: str,
        code: int,
        start_time: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """创建错误响应。"""
        elapsed: float = round(time.monotonic() - start_time, 4)
        return {
            "success": False,
            "data": None,
            "error": message,
            "error_code": code,
            "error_details": details or {},
            "execution_time": elapsed,
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, elapsed: float) -> None:
        """记录执行历史。"""
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
        if len(self._history) > self._HISTORY_LIMIT:
            self._history.pop(0)

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具并返回标准化结果。"""
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated_params = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._make_error_response(str(validated_params), 1002, start_time)

            result: Dict[str, Any] = self.execute(**validated_params)
            elapsed_time: float = round(time.monotonic() - start_time, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed_time
            self._append_history(elapsed_time)

            return self._make_success_response(result, elapsed_time)

        except ToolError as e:
            self._stats["fail"] += 1
            return self._make_error_response(e.message, e.code, start_time, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._make_error_response("工具内部错误", 1006, start_time)