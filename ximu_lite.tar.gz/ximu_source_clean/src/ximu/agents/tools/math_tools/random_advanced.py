"""高级随机工具，支持多种概率分布采样和操作。"""

from __future__ import annotations

import logging
import math
import random
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from src.ximu.agents.tools.base import BaseTool, ToolError

logger: logging.Logger = logging.getLogger("ximu.tool")


class RandomAdvancedTool(BaseTool):
    """高级随机工具，支持均匀分布、正态分布、泊松分布等统计分布采样。"""

    name: str = "random_advanced"
    description: str = "高级随机工具"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculus", "algebra", "statistics"]
    author: str = "汐沫AI"
    _HISTORY_LIMIT: int = 100

    def __init__(self) -> None:
        """初始化工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Any] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """注册工具参数。"""
        self.add_parameter(
            "action", str, required=True,
            choices=["uniform", "normal", "poisson", "exponential", "seed", "permutation", "sample"],
            description="操作"
        )
        self.add_parameter("n", int, required=False, default=10, description="数量")
        self.add_parameter("mean", float, required=False, default=0.0, description="均值")
        self.add_parameter("std", float, required=False, default=1.0, description="标准差")

    def _validate_positive(self, value: Any, name: str, allow_zero: bool = False) -> Tuple[bool, str]:
        """校验数值参数是否符合类型与范围。"""
        if not isinstance(value, (int, float)):
            return False, f"参数 {name} 类型错误"
        min_val = 0.0 if allow_zero else 0.0001
        if value < min_val:
            return False, f"参数 {name} 不能小于 {min_val}"
        return True, ""

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行指定的随机操作。"""
        action: str = str(kwargs.get("action", ""))
        n: int = int(kwargs.get("n", 10))
        ok_n, msg_n = self._validate_positive(n, "n")
        if not ok_n:
            raise ToolError(msg_n, code=1003)
        handlers: Dict[str, Any] = {
            "uniform": lambda: self._sample_uniform(n),
            "normal": lambda: self._sample_normal(n, kwargs),
            "poisson": lambda: self._sample_poisson(n, kwargs),
            "exponential": lambda: self._sample_exponential(n, kwargs),
            "seed": self._set_seed,
            "permutation": lambda: self._generate_permutation(n),
            "sample": lambda: self._draw_sample(n),
        }
        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _sample_uniform(self, n: int) -> Dict[str, Any]:
        """生成均匀分布样本。"""
        samples: List[float] = [round(random.uniform(0.0, 1.0), 4) for _ in range(n)]
        return {"samples": samples, "n": n, "distribution": "uniform(0,1)"}

    def _sample_normal(self, n: int, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """生成正态分布样本。"""
        mean: float = float(kwargs.get("mean", 0.0))
        std: float = float(kwargs.get("std", 1.0))
        ok, msg = self._validate_positive(std, "std", allow_zero=True)
        if not ok or std == 0.0:
            raise ToolError("标准差必须大于 0", code=1003)
        samples: List[float] = [round(random.gauss(mean, std), 4) for _ in range(n)]
        return {"samples": samples, "n": n, "mean": mean, "std": std}

    def _sample_poisson(self, n: int, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """生成泊松分布样本。"""
        lam: float = float(kwargs.get("mean", 5.0))
        ok, msg = self._validate_positive(lam, "lambda")
        if not ok or lam <= 0:
            raise ToolError("均值 λ 必须大于 0", code=1003)
        L: float = math.exp(-lam)
        samples: List[int] = []
        for _ in range(n):
            k, p = 0, 1.0
            while p > L:
                k += 1
                p *= random.random()
            samples.append(k - 1)
        return {"samples": samples, "n": n, "lambda": lam, "distribution": "poisson"}

    def _sample_exponential(self, n: int, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """生成指数分布样本。"""
        lam: float = float(kwargs.get("mean", 1.0))
        ok, msg = self._validate_positive(lam, "lambda")
        if not ok or lam <= 0:
            raise ToolError("均值 λ 必须大于 0", code=1003)
        samples: List[float] = [round(random.expovariate(lam), 4) for _ in range(n)]
        return {"samples": samples, "n": n, "lambda": lam}

    def _set_seed(self) -> Dict[str, Any]:
        """设置随机种子为可复现状态。"""
        random.seed(42)
        return {"seed": 42, "set": True, "reproducible": True}

    def _generate_permutation(self, n: int) -> Dict[str, Any]:
        """生成列表的随机排列。"""
        arr: List[int] = list(range(n))
        random.shuffle(arr)
        return {"permutation": arr, "n": n, "method": "fisher_yates"}

    def _draw_sample(self, n: int) -> Dict[str, Any]:
        """从总体中无放回抽样。"""
        population_size: int = 100
        if n > population_size:
            raise ToolError("抽样数量不能超过总体大小 100", code=1003)
        return {
            "sample": random.sample(list(range(population_size)), n),
            "n": n, "population_size": population_size,
            "without_replacement": True,
        }

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """工具统一入口：校验参数、执行并返回结果。"""
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(validated), 1002, start_time)
            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start_time, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed)
            return self._success(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start_time, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start_time)

    def _err(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """生成标准化错误响应。"""
        return {
            "success": False, "data": None, "error": msg,
            "error_code": code, "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def _success(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """生成标准化成功响应。"""
        return {
            "success": True, "data": data, "error": None,
            "execution_time": elapsed, "tool": self.name,
            "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def _append_history(self, elapsed: float) -> None:
        """记录执行历史。"""
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
        if len(self._history) > self._HISTORY_LIMIT:
            self._history.pop(0)
