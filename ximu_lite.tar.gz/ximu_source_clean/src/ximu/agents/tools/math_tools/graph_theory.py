# 状态: [OK] 已实现
from src.ximu.agents.tools.base import BaseTool
from src.ximu.agents.tools.base import ToolError
"""图论工具，支持最短路径、遍历、连通性"""
import time
import logging
from typing import Any, Dict, List, Optional, Union
from datetime import datetime, timezone

# 第17轮: 魔法数字提取为命名常量
_ERR_BAD_REQUEST = 1002  # 参数/请求错误错误码
_ERR_INTERNAL = 1006     # 工具内部错误错误码
_MAX_HISTORY = 100       # 工具调用历史环形上限
_TIME_PRECISION = 4      # 执行时间秒数保留小数位

logger = logging.getLogger("ximu.tool")

class GraphTheoryTool(BaseTool):
    """图论工具，支持最短路径、遍历、连通性"""
    name = "graph_theory"
    description = "图论工具，支持最短路径、遍历、连通性"
    version = "1.0.0"
    category = "math_tools"
    tags = ["math","calculation","science"]
    author = "汐沫AI"

    def __init__(self) -> None:
        """初始化工具实例"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """设置参数"""
        self.add_parameter("action", str, required=True, choices=["shortest_path","bfs","dfs","connected","dijkstra","adjacency"], description="操作")
        self.add_parameter("graph", dict, required=True, description="邻接表")
        self.add_parameter("start", str, required=True, description="起点")
        self.add_parameter("end", str, required=False, default="", description="终点")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行操作"""
        action = kwargs.get("action", "")
        graph = kwargs.get("graph", {})
        start = kwargs.get("start", "")
        end = kwargs.get("end", "")
        
        # 第17轮: 长方法拆分，各操作提取为独立子方法
        handlers = {
            "bfs": lambda: self._bfs(graph, start),
            "dfs": lambda: self._dfs(graph, start),
            "shortest_path": lambda: self._shortest_path(graph, start, end),
            "dijkstra": lambda: self._dijkstra(graph, start, end),
            "connected": lambda: self._connected(graph),
            "adjacency": lambda: self._adjacency(graph),
        }
        handler = handlers.get(action)
        if handler is None:
            raise ToolError("未知操作: " + action, code=_ERR_BAD_REQUEST)
        return handler()

    def _bfs(self, graph: Dict[str, Any], start: str) -> Dict[str, Any]:
        """广度优先搜索"""
        from collections import deque
        visited = set()
        queue = deque([start])
        order = []
        while queue:
            node = queue.popleft()
            if node not in visited:
                visited.add(node)
                order.append(node)
                for neighbor in graph.get(node, []):
                    if neighbor not in visited:
                        queue.append(neighbor)
        return {"order": order, "visited": len(visited), "start": start}

    def _dfs(self, graph: Dict[str, Any], start: str) -> Dict[str, Any]:
        """深度优先搜索"""
        visited = set()
        order = []
        def dfs(node):
            if node in visited:
                return
            visited.add(node)
            order.append(node)
            for neighbor in graph.get(node, []):
                dfs(neighbor)
        dfs(start)
        return {"order": order, "visited": len(visited), "start": start}

    def _shortest_path(self, graph: Dict[str, Any], start: str, end: str) -> Dict[str, Any]:
        """最短路径"""
        from collections import deque
        if not end:
            raise ToolError("需要end", code=_ERR_BAD_REQUEST)
        queue = deque([(start, [start])])
        visited = set([start])
        while queue:
            node, path = queue.popleft()
            if node == end:
                return {"path": path, "distance": len(path) - 1, "start": start, "end": end}
            for neighbor in graph.get(node, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [neighbor]))
        return {"path": None, "distance": -1, "note": "不可达"}

    def _dijkstra(self, graph: Dict[str, Any], start: str, end: str) -> Dict[str, Any]:
        """Dijkstra算法"""
        import heapq
        if not end:
            raise ToolError("需要end", code=_ERR_BAD_REQUEST)
        distances = {node: float("inf") for node in graph}
        distances[start] = 0
        pq = [(0, start)]
        previous = {}
        while pq:
            dist, node = heapq.heappop(pq)
            if node == end:
                break
            if dist > distances[node]:
                continue
            edges = graph.get(node, {}).items() if isinstance(graph.get(node), dict) else [(n, 1) for n in graph.get(node, [])]
            for neighbor, weight in edges:
                new_dist = dist + weight
                if new_dist < distances[neighbor]:
                    distances[neighbor] = new_dist
                    previous[neighbor] = node
                    heapq.heappush(pq, (new_dist, neighbor))
        path = []
        current = end
        while current in previous:
            path.insert(0, current)
            current = previous[current]
        if path:
            path.insert(0, start)
        return {"distance": distances[end], "path": path, "start": start, "end": end}

    def _connected(self, graph: Dict[str, Any]) -> Dict[str, Any]:
        """连通性检查"""
        from collections import deque
        if not graph:
            return {"connected": False}
        all_nodes = set(graph.keys())
        for neighbors in graph.values():
            if isinstance(neighbors, list):
                all_nodes.update(neighbors)
        visited = set()
        queue = deque([list(all_nodes)[0]])
        while queue:
            node = queue.popleft()
            if node not in visited:
                visited.add(node)
                for neighbor in graph.get(node, []):
                    if neighbor not in visited:
                        queue.append(neighbor)
        return {"connected": len(visited) == len(all_nodes), "visited": len(visited), "total": len(all_nodes)}

    def _adjacency(self, graph: Dict[str, Any]) -> Dict[str, Any]:
        """邻接矩阵"""
        nodes = sorted(set(list(graph.keys()) + [n for neighbors in graph.values() for n in (neighbors if isinstance(neighbors, list) else neighbors.keys())]))
        matrix = [[1 if j in graph.get(i, []) else 0 for j in nodes] for i in nodes]
        return {"nodes": nodes, "adjacency_matrix": matrix}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行图论工具：校验参数、调用 execute、记录统计并返回统一结果。"""
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(v, _ERR_BAD_REQUEST, start)
            result = self.execute(**v)
            el = round(time.monotonic() - start, _TIME_PRECISION)
            self._stats["ok"] += 1
            self._stats["time"] += el
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": el})
            if len(self._history) > _MAX_HISTORY: 
                self._history.pop(0)
            return {"success": True, "data": result, "error": None, "execution_time": el, "tool": self.name, "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()}
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", _ERR_INTERNAL, start)

    def _err(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """错误响应"""
        return {"success": False, "data": None, "error": msg, "error_code": code, "error_details": details or {}, "execution_time": round(time.monotonic() - start, _TIME_PRECISION), "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat()}

    def get_stats(self) -> Dict[str, Any]:
        """返回工具调用统计：总调用、成功/失败、累计耗时、平均耗时与成功率。"""
        avg = self._stats["time"] / self._stats["ok"] if self._stats["ok"] > 0 else 0
        rate = self._stats["ok"] / max(1, self._stats["calls"])
        return {**self._stats, "avg": round(avg, 4), "rate": round(rate, 4)}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取历史"""
        return self._history[-limit:] if limit > 0 else []

    def get_descriptor(self) -> Dict[str, Any]:
        """获取描述符"""
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats()
        }
