"""方程求解器模块。

支持线性方程、二次方程、二元一次方程组求解。
"""

from __future__ import annotations

import logging
import math
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class EquationSolverTool(BaseTool):
    """方程求解器工具类，支持线性、二次方程和二元一次方程组求解。"""

    name: str = "equation_solver"
    description: str = "方程求解器，支持线性、二次方程"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculation", "science"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化方程求解器工具。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """注册工具参数定义。

        定义 action、a、b、c、equations 五个参数及其约束。
        """
        self.add_parameter("action", str, required=True, choices=["linear", "quadratic", "system", "polynomial"], description="操作类型")
        self.add_parameter("a", float, required=False, default=0.0, description="系数 a")
        self.add_parameter("b", float, required=False, default=0.0, description="系数 b")
        self.add_parameter("c", float, required=False, default=0.0, description="系数 c")
        self.add_parameter("equations", list, required=False, default=[], description="方程组系数列表")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行方程求解逻辑。

        Args:
            **kwargs: 包含 action、a、b、c、equations 等参数的关键字参数字典。

        Returns:
            包含求解结果的字典。

        Raises:
            ToolError: 当操作无效时抛出。
        """
        action: str = str(kwargs.get("action", ""))

        dispatch: Dict[str, Any] = {
            "linear": lambda: self._solve_linear(kwargs),
            "quadratic": lambda: self._solve_quadratic(kwargs),
            "system": lambda: self._solve_system(kwargs),
            "polynomial": lambda: self._solve_polynomial(),
        }

        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _solve_linear(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """求解一元一次方程 ax + b = 0。

        Args:
            kwargs: 包含 a 和 b 系数的参数字典。

        Returns:
            包含方程形式和解的字典。
        """
        a: float = float(kwargs.get("a", 0.0))
        b: float = float(kwargs.get("b", 0.0))
        if a == 0:
            if b == 0:
                return {"solution": None, "note": "0x + 0 = 0 有无穷多解"}
            return {"solution": None, "note": "0x + b = 0 (b≠0) 无解"}
        return {"equation": f"{a}x + {b} = 0", "solution": -b / a}

    def _solve_quadratic(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """求解一元二次方程 ax^2 + bx + c = 0。

        Args:
            kwargs: 包含 a、b、c 系数的参数字典。

        Returns:
            包含方程形式、判别式和解的字典。
        """
        a: float = float(kwargs.get("a", 0.0))
        b: float = float(kwargs.get("b", 0.0))
        c: float = float(kwargs.get("c", 0.0))
        if a == 0:
            if b == 0:
                return {"solution": None, "note": "退化为常数方程，无变量解"}
            return {"solution": -c / b, "note": "退化为线性方程"}
        discriminant: float = b * b - 4 * a * c
        eq_str: str = f"{a}x^2 + {b}x + {c} = 0"
        if discriminant > 0:
            sqrt_disc: float = math.sqrt(discriminant)
            x1: float = (-b + sqrt_disc) / (2 * a)
            x2: float = (-b - sqrt_disc) / (2 * a)
            return {"equation": eq_str, "solutions": [x1, x2], "discriminant": discriminant}
        if discriminant == 0:
            x: float = -b / (2 * a)
            return {"equation": eq_str, "solutions": [x], "discriminant": 0.0}
        real: float = -b / (2 * a)
        imag: float = math.sqrt(abs(discriminant)) / (2 * a)
        return {
            "equation": eq_str,
            "solutions": [f"{real}+{imag}i", f"{real}-{imag}i"],
            "discriminant": discriminant,
            "complex": True,
        }

    def _solve_system(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """求解二元一次方程组。

        Args:
            kwargs: 包含 equations 的参数字典，格式为 [[a1,b1,c1],[a2,b2,c2]]。

        Returns:
            包含解和方程系数的字典。
        """
        equations: List[List[float]] = kwargs.get("equations", [])
        if len(equations) == 2 and all(len(eq) == 3 for eq in equations):
            a1, b1, c1 = [float(x) for x in equations[0]]
            a2, b2, c2 = [float(x) for x in equations[1]]
            det: float = a1 * b2 - a2 * b1
            if det == 0:
                return {"solution": None, "note": "无解或无穷多解"}
            x_val: float = (c1 * b2 - c2 * b1) / det
            y_val: float = (a1 * c2 - a2 * c1) / det
            return {"solution": {"x": x_val, "y": y_val}, "equations": equations}
        return {"note": "当前仅支持 2x2 线性方程组"}

    def _solve_polynomial(self) -> Dict[str, Any]:
        """求解多项式方程（暂不支持）。

        Returns:
            包含不支持信息的字典。

        Raises:
            ToolError: 当调用此方法时抛出。
        """
        raise ToolError("多项式求解暂不支持", code=1002, details={"supported_actions": ["linear", "quadratic", "system"]})

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具并返回标准化结果。

        Args:
            params: 参数字典，默认为空。

        Returns:
            包含执行状态、结果数据、错误信息等标准响应字典。
        """
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(validated), 1002, start_time)

            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start_time, 4)

            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._record_history(elapsed)

            return {
                "success": True,
                "data": result,
                "error": None,
                "execution_time": elapsed,
                "tool": self.name,
                "version": self.version,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start_time, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start_time)

    def _record_history(self, elapsed: float) -> None:
        """记录执行历史，最多保留100条。

        Args:
            elapsed: 执行耗时（秒）。
        """
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
        if len(self._history) > 100:
            self._history.pop(0)

    def _err(self, msg: str, code: int, start_time: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构建错误返回结构。

        Args:
            msg: 错误消息。
            code: 错误代码。
            start_time: 操作开始时间。
            details: 额外的错误详情。

        Returns:
            包含错误信息的标准响应字典。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start_time, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取统计信息。

        Returns:
            包含调用次数、成功次数、失败次数、总执行时间和平均执行时间的统计字典。
        """
        total_time: float = float(self._stats["time"])
        ok_count: int = int(self._stats["ok"])
        calls: int = int(self._stats["calls"])
        avg_time: float = round(total_time / ok_count, 4) if ok_count > 0 else 0.0
        success_rate: float = round(ok_count / calls, 4) if calls > 0 else 0.0
        return {**self._stats, "avg": avg_time, "rate": success_rate}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取执行历史记录。

        Args:
            limit: 返回记录数量上限，默认为10。

        Returns:
            最近limit条历史记录列表。
        """
        if limit <= 0:
            return []
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。

        Returns:
            包含工具元数据和参数的描述字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }
