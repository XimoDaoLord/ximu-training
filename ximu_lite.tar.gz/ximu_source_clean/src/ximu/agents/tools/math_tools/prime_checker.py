"""素数检查与生成工具模块。

提供素数判断、邻近素数查找、素数范围生成、筛法及素因子分解功能。
"""

from __future__ import annotations

import logging
import math
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class PrimeCheckerTool(BaseTool):
    """素数检查与生成工具类，提供素数判断、邻近素数查找、素数范围生成、筛法及素因子分解功能。"""

    name: str = "prime_checker"
    description: str = "素数检查与生成工具"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculation", "science"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化素数检查工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Any] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """设置工具参数定义。

        定义 action、n、start、end 四个参数及其约束。
        """
        self.add_parameter("action", str, required=True, choices=["is_prime", "next_prime", "prev_prime", "prime_range", "sieve", "factorize"], description="操作类型")
        self.add_parameter("n", int, required=False, default=0, description="目标数字")
        self.add_parameter("start", int, required=False, default=2, description="范围起始值")
        self.add_parameter("end", int, required=False, default=100, description="范围结束值")

    @staticmethod
    def _is_prime(x: int) -> bool:
        """检查整数是否为素数。

        Args:
            x: 待检查的整数。

        Returns:
            如果是素数返回 True，否则返回 False。
        """
        if x < 2:
            return False
        if x < 4:
            return True
        if x % 2 == 0:
            return False
        for i in range(3, int(math.isqrt(x)) + 1, 2):
            if x % i == 0:
                return False
        return True

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行指定的素数相关操作。

        Args:
            **kwargs: 包含 action、n、start、end 等参数的关键字参数字典。

        Returns:
            操作结果字典。

        Raises:
            ToolError: 当操作无效时抛出。
        """
        action: str = kwargs.get("action", "")
        n: int = int(kwargs.get("n", 0))

        dispatch: Dict[str, Any] = {
            "is_prime": lambda: {"n": n, "is_prime": self._is_prime(n)},
            "next_prime": lambda: self._next_prime(n),
            "prev_prime": lambda: self._prev_prime(n),
            "prime_range": lambda: self._prime_range(kwargs),
            "sieve": lambda: self._sieve(kwargs),
            "factorize": lambda: self._factorize(n),
        }

        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _next_prime(self, n: int) -> Dict[str, int]:
        """查找大于n的最小素数。

        Args:
            n: 起始数字。

        Returns:
            包含下一个素数和起始值的字典。
        """
        x: int = n + 1
        while not self._is_prime(x):
            x += 1
        return {"next_prime": x, "from": n}

    def _prev_prime(self, n: int) -> Dict[str, Optional[int]]:
        """查找小于n的最大素数。

        Args:
            n: 起始数字。

        Returns:
            包含前一个素数和起始值的字典。
        """
        x: int = n - 1
        while x > 1 and not self._is_prime(x):
            x -= 1
        return {"prev_prime": x if x > 1 else None, "from": n}

    def _prime_range(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """在指定范围内生成素数列表。

        Args:
            kwargs: 包含 start 和 end 的参数字典。

        Returns:
            包含素数列表、数量和范围的字典。
        """
        start: int = int(kwargs.get("start", 2))
        end: int = int(kwargs.get("end", 100))
        if end < start:
            start, end = end, start
        primes: List[int] = [x for x in range(max(2, start), end + 1) if self._is_prime(x)]
        return {"primes": primes, "count": len(primes), "range": [start, end]}

    def _sieve(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """使用埃拉托斯特尼筛法生成素数列表。

        Args:
            kwargs: 包含 end 的参数字典。

        Returns:
            包含素数列表、数量和上限的字典。
        """
        end: int = int(kwargs.get("end", 100))
        if end < 2:
            return {"primes": [], "count": 0, "limit": end}
        sieve: List[bool] = [True] * (end + 1)
        sieve[0] = sieve[1] = False
        for i in range(2, int(math.isqrt(end)) + 1):
            if sieve[i]:
                for j in range(i * i, end + 1, i):
                    sieve[j] = False
        primes: List[int] = [i for i, is_p in enumerate(sieve) if is_p]
        return {"primes": primes, "count": len(primes), "limit": end}

    def _factorize(self, n: int) -> Dict[str, Any]:
        """对整数进行素因子分解。

        Args:
            n: 待分解的整数。

        Returns:
            包含因子字典、素数判断结果的字典。
        """
        factors: Dict[int, int] = {}
        temp: int = n
        d: int = 2
        while d * d <= temp:
            while temp % d == 0:
                factors[d] = factors.get(d, 0) + 1
                temp //= d
            d += 1
        if temp > 1:
            factors[temp] = factors.get(temp, 0) + 1
        is_prime_result: bool = len(factors) == 1 and list(factors.values())[0] == 1
        return {"n": n, "factors": factors, "is_prime": is_prime_result}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具并记录统计信息。

        Args:
            params: 参数字典，默认为空。

        Returns:
            包含执行状态、结果数据、错误信息等标准响应字典。
        """
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated_params = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(validated_params), 1002, start_time)

            result: Dict[str, Any] = self.execute(**validated_params)
            elapsed_time: float = round(time.monotonic() - start_time, 4)

            self._stats["ok"] += 1
            self._stats["time"] += elapsed_time
            self._record_history(elapsed_time)

            return {
                "success": True,
                "data": result,
                "error": None,
                "execution_time": elapsed_time,
                "tool": self.name,
                "version": self.version,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start_time, e.details)
        except Exception as e:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start_time)

    def _record_history(self, elapsed: float) -> None:
        """记录执行历史，最多保留100条。

        Args:
            elapsed: 执行耗时（秒）。
        """
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
        if len(self._history) > 100:
            self._history.pop(0)

    def _err(self, msg: str, code: int, start_time: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """生成错误响应字典。

        Args:
            msg: 错误消息。
            code: 错误代码。
            start_time: 操作开始时间。
            details: 额外的错误详情。

        Returns:
            包含错误信息的标准响应字典。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start_time, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def get_stats(self) -> Dict[str, Any]:
        """获取工具统计信息。

        Returns:
            包含调用次数、成功次数、失败次数、总执行时间和平均执行时间的统计字典。
        """
        ok_count: int = int(self._stats["ok"])
        total_calls: int = int(self._stats["calls"])
        total_time: float = float(self._stats["time"])
        avg_time: float = round(total_time / ok_count, 4) if ok_count > 0 else 0.0
        success_rate: float = round(ok_count / total_calls, 4) if total_calls > 0 else 0.0
        return {**self._stats, "avg": avg_time, "rate": success_rate}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取执行历史记录。

        Args:
            limit: 返回记录数量上限，默认为10。

        Returns:
            最近limit条历史记录列表。
        """
        if limit <= 0:
            return []
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。

        Returns:
            包含工具元数据和参数的描述字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }
