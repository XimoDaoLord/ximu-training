import logging
import math
import os
import sys
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.agents.tools.base import BaseTool, ToolError
from src.ximu.security.safe_expression import safe_eval_expression

# 设置日志
logger = logging.getLogger("ximu.tool")

# 添加路径以支持独立脚本运行
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

# 构建安全名称空间
def _build_safe_namespace() -> Dict[str, Any]:
    """构建用于安全表达式求值的名称空间。

    包含所有 :mod:`math` 模块的公开函数以及常用内置函数。

    Returns:
        dict: 包含安全可访问名称的字典。
    """
    namespace: Dict[str, Any] = {
        k: getattr(math, k)
        for k in dir(math)
        if not k.startswith("_")
    }
    namespace.update({
        "abs": abs,
        "round": round,
        "min": min,
        "max": max,
        "sum": sum,
        "pow": pow,
    })
    return namespace

class CalculatorTool(BaseTool):
    """科学计算器工具，支持基本运算与科学函数。

    该类提供安全的数学表达式评估能力，通过 :func:`safe_eval_expression`
    限制可访问的函数范围，防止任意代码执行。
    """
    name: str = "calculator"
    description: str = "科学计算器，支持基本运算、科学函数"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculation", "science"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化计算器工具。

        创建历史记录列表和统计数据字典。
        """
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {
            "calls": 0,
            "ok": 0,
            "fail": 0,
            "time": 0.0,
        }
        self._safe_namespace: Dict[str, Any] = _build_safe_namespace()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """注册工具参数。

        定义 ``expression``（必需）和 ``action``（可选，默认 ``evaluate``）两个参数。
        """
        self.add_parameter(
            "expression",
            str,
            required=True,
            description="数学表达式",
        )
        self.add_parameter(
            "action",
            str,
            required=False,
            default="evaluate",
            choices=["evaluate", "simplify", "factor"],
            description="操作类型：evaluate（求值）、simplify（简化）、factor（因式分解）",
        )

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行数学运算。

        根据 ``action`` 参数决定执行求值、简化或因式分解操作。

        Args:
            **kwargs: 包含以下键：
                - ``expression`` (str): 数学表达式。
                - ``action`` (str): 操作类型，可选值为
                  ``"evaluate"``、``"simplify"``、``"factor"``。

        Returns:
            dict: 执行结果，包含：
                - ``expression``: 原始表达式。
                - ``result``: 计算结果（仅 ``evaluate`` 时存在）。
                - ``type``: 结果类型名称（仅 ``evaluate`` 时存在）。
                - ``note``: 提示信息（``simplify``/``factor`` 时存在）。

        Raises:
            ToolError: 当表达式为空、计算出错或操作未知时抛出。
        """
        expression: str = kwargs.get("expression", "")
        action: str = kwargs.get("action", "evaluate")

        if not expression:
            raise ToolError("表达式为空", code=1002)

        try:
            if action == "evaluate":
                result = safe_eval_expression(expression, self._safe_namespace)
                return {
                    "expression": expression,
                    "result": result,
                    "type": type(result).__name__,
                }

            if action == "simplify":
                return {
                    "expression": expression,
                    "note": "简化需要sympy",
                    "result": expression,
                }

            if action == "factor":
                return {
                    "expression": expression,
                    "note": "因式分解需要sympy",
                }

            raise ToolError(f"未知操作: {action}", code=1002)

        except ToolError:
            raise
        except Exception as e:
            raise ToolError(f"计算错误: {e}", code=1006) from e

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具并返回标准化结果。

        这是工具的主要入口点，负责参数验证、执行、计时和错误处理。

        Args:
            params: 参数字典，可选。默认使用空字典。

        Returns:
            dict: 标准化结果，包含以下键：
                - ``success`` (bool): 是否成功。
                - ``data`` (Any): 执行结果（成功时）或 None。
                - ``error`` (str, optional): 错误信息（失败时）。
                - ``error_code`` (int, optional): 错误码（失败时）。
                - ``error_details`` (dict, optional): 错误详情（失败时）。
                - ``execution_time`` (float): 执行耗时（秒）。
                - ``tool`` (str): 工具名称。
                - ``version`` (str): 工具版本（成功时）。
                - ``timestamp`` (str): UTC 时间戳（ISO 格式）。
        """
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated = self.validate_parameters(params)

            if not ok:
                self._stats["fail"] += 1
                error_message: str = validated if isinstance(validated, str) else "参数验证失败"
                return self._err(error_message, 1002, start)

            result = self.execute(**validated)

            elapsed = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed

            now_iso = datetime.now(timezone.utc).isoformat()
            self._history.append({
                "ts": now_iso,
                "ok": True,
                "t": elapsed,
            })
            if len(self._history) > 100:
                self._history.pop(0)

            return {
                "success": True,
                "data": result,
                "error": None,
                "execution_time": elapsed,
                "tool": self.name,
                "version": self.version,
                "timestamp": now_iso,
            }

        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)

        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _err(
        self,
        msg: str,
        code: int,
        start: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """构建标准化错误响应。

        Args:
            msg: 错误消息。
            code: 错误码。
            start: 操作开始时间（``time.monotonic()`` 返回值）。
            details: 可选的错误详情字典。

        Returns:
            dict: 标准化错误响应字典。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取工具统计数据。

        Returns:
            dict: 包含以下键的统计字典：
                - ``calls``: 总调用次数。
                - ``ok``: 成功次数。
                - ``fail``: 失败次数。
                - ``time``: 累计耗时（秒）。
                - ``avg``: 平均每次成功调用耗时（秒）。
                - ``rate``: 成功率（成功次数 / 总调用次数）。
        """
        success_count = int(self._stats["ok"])
        total_calls = int(self._stats["calls"])
        total_time = float(self._stats["time"])

        avg = round(total_time / success_count, 4) if success_count > 0 else 0.0
        rate = round(success_count / max(1, total_calls), 4)

        return {
            **self._stats,
            "avg": avg,
            "rate": rate,
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史记录。

        Args:
            limit: 返回最近多少条记录，默认为 10。

        Returns:
            list: 历史记录列表，每条记录包含 ``ts``（时间戳）、``ok``（是否成功）、``t``（耗时）。
        """
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。

        Returns:
            dict: 包含工具名称、描述、版本、分类、标签、参数定义和统计信息的字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }

    def validate_input(
        self,
        params: Dict[str, Any],
    ) -> Tuple[bool, str]:
        """验证输入参数。

        调用 :meth:`validate_parameters` 并返回简化的验证结果。

        Args:
            params: 参数字典。

        Returns:
            tuple: ``(is_valid, message)``。
                - ``is_valid`` (bool): 是否通过验证。
                - ``message`` (str): 验证失败时的错误消息，通过时为空字符串。
        """
        ok, result = self.validate_parameters(params)
        message = "" if ok else (result if isinstance(result, str) else "参数验证失败")
        return ok, message

    def calculate(self, expression: str) -> Dict[str, Any]:
        """便捷方法：计算给定表达式的值。

        等价于调用 ``run({"expression": expression})``。

        Args:
            expression: 要计算的数学表达式。

        Returns:
            dict: 标准化结果字典。
        """
        return self.run({"expression": expression})

    def safe_eval(self, expression: str) -> Any:
        """安全地评估数学表达式。

        使用预构建的安全名称空间调用 :func:`safe_eval_expression`。

        Args:
            expression: 要评估的数学表达式。

        Returns:
            表达式的计算结果。

        Raises:
            如果表达式无效或求值过程中发生异常，将抛出相应异常。
        """
        return safe_eval_expression(expression, self._safe_namespace)

    def __repr__(self) -> str:
        """返回工具的可读字符串表示。

        Returns:
            str: 格式为 ``<CalculatorTool name=calculator v1.0.0>`` 的字符串。
        """
        return f"<CalculatorTool name={self.name} v{self.version}>"
