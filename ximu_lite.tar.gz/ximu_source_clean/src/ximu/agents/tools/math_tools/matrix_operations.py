"""矩阵运算工具，支持加减乘、转置、求逆。"""

from __future__ import annotations

import time
import logging
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

Matrix = List[List[float]]
MatrixResult = Dict[str, Any]


class MatrixOperationsTool(BaseTool):
    """矩阵运算工具，支持加减乘、转置、求逆等基础线性代数操作。"""

    name = "matrix_operations"
    description = "矩阵运算工具，支持加减乘、转置、求逆"
    version = "1.0.0"
    category = "math_tools"
    tags = ["math", "calculation", "science"]
    author = "汐沫AI"

    def __init__(self) -> None:
        """初始化矩阵运算工具。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """定义工具输入参数。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=["add", "subtract", "multiply", "transpose", "determinant", "inverse", "scalar"],
            description="操作类型",
        )
        self.add_parameter("matrix1", list, required=True, description="第一个矩阵（二维列表）")
        self.add_parameter("matrix2", list, required=False, default=[], description="第二个矩阵（用于加减乘操作）")
        self.add_parameter("scalar", float, required=False, default=1.0, description="标量值（用于标量乘法）")

    @staticmethod
    def _validate_matrix(matrix: Any, name: str = "矩阵") -> Tuple[bool, Optional[str]]:
        """验证矩阵格式。"""
        if not isinstance(matrix, list) or len(matrix) == 0:
            return False, f"{name}不能为空"
        row_len = len(matrix[0])
        for i, row in enumerate(matrix):
            if not isinstance(row, list) or len(row) != row_len:
                return False, f"{name}第{i}行格式不正确或列数不一致"
            for j, val in enumerate(row):
                if not isinstance(val, (int, float)):
                    return False, f"{name}第{i}行第{j}列必须为数值"
        return True, None

    @staticmethod
    def _check_square(m: Any, name: str) -> None:
        """检查是否为方阵。"""
        if len(m) != len(m[0]):
            raise ToolError(f"{name}需要方阵", code=1002)

    @staticmethod
    def _det(m: Matrix) -> float:
        """递归计算方阵的行列式。"""
        n = len(m)
        if n == 1:
            return float(m[0][0])
        if n == 2:
            return float(m[0][0] * m[1][1] - m[0][1] * m[1][0])
        det = 0.0
        for j in range(n):
            minor = [row[:j] + row[j + 1:] for row in m[1:]]
            sign = -1.0 if j % 2 else 1.0
            det += sign * m[0][j] * MatrixOperationsTool._det(minor)
        return det

    @staticmethod
    def _inverse(matrix: Matrix) -> Tuple[Optional[Matrix], float]:
        """使用高斯-约当消元法计算矩阵的逆。"""
        n = len(matrix)
        det = MatrixOperationsTool._det(matrix)
        if abs(det) < 1e-12:
            return None, det

        augmented: List[List[float]] = [
            [float(x) for x in row] + [1.0 if i == j else 0.0 for j in range(n)]
            for i, row in enumerate(matrix)
        ]

        for i in range(n):
            pivot_row = i
            for k in range(i + 1, n):
                if abs(augmented[k][i]) > abs(augmented[pivot_row][i]):
                    pivot_row = k
            if abs(augmented[pivot_row][i]) < 1e-12:
                return None, det
            if pivot_row != i:
                augmented[i], augmented[pivot_row] = augmented[pivot_row], augmented[i]

            pivot = augmented[i][i]
            for j in range(2 * n):
                augmented[i][j] /= pivot

            for k in range(n):
                if k != i:
                    factor = augmented[k][i]
                    for j in range(2 * n):
                        augmented[k][j] -= factor * augmented[i][j]

        inverse = [row[n:] for row in augmented]
        return inverse, det

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行指定的矩阵运算。"""
        action: str = kwargs.get("action", "")
        m1: Any = kwargs.get("matrix1", [])
        m2: Any = kwargs.get("matrix2", [])
        scalar: float = float(kwargs.get("scalar", 1.0))

        valid, err = MatrixOperationsTool._validate_matrix(m1, "matrix1")
        if not valid:
            raise ToolError(err or "matrix1格式无效", code=1002)

        rows, cols = len(m1), len(m1[0])

        if action in ("add", "subtract"):
            valid2, err2 = MatrixOperationsTool._validate_matrix(m2, "matrix2")
            if not valid2:
                raise ToolError(err2 or "matrix2格式无效", code=1002)
            if len(m1) != len(m2) or len(m1[0]) != len(m2[0]):
                raise ToolError("矩阵维度不匹配", code=1002)
            op = lambda a, b: a + b if action == "add" else a - b
            result: List[List[float]] = [[op(m1[i][j], m2[i][j]) for j in range(cols)] for i in range(rows)]
            return {"result": result, "operation": action}

        if action == "multiply":
            valid2, err2 = MatrixOperationsTool._validate_matrix(m2, "matrix2")
            if not valid2:
                raise ToolError(err2 or "matrix2格式无效", code=1002)
            if cols != len(m2):
                raise ToolError("矩阵维度不匹配（列数需等于第二矩阵行数）", code=1002)
            m2_cols = len(m2[0])
            result = [[sum(m1[i][k] * m2[k][j] for k in range(cols)) for j in range(m2_cols)]
                      for i in range(rows)]
            return {"result": result, "operation": "multiply", "shape": [rows, m2_cols]}

        if action == "transpose":
            result = [[m1[j][i] for j in range(rows)] for i in range(cols)]
            return {"result": result, "operation": "transpose", "shape": [cols, rows]}

        if action == "scalar":
            result = [[m1[i][j] * scalar for j in range(cols)] for i in range(rows)]
            return {"result": result, "operation": "scalar_multiply", "scalar": scalar}

        if action == "determinant":
            MatrixOperationsTool._check_square(m1, "矩阵")
            return {"determinant": MatrixOperationsTool._det(m1)}

        if action == "inverse":
            MatrixOperationsTool._check_square(m1, "矩阵")
            inverse, det = MatrixOperationsTool._inverse(m1)
            if inverse is None:
                return {"inverse": None, "note": "矩阵不可逆", "determinant": det}
            return {"inverse": inverse, "determinant": det}

        raise ToolError(f"未知操作: {action}", code=1002)
