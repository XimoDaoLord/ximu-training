"""几何计算工具模块。

支持面积、周长、体积、距离、角度、圆形和三角形等几何计算。
"""

from __future__ import annotations

import math
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from src.ximu.agents.tools.base import BaseTool, ToolError


class GeometryTool(BaseTool):
    """几何计算工具，支持面积、周长、体积、距离、角度、圆形和三角形计算。"""

    name: str = "geometry"
    description: str = "几何计算工具，支持面积、体积、距离计算"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculation", "science"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化几何工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, float] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """配置工具参数。

        定义 action、shape、params、point1、point2 等参数及其约束。
        """
        self.add_parameter("action", str, required=True, choices=["area", "perimeter", "volume", "distance", "angle", "circle", "triangle"], description="操作类型")
        self.add_parameter("shape", str, required=False, default="", description="几何形状")
        self.add_parameter("params", dict, required=False, default={}, description="形状参数")
        self.add_parameter("point1", list, required=False, default=[], description="第一个点坐标")
        self.add_parameter("point2", list, required=False, default=[], description="第二个点坐标")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行几何计算。

        Args:
            **kwargs: 包含 action, shape, params, point1, point2 等参数。

        Returns:
            包含计算结果的字典。

        Raises:
            ToolError: 当操作或形状未知时。
        """
        action: str = kwargs.get("action", "")
        params: Dict[str, Any] = kwargs.get("params", {})
        shape: str = kwargs.get("shape", "")
        point1: List[float] = [float(x) for x in kwargs.get("point1", [])]
        point2: List[float] = [float(x) for x in kwargs.get("point2", [])]

        dispatch: Dict[str, Any] = {
            "area": lambda: self._calc_area(shape, params),
            "perimeter": lambda: self._calc_perimeter(shape, params),
            "volume": lambda: self._calc_volume(shape, params),
            "distance": lambda: self._calc_distance(point1, point2),
            "angle": lambda: self._calc_angle(point1, point2),
            "circle": lambda: self._calc_circle(params),
            "triangle": lambda: self._calc_triangle(params),
        }

        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _calc_area(self, shape: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """计算指定形状的面积。

        Args:
            shape: 形状类型。
            params: 形状参数字典。

        Returns:
            包含面积结果的字典。

        Raises:
            ToolError: 当形状未知时抛出。
        """
        if shape == "circle":
            r: float = float(params.get("radius", 0))
            return {"area": math.pi * r * r, "shape": "circle", "radius": r}
        if shape == "rectangle":
            w: float = float(params.get("width", 0))
            h: float = float(params.get("height", 0))
            return {"area": w * h, "shape": "rectangle"}
        if shape == "triangle":
            b: float = float(params.get("base", 0))
            h: float = float(params.get("height", 0))
            return {"area": 0.5 * b * h, "shape": "triangle"}
        if shape == "sphere":
            r: float = float(params.get("radius", 0))
            return {"area": 4 * math.pi * r * r, "shape": "sphere"}
        if shape == "cylinder":
            r: float = float(params.get("radius", 0))
            h: float = float(params.get("height", 0))
            return {"area": 2 * math.pi * r * (r + h), "shape": "cylinder"}
        raise ToolError(f"未知形状: {shape}", code=1002)

    def _calc_perimeter(self, shape: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """计算指定形状的周长。

        Args:
            shape: 形状类型。
            params: 形状参数字典。

        Returns:
            包含周长结果的字典。

        Raises:
            ToolError: 当形状未知时抛出。
        """
        if shape == "circle":
            r: float = float(params.get("radius", 0))
            return {"perimeter": 2 * math.pi * r, "shape": "circle"}
        if shape == "rectangle":
            w: float = float(params.get("width", 0))
            h: float = float(params.get("height", 0))
            return {"perimeter": 2 * (w + h), "shape": "rectangle"}
        if shape == "triangle":
            a: float = float(params.get("a", 0))
            b: float = float(params.get("b", 0))
            c: float = float(params.get("c", 0))
            return {"perimeter": a + b + c, "shape": "triangle"}
        raise ToolError(f"未知形状: {shape}", code=1002)

    def _calc_volume(self, shape: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """计算指定形状的体积。

        Args:
            shape: 形状类型。
            params: 形状参数字典。

        Returns:
            包含体积结果的字典。

        Raises:
            ToolError: 当形状未知时抛出。
        """
        if shape == "sphere":
            r: float = float(params.get("radius", 0))
            return {"volume": (4.0 / 3.0) * math.pi * r ** 3, "shape": "sphere"}
        if shape == "cube":
            s: float = float(params.get("side", 0))
            return {"volume": s ** 3, "shape": "cube"}
        if shape == "cylinder":
            r: float = float(params.get("radius", 0))
            h: float = float(params.get("height", 0))
            return {"volume": math.pi * r * r * h, "shape": "cylinder"}
        if shape == "cone":
            r: float = float(params.get("radius", 0))
            h: float = float(params.get("height", 0))
            return {"volume": (1.0 / 3.0) * math.pi * r * r * h, "shape": "cone"}
        raise ToolError(f"未知形状: {shape}", code=1002)

    def _calc_distance(self, point1: List[float], point2: List[float]) -> Dict[str, Any]:
        """计算两点之间的距离。

        Args:
            point1: 第一个点的坐标列表。
            point2: 第二个点的坐标列表。

        Returns:
            包含距离和点坐标的字典。

        Raises:
            ToolError: 当点维度不匹配时抛出。
        """
        if len(point1) != len(point2):
            raise ToolError("点维度不匹配", code=1002)
        dist: float = math.sqrt(sum((a - b) ** 2 for a, b in zip(point1, point2)))
        return {"distance": round(dist, 6), "point1": point1, "point2": point2, "dimension": len(point1)}

    def _calc_angle(self, point1: List[float], point2: List[float]) -> Dict[str, Any]:
        """计算两点之间的角度。

        Args:
            point1: 第一个点的2D坐标。
            point2: 第二个点的2D坐标。

        Returns:
            包含角度（度和弧度）的字典。
        """
        if len(point1) == 2 and len(point2) == 2:
            angle_deg: float = math.degrees(math.atan2(point2[1] - point1[1], point2[0] - point1[0]))
            return {"angle_degrees": round(angle_deg, 2), "angle_radians": round(math.radians(angle_deg), 4)}
        return {"note": "需要2D点"}

    def _calc_circle(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """计算圆的属性。

        Args:
            params: 包含 radius 的参数字典。

        Returns:
            包含半径、面积、周长和直径的字典。
        """
        r: float = float(params.get("radius", 0))
        return {"radius": r, "area": math.pi * r * r, "circumference": 2 * math.pi * r, "diameter": 2 * r}

    def _calc_triangle(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """计算三角形的属性（海伦公式）。

        Args:
            params: 包含 a, b, c 边长的参数字典。

        Returns:
            包含半周长、面积和周长的字典。

        Raises:
            ToolError: 当边长不构成合法三角形时抛出。
        """
        a: float = float(params.get("a", 0))
        b: float = float(params.get("b", 0))
        c: float = float(params.get("c", 0))
        s: float = (a + b + c) / 2
        inner: float = s * (s - a) * (s - b) * (s - c)
        if inner < 0:
            raise ToolError("三角形边长不合法", code=1002)
        area: float = math.sqrt(inner)
        return {"sides": [a, b, c], "semi_perimeter": s, "area": area, "perimeter": a + b + c}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具入口。

        Args:
            params: 输入参数字典。

        Returns:
            标准化结果字典。
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._build_error(str(validated), 1002, start)

            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed)

            return {
                "success": True,
                "data": result,
                "error": None,
                "execution_time": elapsed,
                "tool": self.name,
                "version": self.version,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except ToolError as e:
            self._stats["fail"] += 1
            return self._build_error(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._build_error("工具内部错误", 1006, start)

    def _build_error(
        self,
        msg: str,
        code: int,
        start: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """构建错误响应字典。

        Args:
            msg: 错误消息。
            code: 错误代码。
            start: 开始时间戳。
            details: 额外错误详情。

        Returns:
            标准化错误响应字典。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, elapsed: float) -> None:
        """记录执行历史并限制长度。

        Args:
            elapsed: 本次执行耗时（秒）。
        """
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
        if len(self._history) > 100:
            self._history.pop(0)

    def get_stats(self) -> Dict[str, float]:
        """获取执行统计信息。

        Returns:
            包含 calls、ok、fail、time、avg、rate 的字典。
        """
        ok: float = self._stats["ok"]
        avg: float = self._stats["time"] / ok if ok > 0 else 0.0
        rate: float = ok / max(1, self._stats["calls"])
        return {**self._stats, "avg": round(avg, 4), "rate": round(rate, 4)}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的执行历史记录。

        Args:
            limit: 返回最近多少条记录，默认为10。

        Returns:
            最近的历史记录列表。
        """
        return self._history[-limit:] if limit > 0 else []

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述信息。

        Returns:
            包含工具基本信息和统计信息的字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "author": self.author,
            "parameters": self._get_parameters(),
            "stats": self.get_stats(),
        }
