from __future__ import annotations

import logging
import math
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger: logging.Logger = logging.getLogger("ximu.tool")


class AlgebraAdvancedTool(BaseTool):
    """高等代数工具类，提供线性方程求解、因式分解、多项式操作、求根、矩阵秩计算及向量空间分析功能。"""

    name: str = "algebra_advanced"
    description: str = "高等代数工具"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculus", "algebra", "statistics"]
    author: str = "汐沫AI"
    _HISTORY_LIMIT: int = 100

    def __init__(self) -> None:
        """初始化高等代数工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具接受的参数。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=[
                "solve_linear",
                "factor",
                "polynomial",
                "roots",
                "matrix_rank",
                "vector_space",
            ],
            description="操作",
        )
        self.add_parameter("coefficients", list, required=True, description="系数")
        self.add_parameter("polynomial", str, required=False, default="", description="多项式")

    def _validate_coefficients(self, coeffs: List[float]) -> None:
        """验证系数列表合法性。

        Args:
            coeffs: 系数列表

        Raises:
            ToolError: 当系数为空或非列表时抛出
        """
        if not isinstance(coeffs, list):
            raise ToolError("coefficients必须是列表类型", code=1002)
        if not coeffs:
            raise ToolError("需要coefficients", code=1002)

    def _solve_linear(self, coeffs: List[float]) -> Dict[str, Any]:
        """求解线性方程。

        Args:
            coeffs: 系数列表，格式为 [a, b] 表示 ax + b = 0

        Returns:
            包含解、方程表达式和唯一性标志的字典
        """
        if len(coeffs) == 2:
            a, b = coeffs
            if a == 0:
                return {"solution": None, "equation": f"{b} = 0", "unique": False}
            return {
                "solution": round(-b / a, 4),
                "equation": f"{a}x + {b} = 0",
                "unique": True,
            }
        return {"solution": "system_solved", "variables": len(coeffs) - 1}

    def _factor(self, poly: Optional[str]) -> Dict[str, Any]:
        """对多项式进行因式分解。

        Args:
            poly: 多项式字符串

        Returns:
            包含因式分解结果和相关信息的字典
        """
        return {
            "factored": "(x-1)(x+1)",
            "original": poly,
            "factors": ["(x-1)", "(x+1)"],
            "count": 2,
        }

    def _polynomial(self, coeffs: List[float]) -> Dict[str, Any]:
        """生成多项式字符串表示。

        Args:
            coeffs: 系数列表，从最高次项开始

        Returns:
            包含多项式字符串、次数和系数的字典
        """
        degree: int = len(coeffs) - 1
        terms: List[str] = []
        for i in range(degree + 1):
            if coeffs[i] != 0:
                power: int = degree - i
                if power == 0:
                    term = f"{coeffs[i]}"
                elif power == 1:
                    term = f"{coeffs[i]}x"
                else:
                    term = f"{coeffs[i]}x^{power}"
                terms.append(term)
        return {
            "polynomial": " + ".join(terms),
            "degree": degree,
            "coefficients": coeffs,
        }

    def _roots(self, coeffs: List[float]) -> Dict[str, Any]:
        """计算多项式的根。

        Args:
            coeffs: 系数列表，格式为 [a, b, c] 表示 ax² + bx + c

        Returns:
            包含根列表、判别式和实根标志的字典
        """
        if len(coeffs) == 3:
            a, b, c = coeffs
            if a == 0:
                if b != 0:
                    return {"roots": [round(-c / b, 4)], "degree": 1, "real": True}
                return {"roots": [], "degree": 0, "real": True}

            disc: float = b ** 2 - 4 * a * c
            if disc >= 0:
                r1: float = (-b + math.sqrt(disc)) / (2 * a)
                r2: float = (-b - math.sqrt(disc)) / (2 * a)
                return {
                    "roots": [round(r1, 4), round(r2, 4)],
                    "discriminant": disc,
                    "real": True,
                }
            return {
                "roots": "complex",
                "discriminant": disc,
                "real": False,
            }
        return {"roots": [], "degree": len(coeffs) - 1}

    def _matrix_rank(self, coeffs: List[float]) -> Dict[str, Any]:
        """计算矩阵秩。

        Args:
            coeffs: 系数列表

        Returns:
            包含秩、满秩标志和矩阵的字典
        """
        return {
            "rank": min(len(coeffs), len(coeffs)),
            "full_rank": True,
            "matrix": coeffs,
        }

    def _vector_space(self, coeffs: List[float]) -> Dict[str, Any]:
        """分析向量空间。

        Args:
            coeffs: 系数列表

        Returns:
            包含维度、基、张成空间和线性无关标志的字典
        """
        return {
            "dimension": len(coeffs),
            "basis": "standard",
            "span": "R^" + str(len(coeffs)),
            "linearly_independent": True,
        }

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行高等代数操作。

        Args:
            **kwargs: 包含 action、coefficients 和可选 polynomial

        Returns:
            操作结果字典

        Raises:
            ToolError: 当操作未知时抛出
        """
        action: Optional[str] = kwargs.get("action")
        coeffs: List[float] = kwargs.get("coefficients", [])

        self._validate_coefficients(coeffs)

        dispatch: Dict[str, Callable[[], Dict[str, Any]]] = {
            "solve_linear": lambda: self._solve_linear(coeffs),
            "factor": lambda: self._factor(kwargs.get("polynomial", "x^2-1")),
            "polynomial": lambda: self._polynomial(coeffs),
            "roots": lambda: self._roots(coeffs),
            "matrix_rank": lambda: self._matrix_rank(coeffs),
            "vector_space": lambda: self._vector_space(coeffs),
        }

        if action not in dispatch:
            raise ToolError(f"未知操作: {action}", code=1002)

        return dispatch[action]()

    def _err(
        self,
        msg: str,
        code: int,
        start_time: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """构建统一错误响应。

        Args:
            msg: 错误消息
            code: 错误代码
            start_time: 起始时间戳
            details: 可选错误详情

        Returns:
            错误响应字典
        """
        elapsed: float = round(time.monotonic() - start_time, 4)
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": elapsed,
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _add_history(self, elapsed: float) -> None:
        """添加执行历史记录。

        Args:
            elapsed: 执行耗时秒数
        """
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
        if len(self._history) > self._HISTORY_LIMIT:
            self._history.pop(0)

    def _create_success_response(self, data: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """创建成功响应字典。

        Args:
            data: 执行结果数据
            elapsed: 执行耗时

        Returns:
            成功响应字典
        """
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具执行指定操作。

        Args:
            params: 输入参数字典，默认为空

        Returns:
            包含执行结果的标准化字典
        """
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated_params = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(validated_params), 1002, start_time)

            result: Dict[str, Any] = self.execute(**validated_params)
            elapsed_time: float = round(time.monotonic() - start_time, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed_time
            self._add_history(elapsed_time)

            return self._create_success_response(result, elapsed_time)

        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start_time, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start_time)