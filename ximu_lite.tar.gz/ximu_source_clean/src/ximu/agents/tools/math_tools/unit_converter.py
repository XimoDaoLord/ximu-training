"""
单位转换工具，支持长度、重量、温度等多种单位换算。
本模块提供 UnitConverterTool 类，用于执行各类单位转换。
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger: logging.Logger = logging.getLogger("ximu.tool")


class UnitConverterTool(BaseTool):
    """单位转换工具，支持长度、重量、温度、面积、体积、速度、时间和数据单位换算。

    支持的转换类型：
    - length: 长度单位
    - weight: 重量单位
    - temperature: 温度单位
    - area: 面积单位
    - volume: 体积单位
    - speed: 速度单位
    - time: 时间单位
    - data: 数据单位
    """

    name: str = "unit_converter"
    description: str = "单位转换工具，支持长度、重量、温度等"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculation", "science"]
    author: str = "汐沫AI"
    _HISTORY_LIMIT: int = 100

    # 长度单位换算因子（以米为基准）
    LENGTH_FACTORS: Dict[str, float] = {
        "m": 1.0, "km": 1000.0, "cm": 0.01, "mm": 0.001, "mi": 1609.344, "yd": 0.9144, "ft": 0.3048, "in": 0.0254, "nm": 1e-9,
    }
    # 重量单位换算因子（以千克为基准）
    WEIGHT_FACTORS: Dict[str, float] = {
        "kg": 1.0, "g": 0.001, "mg": 1e-6, "t": 1000.0, "lb": 0.453592, "oz": 0.0283495, "ton": 1000.0,
    }
    # 面积单位换算因子（以平方米为基准）
    AREA_FACTORS: Dict[str, float] = {
        "m2": 1.0, "km2": 1e6, "cm2": 1e-4, "mm2": 1e-6, "ha": 10000.0, "acre": 4046.86, "ft2": 0.092903,
    }
    # 体积单位换算因子（以升为基准）
    VOLUME_FACTORS: Dict[str, float] = {
        "l": 1.0, "ml": 0.001, "m3": 1000.0, "gal": 3.78541, "qt": 0.946353, "pt": 0.473176, "cup": 0.236588,
    }
    # 速度单位换算因子（以米/秒为基准）
    SPEED_FACTORS: Dict[str, float] = {
        "mps": 1.0, "kmh": 0.277778, "mph": 0.44704, "knot": 0.514444,
    }
    # 时间单位换算因子（以秒为基准）
    TIME_FACTORS: Dict[str, float] = {
        "s": 1.0, "ms": 0.001, "min": 60.0, "h": 3600.0, "day": 86400.0, "week": 604800.0,
    }
    # 数据单位换算因子（以字节为基准）
    DATA_FACTORS: Dict[str, float] = {
        "B": 1.0, "KB": 1024.0, "MB": 1048576.0, "GB": 1073741824.0, "TB": 1099511627776.0,
    }

    # 温度转换规则列表
    TEMP_CONVERSIONS: List[tuple] = [
        ("C", "F", lambda x: x * 9 / 5 + 32),
        ("F", "C", lambda x: (x - 32) * 5 / 9),
        ("C", "K", lambda x: x + 273.15),
        ("K", "C", lambda x: x - 273.15),
        ("F", "K", lambda x: (x - 32) * 5 / 9 + 273.15),
        ("K", "F", lambda x: (x - 273.15) * 9 / 5 + 32),
    ]

    # 因子映射字典
    FACTOR_MAP: Dict[str, Dict[str, float]] = {
        "length": LENGTH_FACTORS, "weight": WEIGHT_FACTORS, "area": AREA_FACTORS, "volume": VOLUME_FACTORS, "speed": SPEED_FACTORS, "time": TIME_FACTORS, "data": DATA_FACTORS,
    }

    def __init__(self) -> None:
        """初始化工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """配置工具参数。"""
        self.add_parameter("action", str, required=True, choices=["length", "weight", "temperature", "area", "volume", "speed", "time", "data"], description="操作类型")
        self.add_parameter("value", float, required=True, description="待转换数值")
        self.add_parameter("from_unit", str, required=True, description="源单位")
        self.add_parameter("to_unit", str, required=True, description="目标单位")

    def _convert_temperature(self, value: float, from_unit: str, to_unit: str) -> float:
        """执行温度单位转换。

        Args:
            value: 温度值
            from_unit: 源单位
            to_unit: 目标单位

        Returns:
            转换后的温度值
        """
        for f, t, func in self.TEMP_CONVERSIONS:
            if from_unit == f and to_unit == t:
                return func(value)
        return value

    def _convert_linear(self, value: float, from_unit: str, to_unit: str, factors: Dict[str, float]) -> float:
        """执行线性单位转换。

        Args:
            value: 数值
            from_unit: 源单位
            to_unit: 目标单位
            factors: 单位换算因子字典

        Returns:
            转换后的数值
        """
        base: float = value * factors[from_unit]
        return base / factors[to_unit]

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行单位转换。

        Args:
            **kwargs: 包含 action, value, from_unit, to_unit 等参数

        Returns:
            包含转换结果的字典

        Raises:
            ToolError: 当参数无效或单位不支持时抛出
        """
        action: str = str(kwargs.get("action", ""))
        value: float = float(kwargs.get("value", 0.0))
        from_unit: str = str(kwargs.get("from_unit", ""))
        to_unit: str = str(kwargs.get("to_unit", ""))

        if action == "temperature":
            result: float = self._convert_temperature(value, from_unit, to_unit)
            return {"result": round(result, 6), "value": value, "from": from_unit, "to": to_unit, "type": "temperature"}

        factors: Optional[Dict[str, float]] = self.FACTOR_MAP.get(action)
        if not factors or from_unit not in factors or to_unit not in factors:
            raise ToolError("不支持的单位转换", code=1002)

        result: float = self._convert_linear(value, from_unit, to_unit, factors)
        return {"result": round(result, 8), "value": value, "from": from_unit, "to": to_unit, "type": action}

    def _make_success_response(self, data: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """构造成功响应字典。

        Args:
            data: 执行结果数据
            elapsed: 执行耗时

        Returns:
            标准化的成功响应字典
        """
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _make_error_response(self, msg: str, code: int, start_time: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构造错误响应字典。

        Args:
            msg: 错误消息
            code: 错误代码
            start_time: 开始时间戳
            details: 可选详情

        Returns:
            标准化的错误响应字典
        """
        elapsed: float = round(time.monotonic() - start_time, 4)
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": elapsed,
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, elapsed: float) -> None:
        """添加历史记录。

        Args:
            elapsed: 执行耗时
        """
        entry: Dict[str, Any] = {"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed}
        self._history.append(entry)
        if len(self._history) > self._HISTORY_LIMIT:
            self._history.pop(0)

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具入口。

        Args:
            params: 参数字典，默认为空

        Returns:
            包含成功/失败状态、数据、错误信息等字段的字典
        """
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._make_error_response(str(validated), 1002, start_time)

            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start_time, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed)

            return self._make_success_response(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._make_error_response(e.message, e.code, start_time, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._make_error_response("工具内部错误", 1006, start_time)