"""日期时间计算工具。"""

import logging
from typing import Any, Dict, Optional, Union, List
from datetime import datetime, timedelta

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DatetimeCalculatorTool(BaseTool):
    """日期时间计算工具类。"""

    name: str = "datetime_calculator"
    description: str = "日期时间计算工具"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculation", "science"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化日期时间计算工具。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数。"""
        self.add_parameter(
            "action", str, required=True,
            choices=["add", "subtract", "diff", "format", "parse", "weekday", "timestamp"],
            description="操作类型"
        )
        self.add_parameter("date", str, required=False, default="", description="日期字符串")
        self.add_parameter("days", int, required=False, default=0, description="天数")
        self.add_parameter("date2", str, required=False, default="", description="第二个日期字符串")
        self.add_parameter("format", str, required=False, default="%Y-%m-%d", description="日期格式")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行日期时间计算操作。"""
        action: str = str(kwargs.get("action", ""))
        fmt: str = str(kwargs.get("format", "%Y-%m-%d"))

        if action == "add":
            return self._add_days(kwargs, fmt)
        if action == "subtract":
            return self._subtract_days(kwargs, fmt)
        if action == "diff":
            return self._date_diff(kwargs, fmt)
        if action == "format":
            return self._format_date(kwargs, fmt)
        if action == "parse":
            return self._parse_date(kwargs, fmt)
        if action == "weekday":
            return self._get_weekday(kwargs, fmt)
        if action == "timestamp":
            return self._get_timestamp(kwargs, fmt)

        raise ToolError(f"未知操作: {action}", code=1002, details={"action": action})

    def _add_days(self, kwargs: Dict[str, Any], fmt: str) -> Dict[str, Any]:
        """添加天数。"""
        date_str: str = str(kwargs.get("date", ""))
        days: int = int(kwargs.get("days", 0))
        dt: datetime = self._parse_date_or_now(date_str, fmt)
        result: datetime = dt + timedelta(days=days)
        return {"result": result.strftime(fmt), "original": dt.strftime(fmt), "days_added": days}

    def _subtract_days(self, kwargs: Dict[str, Any], fmt: str) -> Dict[str, Any]:
        """减去天数。"""
        date_str: str = str(kwargs.get("date", ""))
        days: int = int(kwargs.get("days", 0))
        dt: datetime = self._parse_date_or_now(date_str, fmt)
        result: datetime = dt - timedelta(days=days)
        return {"result": result.strftime(fmt), "original": dt.strftime(fmt), "days_subtracted": days}

    def _date_diff(self, kwargs: Dict[str, Any], fmt: str) -> Dict[str, Any]:
        """计算日期差。"""
        date1_str: str = str(kwargs.get("date", ""))
        date2_str: str = str(kwargs.get("date2", ""))
        if not date1_str or not date2_str:
            raise ToolError("计算日期差值需要提供两个日期", code=1002)
        try:
            d1: datetime = datetime.strptime(date1_str, fmt)
            d2: datetime = datetime.strptime(date2_str, fmt)
        except ValueError as e:
            raise ToolError(f"日期解析失败: {e}", code=1002, details={"date1": date1_str, "date2": date2_str})
        delta: timedelta = d2 - d1
        return {
            "days": delta.days,
            "seconds": delta.total_seconds(),
            "hours": delta.total_seconds() / 3600,
            "date1": d1.strftime(fmt),
            "date2": d2.strftime(fmt),
        }

    def _format_date(self, kwargs: Dict[str, Any], fmt: str) -> Dict[str, Any]:
        """格式化日期。"""
        date_str: str = str(kwargs.get("date", ""))
        dt: datetime = self._parse_date_or_now(date_str, fmt)
        return {
            "iso": dt.isoformat(),
            "formatted": dt.strftime(fmt),
            "year": dt.year,
            "month": dt.month,
            "day": dt.day,
            "hour": dt.hour,
            "minute": dt.minute,
            "second": dt.second,
        }

    def _parse_date(self, kwargs: Dict[str, Any], fmt: str) -> Dict[str, Any]:
        """解析日期字符串。"""
        date_str: str = str(kwargs.get("date", ""))
        if not date_str:
            raise ToolError("解析操作需要提供日期字符串", code=1002)
        try:
            dt: datetime = datetime.strptime(date_str, fmt)
        except ValueError as e:
            raise ToolError(f"日期解析失败: {e}", code=1002, details={"date": date_str, "format": fmt})
        return {"parsed": dt.isoformat(), "year": dt.year, "month": dt.month, "day": dt.day}

    def _get_weekday(self, kwargs: Dict[str, Any], fmt: str) -> Dict[str, Any]:
        """获取星期几。"""
        date_str: str = str(kwargs.get("date", ""))
        dt: datetime = self._parse_date_or_now(date_str, fmt)
        weekdays: List[str] = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        return {"weekday": weekdays[dt.weekday()], "weekday_number": dt.weekday() + 1, "date": dt.strftime(fmt)}

    def _get_timestamp(self, kwargs: Dict[str, Any], fmt: str) -> Dict[str, Any]:
        """获取时间戳。"""
        date_str: str = str(kwargs.get("date", ""))
        dt: datetime = self._parse_date_or_now(date_str, fmt)
        return {"timestamp": dt.timestamp(), "datetime": dt.isoformat()}

    def _parse_date_or_now(self, date_str: str, fmt: str) -> datetime:
        """解析日期字符串，如果为空则返回当前时间。"""
        if not date_str:
            return datetime.now()
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError as e:
            raise ToolError(f"日期解析失败: '{date_str}' 不符合格式 '{fmt}'", code=1002, details={"date": date_str, "format": fmt, "error": str(e)})
