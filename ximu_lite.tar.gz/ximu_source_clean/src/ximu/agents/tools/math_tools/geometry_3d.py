"""3D几何工具模块。

提供三维空间中的距离、体积、表面积、旋转、投影和相交计算功能。
"""

import logging
import math
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class Geometry3dTool(BaseTool):
    """3D几何工具，支持距离、体积、表面积、旋转、投影和相交计算。"""

    name: str = "geometry_3d"
    description: str = "3D几何工具"
    version: str = "1.0.0"
    category: str = "math_tools"
    tags: List[str] = ["math", "calculus", "algebra", "statistics"]
    author: str = "汐沫AI"
    _MAX_HISTORY: int = 100

    def __init__(self) -> None:
        """初始化几何工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Any] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """注册工具参数定义。"""
        self.add_parameter("action", str, required=True, choices=["distance", "volume", "surface", "rotation", "projection", "intersection"], description="操作类型")
        self.add_parameter("point_a", list, required=True, description="点A坐标 [x, y, z]")
        self.add_parameter("point_b", list, required=False, default=[], description="点B坐标 [x, y, z]，仅 distance 操作使用")
        self.add_parameter("shape", str, required=False, default="sphere", description="几何形状类型，如 sphere, cube")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行具体的几何计算。"""
        action: str = kwargs.get("action", "")
        pa: List[float] = self._ensure_3d_point(kwargs.get("point_a", [0, 0, 0]), "point_a")
        handlers: Dict[str, Any] = {
            "distance": lambda: self._compute_distance(pa, kwargs),
            "volume": lambda: self._compute_volume(pa, kwargs.get("shape", "sphere")),
            "surface": lambda: self._compute_surface_area(pa, kwargs.get("shape", "sphere")),
            "rotation": lambda: self._rotate_z_axis(pa),
            "projection": lambda: self._project_to_2d(pa),
            "intersection": lambda: self._compute_intersection(pa),
        }
        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _compute_distance(self, point_a: List[float], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """计算两点间距离。"""
        point_b: List[float] = self._ensure_3d_point(kwargs.get("point_b", [1, 1, 1]), "point_b")
        dist: float = math.sqrt(sum((point_a[i] - point_b[i]) ** 2 for i in range(3)))
        return {"distance": round(dist, 4), "point_a": point_a, "point_b": point_b, "dimensions": 3}

    def _compute_volume(self, point: List[float], shape: str) -> Dict[str, Any]:
        """计算几何体体积。"""
        r: float = point[0] if point else 1.0
        if shape == "sphere":
            return {"volume": round(4.0 / 3.0 * math.pi * r ** 3, 4), "shape": shape, "radius": r}
        if shape == "cube":
            s: float = point[0] if point else 1.0
            return {"volume": round(s ** 3, 4), "shape": shape, "side": s}
        return {"volume": 1.0, "shape": shape}

    def _compute_surface_area(self, point: List[float], shape: str) -> Dict[str, Any]:
        """计算几何体表面积。"""
        r: float = point[0] if point else 1.0
        return {"surface_area": round(4.0 * math.pi * r ** 2, 4), "shape": shape, "radius": r}

    def _rotate_z_axis(self, point: List[float]) -> Dict[str, Any]:
        """绕Z轴旋转90度。"""
        return {"rotated": point, "axis": "z", "angle_deg": 90, "result": [round(-point[1], 4), round(point[0], 4), point[2]]}

    def _project_to_2d(self, point: List[float]) -> Dict[str, Any]:
        """将三维点投影到二维平面。"""
        return {"projected": [point[0], point[1]], "from": "3D", "to": "2D", "method": "orthographic", "z_removed": point[2] if len(point) > 2 else 0}

    def _compute_intersection(self, point: List[float]) -> Dict[str, Any]:
        """计算与平面的相交情况。"""
        return {"intersects": True, "shape_a": "sphere", "shape_b": "plane", "intersection": "circle", "radius": point[0] if point else 1.0}

    @staticmethod
    def _ensure_3d_point(point: Any, param_name: str) -> List[float]:
        """验证并确保点为三维坐标。"""
        if not isinstance(point, (list, tuple)):
            raise ValueError(f"参数 '{param_name}' 必须是列表或元组")
        if len(point) != 3:
            raise ValueError(f"参数 '{param_name}' 必须包含恰好3个坐标分量，收到 {len(point)} 个")
        return [float(x) for x in point]

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具，执行参数验证、计算和统计记录。"""
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._build_error_response(str(validated) if isinstance(validated, str) else "参数无效", 1002, start)
            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed)
            return self._build_success_response(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._build_error_response(e.message, e.code, start, e.details)
        except ValueError as e:
            self._stats["fail"] += 1
            return self._build_error_response(str(e), 1002, start)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._build_error_response("工具内部错误", 1006, start)

    def _append_history(self, elapsed: float) -> None:
        """将执行记录追加到历史中，保持有界长度。"""
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
        if len(self._history) > self._MAX_HISTORY:
            self._history.pop(0)

    def _build_success_response(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """构造成功响应字典。"""
        return {"success": True, "data": data, "error": None, "execution_time": elapsed, "tool": self.name, "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()}

    def _build_error_response(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构造错误响应字典。"""
        elapsed: float = round(time.monotonic() - start, 4)
        return {"success": False, "data": None, "error": msg, "error_code": code, "error_details": details or {}, "execution_time": elapsed, "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat()}
