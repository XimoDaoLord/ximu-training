"""工具基类模块 - 定义所有工具的标准化接口、参数验证与执行框架。"""

import logging
import time
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Type, Union

logger = logging.getLogger("ximu.tools.base")


class ToolError(Exception):
    """工具执行过程中抛出的标准异常。"""

    def __init__(self, message: str, code: int = 1006, details: Optional[Dict[str, Any]] = None) -> None:
        """初始化工具异常。

        Args:
            message: 错误消息。
            code: 错误代码。
            details: 错误详情字典。
        """
        super().__init__(message)
        self.message: str = message
        self.code: int = code
        self.details: Dict[str, Any] = details or {}


class ParameterSchema:
    """参数模式定义，用于描述和验证输入参数。"""

    def __init__(
        self,
        name: str,
        param_type: Type,
        required: bool = True,
        description: str = "",
        default: Any = None,
        choices: Optional[List[Any]] = None,
        min_value: Any = None,
        max_value: Any = None,
        max_length: Optional[int] = None,
    ) -> None:
        """初始化参数模式定义。

        Args:
            name: 参数名称。
            param_type: 参数类型。
            required: 是否必填。
            description: 参数描述。
            default: 默认值。
            choices: 可选值列表。
            min_value: 最小值。
            max_value: 最大值。
            max_length: 最大长度。
        """
        self.name: str = name
        self.param_type: Type = param_type
        self.required: bool = required
        self.description: str = description
        self.default: Any = default
        self.choices: Optional[List[Any]] = choices
        self.min_value: Any = min_value
        self.max_value: Any = max_value
        self.max_length: Optional[int] = max_length

    def validate(self, value: Any) -> Tuple[bool, Any]:
        """验证参数值是否符合模式定义。

        Args:
            value: 待验证的值。

        Returns:
            元组，包含验证是否成功和验证后的值或错误消息。
        """
        if value is None:
            if self.required:
                return False, f"参数 '{self.name}' 为必填项"
            return True, None

        if self.param_type == str:
            if not isinstance(value, str):
                value = str(value)
            if self.max_length is not None and len(value) > self.max_length:
                return False, f"参数 '{self.name}' 长度不能超过 {self.max_length}"
        elif self.param_type == int:
            try:
                value = int(value)
            except (ValueError, TypeError):
                return False, f"参数 '{self.name}' 必须为整数"
        elif self.param_type == float:
            try:
                value = float(value)
            except (ValueError, TypeError):
                return False, f"参数 '{self.name}' 必须为数字"
        elif self.param_type == bool:
            if not isinstance(value, bool):
                value = str(value).lower() in ("true", "1", "yes")
        elif self.param_type == list:
            if not isinstance(value, list):
                return False, f"参数 '{self.name}' 必须为列表"
        elif self.param_type == dict:
            if not isinstance(value, dict):
                return False, f"参数 '{self.name}' 必须为字典"

        if self.choices is not None and value not in self.choices:
            return False, f"参数 '{self.name}' 必须为 {self.choices} 之一"

        if self.min_value is not None and value < self.min_value:
            return False, f"参数 '{self.name}' 不能小于 {self.min_value}"
        if self.max_value is not None and value > self.max_value:
            return False, f"参数 '{self.name}' 不能大于 {self.max_value}"

        return True, value

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式以便序列化。

        Returns:
            包含参数定义的字典。
        """
        return {
            "name": self.name,
            "type": self.param_type.__name__,
            "required": self.required,
            "description": self.description,
            "default": self.default,
            "choices": self.choices,
            "min_value": self.min_value,
            "max_value": self.max_value,
            "max_length": self.max_length,
        }


class BaseTool(ABC):
    """工具基类，定义所有工具的标准接口和执行框架。"""

    name: str = "base_tool"
    description: str = "基础工具"
    version: str = "1.0.0"
    category: str = "general"
    tags: List[str] = []
    author: str = "Sapiens AI"
    _HISTORY_LIMIT: int = 100

    def __init__(self) -> None:
        """初始化工具基类。"""
        self.parameters: List[ParameterSchema] = []
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    @abstractmethod
    def _setup_parameters(self) -> None:
        """子类必须实现：注册工具接受的参数。"""
        ...

    def add_parameter(
        self,
        name: str,
        param_type: Type,
        required: bool = True,
        description: str = "",
        default: Any = None,
        **kwargs: Any,
    ) -> None:
        """添加一个参数到工具定义中。

        Args:
            name: 参数名称。
            param_type: 参数类型。
            required: 是否必填。
            description: 参数描述。
            default: 默认值。
            **kwargs: 其他参数选项，如 choices, min_value 等。
        """
        self.parameters.append(
            ParameterSchema(
                name=name,
                param_type=param_type,
                required=required,
                description=description,
                default=default,
                **kwargs,
            )
        )

    def validate_parameters(self, params: Dict[str, Any]) -> Tuple[bool, Any]:
        """验证输入参数字典。

        Args:
            params: 待验证的参数字典。

        Returns:
            元组，包含验证是否成功和验证后的参数字典或错误消息。
        """
        validated: Dict[str, Any] = {}
        errors: List[str] = []
        for schema in self.parameters:
            value = params.get(schema.name, schema.default)
            ok, result = schema.validate(value)
            if not ok:
                errors.append(str(result))
            else:
                validated[schema.name] = result
        if errors:
            return False, "; ".join(errors)
        return True, validated

    @abstractmethod
    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """子类必须实现：核心业务逻辑执行。

        Args:
            **kwargs: 经过验证的参数。

        Returns:
            执行结果字典。
        """
        ...

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """标准执行入口，处理验证、计时、统计和异常捕获。

        Args:
            params: 输入参数字典，可为 None。

        Returns:
            标准化执行结果字典。
        """
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._build_error_response(str(validated), 1002, start_time)

            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start_time, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed)
            return self._build_success_response(result, elapsed)

        except ToolError as e:
            self._stats["fail"] += 1
            return self._build_error_response(e.message, e.code, start_time, e.details)

        except Exception as e:
            self._stats["fail"] += 1
            logger.error("工具 %s 内部错误: %s", self.name, e, exc_info=True)
            return self._build_error_response(
                "工具内部执行异常", 1006, start_time, {"traceback": str(e)}
            )

    def _append_history(self, elapsed: float) -> None:
        """记录执行历史，保持最多100条。

        Args:
            elapsed: 执行耗时（秒）。
        """
        entry: Dict[str, Any] = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "t": elapsed,
        }
        self._history.append(entry)
        if len(self._history) > self._HISTORY_LIMIT:
            self._history.pop(0)

    def _build_success_response(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """构建成功响应。

        Args:
            data: 执行结果数据。
            elapsed: 执行耗时（秒）。

        Returns:
            成功响应字典。
        """
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _build_error_response(
        self,
        msg: str,
        code: int,
        start_time: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """构建错误响应。

        Args:
            msg: 错误消息。
            code: 错误代码。
            start_time: 开始时间戳。
            details: 错误详情字典。

        Returns:
            错误响应字典。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start_time, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取调用统计信息。

        Returns:
            包含调用次数、成功率等统计数据的字典。
        """
        avg: float = (self._stats["time"] / self._stats["ok"]) if self._stats["ok"] > 0 else 0.0
        rate: float = self._stats["ok"] / max(1, self._stats["calls"])
        return {**self._stats, "avg": round(avg, 4), "rate": round(rate, 4)}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的调用历史。

        Args:
            limit: 返回最近多少条记录。

        Returns:
            历史记录列表。
        """
        return self._history[-limit:] if limit > 0 else []

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。

        Returns:
            工具描述符字典，包含元数据和参数定义。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
        }