"""告警管理工具"""

import time
import logging
from typing import Any, Dict, List, Optional, Union
from datetime import datetime, timezone

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class AlertManagerTool(BaseTool):
    """告警管理工具，支持创建、列表、确认、解决、升级、静默、规则、历史等操作。"""

    name: str = "alert_manager"
    description: str = "告警管理工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化告警管理工具。
        
        内部维护告警历史、统计信息和告警字典。
        """
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._alerts: Dict[str, Dict[str, Any]] = {}

    def _setup_parameters(self) -> None:
        """设置工具参数定义。
        
        包括操作类型、告警ID、名称、严重度等。
        """
        self.add_parameter("action", str, required=True, choices=["create", "list", "acknowledge", "resolve", "escalate", "silence", "rules", "history"], description="操作")
        self.add_parameter("alert_id", str, required=False, default="", description="告警ID")
        self.add_parameter("name", str, required=False, default="", description="告警名")
        self.add_parameter("severity", str, required=False, default="warning", choices=["info", "warning", "critical"], description="严重度")
        self.add_parameter("message", str, required=False, default="", description="消息")

    def _create_alert(self, name: str, severity: str, message: str) -> Dict[str, Any]:
        """创建告警。

        Args:
            name: 告警名称。
            severity: 严重度。
            message: 消息。

        Returns:
            创建结果字典。

        Raises:
            ToolError: 名称为空时抛出。
        """
        if not name:
            raise ToolError("需要name", code=1002)
        alert_id = "ALERT-" + str(len(self._alerts) + 1).zfill(4)
        alert = {
            "id": alert_id,
            "name": name,
            "severity": severity,
            "message": message,
            "status": "firing",
            "created": time.time(),
        }
        self._alerts[alert_id] = alert
        return {"created": alert, "id": alert_id}

    def _list_alerts(self) -> Dict[str, Any]:
        """列出告警。

        Returns:
            告警列表字典。
        """
        return {"alerts": list(self._alerts.values()), "count": len(self._alerts)}

    def _acknowledge_alert(self, alert_id: str) -> Dict[str, str]:
        """确认告警。

        Args:
            alert_id: 告警ID。

        Returns:
            确认结果字典。
        """
        if alert_id in self._alerts:
            self._alerts[alert_id]["status"] = "acknowledged"
        return {"acknowledged": alert_id}

    def _resolve_alert(self, alert_id: str) -> Dict[str, str]:
        """解决告警。

        Args:
            alert_id: 告警ID。

        Returns:
            解决结果字典。
        """
        if alert_id in self._alerts:
            self._alerts[alert_id]["status"] = "resolved"
            self._alerts[alert_id]["resolved_at"] = time.time()
        return {"resolved": alert_id}

    def _escalate_alert(self, alert_id: str) -> Dict[str, str]:
        """升级告警。

        Args:
            alert_id: 告警ID。

        Returns:
            升级结果字典。
        """
        if alert_id in self._alerts:
            self._alerts[alert_id]["severity"] = "critical"
        return {"escalated": alert_id, "severity": "critical"}

    def _silence(self) -> Dict[str, str]:
        """静默告警。

        Returns:
            静默结果字典。
        """
        return {"silenced": True, "duration": "1h"}

    def _get_rules(self) -> Dict[str, Any]:
        """获取告警规则。

        Returns:
            规则列表字典。
        """
        return {
            "rules": [
                {"name": "HighCPU", "condition": "cpu > 80", "severity": "warning"},
                {"name": "DiskFull", "condition": "disk > 90", "severity": "critical"},
            ],
            "count": 2,
        }

    def _get_history(self) -> Dict[str, Any]:
        """获取告警历史。

        Returns:
            历史列表字典。
        """
        return {"history": list(self._alerts.values()), "total": len(self._alerts)}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行告警管理操作。

        Args:
            **kwargs: 包含以下可选键:
                - action (str): 操作类型
                - alert_id (str): 告警ID
                - name (str): 告警名
                - severity (str): 严重度
                - message (str): 消息

        Returns:
            dict: 根据操作类型返回相应的结果字典

        Raises:
            ToolError: 当操作未知或参数缺失时抛出
        """
        action = kwargs.get("action", "")
        handlers = {
            "create": lambda: self._create_alert(kwargs.get("name", ""), kwargs.get("severity", "warning"), kwargs.get("message", "")),
            "list": self._list_alerts,
            "acknowledge": lambda: self._acknowledge_alert(kwargs.get("alert_id", "")),
            "resolve": lambda: self._resolve_alert(kwargs.get("alert_id", "")),
            "escalate": lambda: self._escalate_alert(kwargs.get("alert_id", "")),
            "silence": self._silence,
            "rules": self._get_rules,
            "history": self._get_history,
        }
        handler = handlers.get(action)
        if handler is None:
            raise ToolError("未知操作: " + action, code=1002)
        return handler()

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具的主入口。

        Args:
            params: 参数字典

        Returns:
            dict: 包含执行结果、状态、错误信息等
        """
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(v, 1002, start)
            result = self.execute(**v)
            el = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += el
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": el})
            if len(self._history) > 100:
                self._history.pop(0)
            return {"success": True, "data": result, "error": None, "execution_time": el, "tool": self.name, "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()}
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _err(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """生成错误响应。

        Args:
            msg: 错误消息
            code: 错误码
            start: 开始时间
            details: 错误详情

        Returns:
            dict: 错误响应
        """
        return {"success": False, "data": None, "error": msg, "error_code": code, "error_details": details or {}, "execution_time": round(time.monotonic() - start, 4), "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat()}

    def get_stats(self) -> Dict[str, Any]:
        """获取工具统计数据。

        Returns:
            dict: 包含调用次数、成功次数、失败次数、平均时间等
        """
        avg = self._stats["time"] / self._stats["ok"] if self._stats["ok"] > 0 else 0
        return {**self._stats, "avg": round(avg, 4), "rate": round(self._stats["ok"] / max(1, self._stats["calls"]), 4)}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取执行历史。

        Args:
            limit: 返回最近多少条记录

        Returns:
            list: 历史记录列表
        """
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。

        Returns:
            dict: 工具元数据
        """
        return {"name": self.name, "description": self.description, "version": self.version, "category": self.category, "tags": self.tags, "parameters": [p.to_dict() for p in self.parameters], "stats": self.get_stats()}
