"""Docker管理工具模块。

提供容器生命周期管理、镜像管理、日志查看等功能的统一接口。
"""

from __future__ import annotations

import json
import logging
import subprocess
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")

# 常量定义
HISTORY_LIMIT: int = 100
ERROR_CODE_INVALID_ACTION: int = 1002
ERROR_CODE_NOT_FOUND: int = 1005
ERROR_CODE_INTERNAL_ERROR: int = 1006
DEFAULT_CONTAINER_NAME: str = ""
DEFAULT_IMAGE_NAME: str = "app:latest"
DEFAULT_COMMAND: str = ""
VALID_ACTIONS: Tuple[str, ...] = ("ps", "images", "run", "stop", "remove", "logs", "build", "pull", "push", "inspect", "stats", "prune")
DEFAULT_TIMEOUT: int = 30
DEFAULT_LONG_TIMEOUT: int = 300
LOG_TAIL_LINES: int = 50
MAX_OUTPUT_LENGTH: int = 5000
MAX_ERROR_LENGTH: int = 500
MAX_INSPECT_LENGTH: int = 2000


class DockerManagerTool(BaseTool):
    """Docker 管理工具，提供容器生命周期管理、镜像管理、日志查看等功能的统一接口。"""

    name: str = "docker_manager"
    description: str = "Docker管理工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化 DockerManagerTool 实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """配置工具参数。"""
        self.add_parameter("action", str, required=True, choices=list(VALID_ACTIONS), description="操作")
        self.add_parameter("container", str, required=False, default=DEFAULT_CONTAINER_NAME, description="容器名/ID")
        self.add_parameter("image", str, required=False, default="", description="镜像名")
        self.add_parameter("command", str, required=False, default=DEFAULT_COMMAND, description="命令")

    def _run_docker_command(self, args: Tuple[str, ...], timeout: int = DEFAULT_TIMEOUT) -> Tuple[str, str, int]:
        """执行 docker 命令行。

        Args:
            args: 命令行参数元组。
            timeout: 超时时间（秒）。

        Returns:
            (stdout, stderr, returncode) 三元组。

        Raises:
            ToolError: 当命令执行失败时抛出。
        """
        cmd: List[str] = ["docker"] + list(args)
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
            return result.stdout.strip(), result.stderr.strip(), result.returncode
        except subprocess.TimeoutExpired as e:
            raise ToolError(f"Docker命令超时: {e}", code=ERROR_CODE_INTERNAL_ERROR)
        except FileNotFoundError:
            raise ToolError("未找到docker命令，请确保已安装", code=ERROR_CODE_INTERNAL_ERROR)
        except Exception as e:
            raise ToolError(f"Docker命令执行异常: {e}", code=ERROR_CODE_INTERNAL_ERROR)

    def _validate_action_params(self, action: str, container: str, image: str, command: str) -> None:
        """
        验证操作参数的有效性。

        Args:
            action: 操作类型。
            container: 容器名/ID。
            image: 镜像名。
            command: 命令。

        Raises:
            ToolError: 当参数无效时抛出。
        """
        if action == "run" and not image:
            raise ToolError("需要 image 参数", code=ERROR_CODE_INVALID_ACTION)
        if action in ("stop", "remove", "logs", "inspect", "push") and not container:
            raise ToolError(f"操作 {action} 需要 container 参数", code=ERROR_CODE_INVALID_ACTION)
        if action == "pull" and not image:
            raise ToolError("需要 image 参数", code=ERROR_CODE_INVALID_ACTION)

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行 Docker 操作。

        Args:
            **kwargs: 包含action, container, image, command等参数。

        Returns:
            操作结果字典。

        Raises:
            ToolError: 当操作未知时抛出。
        """
        action: str = kwargs.get("action", "")
        container: str = kwargs.get("container", DEFAULT_CONTAINER_NAME)
        image: str = kwargs.get("image", "")
        command: str = kwargs.get("command", DEFAULT_COMMAND)

        self._validate_action_params(action, container, image, command)

        dispatch: Dict[str, Any] = {
            "ps": self._handle_ps,
            "images": self._handle_images,
            "run": lambda: self._handle_run(kwargs),
            "stop": lambda: self._handle_stop(kwargs),
            "remove": lambda: self._handle_remove(kwargs),
            "logs": lambda: self._handle_logs(kwargs),
            "build": lambda: self._handle_build(kwargs),
            "pull": lambda: self._handle_pull(kwargs),
            "inspect": lambda: self._handle_inspect(kwargs),
            "stats": self._handle_stats,
            "prune": self._handle_prune,
        }
        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=ERROR_CODE_INVALID_ACTION, details={"unknown_action": action})
        return handler()

    def _handle_ps(self) -> Dict[str, Any]:
        """处理列出容器操作。

        Returns:
            容器列表字典。
        """
        out, err, rc = self._run_docker_command(("ps", "--format", "{{.ID}} {{.Image}} {{.Status}} {{.Names}}"))
        if rc != 0:
            logger.warning(f"列出容器失败: {err}")
        containers: List[Dict[str, str]] = []
        for line in out.split("\n"):
            if line.strip():
                parts = line.split()
                if len(parts) >= 4:
                    containers.append({"id": parts[0], "image": parts[1], "status": " ".join(parts[2:-1]), "name": parts[-1]})
        return {"containers": containers, "count": len(containers)}

    def _handle_images(self) -> Dict[str, Any]:
        """处理列出镜像操作。

        Returns:
            镜像列表字典。
        """
        out, err, rc = self._run_docker_command(("images", "--format", "{{.Repository}}:{{.Tag}} {{.Size}} {{.ID}}"))
        if rc != 0:
            logger.warning(f"列出镜像失败: {err}")
        images: List[Dict[str, str]] = []
        for line in out.split("\n"):
            if line.strip():
                parts = line.split()
                if len(parts) >= 3:
                    images.append({"name": parts[0], "size": parts[1], "id": parts[2]})
        return {"images": images, "count": len(images)}

    def _handle_run(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理启动容器操作。

        Args:
            kwargs: 参数字典。

        Returns:
            启动结果字典。
        """
        image: str = kwargs.get("image", "")
        cmd: List[str] = ["docker", "run", "-d"]
        name: str = kwargs.get("container", "")
        if name:
            cmd.extend(["--name", name])
        cmd.append(image)
        command: str = kwargs.get("command", "")
        if command:
            cmd.extend(command.split())
        out, err, rc = self._run_docker_command(tuple(cmd), timeout=60)
        return {"started": rc == 0, "container_id": out[:12], "image": image, "error": err if rc != 0 else None}

    def _handle_stop(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理停止容器操作。

        Args:
            kwargs: 参数字典。

        Returns:
            停止结果字典。
        """
        container: str = kwargs.get("container", "")
        out, err, rc = self._run_docker_command(("stop", container))
        return {"stopped": rc == 0, "container": container, "error": err if rc != 0 else None}

    def _handle_remove(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理删除容器操作。

        Args:
            kwargs: 参数字典。

        Returns:
            删除结果字典。
        """
        container: str = kwargs.get("container", "")
        out, err, rc = self._run_docker_command(("rm", "-f", container))
        return {"removed": rc == 0, "container": container, "error": err if rc != 0 else None}

    def _handle_logs(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理查看日志操作。

        Args:
            kwargs: 参数字典。

        Returns:
            日志内容字典。
        """
        container: str = kwargs.get("container", "")
        out, err, rc = self._run_docker_command(("logs", "--tail", str(LOG_TAIL_LINES), container))
        if rc != 0:
            logger.warning(f"获取日志失败: {err}")
        return {"logs": out[:MAX_OUTPUT_LENGTH], "container": container, "error": err if rc != 0 else None}

    def _handle_build(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理构建镜像操作。

        Args:
            kwargs: 参数字典。

        Returns:
            构建结果字典。
        """
        image: str = kwargs.get("image", DEFAULT_IMAGE_NAME)
        out, err, rc = self._run_docker_command(("build", "-t", image, "."), timeout=DEFAULT_LONG_TIMEOUT)
        return {"built": rc == 0, "output": out[:MAX_ERROR_LENGTH], "error": err[:MAX_ERROR_LENGTH] if err else None}

    def _handle_pull(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理拉取镜像操作。

        Args:
            kwargs: 参数字典。

        Returns:
            拉取结果字典。
        """
        image: str = kwargs.get("image", "")
        out, err, rc = self._run_docker_command(("pull", image), timeout=DEFAULT_LONG_TIMEOUT)
        return {"pulled": rc == 0, "image": image, "error": err[:MAX_ERROR_LENGTH] if err else None}

    def _handle_inspect(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理检查对象操作。

        Args:
            kwargs: 参数字典。

        Returns:
            检查信息字典。
        """
        container: str = kwargs.get("container", "")
        out, err, rc = self._run_docker_command(("inspect", container))
        if rc != 0:
            return {"inspect": None, "error": err, "container": container}
        try:
            parsed = json.loads(out) if out else {}
            if isinstance(parsed, list) and parsed:
                return {"inspect": parsed[0], "container": container}
            elif isinstance(parsed, dict):
                return {"inspect": parsed, "container": container}
        except (json.JSONDecodeError, TypeError, ValueError):
            pass
        return {"inspect": out[:MAX_INSPECT_LENGTH], "container": container}

    def _handle_stats(self) -> Dict[str, Any]:
        """处理获取统计信息操作。

        Returns:
            统计信息字典。
        """
        out, err, rc = self._run_docker_command(("stats", "--no-stream", "--format", "{{.Name}} {{.CPUPerc}} {{.MemUsage}}"))
        if rc != 0:
            logger.warning(f"获取统计信息失败: {err}")
        stats: List[Dict[str, str]] = []
        for line in out.split("\n"):
            if line.strip():
                parts = line.split()
                if len(parts) >= 3:
                    stats.append({"name": parts[0], "cpu": parts[1], "memory": parts[2]})
        return {"stats": stats, "count": len(stats)}

    def _handle_prune(self) -> Dict[str, Any]:
        """处理清理无用资源操作。

        Returns:
            清理结果字典。
        """
        out, err, rc = self._run_docker_command(("system", "prune", "-f"))
        return {"pruned": rc == 0, "output": out[:MAX_ERROR_LENGTH], "error": err[:MAX_ERROR_LENGTH] if err else None}

    def _build_result(self, success: bool, data: Optional[Dict[str, Any]], error: Optional[str], code: Optional[int], elapsed: float) -> Dict[str, Any]:
        """构建标准化结果字典。

        Args:
            success: 是否成功。
            data: 成功时的数据。
            error: 错误消息。
            code: 错误代码。
            elapsed: 执行耗时。

        Returns:
            标准化结果字典。
        """
        return {
            "success": success,
            "data": data,
            "error": error,
            "error_code": code,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具调用。

        Args:
            params: 参数字典，可为None。

        Returns:
            标准化结果字典。
        """
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._build_result(False, None, str(validated), ERROR_CODE_INVALID_ACTION, 0.0)
            result = self.execute(**validated)
            elapsed = round(time.monotonic() - start_time, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
            if len(self._history) > HISTORY_LIMIT:
                self._history.pop(0)
            return self._build_result(True, result, None, None, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            elapsed = round(time.monotonic() - start_time, 4)
            return self._build_result(False, None, e.message, e.code, elapsed)
        except Exception as e:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            elapsed = round(time.monotonic() - start_time, 4)
            return self._build_result(False, None, "工具内部错误", ERROR_CODE_INTERNAL_ERROR, elapsed)
