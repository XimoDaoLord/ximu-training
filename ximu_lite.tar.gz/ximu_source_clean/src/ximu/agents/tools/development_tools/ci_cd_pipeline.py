"""
CI/CD 流水线工具。

用于模拟或执行构建、测试和部署等持续集成/持续交付操作。
"""

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class CiCdPipelineTool(BaseTool):
    """CI/CD 流水线工具。

    支持的操作：build（构建）、test（测试）、deploy（部署）。
    """

    name: str = "ci_cd_pipeline"
    description: str = "CI/CD流水线工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "ci-cd", "devops"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化 CI/CD 流水线工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {
            "calls": 0, "ok": 0, "fail": 0, "time": 0.0,
        }

    def _setup_parameters(self) -> None:
        """注册工具参数。"""
        self.add_parameter(
            "action", str, required=True,
            choices=["build", "test", "deploy"],
            description="操作类型（build / test / deploy）",
        )
        self.add_parameter("branch", str, required=False, default="main", description="Git 分支")

    # ── 业务操作 ───────────────────────────────────────────────────────

    def _build(self, branch: str) -> Dict[str, Any]:
        """模拟构建操作。

        Args:
            branch: Git 分支名。

        Returns:
            包含 status、message、build_id、branch、timestamp 的结果字典。
        """
        return {
            "status": "success",
            "message": "构建成功",
            "data": {
                "build_id": f"build-{int(time.time())}",
                "branch": branch,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        }

    def _test(self, branch: str) -> Dict[str, Any]:
        """模拟测试操作。

        Args:
            branch: Git 分支名。

        Returns:
            包含 status、message、test_id、branch、tests_passed、tests_failed 的结果字典。
        """
        return {
            "status": "success",
            "message": "所有测试通过",
            "data": {
                "test_id": f"test-{int(time.time())}",
                "branch": branch,
                "tests_passed": 10,
                "tests_failed": 0,
            },
        }

    def _deploy(self, branch: str) -> Dict[str, Any]:
        """模拟部署操作。

        Args:
            branch: Git 分支名。

        Returns:
            包含 status、message、deployment_id、branch、environment 的结果字典。
        """
        return {
            "status": "success",
            "message": "部署成功",
            "data": {
                "deployment_id": f"deploy-{int(time.time())}",
                "branch": branch,
                "environment": "production",
            },
        }

    # ── 执行入口 ───────────────────────────────────────────────────────

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """根据 action 分发并执行对应的 CI/CD 操作。

        Args:
            **kwargs: 包含 action、branch 等参数。

        Returns:
            操作结果字典。

        Raises:
            ToolError: 当 action 不支持时抛出。
        """
        action: str = kwargs.get("action", "")
        branch: str = kwargs.get("branch", "main")
        handlers: Dict[str, Any] = {
            "build":  lambda: self._build(branch),
            "test":   lambda: self._test(branch),
            "deploy": lambda: self._deploy(branch),
        }
        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"不支持的操作: {action}", code=1002)
        return handler()

    # ── run / _err 公共骨架 ───────────────────────────────────────────

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具，包含参数校验、错误处理和统计记录。

        Args:
            params: 输入参数字典，为 None 时视为空字典。

        Returns:
            包含 success、data、error 等字段的统一响应字典。
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(v), 1002, start)
            result: Dict[str, Any] = self.execute(**v)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(True, elapsed)
            return self._ok_resp(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _err(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构造错误响应字典。

        Args:
            msg: 错误消息。
            code: 错误代码。
            start: 操作开始时间戳（monotonic）。
            details: 错误详细信息，默认为空字典。

        Returns:
            统一格式的错误响应字典。
        """
        return {
            "success": False, "data": None, "error": msg,
            "error_code": code, "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _ok_resp(self, data: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """构造成功响应字典。

        Args:
            data: 业务数据字典。
            elapsed: 执行耗时（秒）。

        Returns:
            统一格式的成功响应字典。
        """
        return {
            "success": True, "data": data, "error": None,
            "execution_time": elapsed, "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, ok: bool, elapsed: float) -> None:
        """追加历史记录，超出 100 条时淘汰最旧的一条。

        Args:
            ok: 是否成功。
            elapsed: 执行耗时（秒）。
        """
        self._history.append({
            "ts": datetime.now(timezone.utc).isoformat(),
            "ok": ok, "t": elapsed,
        })
        if len(self._history) > 100:
            self._history.pop(0)

    # ── 统计与描述 ─────────────────────────────────────────────────────

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取工具调用统计信息。

        Returns:
            包含 calls、ok、fail、time、avg、rate 的字典。
        """
        ok: int = self._stats["ok"]
        avg: float = self._stats["time"] / ok if ok > 0 else 0.0
        rate: float = round(ok / max(1, self._stats["calls"]), 4)
        return {**self._stats, "avg": round(avg, 4), "rate": rate}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的操作历史记录。

        Args:
            limit: 返回记录的最大条数，默认 10。

        Returns:
            最近 limit 条历史记录的列表。
        """
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具的完整描述符。

        Returns:
            包含名称、描述、版本、类别、标签、参数和统计信息的字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }

    def __repr__(self) -> str:
        """返回工具的可读表示字符串。"""
        return f"<{type(self).__name__} name={self.name} v{self.version}>"