"""Kubernetes管理工具"""

import json
import subprocess
import time
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.agents.tools.base import BaseTool, ToolError


class K8sManagerTool(BaseTool):
    """K8s管理工具类，提供kubectl命令的封装执行与资源查询功能。"""

    name: str = "k8s_manager"
    description: str = "Kubernetes管理工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops"]
    author: str = "汐沫AI"
    _TIMEOUT: int = 30

    def __init__(self) -> None:
        """初始化工具实例。"""
        super().__init__()
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """配置工具参数。"""
        self.add_parameter("action", str, required=True, choices=["get", "create", "delete", "apply", "logs", "exec", "describe", "scale", "rollout", "namespaces"], description="kubectl操作类型")
        self.add_parameter("resource", str, required=False, default="pods", description="资源类型")
        self.add_parameter("name", str, required=False, default="", description="资源名称")
        self.add_parameter("namespace", str, required=False, default="default", description="命名空间")
        self.add_parameter("replicas", int, required=False, default=1, description="副本数量")

    def _run_kubectl(self, *args: str) -> Tuple[str, str, int]:
        """执行kubectl命令。"""
        try:
            result = subprocess.run(["kubectl"] + list(args), capture_output=True, text=True, timeout=self._TIMEOUT)
            return result.stdout.strip(), result.stderr.strip(), result.returncode
        except subprocess.TimeoutExpired:
            return "", "命令执行超时", 1
        except FileNotFoundError:
            return "", "kubectl命令未找到", 1

    def _parse_json(self, output: str) -> Dict[str, Any]:
        """解析JSON输出。"""
        try:
            data = json.loads(output)
            return {"data": data, "output": output[:1000]}
        except (json.JSONDecodeError, ValueError):
            return {"output": output[:1000], "error": "JSON解析失败"}

    def _build_items(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """构建资源列表摘要。"""
        items = [{"name": item.get("metadata", {}).get("name", ""), "status": item.get("status", {}).get("phase", "")} for item in data.get("items", [])]
        return {"items": items, "count": len(items)}

    def _handle_get(self, resource: str, namespace: str) -> Dict[str, Any]:
        """处理get操作。"""
        out, err, rc = self._run_kubectl("get", resource, "-n", namespace, "-o", "json")
        if rc != 0:
            return {"error": err}
        parsed = self._parse_json(out)
        if "data" in parsed:
            return self._build_items(parsed["data"])
        return parsed

    def _handle_create(self, resource: str, name: str, namespace: str) -> Dict[str, Any]:
        """处理create操作。"""
        out, err, rc = self._run_kubectl("create", resource, name, "--image=nginx", "-n", namespace)
        return {"created": rc == 0, "error": err if rc != 0 else None}

    def _handle_delete(self, resource: str, name: str, namespace: str) -> Dict[str, Any]:
        """处理delete操作。"""
        out, err, rc = self._run_kubectl("delete", resource, name, "-n", namespace)
        return {"deleted": rc == 0, "error": err if rc != 0 else None}

    def _handle_scale(self, name: str, replicas: int, namespace: str) -> Dict[str, Any]:
        """处理scale操作。"""
        out, err, rc = self._run_kubectl("scale", "deployment", name, f"--replicas={replicas}", "-n", namespace)
        return {"scaled": rc == 0, "replicas": replicas, "error": err if rc != 0 else None}

    def _handle_logs(self, name: str, namespace: str) -> Dict[str, Any]:
        """处理logs操作。"""
        out, err, rc = self._run_kubectl("logs", name, "-n", namespace, "--tail=50")
        return {"logs": out[:5000], "error": err if rc != 0 else None}

    def _handle_namespaces(self) -> Dict[str, Any]:
        """处理namespaces操作。"""
        out, err, rc = self._run_kubectl("get", "ns", "-o", "json")
        if rc != 0:
            return {"error": err}
        parsed = self._parse_json(out)
        if "data" in parsed:
            namespaces_list = [item.get("metadata", {}).get("name", "") for item in parsed["data"].get("items", [])]
            return {"namespaces": namespaces_list, "count": len(namespaces_list)}
        return parsed

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行Kubernetes操作。"""
        action: str = kwargs.get("action", "")
        namespace: str = kwargs.get("namespace", "default")
        resource: str = kwargs.get("resource", "pods")
        name: str = kwargs.get("name", "")
        replicas: int = kwargs.get("replicas", 1)

        handlers = {
            "get": lambda: self._handle_get(resource, namespace),
            "create": lambda: self._handle_create(resource, name, namespace),
            "delete": lambda: self._handle_delete(resource, name, namespace),
            "scale": lambda: self._handle_scale(name, replicas, namespace),
            "logs": lambda: self._handle_logs(name, namespace),
            "namespaces": lambda: self._handle_namespaces(),
        }

        if action in handlers:
            return handlers[action]()
        elif action in ("describe", "exec", "apply", "rollout"):
            return {"note": f"{action} 操作返回占位结果", "action": action}
        else:
            raise ToolError(f"未知操作: {action}", code=1002)

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具并统计执行指标。"""
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return {"success": False, "error": str(validated), "code": 1002}
            result = self.execute(**validated)
            elapsed = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            return {"success": True, "data": result, "elapsed_ms": elapsed * 1000}
        except ToolError as e:
            self._stats["fail"] += 1
            return {"success": False, "error": str(e), "code": e.code}
        except Exception as e:
            self._stats["fail"] += 1
            return {"success": False, "error": str(e), "code": 500}
