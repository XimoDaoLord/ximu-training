from __future__ import annotations

import json
import logging
import subprocess
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger: logging.Logger = logging.getLogger("ximu.terraform")


class TerraformManagerTool(BaseTool):
    """Terraform 管理工具，支持 init、plan、apply、destroy、validate、fmt、show、output 等操作。"""

    name: str = "terraform_manager"
    description: str = "Terraform管理工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化 TerraformManagerTool 实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Any] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数定义。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=["init", "plan", "apply", "destroy", "validate", "fmt", "show", "output"],
            description="Terraform 操作类型",
        )
        self.add_parameter("directory", str, required=False, default=".", description="Terraform 工作目录")
        self.add_parameter("auto_approve", bool, required=False, default=False, description="是否自动确认破坏性操作")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行指定的 Terraform 操作。"""
        action = kwargs.get("action", "")
        directory = kwargs.get("directory", ".")
        auto_approve = kwargs.get("auto_approve", False)

        if not action:
            raise ToolError("缺少必需的操作参数 'action'", code=1001)

        valid_actions = {"init", "plan", "apply", "destroy", "validate", "fmt", "show", "output"}
        if action not in valid_actions:
            raise ToolError(f"未知操作: {action}", code=1002)

        handlers: Dict[str, Any] = {
            "init": lambda: self._handle_init(directory),
            "plan": lambda: self._handle_plan(directory),
            "apply": lambda: self._handle_apply(directory, auto_approve),
            "destroy": lambda: self._handle_destroy(directory, auto_approve),
            "validate": lambda: self._handle_validate(directory),
            "fmt": lambda: self._handle_fmt(directory),
            "show": lambda: self._handle_show(directory),
            "output": lambda: self._handle_output(directory),
        }
        return handlers[action]()

    def _run_terraform(self, directory: str, *args: str, timeout: int = 60) -> Tuple[str, str, int]:
        """执行 terraform 命令。"""
        command = ["terraform", f"-chdir={directory}"] + list(args)
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
            return result.stdout.strip(), result.stderr.strip(), result.returncode
        except FileNotFoundError:
            raise ToolError("未找到 terraform 命令，请确保已安装并添加到 PATH", code=1003)
        except subprocess.TimeoutExpired:
            raise ToolError(f"Terraform 命令执行超时（{timeout}秒）", code=1004)
        except OSError as e:
            raise ToolError(f"操作系统错误: {e}", code=1005)

    def _handle_init(self, directory: str) -> Dict[str, Any]:
        """处理初始化操作。"""
        out, err, rc = self._run_terraform(directory, "init")
        return {"initialized": rc == 0, "output": out[:500], "error": err[:500] if err else None}

    def _handle_plan(self, directory: str) -> Dict[str, Any]:
        """处理计划操作。"""
        out, err, rc = self._run_terraform(directory, "plan")
        changes = "to add: 0, to change: 0, to destroy: 0"
        for line in out.splitlines():
            if "to add:" in line:
                changes = line.strip()
                break
        return {"planned": rc == 0, "output": out[:1000], "changes": changes, "error": err[:500] if err else None}

    def _handle_apply(self, directory: str, auto_approve: bool) -> Dict[str, Any]:
        """处理应用操作。"""
        args = ["apply"]
        if auto_approve:
            args.append("-auto-approve")
        out, err, rc = self._run_terraform(directory, *args)
        return {"applied": rc == 0, "output": out[:1000], "error": err[:500] if err else None}

    def _handle_destroy(self, directory: str, auto_approve: bool) -> Dict[str, Any]:
        """处理销毁操作。"""
        args = ["destroy"]
        if auto_approve:
            args.append("-auto-approve")
        out, err, rc = self._run_terraform(directory, *args)
        return {"destroyed": rc == 0, "output": out[:1000], "error": err[:500] if err else None}

    def _handle_validate(self, directory: str) -> Dict[str, Any]:
        """处理验证操作。"""
        out, err, rc = self._run_terraform(directory, "validate")
        return {"valid": rc == 0, "output": out[:500], "error": err[:500] if err else None}

    def _handle_fmt(self, directory: str) -> Dict[str, Any]:
        """处理格式化操作。"""
        out, err, rc = self._run_terraform(directory, "fmt")
        return {"formatted": rc == 0, "output": out[:500], "error": err[:500] if err else None}

    def _handle_show(self, directory: str) -> Dict[str, Any]:
        """处理展示操作。"""
        out, err, rc = self._run_terraform(directory, "show")
        return {"state": out[:2000], "error": err[:500] if err else None}

    def _handle_output(self, directory: str) -> Dict[str, Any]:
        """处理输出操作。"""
        out, err, rc = self._run_terraform(directory, "output", "-json")
        outputs: Union[str, Dict[str, Any]] = out[:1000]
        if out:
            try:
                outputs = json.loads(out)
            except json.JSONDecodeError:
                pass
        return {"outputs": outputs, "error": err[:500] if err else None}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行 Terraform 工具，包含参数验证、统计和历史记录。"""
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated_params = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._create_error_response(str(validated_params), 1002, start_time)
            result = self.execute(**validated_params)
            elapsed: float = round(time.monotonic() - start_time, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._record_history(elapsed, True)
            return {"success": True, "data": result, "error": None, "execution_time": elapsed,
                    "tool": self.name, "version": self.version,
                    "timestamp": datetime.now(timezone.utc).isoformat()}
        except ToolError as e:
            self._stats["fail"] += 1
            return self._create_error_response(e.message, e.code, start_time, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._create_error_response("工具内部错误", 1006, start_time)

    def _record_history(self, elapsed: float, success: bool) -> None:
        """记录操作历史。"""
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": success, "t": elapsed})
        if len(self._history) > 100:
            self._history.pop(0)

    def _create_error_response(self, msg: str, code: int, start_time: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构造错误响应。"""
        return {"success": False, "data": None, "error": msg, "error_code": code,
                "execution_time": round(time.monotonic() - start_time, 4), "details": details or {},
                "tool": self.name, "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()}
