"""
Ansible自动化工具，支持Playbook运行、Ad-hoc命令及库存管理。
"""
from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from src.ximu.agents.tools.base import BaseTool, ToolError

logger: logging.Logger = logging.getLogger("ximu.tool")


class AnsibleRunnerTool(BaseTool):
    """Ansible自动化工具，支持Playbook运行、Ad-hoc命令及库存管理。

    该工具模拟Ansible的核心功能，包括Playbook执行、主机发现、
    事实收集和安全加密操作。
    """

    name: str = "ansible_runner"
    description: str = "Ansible自动化工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "automation"]
    author: str = "汐沫AI"
    _VALID_ACTIONS: List[str] = ["run_playbook", "adhoc", "inventory", "facts", "vault", "galaxy"]

    def __init__(self) -> None:
        """初始化Ansible运行工具。

        设置Playbook日志容器和工具参数定义。
        """
        super().__init__()
        self._playbook_log: List[Dict[str, Any]] = []
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Any] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数定义。

        添加操作类型、Playbook路径、库存文件、目标主机、模块和额外参数。
        """
        self.add_parameter("action", str, required=True, choices=self._VALID_ACTIONS, description="操作类型")
        self.add_parameter("playbook", str, required=False, default="", description="Playbook路径")
        self.add_parameter("inventory", str, required=False, default="hosts", description="Inventory文件")
        self.add_parameter("host", str, required=False, default="all", description="目标主机")
        self.add_parameter("module", str, required=False, default="ping", description="模块名")
        self.add_parameter("args", str, required=False, default="", description="额外参数")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行Ansible操作。

        Args:
            **kwargs: 包含action及相关参数的字典。

        Returns:
            操作结果字典。

        Raises:
            ToolError: 当操作未知时抛出。
        """
        action: str = kwargs.get("action", "")
        dispatch: Dict[str, Any] = {
            "run_playbook": lambda: self._run_playbook(kwargs),
            "adhoc": lambda: self._adhoc(kwargs),
            "inventory": lambda: self._show_inventory(kwargs),
            "facts": lambda: self._gather_facts(kwargs),
            "vault": self._vault_action,
            "galaxy": lambda: self._galaxy_action(kwargs),
        }
        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _run_playbook(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """运行指定Playbook。

        Args:
            kwargs: 包含playbook和inventory参数的字典。

        Returns:
            Playbook执行结果字典。

        Raises:
            ToolError: 当playbook参数为空时抛出。
        """
        playbook: str = kwargs.get("playbook", "")
        inventory: str = kwargs.get("inventory", "hosts")
        if not playbook:
            raise ToolError("需要playbook参数", code=1002)
        entry: Dict[str, Any] = {
            "playbook": playbook,
            "inventory": inventory,
            "status": "success",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self._playbook_log.append(entry)
        return {"playbook": playbook, "status": "success", "log_entry": entry}

    def _adhoc(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """执行Ad-hoc命令。

        Args:
            kwargs: 包含host、module和args参数的字典。

        Returns:
            Ad-hoc命令执行结果字典。
        """
        host: str = kwargs.get("host", "all")
        module: str = kwargs.get("module", "ping")
        args: str = kwargs.get("args", "")
        return {
            "host": host,
            "module": module,
            "args": args,
            "status": "success",
            "stdout": f"{host}: SUCCESS",
        }

    def _show_inventory(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """显示Inventory信息。

        Args:
            kwargs: 包含inventory参数的字典。

        Returns:
            库存信息字典，包含主机列表和分组。
        """
        inventory: str = kwargs.get("inventory", "hosts")
        return {
            "inventory": inventory,
            "hosts": ["host1", "host2", "host3"],
            "groups": ["webservers", "dbservers"],
        }

    def _gather_facts(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """收集目标主机Facts。

        Args:
            kwargs: 包含host参数的字典。

        Returns:
            主机事实信息字典。
        """
        host: str = kwargs.get("host", "all")
        return {
            "host": host,
            "facts": {"ansible_os": "Linux", "ansible_hostname": host},
            "status": "success",
        }

    def _vault_action(self) -> Dict[str, Any]:
        """执行Vault加密操作。

        Returns:
            Vault操作结果字典。
        """
        return {"vault": "enabled", "status": "success", "message": "Vault操作成功"}

    def _galaxy_action(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """执行Galaxy集合操作。

        Args:
            kwargs: 包含action和playbook参数的字典。

        Returns:
            Galaxy操作结果字典。
        """
        action: str = kwargs.get("action", "list")
        if action == "list":
            return {"collections": ["ansible.builtin", "community.general"], "count": 2}
        if action == "install":
            role: str = kwargs.get("playbook", "")
            return {"installed": role, "status": "success"}
        return {"status": "success"}

    def _success_result(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """构建成功响应字典。

        Args:
            data: 执行结果数据。
            elapsed: 执行耗时（秒）。

        Returns:
            标准成功响应字典。
        """
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _error_result(self, message: str, code: int, start_time: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构建错误响应字典。

        Args:
            message: 错误消息。
            code: 错误代码。
            start_time: 起始时间戳。
            details: 额外详情。

        Returns:
            标准错误响应字典。
        """
        return {
            "success": False,
            "data": None,
            "error": message,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start_time, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, elapsed: float) -> None:
        """追加执行历史并限制长度。

        Args:
            elapsed: 执行耗时（秒）。
        """
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
        if len(self._history) > 100: self._history.pop(0)

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具主入口。

        Args:
            params: 参数字典。

        Returns:
            标准化响应字典。
        """
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._error_result("参数验证失败", 1002, start_time, {"validation": str(validated)})
            result = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start_time, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed)
            return self._success_result(result, elapsed)
        except ToolError as exc:
            self._stats["fail"] += 1
            return self._error_result(exc.message, exc.code, start_time, exc.details)
        except Exception as exc:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._error_result("工具内部错误", 1006, start_time, {"exception": str(exc)})