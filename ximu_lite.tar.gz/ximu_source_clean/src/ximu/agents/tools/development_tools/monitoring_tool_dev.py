"""开发监控工具。"""

from __future__ import annotations

import logging
import os
import sys
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class MonitoringToolDevTool(BaseTool):
    """开发监控工具。"""

    name: str = "monitoring_tool_dev"
    description: str = "开发监控工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "cicd", "monitoring"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化开发监控工具。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {
            "calls": 0,
            "ok": 0,
            "fail": 0,
            "time": 0.0,
        }
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置参数。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=["metrics", "alerts", "dashboard", "trace", "log", "health"],
            description="操作",
        )
        self.add_parameter(
            "service", str, required=False, default="all", description="服务"
        )

    def _metrics(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """获取指标。"""
        return {
            "cpu": 45.2,
            "memory": 62.8,
            "requests_per_min": 1250,
            "error_rate": 0.1,
            "latency_p99_ms": 120,
        }

    def _alerts(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """获取告警。"""
        return {
            "active_alerts": 2,
            "critical": 0,
            "warning": 2,
            "alerts": [{"name": "HighCPU", "severity": "warning"}],
        }

    def _dashboard(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """获取仪表板。"""
        return {"dashboard": {"panels": 8, "refresh": "30s", "time_range": "1h"}}

    def _trace(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """获取追踪。"""
        return {"trace_id": f"trace-{int(time.time())}", "spans": 5, "duration_ms": 230}

    def _log(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """获取日志。"""
        return {"logs": ["INFO: request handled", "WARN: slow query"], "count": 2}

    def _health(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """获取健康检查。"""
        return {"status": "healthy", "services": {"api": "up", "db": "up", "cache": "up"}}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行操作。"""
        action: str = kwargs.get("action", "")
        handlers: Dict[str, Any] = {
            "metrics": lambda: self._metrics(kwargs),
            "alerts": lambda: self._alerts(kwargs),
            "dashboard": lambda: self._dashboard(kwargs),
            "trace": lambda: self._trace(kwargs),
            "log": lambda: self._log(kwargs),
            "health": lambda: self._health(kwargs),
        }
        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具。"""
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(v), 1002, start)
            result: Dict[str, Any] = self.execute(**v)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._history.append(
                {"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed}
            )
            if len(self._history) > 100:
                self._history.pop(0)
            return {
                "success": True,
                "data": result,
                "error": None,
                "execution_time": elapsed,
                "tool": self.name,
                "version": self.version,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception as exc:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _err(
        self,
        msg: str,
        code: int,
        start: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """生成错误响应。"""
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取统计。"""
        ok: int = int(self._stats["ok"])
        calls: int = int(self._stats["calls"])
        avg: float = self._stats["time"] / ok if ok > 0 else 0.0
        rate: float = ok / max(1, calls)
        return {**self._stats, "avg": round(avg, 4), "rate": round(rate, 4)}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取历史记录。"""
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。"""
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }

    def validate_input(self, params: Dict[str, Any]) -> tuple:
        """验证输入参数。"""
        ok, r = self.validate_parameters(params)
        return ok, "" if ok else r

    def __repr__(self) -> str:
        """工具表示。"""
        return f"<MonitoringToolDevTool name={self.name} v{self.version}>"

    def get_metrics(self, service: str = "all") -> Dict[str, Any]:
        """获取指标。"""
        return self.run({"action": "metrics", "service": service})
