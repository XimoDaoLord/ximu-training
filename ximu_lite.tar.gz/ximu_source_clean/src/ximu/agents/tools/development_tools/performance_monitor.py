from datetime import datetime, timezone
import logging
import time
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class PerformanceMonitorTool(BaseTool):
    """
    性能监控工具类。
    
    提供代码性能分析、基准测试、内存、CPU、IO及网络指标的模拟监控。
    """

    name: str = "performance_monitor"
    description: str = "性能监控工具"
    version: str = "2.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"
    
    HISTORY_LIMIT: int = 100

    def __init__(self) -> None:
        """
        初始化性能监控工具。
        """
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """
        注册参数定义。
        """
        self.add_parameter(
            "action", str, required=True,
            choices=["profile", "benchmark", "trace", "memory", "cpu", "io", "network"],
            description="操作类型"
        )
        self.add_parameter("code", str, required=False, default="", description="待分析代码")
        self.add_parameter("duration", int, required=False, default=5, description="监控时长(秒)")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """
        执行性能监控操作。
        
        Args:
            **kwargs: 工具参数。
            
        Returns:
            监控结果字典。
            
        Raises:
            ToolError: 当操作无效时抛出。
        """
        action: str = kwargs.get("action", "")
        code: str = kwargs.get("code", "")
        
        dispatch = {
            "profile": lambda: self._profile(code),
            "benchmark": lambda: self._benchmark(code),
            "trace": lambda: self._trace(),
            "memory": lambda: self._memory_snapshot(),
            "cpu": lambda: self._cpu_snapshot(),
            "io": lambda: self._io_snapshot(),
            "network": lambda: self._network_snapshot(),
        }
        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _profile(self, code: str) -> Dict[str, Any]:
        """
        模拟代码性能分析。
        
        Args:
            code: 代码字符串。
            
        Returns:
            分析结果。
        """
        return {"status": "completed", "code_length": len(code), "estimated_time_ms": 100}

    def _benchmark(self, code: str) -> Dict[str, Any]:
        """
        模拟基准测试。
        
        Args:
            code: 代码字符串。
            
        Returns:
            基准测试结果。
        """
        return {"iterations": 100, "avg_ms": 2.5, "min_ms": 1.2, "max_ms": 5.1}

    def _trace(self) -> Dict[str, Any]:
        """
        获取调用跟踪统计。
        
        Returns:
            统计信息。
        """
        return {
            "calls": self._stats["calls"],
            "ok": self._stats["ok"],
            "fail": self._stats["fail"],
            "total_time_s": round(self._stats["time"], 4)
        }

    def _memory_snapshot(self) -> Dict[str, Any]:
        """
        模拟内存快照。
        
        Returns:
            内存指标。
        """
        return {"used_mb": 1024, "available_mb": 2048, "percent": 33.3}

    def _cpu_snapshot(self) -> Dict[str, Any]:
        """
        模拟CPU快照。
        
        Returns:
            CPU指标。
        """
        return {"percent": 45.5, "load_avg_1m": 1.2, "cores": 4}

    def _io_snapshot(self) -> Dict[str, Any]:
        """
        模拟IO快照。
        
        Returns:
            IO指标。
        """
        return {"read_ops": 100, "write_ops": 50, "total_bytes": 102400}

    def _network_snapshot(self) -> Dict[str, Any]:
        """
        模拟网络快照。
        
        Returns:
            网络指标。
        """
        return {"bytes_rx": 50000, "bytes_tx": 20000, "packets": 500}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        执行工具调用。
        
        Args:
            params: 参数字典。
            
        Returns:
            标准化响应。
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1
        
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._error(str(validated), 1002, start)
            
            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
            if len(self._history) > self.HISTORY_LIMIT:
                self._history.pop(0)
            
            return {
                "success": True,
                "data": result,
                "error": None,
                "execution_time": elapsed,
                "tool": self.name,
                "version": self.version,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
        except ToolError as e:
            self._stats["fail"] += 1
            return self._error(e.message, e.code, start, getattr(e, 'details', None))
        except Exception:
            self._stats["fail"] += 1
            logger.error("PerformanceMonitorTool 内部错误", exc_info=True)
            return self._error("内部错误", 1006, start)

    def _error(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        构建错误响应。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """
        获取统计信息。
        
        Returns:
            统计字典。
        """
        return dict(self._stats)