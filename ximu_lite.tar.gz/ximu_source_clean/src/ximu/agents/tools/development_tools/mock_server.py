"""Mock服务器工具。

模拟开发环境中的API端点，支持路由管理和状态查询。
"""
from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

_logger: logging.Logger = logging.getLogger("ximu.tool")


class MockServerTool(BaseTool):
    """Mock服务器工具实现类。"""

    name: str = "mock_server"
    description: str = "Mock服务器工具，用于模拟开发环境中的API端点"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._routes: Dict[str, Dict[str, Any]] = {}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """配置工具参数定义。"""
        self.add_parameter("action", str, required=True, choices=["start", "stop", "add_route", "remove_route", "list_routes", "status"], description="要执行的操作类型")
        self.add_parameter("port", int, required=False, default=3000, description="服务器监听的端口号")
        self.add_parameter("path", str, required=False, default="/", description="路由路径")
        self.add_parameter("method", str, required=False, default="GET", description="HTTP请求方法")
        self.add_parameter("response", str, required=False, default="{}", description="模拟的响应内容")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行Mock服务器操作。"""
        action = kwargs.get("action", "")
        if not action:
            raise ToolError("缺少必需参数: action", code=1002)
        
        dispatch_map: Dict[str, Any] = {
            "start": lambda: self._handle_start(kwargs),
            "stop": lambda: self._handle_stop(),
            "add_route": lambda: self._handle_add_route(kwargs),
            "remove_route": lambda: self._handle_remove_route(kwargs),
            "list_routes": lambda: self._handle_list_routes(),
            "status": lambda: self._handle_status(kwargs),
        }
        
        handler = dispatch_map.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _handle_start(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理启动操作。"""
        port: int = int(kwargs.get("port", 3000))
        return {"started": True, "port": port, "url": f"http://localhost:{port}", "routes": len(self._routes)}

    def _handle_stop(self) -> Dict[str, Any]:
        """处理停止操作。"""
        return {"stopped": True}

    def _handle_add_route(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理添加路由操作。"""
        path: str = kwargs.get("path", "/")
        method: str = kwargs.get("method", "GET")
        response: str = kwargs.get("response", "{}")
        key: str = f"{method} {path}"
        self._routes[key] = {"path": path, "method": method, "response": response, "status": 200}
        return {"added": key, "total_routes": len(self._routes)}

    def _handle_remove_route(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理移除路由操作。"""
        path: str = kwargs.get("path", "/")
        method: str = kwargs.get("method", "GET")
        key: str = f"{method} {path}"
        existed: bool = key in self._routes
        if existed:
            del self._routes[key]
        return {"removed": key, "existed": existed, "total_routes": len(self._routes)}

    def _handle_list_routes(self) -> Dict[str, Any]:
        """处理列出路由操作。"""
        return {"routes": list(self._routes.values()), "count": len(self._routes)}

    def _handle_status(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理查询状态操作。"""
        port: int = int(kwargs.get("port", 3000))
        return {"running": True, "routes": len(self._routes), "port": port}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具并返回标准化结果。"""
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._create_error_response(str(validated), 1002, start_time)
            
            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start_time, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._record_history(elapsed, True)
            return self._create_success_response(result, elapsed)
        
        except ToolError as e:
            self._stats["fail"] += 1
            return self._create_error_response(e.message, e.code, start_time, e.details)
        except Exception:
            self._stats["fail"] += 1
            _logger.error("工具内部错误", exc_info=True)
            return self._create_error_response("工具内部错误", 1006, start_time)

    def _record_history(self, elapsed: float, success: bool) -> None:
        """记录操作历史。"""
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": success, "t": elapsed})
        if len(self._history) > 100:
            self._history.pop(0)

    def _create_success_response(self, data: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """构造成功响应。"""
        return {
            "success": True, "data": data, "error": None, "execution_time": elapsed,
            "tool": self.name, "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def _create_error_response(self, msg: str, code: int, start_time: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构造错误响应。"""
        return {
            "success": False, "data": None, "error": msg, "error_code": code, "error_details": details or {},
            "execution_time": round(time.monotonic() - start_time, 4), "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat()
        }