"""容器镜像仓库工具模块。

提供镜像管理、推送、拉取、删除、标签查询、安全扫描和配额管理等功能。
"""

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger: logging.Logger = logging.getLogger("ximu.tool")
_MAX_HISTORY_SIZE: int = 100


class ContainerRegistryTool(BaseTool):
    """容器镜像仓库工具类。

    支持镜像的列出、推送、拉取、删除、标签查询、安全扫描和配额管理。
    所有数据为模拟数据，用于接口演示和测试。
    """

    name: str = "container_registry"
    description: str = "容器镜像仓库工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化ContainerRegistryTool实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数定义。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=["list", "push", "pull", "delete", "tags", "scan", "quota"],
            description="操作类型",
        )
        self.add_parameter("image", str, required=False, default="", description="镜像名称")
        self.add_parameter("tag", str, required=False, default="latest", description="镜像标签")
        self.add_parameter("registry", str, required=False, default="docker.io", description="镜像仓库地址")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行具体的仓库操作。

        Args:
            **kwargs: 包含 action、registry、image、tag 等参数。

        Returns:
            操作结果字典。

        Raises:
            ToolError: 当操作未知时抛出。
        """
        action: str = kwargs.get("action", "")
        registry: str = kwargs.get("registry", "docker.io")
        image: str = kwargs.get("image", "")
        tag: str = kwargs.get("tag", "latest")

        handlers: Dict[str, Any] = {
            "list": lambda: self._handle_list(registry=registry, image=image, tag=tag),
            "push": lambda: self._handle_push(registry=registry, image=image, tag=tag),
            "pull": lambda: self._handle_pull(registry=registry, image=image, tag=tag),
            "delete": lambda: self._handle_delete(registry=registry, image=image, tag=tag),
            "tags": lambda: self._handle_tags(registry=registry, image=image, tag=tag),
            "scan": lambda: self._handle_scan(registry=registry, image=image, tag=tag),
            "quota": lambda: self._handle_quota(registry=registry, image=image, tag=tag),
        }

        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _handle_list(self, **kwargs: Any) -> Dict[str, Any]:
        """处理列出镜像操作。

        Args:
            **kwargs: 包含 registry, image, tag 的参数字典。

        Returns:
            镜像列表字典。
        """
        return {
            "images": [
                {"name": "app", "tags": ["latest", "v1.0", "v1.1"], "size": "256MB"},
                {"name": "nginx", "tags": ["latest"], "size": "50MB"},
            ],
            "count": 2,
            "registry": kwargs.get("registry", "docker.io"),
        }

    def _handle_push(self, **kwargs: Any) -> Dict[str, Any]:
        """处理推送镜像操作。

        Args:
            **kwargs: 包含 registry, image, tag 的参数字典。

        Returns:
            推送结果字典。
        """
        return {
            "pushed": True,
            "image": kwargs.get("image", ""),
            "tag": kwargs.get("tag", "latest"),
            "registry": kwargs.get("registry", "docker.io"),
        }

    def _handle_pull(self, **kwargs: Any) -> Dict[str, Any]:
        """处理拉取镜像操作。

        Args:
            **kwargs: 包含 registry, image, tag 的参数字典。

        Returns:
            拉取结果字典。
        """
        return {
            "pulled": True,
            "image": kwargs.get("image", ""),
            "tag": kwargs.get("tag", "latest"),
        }

    def _handle_delete(self, **kwargs: Any) -> Dict[str, Any]:
        """处理删除镜像操作。

        Args:
            **kwargs: 包含 registry, image, tag 的参数字典。

        Returns:
            删除结果字典。
        """
        return {
            "deleted": True,
            "image": kwargs.get("image", ""),
            "tag": kwargs.get("tag", "latest"),
        }

    def _handle_tags(self, **kwargs: Any) -> Dict[str, Any]:
        """处理标签查询操作。

        Args:
            **kwargs: 包含 registry, image, tag 的参数字典。

        Returns:
            标签列表字典。
        """
        return {
            "image": kwargs.get("image", ""),
            "tags": ["latest", "v1.0", "v1.1", "v2.0-beta"],
            "count": 4,
        }

    def _handle_scan(self, **kwargs: Any) -> Dict[str, Any]:
        """处理安全扫描操作。

        Args:
            **kwargs: 包含 registry, image, tag 的参数字典。

        Returns:
            扫描结果字典。
        """
        return {
            "image": kwargs.get("image", ""),
            "vulnerabilities": [
                {"severity": "high", "cve": "CVE-2023-0001", "package": "openssl"}
            ],
            "scan_status": "completed",
            "risk_level": "medium",
        }

    def _handle_quota(self, **kwargs: Any) -> Dict[str, Any]:
        """处理配额查询操作。

        Args:
            **kwargs: 包含 registry, image, tag 的参数字典。

        Returns:
            配额信息字典。
        """
        return {
            "used": "5.2GB",
            "limit": "10GB",
            "images": 15,
            "usage_percent": 52,
        }

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具操作，包含参数验证、执行和统计更新。

        Args:
            params: 参数字典，可为 None。

        Returns:
            标准化结果字典。
        """
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            is_valid, validated_params = self.validate_parameters(params)
            if not is_valid:
                self._stats["fail"] += 1
                return self._build_error_response(str(validated_params), 1002, start_time)

            result: Dict[str, Any] = self.execute(**validated_params)
            elapsed_time: float = round(time.monotonic() - start_time, 4)

            self._stats["ok"] += 1
            self._stats["time"] += elapsed_time
            self._append_history(True, elapsed_time)

            return self._build_success_response(result, elapsed_time)

        except ToolError as e:
            self._stats["fail"] += 1
            return self._build_error_response(e.message, e.code, start_time, e.details)

        except Exception as e:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._build_error_response(f"工具内部错误: {e}", 1006, start_time)

    def _append_history(self, ok: bool, elapsed: float) -> None:
        """追加历史记录。

        Args:
            ok: 执行是否成功。
            elapsed: 执行耗时。
        """
        history_entry: Dict[str, Any] = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "ok": ok,
            "t": elapsed,
        }
        self._history.append(history_entry)
        if len(self._history) > _MAX_HISTORY_SIZE:
            self._history.pop(0)

    def _build_success_response(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """构建成功响应。

        Args:
            data: 执行结果数据。
            elapsed: 执行耗时（秒）。

        Returns:
            标准成功响应字典。
        """
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _build_error_response(self, message: str, code: int, start_time: float,
                               details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构建错误响应。

        Args:
            message: 错误信息。
            code: 错误代码。
            start_time: 开始时间。
            details: 详细信息。

        Returns:
            标准错误响应字典。
        """
        elapsed: float = round(time.monotonic() - start_time, 4)
        return {
            "success": False,
            "data": None,
            "error": message,
            "error_code": code,
            "error_details": details or {},
            "execution_time": elapsed,
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
