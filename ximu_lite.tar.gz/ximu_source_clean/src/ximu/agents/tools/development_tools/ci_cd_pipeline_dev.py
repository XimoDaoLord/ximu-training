import logging
import time
from collections import deque
from datetime import datetime, timezone
from typing import Any, Deque, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class CiCdPipelineDevTool(BaseTool):
    """CI/CD流水线工具，模拟run、status、deploy等操作。"""

    name: str = "ci_cd_pipeline_dev"
    description: str = "CI/CD流水线工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "cicd", "monitoring"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化CI/CD流水线工具。"""
        super().__init__()
        self._history: Deque[Dict[str, Any]] = deque(maxlen=100)
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """注册工具参数。"""
        self.add_parameter("action", str, required=True, choices=["run", "status", "deploy", "rollback", "logs", "config"], description="操作类型")
        self.add_parameter("pipeline", str, required=False, default="default", description="流水线")
        self.add_parameter("branch", str, required=False, default="main", description="分支")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行CI/CD操作。"""
        action: str = kwargs.get("action", "")
        pipeline: str = kwargs.get("pipeline", "default")
        branch: str = kwargs.get("branch", "main")
        
        if action == "run":
            return self._run_pipeline(pipeline, branch)
        elif action == "status":
            return self._get_status(pipeline)
        elif action == "deploy":
            return self._deploy()
        elif action == "rollback":
            return self._rollback()
        elif action == "logs":
            return self._get_logs()
        elif action == "config":
            return self._get_config()
        else:
            raise ToolError(f"未知操作: {action}", code=1002)

    def _run_pipeline(self, pipeline: str, branch: str) -> Dict[str, Any]:
        """运行流水线。"""
        return {"pipeline": pipeline, "branch": branch, "status": "running", "build_id": f"BUILD-{int(time.time())}"}

    def _get_status(self, pipeline: str) -> Dict[str, Any]:
        """获取状态。"""
        return {"pipeline": pipeline, "status": "success", "duration": "120s", "stages": 4}

    def _deploy(self) -> Dict[str, Any]:
        """部署。"""
        return {"deployed": True, "environment": "production", "version": "v1.0.0"}

    def _rollback(self) -> Dict[str, Any]:
        """回滚。"""
        return {"rolled_back": True, "previous_version": "v0.9.9"}

    def _get_logs(self) -> Dict[str, Any]:
        """获取日志。"""
        return {"logs": "Build started...\nCompiling...\nTests passed...\nDeployed.", "lines": 4}

    def _get_config(self) -> Dict[str, Any]:
        """获取配置。"""
        return {"config": {"stages": ["build", "test", "deploy"], "trigger": "push", "branches": ["main", "develop"]}}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具调用。"""
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(v, 1002, start)
            result = self.execute(**v)
            elapsed = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
            return {"success": True, "data": result, "error": None, "execution_time": elapsed, "tool": self.name, "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()}
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception as e:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _err(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构建错误响应。"""
        return {"success": False, "data": None, "error": msg, "error_code": code, "error_details": details or {}, "execution_time": round(time.monotonic() - start, 4), "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat()}

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取统计信息。"""
        avg = self._stats["time"] / self._stats["ok"] if self._stats["ok"] > 0 else 0.0
        return {**self._stats, "avg": round(avg, 4), "rate": round(self._stats["ok"] / max(1, self._stats["calls"]), 4)}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史记录。"""
        return list(self._history)[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。"""
        return {"name": self.name, "description": self.description, "version": self.version, "category": self.category, "tags": self.tags, "parameters": [p.to_dict() for p in self.parameters], "stats": self.get_stats()}

    def validate_input(self, params: Dict[str, Any]) -> tuple[bool, str]:
        """验证输入参数。"""
        ok, r = self.validate_parameters(params)
        return ok, "" if ok else r

    def __repr__(self) -> str:
        """返回工具的可读表示。"""
        return f"<CiCdPipelineDevTool name={self.name} v{self.version}>"

    def run_pipeline(self, pipeline: str = "default", branch: str = "main") -> Dict[str, Any]:
        """运行流水线。"""
        return self.run({"action": "run", "pipeline": pipeline, "branch": branch})