import ast
from dataclasses import dataclass
from datetime import datetime, timezone
import logging
import random
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


@dataclass(frozen=True)
class TaskTypeSpec:
    """任务类型规格：描述一类任务的完整元信息。

    每个字段对应任务生成器的一个维度，供调度系统做意图识别、
    任务拆解与路由决策使用。
    """

    type_key: str  # 英文唯一键，如 code_generation
    name: str  # 中文名称，如 代码生成
    category: str  # 所属大类，如 代码类
    description: str  # 任务描述
    input_template: str  # 输入模板（含 {placeholders}）
    output_template: str  # 输出模板
    difficulty: str  # simple / medium / hard
    estimated_duration_s: float  # 预计执行时长（秒）
    routing_hint: str  # 路由提示：交给哪个执行域

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典，便于日志与调度系统消费。"""
        return {
            "type_key": self.type_key,
            "name": self.name,
            "category": self.category,
            "description": self.description,
            "input_template": self.input_template,
            "output_template": self.output_template,
            "difficulty": self.difficulty,
            "estimated_duration_s": self.estimated_duration_s,
            "routing_hint": self.routing_hint,
        }


# --------------------------------------------------------------------------- #
# 16 大类任务类型注册表（共 113 种）                                            #
# 元组字段顺序: (type_key, name, description, input_tpl, output_tpl,           #
#               difficulty, estimated_duration_s, routing_hint)               #
# category 由所在批次决定。                                                    #
# --------------------------------------------------------------------------- #
CATEGORY_CODE = "代码类"
CATEGORY_TEXT = "文本类"
CATEGORY_CREATIVE = "创意写作类"
CATEGORY_CHAT = "日常聊天类"
CATEGORY_ROLEPLAY = "角色扮演类"
CATEGORY_DATA = "数据处理类"
CATEGORY_TOOL = "工具调用类"
CATEGORY_MATH = "数学计算类"
CATEGORY_DECISION = "决策推理类"
CATEGORY_PLANNING = "规划调度类"
CATEGORY_ERROR = "错误处理类"
CATEGORY_SECURITY = "安全相关类"
CATEGORY_PERF = "性能优化类"
CATEGORY_DOC = "文档生成类"
CATEGORY_EDU = "学习教育类"
CATEGORY_MISC = "其他类"

# 代码类（10 种）
_CODE_ROWS: List[Tuple[Any, ...]] = [
    ("code_generation", "代码生成", "根据需求描述生成可运行的源代码", "生产系统需要用{lang}实现{feature}，要求{constraint}。现有代码上下文：\n{code}", "```{lang}\n{code}\n```\n说明：{notes}", "hard", 30.0, "dev_executor"),
    ("code_review", "代码审查", "审查代码质量、规范与潜在缺陷", "审查以下生产环境{lang}代码：\n{code}", "问题列表：{issues}\n建议：{suggestions}", "hard", 20.0, "qa_executor"),
    ("code_refactor", "代码重构", "在不改变行为的前提下重构代码结构", "重构以下生产代码以提升可读性和性能：\n{code}", "重构后：\n{refactored}\n改进点：{points}", "hard", 45.0, "dev_executor"),
    ("code_explain", "代码解释", "逐段解释代码逻辑与意图", "解释这段生产系统代码的作用：\n{code}", "功能概述：{summary}\n逐段解析：{detail}", "medium", 10.0, "edu_executor"),
    ("code_debug", "代码调试", "定位并修复代码中的错误", "报错信息：{error}\n相关代码：\n{code}", "根因：{root_cause}\n修复：{fix}", "hard", 40.0, "dev_executor"),
    ("unit_test_gen", "单元测试生成", "为函数生成单元测试用例", "为以下生产代码中的函数 {func_name} 生成 pytest 用例：\n{code}", "def test_{func_name}():\n    {cases}", "hard", 25.0, "qa_executor"),
    ("api_design", "API设计", "设计RESTful接口的请求与响应结构", "为 {resource} 设计 CRUD API，现有系统代码结构：\n{code}", "端点：{endpoints}\n字段：{schema}", "hard", 35.0, "arch_executor"),
    ("algorithm_impl", "算法实现", "实现指定算法并分析复杂度", "生产系统高并发场景下需要实现{algo}处理{input_desc}，当前瓶颈：{error}\n现有代码上下文：\n{code}", "代码：\n{code_out}\n复杂度：{complexity}", "hard", 50.0, "dev_executor"),
    ("code_optimize", "代码优化", "优化代码运行性能与资源占用", "优化以下生产代码的性能（当前CPU占用过高）：\n{code}", "优化后：{opt_code}\n提升：{gain}", "hard", 45.0, "perf_executor"),
    ("code_translate", "代码翻译", "将代码从一种语言移植到另一种", "将以下{src}代码移植到{dst}：\n{code}", "{dst}实现：\n{code_out}", "medium", 30.0, "dev_executor"),
]

# 文本类（12 种）
_TEXT_ROWS: List[Tuple[Any, ...]] = [
    ("text_summary", "文本摘要", "提取长文本的核心要点", "请为以下文本生成{style}摘要：\n{text}", "摘要：{summary}\n要点：{points}", "simple", 8.0, "nlp_executor"),
    ("text_translate", "文本翻译", "在两种语言间翻译文本", "将以下{src_lang}文本翻译为{dst_lang}：\n{text}", "译文：{translation}", "simple", 6.0, "nlp_executor"),
    ("text_correct", "文本纠错", "修正文本中的语法与错别字", "请纠正以下文本的错误：\n{text}", "修正后：{corrected}\n错误说明：{errors}", "simple", 5.0, "nlp_executor"),
    ("text_classify", "文本分类", "将文本归类到指定标签体系", "判断以下文本属于哪个类别：\n{text}\n候选：{labels}", "分类结果：{label}\n置信度：{confidence}", "medium", 7.0, "nlp_executor"),
    ("text_continue", "文本续写", "根据上下文续写后续内容", "续写以下段落，保持风格：\n{text}", "续写：{continuation}", "medium", 12.0, "creative_executor"),
    ("text_rewrite", "文本改写", "在保留原意的前提下改写表达方式", "改写以下文本为{tone}风格：\n{text}", "改写后：{rewritten}", "simple", 6.0, "nlp_executor"),
    ("keyword_extract", "关键词提取", "从文本中提取关键词与主题词", "提取以下文本的关键词：\n{text}", "关键词：{keywords}", "simple", 5.0, "nlp_executor"),
    ("entity_recognize", "实体识别", "识别文本中的命名实体", "识别以下文本中的实体：\n{text}", "实体：{entities}", "medium", 8.0, "nlp_executor"),
    ("sentiment_analysis", "情感分析", "判断文本的情感倾向与极性", "分析以下文本的情感：\n{text}", "情感：{sentiment}\n得分：{score}", "simple", 5.0, "nlp_executor"),
    ("text_compare", "文本对比", "对比两段文本的异同", "对比以下两段文本：\nA:{a}\nB:{b}", "相同点：{same}\n差异点：{diff}", "medium", 10.0, "nlp_executor"),
    ("text_compress", "文本压缩", "在保留关键信息下压缩文本长度", "将以下文本压缩到{ratio}：\n{text}", "压缩后：{compressed}", "simple", 6.0, "nlp_executor"),
    ("text_expand", "文本扩写", "将简短文本扩写为详尽内容", "将以下要点扩写为完整段落：\n{points}", "扩写后：{expanded}", "simple", 8.0, "creative_executor"),
]

# 创意写作类（10 种）
_CREATIVE_ROWS: List[Tuple[Any, ...]] = [
    ("story_writing", "故事创作", "根据设定创作短篇故事", "创作一个关于{topic}的{genre}故事", "标题：{title}\n正文：{story}", "medium", 30.0, "creative_executor"),
    ("poem_writing", "诗歌创作", "创作指定体裁的诗歌", "以{theme}为题写一首{form}", "标题：{title}\n{poem}", "simple", 10.0, "creative_executor"),
    ("script_writing", "剧本创作", "创作影视或短剧剧本片段", "为{scene}场景写一段剧本", "{script}", "hard", 40.0, "creative_executor"),
    ("novel_continue", "小说续写", "延续已有小说设定续写章节", "续写以下小说段落：\n{text}", "续写：{continuation}", "medium", 35.0, "creative_executor"),
    ("ad_copy", "广告文案", "撰写有感染力的广告文案", "为{product}写一支{medium}广告", "标题：{headline}\n正文：{body}\nCTA：{cta}", "simple", 12.0, "creative_executor"),
    ("marketing_copy", "营销文案", "撰写促进转化的营销文案", "为{product}面向{audience}写营销文案", "卖点：{selling_points}\n文案：{copy}", "medium", 15.0, "creative_executor"),
    ("wechat_article", "公众号文章", "撰写公众号风格长文", "写一篇关于{topic}的公众号文章", "标题：{title}\n正文：{article}", "medium", 40.0, "creative_executor"),
    ("product_desc", "产品描述", "撰写电商产品描述", "为{product}撰写产品描述", "标题：{title}\n详情：{detail}", "simple", 10.0, "creative_executor"),
    ("brand_naming", "品牌命名", "为产品或公司起品牌名", "为{industry}行业的{feature}产品起名", "候选名：{names}\n寓意：{meanings}", "simple", 8.0, "creative_executor"),
    ("slogan_gen", "slogan生成", "生成品牌口号", "为{brand}生成{count}条slogan", "口号：{slogans}", "simple", 6.0, "creative_executor"),
]

# 日常聊天类（10 种）
_CHAT_ROWS: List[Tuple[Any, ...]] = [
    ("chitchat", "闲聊", "进行轻松自然的日常对话", "用户说：{utterance}", "回复：{reply}", "simple", 2.0, "chat_executor"),
    ("qa", "问答", "回答用户提出的事实性问题", "用户提问：{question}", "答案：{answer}", "simple", 5.0, "chat_executor"),
    ("advice", "建议", "针对用户困境给出可行建议", "用户处境：{situation}", "建议：{advice}", "medium", 8.0, "chat_executor"),
    ("comfort", "安慰", "给予情绪上的安抚与支持", "用户说：{feeling}", "安慰：{reply}", "simple", 4.0, "chat_executor"),
    ("encourage", "鼓励", "在用户低落时给予鼓励", "用户状态：{state}", "鼓励：{reply}", "simple", 3.0, "chat_executor"),
    ("complain", "吐槽", "陪用户一起吐槽某事", "用户吐槽：{topic}", "回应：{reply}", "simple", 3.0, "chat_executor"),
    ("companion", "陪伴", "进行长时间的陪伴式对话", "用户：{utterance}", "陪伴回应：{reply}", "simple", 4.0, "chat_executor"),
    ("popularize", "知识科普", "用通俗语言解释科普知识", "科普主题：{topic}", "科普：{explanation}", "medium", 10.0, "edu_executor"),
    ("life_assistant", "生活助手", "处理日常生活咨询与安排", "生活问题：{question}", "方案：{answer}", "simple", 6.0, "chat_executor"),
    ("emotional_talk", "情感倾诉", "倾听并回应用户的情感倾诉", "用户倾诉：{feeling}", "回应：{reply}", "simple", 5.0, "chat_executor"),
]

# 角色扮演类（10 种）
_ROLEPLAY_ROWS: List[Tuple[Any, ...]] = [
    ("expert_consult", "专家咨询", "以{domain}专家身份解答问题", "我想咨询{domain}方面：{question}", "专家解答：{answer}", "medium", 12.0, "expert_executor"),
    ("historical_figure", "历史人物", "扮演{person}进行对话", "扮演{person}，对我说：{utterance}", "{person}回应：{reply}", "medium", 8.0, "roleplay_executor"),
    ("fictional_character", "虚构角色", "扮演虚构角色{character}对话", "扮演{character}，场景：{scene}", "角色回应：{reply}", "medium", 8.0, "roleplay_executor"),
    ("job_simulation", "职业模拟", "模拟{job}职业场景对话", "模拟{job}工作场景：{context}", "职业回应：{reply}", "hard", 15.0, "roleplay_executor"),
    ("interview_simulation", "面试模拟", "模拟面试官提问与点评", "面试岗位：{position}", "提问：{question}\n点评：{feedback}", "hard", 20.0, "roleplay_executor"),
    ("debate_opponent", "辩论对手", "作为反方与用户辩论", "辩题：{topic}\n我方立场：{stance}", "驳论：{argument}", "hard", 18.0, "reasoning_executor"),
    ("teaching_teacher", "教学老师", "以老师身份讲解知识点", "请讲解{topic}，面向{audience}", "讲解：{lesson}", "medium", 12.0, "edu_executor"),
    ("counseling", "心理咨询", "以心理咨询师身份倾听引导", "来访者说：{issue}", "咨询回应：{response}", "hard", 15.0, "chat_executor"),
    ("legal_advisor", "法律顾问", "解答一般性法律问题", "法律问题：{question}", "法律分析：{analysis}\n提示：{disclaimer}", "hard", 15.0, "expert_executor"),
    ("medical_consult", "医疗咨询", "提供健康科普与就医建议", "症状描述：{symptom}", "建议：{advice}\n就医提示：{disclaimer}", "hard", 15.0, "expert_executor"),
]

# 数据处理类（8 种）
_DATA_ROWS: List[Tuple[Any, ...]] = [
    ("data_clean", "数据清洗", "清洗脏数据处理缺失与异常", "清洗以下数据：\n{data}", "清洗后：{cleaned}\n报告：{report}", "medium", 20.0, "data_executor"),
    ("data_transform", "数据转换", "在不同数据格式/结构间转换", "将{src_fmt}数据转换为{dst_fmt}：\n{data}", "转换结果：{result}", "medium", 15.0, "data_executor"),
    ("data_aggregate", "数据聚合", "按维度对数据做分组聚合统计", "按{group_by}聚合，指标：{metrics}\n数据：\n{data}", "聚合结果：{aggregated}", "medium", 18.0, "data_executor"),
    ("data_visualize", "数据可视化", "根据数据选择合适图表并描述", "为以下数据选择图表：\n{data}", "图表建议：{chart}\n字段映射：{mapping}", "medium", 15.0, "data_executor"),
    ("data_analysis", "数据分析", "对数据做探索性分析得出结论", "分析目标：{goal}\n数据：\n{data}", "结论：{conclusion}\n洞察：{insights}", "hard", 30.0, "data_executor"),
    ("data_annotate", "数据标注", "对数据样本进行打标", "标注以下样本，标签体系：{schema}\n{data}", "标注结果：{annotations}", "medium", 20.0, "data_executor"),
    ("data_sample", "数据采样", "按策略从大数据集中抽样", "从数据集中抽取{size}条，策略：{strategy}", "采样：{sample}", "simple", 10.0, "data_executor"),
    ("data_desensitize", "数据脱敏", "识别并脱敏敏感个人信息", "对以下数据做脱敏：\n{data}", "脱敏后：{desensitized}", "medium", 12.0, "security_executor"),
]

# 工具调用类（8 种）
_TOOL_ROWS: List[Tuple[Any, ...]] = [
    ("search_query", "搜索查询", "构造并执行搜索查询", "搜索关键词：{query}", "结果：{results}", "simple", 5.0, "tool_executor"),
    ("file_op", "文件操作", "对文件进行读写复制移动", "对文件{path}执行{op}", "操作结果：{result}", "simple", 3.0, "tool_executor"),
    ("api_call", "API调用", "构造并调用外部API", "调用 {endpoint}，参数：{params}", "响应：{response}", "medium", 8.0, "tool_executor"),
    ("command_exec", "命令执行", "在受控环境执行shell命令", "执行命令：{cmd}", "输出：{stdout}\n退出码：{code}", "medium", 5.0, "tool_executor"),
    ("email_send", "邮件发送", "撰写并发送邮件", "收件人：{to}\n主题：{subject}\n正文：{body}", "发送结果：{status}", "simple", 6.0, "tool_executor"),
    ("calendar_mgmt", "日历管理", "查询或安排日程", "操作日历：{op}，详情：{detail}", "日历结果：{result}", "simple", 5.0, "tool_executor"),
    ("reminder_set", "提醒设置", "设置定时提醒事项", "提醒内容：{content}，时间：{when}", "设置结果：{status}", "simple", 2.0, "tool_executor"),
    ("web_scrape", "网页抓取", "抓取并解析网页内容", "抓取URL：{url}，目标：{target}", "抽取内容：{content}", "medium", 10.0, "tool_executor"),
]

# 数学计算类（6 种）
_MATH_ROWS: List[Tuple[Any, ...]] = [
    ("arithmetic", "算术运算", "执行四则混合运算", "计算：{expression}", "结果：{result}\n步骤：{steps}", "simple", 2.0, "reasoning_executor"),
    ("algebra_solve", "代数求解", "求解方程或代数式", "解方程：{equation}", "解：{solution}", "medium", 8.0, "reasoning_executor"),
    ("geometry_calc", "几何计算", "计算几何图形的边长面积体积", "已知：{given}\n求：{target}", "结果：{result}\n过程：{steps}", "medium", 8.0, "reasoning_executor"),
    ("stat_analysis", "统计分析", "计算均值方差等统计量", "对以下数据做统计：\n{data}", "统计量：{stats}", "medium", 10.0, "data_executor"),
    ("probability", "概率计算", "计算事件概率与期望", "概率问题：{problem}", "答案：{answer}\n推理：{reasoning}", "hard", 12.0, "reasoning_executor"),
    ("formula_derive", "公式推导", "推导或化简数学公式", "推导：{derivation_target}", "推导过程：{steps}\n结果：{result}", "hard", 15.0, "reasoning_executor"),
]

# 决策推理类（6 种）
_DECISION_ROWS: List[Tuple[Any, ...]] = [
    ("multi_option_decision", "多选项决策", "在多个选项间做权衡决策", "选项：{options}\n目标：{goal}", "推荐：{choice}\n理由：{reason}", "hard", 12.0, "reasoning_executor"),
    ("pros_cons", "利弊分析", "分析某决策的利弊得失", "分析决策：{decision}", "利：{pros}\n弊：{cons}\n结论：{conclusion}", "medium", 10.0, "reasoning_executor"),
    ("causal_reason", "因果推理", "分析事件之间的因果链条", "现象：{effect}\n找原因", "因果链：{chain}\n主因：{root_cause}", "hard", 15.0, "reasoning_executor"),
    ("logic_reason", "逻辑推理", "进行演绎或归纳推理", "前提：{premises}\n问：{question}", "推理：{reasoning}\n结论：{conclusion}", "hard", 12.0, "reasoning_executor"),
    ("risk_assess", "风险评估", "评估方案的各类风险等级", "方案：{plan}", "风险清单：{risks}\n评级：{rating}", "hard", 15.0, "reasoning_executor"),
    ("priority_rank", "优先级排序", "按重要紧急度给任务排序", "待办：{items}", "排序：{ranked}\n依据：{criteria}", "medium", 8.0, "planning_executor"),
]

# 规划调度类（5 种）
_PLANNING_ROWS: List[Tuple[Any, ...]] = [
    ("task_plan", "任务规划", "把大目标拆解为可执行计划", "目标：{goal}", "计划：{plan}\n里程碑：{milestones}", "hard", 15.0, "planning_executor"),
    ("time_mgmt", "时间管理", "安排日程与时间分配", "待办：{tasks}\n可用时间：{hours}", "时间表：{schedule}", "medium", 8.0, "planning_executor"),
    ("resource_alloc", "资源分配", "在多任务间分配有限资源", "资源：{resources}\n任务：{tasks}", "分配方案：{allocation}", "hard", 12.0, "planning_executor"),
    ("process_design", "流程设计", "设计业务或工作流程", "目标流程：{process_goal}", "流程：{flow}\n节点：{steps}", "hard", 18.0, "planning_executor"),
    ("project_schedule", "项目排期", "制定项目排期与甘特", "项目：{project}\n范围：{scope}", "排期：{schedule}\n依赖：{deps}", "hard", 20.0, "planning_executor"),
]

# 错误处理类（5 种）
_ERROR_ROWS: List[Tuple[Any, ...]] = [
    ("error_diagnose", "错误诊断", "根据报错信息诊断错误类型", "报错：{error}\n上下文：{context}", "诊断：{diagnosis}\n错误归类：{category}", "medium", 12.0, "dev_executor"),
    ("bug_locate", "bug定位", "在代码中定位bug所在位置", "现象：{symptom}\n代码：\n{code}", "位置：{location}\n原因：{cause}", "hard", 25.0, "dev_executor"),
    ("exception_handle", "异常处理", "设计异常捕获与处理方案", "可能异常：{exceptions}\n代码：\n{code}", "处理方案：{handler}", "medium", 15.0, "dev_executor"),
    ("log_analyze", "日志分析", "从日志中定位异常线索", "日志片段：\n{logs}", "异常点：{anomalies}\n结论：{conclusion}", "medium", 15.0, "reliability_executor"),
    ("fault_recover", "故障恢复", "制定故障恢复与补救方案", "故障现象：{fault}", "恢复步骤：{steps}\n预防：{prevention}", "hard", 20.0, "reliability_executor"),
]

# 安全相关类（5 种）
_SECURITY_ROWS: List[Tuple[Any, ...]] = [
    ("security_audit", "安全审计", "审计代码与配置的安全问题", "审计以下生产代码的安全问题：\n{code}", "发现：{findings}\n评级：{rating}", "hard", 25.0, "security_executor"),
    ("vuln_scan", "漏洞扫描", "检查常见安全漏洞", "扫描代码/配置：\n{target}", "漏洞列表：{vulns}\n严重度：{severity}", "hard", 20.0, "security_executor"),
    ("password_gen", "密码生成", "生成符合策略的强密码", "策略：{policy}", "密码：{password}\n说明：{notes}", "simple", 2.0, "security_executor"),
    ("permission_check", "权限检查", "检查资源访问权限是否合理", "资源：{resource}\n主体：{subject}", "结论：{verdict}\n建议：{advice}", "medium", 10.0, "security_executor"),
    ("penetration_test", "渗透测试", "模拟攻击发现可利用弱点", "测试目标：{target}", "测试报告：{report}\nPoC：{poc}", "hard", 40.0, "security_executor"),
]

# 性能优化类（5 种）
_PERF_ROWS: List[Tuple[Any, ...]] = [
    ("perf_analyze", "性能分析", "分析程序性能指标与瓶颈", "生产环境性能数据：{metrics}\n相关代码：\n{code}", "分析：{analysis}\n瓶颈：{bottleneck}", "hard", 20.0, "perf_executor"),
    ("bottleneck_locate", "瓶颈定位", "定位系统中的性能瓶颈", "现象：{symptom}", "瓶颈：{bottleneck}\n定位依据：{evidence}", "hard", 25.0, "perf_executor"),
    ("code_perf_opt", "代码优化", "优化代码级执行效率", "待优化代码：\n{code}", "优化后：{opt_code}\n预期收益：{gain}", "hard", 30.0, "perf_executor"),
    ("resource_opt", "资源优化", "优化内存/CPU/IO资源占用", "资源画像：{profile}", "优化方案：{plan}\n降幅：{saving}", "hard", 25.0, "perf_executor"),
    ("arch_opt", "架构优化", "从架构层面提升性能与扩展性", "当前架构：{arch}", "优化后：{new_arch}\n收益：{benefits}", "hard", 45.0, "arch_executor"),
]

# 文档生成类（5 种）
_DOC_ROWS: List[Tuple[Any, ...]] = [
    ("api_doc", "API文档", "生成接口的使用文档", "接口定义：{api_def}", "文档：{doc}", "medium", 15.0, "doc_executor"),
    ("tech_doc", "技术文档", "撰写技术设计与说明文档", "主题：{topic}", "文档：{doc}", "medium", 20.0, "doc_executor"),
    ("user_manual", "用户手册", "撰写面向用户的操作手册", "产品：{product}", "手册：{manual}", "medium", 25.0, "doc_executor"),
    ("readme_gen", "README", "生成项目README", "项目信息：{project_info}", "README：{readme}", "simple", 10.0, "doc_executor"),
    ("changelog_gen", "CHANGELOG", "整理版本变更记录", "变更：{changes}", "CHANGELOG：{changelog}", "simple", 8.0, "doc_executor"),
]

# 学习教育类（5 种）
_EDU_ROWS: List[Tuple[Any, ...]] = [
    ("point_lesson", "知识点讲解", "讲解一个知识点的来龙去去脉", "知识点：{topic}", "讲解：{lesson}\n要点：{points}", "simple", 8.0, "edu_executor"),
    ("problem_solve", "题目解答", "逐步解答一道题目", "题目：{problem}", "解答：{solution}\n步骤：{steps}", "medium", 10.0, "edu_executor"),
    ("study_plan", "学习计划", "制定学习某领域的计划", "学习目标：{goal}\n时间：{duration}", "计划：{plan}", "medium", 12.0, "edu_executor"),
    ("quiz_gen", "知识测验", "出一套测验题并附答案", "范围：{scope}\n题量：{count}", "题目：{quiz}\n答案：{answers}", "medium", 12.0, "edu_executor"),
    ("concept_explain", "概念解释", "用通俗方式解释抽象概念", "概念：{concept}", "解释：{explanation}\n类比：{analogy}", "simple", 6.0, "edu_executor"),
]

# 其他类（3 种）
_MISC_ROWS: List[Tuple[Any, ...]] = [
    ("meta_task", "元任务", "对任务本身进行规划或反思", "元任务目标：{goal}", "元结果：{result}", "hard", 15.0, "orchestrator"),
    ("system_task", "系统任务", "系统级的维护/自检/配置任务", "系统任务：{task}", "执行结果：{result}", "medium", 10.0, "system_executor"),
    ("custom_task", "自定义任务", "用户自定义的任意任务", "自定义描述：{freeform}", "输出：{output}", "medium", 15.0, "chat_executor"),
]


# 汇总：(类别, 行列表)
_CATEGORY_BATCHES: List[Tuple[str, List[Tuple[Any, ...]]]] = [
    (CATEGORY_CODE, _CODE_ROWS),
    (CATEGORY_TEXT, _TEXT_ROWS),
    (CATEGORY_CREATIVE, _CREATIVE_ROWS),
    (CATEGORY_CHAT, _CHAT_ROWS),
    (CATEGORY_ROLEPLAY, _ROLEPLAY_ROWS),
    (CATEGORY_DATA, _DATA_ROWS),
    (CATEGORY_TOOL, _TOOL_ROWS),
    (CATEGORY_MATH, _MATH_ROWS),
    (CATEGORY_DECISION, _DECISION_ROWS),
    (CATEGORY_PLANNING, _PLANNING_ROWS),
    (CATEGORY_ERROR, _ERROR_ROWS),
    (CATEGORY_SECURITY, _SECURITY_ROWS),
    (CATEGORY_PERF, _PERF_ROWS),
    (CATEGORY_DOC, _DOC_ROWS),
    (CATEGORY_EDU, _EDU_ROWS),
    (CATEGORY_MISC, _MISC_ROWS),
]


def _build_registry() -> List[TaskTypeSpec]:
    """把各批次行数据展开为 TaskTypeSpec 列表。

    Returns:
        按类别顺序排列的全部任务类型规格列表。
    """
    registry: List[TaskTypeSpec] = []
    for category, rows in _CATEGORY_BATCHES:
        for row in rows:
            registry.append(
                TaskTypeSpec(
                    type_key=row[0], name=row[1], category=category,
                    description=row[2], input_template=row[3],
                    output_template=row[4], difficulty=row[5],
                    estimated_duration_s=float(row[6]), routing_hint=row[7],
                )
            )
    return registry


# 全局任务类型注册表（113 种）
TASK_TYPE_REGISTRY: List[TaskTypeSpec] = _build_registry()


# 占位符样例值池：把 {placeholder} 模板渲染成真实可测的输入用例。
_SAMPLE_POOL: Dict[str, List[str]] = {
    "lang": ["Python", "JavaScript", "Go", "Java", "Rust", "TypeScript", "C++", "PHP", "Kotlin", "Swift"],
    "src": ["Python", "Java", "C++", "JavaScript", "PHP"],
    "dst": ["Python", "Rust", "Go", "TypeScript", "Kotlin"],
    "feature": [
        "用户登录", "订单导出", "缓存查询", "消息推送",
        "数据报表", "权限管理", "系统监控",
        "分布式锁", "限流熔断", "异步任务队列",
        "文件上传下载", "实时通信WebSocket", "全文搜索引擎",
        "定时任务调度", "数据同步ETL", "API网关路由",
    ],
    "constraint": [
        "类型注解完整，支持单元测试，性能优于O(n^2)",
        "预算不超过100万，周期不超过3个月",
        "必须使用公司指定技术栈（Java+MySQL+Redis）",
        "不能影响现有线上服务，零停机升级",
        "数据不能出境，服务器必须在国内",
        "团队只有3人，不能过度设计",
        "必须在大促前上线，硬deadline",
        "内存占用不超过512MB，支持10万QPS",
        "必须兼容Python 3.8+，不能引入C扩展",
        "接口响应时间P99<200ms，可用性99.99%",
    ],
    "notes": [
        "已处理边界情况",
        "需关注空输入",
        "并发场景下需加锁",
        "大文件需流式处理",
        "外部接口需设置超时",
        "已补充单元测试",
        "使用了连接池避免频繁创建连接",
        "包含重试机制，最多重试3次",
        "已做输入校验，防止注入攻击",
        "支持断点续传",
    ],
    "error": [
        "IndexError: list index out of range\n  File \"app.py\", line 45, in process\n    result = data[10]",
        "KeyError: 'user_id'\nTraceback (most recent call last):\n  File \"/opt/app/handlers.py\", line 128, in handle_request\n    uid = payload['user_id']",
        "AttributeError: 'NoneType' object has no attribute 'encode'\n  File \"utils.py\", line 67, in sanitize\n    return text.encode('utf-8')",
        "RecursionError: maximum recursion depth exceeded\n  File \"solver.py\", line 15, in fib\n    return fib(n-1) + fib(n-2)",
        "MemoryError: Unable to allocate 8.00 GiB for an array with shape (1000000, 1000) and data type float64",
        "ConnectionError: HTTPConnectionPool(host='db.internal', port=5432): Max retries exceeded (Caused by NewConnectionError())",
        "TimeoutError: Operation timed out after 30000ms with 0 bytes received",
        "ValueError: invalid literal for int() with base 10: 'abc'\n  File \"parser.py\", line 89, in parse_id\n    return int(raw_id)",
        "TypeError: unsupported operand type(s) for +: 'int' and 'str'\n  File \"calculator.py\", line 34, in add\n    return a + b",
        "RuntimeError: dictionary changed size during iteration\n  File \"cache.py\", line 56, in cleanup\n    for key in cache:",
        "Deadlock found when trying to get lock; try restarting transaction (MySQL Error 1213)",
        "ssl.SSLError: [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: self signed certificate",
        "ConcurrentModificationException: ArrayList was modified during iteration",
        "StackOverflowError: at com.example.Node.calculate(Node.java:42)",
        "java.lang.OutOfMemoryError: Java heap space\n  at java.util.Arrays.copyOf(Arrays.java:3210)"
    ],
    "code": [
        "def process_users(users):\n    result = {}\n    for u in users:\n        if u['active']:\n            result[u['id']] = u['name']\n    return result\n# Bug: 当users很大时内存溢出，且没有处理u['active']缺失",
        "async def fetch_with_retry(url, retries=3):\n    for i in range(retries):\n        try:\n            resp = await session.get(url, timeout=5)\n            return await resp.json()\n        except Exception:\n            if i == retries - 1:\n                raise\n            await asyncio.sleep(2 ** i)\n# Bug: 没有区分可重试异常，且没有熔断",
        "class LRUCache:\n    def __init__(self, capacity):\n        self.capacity = capacity\n        self.cache = {}\n    def get(self, key):\n        if key in self.cache:\n            return self.cache[key]\n        return -1\n    def put(self, key, value):\n        self.cache[key] = value\n        if len(self.cache) > self.capacity:\n            del self.cache[next(iter(self.cache))]\n# Bug: get没有更新访问顺序，淘汰的是最早插入不是最久未使用",
        "def quicksort(arr):\n    if len(arr) <= 1:\n        return arr\n    pivot = arr[0]\n    left = [x for x in arr[1:] if x < pivot]\n    right = [x for x in arr[1:] if x >= pivot]\n    return quicksort(left) + [pivot] + quicksort(right)\n# Bug: 已排序数组退化为O(n^2)，递归深度可能溢出",
        "SELECT u.id, u.name, o.total, o.created_at\nFROM users u\nLEFT JOIN orders o ON u.id = o.user_id\nWHERE o.status = 'paid'\nAND u.created_at > '2026-01-01'\nORDER BY o.created_at DESC\nLIMIT 100;\n-- Bug: LEFT JOIN+WHERE实际上变成INNER JOIN，且没有索引",
        "public synchronized void transfer(Account from, Account to, BigDecimal amount) {\n    if (from.getBalance().compareTo(amount) < 0) throw new InsufficientFunds();\n    from.withdraw(amount);\n    to.deposit(amount);\n}\n// Bug: 锁顺序不一致会死锁，且没有事务回滚",
        "func (h *Handler) HandleRequest(w http.ResponseWriter, r *http.Request) {\n    body, _ := ioutil.ReadAll(r.Body)\n    var req Request\n    json.Unmarshal(body, &req)\n    result := h.process(req)\n    w.Write([]byte(result))\n}\n// Bug: 忽略所有错误，没有超时控制，没有限流",
        "@app.route('/api/user/<int:uid>')\ndef get_user(uid):\n    user = db.query(\"SELECT * FROM users WHERE id=\" + str(uid)).fetchone()\n    return jsonify(user)\n# Bug: SQL注入！且没有权限校验，没有缓存",
        "def merge_intervals(intervals):\n    intervals.sort(key=lambda x: x[0])\n    merged = [intervals[0]]\n    for start, end in intervals[1:]:\n        if start <= merged[-1][1]:\n            merged[-1][1] = max(merged[-1][1], end)\n        else:\n            merged.append([start, end])\n    return merged\n# Bug: 空列表会IndexError，且没有处理边界",
        "try:\n    result = risky_operation()\nexcept:\n    result = None\nfinally:\n    cleanup()\nreturn result\n# Bug: 裸except吞掉所有异常包括KeyboardInterrupt，且没有日志",
        "def binary_search(arr, target):\n    low, high = 0, len(arr) - 1\n    while low <= high:\n        mid = (low + high) // 2\n        if arr[mid] == target:\n            return mid\n        elif arr[mid] < target:\n            low = mid + 1\n        else:\n            high = mid - 1\n    return -1\n# Bug: (low+high)可能溢出，且没有处理重复元素",
        "const debounce = (fn, delay) => {\n  let timer = null;\n  return (...args) => {\n    clearTimeout(timer);\n    timer = setTimeout(() => fn.apply(this, args), delay);\n  };\n};\n// Bug: this绑定错误，高频调用会一直延迟",
        "def parse_log_line(line):\n    parts = line.split(' ')\n    timestamp = parts[0] + ' ' + parts[1]\n    level = parts[2]\n    message = ' '.join(parts[3:])\n    return {'timestamp': timestamp, 'level': level, 'message': message}\n# Bug: 当日志消息包含额外空格时解析正确，但时间格式变化时崩溃，且没有异常处理",
        "async def batch_process(items, batch_size=100):\n    results = []\n    for i in range(0, len(items), batch_size):\n        batch = items[i:i+batch_size]\n        tasks = [process_item(item) for item in batch]\n        batch_results = await asyncio.gather(*tasks)\n        results.extend(batch_results)\n    return results\n# Bug: 没有限流，大列表会同时创建上万协程导致内存溢出，且单个失败会导致整个batch失败",
        "def get_user_profile(user_id):\n    cache_key = f'user:{user_id}'\n    user = redis.get(cache_key)\n    if user:\n        return json.loads(user)\n    user = db.query('SELECT * FROM users WHERE id = %s', (user_id,)).fetchone()\n    if user:\n        redis.setex(cache_key, 3600, json.dumps(dict(user)))\n    return dict(user) if user else None\n# Bug: 缓存穿透（不存在的用户每次都查DB），缓存与DB双写不一致，且没有序列化异常处理",
        "def calculate_discount(price, discount_rate):\n    if discount_rate > 0 and discount_rate <= 1:\n        return price * (1 - discount_rate)\n    elif discount_rate > 1 and discount_rate <= 100:\n        return price * (1 - discount_rate / 100)\n    return price\n# Bug: 没有校验price为负数的情况，浮点数计算有精度问题，且discount_rate=0时走else返回原价但逻辑不清晰",
        "func IsValidEmail(email string) bool {\n    at := strings.Index(email, \"@\")\n    dot := strings.Index(email, \".\")\n    return at > 0 && dot > at+1 && dot < len(email)-1\n}\n// Bug: 没有处理多个@符号，没有校验域名后缀长度，且Index只找第一个出现位置",
        "const users = [{id:1,name:'Alice'},{id:2,name:'Bob'}];\nfunction findUser(id) {\n  return users.find(u => u.id === id);\n}\nfunction getUserNames() {\n  return users.map(u => u.name).join(', ');\n}\n// Bug: findUser找不到时返回undefined，调用方未做判空；没有去重逻辑",
        "def read_config(path):\n    with open(path, 'r') as f:\n        config = yaml.safe_load(f)\n    return config.get('database', {}).get('host', 'localhost')\n# Bug: 文件不存在时崩溃，YAML解析错误未捕获，且嵌套get在database为None时会AttributeError",
    ],
    "func_name": [
        "calculate_total", "parse_config", "fetch_user",
        "validate_input", "process_payment",
        "generate_report", "send_notification",
        "merge_intervals", "deduplicate_list", "retry_with_backoff",
        "parse_csv_stream", "build_connection_pool", "serialize_to_json",
        "encrypt_sensitive_data", "validate_email_format",
        "calculate_page_rank", "find_cycle_in_graph",
        "compress_log_files", "throttle_requests",
    ],
    "resource": [
        "/api/orders", "用户资源", "订单资源",
        "商品库存", "支付网关", "消息队列",
        "文件存储服务", "缓存集群", "搜索引擎",
        "短信通知服务", "邮件服务", "CDN加速",
    ],
    "algo": ["快速排序", "Dijkstra最短路", "LRU缓存", "红黑树插入", "KMP字符串匹配", "动态规划-背包问题", "拓扑排序", "最小生成树-Prim", "最大流-Ford-Fulkerson", "A*寻路", "布隆过滤器", "一致性哈希", "跳表", "Trie树", "并查集", "线段树", "后缀数组", "Manacher回文", "FFT快速傅里叶", "PageRank"],
    "input_desc": ["一个无序整数数组，包含100万个元素", "加权有向图，1000个节点5000条边", "一个JSON对象，嵌套深度10层", "一段1000字的中文文本", "一个SQL查询，涉及5表JOIN", "一组日志文件，总计10GB", "一个二叉树，可能不平衡", "一张稀疏矩阵，99%元素为0", "一个字符串，长度10^5", "一组区间，可能重叠"],
    "text": [
        "今天天气很好，适合出去走走。",
        "项目上线后反馈总体不错，但偶发卡顿。",
        "数据库CPU突然飙升到90%，需要紧急排查。",
        "用户反馈支付功能在高峰期经常超时。",
        "新版本发布后，错误率从0.1%上升到2%。",
    ],
    "style": [
        "一句话", "要点式",
        "段落式", "表格对比",
        "分步骤", "问答式",
    ],
    "label": [
        "积极", "消极",
        "中性", "紧急",
        "高优先级", "待确认",
    ],
    "tone": [
        "正式", "活泼",
        "专业严谨", "轻松友好",
        "客观中立",
    ],
    "ratio": ["50%", "30%", "70%", "90%"],
    "points": [
        "开头吸引人", "中间有转折", "结尾升华",
        "逻辑清晰，层层递进",
        "数据支撑，论据充分",
        "案例丰富，说服力强",
    ],
    "topic": [
        "微服务架构下的分布式事务解决方案",
        "高并发秒杀系统的设计与实现",
        "Redis在电商场景的深度应用",
        "从单体到微服务的演进之路",
        "云原生时代的DevOps实践",
        "大模型应用开发的工程化挑战",
    ],
    "genre": ["科幻", "悬疑", "言情", "历史", "武侠", "都市"],
    "theme": [
        "离别", "故乡",
        "技术成长与职业发展",
        "架构设计的艺术与科学",
        "代码质量与工程效能",
    ],
    "form": ["五言绝句", "现代诗", "七言律诗", "词", "散文诗"],
    "scene": ["办公室争吵", "雨夜重逢", "急诊室抢救", "法庭辩论", "战场指挥"],
    "product": [
        "降噪耳机", "智能水杯", "便携充电宝",
        "智能手表", "无线键盘",
        "机械键盘", "4K显示器",
    ],
    "medium": ["短视频", "朋友圈海报", "公众号文章", "直播"],
    "audience": ["学生", "职场新人", "宝妈", "技术开发者"],
    "industry": ["咖啡", "运动装备", "电商", "金融科技"],
    "brand": ["晨光文具", "小米", "华为", "瑞幸咖啡"],
    "count": ["3", "5", "10", "20"],
    "utterance": [
        "今天好累啊", "周末去哪玩",
        "这个bug改了三天还没好",
        "终于上线了，庆祝一下",
        "服务器又崩了，连夜抢修",
    ],
    "question": [
        "为什么数据库CPU突然飙升到90%？",
        "如何设计支持百万并发的秒杀系统？",
        "Redis缓存穿透、击穿、雪崩的区别和解决方案？",
        "分布式事务有哪些实现方式，各自优缺点？",
        "如何排查Java服务的内存泄漏问题？",
        "MySQL索引失效的常见场景有哪些？",
    ],
    "situation": [
        "想辞职但担心找不到下家",
        "备考时间不够",
        "项目延期被老板批评",
        "和同事发生冲突",
        "技术选型陷入两难",
    ],
    "feeling": [
        "压力很大", "有点难过",
        "焦虑不安", "迷茫困惑",
        "挫败感强", "期待兴奋",
    ],
    "state": [
        "考试失利后", "项目被驳回",
        "刚加班到凌晨", "休假归来",
        "被裁员后", "升职加薪后",
    ],
    "domain": ["法律", "心理", "财务", "职场", "情感", "健康"],
    "person": ["诸葛亮", "李白", "苏轼", "王阳明", "曾国藩"],
    "character": ["福尔摩斯", "哈利波特", "贾宝玉", "孙悟空", "林黛玉"],
    "job": ["医生", "律师", "程序员", "产品经理", "设计师"],
    "position": [
        "高级后端工程师", "产品经理",
        "前端架构师", "数据科学家",
        "运维工程师", "测试经理",
    ],
    "stance": ["正方", "反方", "中立", "支持", "反对"],
    "issue": [
        "失眠", "和同事关系紧张",
        "工作效率低", "职业发展迷茫",
        "技术选型困难", "项目管理混乱",
    ],
    "data": [
        "[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]",
        "name,age,department,salary\nAlice,30,Engineering,15000\nBob,25,Marketing,12000\nCharlie,35,Engineering,18000\nDiana,28,Design,13000\nEve,32,Engineering,16000",
        "{'user_id': 123, 'actions': [{'type': 'click', 'ts': 1696200000}, {'type': 'view', 'ts': 1696200060}], 'session': 'abc123'}",
        "2026-01-01,100.5,200\n2026-01-02,101.2,180\n2026-01-03,99.8,220\n2026-01-04,102.1,190\n2026-01-05,103.5,250",
        "[{'id': 1, 'name': 'A', 'value': 10}, {'id': 2, 'name': 'B', 'value': 25}, {'id': 3, 'name': 'C', 'value': 15}]",
        "user_id,event_type,timestamp,page_url,referrer\n1001,page_view,2026-10-01 10:00:00,/home,https://google.com\n1001,click,2026-10-01 10:00:05,/home,/home\n1002,page_view,2026-10-01 10:01:00,/product,/home",
        "<?xml version=\"1.0\"?><users><user id=\"1\"><name>Alice</name><age>30</age></user><user id=\"2\"><name>Bob</name><age>25</age></user></users>",
        "timestamp,cpu_usage,memory_usage,network_in,network_out,disk_io\n2026-10-01T10:00:00,45.2,62.1,125.5,89.3,15.2\n2026-10-01T10:01:00,48.7,63.5,130.2,92.1,18.7",
    ],
    "src_fmt": ["CSV", "JSON", "XML", "Excel", "Parquet"],
    "dst_fmt": ["JSON", "SQL", "CSV", "Excel", "Parquet"],
    "group_by": ["部门", "月份", "地区", "产品类别", "用户等级"],
    "metrics": ["销售额", "人数", "转化率", "留存率", "错误率"],
    "size": ["100", "1000", "10000", "100万"],
    "strategy": [
        "随机抽样", "分层抽样",
        "系统抽样", "整群抽样",
        "便利抽样", "滚雪球抽样",
    ],
    "query": ["汐沫AI 任务调度", "今天天气", "Python性能优化", "微服务架构设计", "Redis缓存策略"],
    "path": ["/data/logs", "/tmp/cache", "/var/lib/mysql", "/home/user/data", "/opt/app/config"],
    "op": ["读取", "复制", "删除", "移动", "压缩", "解压"],
    "endpoint": ["/api/v1/users", "/api/v1/orders", "/api/v1/products", "/api/v1/payments", "/api/v1/auth"],
    "params": ["user_id=123", "page=1&size=20", "status=active&type=premium", "start_date=2026-01-01&end_date=2026-10-01"],
    "cmd": ["ls -la", "echo hello", "grep -r 'error' /var/log", "docker ps -a", "kubectl get pods"],
    "to": ["boss@example.com", "team@company.com", "client@partner.com", "hr@company.com"],
    "subject": ["周报", "会议纪要", "项目进度汇报", "紧急故障通知"],
    "when": ["明天早上9点", "30分钟后", "下周一", "大促前一周"],
    "url": [
        "https://example.com/docs",
        "https://api.example.com/v1/users",
        "https://github.com/ximu/ai-agent",
        "https://dashboard.example.com/metrics",
    ],
    "expression": [
        "(3 + 5) * 2", "128 / 4",
        "sin(x) + cos(x)", "log₂(8) + log₂(4)",
        "sum([i**2 for i in range(10)])",
    ],
    "equation": [
        "2x + 3 = 7", "x^2 - 5x + 6 = 0",
        "e^x = 10", "∫(0 to π) sin(x) dx",
        "lim(x→0) sin(x)/x",
    ],
    "given": [
        "直角三角形两直角边 3 和 4",
        "等差数列首项2，公差3，求第10项",
        "函数f(x)=x²-4x+3，求最小值",
        "已知log₂8=3，求log₂64",
    ],
    "problem": [
        "抛两枚硬币，至少一个正面的概率？",
        "一个班50人，至少两人生日相同的概率？",
        "从1到100中随机取一个数，是质数的概率？",
        "甲乙两人下棋，甲胜率60%，三局两胜甲赢的概率？",
    ],
    "derivation_target": [
        "勾股定理",
        "二次方程求根公式",
        "欧拉公式e^(iπ)+1=0",
        "微积分基本定理",
    ],
    "options": ["方案A", "方案B", "方案C", "不做任何改变"],
    "goal": [
        "将接口P99延迟从500ms降到200ms以内",
        "系统可用性达到99.99%，年停机<52分钟",
        "日活从10万提升到100万，水平扩展支持",
        "代码覆盖率从40%提升到80%",
        "部署时间从2小时缩短到15分钟",
        "降低云成本30%，同时不影响性能",
    ],
    "decision": [
        "是否上线新功能",
        "是否回滚到上一版本",
        "是否扩容数据库",
        "是否切换到新架构",
        "是否终止该项目",
    ],
    "premises": [
        "所有人都会死，苏格拉底是人",
        "如果明天下雨比赛就取消，明天有暴雨预警",
        "A大于B，B大于C",
        "所有金属导电，铜是金属",
        "勤奋的人会成功，小明很勤奋",
        "三角形内角和180度，已知两角60和80",
    ],
    "plan": [
        "第一周需求分析，第二周开发，第三周测试，第四周上线",
        "先做POC验证可行性，再拆分迭代每两周一个版本",
        "按模块拆解：用户→订单→支付→报表，串行开发并行测试",
        "先搭基础设施（CI/CD、监控），再开发业务功能",
        "MVP先上线核心流程，后续迭代优化体验和性能",
        "灰度发布：1%→10%→50%→100%，每阶段观察24小时",
    ],
    "tasks": [
        "写文档", "改bug", "发版",
        "代码审查", "性能优化", "技术分享",
        "需求评审", "线上问题排查",
    ],
    "resources": [
        "8核16G", "10人日",
        "3台应用服务器+1台DB",
        "预算50万", "周期2周",
    ],
    "hours": ["8小时", "40小时", "100人日", "2周"],
    "process_goal": [
        "新用户注册流程",
        "订单支付流程",
        "商品上架审核流程",
        "用户退款流程",
    ],
    "project": [
        "任务生成器扩展",
        "微服务架构改造",
        "数据平台建设",
        "移动端APP重构",
    ],
    "scope": [
        "113种任务类型",
        "用户模块和订单模块",
        "后端API层，不涉及前端",
        "核心交易链路，非核心功能暂不处理",
        "全链路：从用户输入到结果返回",
    ],
    "context": [
        "服务启动时，需要加载10GB配置数据，启动时间超过2分钟",
        "请求处理中，用户上传了一个100MB的文件，内存占用飙升",
        "高并发场景下，每秒1万请求，数据库连接池只有100个",
        "分布式环境下，多个节点同时修改同一条记录",
        "弱网环境下，请求超时率达到30%",
        "数据一致性要求高，不能出现脏读幻读",
        "幂等性要求，重复请求不能产生副作用",
        "降级策略，核心功能可用，非核心功能关闭"
    ],
    "symptom": [
        "偶发超时，P99延迟从200ms升到3s",
        "内存持续上涨，每小时增加500MB，疑似内存泄漏",
        "CPU使用率持续90%以上，负载很高",
        "数据库连接数打满，新请求被拒绝",
        "磁盘IO等待时间长，写入缓慢",
        "网络丢包率5%，接口频繁超时",
        "线程阻塞，请求堆积",
        "GC频繁，STW时间超过1秒"
    ],
    "exceptions": ["网络超时", "空指针", "数组越界", "类型转换失败", "数据库死锁", "连接池耗尽", "文件句柄泄漏", "线程死锁", "栈溢出", "内存溢出"],
    "logs": [
        "ERROR 2026-10-05 14:30:15 timeout after 30000ms url=/api/orders user_id=12345",
        "WARN 2026-10-05 14:30:16 connection pool exhausted, active=100, idle=0, waiting=50",
        "ERROR 2026-10-05 14:30:17 OutOfMemoryError: Java heap space at com.example.Cache.put(Cache.java:45)",
        "INFO 2026-10-05 14:30:18 circuit breaker opened for service payment, failure rate=85%",
        "ERROR 2026-10-05 14:30:19 Deadlock found when trying to get lock; try restarting transaction",
        "2026-10-05T14:30:20.123Z [ERROR] [order-service] [trace-id=abc123] Failed to process order #45678: com.mysql.cj.jdbc.exceptions.CommunicationsException: Communications link failure",
        "2026-10-05 14:30:21 WARN  c.x.c.RedisClient - Redis connection timeout, host=redis.internal:6379, elapsed=5000ms, retrying (1/3)",
        "2026-10-05 14:30:22 INFO  c.x.s.TaskScheduler - Task batch_20261005 completed: 1500/1500 success, 0 failed, duration=45.2s",
        "2026-10-05 14:30:23 ERROR c.x.h.GlobalExceptionHandler - Unhandled exception: java.lang.NullPointerException at com.x.service.UserService.getUser(UserService.java:87)",
        "2026-10-05 14:30:24 DEBUG c.x.m.RequestMetrics - GET /api/users 200 45ms db=12ms cache=hit rate_limit=remaining",
    ],
    "fault": [
        "线上服务502，影响全部用户",
        "数据库主库宕机，只读从库提供服务",
        "缓存集群雪崩，数据库压力骤增",
        "消息队列堆积，延迟消费超过1小时",
        "第三方支付接口不可用，下单流程中断",
        "CDN节点故障，部分地区访问缓慢",
        "SSL证书过期，HTTPS无法访问",
        "DNS解析故障，域名无法访问"
    ],
    "profile": [
        "CPU 90%, 内存 4GB, 磁盘IO 80%, 网络 50Mbps",
        "CPU 20%, 内存 8GB, 线程数 500, GC 10次/秒",
        "CPU 100%, 内存 15GB/16GB, 连接数 1000, 队列堆积 10000",
        "CPU 10%, 内存 2GB, QPS 5000, P99 50ms, 错误率 0.01%",
        "CPU 65%, 内存 12GB/16GB, 磁盘IO等待 30%, 网络入 200Mbps出 80Mbps",
        "CPU 5% (单核跑满100%), 内存 1GB, 锁等待 80%, 上下文切换 50000/s",
        "CPU 30%, 内存 14GB/16GB (持续增长), FD数 4000/4096, 句柄泄漏",
        "CPU 80%, 内存 6GB, GPU利用率 95%, 显存 18GB/24GB, 推理吞吐 120/s",
    ],
    "arch": ["单体应用", "微服务架构", "事件驱动架构", "CQRS", "六边形架构", "Serverless", "Service Mesh", "分层架构"],
    "api_def": [
        "GET /users 返回用户列表",
        "POST /orders 创建订单，参数：user_id, items[], amount",
        "PUT /users/{id} 更新用户信息",
        "DELETE /cache/{key} 删除缓存",
        "POST /auth/login 登录，参数：username, password，返回token",
        "GET /reports/export 异步导出报表，返回task_id用于轮询",
        "WebSocket /ws/notifications 实时推送通知，心跳间隔30s",
        "GET /health 健康检查，返回status和依赖服务状态",
    ],
    "project_info": [
        "汐沫AI 任务调度",
        "电商平台订单系统，日订单量100万",
        "内容推荐引擎，日活500万",
        "物联网设备管理平台，接入设备10万台",
        "实时风控系统，日均处理5000万事件，延迟要求<50ms",
        "微服务架构的在线教育平台，支持10万并发在线学习",
    ],
    "changes": [
        "v0.5 新增任务生成器",
        "v1.0 重构调度引擎，支持多智能体",
        "v1.1 修复内存泄漏，优化性能30%",
        "v2.0 引入向量数据库，支持语义检索",
        "v2.1 修复支付回调幂等性问题，增加分布式锁",
        "v2.2 升级Python至3.11，移除废弃依赖，启动速度提升40%",
    ],
    "concept": ["递归", "时间复杂度", "空间复杂度", "动态规划", "贪心算法", "分治", "回溯", "哈希表", "红黑树", "B+树", "CAP定理", "BASE理论", "最终一致性", "幂等性", "熔断降级"],
    "freeform": [
        "帮我整理一下这周的待办，按优先级排序",
        "分析一下这个项目的技术风险",
        "给我一个学习Python的路线图",
        "帮我写一封辞职信，要委婉一点",
        "评估一下这个方案的可行性",
        "帮我设计一个数据库表结构",
        "给我一些提高效率的建议",
        "帮我分析这个bug可能的原因"
    ],
    "effect": [
        "服务器响应时间从200ms增加到3s",
        "用户投诉率上升了15%",
        "数据库CPU使用率持续90%以上",
        "订单转化率下降了20%",
        "内存每小时增长500MB，最终OOM",
        "接口错误率从0.1%升到5%",
        "消息队列堆积超过100万条",
        "页面加载时间从1s变成8s"
    ],
    "cause": [
        "缓存击穿导致数据库压力骤增",
        "连接池配置过小，高并发下等待",
        "代码中有内存泄漏，大对象未释放",
        "SQL没有命中索引，全表扫描",
        "第三方接口超时，级联失败",
        "日志同步写入阻塞了主线程",
        "锁粒度太大，并发竞争激烈",
        "配置错误，限流阈值设置过高"
    ],
    "root_cause": [
        "缓存与数据库双写不一致",
        "线程池拒绝策略设置为AbortPolicy",
        "GC参数不合理，频繁Full GC",
        "分布式锁过期时间短于业务执行时间",
        "N+1查询问题，循环调用数据库",
        "大对象直接进入老年代，触发Full GC"
    ],
    "chain": [
        "流量突增→缓存击穿→DB压力大→连接池耗尽→请求超时→熔断",
        "代码发布引入bug→内存泄漏→OOM→服务重启→流量切换→数据不一致",
        "第三方接口变慢→线程阻塞→线程池满→新请求拒绝→用户投诉",
        "慢SQL→锁等待→死锁→事务回滚→数据不一致→重试风暴",
        "DNS解析失败→服务无法连接→重试风暴→连接池耗尽→级联故障",
        "大促流量→网关限流→部分请求被拒→用户刷新→流量进一步放大→雪崩",
        "Kafka消息堆积→消费延迟→数据不一致→下游服务超时→熔断触发",
        "Redis主节点宕机→哨兵切换→短暂不可用→缓存未命中→DB压力激增",
    ],
    "conclusion": [
        "问题根因是缓存击穿，建议加互斥锁和空值缓存",
        "需要优化SQL并增加索引，同时调整连接池大小",
        "存在内存泄漏，建议使用内存分析工具定位大对象",
        "第三方接口不稳定，建议增加熔断和降级机制",
        "整体架构需要重构，引入消息队列解耦"
    ],
    "reasoning": [
        "根据前提A和B，可以推出C，又因为D，所以最终结论是E",
        "数据显示X指标异常，结合Y事件时间点吻合，推断Z是原因",
        "排除法：A不可能因为时间不符，B不可能因为条件不满足，所以C最可能",
        "归纳推理：观察到n个案例都符合模式P，推断新案例也符合P",
        "类比推理：系统A和系统B架构相似，A出现过内存泄漏，B也可能有相同问题",
        "演绎推理：所有慢查询都导致连接占用，该SQL执行5秒，因此它占用连接5秒",
        "反证法：假设缓存有效，则DB QPS应下降，但实际DB QPS上升，故缓存未命中",
        "相关性分析：错误率与版本发布时间相关系数0.95，高度相关，推断发布引入bug",
    ],
    "location": [
        "第45行，process函数中的数组访问",
        "Cache.java第67行，put方法的缓存淘汰逻辑",
        "OrderService.java第128行，事务提交前的远程调用",
        "SQL查询语句第3行，缺少索引的WHERE条件",
        "配置文件application.yml第15行，连接池大小配置"
    ],
    "fix": [
        "增加空值缓存和互斥锁，防止缓存击穿",
        "优化SQL，增加复合索引(created_at, status)",
        "将远程调用移出事务，避免长事务",
        "调整连接池大小为200，增加等待超时",
        "修复内存泄漏，在finally中释放大对象",
        "增加熔断机制，失败率超过50%自动降级"
    ],
    "handler": [
        "try-catch捕获特定异常，记录日志后返回默认值",
        "全局异常处理器统一处理，区分业务异常和系统异常",
        "重试机制+退避策略，最多重试3次",
        "降级处理，非核心功能返回缓存数据",
        "熔断机制，失败率超阈值自动切断调用"
    ],
    "risks": [
        "数据一致性风险：分布式事务可能失败",
        "性能风险：新功能引入慢查询",
        "安全风险：输入未校验可能导致注入",
        "可用性风险：单点故障，没有降级方案",
        "兼容性风险：API变更影响老版本客户端",
        "成本风险：资源消耗增加30%"
    ],
    "rating": ["高风险", "中风险", "低风险", "需立即处理", "可接受", "需持续监控"],
    "steps": [
        "1. 分析需求 2. 设计方案 3. 编码实现 4. 单元测试 5. 代码审查 6. 集成测试 7. 灰度发布",
        "1. 复现问题 2. 定位根因 3. 制定修复方案 4. 编码修复 5. 验证测试 6. 上线发布",
        "1. 数据采集 2. 数据清洗 3. 特征工程 4. 模型训练 5. 模型评估 6. 模型部署",
        "1. 备份数据 2. 停服 3. 执行升级 4. 数据迁移 5. 验证 6. 恢复服务",
        "1. 建立基线 2. 识别瓶颈 3. 优化方案 4. 实施 5. 对比测试 6. 持续监控",
        "1. 需求评审 2. 方案设计 3. 编码 4. 自测 5. QA测试 6. 预发验证 7. 生产发布",
    ],
    "summary": [
        "本次优化将P99延迟从1s降到200ms，吞吐量提升3倍",
        "问题根因是缓存击穿，已修复并增加监控告警",
        "新功能已上线，用户反馈良好，转化率提升15%",
        "系统整体健康度85分，存在1个高危安全漏洞需修复",
        "数据迁移完成，10亿条记录零丢失，耗时3小时",
        "灰度发布顺利，1%→100%无P0/P1问题，核心指标稳定",
    ],
    "diagnosis": [
        "根据报错信息和日志，判断是数据库连接池耗尽",
        "症状符合内存泄漏特征，建议用MAT分析heap dump",
        "CPU高是因为频繁Full GC，根因是大对象直接进入老年代",
        "网络超时是因为第三方接口响应慢，建议增加超时和重试",
        "线程阻塞在锁等待，jstack显示两个线程互相持有对方需要的锁",
        "慢查询全表扫描，执行计划显示未走索引，需要添加复合索引",
    ],
    "anomalies": [
        "14:30开始错误率飙升，对应版本发布时间",
        "CPU和内存同时上涨，疑似内存泄漏",
        "慢查询集中在订单表，缺少索引",
        "连接池活跃数持续100%，等待队列增长",
        "GC停顿时间从50ms增加到2s，频繁Full GC",
        "网络入站流量正常但出站流量下降80%，疑似下游阻塞",
        "磁盘IO等待%util达到95%，写入延迟超过1s",
        "线程数从200增长到800且持续增长，疑似线程泄漏",
    ],
    "evidence": [
        "日志显示14:30后大量TimeoutException",
        "监控图表显示CPU从20%涨到90%",
        "数据库慢查询日志显示同一条SQL执行1000次",
        "heap dump显示100MB的byte[]未被回收",
        "jstack输出显示50个线程BLOCKED在同一把锁上",
        "tcpdump显示大量SYN重传，目标端口5432无响应",
        "火焰图显示70%CPU消耗在JSON序列化函数",
        "ping延迟从1ms增加到500ms，丢包率10%",
    ],
    "findings": [
        "发现SQL注入漏洞，用户输入未参数化",
        "发现3处空指针风险，未做null检查",
        "发现性能瓶颈，单条SQL执行超过5s",
        "发现内存泄漏，监听器未注销",
        "发现硬编码密钥，API Key直接写在配置文件中",
        "发现越权访问漏洞，接口未校验用户权限",
        "发现不安全的反序列化，使用pickle加载用户输入",
        "发现XSS漏洞，用户输入未转义直接渲染到页面",
    ],
    "poc": [
        "输入 ' OR 1=1 -- 可绕过登录验证",
        "构造恶意JSON触发反序列化执行任意代码",
        "发送超长Header导致缓冲区溢出",
        "通过路径遍历读取/etc/passwd",
        "在评论区输入 <script>alert('xss')</script> 可执行恶意脚本",
        "修改请求中的user_id参数可查看他人订单",
        "上传恶意PHP文件到图片上传接口可获取webshell",
        "通过SSRF漏洞访问内网服务 http://169.254.169.254/latest/meta-data/",
    ],
    "issues": [
        "代码重复率高，3个模块有相同逻辑",
        "缺少单元测试，核心模块覆盖率仅30%",
        "命名不规范，存在拼音和英文混用",
        "异常处理不当，裸except吞掉异常",
        "函数过长，process_data函数超过200行，职责不单一",
        "存在循环导入，module_a导入module_b，module_b又导入module_a",
        "硬编码配置，数据库连接字符串写死在代码中",
        "没有类型注解，函数参数和返回值类型不明确",
    ],
    "suggestions": [
        "提取公共方法，消除重复代码",
        "补充单元测试，目标覆盖率80%",
        "统一命名规范，使用英文驼峰",
        "细化异常捕获，记录日志并抛出业务异常",
        "拆分长函数，按职责提取子函数，每个函数不超过50行",
        "重构模块依赖，消除循环导入，使用依赖注入",
        "配置外部化，使用环境变量或配置文件管理敏感信息",
        "添加类型注解，启用mypy静态检查",
    ],
    "score": ["85分", "92分", "78分", "60分", "45分", "100分"],
    "verdict": ["通过", "不通过", "有条件通过", "需修改后再审", "优秀", "合格"],
    "severity": ["严重", "高危", "中危", "低危", "提示", "信息"],
    "prevention": [
        "增加单元测试和集成测试，CI自动执行",
        "代码审查制度，高危变更需两人审核",
        "增加监控告警，异常及时发现",
        "定期安全扫描，每月一次渗透测试",
        "灰度发布，先10%流量验证"
    ],
    "policy": [
        "密码长度至少8位，包含大小写字母和数字",
        "敏感数据必须加密存储，传输使用HTTPS",
        "访问日志保留6个月，定期审计",
        "第三方依赖必须经过安全评估",
        "生产环境变更需走变更审批流程"
    ],
    "keywords": [
        "Python, 后端, 微服务",
        "React, 前端, TypeScript",
        "数据分析, SQL, Python",
        "DevOps, Kubernetes, Docker",
        "机器学习, PyTorch, NLP",
        "高并发, 分布式, 缓存",
        "安全, 渗透测试, 漏洞",
    ],
    "entities": [
        "人名: 张三, 李四; 地点: 北京, 上海; 时间: 2026年10月",
        "机构: 汐沫科技; 产品: AI助手; 技术: 深度学习",
        "公司: 阿里巴巴; 人物: 马云; 事件: 双十一",
        "药物: 阿司匹林; 疾病: 高血压; 症状: 头痛",
        "编程语言: Python, Go; 框架: Django, Gin; 数据库: MySQL, Redis",
    ],
    "sentiment": ["积极", "消极", "中性", "愤怒", "期待", "失望"],
    "labels": ["技术", "产品", "运营", "市场", "财务", "人事"],
    "schedule": [
        "第1周：需求分析和设计\n第2-3周：开发\n第4周：测试\n第5周：上线",
        "2026-10-01 启动\n2026-10-15 开发完成\n2026-10-20 测试完成\n2026-10-25 上线",
        "Sprint 1: 用户模块\nSprint 2: 订单模块\nSprint 3: 支付模块\nSprint 4: 集成测试",
        "Day 1-3: 调研\nDay 4-7: 方案设计\nDay 8-20: 开发\nDay 21-25: 测试\nDay 26-28: 上线",
        "Phase 1: POC验证（2周）\nPhase 2: MVP开发（4周）\nPhase 3: 优化迭代（2周）",
    ],
    "milestones": [
        "M1: 需求评审完成\nM2: 原型设计完成\nM3: 开发完成\nM4: 测试通过\nM5: 上线发布",
        "Q1: 基础架构搭建\nQ2: 核心功能开发\nQ3: 性能优化\nQ4: 全面上线",
        "里程碑1: 技术选型确认\n里程碑2: 接口定义完成\n里程碑3: 核心功能交付\n里程碑4: 全量上线",
        "Alpha: 内部测试\nBeta: 公测\nRC: 发布候选\nGA: 正式发布",
        "Sprint 1: 用户认证模块\nSprint 2: 订单管理模块\nSprint 3: 支付集成\nSprint 4: 性能优化与上线",
        "Day 1-3: 需求分析\nDay 4-7: 方案设计\nDay 8-20: 开发\nDay 21-25: 测试\nDay 26-28: 上线",
    ],
    "benefits": ["提升效率50%", "降低成本30%", "用户体验改善", "系统稳定性提升", "可扩展性增强"],
    "pros": ["技术成熟，社区活跃", "性能优异，吞吐量高", "学习曲线平缓", "文档完善"],
    "cons": ["内存占用较高", "部署复杂", "学习成本高", "第三方依赖多"],
    "criteria": ["性能：P99<200ms", "可用性：99.99%", "安全性：通过等保三级", "可维护性：代码覆盖率>80%"],
    "reason": [
        "方案A在性能和可维护性上综合最优，虽然初期成本略高但长期收益更大",
        "选择回滚是因为新功能引入的bug影响核心交易链路，修复时间不可控",
        "推荐微服务架构，因为团队规模扩大后单体部署效率低，且需要独立扩展",
        "不建议立即扩容，先优化慢查询，当前瓶颈在数据库而非应用服务器",
        "选择Kafka而非RabbitMQ，因为需要高吞吐量和消息持久化，且团队有Kafka经验",
    ],
    "target": [
        "用户登录接口 /api/auth/login",
        "订单服务的支付回调处理函数",
        "配置文件 application.yml 中的数据库连接池配置",
        "前端用户注册页面的表单校验逻辑",
        "Dockerfile 中的基础镜像和依赖安装步骤",
        "Nginx 反向代理配置文件",
    ],
    "choice": ["方案A", "方案B", "方案C", "自研方案", "开源方案", "混合方案"],
    "errors": [
        "1. '明田'应为'明天'\n2. '学笑'应为'学校'\n3. 缺少标点符号",
        "1. '连接迟'应为'连接池'\n2. '配至'应为'配置'",
        "1. 主语缺失\n2. '的/地/得'使用错误\n3. 句子不完整",
    ],
    "stats": [
        "均值: 85.2, 中位数: 88, 标准差: 12.5, 最小值: 40, 最大值: 100",
        "count: 1000, mean: 156.8, std: 45.2, min: 20, 25%: 120, 50%: 155, 75%: 190, max: 300",
        "总和: 12500, 均值: 125, 方差: 156.25, 标准差: 12.5",
    ],
    "deps": [
        "用户模块→订单模块→支付模块→报表模块",
        "前端依赖后端API，后端依赖数据库和缓存，缓存依赖数据库",
        "任务A无依赖，任务B依赖A，任务C依赖A和B，任务D依赖C",
    ],
    "a": [
        "微服务架构将系统拆分为独立服务，每个服务独立部署和扩展。",
        "Redis是内存数据库，读写速度快，适合做缓存。",
        "Python是解释型语言，开发效率高但运行速度较慢。",
    ],
    "b": [
        "单体架构所有功能在一个应用中，部署简单但扩展困难。",
        "MySQL是关系型数据库，支持事务，适合结构化数据存储。",
        "Go是编译型语言，并发性能好，适合高并发服务。",
    ],
    "same": [
        "都讨论了架构选型问题，都提到了扩展性和部署",
        "都涉及数据存储技术，都对比了不同方案的优缺点",
        "都在分析编程语言特性，都提到了开发效率和运行性能",
    ],
    "ranked": [
        "1. 方案A 综合得分92\n2. 方案C 综合得分85\n3. 方案B 综合得分78",
        "1. 紧急：线上P0故障\n2. 高：性能优化\n3. 中：文档完善\n4. 低：代码重构",
        "1. 数据库扩容\n2. 缓存优化\n3. 代码重构\n4. 前端优化",
        "1. P0: 支付失败\n2. P1: 登录异常\n3. P2: 页面卡顿\n4. P3: 文案错误",
    ],
    "items": [
        "1. 需求分析\n2. 方案设计\n3. 编码实现\n4. 测试验证\n5. 上线发布",
        "1. 复现问题\n2. 定位根因\n3. 制定方案\n4. 编码修复\n5. 验证测试",
        "1. 数据采集\n2. 数据清洗\n3. 特征工程\n4. 模型训练\n5. 模型部署",
        "1. 备份数据\n2. 停服\n3. 执行升级\n4. 验证\n5. 恢复服务",
    ],
    "allocation": [
        "CPU: 4核, 内存: 8GB, 存储: 100GB",
        "前端: 2台, 后端: 4台, 数据库: 1主2从",
        "开发: 5人, 测试: 2人, 产品: 1人, 设计: 1人",
        "K8s集群: 3个master, 10个worker, 每个worker 16核32G",
        "预算: 开发50万, 运维20万, 硬件30万",
    ],
    "bottleneck": ["数据库查询慢", "网络带宽不足", "CPU计算密集", "内存不够", "磁盘IO慢"],
    "saving": ["成本降低40%", "时间节省50%", "人力减少30%", "资源利用率提升60%"],
    "new_arch": [
        "微服务架构，拆分6个服务",
        "事件驱动，引入Kafka解耦",
        "Serverless架构，按需扩容",
        "CQRS模式，读写分离",
        "六边形架构，领域驱动设计",
    ],
    "headline": [
        "重磅！汐沫AI发布新版本",
        "效率提升3倍的秘密",
        "从0到1构建高可用系统",
        "性能优化实战：从500ms到50ms",
        "微服务架构演进之路",
    ],
    "selling_points": ["高性能：P99 50ms", "低成本：每月节省1万", "易使用：5分钟接入", "可扩展：支持百万并发"],
    "results": ["营收增长15%", "用户数突破100万", "DAU达到20万", "转化率提升8%"],
    "content": [
        "这是正文内容，包含详细的分析和说明。",
        "文章主体部分，分三个小节展开论述。",
        "系统采用微服务架构，共拆分6个服务，通过Kafka异步通信。",
        "性能测试结果显示，优化后P99延迟从500ms降到150ms，吞吐量提升3倍。",
        "安全审计发现3个中危漏洞，已全部修复并补充测试用例。",
    ],
    "cleaned": ["已去除HTML标签", "已修正错别字", "已统一格式", "已去除重复内容",
        "原始: '  Hello  World!  ' → 清洗后: 'Hello World!' (去除首尾空格，合并中间空格)",
        "原始: '2026/1/5', '2026-01-05', 'Jan 5, 2026' → 统一为: '2026-01-05' (日期格式标准化)",
        "删除空值行12条，修正数据类型错误8处，去除重复记录5条，最终有效数据1235条",
    ],
    "corrected": [
        "我明天去学校。（原：我明田去学笑）",
        "这是正确的写法。（原：这是正却的写发）",
        "数据库连接池已配置最大连接数。（原：数据库连接迟已配置最大连接数）",
        "函数返回值类型为整数。（原：函数返回值类型为整数）",
    ],
    "rewritten": [
        "优化后的表达更加简洁清晰。",
        "改写后逻辑更通顺，重点更突出。",
        "原句冗长，改写后用主动语态，信息密度更高。",
        "调整段落结构，先结论后论据，可读性提升。",
    ],
    "expanded": [
        "原文基础上增加了背景介绍、详细分析和具体案例。",
        "扩展后内容更丰富，涵盖了更多细节。",
        "补充了技术原理、实现步骤和性能对比。",
        "增加了使用场景、注意事项和最佳实践。",
    ],
    "compressed": [
        "核心要点：1. 问题 2. 原因 3. 方案",
        "压缩后保留关键信息，去除冗余。",
        "一句话总结：通过引入缓存，性能提升3倍。",
        "关键结论：根因是连接池耗尽，已修复。",
    ],
    "diff": [
        "- 旧代码\n+ 新代码\n@@ -10,5 +10,6 @@",
        "修改了3个文件，新增50行，删除30行",
        "diff --git a/app.py b/app.py\nindex abc..def 100644\n--- a/app.py\n+++ b/app.py\n@@ -1,3 +1,4 @@\n+import logging",
        "PR #123: 修复内存泄漏，涉及5个文件，+200/-80",
    ],
    "password": [
        "Abc123456!", "Ximo@2026", "Secure#Pass99",
        "MyP@ssw0rd2026", "Str0ng!Pass#2024",
    ],
    "file_path": [
        "/opt/app/config.yaml", "/var/log/app/error.log", "/home/user/data.csv",
        "/etc/nginx/nginx.conf", "/data/backup/2026-10-01.sql",
    ],
    "action": ["创建", "删除", "修改", "查询", "执行", "部署"],
    "task": [
        "完成用户登录功能", "优化数据库查询性能", "修复支付bug", "编写API文档",
        "搭建监控告警系统", "进行安全渗透测试",
    ],
    "key": [
        "user_id", "order_id", "session_token", "api_key",
        "access_token", "refresh_token", "csrf_token",
    ],
    "duration": ["30分钟", "2小时", "1天", "1周", "1个月"],
    "confidence": ["95%", "80%", "60%", "不确定", "75%", "99%"],
    "disclaimer": [
        "以上分析仅供参考，不构成投资建议。",
        "数据来源于公开信息，准确性不保证。",
        "本工具仅用于学习研究，请勿用于非法用途。",
        "测试结果受环境影响，实际性能可能有所不同。",
    ],
    "src_lang": ["中文", "英文", "日文", "韩文"],
    "dst_lang": ["英文", "中文", "日文", "法文"],
    "vulns": ["SQL注入", "XSS跨站脚本", "CSRF跨站请求伪造", "SSRF服务端请求伪造", "反序列化漏洞", "越权访问"],
    "lesson": [
        "## 递归\n递归是函数在内部调用自身，需要基线条件终止。\n## 动态规划\n将大问题拆成子问题，保存子问题结果避免重复计算。",
        "## 索引\n索引类似书的目录，通过B+树快速定位数据，避免全表扫描。\n## 事务\nACID特性：原子性、一致性、隔离性、持久性。",
        "## HTTP\n无状态协议，常用方法GET/POST/PUT/DELETE，状态码200/404/500。\n## RESTful\n资源导向的API设计风格，用HTTP方法表示操作。",
        "## 死锁\n两个线程互相持有对方需要的锁，都在等待。四个必要条件：互斥、持有等待、不可剥夺、循环等待。",
        "## 缓存穿透\n查询不存在的数据，请求直接打到数据库。解决方案：布隆过滤器、空值缓存。\n## 缓存击穿\n热点key过期瞬间大量请求打到数据库。解决方案：互斥锁、永不过期。",
        "## 一致性哈希\n解决分布式缓存节点增减时的数据迁移问题，将key和节点映射到哈希环上。\n## 布隆过滤器\n用多个哈希函数判断元素是否在集合中，有误判但不会漏判。",
    ],
    "solution": [
        "解：x=2\n验证：2*2+3=7 ✓",
        "答案：斜边=5\n验证：3²+4²=5²=25 ✓",
        "根因：连接池耗尽\n修复：增加最大连接数+超时回收\n验证：压测1小时无报错",
        "方案：引入Redis缓存\n效果：P99从500ms降到150ms",
        "结论：使用分库分表\n步骤：1.水平拆分 2.读写分离 3.数据迁移",
    ],
    "quiz": [
        "1. 什么是递归？\n2. 时间复杂度O(n log n)的排序算法？\n3. CAP定理的三个特性？",
        "1. HTTP和HTTPS的区别？\n2. TCP三次握手过程？\n3. 什么是RESTful API？",
        "1. 索引的底层数据结构？\n2. 事务的ACID特性？\n3. 什么是脏读、不可重复读、幻读？",
        "1. 进程和线程的区别？\n2. 什么是死锁？\n3. 常见的垃圾回收算法？",
        "1. Redis缓存穿透、击穿、雪崩的区别？\n2. 什么是布隆过滤器？\n3. 分布式锁有哪些实现方式？",
        "1. Python的GIL是什么？\n2. 列表和元组的区别？\n3. *args和**kwargs的用法？",
    ],
    "answers": [
        "1. 函数在内部调用自身\n2. 归并排序、快速排序（平均）\n3. 一致性、可用性、分区容错性",
        "1. HTTPS加密传输，端口443\n2. SYN→SYN+ACK→ACK\n3. 资源导向，用HTTP方法表示操作",
        "1. B+树\n2. 原子性、一致性、隔离性、持久性\n3. 读到未提交数据、同一查询两次结果不同、幻行",
        "1. 进程有独立地址空间，线程共享\n2. 互相持有对方需要的锁\n3. 标记清除、复制、标记整理、分代",
        "1. 穿透查不存在数据、击穿热点key过期、雪崩大量key同时过期\n2. 多哈希函数的概率型数据结构\n3. Redis、ZooKeeper、数据库",
        "1. 全局解释器锁，保证同一时刻只有一个线程执行字节码\n2. 列表可变，元组不可变\n3. *args接收位置参数，**kwargs接收关键字参数",
    ],
    "analogy": ["就像图书馆的索引目录，快速定位书籍。", "好比快递分拣中心，按目的地分类。", "类似银行的叫号系统，保证顺序。",
        "缓存就像书桌，常用的东西放桌上（快），不常用的放书架（慢）。",
        "负载均衡好比餐厅领位员，把客人均匀分配到各个餐桌。",
        "熔断机制类似电路保险丝，电流过大时自动断开保护电器。",
    ],
    "endpoints": [
        "GET /api/v1/users - 获取用户列表\nPOST /api/v1/users - 创建用户\nPUT /api/v1/users/{id} - 更新用户\nDELETE /api/v1/users/{id} - 删除用户",
        "GET /api/v1/orders - 订单列表\nPOST /api/v1/orders - 创建订单\nGET /api/v1/orders/{id} - 订单详情\nPOST /api/v1/orders/{id}/cancel - 取消订单",
        "GET /api/v1/products - 商品列表\nPOST /api/v1/products - 上架商品\nGET /api/v1/products/{id}/stock - 库存查询",
        "POST /api/v1/auth/login - 登录\nPOST /api/v1/auth/register - 注册\nPOST /api/v1/auth/refresh - 刷新token",
        "GET /api/v1/metrics - 系统指标\nGET /api/v1/health - 健康检查\nGET /api/v1/logs - 日志查询",
        "GET /api/v1/payments - 支付记录\nPOST /api/v1/payments - 发起支付\nPOST /api/v1/payments/{id}/refund - 退款\nGET /api/v1/payments/{id}/status - 支付状态",
        "POST /api/v1/upload - 文件上传\nGET /api/v1/files/{id} - 文件下载\nDELETE /api/v1/files/{id} - 删除文件",
        "GET /api/v1/search - 全文搜索\nGET /api/v1/suggest - 搜索建议\nPOST /api/v1/index - 重建索引",
    ],
    "sql_query": [
        "SELECT u.id, u.name, COUNT(o.id) as order_count, SUM(o.total) as total_spent FROM users u LEFT JOIN orders o ON u.id = o.user_id WHERE o.status = 'paid' AND u.created_at > '2026-01-01' GROUP BY u.id, u.name HAVING COUNT(o.id) > 5 ORDER BY total_spent DESC LIMIT 100",
        "UPDATE inventory SET stock = stock - :quantity WHERE product_id = :pid AND stock >= :quantity",
        "SELECT DATE(created_at) as day, COUNT(*) as cnt, AVG(response_time) as avg_time FROM api_logs WHERE created_at >= NOW() - INTERVAL 7 DAY GROUP BY DATE(created_at) ORDER BY day",
        "DELETE FROM sessions WHERE expires_at < NOW()",
        "WITH monthly_sales AS (SELECT DATE_TRUNC('month', created_at) as month, SUM(amount) as total FROM orders WHERE status='paid' GROUP BY 1) SELECT month, total, LAG(total) OVER (ORDER BY month) as prev_month, ROUND((total - LAG(total) OVER (ORDER BY month)) / LAG(total) OVER (ORDER BY month) * 100, 2) as growth_pct FROM monthly_sales",
    ],
    "schema": [
        "用户表：id(BIGINT PK), username(VARCHAR 50), email(VARCHAR 100), created_at(DATETIME)",
        "订单表：id(BIGINT PK), user_id(BIGINT FK), amount(DECIMAL 10,2), status(TINYINT), created_at(DATETIME)",
        "商品表：id(BIGINT PK), name(VARCHAR 200), price(DECIMAL 10,2), stock(INT), category_id(BIGINT FK)",
        "日志表：id(BIGINT PK), level(VARCHAR 10), message(TEXT), user_id(BIGINT), created_at(DATETIME), INDEX(level, created_at)",
        "{\"type\":\"object\",\"properties\":{\"name\":{\"type\":\"string\"},\"age\":{\"type\":\"integer\"}},\"required\":[\"name\"]}",
        "CREATE TABLE orders (id BIGINT PRIMARY KEY AUTO_INCREMENT, user_id BIGINT NOT NULL, amount DECIMAL(10,2) DEFAULT 0, status TINYINT DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_user_status(user_id, status), FOREIGN KEY (user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "用户行为日志: user_id(BIGINT), event_type(VARCHAR 32), page_url(VARCHAR 500), referrer(VARCHAR 500), user_agent(VARCHAR 255), ip(VARCHAR 45), created_at(DATETIME), 分区键: created_at按月分区",
    ],
    "complexity": ["O(n log n)", "O(n)", "O(n^2)", "O(log n)", "O(1)", "O(n*m)"],
    "translation": [
        "Hello, how are you? → 你好，你好吗？",
        "The quick brown fox jumps over the lazy dog. → 敏捷的棕色狐狸跳过懒狗。",
        "机器学习是人工智能的一个分支。→ Machine learning is a branch of artificial intelligence.",
        "分布式系统由多台独立计算机协同工作，对外呈现为一个整体。→ A distributed system consists of multiple independent computers working together, appearing as a single system.",
        "代码审查是提升软件质量的重要手段。→ Code review is an important means of improving software quality.",
        "早期发现的错误修复成本越低。→ The earlier a bug is found, the lower the cost to fix it.",
    ],
    "feedback": [
        "用户反映页面加载慢，特别是首页",
        "客服收到大量投诉，集中在支付环节",
        "NPS评分从40降到30，需重视",
        "应用商店评分从4.5降到3.8",
        "测试团队发现边界条件未覆盖，建议补充用例",
        "DBA反馈慢查询增多，TOP10全是订单相关SQL",
    ],
    "output": [
        "处理完成，结果已保存。",
        "生成成功，共100条记录。",
        "分析完毕，发现3个问题。",
        "导出完成，文件大小2.3MB。",
        "部署成功，服务已重启，健康检查通过。",
    ],
    # 输出模板常用占位符
    "title": [
        "《星尘降临》", "《归途》",
        "深入理解MySQL索引原理与优化",
        "Kafka高可用架构设计实战",
        "从0到1搭建可观测性平台",
        "分布式锁的八种实现方式对比",
    ],
    "story": [
        "一段关于抉择与成长的故事正文。",
        "在末世废土中，幸存者寻找希望的旅程。",
        "程序员穿越到古代，用技术改变世界。",
    ],
    "poem": [
        "床前明月光，疑是地上霜。",
        "春眠不觉晓，处处闻啼鸟。",
        "大漠孤烟直，长河落日圆。",
        "海内存知己，天涯若比邻。",
    ],
    "script": [
        "甲：你真的要走？\n乙：嗯。",
        "产品：这个需求很简单\n开发：有多简单？\n产品：就加个按钮",
        "面试官：说一下你的缺点\n候选人：太追求完美\n面试官：举个例子\n候选人：我还没想好",
        "A：系统又崩了\nB：上次不是修好了吗\nA：修好了新的bug",
    ],
    "continuation": [
        "他抬起头，望向远方，做出了决定。",
        "就在这时，警报声突然响起。",
        "她微微一笑，转身离开了房间。",
        "代码编译通过，测试全绿，终于可以下班了。",
    ],
    "body": [
        "这款耳机降噪深度达 -42dB，久戴不累。",
        "本周完成了任务生成器扩展，新增20种任务类型。",
        "系统于14:30出现P0故障，影响支付功能，15:00恢复。",
        "请查收附件中的季度报告，如有问题随时沟通。",
        "代码审查发现3个安全漏洞，已分配给对应负责人修复。",
    ],
    "cta": ["立即抢购", "点击了解更多", "免费试用", "预约演示"],
    "copy": [
        "写给职场新人的一段话。",
        "这款产品采用最新技术，性能提升3倍，价格不变。",
        "限时优惠，买一送一，活动截止本周末。",
        "用户好评率99%，已有10万人选择。",
    ],
    "article": [
        "长文正文段落。",
        "在微服务架构下，服务间通信是核心挑战。本文从同步、异步、事件驱动三种模式出发，分析各自适用场景。",
        "性能优化是一个持续的过程。本文介绍了从数据库、缓存、代码三个层面的优化实践。",
    ],
    "detail": [
        "· 音质清晰\n· 续航持久",
        "· 降噪深度-42dB\n· 续航30小时\n· 蓝牙5.3\n· 重量4.5g",
        "· 8核CPU\n· 16GB内存\n· 512GB SSD\n· 4G独立显卡",
        "第一段：定义函数并初始化结果字典\n第二段：遍历用户列表，筛选活跃用户并存入字典\n第三段：返回结果字典\n注意：使用get方法避免KeyError",
        "1. 导入必要模块（json, hashlib, datetime）\n2. 定义数据模型类，包含字段验证\n3. 实现CRUD方法，每个方法包含异常处理\n4. 添加单元测试，覆盖正常和边界情况",
        "核心逻辑：使用双指针法，时间复杂度O(n)，空间复杂度O(1)\n边界条件：空数组返回0，单元素数组返回1\n优化点：提前终止，当两指针相遇时停止",
    ],
    "names": ["晨雾, 林间", "星野, 沐光", "汐沫, 清风", "云深, 归鹤"],
    "meanings": [
        "寓意清新自然",
        "象征希望与新生",
        "代表坚韧与勇气",
        "寓意智慧与宁静",
    ],
    "slogans": ["让改变发生", "一步一脚印", "技术改变生活", "简单而强大"],
    "reply": [
        "我理解你的感受，慢慢说。",
        "这确实是个挑战，我们一起想办法。",
        "你已经做得很好了，不要太苛责自己。",
        "先深呼吸，我们一步步来解决。",
    ],
    "answer": [
        "光在真空中约 3e8 m/s。",
        "斜边长度为5（勾股定理3²+4²=5²）。",
        "概率是3/4（至少一个正面=1-全反=1-1/4）。",
        "时间复杂度O(n log n)，空间复杂度O(n)。",
        "CAP定理：一致性、可用性、分区容错性三者不可兼得。",
    ],
    "explanation": [
        "递归就是函数在内部调用自身，需要基线条件终止。",
        "索引类似书的目录，通过指针快速定位数据，避免全表扫描。",
        "死锁是两个线程互相持有对方需要的锁，都在等待对方释放。",
        "缓存穿透是查询不存在的数据，请求直接打到数据库。",
    ],
    "advice": [
        "先保证睡眠，再逐步调整节奏。",
        "把大任务拆成小步骤，每天完成一点。",
        "遇到困难及时求助，不要一个人硬扛。",
        "定期复盘总结，避免重复犯错。",
    ],
    "response": [
        "这种情绪是正常的，我们一起梳理。",
        "我听到了你的困扰，这确实不容易。",
        "你的感受是合理的，不要否定自己。",
        "我们可以一起找到解决办法。",
    ],
    "analysis": [
        "现象背后有三层原因：直接原因是连接池耗尽，根本原因是慢查询未释放连接，深层原因是缺少熔断降级。",
        "数据显示错误率在14:30开始飙升，与版本发布时间完全吻合，回滚后立即恢复。",
        "性能瓶颈在数据库层，TOP5慢查询占总耗时80%，其中3个缺少索引。",
        "内存泄漏定位到缓存模块，对象未从监听器注销，导致Full GC频繁。",
        "火焰图分析显示60%CPU消耗在JSON序列化，建议使用protobuf替代，预计可提升吞吐量2倍",
        "日志分析发现错误集中在支付回调接口，失败率15%，根因是第三方支付接口超时，建议增加异步重试和本地补偿",
        "对比测试表明：Redis缓存命中率从60%提升到90%后，数据库QPS下降70%，接口P99延迟从200ms降至50ms",
    ],
    "result": [
        "操作成功",
        "修复完成，验证通过，已上线",
        "优化后P99从500ms降到150ms",
        "数据迁移完成，10亿条零丢失",
        "测试通过，覆盖率85%",
    ],
    "cases": [
        "assert func(1,2)==3",
        "assert divide(10,2)==5",
        "assert reverse('abc')=='cba'",
        "with pytest.raises(ValueError): func(-1)",
        "assert merge_intervals([[1,3],[2,6],[8,10]])==[[1,6],[8,10]]",
        "assert binary_search([1,3,5,7,9], 7)==3",
        "assert binary_search([1,3,5,7,9], 4)==-1",
        "assert len(fib(10))==10",
        "with pytest.raises(ZeroDivisionError): divide(1,0)",
        "assert parse_email('test@example.com')=='test@example.com'",
    ],
    "regex_pattern": [
        r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
        r"^1[3-9]\d{9}$",
        r"^\d{4}-\d{2}-\d{2}$",
        r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$",
        r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
        r"^[\u4e00-\u9fa5]{2,10}$",
        r"https?://[^\s]+",
        r"#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})",
    ],
    "code_out": [
        "def add(a,b):\n    return a+b",
        "def fib(n):\n    if n<2: return n\n    return fib(n-1)+fib(n-2)",
        "class Stack:\n    def __init__(self): self.items=[]\n    def push(self,x): self.items.append(x)",
        "def binary_search(arr, target):\n    low, high = 0, len(arr) - 1\n    while low <= high:\n        mid = (low + high) // 2\n        if arr[mid] == target:\n            return mid\n        elif arr[mid] < target:\n            low = mid + 1\n        else:\n            high = mid - 1\n    return -1",
        "def merge_sort(arr):\n    if len(arr) <= 1:\n        return arr\n    mid = len(arr) // 2\n    left = merge_sort(arr[:mid])\n    right = merge_sort(arr[mid:])\n    return merge(left, right)\n\ndef merge(left, right):\n    result = []\n    i = j = 0\n    while i < len(left) and j < len(right):\n        if left[i] <= right[j]:\n            result.append(left[i])\n            i += 1\n        else:\n            result.append(right[j])\n            j += 1\n    result.extend(left[i:])\n    result.extend(right[j:])\n    return result",
        "import re\ndef extract_emails(text):\n    pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}'\n    return re.findall(pattern, text)",
    ],
    "refactored": [
        "def process_users(users):\n    return {u['id']: u['name'] for u in users if u.get('active')}",
        "async def fetch_with_retry(url, retries=3):\n    for i in range(retries):\n        try:\n            async with session.get(url, timeout=5) as resp:\n                return await resp.json()\n        except (TimeoutError, ConnectionError):\n            if i == retries - 1:\n                raise\n            await asyncio.sleep(2 ** i)",
        "from collections import OrderedDict\nclass LRUCache:\n    def __init__(self, capacity):\n        self.cache = OrderedDict()\n        self.capacity = capacity\n    def get(self, key):\n        if key in self.cache:\n            self.cache.move_to_end(key)\n            return self.cache[key]\n        return -1\n    def put(self, key, value):\n        self.cache[key] = value\n        self.cache.move_to_end(key)\n        if len(self.cache) > self.capacity:\n            self.cache.popitem(last=False)",
        "import random\ndef quicksort(arr):\n    if len(arr) <= 1:\n        return arr\n    pivot = random.choice(arr)\n    left = [x for x in arr if x < pivot]\n    mid = [x for x in arr if x == pivot]\n    right = [x for x in arr if x > pivot]\n    return quicksort(left) + mid + quicksort(right)",
        "def merge_intervals(intervals):\n    if not intervals:\n        return []\n    intervals.sort(key=lambda x: x[0])\n    merged = [intervals[0]]\n    for start, end in intervals[1:]:\n        if start <= merged[-1][1]:\n            merged[-1][1] = max(merged[-1][1], end)\n        else:\n            merged.append([start, end])\n    return merged",
    ],
    "opt_code": [
        "# 原: O(n²) → 优化后: O(n)\nseen=set()\nfor x in arr:\n    if x in seen: return x\n    seen.add(x)",
        "# 使用列表推导式替代循环\nresult = [x*2 for x in data if x>0]",
        "# 预计算避免重复计算\nn=len(data)\ntotal=sum(data)\navg=total/n",
        "# 使用生成器减少内存\ndef process(items):\n    for item in items:\n        yield transform(item)",
        "# 批量查询替代N+1\nids=[u.id for u in users]\nprofiles=db.query('SELECT * FROM profiles WHERE id=ANY(%s)', ids)",
    ],
    "gain": [
        "耗时下降约 40%",
        "内存占用减少50%",
        "吞吐量提升3倍",
        "代码行数减少40%",
        "P99延迟从500ms降至150ms（降幅70%）",
        "CPU使用率从90%降至45%，同时QPS从1000提升到3000",
        "数据库查询时间从2s降至50ms，通过添加复合索引",
        "内存泄漏修复后，服务连续运行72小时无OOM，内存稳定在2GB",
    ],
    "chart": [
        "折线图",
        "柱状图",
        "饼图",
        "散点图",
        "热力图",
    ],
    "mapping": [
        "x=时间, y=销售额",
        "x=月份, y=用户数",
        "x=版本, y=错误率",
        "x=并发数, y=响应时间",
        "x轴: 日期(2026-01至2026-10), y轴左: 日活用户数(柱状), y轴右: 留存率(折线)",
        "维度: 地区(华东/华南/华北), 指标: 销售额(求和), 对比: 同比增长率",
    ],
    "aggregated": [
        "{部门: 100万}",
        "{2026-01: 500, 2026-02: 600, 2026-03: 750}",
        "{成功: 95%, 失败: 5%}",
        "地区,销售额,订单数,客单价\n华东,250万,5000,500\n华南,180万,3600,500\n华北,150万,3000,500\n西南,80万,2000,400",
        "{'total_users': 15234, 'active_users': 8921, 'new_users': 1203, 'churn_rate': '5.2%', 'avg_session': '12.5min'}",
        "按小时聚合: [{'hour': '00', 'count': 120}, {'hour': '01', 'count': 85}, {'hour': '02', 'count': 45}, {'hour': '03', 'count': 30}]",
    ],
    "annotations": ["情感=积极", "实体=人名", "关键词=性能优化", "类别=技术",
        "文本: '这款手机拍照很好，续航也不错' → 情感: 积极, 实体: 手机(产品), 关键词: 拍照,续航, 类别: 电子产品评价",
        "文本: '订单支付失败，客服没人理' → 情感: 消极, 实体: 订单(业务),客服(角色), 关键词: 支付失败,客服, 类别: 投诉",
        "label: spam, confidence: 0.95, reason: 包含推广链接和诱导性用语",
    ],
    "insights": ["用户更关注速度而非功能", "移动端用户占比60%", "高峰时段在晚上8-10点", "新用户留存率30%",
        "周末订单量比工作日高35%，但客单价低15%",
        "使用优惠券的用户复购率比未使用者高2.3倍",
        "页面加载时间每增加1秒，转化率下降7%",
        "80%的用户投诉集中在支付和物流两个环节",
    ],
    "sample": [
        "采样出的若干行数据。",
        "id,name,age\n1,张三,25\n2,李四,30",
        "{\"user_id\": 123, \"action\": \"login\", \"timestamp\": \"2026-10-01T10:00:00\"}",
        "order_id,user_id,amount,status,created_at\n1001,501,299.00,paid,2026-10-01 10:30:00\n1002,502,158.50,pending,2026-10-01 10:31:00\n1003,501,89.90,paid,2026-10-01 10:32:00",
        "[{\"id\":1,\"name\":\"iPhone 15\",\"price\":5999,\"stock\":120},{\"id\":2,\"name\":\"MacBook Pro\",\"price\":14999,\"stock\":45}]",
        "2026-10-01,100.5,200,15.2\n2026-10-02,101.2,180,18.7\n2026-10-03,99.8,220,12.1",
    ],
    "desensitized": ["脱敏后的数据。", "手机号: 138****1234", "身份证: 440***********1234",
        "name: 张*, phone: 138****1234, email: zhang***@example.com, id_card: 440***********1234",
        "原始: 张三,13812345678,440101199001011234 → 脱敏: 张*,138****5678,440101********1234",
        "IP地址: 192.168.1.*, MAC地址: AA:BB:CC:**:**:**, 银行卡: 6222 **** **** 1234",
    ],
    "stdout": ["total 0", "Process finished with exit code 0", "Building... 100%",
        "✓ 3 passed, 0 failed in 0.45s",
        "2026-10-06 08:30:00 INFO  Starting server on port 8080\n2026-10-06 08:30:01 INFO  Connected to database\n2026-10-06 08:30:01 INFO  Ready to accept connections",
        "NAME                STATUS              PORTS\nnginx               Up 2 hours          0.0.0.0:80->80/tcp\nredis               Up 2 hours          6379/tcp\nmysql               Up 2 hours          3306/tcp",
    ],
    "status": ["已发送", "处理中", "已完成", "失败", "pending", "processing", "completed", "failed", "cancelled", "待审核", "已通过", "已拒绝"],
    "flow": [
        "注册→登录→授权→使用",
        "下单→支付→发货→签收→评价",
        "提交→审核→驳回→修改→通过→发布",
        "报警→定位→修复→验证→复盘",
        "需求分析→方案设计→编码实现→单元测试→代码审查→集成测试→灰度发布→全量上线",
        "数据采集→数据清洗→特征工程→模型训练→模型评估→模型部署→监控反馈",
    ],
    "report": [
        "发现2处中风险问题。",
        "安全扫描完成：0高危，3中危，5低危。",
        "性能测试报告：P99=180ms，吞吐量=5000QPS。",
        "代码审查报告：10个文件，发现5个问题，已修复3个。",
        "数据清洗报告：原始数据10000条，删除空值行230条，修正格式错误156处，去重89条，最终有效数据9525条",
        "安全审计报告：审计范围覆盖5个微服务，发现SQL注入漏洞1个（高危）、XSS漏洞2个（中危）、敏感信息泄露3处（低危），已全部修复并补充测试用例",
        "性能分析报告：压测1000并发，P50=45ms，P99=320ms，P999=1.2s，错误率0.02%，瓶颈在数据库连接池（建议从100调整到200）",
    ],
    "doc": [
        "## GET /api/v1/users\n获取用户列表\n\n### 参数\n- page: 页码\n- size: 每页数量",
        "## 部署文档\n1. 拉取镜像\n2. 配置环境变量\n3. 执行kubectl apply",
        "## 接口说明\nGET /users 返回用户列表\n### 参数\n- page: 页码\n- size: 每页条数",
        "## 数据库设计文档\n用户表: id BIGINT PK, username VARCHAR(50), created_at DATETIME\n索引: idx_username(username)",
    ],
    "manual": [
        "1. 打开APP\n2. 点击注册\n3. 填写信息\n4. 验证邮箱\n5. 完成注册",
        "1. 登录后台\n2. 进入设置页\n3. 修改密码\n4. 保存",
        "1. 登录系统\n2. 进入管理后台\n3. 点击导出按钮\n4. 选择导出格式\n5. 下载文件",
        "1. 接入SDK\n2. 配置API Key\n3. 初始化客户端\n4. 调用接口\n5. 处理返回结果",
    ],
    "readme": [
        "# 汐沫AI任务调度\n\n## 功能\n- 113种任务类型\n- 多模型协同\n- 自动重试",
        "# 数据平台\n\n## 快速开始\n```bash\npip install -r requirements.txt\npython main.py\n```",
        "# 汐沫AI任务调度系统\n## 快速开始\n```bash\npip install -r requirements.txt\npython app.py\n```",
        "# 高并发秒杀系统\n## 架构\n- 网关层限流\n- 缓存层预扣库存\n- 消息队列异步下单\n## 启动\n```bash\ndocker-compose up -d\n```",
    ],
    "changelog": [
        "## v0.5\n- 新增任务生成器",
        "## v1.0\n- 重构调度引擎\n- 支持多智能体\n- 性能提升3倍",
        "## v1.1\n- 修复内存泄漏\n- 优化数据库查询\n- 新增监控告警",
        "## v1.0.0\n- 初始版本发布\n- 支持113种任务类型\n## v1.1.0\n- 性能优化50%\n- 修复已知bug",
        "## v2.0.0\n- 引入向量数据库\n- 支持语义检索\n- 重构任务路由\n- 破坏性变更: 配置文件格式更新",
    ],
}


class TestGeneratorTool(BaseTool):
    """
    测试代码生成工具类。
    
    支持从Python源码中解析函数并生成pytest测试用例，
    以及模拟覆盖率、运行和变异测试功能。
    """

    name: str = "test_generator"
    description: str = "测试代码生成工具"
    version: str = "2.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """
        初始化测试生成工具。
        """
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()
        # 任务类型索引：type_key -> TaskTypeSpec，类别 -> [TaskTypeSpec]
        self._by_key: Dict[str, TaskTypeSpec] = {
            s.type_key: s for s in TASK_TYPE_REGISTRY
        }
        self._by_category: Dict[str, List[TaskTypeSpec]] = {}
        for spec in TASK_TYPE_REGISTRY:
            self._by_category.setdefault(spec.category, []).append(spec)

    def _setup_parameters(self) -> None:
        """
        注册参数定义。
        """
        self.add_parameter(
            "action", str, required=True,
            choices=[
                "generate", "coverage", "run", "mutate",
                "list_types", "get_type", "generate_case", "route",
            ],
            description="操作类型"
        )
        self.add_parameter("code", str, required=False, default="", description="源代码")
        self.add_parameter("framework", str, required=False, default="pytest", choices=["pytest", "unittest", "jest", "junit"], description="测试框架")
        self.add_parameter("file", str, required=False, default="", description="文件路径")
        self.add_parameter("type_key", str, required=False, default="", description="任务类型英文键")
        self.add_parameter("category", str, required=False, default="", description="任务大类名")
        self.add_parameter("count", int, required=False, default=1, description="生成用例数量")
        self.add_parameter("seed", int, required=False, default=0, description="随机种子（0为不固定）")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """
        执行测试生成操作。
        
        Args:
            **kwargs: 工具参数。
            
        Returns:
            操作结果字典。
            
        Raises:
            ToolError: 当操作无效或解析失败时抛出。
        """
        action: str = str(kwargs.get("action", ""))
        
        if action == "generate":
            return self._generate_test_code(kwargs)
        if action == "coverage":
            return self._simulate_coverage()
        if action == "run":
            return self._simulate_run()
        if action == "mutate":
            return self._simulate_mutation()
        if action == "list_types":
            return self._list_task_types(kwargs)
        if action == "get_type":
            return self._get_task_type(kwargs)
        if action == "generate_case":
            return self._generate_test_case(kwargs)
        if action == "route":
            return self._route_task(kwargs)

        raise ToolError(f"未知操作: {action}", code=1002)

    def _generate_test_code(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        生成测试代码。
        
        如果未提供code，尝试从file读取。解析AST提取函数名并生成测试模板。
        
        Args:
            kwargs: 包含code, file, framework的参数。
            
        Returns:
            包含生成代码的字典。
            
        Raises:
            ToolError: 当无法获取代码或语法错误时抛出。
        """
        code: str = str(kwargs.get("code", ""))
        file_path: str = str(kwargs.get("file", ""))
        framework: str = str(kwargs.get("framework", "pytest"))
        
        if not code and file_path:
            path = Path(file_path)
            if not path.exists():
                raise ToolError(f"文件不存在: {file_path}", code=1005)
            try:
                code = path.read_text(encoding="utf-8", errors="replace")
            except OSError as e:
                raise ToolError(f"读取文件失败: {e}", code=1006) from e
        
        if not code:
            raise ToolError("需要提供code或file", code=1002)
        
        try:
            tree: ast.Module = ast.parse(code)
            functions: List[str] = [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
        except SyntaxError as e:
            raise ToolError(f"代码语法错误: {e}", code=1008) from e
        
        test_cases: List[str] = []
        for func_name in functions:
            test_cases.append(f"def test_{func_name}():\n    assert True # TODO: implement")
        
        header = "import pytest\n\n" if framework == "pytest" else "import unittest\n\n"
        generated_code: str = header + "\n\n".join(test_cases)
        
        return {
            "test_code": generated_code,
            "functions_found": len(functions),
            "function_names": functions,
            "framework": framework
        }

    def _simulate_coverage(self) -> Dict[str, Any]:
        """
        模拟覆盖率分析结果。
        
        Returns:
            覆盖率统计数据。
        """
        return {"coverage_percent": 85.5, "lines_total": 200, "lines_covered": 171, "uncovered_lines": [15, 23, 45]}

    def _simulate_run(self) -> Dict[str, Any]:
        """
        模拟测试运行结果。
        
        Returns:
            测试结果统计。
        """
        return {"passed": 15, "failed": 0, "skipped": 1, "total_time_s": 2.5}

    def _simulate_mutation(self) -> Dict[str, Any]:
        """
        模拟变异测试结果。
        
        Returns:
            变异测试统计。
        """
        return {"total_mutants": 50, "killed": 42, "survived": 8, "score_percent": 84.0}

    def _list_task_types(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        列出全部或指定大类的任务类型。

        Args:
            kwargs: 可选 category 过滤。

        Returns:
            按大类分组的任务类型列表及统计。
        """
        category: str = str(kwargs.get("category", "") or "")
        groups: Dict[str, List[Dict[str, Any]]] = {}
        for spec in TASK_TYPE_REGISTRY:
            if category and spec.category != category:
                continue
            groups.setdefault(spec.category, []).append({
                "type_key": spec.type_key, "name": spec.name,
                "difficulty": spec.difficulty, "routing_hint": spec.routing_hint,
            })
        return {
            "total_types": sum(len(v) for v in groups.values()),
            "category_count": len(groups),
            "categories": groups,
        }

    def _get_task_type(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        按 type_key 获取单个任务类型的完整规格。

        Args:
            kwargs: 含 type_key。

        Returns:
            任务类型规格字典。

        Raises:
            ToolError: 当 type_key 缺失或不存在时抛出。
        """
        key: str = str(kwargs.get("type_key", "") or "")
        if not key:
            raise ToolError("get_type 需要 type_key 参数", code=1002)
        spec = self._by_key.get(key)
        if spec is None:
            raise ToolError(f"未知任务类型: {key}", code=1004)
        return {"spec": spec.to_dict()}

    def _fill_template(self, template: str, rng: random.Random) -> str:
        """
        用样例值池填充模板中的 {placeholder}。

        Args:
            template: 含占位符的模板字符串。
            rng: 随机数生成器，保证可复现。

        Returns:
            填充后的字符串。
        """
        pool = _SAMPLE_POOL

        class _Map(dict):
            def __missing__(self, key: str) -> str:  # type: ignore[override]
                vals = pool.get(key)
                return rng.choice(vals) if vals else "{" + key + "}"

        try:
            return template.format_map(_Map())
        except (IndexError, KeyError, ValueError):
            return template

    def _generate_test_case(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        按类型随机生成测试用例。

        可选 type_key 指定类型，或 category 指定大类；都不给则全库随机。

        Args:
            kwargs: 含 type_key/category/count/seed。

        Returns:
            生成的用例列表。

        Raises:
            ToolError: 当指定类型或大类不存在时抛出。
        """
        count: int = max(1, int(kwargs.get("count", 1) or 1))
        seed: int = int(kwargs.get("seed", 0) or 0)
        rng = random.Random(seed) if seed else random.Random()
        type_key: str = str(kwargs.get("type_key", "") or "")
        category: str = str(kwargs.get("category", "") or "")

        if type_key:
            spec = self._by_key.get(type_key)
            if spec is None:
                raise ToolError(f"未知任务类型: {type_key}", code=1004)
            candidates: List[TaskTypeSpec] = [spec]
        elif category:
            candidates = self._by_category.get(category, [])
            if not candidates:
                raise ToolError(f"未知任务大类: {category}", code=1004)
        else:
            candidates = list(TASK_TYPE_REGISTRY)

        cases: List[Dict[str, Any]] = []
        for _ in range(count):
            spec = rng.choice(candidates)
            cases.append({
                "type_key": spec.type_key,
                "name": spec.name,
                "category": spec.category,
                "difficulty": spec.difficulty,
                "estimated_duration_s": spec.estimated_duration_s,
                "input": self._fill_template(spec.input_template, rng),
                "expected_output_template": self._fill_template(spec.output_template, rng),
                "routing_hint": spec.routing_hint,
            })
        return {"requested_count": count, "generated": len(cases), "cases": cases}

    def _route_task(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        把任务类型转成父任务模型可消费的调度负载。

        输出三段式：intent（意图识别）、decomposition（任务拆解，
        与 ParentTask.build_task_tree 的模块列表同构）、routing（路由决策）。

        Args:
            kwargs: 含 type_key。

        Returns:
            父任务兼容的调度负载。

        Raises:
            ToolError: 当 type_key 缺失或不存在时抛出。
        """
        type_key: str = str(kwargs.get("type_key", "") or "")
        if not type_key:
            raise ToolError("route 需要 type_key 参数", code=1002)
        spec = self._by_key.get(type_key)
        if spec is None:
            raise ToolError(f"未知任务类型: {type_key}", code=1004)

        # 意图识别：来自任务类型规格
        intent: Dict[str, Any] = {
            "type_key": spec.type_key, "name": spec.name,
            "category": spec.category, "description": spec.description,
        }
        # 任务拆解：基础模块 + 三步子任务（与 ParentTask 模块列表同构）
        base = f"{spec.name}-基础准备"
        decomposition: List[Dict[str, Any]] = [
            {"name": base, "desc": f"准备{spec.name}所需的输入与上下文", "deps": []},
            {"name": f"{spec.name}-执行", "desc": spec.description, "deps": [base]},
            {"name": f"{spec.name}-验收", "desc": f"按{spec.difficulty}难度验收{spec.name}结果", "deps": [f"{spec.name}-执行"]},
        ]
        # 路由决策：执行域/难度/模式/时长
        mode = {"simple": "fast", "medium": "standard", "hard": "deep"}.get(spec.difficulty, "standard")
        routing: Dict[str, Any] = {
            "executor": spec.routing_hint,
            "difficulty": spec.difficulty,
            "running_mode": mode,
            "estimated_duration_s": spec.estimated_duration_s,
        }
        return {"parent_task_compatible": True, "intent": intent, "decomposition": decomposition, "routing": routing}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        执行工具调用。
        
        Args:
            params: 参数字典。
            
        Returns:
            标准化响应。
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1
        
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._error(str(validated), 1002, start)
            
            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
            if len(self._history) > 100:
                self._history.pop(0)
            
            return {
                "success": True,
                "data": result,
                "error": None,
                "execution_time": elapsed,
                "tool": self.name,
                "version": self.version,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
        except ToolError as e:
            self._stats["fail"] += 1
            return self._error(e.message, e.code, start, getattr(e, 'details', None))
        except Exception:
            self._stats["fail"] += 1
            logger.error("TestGeneratorTool 内部错误", exc_info=True)
            return self._error("内部错误", 1006, start)

    def _error(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        构建错误响应。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """
        获取统计信息，包含平均值和成功率。
        
        Returns:
            统计字典。
        """
        ok_count: int = int(self._stats["ok"])
        total_calls: int = int(self._stats["calls"])
        avg_time: float = self._stats["time"] / ok_count if ok_count > 0 else 0.0
        success_rate: float = ok_count / max(1, total_calls)
        
        return {
            **self._stats,
            "avg_time_s": round(avg_time, 4),
            "success_rate_percent": round(success_rate * 100, 2)
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        获取最近的历史记录。
        
        Args:
            limit: 获取条数。
            
        Returns:
            历史记录列表。
        """
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """
        获取工具描述符。
        
        Returns:
            包含元数据的字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }

    def __repr__(self) -> str:
        """
        返回工具的字符串表示。
        
        Returns:
            表示字符串。
        """
        return f"<TestGeneratorTool v{self.version} calls={self._stats['calls']}>"