from __future__ import annotations

import logging
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from src.ximu.agents.tools.base import BaseTool, ToolError

logger: logging.Logger = logging.getLogger("ximu.tool")


def _execute_git_command(repo: str, *args: str) -> Tuple[str, str, int]:
    """执行Git命令并返回结果。"""
    try:
        result = subprocess.run(
            ["git", "-C", repo] + list(args),
            capture_output=True,
            text=True,
            timeout=30
        )
        return result.stdout.strip(), result.stderr.strip(), result.returncode
    except subprocess.TimeoutExpired:
        raise ToolError("Git命令执行超时", code=1004)


class GitOperationsTool(BaseTool):
    """Git操作工具。"""

    name: str = "git_operations"
    description: str = "Git操作工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: list = ["development", "devops", "tools"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化GitOperationsTool实例。"""
        super().__init__()
        self._history: list = []
        self._stats: Dict[str, Any] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数定义。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=["clone", "commit", "push", "pull", "branch", "merge", "status", "log", "diff", "stash", "tag", "rebase"],
            description="操作",
        )
        self.add_parameter("repo", str, required=False, default=".", description="仓库路径")
        self.add_parameter("message", str, required=False, default="", description="提交信息")
        self.add_parameter("branch", str, required=False, default="", description="分支名")
        self.add_parameter("remote", str, required=False, default="origin", description="远程名")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行Git操作。"""
        action: str = kwargs.get("action", "")
        repo: str = kwargs.get("repo", ".")

        if not Path(repo).exists():
            raise ToolError("仓库路径不存在", code=1005)

        dispatch_map: Dict[str, Any] = {
            "clone": lambda: self._handle_clone(kwargs),
            "commit": lambda: self._handle_commit(repo, kwargs),
            "push": lambda: self._handle_push(repo, kwargs),
            "pull": lambda: self._handle_pull(repo),
            "branch": lambda: self._handle_branch(repo, kwargs),
            "merge": lambda: self._handle_merge(repo, kwargs),
            "status": lambda: self._handle_status(repo),
            "log": lambda: self._handle_log(repo),
            "diff": lambda: self._handle_diff(repo),
            "stash": lambda: self._handle_stash(repo),
            "tag": lambda: self._handle_tag(repo, kwargs),
            "rebase": lambda: self._handle_rebase(repo, kwargs),
        }

        handler = dispatch_map.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _handle_clone(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理克隆操作。"""
        url: str = kwargs.get("message", "")
        repo: str = kwargs.get("repo", ".")
        if not url:
            raise ToolError("需要 url 参数", code=1002)
        result = subprocess.run(["git", "clone", url, repo], capture_output=True, text=True, timeout=60)
        return {"cloned": result.returncode == 0, "url": url, "output": result.stdout[:500]}

    def _handle_commit(self, repo: str, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理提交操作。"""
        msg: str = kwargs.get("message", "update")
        out, err, rc = _execute_git_command(repo, "commit", "-m", msg)
        return {"committed": rc == 0, "message": msg, "output": out[:500], "error": err[:200]}

    def _handle_push(self, repo: str, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理推送操作。"""
        branch: str = kwargs.get("branch", "main")
        remote: str = kwargs.get("remote", "origin")
        out, err, rc = _execute_git_command(repo, "push", remote, branch)
        return {"pushed": rc == 0, "branch": branch, "output": out[:500]}

    def _handle_pull(self, repo: str) -> Dict[str, Any]:
        """处理拉取操作。"""
        out, err, rc = _execute_git_command(repo, "pull")
        return {"pulled": rc == 0, "output": out[:500]}

    def _handle_branch(self, repo: str, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理分支操作。"""
        branch: str = kwargs.get("branch", "")
        if branch:
            out, err, rc = _execute_git_command(repo, "checkout", "-b", branch)
            return {"created": rc == 0, "branch": branch}
        out, _, _ = _execute_git_command(repo, "branch")
        return {"branches": out.split("\n")}

    def _handle_merge(self, repo: str, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理合并操作。"""
        branch: str = kwargs.get("branch", "")
        out, err, rc = _execute_git_command(repo, "merge", branch)
        return {"merged": rc == 0, "branch": branch, "output": out[:500]}

    def _handle_status(self, repo: str) -> Dict[str, Any]:
        """处理状态查询操作。"""
        out, _, _ = _execute_git_command(repo, "status", "--short")
        return {"status": out, "clean": not out}

    def _handle_log(self, repo: str) -> Dict[str, Any]:
        """处理日志查询操作。"""
        out, _, _ = _execute_git_command(repo, "log", "--oneline", "-20")
        lines: list = out.split("\n")
        return {"log": lines, "count": len(lines)}

    def _handle_diff(self, repo: str) -> Dict[str, Any]:
        """处理差异查询操作。"""
        out, _, _ = _execute_git_command(repo, "diff")
        return {"diff": out[:5000], "has_changes": bool(out)}

    def _handle_stash(self, repo: str) -> Dict[str, Any]:
        """处理暂存操作。"""
        out, _, _ = _execute_git_command(repo, "stash")
        return {"stashed": True, "output": out[:200]}

    def _handle_tag(self, repo: str, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理标签操作。"""
        tag: str = kwargs.get("branch", "")
        if tag:
            out, _, _ = _execute_git_command(repo, "tag", tag)
            return {"tagged": True, "tag": tag}
        out, _, _ = _execute_git_command(repo, "tag")
        return {"tags": out.split("\n")}

    def _handle_rebase(self, repo: str, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理变基操作。"""
        branch: str = kwargs.get("branch", "")
        out, err, rc = _execute_git_command(repo, "rebase", branch)
        return {"rebased": rc == 0, "branch": branch, "output": out[:500]}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具调用。"""
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated_params = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._create_error_response(str(validated_params), 1002, start_time)
            result = self.execute(**validated_params)
            elapsed: float = round(time.monotonic() - start_time, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._record_history(elapsed, True)
            return {
                "success": True,
                "data": result,
                "error": None,
                "execution_time": elapsed,
                "tool": self.name,
                "version": self.version,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
        except ToolError as e:
            self._stats["fail"] += 1
            return self._create_error_response(e.message, e.code, start_time, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._create_error_response("工具内部错误", 1006, start_time)

    def _record_history(self, elapsed: float, success: bool) -> None:
        """记录操作历史。"""
        self._history.append({
            "ts": datetime.now(timezone.utc).isoformat(),
            "ok": success,
            "t": elapsed
        })
        if len(self._history) > 100:
            self._history.pop(0)

    def _create_error_response(self, msg: str, code: int, start_time: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构造错误响应。"""
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "execution_time": round(time.monotonic() - start_time, 4),
            "details": details or {},
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
