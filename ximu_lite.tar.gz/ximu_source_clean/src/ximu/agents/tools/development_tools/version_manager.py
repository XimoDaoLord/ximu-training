"""版本管理工具模块。"""

from __future__ import annotations

import logging
import re
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")

# 常量定义
HISTORY_LIMIT: int = 100
ERROR_CODE_INVALID_ACTION: int = 1002
ERROR_CODE_INTERNAL_ERROR: int = 1006
DEFAULT_VERSION: str = "1.0.0"
DEFAULT_PART: str = "patch"
VALID_PARTS: Tuple[str, ...] = ("major", "minor", "patch")
VALID_ACTIONS: Tuple[str, ...] = ("bump", "get", "set", "compare", "history", "changelog")


class VersionManagerTool(BaseTool):
    """语义化版本管理工具。"""

    name: str = "version_manager"
    description: str = "版本管理工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"

    _SEMVER_RE: re.Pattern = re.compile(r"^\d+\.\d+\.\d+$")

    def __init__(self) -> None:
        """初始化版本管理工具。"""
        super().__init__()
        self._version: str = DEFAULT_VERSION
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数定义。"""
        self.add_parameter("action", str, required=True, choices=list(VALID_ACTIONS), description="操作")
        self.add_parameter("version", str, required=False, default="", description="版本号")
        self.add_parameter("part", str, required=False, default=DEFAULT_PART, choices=list(VALID_PARTS), description="版本部分")

    def _parse_semver(self, version_str: str) -> Tuple[int, int, int]:
        """解析 SemVer 字符串为三元组。

        Args:
            version_str: 版本字符串。

        Returns:
            (major, minor, patch) 三元组。

        Raises:
            ToolError: 当版本号格式无效时抛出。
        """
        if not self._SEMVER_RE.match(version_str):
            raise ToolError(f"无效版本号格式: {version_str}", code=ERROR_CODE_INVALID_ACTION, details={"invalid_version": version_str})
        return tuple(map(int, version_str.split(".")))

    def _format_semver(self, major: int, minor: int, patch: int) -> str:
        """将整数三元组格式化为 SemVer 字符串。

        Args:
            major: 主版本号。
            minor: 次版本号。
            patch: 修订版本号。

        Returns:
            格式化后的版本字符串。
        """
        return f"{major}.{minor}.{patch}"

    def _validate_action_params(self, action: str, version: str, part: str) -> None:
        """
        验证操作参数的有效性。

        Args:
            action: 操作类型。
            version: 版本号。
            part: 版本部分。

        Raises:
            ToolError: 当参数无效时抛出。
        """
        if action in ("set", "compare") and not version:
            raise ToolError("需要version参数", code=ERROR_CODE_INVALID_ACTION)
        if action == "bump" and part not in VALID_PARTS:
            raise ToolError(f"无效的版本部分: {part}", code=ERROR_CODE_INVALID_ACTION, details={"invalid_part": part})

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行版本管理操作。

        Args:
            **kwargs: 包含action, version, part等参数。

        Returns:
            操作结果字典。

        Raises:
            ToolError: 当操作未知时抛出。
        """
        action: str = kwargs.get("action", "")
        version: str = kwargs.get("version", "")
        part: str = kwargs.get("part", DEFAULT_PART)

        self._validate_action_params(action, version, part)

        handlers: Dict[str, Any] = {
            "get": self._handle_get,
            "set": lambda: self._handle_set(version),
            "bump": lambda: self._handle_bump(part),
            "compare": lambda: self._handle_compare(version),
            "history": self._handle_history,
            "changelog": self._handle_changelog,
        }
        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=ERROR_CODE_INVALID_ACTION, details={"unknown_action": action})
        return handler()

    def _handle_get(self) -> Dict[str, Any]:
        """处理获取当前版本操作。

        Returns:
            当前版本信息字典。
        """
        return {"version": self._version, "semver": True}

    def _handle_set(self, version: str) -> Dict[str, Any]:
        """处理设置版本操作。

        Args:
            version: 新版本号。

        Returns:
            设置结果字典。
        """
        self._parse_semver(version)
        self._version = version
        return {"version": version, "set": True}

    def _handle_bump(self, part: str) -> Dict[str, Any]:
        """处理递增版本操作。

        Args:
            part: 版本部分（major/minor/patch）。

        Returns:
            递增后版本信息字典。
        """
        major, minor, patch = self._parse_semver(self._version)
        if part == "major":
            major, minor, patch = major + 1, 0, 0
        elif part == "minor":
            minor, patch = minor + 1, 0
        else:
            patch += 1
        self._version = self._format_semver(major, minor, patch)
        return {"version": self._version, "bumped": part}

    def _handle_compare(self, version: str) -> Dict[str, Any]:
        """处理版本比较操作。

        Args:
            version: 要比较的版本号。

        Returns:
            比较结果字典。
        """
        v1 = self._parse_semver(self._version)
        v2 = self._parse_semver(version)
        if v1 > v2:
            result = "greater"
        elif v1 < v2:
            result = "less"
        else:
            result = "equal"
        return {"current": self._version, "compare_to": version, "result": result}

    def _handle_history(self) -> Dict[str, Any]:
        """处理获取版本历史操作。

        Returns:
            版本历史列表字典。
        """
        # 模拟历史数据，实际应存储真实历史
        history: List[Dict[str, Any]] = [
            {"version": DEFAULT_VERSION, "date": "2026-01-01", "changes": ["Initial release"]},
        ]
        return {"history": history, "count": len(history)}

    def _handle_changelog(self) -> Dict[str, Any]:
        """处理生成变更日志操作。

        Returns:
            变更日志字符串字典。
        """
        changelog: str = f"# Changelog\n## {self._version}\n- Initial release"
        return {"changelog": changelog, "version": self._version}

    def _build_result(self, success: bool, data: Optional[Dict[str, Any]], error: Optional[str], code: Optional[int], elapsed: float) -> Dict[str, Any]:
        """构建标准化结果字典。

        Args:
            success: 是否成功。
            data: 成功时的数据。
            error: 错误消息。
            code: 错误代码。
            elapsed: 执行耗时。

        Returns:
            标准化结果字典。
        """
        return {
            "success": success,
            "data": data,
            "error": error,
            "error_code": code,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具调用。

        Args:
            params: 参数字典，可为None。

        Returns:
            标准化结果字典。
        """
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._build_result(False, None, str(validated), ERROR_CODE_INVALID_ACTION, 0.0)
            result = self.execute(**validated)
            elapsed = round(time.monotonic() - start_time, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
            if len(self._history) > HISTORY_LIMIT:
                self._history.pop(0)
            return self._build_result(True, result, None, None, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            elapsed = round(time.monotonic() - start_time, 4)
            return self._build_result(False, None, e.message, e.code, elapsed)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            elapsed = round(time.monotonic() - start_time, 4)
            return self._build_result(False, None, "工具内部错误", ERROR_CODE_INTERNAL_ERROR, elapsed)
