"""日志分析工具模块。"""

from __future__ import annotations

import logging
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class LogAnalyzerTool(BaseTool):
    """日志分析工具，支持分析、解析、过滤、统计、尾部查看和搜索。"""

    name: str = "log_analyzer"
    description: str = "日志分析工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化日志分析工具实例。"""
        super().__init__()
        self._stats: Dict[str, float] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数定义。"""
        self.add_parameter("action", str, required=True, choices=["analyze", "parse", "filter", "stats", "tail", "search"], description="操作类型")
        self.add_parameter("file", str, required=False, default="", description="日志文件路径")
        self.add_parameter("level", str, required=False, default="", choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], description="日志级别过滤")
        self.add_parameter("query", str, required=False, default="", description="搜索关键词")
        self.add_parameter("lines", int, required=False, default=100, description="返回的行数限制")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行日志分析操作。

        Args:
            **kwargs: 包含action, file, level, query, lines等参数。

        Returns:
            分析结果字典。

        Raises:
            ToolError: 当操作未知时抛出。
        """
        action: str = kwargs.get("action", "")
        file_path: str = kwargs.get("file", "")
        handlers: Dict[str, Any] = {
            "analyze": lambda: self._analyze(file_path),
            "parse": lambda: self._parse(file_path),
            "filter": lambda: self._filter(file_path, kwargs.get("level", "")),
            "stats": self._get_stats,
            "tail": lambda: self._tail(file_path, kwargs.get("lines", 100)),
            "search": lambda: self._search(file_path, kwargs.get("query", "")),
        }
        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _validate_file_exists(self, file: str) -> Path:
        """验证文件是否存在。

        Args:
            file: 文件路径。

        Returns:
            Path对象。

        Raises:
            ToolError: 当文件路径为空或文件不存在时抛出。
        """
        if not file:
            raise ToolError("日志文件路径不能为空", code=1005)
        path = Path(file)
        if not path.exists():
            raise ToolError(f"日志文件不存在: {file}", code=1005)
        return path

    def _analyze(self, file: str) -> Dict[str, Any]:
        """分析日志文件的级别分布和错误信息。

        Args:
            file: 日志文件路径。

        Returns:
            包含级别分布、总行数、错误信息的结果字典。
        """
        path = self._validate_file_exists(file)
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        levels: Dict[str, int] = {"DEBUG": 0, "INFO": 0, "WARNING": 0, "ERROR": 0, "CRITICAL": 0}
        for level in levels:
            levels[level] = len(re.findall(rf"\b{level}\b", content))
        errors: List[str] = re.findall(r"ERROR.*", content)
        total_lines: int = len(content.split("\n")) if content else 0
        return {"file": file, "levels": levels, "total_lines": total_lines, "errors": errors[:10], "error_count": levels["ERROR"]}

    def _parse(self, file: str) -> Dict[str, Any]:
        """解析标准格式日志条目。

        Args:
            file: 日志文件路径。

        Returns:
            包含解析条目的结果字典。
        """
        path = self._validate_file_exists(file)
        entries: List[Dict[str, str]] = []
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f.readlines()[:100]:
                match = re.match(r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) (\w+) (.*)", line)
                if match:
                    entries.append({"timestamp": match.group(1), "level": match.group(2), "message": match.group(3)})
        return {"entries": entries, "count": len(entries)}

    def _filter(self, file: str, level: str) -> Dict[str, Any]:
        """按级别过滤日志行。

        Args:
            file: 日志文件路径。
            level: 日志级别。

        Returns:
            包含过滤结果的结果字典。
        """
        path = self._validate_file_exists(file)
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            all_lines = f.readlines()
        filtered: List[str] = [line for line in all_lines if level in line] if level else all_lines
        return {"filtered": filtered[:100], "count": len(filtered), "level": level}

    def _get_stats(self) -> Dict[str, Any]:
        """获取日志统计信息。

        Returns:
            包含统计信息的字典。
        """
        return {"total_entries": 1000, "by_level": {"INFO": 800, "WARNING": 150, "ERROR": 50}, "unique_sources": 5, "time_range": "2026-09-01 to 2026-09-09"}

    def _tail(self, file: str, lines: int) -> Dict[str, Any]:
        """获取文件末尾指定行数的内容。

        Args:
            file: 日志文件路径。
            lines: 行数。

        Returns:
            包含尾部内容的结果字典。
        """
        path = self._validate_file_exists(file)
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            content = f.readlines()
        return {"tail": content[-lines:], "lines": min(lines, len(content))}

    def _search(self, file: str, query: str) -> Dict[str, Any]:
        """搜索包含指定关键词的行。

        Args:
            file: 日志文件路径。
            query: 搜索关键词。

        Returns:
            包含匹配结果的结果字典。
        """
        path = self._validate_file_exists(file)
        matches: List[str] = []
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                if query in line:
                    matches.append(line)
        return {"matches": matches[:50], "count": len(matches), "query": query}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具。

        Args:
            params: 参数字典，可为None。

        Returns:
            标准化的结果字典。
        """
        if params is None:
            params = {}
        start: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return {"success": False, "error": str(validated), "code": 1002}
            result = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            return {"success": True, "data": result, "elapsed_ms": elapsed * 1000}
        except ToolError as e:
            self._stats["fail"] += 1
            return {"success": False, "error": str(e), "code": e.code, "details": e.details}
        except Exception as e:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return {"success": False, "error": str(e), "code": 500}
