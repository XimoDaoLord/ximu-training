"""代码仓库管理工具模块。支持仓库创建、Fork、Star、Watch及Issues管理。"""

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class CodeRepositoryTool(BaseTool):
    """代码仓库管理工具类。

    支持 create、fork、star、watch、issues、pull_requests、contributors、commits 操作。
    """

    name: str = "code_repository"
    description: str = "代码仓库管理工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化代码仓库管理工具。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """注册工具参数。"""
        self.add_parameter(
            "action", str, required=True,
            choices=["create", "fork", "star", "watch", "issues", "pull_requests", "contributors", "commits"],
            description="操作类型",
        )
        self.add_parameter("repo", str, required=False, default="", description="仓库名")
        self.add_parameter("owner", str, required=False, default="", description="所有者")

    def _create_repo(self, repo: str, owner: str) -> Dict[str, Any]:
        """创建仓库。

        Args:
            repo: 仓库名，不能为空。
            owner: 所有者名称，为空时使用默认值 "user"。

        Returns:
            包含创建结果、仓库信息的字典。

        Raises:
            ToolError: repo 为空时抛出。
        """
        if not repo:
            raise ToolError("需要repo", code=1002)
        owner_resolved: str = owner or "user"
        return {
            "created": True,
            "name": repo,
            "owner": owner_resolved,
            "url": f"https://github.com/{owner_resolved}/{repo}",
            "private": False,
        }

    def _fork_repo(self, repo: str, owner: str) -> Dict[str, Any]:
        """Fork 仓库。

        Args:
            repo: 仓库名。
            owner: 所有者。

        Returns:
            包含 Fork 结果的字典。
        """
        return {
            "forked": True,
            "original": f"{owner}/{repo}",
            "url": f"https://github.com/user/{repo}",
        }

    def _star_repo(self, repo: str) -> Dict[str, str]:
        """Star 仓库。

        Args:
            repo: 仓库名。

        Returns:
            包含 Star 结果的字典。
        """
        return {"starred": True, "repo": repo}

    def _watch_repo(self, repo: str) -> Dict[str, str]:
        """Watch 仓库。

        Args:
            repo: 仓库名。

        Returns:
            包含 Watch 结果的字典。
        """
        return {"watching": True, "repo": repo}

    def _get_issues(self) -> Dict[str, Any]:
        """获取 Issues 列表。

        Returns:
            包含 Issue 列表及总数的字典。
        """
        issues: List[Dict[str, Any]] = [
            {"number": i, "title": f"Issue {i}", "state": "open"}
            for i in range(1, 4)
        ]
        return {"issues": issues, "count": len(issues)}

    def _get_pull_requests(self) -> Dict[str, Any]:
        """获取 Pull Requests 列表。

        Returns:
            包含 PR 列表及总数的字典。
        """
        prs: List[Dict[str, Any]] = [
            {"number": i, "title": f"PR {i}", "state": "open"}
            for i in range(1, 3)
        ]
        return {"pull_requests": prs, "count": len(prs)}

    def _get_contributors(self) -> Dict[str, Any]:
        """获取 Contributors 列表。

        Returns:
            包含贡献者列表及总数的字典。
        """
        contributors: List[Dict[str, Any]] = [
            {"name": "dev1", "commits": 50},
            {"name": "dev2", "commits": 30},
        ]
        return {"contributors": contributors, "count": len(contributors)}

    def _get_commits(self) -> Dict[str, Any]:
        """获取 Commits 列表。

        Returns:
            包含提交列表及总数的字典。
        """
        commits: List[Dict[str, Any]] = [
            {
                "sha": "abc123",
                "message": "Initial commit",
                "author": "dev1",
                "date": "2026-09-01",
            }
        ]
        return {"commits": commits, "count": len(commits)}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """根据 action 分发并执行对应的仓库操作。

        Args:
            **kwargs: 包含 action、repo、owner 等参数。

        Returns:
            执行结果字典。

        Raises:
            ToolError: 当 action 无效时抛出。
        """
        action: str = kwargs.get("action", "")
        repo: str = kwargs.get("repo", "")
        owner: str = kwargs.get("owner", "")
        dispatch: Dict[str, Any] = {
            "create": lambda: self._create_repo(repo, owner),
            "fork": lambda: self._fork_repo(repo, owner),
            "star": lambda: self._star_repo(repo),
            "watch": lambda: self._watch_repo(repo),
            "issues": self._get_issues,
            "pull_requests": self._get_pull_requests,
            "contributors": self._get_contributors,
            "commits": self._get_commits,
        }
        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具，包含参数校验、错误处理和统计记录。

        Args:
            params: 输入参数字典，为 None 时视为空字典。

        Returns:
            包含 success、data、error 等字段的统一响应字典。
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(v), 1002, start)
            result: Dict[str, Any] = self.execute(**v)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed, True)
            return self._ok_resp(result, elapsed)
        except ToolError as err:
            self._stats["fail"] += 1
            return self._err(err.message, err.code, start, err.details)
        except Exception as exc:  # pylint: disable=broad-except
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _err(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构造错误响应字典。

        Args:
            msg: 错误消息。
            code: 错误代码。
            start: 操作开始时间戳（monotonic）。
            details: 错误详细信息。

        Returns:
            统一格式的错误响应字典。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _ok_resp(self, data: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """构造成功响应字典。

        Args:
            data: 业务数据字典。
            elapsed: 执行耗时（秒）。

        Returns:
            统一格式的成功响应字典。
        """
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, elapsed: float, ok: bool) -> None:
        """追加历史记录，超出限制时淘汰最旧记录。

        Args:
            elapsed: 执行耗时。
            ok: 是否成功。
        """
        self._history.append({
            "ts": datetime.now(timezone.utc).isoformat(),
            "ok": ok,
            "t": elapsed,
        })
        if len(self._history) > 100:
            self._history.pop(0)

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取工具调用统计信息。

        Returns:
            包含 calls、ok、fail、time、avg、rate 的字典。
        """
        ok: int = self._stats["ok"]
        avg: float = self._stats["time"] / ok if ok > 0 else 0.0
        rate: float = round(ok / max(1, self._stats["calls"]), 4)
        return {**self._stats, "avg": round(avg, 4), "rate": rate}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的操作历史记录。

        Args:
            limit: 返回记录的最大条数，默认10。

        Returns:
            最近 limit 条历史记录的列表。
        """
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具的完整描述符。

        Returns:
            包含名称、描述、版本、类别、标签、参数和统计信息的字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }

    def __repr__(self) -> str:
        """返回工具的可读表示字符串。

        Returns:
            工具的可读表示字符串。
        """
        return f"<{type(self).__name__} name={self.name} v{self.version}>"
