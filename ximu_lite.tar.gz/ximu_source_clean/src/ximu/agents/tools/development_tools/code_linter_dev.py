import logging
import time
from collections import deque
from datetime import datetime, timezone
from typing import Any, Deque, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class CodeLinterDevTool(BaseTool):
    """开发代码检查工具，支持lint、fix、rules等操作。"""

    name: str = "code_linter_dev"
    description: str = "开发代码检查工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "format", "lint"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化代码检查工具。"""
        super().__init__()
        self._history: Deque[Dict[str, Any]] = deque(maxlen=100)
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """注册工具参数。"""
        self.add_parameter("action", str, required=True, choices=["lint", "fix", "rules", "ignore", "report", "config"], description="操作类型")
        self.add_parameter("code", str, required=True, description="代码")
        self.add_parameter("linter", str, required=False, default="flake8", description="检查器")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行代码检查操作。"""
        action: str = kwargs.get("action", "")
        code: str = kwargs.get("code", "")
        linter: str = kwargs.get("linter", "flake8")
        if not code:
            raise ToolError("需要code", code=1002)
        handlers = {
            "lint": lambda: {"issues": [{"line": 5, "code": "E501", "message": "line too long"}], "errors": 0, "warnings": 1, "linter": linter},
            "fix": lambda: {"fixed": 3, "remaining": 1, "auto_fixable": 3, "linter": linter},
            "rules": lambda: {"rules": ["E501", "W292", "F401"], "active": 3, "linter": linter},
            "ignore": lambda: {"ignored": ["E501", "W292"], "config_file": ".flake8", "linter": linter},
            "report": lambda: {"total_issues": 5, "errors": 1, "warnings": 3, "info": 1, "score": 8.5},
            "config": lambda: {"config": {"max_line_length": 88, "ignore": ["E203"], "select": ["E", "W", "F"]}, "linter": linter},
        }
        if action not in handlers:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handlers[action]()

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具调用。"""
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(v, 1002, start)
            result = self.execute(**v)
            elapsed = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
            return {"success": True, "data": result, "error": None, "execution_time": elapsed, "tool": self.name, "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()}
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception as e:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _err(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构建错误响应。"""
        return {"success": False, "data": None, "error": msg, "error_code": code, "error_details": details or {}, "execution_time": round(time.monotonic() - start, 4), "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat()}

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取统计信息。"""
        avg = self._stats["time"] / self._stats["ok"] if self._stats["ok"] > 0 else 0.0
        return {**self._stats, "avg": round(avg, 4), "rate": round(self._stats["ok"] / max(1, self._stats["calls"]), 4)}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史记录。"""
        return list(self._history)[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。"""
        return {"name": self.name, "description": self.description, "version": self.version, "category": self.category, "tags": self.tags, "parameters": [p.to_dict() for p in self.parameters], "stats": self.get_stats()}

    def validate_input(self, params: Dict[str, Any]) -> tuple[bool, str]:
        """验证输入参数。"""
        ok, r = self.validate_parameters(params)
        return ok, "" if ok else r

    def __repr__(self) -> str:
        """返回工具的可读表示。"""
        return f"<CodeLinterDevTool name={self.name} v{self.version}>"

    def lint(self, code: str, linter: str = "flake8") -> Dict[str, Any]:
        """执行代码lint检查。"""
        return self.run({"action": "lint", "code": code, "linter": linter})