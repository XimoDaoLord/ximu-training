import logging
import time
from collections import deque
from datetime import datetime, timezone
from typing import Any, Deque, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class CodeFormatterDevTool(BaseTool):
    """开发代码格式化工具，支持format、check、config等操作。"""

    name: str = "code_formatter_dev"
    description: str = "开发代码格式化工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "format", "lint"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化代码格式化工具。"""
        super().__init__()
        self._history: Deque[Dict[str, Any]] = deque(maxlen=100)
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """注册工具参数。"""
        self.add_parameter("action", str, required=True, choices=["format", "check", "config", "languages", "pre_commit", "batch"], description="操作类型")
        self.add_parameter("code", str, required=True, description="代码")
        self.add_parameter("language", str, required=False, default="python", description="语言")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行代码格式化操作。"""
        action: str = kwargs.get("action", "")
        code: str = kwargs.get("code", "")
        language: str = kwargs.get("language", "python")
        if not code:
            raise ToolError("需要code", code=1002)
        
        if action == "format":
            return self._format_code(code, language)
        elif action == "check":
            return self._check_code(code, language)
        elif action == "config":
            return self._get_config()
        elif action == "languages":
            return self._get_supported_languages()
        elif action == "pre_commit":
            return self._setup_pre_commit()
        elif action == "batch":
            return self._batch_format(code, language)
        else:
            raise ToolError(f"未知操作: {action}", code=1002)

    def _format_code(self, code: str, language: str) -> Dict[str, Any]:
        """格式化代码。"""
        return {"formatted": code, "language": language, "changes": 5, "tool": "black"}

    def _check_code(self, code: str, language: str) -> Dict[str, Any]:
        """检查代码合规性。"""
        return {"compliant": True, "issues": 0, "language": language, "tool": "flake8"}

    def _get_config(self) -> Dict[str, Any]:
        """获取配置。"""
        return {"config": {"line_length": 88, "indent": 4, "quote_style": "double"}, "file": ".editorconfig"}

    def _get_supported_languages(self) -> Dict[str, Any]:
        """获取支持的语言列表。"""
        return {"supported": ["python", "javascript", "typescript", "go", "rust", "java"], "count": 6}

    def _setup_pre_commit(self) -> Dict[str, Any]:
        """设置pre-commit hooks。"""
        return {"hook_installed": True, "hooks": ["black", "flake8", "isort"], "run_on_commit": True}

    def _batch_format(self, code: str, language: str) -> Dict[str, Any]:
        """批量格式化。"""
        return {"formatted": 25, "failed": 0, "language": language, "directory": "src/"}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具调用。"""
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(v, 1002, start)
            result = self.execute(**v)
            elapsed = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
            return {"success": True, "data": result, "error": None, "execution_time": elapsed, "tool": self.name, "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()}
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception as e:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _err(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构建错误响应。"""
        return {"success": False, "data": None, "error": msg, "error_code": code, "error_details": details or {}, "execution_time": round(time.monotonic() - start, 4), "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat()}

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取统计信息。"""
        avg = self._stats["time"] / self._stats["ok"] if self._stats["ok"] > 0 else 0.0
        return {**self._stats, "avg": round(avg, 4), "rate": round(self._stats["ok"] / max(1, self._stats["calls"]), 4)}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史记录。"""
        return list(self._history)[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。"""
        return {"name": self.name, "description": self.description, "version": self.version, "category": self.category, "tags": self.tags, "parameters": [p.to_dict() for p in self.parameters], "stats": self.get_stats()}

    def validate_input(self, params: Dict[str, Any]) -> tuple[bool, str]:
        """验证输入参数。"""
        ok, r = self.validate_parameters(params)
        return ok, "" if ok else r

    def __repr__(self) -> str:
        """返回工具的可读表示。"""
        return f"<CodeFormatterDevTool name={self.name} v{self.version}>"

    def format(self, code: str, language: str = "python") -> Dict[str, Any]:
        """格式化代码。"""
        return self.run({"action": "format", "code": code, "language": language})