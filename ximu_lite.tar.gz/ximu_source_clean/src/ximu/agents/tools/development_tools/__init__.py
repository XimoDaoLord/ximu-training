"""开发工具模块

提供开发相关的工具类，包括CI/CD流水线工具等。
定义工具基类BaseToolImpl，提供通用的执行框架。
"""
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from src.ximu.agents.tools.base import BaseTool


class BaseToolImpl(BaseTool):
    """工具基类，提供通用的执行框架

    提供工具执行的通用逻辑，包括参数验证、执行、错误处理、统计和历史记录。
    所有工具类都应继承此类，并重写execute方法实现具体功能。
    """

    name: str = ""
    description: str = ""
    version: str = "1.0.0"
    category: str = ""
    tags: List[str] = []
    author: str = ""

    def __init__(self) -> None:
        """初始化工具实例"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, float] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具

        Args:
            params: 参数字典

        Returns:
            执行结果
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._format_error(v, 1002, start)

            result: Dict[str, Any] = self.execute(**v)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed)
            return self._format_success(result, elapsed)
        except Exception as e:
            self._stats["fail"] += 1
            logging.getLogger("ximu.tool").error("工具内部错误", exc_info=True)
            return self._format_error(str(e), 1006, start)

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行具体操作（子类实现）

        Args:
            kwargs: 操作参数

        Returns:
            操作结果字典

        Raises:
            NotImplementedError: 子类未实现此方法时抛出
        """
        raise NotImplementedError("子类必须实现execute方法")

    def _format_error(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """格式化错误响应

        Args:
            msg: 错误消息
            code: 错误代码
            start: 开始时间
            details: 详细信息

        Returns:
            错误响应字典
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def _format_success(self, data: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """格式化成功响应

        Args:
            data: 数据
            elapsed: 耗时

        Returns:
            成功响应字典
        """
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def _append_history(self, elapsed: float) -> None:
        """追加历史记录

        Args:
            elapsed: 执行耗时
        """
        self._history.append({
            "ts": datetime.now(timezone.utc).isoformat(),
            "ok": True,
            "t": elapsed
        })
        if len(self._history) > 100:
            self._history.pop(0)

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息

        Returns:
            统计信息字典
        """
        stats: Dict[str, float] = self._stats
        ok: float = stats["ok"]
        calls: float = stats["calls"]
        avg: float = stats["time"] / ok if ok > 0 else 0
        return {
            **stats,
            "avg": round(avg, 4),
            "rate": round(ok / max(1, calls), 4)
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取历史记录

        Args:
            limit: 返回的最大记录数

        Returns:
            历史记录列表
        """
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符

        Returns:
            工具描述符字典
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats()
        }

    def validate_input(self, params: Dict[str, Any]) -> Tuple[bool, str]:
        """验证输入参数

        Args:
            params: 参数字典

        Returns:
            (是否有效, 错误消息)
        """
        ok, r = self.validate_parameters(params)
        return ok, "" if ok else r

    def __repr__(self) -> str:
        """返回字符串表示"""
        return f"<{self.__class__.__name__} name={self.name} v{self.version}>"


__all__ = ["BaseToolImpl"]