from __future__ import annotations

import logging
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger: logging.Logger = logging.getLogger("ximu.tool")


class DependencyAnalyzerTool(BaseTool):
    """依赖分析工具，支持分析、过期检查、漏洞扫描、依赖树、更新和锁定操作。"""

    name: str = "dependency_analyzer"
    description: str = "依赖分析工具"
    version: str = "0.5"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化依赖分析工具。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {
            "calls": 0,
            "ok": 0,
            "fail": 0,
            "time": 0.0,
        }
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=["analyze", "outdated", "vulnerabilities", "tree", "update", "lock"],
            description="操作类型"
        )
        self.add_parameter(
            "file",
            str,
            required=False,
            default="",
            description="依赖文件路径"
        )
        self.add_parameter(
            "package",
            str,
            required=False,
            default="",
            description="包名称"
        )

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行依赖分析操作。

        Args:
            **kwargs: 包含 action, file, package 等参数。

        Returns:
            操作结果字典。

        Raises:
            ToolError: 当操作未知时抛出。
        """
        action: str = kwargs.get("action", "")
        file_path: str = kwargs.get("file", "")
        package: str = kwargs.get("package", "")

        handlers: Dict[str, Any] = {
            "analyze": self._analyze_dependencies,
            "outdated": self._get_outdated_dependencies,
            "vulnerabilities": self._get_vulnerabilities,
            "tree": self._get_dependency_tree,
            "update": self._update_package,
            "lock": self._lock_dependencies,
        }

        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)

        if action == "analyze":
            return handler(file_path)
        elif action == "update":
            return handler(package)
        else:
            return handler()

    def _analyze_dependencies(self, file_path: str) -> Dict[str, Any]:
        """分析依赖文件。

        Args:
            file_path: 依赖文件路径。

        Returns:
            分析结果字典。

        Raises:
            ToolError: 当文件读取失败时抛出。
        """
        if not file_path:
            return {"dependencies": [], "note": "需要指定依赖文件"}

        path = Path(file_path)
        if not path.exists():
            return {"dependencies": [], "note": f"文件不存在: {file_path}"}

        try:
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            deps: List[Tuple[str, str]] = re.findall(r'([\w-]+)[=<>~]+([\d.]+)', content)
            dependencies: List[Dict[str, str]] = [
                {"name": name, "version": version}
                for name, version in deps
            ]
            return {
                "dependencies": dependencies,
                "count": len(dependencies)
            }
        except Exception as e:
            logger.warning(f"分析依赖文件失败: {file_path}", exc_info=True)
            raise ToolError(f"分析失败: {str(e)}", code=1005) from e

    def _get_outdated_dependencies(self) -> Dict[str, Any]:
        """获取过期的依赖（模拟数据）。

        Returns:
            过期依赖列表字典。
        """
        outdated: List[Dict[str, str]] = [
            {"name": "requests", "current": "2.28.0", "latest": "2.31.0"},
            {"name": "flask", "current": "2.0.0", "latest": "2.3.0"}
        ]
        return {"outdated": outdated, "count": len(outdated)}

    def _get_vulnerabilities(self) -> Dict[str, Any]:
        """获取已知漏洞（模拟数据）。

        Returns:
            漏洞列表字典。
        """
        vulnerabilities: List[Dict[str, str]] = [
            {
                "package": "requests",
                "severity": "high",
                "advisory": "CVE-2023-0001",
                "fixed_in": "2.31.0"
            }
        ]
        return {"vulnerabilities": vulnerabilities, "count": len(vulnerabilities)}

    def _get_dependency_tree(self) -> Dict[str, Any]:
        """获取依赖树结构（模拟数据）。

        Returns:
            依赖树字典。
        """
        tree: Dict[str, Any] = {
            "app": {
                "requests": {
                    "urllib3": {},
                    "charset-normalizer": {}
                },
                "flask": {
                    "werkzeug": {},
                    "jinja2": {}
                }
            }
        }
        return {"tree": tree}

    def _update_package(self, package_name: str) -> Dict[str, Any]:
        """更新指定包（模拟操作）。

        Args:
            package_name: 包名称。

        Returns:
            更新结果字典。
        """
        return {
            "updated": package_name if package_name else "all",
            "success": True
        }

    def _lock_dependencies(self) -> Dict[str, Any]:
        """锁定依赖版本（模拟操作）。

        Returns:
            锁定结果字典。
        """
        return {
            "locked": True,
            "lock_file": "requirements.lock"
        }

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具操作，包含参数验证、执行和统计更新。

        Args:
            params: 参数字典，可为 None。

        Returns:
            标准化结果字典。
        """
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated_params = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._create_error_response(str(validated_params), 1002, start_time)

            result: Dict[str, Any] = self.execute(**validated_params)
            elapsed_time: float = round(time.monotonic() - start_time, 4)

            self._stats["ok"] += 1
            self._stats["time"] += elapsed_time

            history_entry: Dict[str, Any] = {
                "ts": datetime.now(timezone.utc).isoformat(),
                "ok": True,
                "t": elapsed_time
            }
            self._history.append(history_entry)
            if len(self._history) > 100:
                self._history.pop(0)

            return self._success_response(result, elapsed_time)

        except ToolError as e:
            self._stats["fail"] += 1
            return self._create_error_response(e.message, e.code, start_time, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._create_error_response("工具内部错误", 1006, start_time)

    def _create_error_response(
        self,
        message: str,
        error_code: int,
        start_time: float,
        details: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """创建错误响应。

        Args:
            message: 错误信息。
            error_code: 错误代码。
            start_time: 开始时间。
            details: 详细信息。

        Returns:
            标准化错误响应字典。
        """
        elapsed_time: float = round(time.monotonic() - start_time, 4)
        return {
            "success": False,
            "data": None,
            "error": message,
            "error_code": error_code,
            "error_details": details or {},
            "execution_time": elapsed_time,
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def _success_response(self, result: Any, elapsed: float) -> Dict[str, Any]:
        """创建成功响应。

        Args:
            result: 执行结果。
            elapsed: 执行耗时。

        Returns:
            标准化成功响应字典。
        """
        return {
            "success": True,
            "data": result,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
