import random
from datetime import datetime, timezone
import logging
import time
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class MonitoringTool(BaseTool):
    """
    监控工具类。
    
    提供指标查询、告警管理、仪表板列表及监控查询功能。
    数据为模拟生成，用于演示监控工具接口。
    """

    name: str = "monitoring_tool"
    description: str = "监控工具"
    version: str = "2.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"
    
    ACTIONS: frozenset = frozenset({"metrics", "alerts", "dashboards", "query", "set_alert", "silence"})
    METRICS: frozenset = frozenset({"cpu", "memory", "disk", "network", "latency", "errors"})

    def __init__(self) -> None:
        """
        初始化监控工具。
        """
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """
        注册参数定义。
        """
        self.add_parameter(
            "action", str, required=True,
            choices=list(self.ACTIONS),
            description="操作类型"
        )
        self.add_parameter("target", str, required=False, default="", description="监控目标")
        self.add_parameter("metric", str, required=False, default="cpu", choices=list(self.METRICS), description="指标")
        self.add_parameter("duration", str, required=False, default="1h", description="时间范围")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """
        执行监控操作。
        
        Args:
            **kwargs: 工具参数。
            
        Returns:
            操作结果字典。
            
        Raises:
            ToolError: 当操作无效时抛出。
        """
        action: str = kwargs.get("action", "")
        if action not in self.ACTIONS:
            raise ToolError(f"未知操作: {action}", code=1002)
        
        dispatch = {
            "metrics": self._query_metrics,
            "alerts": self._list_alerts,
            "dashboards": self._list_dashboards,
            "query": self._execute_query,
            "set_alert": self._configure_alert,
            "silence": self._silence_alert,
        }
        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        
        return handler(**kwargs)

    def _query_metrics(self, **kwargs: Any) -> Dict[str, Any]:
        """
        查询模拟监控指标数据。
        
        Args:
            **kwargs: 包含metric, target, duration的参数。
            
        Returns:
            包含时间序列数据及统计值的字典。
        """
        metric: str = kwargs.get("metric", "cpu")
        target: str = kwargs.get("target", "localhost")
        duration: str = kwargs.get("duration", "1h")
        
        points: List[Dict[str, float]] = []
        now: float = time.time()
        for i in range(60):
            points.append({"ts": now - (i * 60), "value": random.uniform(10, 90)})
        
        values: List[float] = [p["value"] for p in points]
        avg_val: float = sum(values) / len(values) if values else 0.0
        
        return {
            "metric": metric,
            "target": target,
            "data_points": len(points),
            "avg": round(avg_val, 2),
            "min": min(values) if values else 0,
            "max": max(values) if values else 0,
        }

    def _list_alerts(self, **kwargs: Any) -> Dict[str, Any]:
        """
        列出当前告警。
        
        Args:
            **kwargs: 参数。
            
        Returns:
            告警列表。
        """
        return {"alerts": [{"id": 1, "name": "HighCPU", "status": "firing", "value": "85%"}], "count": 1}

    def _list_dashboards(self, **kwargs: Any) -> Dict[str, Any]:
        """
        列出仪表板。
        
        Args:
            **kwargs: 参数。
            
        Returns:
            仪表板列表。
        """
        return {"dashboards": [{"name": "System Overview", "panels": 8}], "count": 1}

    def _execute_query(self, **kwargs: Any) -> Dict[str, Any]:
        """
        执行特定查询。
        
        Args:
            **kwargs: 参数。
            
        Returns:
            查询结果。
        """
        metric: str = kwargs.get("metric", "cpu")
        return {"query": metric, "result_value": 45.2, "unit": "percent"}

    def _configure_alert(self, **kwargs: Any) -> Dict[str, Any]:
        """
        配置告警规则。
        
        Args:
            **kwargs: 参数。
            
        Returns:
            配置结果。
        """
        metric: str = kwargs.get("metric", "cpu")
        return {"alert_configured": True, "metric": metric, "threshold_default": 80.0}

    def _silence_alert(self, **kwargs: Any) -> Dict[str, Any]:
        """
        静默告警。
        
        Args:
            **kwargs: 参数。
            
        Returns:
            静默结果。
        """
        target: str = kwargs.get("target", "all")
        return {"silenced": True, "target": target, "duration_default": "1h"}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        执行工具调用。
        
        Args:
            params: 参数字典。
            
        Returns:
            标准化响应。
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1
        
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._error(str(validated), 1002, start)
            
            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
            if len(self._history) > 100:
                self._history.pop(0)
            
            return {
                "success": True,
                "data": result,
                "error": None,
                "execution_time": elapsed,
                "tool": self.name,
                "version": self.version,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
        except ToolError as e:
            self._stats["fail"] += 1
            return self._error(e.message, e.code, start, getattr(e, 'details', None))
        except Exception:
            self._stats["fail"] += 1
            logger.error("MonitoringTool 内部错误", exc_info=True)
            return self._error("内部错误", 1006, start)

    def _error(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        构建错误响应。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """
        获取统计信息。
        
        Returns:
            统计字典。
        """
        ok_count: int = int(self._stats["ok"])
        total_calls: int = int(self._stats["calls"])
        avg_time: float = self._stats["time"] / ok_count if ok_count > 0 else 0.0
        
        return {
            **self._stats,
            "avg_time_s": round(avg_time, 4),
            "success_rate_percent": round((ok_count / max(1, total_calls)) * 100, 2)
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        获取最近的历史记录。
        
        Args:
            limit: 获取条数。
            
        Returns:
            历史记录列表。
        """
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """
        获取工具描述符。
        
        Returns:
            包含元数据的字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }

    def __repr__(self) -> str:
        """
        返回工具的字符串表示。
        
        Returns:
            表示字符串。
        """
        return f"<MonitoringTool v{self.version} calls={self._stats['calls']}>"