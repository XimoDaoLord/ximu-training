"""环境管理工具，支持创建、激活、停用、列出、删除虚拟环境以及包管理。"""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class EnvironmentManagerTool(BaseTool):
    """环境管理工具，支持创建、激活、停用、列出、删除虚拟环境以及包管理。"""

    name: str = "environment_manager"
    description: str = "环境管理工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化环境管理工具。设置工具的基本属性并初始化内部状态。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {
            "calls": 0,
            "ok": 0,
            "fail": 0,
            "time": 0.0,
        }
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数。定义操作、环境名、Python版本、包名等参数。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=[
                "create", "activate", "deactivate", "list", "remove",
                "packages", "install", "freeze",
            ],
            description="操作",
        )
        self.add_parameter("name", str, required=False, default="", description="环境名")
        self.add_parameter(
            "python_version",
            str,
            required=False,
            default="3.11",
            description="Python版本",
        )
        self.add_parameter("package", str, required=False, default="", description="包名")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行环境管理操作。

        Args:
            **kwargs: 操作参数，必须包含 action 字段。

        Returns:
            操作结果字典。

        Raises:
            ToolError: 当参数无效或操作失败时。
        """
        action: str = kwargs.get("action", "")
        handlers: Dict[str, Any] = {
            "create": lambda: self._handle_create(kwargs),
            "activate": lambda: self._handle_activate(kwargs),
            "deactivate": lambda: self._handle_deactivate(kwargs),
            "list": lambda: self._handle_list(kwargs),
            "remove": lambda: self._handle_remove(kwargs),
            "packages": lambda: self._handle_packages(kwargs),
            "install": lambda: self._handle_install(kwargs),
            "freeze": lambda: self._handle_freeze(kwargs),
        }
        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _handle_create(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理虚拟环境创建。

        Args:
            kwargs: 包含 name, python_version 参数。

        Returns:
            创建结果字典。

        Raises:
            ToolError: 当创建超时或失败时抛出。
        """
        name: str = kwargs.get("name", "venv")
        python_version: str = kwargs.get("python_version", "3.11")
        try:
            result = subprocess.run(
                [sys.executable, "-m", "venv", name],
                capture_output=True,
                text=True,
                timeout=30,
            )
            return {
                "created": result.returncode == 0,
                "name": name,
                "python": python_version,
            }
        except subprocess.TimeoutExpired:
            raise ToolError("创建环境超时", code=1007)
        except OSError as e:
            raise ToolError(f"创建环境失败: {e}", code=1008)

    def _handle_activate(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理虚拟环境激活。

        Args:
            kwargs: 包含 name 参数。

        Returns:
            激活结果字典。
        """
        name: str = kwargs.get("name", "venv")
        return {
            "activated": True,
            "name": name,
            "command": f"source {name}/bin/activate",
        }

    def _handle_deactivate(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理虚拟环境停用。

        Args:
            kwargs: 参数。

        Returns:
            停用结果字典。
        """
        return {"deactivated": True}

    def _handle_list(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理环境列表查询。

        Args:
            kwargs: 参数。

        Returns:
            环境列表字典。
        """
        return {
            "environments": [
                {"name": "venv", "python": "3.11", "packages": 15}
            ],
            "count": 1,
        }

    def _handle_remove(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理虚拟环境删除。

        Args:
            kwargs: 包含 name 参数。

        Returns:
            删除结果字典。

        Raises:
            ToolError: 当检测到路径遍历攻击或删除失败时抛出。
        """
        name: str = kwargs.get("name", "venv")
        if name.strip() in ("", ".", "..") or ".." in Path(name).parts:
            raise ToolError("invalid environment name: path traversal blocked", code=1003)
        path: Path = Path(name)
        if path.exists():
            try:
                shutil.rmtree(path)
            except OSError as e:
                raise ToolError(f"删除环境失败: {e}", code=1009)
        return {"removed": name}

    def _handle_packages(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理包列表查询。

        Args:
            kwargs: 参数。

        Returns:
            包列表字典。

        Raises:
            ToolError: 当查询超时时抛出。
        """
        try:
            result = subprocess.run(
                ["pip", "list", "--format=json"],
                capture_output=True,
                text=True,
                timeout=15,
            )
            pkgs: List[Dict[str, Any]] = json.loads(result.stdout)
            return {"packages": pkgs[:50], "count": len(pkgs)}
        except subprocess.TimeoutExpired:
            raise ToolError("获取包列表超时", code=1010)
        except json.JSONDecodeError:
            return {"packages": [], "output": result.stdout[:1000]}
        except (OSError, ValueError, TypeError) as e:
            return {"packages": [], "output": str(e)[:1000]}

    def _handle_install(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理包安装。

        Args:
            kwargs: 包含 package 参数。

        Returns:
            安装结果字典。

        Raises:
            ToolError: 当缺少包名或安装失败时抛出。
        """
        package: str = kwargs.get("package", "")
        if not package:
            raise ToolError("需要package", code=1002)
        try:
            result = subprocess.run(
                ["pip", "install", package],
                capture_output=True,
                text=True,
                timeout=60,
            )
            return {
                "installed": result.returncode == 0,
                "package": package,
                "output": result.stdout[:500],
            }
        except subprocess.TimeoutExpired:
            raise ToolError("安装包超时", code=1011)
        except OSError as e:
            raise ToolError(f"安装包失败: {e}", code=1012)

    def _handle_freeze(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """处理requirements生成。

        Args:
            kwargs: 参数。

        Returns:
            requirements字典。

        Raises:
            ToolError: 当查询超时时抛出。
        """
        try:
            result = subprocess.run(
                ["pip", "freeze"],
                capture_output=True,
                text=True,
                timeout=15,
            )
            requirements: str = result.stdout
            return {
                "requirements": requirements,
                "count": len(requirements.split("\n")),
            }
        except subprocess.TimeoutExpired:
            raise ToolError("获取requirements超时", code=1013)
        except OSError as e:
            raise ToolError(f"获取requirements失败: {e}", code=1014)

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具调用，包含参数验证、执行和统计更新。

        Args:
            params: 参数字典，可为 None。

        Returns:
            标准化结果字典。
        """
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            is_valid, validated_params = self.validate_parameters(params)
            if not is_valid:
                self._stats["fail"] += 1
                return self._create_error_response(str(validated_params), 1002, start_time)

            result: Dict[str, Any] = self.execute(**validated_params)
            elapsed_time: float = round(time.monotonic() - start_time, 4)

            self._stats["ok"] += 1
            self._stats["time"] += elapsed_time

            history_entry: Dict[str, Any] = {
                "ts": datetime.now(timezone.utc).isoformat(),
                "ok": True,
                "t": elapsed_time
            }
            self._history.append(history_entry)
            if len(self._history) > 100:
                self._history.pop(0)

            return self._create_success_response(result, elapsed_time)

        except ToolError as e:
            self._stats["fail"] += 1
            return self._create_error_response(e.message, e.code, start_time, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._create_error_response("工具内部错误", 1006, start_time)

    def _create_error_response(
        self,
        message: str,
        error_code: int,
        start_time: float,
        details: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """创建错误响应。

        Args:
            message: 错误信息。
            error_code: 错误代码。
            start_time: 开始时间。
            details: 详细信息。

        Returns:
            标准化错误响应字典。
        """
        elapsed_time: float = round(time.monotonic() - start_time, 4)
        return {
            "success": False,
            "data": None,
            "error": message,
            "error_code": error_code,
            "error_details": details or {},
            "execution_time": elapsed_time,
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def _create_success_response(self, result: Any, elapsed: float) -> Dict[str, Any]:
        """创建成功响应。

        Args:
            result: 执行结果。
            elapsed: 执行耗时。

        Returns:
            标准化成功响应字典。
        """
        return {
            "success": True,
            "data": result,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
