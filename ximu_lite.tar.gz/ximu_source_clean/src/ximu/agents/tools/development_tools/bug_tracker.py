"""
缺陷跟踪工具，支持创建、更新、查询、分配、关闭、搜索和统计操作。
"""
from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger: logging.Logger = logging.getLogger("ximu.tool")


class BugTrackerTool(BaseTool):
    """缺陷跟踪工具，支持创建、更新、查询、分配、关闭、搜索和统计操作。"""

    name: str = "bug_tracker"
    description: str = "缺陷跟踪工具"
    version: str = "1.0.0"
    category: str = "development_tools"
    tags: List[str] = ["development", "devops", "tools"]
    author: str = "汐沫AI"
    _VALID_STATUSES: List[str] = ["open", "in_progress", "resolved", "closed"]
    _VALID_PRIORITIES: List[str] = ["low", "medium", "high", "critical"]
    _VALID_ACTIONS: List[str] = ["create", "update", "list", "get", "assign", "close", "search", "stats"]

    def __init__(self) -> None:
        """初始化缺陷跟踪工具实例。"""
        super().__init__()
        self._bugs: Dict[str, Dict[str, Any]] = {}
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """注册工具参数定义。"""
        self.add_parameter(
            "action", str, required=True,
            choices=self._VALID_ACTIONS,
            description="操作类型"
        )
        self.add_parameter("title", str, required=False, default="", description="缺陷标题")
        self.add_parameter("bug_id", str, required=False, default="", description="缺陷ID")
        self.add_parameter(
            "status", str, required=False, default="open",
            choices=self._VALID_STATUSES,
            description="缺陷状态"
        )
        self.add_parameter(
            "priority", str, required=False, default="medium",
            choices=self._VALID_PRIORITIES,
            description="优先级"
        )
        self.add_parameter("assignee", str, required=False, default="", description="指派人")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """根据action分发给对应处理方法。

        Args:
            **kwargs: 操作参数。

        Returns:
            操作结果字典。

        Raises:
            ToolError: 当操作未知时抛出。
        """
        action: str = kwargs.get("action", "")
        handlers: Dict[str, Any] = {
            "create": lambda: self._create(**kwargs),
            "update": lambda: self._update(**kwargs),
            "list": self._list,
            "get": lambda: self._get(**kwargs),
            "assign": lambda: self._assign(**kwargs),
            "close": lambda: self._close(**kwargs),
            "search": lambda: self._search(**kwargs),
            "stats": self._stats_info,
        }
        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _create(self, **kwargs: Any) -> Dict[str, Any]:
        """创建新缺陷记录。

        Args:
            **kwargs: 包含title等参数。

        Returns:
            创建的缺陷信息。

        Raises:
            ToolError: 当标题为空时抛出。
        """
        title: str = kwargs.get("title", "")
        if not title:
            raise ToolError("需要title", code=1002)
        bug_id: str = f"BUG-{len(self._bugs) + 1:04d}"
        bug: Dict[str, Any] = {
            "id": bug_id, "title": title, "status": "open",
            "priority": kwargs.get("priority", "medium"),
            "assignee": kwargs.get("assignee", ""),
            "created": time.time(), "comments": []
        }
        self._bugs[bug_id] = bug
        return {"created": bug, "id": bug_id}

    def _update(self, **kwargs: Any) -> Dict[str, Any]:
        """更新指定缺陷的属性。

        Args:
            **kwargs: 包含bug_id及要更新的字段。

        Returns:
            更新后的缺陷信息。

        Raises:
            ToolError: 当缺陷不存在时抛出。
        """
        bug_id: str = kwargs.get("bug_id", "")
        if bug_id not in self._bugs:
            raise ToolError("缺陷不存在", code=1005)
        bug: Dict[str, Any] = self._bugs[bug_id]
        for key in ["status", "priority", "assignee", "title"]:
            value = kwargs.get(key)
            if value:
                bug[key] = value
        return {"updated": bug, "id": bug_id}

    def _list(self) -> Dict[str, Any]:
        """列出所有缺陷。

        Returns:
            包含缺陷列表和总数的字典。
        """
        return {"bugs": list(self._bugs.values()), "count": len(self._bugs)}

    def _get(self, **kwargs: Any) -> Dict[str, Any]:
        """获取单个缺陷详情。

        Args:
            **kwargs: 包含bug_id参数。

        Returns:
            缺陷信息。

        Raises:
            ToolError: 当缺陷不存在时抛出。
        """
        bug_id: str = kwargs.get("bug_id", "")
        if bug_id not in self._bugs:
            raise ToolError("缺陷不存在", code=1005)
        return {"bug": self._bugs[bug_id]}

    def _assign(self, **kwargs: Any) -> Dict[str, Any]:
        """为缺陷指配合适人员。

        Args:
            **kwargs: 包含bug_id和assignee参数。

        Returns:
            分配结果。
        """
        bug_id: str = kwargs.get("bug_id", "")
        assignee: str = kwargs.get("assignee", "")
        if bug_id in self._bugs:
            self._bugs[bug_id]["assignee"] = assignee
            self._bugs[bug_id]["status"] = "in_progress"
        return {"assigned": bug_id, "assignee": assignee}

    def _close(self, **kwargs: Any) -> Dict[str, Any]:
        """关闭指定缺陷。

        Args:
            **kwargs: 包含bug_id参数。

        Returns:
            关闭结果。
        """
        bug_id: str = kwargs.get("bug_id", "")
        if bug_id in self._bugs:
            self._bugs[bug_id]["status"] = "closed"
        return {"closed": bug_id}

    def _search(self, **kwargs: Any) -> Dict[str, Any]:
        """按标题关键词搜索缺陷。

        Args:
            **kwargs: 包含title搜索关键词。

        Returns:
            匹配结果列表及数量。
        """
        query: str = kwargs.get("title", "").lower()
        results: List[Dict[str, Any]] = [
            bug for bug in self._bugs.values() if query in bug["title"].lower()
        ]
        return {"results": results, "count": len(results)}

    def _stats_info(self) -> Dict[str, Any]:
        """统计各状态和优先级的缺陷数量。

        Returns:
            按状态和优先级分类的统计结果。
        """
        by_status: Dict[str, int] = {status: 0 for status in self._VALID_STATUSES}
        by_priority: Dict[str, int] = {priority: 0 for priority in self._VALID_PRIORITIES}
        for bug in self._bugs.values():
            status = bug.get("status", "open")
            priority = bug.get("priority", "medium")
            if status in by_status: by_status[status] += 1
            if priority in by_priority: by_priority[priority] += 1
        return {"by_status": by_status, "by_priority": by_priority, "total": len(self._bugs)}

    def _error_result(self, message: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构建错误响应。"""
        elapsed: float = round(time.monotonic() - start, 4)
        return {
            "success": False, "data": None, "error": message, "error_code": code,
            "error_details": details or {}, "execution_time": elapsed,
            "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def _success_result(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """构建成功响应。"""
        return {
            "success": True, "data": data, "error": None, "execution_time": elapsed,
            "tool": self.name, "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具主入口。"""
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._error_result(str(validated), 1002, start)
            result = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
            return self._success_result(result, elapsed)
        except ToolError as exc:
            self._stats["fail"] += 1
            return self._error_result(exc.message, exc.code, start, exc.details)
        except Exception as exc:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._error_result("工具内部错误", 1006, start)

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取统计信息。"""
        ok: int = self._stats["ok"]
        calls: int = self._stats["calls"]
        return {**self._stats, "avg": round(self._stats["time"] / ok, 4) if ok > 0 else 0.0, "rate": round(ok / max(1, calls), 4)}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近历史记录。"""
        return list(self._history)[-limit:] if limit > 0 else []