"""
数据聚合工具，支持求和、平均、计数、分组聚合等操作。
"""
from __future__ import annotations

import statistics
from typing import Any, Callable, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

NumericType = Union[int, float]


class DataAggregatorTool(BaseTool):
    """数据聚合工具，支持求和、平均、计数、分组聚合。"""

    name: str = "data_aggregator"
    description: str = "数据聚合工具"
    version: str = "2.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化数据聚合工具。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """注册参数定义。"""
        self.add_parameter(
            "data", list, required=True, description="数据列表"
        )
        self.add_parameter(
            "action", str, required=False, default="summary",
            choices=["summary", "group_sum", "group_avg", "group_count", "group_min", "group_max"],
            description="聚合操作类型"
        )
        self.add_parameter("group_by", str, required=False, default="", description="分组键")
        self.add_parameter("value_field", str, required=False, default="", description="值字段")

    def _summary(self, data: List[Any]) -> Dict[str, Any]:
        """计算数据摘要统计。

        Args:
            data: 数据列表

        Returns:
            统计结果字典
        """
        numeric = [x for x in data if isinstance(x, (int, float))]

        if not numeric:
            return {"count": len(data), "numeric_count": 0}

        result: Dict[str, Any] = {
            "count": len(data),
            "numeric_count": len(numeric),
            "sum": sum(numeric),
            "mean": round(statistics.mean(numeric), 4),
            "median": statistics.median(numeric),
            "min": min(numeric),
            "max": max(numeric),
        }

        if len(numeric) > 1:
            result["stdev"] = round(statistics.stdev(numeric), 4)
            result["variance"] = round(statistics.variance(numeric), 4)
        else:
            result["stdev"] = 0.0
            result["variance"] = 0.0

        return result

    def _group(
        self,
        data: List[Dict[str, Any]],
        group_by: str,
        value_field: str,
        agg_func: Callable[[List[NumericType]], Any],
    ) -> Dict[str, Any]:
        """执行分组聚合操作。

        Args:
            data: 数据字典列表
            group_by: 分组键
            value_field: 值字段
            agg_func: 聚合函数

        Returns:
            分组聚合结果字典

        Raises:
            ToolError: 当参数无效时抛出
        """
        if not group_by or not value_field:
            raise ToolError("分组聚合需要group_by和value_field", code=1002)

        if not all(isinstance(x, dict) for x in data):
            raise ToolError("数据需要是字典列表", code=1002)

        groups: Dict[Any, List[NumericType]] = {}
        for item in data:
            key = item.get(group_by)
            val = item.get(value_field)
            if isinstance(val, (int, float)):
                groups.setdefault(key, []).append(val)

        result_dict = {str(k): agg_func(v) for k, v in groups.items()}
        return {
            "group_by": group_by,
            "value_field": value_field,
            "aggregation": getattr(agg_func, "__name__", "unknown"),
            "result": result_dict,
        }

    def execute(
        self,
        data: Optional[List[Any]] = None,
        action: str = "summary",
        group_by: str = "",
        value_field: str = "",
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """执行数据聚合操作。

        Args:
            data: 数据列表。
            action: 操作类型。
            group_by: 分组键。
            value_field: 值字段。
            **kwargs: 额外参数。

        Returns:
            聚合结果字典。

        Raises:
            ToolError: 当数据为空或操作无效时抛出。
        """
        if data is None or not data:
            raise ToolError("数据为空", code=1002)

        handlers: Dict[str, Callable[[], Dict[str, Any]]] = {
            "summary": lambda: self._summary(data),
            "group_sum": lambda: self._group(data, group_by, value_field, sum),
            "group_avg": lambda: self._group(data, group_by, value_field, statistics.mean),
            "group_count": lambda: self._group(data, group_by, value_field, len),
            "group_min": lambda: self._group(data, group_by, value_field, min),
            "group_max": lambda: self._group(data, group_by, value_field, max),
        }

        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()
