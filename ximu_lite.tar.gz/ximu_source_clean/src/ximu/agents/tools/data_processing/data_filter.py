"""
数据过滤工具，支持条件过滤、范围过滤、去重、空值移除和随机采样。
"""
from __future__ import annotations

import json
import random
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError


class DataFilterTool(BaseTool):
    """数据过滤工具，提供多种数据筛选和采样操作。"""

    name: str = "data_filter"
    description: str = "数据过滤工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化数据过滤工具。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {
            "calls": 0, "ok": 0, "fail": 0, "time": 0.0
        }
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """注册参数定义。"""
        self.add_parameter("data", list, required=True, description="数据列表")
        self.add_parameter(
            "action", str, required=False, default="condition",
            choices=["condition", "range", "unique", "null_removal", "sample"],
            description="过滤操作类型"
        )
        self.add_parameter("field", str, required=False, default="", description="字段名")
        self.add_parameter(
            "operator", str, required=False, default="eq",
            choices=["eq", "ne", "gt", "lt", "gte", "lte", "contains", "in"],
            description="比较操作符"
        )
        self.add_parameter("value", Any, required=False, default=None, description="比较值")
        self.add_parameter("min_val", float, required=False, default=0, description="最小值")
        self.add_parameter("max_val", float, required=False, default=0, description="最大值")
        self.add_parameter("sample_size", int, required=False, default=10, description="采样数量")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行数据过滤操作。

        Args:
            **kwargs: 包含 data, action, field, operator, value, min_val, max_val, sample_size 等参数。

        Returns:
            包含过滤结果和统计信息的字典。

        Raises:
            ToolError: 当操作无效或参数错误时抛出。
        """
        data: List[Any] = kwargs.get("data", [])
        action: str = kwargs.get("action", "condition")
        field: str = kwargs.get("field", "")
        operator: str = kwargs.get("operator", "eq")
        value: Any = kwargs.get("value")
        min_val: float = kwargs.get("min_val", 0)
        max_val: float = kwargs.get("max_val", 0)
        sample_size: int = kwargs.get("sample_size", 10)

        if not data:
            raise ToolError("数据列表不能为空", code=1002)

        dispatch: Dict[str, Callable[[], Dict[str, Any]]] = {
            "condition": lambda: self._execute_condition(data, field, operator, value),
            "range": lambda: self._execute_range(data, field, min_val, max_val),
            "unique": lambda: self._execute_unique(data),
            "null_removal": lambda: self._execute_null_removal(data),
            "sample": lambda: self._execute_sample(data, sample_size),
        }

        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _execute_condition(self, data: List[Any], field: str, operator: str, value: Any) -> Dict[str, Any]:
        """执行条件过滤。

        Args:
            data: 数据列表。
            field: 字段名。
            operator: 比较操作符。
            value: 比较值。

        Returns:
            包含过滤结果的字典。

        Raises:
            ToolError: 当缺少字段或操作符无效时抛出。
        """
        if not field:
            raise ToolError("条件过滤需要field参数", code=1002)

        operators: Dict[str, Callable[[Any], bool]] = {
            "eq": lambda x: x == value,
            "ne": lambda x: x != value,
            "gt": lambda x: x > value if x is not None else False,
            "lt": lambda x: x < value if x is not None else False,
            "gte": lambda x: x >= value if x is not None else False,
            "lte": lambda x: x <= value if x is not None else False,
            "contains": lambda x: value in str(x) if x is not None else False,
            "in": lambda x: x in (value or []) if isinstance(value, (list, tuple)) else False,
        }

        func = operators.get(operator)
        if func is None:
            raise ToolError(f"不支持的操作符: {operator}", code=1002)

        result: List[Any] = [x for x in data if isinstance(x, dict) and func(x.get(field))]
        return {"filtered": result, "original": len(data), "remaining": len(result)}

    def _execute_range(self, data: List[Any], field: str, min_val: float, max_val: float) -> Dict[str, Any]:
        """执行范围过滤。

        Args:
            data: 数据列表。
            field: 字段名（可选）。
            min_val: 最小值。
            max_val: 最大值（0表示无限）。

        Returns:
            包含过滤结果的字典。
        """
        effective_max: float = max_val if max_val > 0 else float("inf")

        if field:
            result: List[Any] = [
                x for x in data
                if isinstance(x, dict)
                and isinstance(x.get(field), (int, float))
                and min_val <= x[field] <= effective_max
            ]
        else:
            result: List[Any] = [
                x for x in data
                if isinstance(x, (int, float))
                and min_val <= x <= effective_max
            ]

        return {"filtered": result, "original": len(data), "remaining": len(result)}

    def _execute_unique(self, data: List[Any]) -> Dict[str, Any]:
        """执行去重操作。

        Args:
            data: 数据列表。

        Returns:
            包含去重结果的字典。
        """
        seen: set = set()
        result: List[Any] = []
        for x in data:
            key: str = json.dumps(x, sort_keys=True) if isinstance(x, (dict, list)) else str(x)
            if key not in seen:
                seen.add(key)
                result.append(x)
        return {"filtered": result, "original": len(data), "remaining": len(result)}

    def _execute_null_removal(self, data: List[Any]) -> Dict[str, Any]:
        """移除空值（None或空字符串）。

        Args:
            data: 数据列表。

        Returns:
            包含移除空值结果的字典。
        """
        result: List[Any] = [x for x in data if x is not None and x != ""]
        return {"filtered": result, "original": len(data), "removed": len(data) - len(result)}

    def _execute_sample(self, data: List[Any], sample_size: int) -> Dict[str, Any]:
        """执行随机采样。

        Args:
            data: 数据列表。
            sample_size: 采样数量。

        Returns:
            包含采样结果的字典。
        """
        actual_size: int = min(sample_size, len(data))
        if actual_size == 0:
            return {"sample": [], "size": 0, "original": len(data)}
        result: List[Any] = random.sample(data, actual_size)
        return {"sample": result, "size": actual_size, "original": len(data)}

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具主入口，包含参数验证、执行和统计更新。

        Args:
            params: 参数字典，可为 None。

        Returns:
            标准化结果字典。
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._create_error_response(str(validated), 1002, start)

            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed

            history_entry: Dict[str, Any] = {
                "ts": datetime.now(timezone.utc).isoformat(),
                "ok": True,
                "t": elapsed
            }
            self._history.append(history_entry)
            if len(self._history) > 100:
                self._history.pop(0)

            return self._success_response(result, elapsed)

        except ToolError as exc:
            self._stats["fail"] += 1
            return self._create_error_response(exc.message, exc.code, start, exc.details)
        except Exception as exc:
            self._stats["fail"] += 1
            return self._create_error_response("工具内部错误", 1006, start)

    def _create_error_response(self, message: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构建错误响应。"""
        return {
            "success": False, "data": None, "error": message, "error_code": code,
            "error_details": details or {}, "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def _success_response(self, result: Any, elapsed: float) -> Dict[str, Any]:
        """构建成功响应。"""
        return {
            "success": True, "data": result, "error": None, "execution_time": elapsed,
            "tool": self.name, "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取统计信息。"""
        ok: int = self._stats["ok"]
        calls: int = self._stats["calls"]
        return {
            **self._stats,
            "avg": round(self._stats["time"] / ok, 4) if ok > 0 else 0.0,
            "rate": round(ok / max(1, calls), 4)
        }
