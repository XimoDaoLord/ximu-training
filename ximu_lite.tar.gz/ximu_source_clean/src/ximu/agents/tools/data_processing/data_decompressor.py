"""
数据解压工具，支持 zlib, gzip, bz2 等多种压缩格式自动检测与解压。

本模块提供 DataDecompressorTool 类，继承自 BaseTool，用于处理不同格式的压缩数据。
支持手动指定算法或自动探测模式，输出格式包括文本、十六进制和原始字节。
"""
from __future__ import annotations

import bz2
import gzip
import zlib
from typing import Any, Dict, List, Callable

from src.ximu.agents.tools.base import BaseTool, ToolError


class DataDecompressorTool(BaseTool):
    """数据解压工具，支持多种压缩格式自动检测和解压。"""

    name: str = "data_decompressor"
    description: str = "数据解压工具"
    version: str = "2.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    _DECOMPRESSORS: Dict[str, Callable[[bytes], bytes]] = {
        "zlib": zlib.decompress,
        "gzip": gzip.decompress,
        "bz2": bz2.decompress,
    }
    _VALID_ALGORITHMS: List[str] = ["zlib", "gzip", "bz2", "auto"]
    _VALID_OUTPUT_FORMATS: List[str] = ["text", "hex", "bytes"]

    def __init__(self) -> None:
        """初始化 DataDecompressorTool 实例。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """注册工具参数定义。"""
        self.add_parameter("data", str, required=True, description="压缩数据（hex编码或UTF-8文本）")
        self.add_parameter("algorithm", str, required=False, default="zlib", choices=self._VALID_ALGORITHMS, description="解压算法")
        self.add_parameter("output_format", str, required=False, default="text", choices=self._VALID_OUTPUT_FORMATS, description="输出格式")

    @staticmethod
    def _decode_input(data: str) -> bytes:
        """解码输入数据，优先尝试hex编码，失败则转为UTF-8字节。

        Args:
            data: 输入字符串，可以是十六进制编码或普通文本。

        Returns:
            解码后的字节流。
        """
        try:
            return bytes.fromhex(data)
        except ValueError:
            return data.encode("utf-8")

    def _decompress(self, data: bytes, algorithm: str) -> bytes:
        """使用指定算法执行解压操作。

        Args:
            data: 压缩后的字节流。
            algorithm: 解压算法名称（zlib, gzip, bz2）。

        Returns:
            解压后的原始字节流。

        Raises:
            ToolError: 当算法不在支持列表中时抛出。
        """
        decompressor = self._DECOMPRESSORS.get(algorithm)
        if decompressor is None:
            supported = ", ".join(self._DECOMPRESSORS.keys())
            raise ToolError(f"不支持的算法: {algorithm}，可选: {supported}", code=1008)
        return decompressor(data)

    @staticmethod
    def _format_output(data: bytes, output_format: str) -> Any:
        """将解压后的字节流转换为指定格式的输出。

        Args:
            data: 解压后的原始字节流。
            output_format: 目标格式（text, hex, bytes）。

        Returns:
            格式化后的结果，类型为str或list。
        """
        if output_format == "text":
            return data.decode("utf-8", errors="replace")
        if output_format == "hex":
            return data.hex()
        return list(data)

    def _decompress_auto(self, compressed: bytes, output_format: str) -> Dict[str, Any]:
        """自动检测压缩格式并解压。

        按顺序尝试 zlib, gzip, bz2，返回第一个成功的结果。

        Args:
            compressed: 压缩后的字节流。
            output_format: 期望的输出格式。

        Returns:
            包含算法名称、自动检测标记、数据和尺寸的结果字典。

        Raises:
            ToolError: 当所有算法均失败时抛出。
        """
        for alg in ("zlib", "gzip", "bz2"):
            try:
                result_bytes = self._decompress(compressed, alg)
                return {
                    "algorithm": alg,
                    "auto_detected": True,
                    "data": self._format_output(result_bytes, output_format),
                    "size": len(result_bytes),
                }
            except (zlib.error, OSError):
                continue
        raise ToolError("无法自动识别压缩格式，请指定algorithm参数", code=1008)

    def _decompress_specific(self, compressed: bytes, algorithm: str, output_format: str) -> Dict[str, Any]:
        """使用指定算法解压数据。

        Args:
            compressed: 压缩后的字节流。
            algorithm: 指定的解压算法。
            output_format: 期望的输出格式。

        Returns:
            包含算法、数据和尺寸的结果字典。

        Raises:
            ToolError: 当解压失败或算法不支持时抛出。
        """
        try:
            result = self._decompress(compressed, algorithm)
        except Exception as exc:
            raise ToolError(f"解压失败: {exc}", code=1008) from exc

        return {
            "algorithm": algorithm,
            "data": self._format_output(result, output_format),
            "size": len(result),
        }

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行数据解压核心逻辑。

        Args:
            **kwargs: 包含 data, algorithm, output_format 等参数。

        Returns:
            解压结果字典，包含 algorithm, data, size 等字段。

        Raises:
            ToolError: 当数据为空或解压失败时抛出。
        """
        data: str = kwargs.get("data", "")
        algorithm: str = kwargs.get("algorithm", "zlib")
        output_format: str = kwargs.get("output_format", "text")

        if not data:
            raise ToolError("data参数不能为空", code=1002)

        compressed = self._decode_input(data)

        if algorithm == "auto":
            return self._decompress_auto(compressed, output_format)
        return self._decompress_specific(compressed, algorithm, output_format)
