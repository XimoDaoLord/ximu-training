from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple, Union
from collections import Counter
from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataImputeTool(BaseTool):
    """数据填补工具，实现多种数据填补算法。"""

    name: str = "data_impute"
    description: str = "数据填补工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "analytics"]
    author: str = "汐沫AI"

    _VALID_ACTIONS: Tuple[str, ...] = ("mean", "median", "mode", "ffill", "bfill", "interpolate", "knn")

    def __init__(self) -> None:
        """初始化数据填补工具。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """定义工具参数。"""
        self.add_parameter("action", str, required=True, choices=list(self._VALID_ACTIONS), description="填补操作方法")
        self.add_parameter("data", list, required=True, description="待填补的数据序列")
        self.add_parameter("value", float, required=False, default=0.0, description="指定填充值")

    def _validate_input(self, action: Optional[str], data: Optional[List[Any]]) -> None:
        """验证输入参数的有效性。
        
        Args:
            action: 操作类型。
            data: 数据序列。
            
        Raises:
            ToolError: 当参数无效时抛出。
        """
        if action is None:
            raise ToolError("需要 action 参数", code=1002)
        if data is None:
            raise ToolError("需要 data 参数", code=1002)
        if not isinstance(data, list):
            raise ToolError("data 必须为列表类型", code=1002)
        if action not in self._VALID_ACTIONS:
            raise ToolError(f"未知操作: {action}", code=1002)

    def _get_valid_values(self, data: List[Any]) -> List[Any]:
        """获取非空值列表。
        
        Args:
            data: 原始数据列表。
            
        Returns:
            非空值列表。
        """
        return [x for x in data if x is not None]

    def _count_missing(self, data: List[Any]) -> int:
        """统计缺失值数量。
        
        Args:
            data: 原始数据列表。
            
        Returns:
            缺失值数量。
        """
        return data.count(None)

    def _find_nearest_valid_index(self, data: List[Any], start: int, step: int) -> int:
        """查找最近的有效值索引。
        
        Args:
            data: 原始数据列表。
            start: 起始索引。
            step: 搜索步长（-1或1）。
            
        Returns:
            最近有效值的索引，或-1表示未找到。
        """
        current = start
        limit = 0 if step == -1 else len(data)
        while 0 <= current < len(data) and (step == -1 or current >= 0):
            if data[current] is not None:
                return current
            current += step
            if step == -1 and current < 0:
                break
            if step == 1 and current >= len(data):
                break
        return -1

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行数据填补操作。
        
        Args:
            **kwargs: 包含action, data, value等参数。
            
        Returns:
            包含填补结果的字典。
            
        Raises:
            ToolError: 当参数无效时抛出。
        """
        action: Optional[str] = kwargs.get("action")
        data: Optional[List[Any]] = kwargs.get("data")
        fill_value: float = kwargs.get("value", 0.0)

        self._validate_input(action, data)
        assert data is not None  # 类型收窄

        if action == "mean":
            result = self._fill_mean(data, fill_value)
        elif action == "median":
            result = self._fill_median(data, fill_value)
        elif action == "mode":
            result = self._fill_mode(data, fill_value)
        elif action == "ffill":
            result = self._fill_ffill(data, fill_value)
        elif action == "bfill":
            result = self._fill_bfill(data, fill_value)
        elif action == "interpolate":
            result = self._fill_interpolate(data, fill_value)
        else:  # knn
            result = self._fill_knn(data, fill_value)

        result["filled"] = self._count_missing(data)
        return result

    def _fill_mean(self, data: List[Any], fill_value: float) -> Dict[str, Any]:
        """均值填补。
        
        Args:
            data: 原始数据列表。
            fill_value: 默认填充值。
            
        Returns:
            包含填补结果的字典。
        """
        valid: List[Any] = self._get_valid_values(data)
        mean_val: Any = fill_value
        if valid:
            try:
                total = sum(valid)
                mean_val = total / len(valid)
            except (TypeError, ValueError):
                mean_val = fill_value
                
        result: List[Any] = [x if x is not None else mean_val for x in data]
        
        fill_value_display = round(mean_val, 4) if isinstance(mean_val, float) else mean_val
        return {"imputed": result, "method": "mean", "fill_value": fill_value_display}

    def _fill_median(self, data: List[Any], fill_value: float) -> Dict[str, Any]:
        """中位数填补。
        
        Args:
            data: 原始数据列表。
            fill_value: 默认填充值。
            
        Returns:
            包含填补结果的字典。
        """
        valid: List[Any] = self._get_valid_values(data)
        median: Any = fill_value
        
        if valid:
            try:
                sorted_v: List[Any] = sorted(valid)
                n: int = len(sorted_v)
                if n % 2 == 1:
                    median = sorted_v[n // 2]
                else:
                    median = (sorted_v[n // 2 - 1] + sorted_v[n // 2]) / 2
            except (TypeError, ValueError):
                median = fill_value
                
        result: List[Any] = [x if x is not None else median for x in data]
        return {"imputed": result, "method": "median", "fill_value": median}

    def _fill_mode(self, data: List[Any], fill_value: float) -> Dict[str, Any]:
        """众数填补。
        
        Args:
            data: 原始数据列表。
            fill_value: 默认填充值。
            
        Returns:
            包含填补结果的字典。
        """
        valid: List[Any] = self._get_valid_values(data)
        mode: Any = fill_value
        
        if valid:
            counter = Counter(valid)
            mode = counter.most_common(1)[0][0]
            
        result: List[Any] = [x if x is not None else mode for x in data]
        return {"imputed": result, "method": "mode", "fill_value": mode}

    def _fill_ffill(self, data: List[Any], fill_value: float) -> Dict[str, Any]:
        """前向填充。
        
        Args:
            data: 原始数据列表。
            fill_value: 默认填充值。
            
        Returns:
            包含填补结果的字典。
        """
        result: List[Any] = data.copy()
        last_valid: Optional[Any] = None
        
        for i in range(len(result)):
            if result[i] is not None:
                last_valid = result[i]
            else:
                result[i] = last_valid if last_valid is not None else fill_value
                
        return {"imputed": result, "method": "ffill"}

    def _fill_bfill(self, data: List[Any], fill_value: float) -> Dict[str, Any]:
        """后向填充。
        
        Args:
            data: 原始数据列表。
            fill_value: 默认填充值。
            
        Returns:
            包含填补结果的字典。
        """
        result: List[Any] = data.copy()
        next_valid: Optional[Any] = None
        
        for i in range(len(result) - 1, -1, -1):
            if result[i] is not None:
                next_valid = result[i]
            else:
                result[i] = next_valid if next_valid is not None else fill_value
                
        return {"imputed": result, "method": "bfill"}

    def _fill_interpolate(self, data: List[Any], fill_value: float) -> Dict[str, Any]:
        """线性插值。
        
        Args:
            data: 原始数据列表。
            fill_value: 默认填充值。
            
        Returns:
            包含填补结果的字典。
        """
        result: List[Any] = data.copy()
        
        for i in range(len(result)):
            if result[i] is not None:
                continue
                
            prev_idx = self._find_nearest_valid_index(result, i - 1, -1)
            next_idx = self._find_nearest_valid_index(result, i + 1, 1)
            
            if prev_idx != -1 and next_idx != -1:
                prev_val: Any = result[prev_idx]
                next_val: Any = result[next_idx]
                try:
                    ratio: float = (i - prev_idx) / (next_idx - prev_idx)
                    result[i] = prev_val + (next_val - prev_val) * ratio
                except (TypeError, ValueError, ZeroDivisionError):
                    result[i] = fill_value
            elif prev_idx != -1:
                result[i] = result[prev_idx]
            elif next_idx != -1:
                result[i] = result[next_idx]
            else:
                result[i] = fill_value
                
        return {"imputed": result, "method": "interpolate"}

    def _fill_knn(self, data: List[Any], fill_value: float) -> Dict[str, Any]:
        """KNN填补（简化为最近非空值）。
        
        Args:
            data: 原始数据列表。
            fill_value: 默认填充值。
            
        Returns:
            包含填补结果的字典。
        """
        result: List[Any] = data.copy()
        
        for i in range(len(result)):
            if result[i] is not None:
                continue
                
            nearest = self._find_nearest_valid_index(result, i - 1, -1)
            result[i] = result[nearest] if nearest != -1 else fill_value
            
        return {"imputed": result, "method": "knn"}