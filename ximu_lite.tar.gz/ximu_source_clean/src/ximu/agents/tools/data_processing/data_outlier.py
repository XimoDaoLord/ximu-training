"""数据离群点检测与处理工具。"""

from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

class DataOutlierTool(BaseTool):
    """数据离群点工具类。"""
    name: str = "data_outlier"
    description: str = "数据离群点工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "analytics"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """配置参数。"""
        self.add_parameter("action", str, required=True, choices=["detect", "remove", "cap", "iqr", "zscore", "report"], description="离群点操作类型")
        self.add_parameter("data", list, required=True, description="数据列表")
        self.add_parameter("threshold", float, required=False, default=3.0, description="离群点阈值")

    def _compute_statistics(self, data: List[float]) -> Tuple[float, float, int]:
        """计算数据的基本统计量。"""
        n = len(data)
        if n == 0:
            raise ValueError("数据列表为空")
        mean = sum(data) / n
        if n > 1:
            variance = sum((x - mean) ** 2 for x in data) / n
            std = variance ** 0.5
        else:
            std = 0.0
        return mean, std, n

    def _detect_outliers(self, data: List[float], mean: float, std: float, threshold: float) -> List[Dict[str, Any]]:
        """基于Z-score检测离群点。"""
        if std <= 0:
            return []
        return [{"index": i, "value": x, "z_score": round((x - mean) / std, 2)} for i, x in enumerate(data) if abs((x - mean) / std) > threshold]

    def _remove_outliers(self, data: List[float], mean: float, std: float, threshold: float, n: int) -> Dict[str, Any]:
        """移除离群点。"""
        if std <= 0:
            return {"cleaned": list(data), "removed": 0, "original_count": n}
        cleaned = [x for x in data if abs((x - mean) / std) <= threshold]
        return {"cleaned": cleaned, "removed": n - len(cleaned), "original_count": n}

    def _cap_values(self, data: List[float], mean: float, std: float, threshold: float) -> Dict[str, Any]:
        """截断离群值至边界内。"""
        if std <= 0:
            return {"capped": list(data), "upper_bound": None, "lower_bound": None}
        upper = mean + threshold * std
        lower = mean - threshold * std
        capped = [min(max(x, lower), upper) for x in data]
        return {"capped": capped, "upper_bound": round(upper, 4), "lower_bound": round(lower, 4)}

    def _iqr_detect(self, data: List[float]) -> Dict[str, Any]:
        """使用IQR方法检测离群点。"""
        if len(data) < 4:
            raise ToolError("IQR方法至少需要4个数据点", code=1002)
        sorted_data = sorted(data)
        q1_index = len(sorted_data) // 4
        q3_index = 3 * len(sorted_data) // 4
        q1 = sorted_data[q1_index]
        q3 = sorted_data[q3_index]
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        outliers = [x for x in data if x < lower_bound or x > upper_bound]
        return {"q1": q1, "q3": q3, "iqr": iqr, "outliers": outliers, "bounds": [lower_bound, upper_bound]}

    def _zscore_scores(self, data: List[float], mean: float, std: float) -> Dict[str, Any]:
        """计算每个数据点的Z分数。"""
        if std > 0:
            z_scores = [round((x - mean) / std, 4) for x in data]
        else:
            z_scores = [0.0 for _ in data]
        return {"zscores": z_scores, "mean": round(mean, 4), "std": round(std, 4)}

    def _generate_report(self, data: List[float], mean: float, std: float, threshold: float, n: int) -> Dict[str, Any]:
        """生成离群点分析报告。"""
        outliers_count = len(self._detect_outliers(data, mean, std, threshold)) if std > 0 else 0
        outlier_pct = round(outliers_count / n * 100, 1) if n > 0 else 0.0
        return {"data_points": n, "outliers": outliers_count, "outlier_pct": outlier_pct, "method": "zscore"}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行离群点操作。"""
        action: str = kwargs.get("action", "")
        data: List[float] = kwargs.get("data", [])
        threshold: float = float(kwargs.get("threshold", 3.0))
        if not data:
            raise ToolError("数据列表不能为空", code=1002)
        mean, std, n = self._compute_statistics(data)
        dispatch = {
            "detect": lambda: {"outliers": self._detect_outliers(data, mean, std, threshold), "count": len(self._detect_outliers(data, mean, std, threshold)), "method": "zscore"},
            "remove": lambda: self._remove_outliers(data, mean, std, threshold, n),
            "cap": lambda: self._cap_values(data, mean, std, threshold),
            "iqr": lambda: self._iqr_detect(data),
            "zscore": lambda: self._zscore_scores(data, mean, std),
            "report": lambda: self._generate_report(data, mean, std, threshold, n)
        }
        if action not in dispatch:
            raise ToolError(f"未知操作: {action}", code=1002)
        return dispatch[action]()