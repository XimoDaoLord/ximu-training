"""数据转换工具，支持映射、过滤、聚合、透视、转置、长表化。"""

import logging
import time
from typing import Any, Dict, List, Optional, Union
from datetime import datetime, timezone

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataTransformerTool(BaseTool):
    """数据转换工具，支持多种数据变换操作。"""

    name: str = "data_transformer"
    description: str = "数据转换工具，支持映射、过滤、聚合、透视"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """设置工具参数。"""
        self.add_parameter(
            "action", str, required=True,
            choices=["map", "filter", "reduce", "pivot", "melt", "transpose", "group_by"],
            description="操作",
        )
        self.add_parameter("data", list, required=True, description="数据")
        self.add_parameter("key", str, required=False, default="", description="键")
        self.add_parameter("value", str, required=False, default="", description="值")
        self.add_parameter("func", str, required=False, default="", description="转换函数名")

    @staticmethod
    def _do_map(**kwargs: Any) -> Dict[str, Any]:
        """对列表元素按函数名做映射。"""
        data: List[Any] = kwargs.get("data", [])
        func_name: str = kwargs.get("func", "")
        
        if func_name == "uppercase":
            result = [x.upper() if isinstance(x, str) else x for x in data]
        elif func_name == "lowercase":
            result = [x.lower() if isinstance(x, str) else x for x in data]
        elif func_name == "length":
            result = [len(x) if hasattr(x, "__len__") else 0 for x in data]
        elif func_name == "square":
            result = [x ** 2 if isinstance(x, (int, float)) else x for x in data]
        else:
            result = data
        
        return {"transformed": result, "count": len(result)}

    @staticmethod
    def _do_filter(**kwargs: Any) -> Dict[str, Any]:
        """按条件过滤列表。"""
        data: List[Any] = kwargs.get("data", [])
        func_name: str = kwargs.get("func", "non_empty")
        
        if func_name == "non_empty":
            result = [x for x in data if x]
        elif func_name == "numeric":
            result = [x for x in data if isinstance(x, (int, float))]
        elif func_name == "string":
            result = [x for x in data if isinstance(x, str)]
        else:
            result = data
        
        return {
            "filtered": result,
            "original": len(data),
            "remaining": len(result),
        }

    @staticmethod
    def _do_reduce(**kwargs: Any) -> Dict[str, Any]:
        """对列表做规约聚合：sum/product/concat。"""
        data: List[Any] = kwargs.get("data", [])
        func_name: str = kwargs.get("func", "sum")
        numeric = [x for x in data if isinstance(x, (int, float))]
        
        if func_name == "sum":
            return {"result": sum(numeric)}
        if func_name == "product":
            result = 1
            for x in numeric:
                result *= x
            return {"result": result}
        if func_name == "concat":
            return {"result": "".join(str(x) for x in data)}
        return {"result": None}

    @staticmethod
    def _do_group_by(**kwargs: Any) -> Dict[str, Any]:
        """按字典 key 分组。"""
        data: List[Any] = kwargs.get("data", [])
        key: str = kwargs.get("key", "")
        if not key or not all(isinstance(x, dict) for x in data):
            raise ToolError("需要key和字典列表", code=1002)
        
        groups: Dict[Any, List[Dict[str, Any]]] = {}
        for item in data:
            groups.setdefault(item.get(key), []).append(item)
        
        return {
            "groups": {str(k): v for k, v in groups.items()},
            "group_count": len(groups),
        }

    @staticmethod
    def _do_pivot(**kwargs: Any) -> Dict[str, Any]:
        """按 key 透视，对 value 列汇总。"""
        data: List[Any] = kwargs.get("data", [])
        key: str = kwargs.get("key", "")
        value: str = kwargs.get("value", "")
        if not key or not value or not all(isinstance(x, dict) for x in data):
            raise ToolError("需要key和value", code=1002)
        
        pivot: Dict[Any, List[Any]] = {}
        for item in data:
            pivot.setdefault(item.get(key), []).append(item.get(value))
        
        result: Dict[str, Any] = {}
        for k, v in pivot.items():
            nums = [x for x in v if isinstance(x, (int, float))]
            result[str(k)] = {
                "values": v,
                "count": len(v),
                "sum": sum(nums),
            }
        return {"pivot": result}

    @staticmethod
    def _do_transpose(**kwargs: Any) -> Dict[str, Any]:
        """二维列表转置。"""
        data: List[List[Any]] = kwargs.get("data", [])
        if not data or not all(isinstance(x, list) for x in data):
            raise ToolError("需要二维列表", code=1002)
        
        max_len: int = max(len(row) for row in data)
        transposed: List[List[Any]] = [
            [data[r][c] if c < len(data[r]) else None for r in range(len(data))] for c in range(max_len)
        ]
        
        return {
            "transposed": transposed,
            "original_shape": [len(data), max_len],
            "new_shape": [max_len, len(data)],
        }

    @staticmethod
    def _do_melt(**kwargs: Any) -> Dict[str, Any]:
        """字典列表长表化：每行拆成 variable/value 两列。"""
        data: List[Dict[str, Any]] = kwargs.get("data", [])
        if not all(isinstance(x, dict) for x in data):
            raise ToolError("需要字典列表", code=1002)
        
        melted: List[Dict[str, Any]] = [
            {"variable": k, "value": v} for item in data for k, v in item.items()
        ]
        return {"melted": melted, "count": len(melted)}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """路由到具体数据转换操作。"""
        action: str = kwargs.get("action", "")
        
        handlers: Dict[str, Any] = {
            "map": self._do_map,
            "filter": self._do_filter,
            "reduce": self._do_reduce,
            "group_by": self._do_group_by,
            "pivot": self._do_pivot,
            "transpose": self._do_transpose,
            "melt": self._do_melt,
        }
        
        handler = handlers.get(action)
        if handler is None:
            raise ToolError("未知操作: " + action, code=1002)
        
        return handler(**kwargs)

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具。"""
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1
        
        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._build_error(str(v), 1002, start)
            
            result: Dict[str, Any] = self.execute(**v)
            elapsed = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed, True)
            return self._build_success(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._build_error(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("数据转换工具内部错误", exc_info=True)
            return self._build_error("工具内部错误", 1006, start)

    def _build_success(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """构建成功响应字典。"""
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _build_error(
        self,
        msg: str,
        code: int,
        start: float,
        details: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """构建错误响应字典。"""
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, elapsed: float, ok: bool) -> None:
        """追加执行历史，保持最多 100 条记录。"""
        self._history.append(
            {"ts": datetime.now(timezone.utc).isoformat(), "ok": ok, "t": elapsed}
        )
        if len(self._history) > 100:
            self._history.pop(0)

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取工具运行统计信息。"""
        ok = self._stats["ok"]
        calls = self._stats["calls"]
        avg_time = self._stats["time"] / ok if ok > 0 else 0.0
        success_rate = ok / max(1, calls)
        return {
            **self._stats,
            "avg": round(avg_time, 4),
            "rate": round(success_rate, 4),
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史执行记录。"""
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。"""
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }
