"""数据去噪工具，支持移动平均、中值滤波、高斯滤波、指数平滑、Savitzky-Golay 滤波。"""

import logging
import math
import statistics
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataDenoiserTool(BaseTool):
    """数据去噪工具，支持多种常见去噪方法。"""

    name: str = "data_denoiser"
    description: str = "数据去噪工具，支持移动平均、中值滤波、高斯滤波、指数平滑、Savitzky-Golay滤波"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    _VALID_METHODS: tuple = (
        "moving_average",
        "median",
        "gaussian",
        "exponential",
        "savgol",
    )

    def __init__(self) -> None:
        """初始化工具实例，建立历史记录与统计容器。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {
            "calls": 0,
            "ok": 0,
            "fail": 0,
            "time": 0.0,
        }

    def _setup_parameters(self) -> None:
        """配置工具输入参数。"""
        self.add_parameter("data", list, required=True, description="待去噪数据")
        self.add_parameter(
            "method",
            str,
            required=False,
            default="moving_average",
            choices=list(self._VALID_METHODS),
            description="去噪方法",
        )
        self.add_parameter("window", int, required=False, default=5, description="窗口大小")
        self.add_parameter("sigma", float, required=False, default=1.0, description="高斯标准差")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行去噪操作并返回结果。

        Args:
            **kwargs: 包含 data、method、window、sigma 等参数。

        Returns:
            包含 denoised、method、window、original 的字典。

        Raises:
            ToolError: 当无数值数据或方法不支持时抛出。
        """
        data: List[Any] = kwargs.get("data", [])
        method: str = str(kwargs.get("method", "moving_average"))
        window: int = int(kwargs.get("window", 5))
        sigma: float = float(kwargs.get("sigma", 1.0))

        values: List[float] = [float(x) for x in data if isinstance(x, (int, float))]
        if not values:
            raise ToolError("无数值数据", code=1002)

        if method not in self._VALID_METHODS:
            raise ToolError(f"不支持的方法: {method}", code=1002)

        handlers: Dict[str, Any] = {
            "moving_average": lambda: self._moving_average(values, window),
            "median": lambda: self._median_filter(values, window),
            "gaussian": lambda: self._gaussian_filter(values, window, sigma),
            "exponential": lambda: self._exponential_smooth(values, window),
            "savgol": lambda: self._savgol_filter(values, window),
        }
        
        result: List[float] = handlers[method]()
        return {"denoised": result, "method": method, "window": window, "original": values}

    @staticmethod
    def _moving_average(values: List[float], window: int) -> List[float]:
        """移动平均去噪。
        
        Args:
            values: 数值序列。
            window: 滑动窗口大小。
            
        Returns:
            去噪后的序列。
        """
        n: int = len(values)
        result: List[float] = []
        for i in range(n):
            start = max(0, i - window // 2)
            end = min(n, i + window // 2 + 1)
            result.append(round(sum(values[start:end]) / (end - start), 4))
        return result

    @staticmethod
    def _median_filter(values: List[float], window: int) -> List[float]:
        """中值滤波去噪。
        
        Args:
            values: 数值序列。
            window: 滑动窗口大小。
            
        Returns:
            去噪后的序列。
        """
        n: int = len(values)
        result: List[float] = []
        for i in range(n):
            start = max(0, i - window // 2)
            end = min(n, i + window // 2 + 1)
            result.append(statistics.median(values[start:end]))
        return result

    @staticmethod
    def _gaussian_filter(
        values: List[float], window: int, sigma: float
    ) -> List[float]:
        """高斯滤波去噪。
        
        Args:
            values: 数值序列。
            window: 滤波窗口大小。
            sigma: 标准差。
            
        Returns:
            去噪后的序列。
            
        Raises:
            ToolError: 当高斯核归一化失败时抛出。
        """
        half_window: int = window // 2
        # 生成高斯核
        kernel: List[float] = [
            math.exp(-((x ** 2) / (2 * sigma ** 2)))
            for x in range(-half_window, half_window + 1)
        ]
        ksum: float = sum(kernel)
        if ksum == 0:
            raise ToolError("高斯核归一化失败（sigma过小）", code=1002)
        
        kernel = [k / ksum for k in kernel]

        n: int = len(values)
        result: List[float] = []
        for i in range(n):
            val: float = 0.0
            for j, k in enumerate(kernel):
                idx = i + j - half_window
                if 0 <= idx < n:
                    val += values[idx] * k
            result.append(round(val, 4))
        return result

    @staticmethod
    def _exponential_smooth(values: List[float], window: int) -> List[float]:
        """指数平滑去噪。
        
        Args:
            values: 数值序列。
            window: 窗口大小，用于计算平滑因子。
            
        Returns:
            去噪后的序列。
            
        Raises:
            ToolError: 当窗口无效时抛出。
        """
        if window <= 0:
            raise ToolError("窗口大小必须为正数", code=1002)
            
        alpha: float = 2.0 / (window + 1)
        result: List[float] = [float(values[0])]
        for i in range(1, len(values)):
            result.append(round(alpha * values[i] + (1 - alpha) * result[-1], 4))
        return result

    @staticmethod
    def _savgol_filter(values: List[float], window: int) -> List[float]:
        """Savitzky-Golay 滤波去噪（线性拟合简化版）。
        
        Args:
            values: 数值序列。
            window: 窗口大小。
            
        Returns:
            去噪后的序列。
        """
        half: int = window // 2
        n: int = len(values)
        result: List[float] = list(values)
        
        if half <= 0 or n <= 2 * half:
            return result

        # 线性拟合参数计算
        x: List[int] = list(range(-half, half + 1))
        x_mean: float = sum(x) / len(x)
        x_sq_dev: float = sum((xi - x_mean) ** 2 for xi in x)
        
        if x_sq_dev == 0:
            return result

        for i in range(half, n - half):
            segment: List[float] = values[i - half : i + half + 1]
            y_mean: float = sum(segment) / len(segment)
            num: float = sum((x[j] - x_mean) * (segment[j] - y_mean) for j in range(len(x)))
            slope: float = num / x_sq_dev
            intercept: float = y_mean - slope * x_mean
            result[i] = round(intercept, 4)
            
        return result

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具的主入口，包含统一的状态追踪与错误处理。
        
        Args:
            params: 可选的参数字典。
            
        Returns:
            包含执行状态和结果的字典。
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(validated), 1002, start)
            
            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(True, elapsed)
            return self._success_result(result, elapsed)
        
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _success_result(self, result: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """构建成功响应字典。
        
        Args:
            result: 内部执行结果。
            elapsed: 执行耗时。
            
        Returns:
            标准化的成功响应。
        """
        return {
            "success": True,
            "data": result,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _err(
        self,
        msg: str,
        code: int,
        start: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """构建错误响应字典。
        
        Args:
            msg: 错误信息。
            code: 错误代码。
            start: 开始时间戳。
            details: 额外细节。
            
        Returns:
            标准化的错误响应。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, ok: bool, elapsed: float) -> None:
        """追加执行历史，保持最多 100 条记录。
        
        Args:
            ok: 是否成功。
            elapsed: 耗时。
        """
        self._history.append(
            {"ts": datetime.now(timezone.utc).isoformat(), "ok": ok, "t": elapsed}
        )
        if len(self._history) > 100:
            self._history.pop(0)

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取工具运行统计信息。
        
        Returns:
            统计字典。
        """
        ok: int = self._stats["ok"]
        calls: int = self._stats["calls"]
        avg_time: float = self._stats["time"] / ok if ok > 0 else 0.0
        success_rate: float = ok / max(1, calls)
        
        return {
            **self._stats,
            "avg": round(avg_time, 4),
            "rate": round(success_rate, 4),
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史执行记录。
        
        Args:
            limit: 返回记录条数限制。
            
        Returns:
            历史记录列表。
        """
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。
        
        Returns:
            描述符字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }

    def __repr__(self) -> str:
        """返回工具的可读表示。"""
        return f"<{self.__class__.__name__} v{self.version}>"
