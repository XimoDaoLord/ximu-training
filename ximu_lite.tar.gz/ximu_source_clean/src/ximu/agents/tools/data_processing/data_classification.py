"""数据分类工具，提供规则式数据类型推断 + 轻量多数票基线。"""

import re
from collections import Counter
from typing import Any, Dict, List, Tuple

from src.ximu.agents.tools.base import BaseTool, ToolError


# 预编译正则表达式以提高性能
_REGEX_BOOLEAN_WORDS = re.compile(r"^(true|false|yes|no|是|否)$", re.IGNORECASE)
_REGEX_NUMERIC = re.compile(r"^-?\d+(\.\d+)?$")
_REGEX_DATE = re.compile(r"^\d{4}[-/]\d{1,2}[-/]\d{1,2}[日]?$")
_REGEX_EMAIL = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
_REGEX_URL = re.compile(r"^https?://\S+$")


def _classify_value(v: Any) -> str:
    """
    根据值的字符串特征推断其数据类型。
    
    Args:
        v: 任意类型的输入值。
    
    Returns:
        推断出的类型字符串，如 'numeric', 'text', 'bool' 等。
    """
    if v is None:
        return "missing"
    if isinstance(v, bool):
        return "bool"
    if isinstance(v, (int, float)):
        return "numeric"
    
    s = str(v).strip()
    if not s:
        return "empty"
    
    # 使用预编译正则进行匹配
    if _REGEX_BOOLEAN_WORDS.match(s):
        return "bool"
    if _REGEX_NUMERIC.match(s):
        return "numeric"
    if _REGEX_DATE.match(s):
        return "date"
    if _REGEX_EMAIL.match(s):
        return "email"
    if _REGEX_URL.match(s):
        return "url"
    
    # 简单的分类特征：短字符串且独特字符比例较高
    if len(s) <= 20 and len(set(s)) <= len(s) * 0.6:
        return "categorical"
    
    return "text"


def _infer_column(values: List[Any]) -> Dict[str, Any]:
    """
    对单列数据做类型推断，采用多数票 + 基数率策略。
    
    Args:
        values: 一列数据的值列表。
    
    Returns:
        包含推断类型、样本数、唯一值数及置信度的字典。
    """
    # 过滤掉无效值
    present = [v for v in values if v not in (None, "", [])]
    if not present:
        return {"type": "empty", "samples": 0, "unique": 0}

    votes: Counter = Counter(_classify_value(v) for v in present)
    dtype: str = votes.most_common(1)[0][0]
    unique_count: int = len({str(v) for v in present})

    # 如果多数为文本但基数率低，可能是分类变量
    if dtype == "text" and unique_count / len(present) < 0.4:
        dtype = "categorical"

    # 计算置信度
    matching_votes = sum(v for k, v in votes.items() if k == dtype)
    confidence: float = round(matching_votes / len(present), 2)
    
    return {
        "type": dtype, 
        "samples": len(present), 
        "unique": unique_count,
        "vote_confidence": confidence, 
        "vote_breakdown": dict(votes)
    }


class DataClassificationTool(BaseTool):
    """数据分类工具，基于规则进行数据类型推断和基础预测。"""

    name: str = "data_classification"
    description: str = "数据分类工具（规则式数据类型推断 + 多数票基线）"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "analytics"]
    author: str = "汐沫AI"

    _VALID_ACTIONS: Tuple[str, ...] = (
        "infer_schema", "classify_value", "train", "predict",
        "evaluate", "metrics", "cross_validate", "importance",
    )

    def __init__(self) -> None:
        """初始化工具实例，设置默认基线值。"""
        super().__init__()
        self._majority: Any = None

    def _setup_parameters(self) -> None:
        """初始化工具参数定义。"""
        self.add_parameter("action", str, required=True, choices=list(self._VALID_ACTIONS), description="操作类型")
        self.add_parameter("features", list, required=False, default=[], description="特征列表")
        self.add_parameter("labels", list, required=False, default=[], description="标签列表")
        self.add_parameter("data", list, required=False, default=[], description="记录列表")
        self.add_parameter("value", str, required=False, default="", description="单值输入")
        self.add_parameter("model", str, required=False, default="rule_majority", description="模型名称")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """
        根据 action 路由到对应处理方法。
        
        Args:
            **kwargs: 包含操作参数及数据的键值对。
            
        Returns:
            操作结果字典。
            
        Raises:
            ToolError: 当操作未知时抛出。
        """
        action: str = str(kwargs.get("action", ""))
        dispatch: Dict[str, Any] = {
            "infer_schema": self._infer_schema_internal,
            "classify_value": self._classify_value_internal,
            "train": self._train_internal,
            "predict": self._predict_internal,
            "evaluate": self._evaluate_internal,
            "metrics": self._metrics_internal,
            "cross_validate": self._cross_validate_internal,
            "importance": self._importance_internal,
        }
        
        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        
        return handler(kwargs)

    def _infer_schema_internal(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        推断数据结构，生成列级 Schema。
        
        Args:
            kwargs: 输入参数，包含 data 或 features。
            
        Returns:
            包含 schema 及其统计信息的字典。
        """
        records: List[Any] = kwargs.get("data") or kwargs.get("features", [])
        if not records:
            raise ToolError("需要 data(记录列表)", code=1002)

        columns: Dict[str, List[Any]] = {}
        if records and isinstance(records[0], dict):
            for rec in records:
                for key, value in rec.items():
                    columns.setdefault(str(key), []).append(value)
            schema: Dict[str, Dict[str, Any]] = {col: _infer_column(vals) for col, vals in columns.items()}
        else:
            schema = {"__all__": _infer_column(records)}

        return {"schema": schema, "rows": len(records), "columns": list(schema.keys())}

    @staticmethod
    def _classify_value_internal(kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        对单个值进行类型分类。
        
        Args:
            kwargs: 输入参数，包含待分类的值。
            
        Returns:
            包含值及其类型推断结果的字典。
        """
        value: Any = kwargs.get("value", "")
        return {"value": value, "type": _classify_value(value)}

    def _train_internal(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        训练多数票基线模型，记录 majority 预测值。
        
        Args:
            kwargs: 包含 features 和 labels 的训练参数。
            
        Returns:
            训练状态及基线值的字典。
        """
        features: List[Any] = kwargs.get("features", [])
        labels: List[Any] = kwargs.get("labels", [])
        
        if not features:
            raise ToolError("需要 features", code=1002)

        if labels:
            # 使用标签计算多数值
            self._majority = Counter([str(x) for x in labels]).most_common(1)[0][0]
        else:
            # 如果没有标签，计算数值特征的均值作为基线
            col: List[Any] = [x[0] if isinstance(x, list) and x else x for x in features]
            nums: List[float] = [x for x in col if isinstance(x, (int, float))]
            self._majority = (sum(nums) / len(nums)) if nums else None

        return {
            "model": kwargs.get("model", "rule_majority"), 
            "trained": True,
            "samples": len(features), 
            "baseline": self._majority, 
            "training_time_s": 0.001,
        }

    def _predict_internal(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        使用已训练的基线模型进行预测。
        
        Args:
            kwargs: 包含特征数据的预测参数。
            
        Returns:
            预测结果列表。
        """
        features: List[Any] = kwargs.get("features", [])
        if not features:
            raise ToolError("需要 features", code=1002)

        pred: Any = self._majority if self._majority is not None else "0"
        return {
            "predictions": [pred] * len(features), 
            "model": kwargs.get("model", "rule_majority"),
            "count": len(features), 
            "baseline": pred,
        }

    def _evaluate_internal(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        评估基线模型的准确率。
        
        Args:
            kwargs: 包含标签的评估参数。
            
        Returns:
            评估指标字典。
        """
        labels: List[Any] = kwargs.get("labels", [])
        if not labels:
            return {"note": "无标签，无法计算指标；仅返回基线", "baseline": self._majority}

        preds: List[Any] = [self._majority] * len(labels)
        correct: int = sum(1 for p, t in zip(preds, labels) if str(p) == str(t))
        accuracy: float = round(correct / max(1, len(labels)), 3)
        
        return {
            "accuracy": accuracy, 
            "model": kwargs.get("model", "rule_majority"),
            "tested": len(labels), 
            "baseline_always": self._majority,
        }

    def _metrics_internal(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        计算综合指标（模拟实现）。
        
        Args:
            kwargs: 输入参数。
            
        Returns:
            指标字典。
        """
        return {
            "precision": 0.0, 
            "recall": 0.0, 
            "f1": 0.0, 
            "model": kwargs.get("model", "rule_majority")
        }

    def _cross_validate_internal(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        交叉验证（模拟实现）。
        
        Args:
            kwargs: 输入参数。
            
        Returns:
            交叉验证结果。
        """
        return {"cv_scores": [0.0], "std": 0.0, "model": kwargs.get("model", "rule_majority")}

    def _importance_internal(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        特征重要性（模拟实现）。
        
        Args:
            kwargs: 输入参数。
            
        Returns:
            重要性字典。
        """
        return {"importance": {}, "model": kwargs.get("model", "rule_majority")}
