"""
XML解析器工具，支持解析、XPath查询、转换、验证和元素统计。
"""
from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Union

import xml.etree.ElementTree as ET

from src.ximu.agents.tools.base import BaseTool, ToolError

logger: logging.Logger = logging.getLogger("ximu.tool")


class XmlParserTool(BaseTool):
    """XML解析器工具，支持解析、XPath查询、转换、验证和元素统计。"""

    name: str = "xml_parser"
    description: str = "XML解析器，支持解析、XPath查询、转换、验证"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"
    _MAX_RESULT_ITEMS: int = 100
    _MAX_TEXT_LENGTH: int = 500
    _HISTORY_LIMIT: int = 100
    _VALID_ACTIONS: List[str] = ["parse", "xpath", "to_json", "to_dict", "validate", "elements"]

    def __init__(self) -> None:
        """初始化XmlParserTool实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """定义工具的输入参数。"""
        self.add_parameter(
            "action", str, required=True,
            choices=self._VALID_ACTIONS,
            description="指定要执行的操作类型"
        )
        self.add_parameter("data", str, required=True, description="XML字符串内容")
        self.add_parameter(
            "xpath", str, required=False, default="",
            description="XPath表达式（仅当action为xpath时有效）"
        )

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行指定的XML操作。

        Args:
            **kwargs: 必须包含action和data，可选包含xpath。

        Returns:
            根据action返回对应的结果字典。

        Raises:
            ToolError: 当XML解析失败或操作无效时抛出。
        """
        action: str = kwargs.get("action", "")
        data: str = kwargs.get("data", "")
        xpath_expr: str = kwargs.get("xpath", "")
        if not data:
            raise ToolError("XML数据不能为空", code=1001)
        try:
            root: ET.Element = ET.fromstring(data)
        except ET.ParseError as exc:
            raise ToolError(f"XML解析失败: {exc}", code=1008) from exc

        handler_map: Dict[str, Any] = {
            "parse": lambda: self._parse(root),
            "xpath": lambda: self._xpath(root, xpath_expr),
            "to_json": lambda: {"result": self._element_to_dict(root)},
            "to_dict": lambda: {"result": self._element_to_dict(root)},
            "validate": lambda: {"valid": True, "root_tag": root.tag},
            "elements": lambda: self._elements(root),
        }
        handler = handler_map.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _parse(self, root: ET.Element) -> Dict[str, Any]:
        """解析XML根节点并返回基础信息。

        Args:
            root: 已解析的XML根元素。

        Returns:
            包含根标签、属性、子节点数量和命名空间信息的字典。
        """
        xmlns_keys: Set[str] = {k for k in root.attrib.keys() if "xmlns" in k.lower()}
        return {
            "root_tag": root.tag,
            "root_attrib": dict(root.attrib),
            "children_count": len(root),
            "xmlns": sorted(xmlns_keys),
        }

    def _xpath(self, root: ET.Element, xpath_expr: str) -> Dict[str, Any]:
        """使用XPath表达式查询元素。

        Args:
            root: XML根元素。
            xpath_expr: XPath表达式字符串。

        Returns:
            包含匹配元素列表的字典。

        Raises:
            ToolError: 当XPath表达式为空或查询失败时抛出。
        """
        if not xpath_expr:
            raise ToolError("XPath表达式不能为空", code=1002)
        try:
            elements: List[ET.Element] = root.findall(xpath_expr)
        except Exception as exc:
            raise ToolError(f"XPath查询失败: {exc}", code=1003) from exc
        results: List[Dict[str, Any]] = []
        for elem in elements[: self._MAX_RESULT_ITEMS]:
            text: str = (elem.text or "").strip()
            results.append({
                "tag": elem.tag,
                "attrib": dict(elem.attrib),
                "text": text[: self._MAX_TEXT_LENGTH],
            })
        return {"xpath": xpath_expr, "count": len(results), "results": results}

    def _elements(self, root: ET.Element) -> Dict[str, Any]:
        """统计XML中所有元素的标签分布。

        Args:
            root: XML根元素。

        Returns:
            包含总元素数量和标签分布的字典。
        """
        tag_counts: Dict[str, int] = {}
        for elem in root.iter():
            tag_counts[elem.tag] = tag_counts.get(elem.tag, 0) + 1
        return {"total_elements": sum(tag_counts.values()), "tag_distribution": tag_counts}

    def _element_to_dict(self, element: ET.Element) -> Any:
        """将ElementTree元素递归转换为Python字典。

        Args:
            element: 要转换的XML元素。

        Returns:
            转换后的字典或基本类型值。
        """
        result: Dict[str, Any] = {}
        if element.attrib:
            result["@attributes"] = dict(element.attrib)
        children = list(element)
        if not children and element.text and element.text.strip():
            return element.text.strip()
        for child in children:
            child_data = self._element_to_dict(child)
            if child.tag in result:
                if isinstance(result[child.tag], list):
                    result[child.tag].append(child_data)
                else:
                    result[child.tag] = [result[child.tag], child_data]
            else:
                result[child.tag] = child_data
        return result

    def _error_result(self, message: str, code: int, start_time: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构建错误响应字典。"""
        return {
            "success": False, "data": None, "error": message, "error_code": code,
            "error_details": details or {}, "execution_time": round(time.monotonic() - start_time, 4),
            "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def _success_result(self, result: Any, elapsed: float) -> Dict[str, Any]:
        """构建成功响应字典。"""
        return {
            "success": True, "data": result, "error": None, "execution_time": elapsed,
            "tool": self.name, "version": self.version, "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具的主入口。"""
        params = params or {}
        start_time: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            valid, validated = self.validate_parameters(params)
            if not valid:
                self._stats["fail"] += 1
                return self._error_result(str(validated), 1002, start_time)
            result = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start_time, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": True, "t": elapsed})
            if len(self._history) > self._HISTORY_LIMIT: self._history.pop(0)
            return self._success_result(result, elapsed)
        except ToolError as exc:
            self._stats["fail"] += 1
            return self._error_result(exc.message, exc.code, start_time, exc.details)
        except Exception as exc:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._error_result("工具内部错误", 1006, start_time)

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取统计信息。"""
        ok: int = self._stats["ok"]
        calls: int = self._stats["calls"]
        return {**self._stats, "avg": round(self._stats["time"] / ok, 4) if ok > 0 else 0.0, "rate": round(ok / max(1, calls), 4)}
