"""数据采样工具\n\n支持随机、分层、系统、加权和自助法采样。\n"""

from __future__ import annotations

import random
from typing import Any, Dict, List, Optional

from src.ximu.agents.tools.base import BaseTool, ToolError


class DataSamplerTool(BaseTool):
    """数据采样工具，支持随机、分层、系统、加权和自助法采样。"""

    name: str = "data_sampler"
    description: str = "数据采样工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化采样工具。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """注册工具参数。"""
        self.add_parameter("data", list, required=True, description="输入数据列表")
        self.add_parameter("action", str, required=False, default="random", choices=["random", "stratified", "systematic", "weighted", "bootstrap"], description="采样方式")
        self.add_parameter("size", int, required=False, default=10, description="样本大小")
        self.add_parameter("field", str, required=False, default="", description="分层字段")
        self.add_parameter("weights", list, required=False, default=[], description="权重列表")
        self.add_parameter("seed", int, required=False, default=42, description="随机种子")

    def _validate_sampling_params(self, data: List[Any], size: int) -> None:
        """验证采样参数。

        Args:
            data: 数据列表。
            size: 样本大小。

        Raises:
            ToolError: 当数据为空或参数无效时抛出。
        """
        if not data:
            raise ToolError("数据为空", code=1002)
        if size < 0:
            raise ToolError("样本大小必须为非负整数", code=1002)

    def _random_sample(self, data: List[Any], size: int) -> Dict[str, Any]:
        """执行随机采样。

        Args:
            data: 数据列表。
            size: 样本大小。

        Returns:
            采样结果字典。
        """
        sample = random.sample(data, min(size, len(data)))
        return {"sample": sample, "size": len(sample), "method": "random"}

    def _stratified_sample(self, data: List[Any], field: str, size: int) -> Dict[str, Any]:
        """执行分层采样。

        Args:
            data: 数据列表。
            field: 分层字段。
            size: 样本大小。

        Returns:
            采样结果字典。

        Raises:
            ToolError: 当字段缺失或数据非字典列表时抛出。
        """
        if not field:
            raise ToolError("分层采样需要提供 field 参数", code=1002)
        if not all(isinstance(item, dict) for item in data):
            raise ToolError("分层采样要求数据为字典列表", code=1002)
        groups: Dict[Any, List[Any]] = {}
        for item in data:
            key = item.get(field)
            groups.setdefault(key, []).append(item)
        num_groups = len(groups)
        if num_groups == 0:
            return {"sample": [], "size": 0, "strata": 0, "method": "stratified"}
        per_group = max(1, size // num_groups)
        sample: List[Any] = []
        for items in groups.values():
            sample.extend(random.sample(items, min(per_group, len(items))))
            if len(sample) >= size:
                break
        return {"sample": sample[:size], "size": min(len(sample), size), "strata": num_groups, "method": "stratified"}

    def _systematic_sample(self, data: List[Any], size: int) -> Dict[str, Any]:
        """执行系统采样。

        Args:
            data: 数据列表。
            size: 样本大小。

        Returns:
            采样结果字典。
        """
        interval = max(1, len(data) // size) if size > 0 else 1
        start = random.randint(0, interval - 1)
        sample = [data[i] for i in range(start, len(data), interval)][:size]
        return {"sample": sample, "size": len(sample), "interval": interval, "method": "systematic"}

    def _weighted_sample(self, data: List[Any], weights: List[float], size: int) -> Dict[str, Any]:
        """执行加权采样。

        Args:
            data: 数据列表。
            weights: 权重列表。
            size: 样本大小。

        Returns:
            采样结果字典。

        Raises:
            ToolError: 当权重无效时抛出。
        """
        if not weights or len(weights) != len(data):
            raise ToolError("weights 必须有效且长度与 data 一致", code=1002)
        if any(w <= 0 for w in weights):
            raise ToolError("weights 中所有值必须为正数", code=1002)
        sample = random.choices(data, weights=weights, k=size)
        return {"sample": sample, "size": size, "method": "weighted"}

    def _bootstrap_sample(self, data: List[Any], size: int) -> Dict[str, Any]:
        """执行自助法采样。

        Args:
            data: 数据列表。
            size: 样本大小。

        Returns:
            采样结果字典。
        """
        sample = [random.choice(data) for _ in range(size)]
        return {"sample": sample, "size": size, "method": "bootstrap"}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行采样逻辑。

        Args:
            **kwargs: 包含data, action, size, field, weights, seed等参数。

        Returns:
            采样结果字典。

        Raises:
            ToolError: 当参数无效或操作未知时抛出。
        """
        data: List[Any] = kwargs.get("data", [])
        action: str = kwargs.get("action", "random")
        size: int = int(kwargs.get("size", 10))
        field: str = kwargs.get("field", "")
        seed: int = int(kwargs.get("seed", 42))
        weights: List[float] = kwargs.get("weights", [])

        self._validate_sampling_params(data, size)
        random.seed(seed)
        clamped_size = max(0, min(size, len(data)))
        if clamped_size == 0:
            return {"sample": [], "size": 0, "method": action}

        dispatch: Dict[str, Any] = {
            "random": lambda: self._random_sample(data, clamped_size),
            "stratified": lambda: self._stratified_sample(data, field, clamped_size),
            "systematic": lambda: self._systematic_sample(data, clamped_size),
            "weighted": lambda: self._weighted_sample(data, weights, clamped_size),
            "bootstrap": lambda: self._bootstrap_sample(data, clamped_size),
        }
        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()
