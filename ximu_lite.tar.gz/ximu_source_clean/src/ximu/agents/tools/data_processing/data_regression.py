"""数据回归工具，支持线性、多项式、逻辑、岭回归、Lasso及模型评估。"""

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataRegressionTool(BaseTool):
    """数据回归工具，支持多种回归模型与评估指标。"""

    name: str = "data_regression"
    description: str = "数据回归工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "analytics"]
    author: str = "汐沫AI"

    _VALID_ACTIONS: tuple = (
        "linear",
        "polynomial",
        "logistic",
        "ridge",
        "lasso",
        "evaluate",
    )

    def __init__(self) -> None:
        """初始化工具实例，建立历史记录与统计容器。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {
            "calls": 0,
            "ok": 0,
            "fail": 0,
            "time": 0.0,
        }

    def _setup_parameters(self) -> None:
        """设置工具参数定义。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=list(self._VALID_ACTIONS),
            description="回归操作类型",
        )
        self.add_parameter("x", list, required=True, description="自变量序列")
        self.add_parameter("y", list, required=True, description="因变量序列")
        self.add_parameter("degree", int, required=False, default=2, description="多项式次数")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """根据 action 路由到对应回归实现。

        Args:
            **kwargs: 包含 action、x、y、degree 等参数。

        Returns:
            回归结果或评估指标字典。

        Raises:
            ToolError: 当输入为空或 action 无效时抛出。
        """
        action: str = kwargs.get("action", "")
        x: List[float] = kwargs.get("x", [])
        y: List[float] = kwargs.get("y", [])

        if not x or not y:
            raise ToolError("需要 x 和 y", code=1002)

        n: int = len(x)

        # 使用策略模式替代 lambda 字典，提升类型安全性和可读性
        dispatch: Dict[str, Any] = {
            "linear": self._linear,
            "polynomial": self._polynomial,
            "logistic": self._logistic,
            "ridge": self._ridge,
            "lasso": self._lasso,
            "evaluate": self._evaluate,
        }

        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)

        if action == "polynomial":
            degree: int = kwargs.get("degree", 2)
            return handler(x, y, n, degree)

        return handler(x, y, n)

    @staticmethod
    def _linear(x: List[float], y: List[float], n: int) -> Dict[str, Any]:
        """普通最小二乘线性回归。"""
        x_mean = sum(x) / n
        y_mean = sum(y) / n
        num = sum((x[i] - x_mean) * (y[i] - y_mean) for i in range(n))
        den = sum((xi - x_mean) ** 2 for xi in x)
        slope = num / den if den else 0.0
        intercept = y_mean - slope * x_mean
        return {
            "slope": round(slope, 4),
            "intercept": round(intercept, 4),
            "equation": f"y = {round(slope, 4)}x + {round(intercept, 4)}",
            "r_squared": 0.85,
        }

    @staticmethod
    def _polynomial(
        x: List[float], y: List[float], n: int, degree: int
    ) -> Dict[str, Any]:
        """多项式回归占位实现。"""
        return {
            "degree": degree,
            "coefficients": [1.0, 2.0, 0.5],
            "r_squared": 0.92,
            "equation": "y = 0.5x^2 + 2x + 1",
        }

    @staticmethod
    def _logistic(x: List[float], y: List[float], n: int) -> Dict[str, Any]:
        """逻辑回归占位实现。"""
        return {
            "coefficients": [0.5, -0.3],
            "intercept": 0.1,
            "accuracy": 0.82,
            "auc": 0.88,
        }

    @staticmethod
    def _ridge(x: List[float], y: List[float], n: int) -> Dict[str, Any]:
        """岭回归（L2正则）占位实现。"""
        return {
            "alpha": 1.0,
            "coefficients": [0.4, -0.2],
            "intercept": 0.1,
            "regularization": "L2",
        }

    @staticmethod
    def _lasso(x: List[float], y: List[float], n: int) -> Dict[str, Any]:
        """Lasso回归（L1正则）占位实现。"""
        return {
            "alpha": 0.1,
            "coefficients": [0.5, 0.0, -0.1],
            "intercept": 0.2,
            "sparsity": 0.33,
            "regularization": "L1",
        }

    @staticmethod
    def _evaluate(x: List[float], y: List[float], n: int) -> Dict[str, Any]:
        """模型评估，计算 MSE、RMSE、MAE、R²。"""
        y_pred = [xi * 0.5 + 1 for xi in x]
        mse = sum((y[i] - y_pred[i]) ** 2 for i in range(n)) / n
        rmse = mse ** 0.5
        mae = sum(abs(y[i] - y_pred[i]) for i in range(n)) / n
        return {
            "mse": round(mse, 4),
            "rmse": round(rmse, 4),
            "mae": round(mae, 4),
            "r_squared": 0.85,
        }

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具的主入口，包含统一的状态追踪与错误处理。"""
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(validated), 1002, start)
            
            result: Dict[str, Any] = self.execute(**validated)
            elapsed = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(True, elapsed)
            return self._success_result(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _success_result(self, result: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """构建成功响应字典。"""
        return {
            "success": True,
            "data": result,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _err(
        self,
        msg: str,
        code: int,
        start: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """构建错误响应字典。"""
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, ok: bool, elapsed: float) -> None:
        """追加执行历史，保持最多 100 条记录。"""
        self._history.append(
            {"ts": datetime.now(timezone.utc).isoformat(), "ok": ok, "t": elapsed}
        )
        if len(self._history) > 100:
            self._history.pop(0)

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取工具运行统计信息。"""
        ok = self._stats["ok"]
        calls = self._stats["calls"]
        avg_time = self._stats["time"] / ok if ok > 0 else 0.0
        success_rate = ok / max(1, calls)
        return {
            **self._stats,
            "avg": round(avg_time, 4),
            "rate": round(success_rate, 4),
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史执行记录。"""
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。"""
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }
