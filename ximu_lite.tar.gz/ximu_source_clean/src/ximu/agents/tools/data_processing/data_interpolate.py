from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataInterpolateTool(BaseTool):
    """
    数据插值工具类，支持线性、三次、最近邻、外推、填充缺失及平滑操作。

    该工具封装了多种数据插值算法，用于处理时间序列或数值序列中的缺失值、
    数据点生成及信号平滑需求。所有插值逻辑均基于纯 Python 实现，
    不依赖外部科学计算库，确保轻量级依赖和广泛的兼容性。
    """

    name: str = "data_interpolate"
    description: str = "数据插值工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "analytics"]
    author: str = "汐沫AI"

    _VALID_ACTIONS: Tuple[str, ...] = (
        "linear",
        "cubic",
        "nearest",
        "extrapolate",
        "fill_missing",
        "smooth",
    )

    def __init__(self) -> None:
        """
        初始化数据插值工具。

        构造工具实例，注册参数定义，准备执行插值操作所需的内部状态。
        """
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """
        配置工具接受的参数定义。

        注册 action、x、y、x_new 等参数，指定其类型、必填性及可选值范围，
        以便外部调用者正确传参并触发参数校验。
        """
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=list(self._VALID_ACTIONS),
            description="插值操作类型",
        )
        self.add_parameter("x", list, required=True, description="X值列表，应为数值型列表")
        self.add_parameter("y", list, required=True, description="Y值列表，应为数值型列表，与x等长")
        self.add_parameter(
            "x_new",
            list,
            required=False,
            default=[],
            description="新的X值列表，用于插值计算",
        )

    def _validate_sequences(self, x: List[Union[int, float, None]], y: List[Union[int, float, None]]) -> None:
        """
        校验输入序列的有效性。

        确保 x 和 y 非空且长度一致，否则抛出 ToolError。

        Args:
            x: X 轴数值列表。
            y: Y 轴数值列表。

        Raises:
            ToolError: 当输入为空或长度不匹配时抛出。
        """
        if not x or not y:
            raise ToolError("需要非空的x和y列表", code=1002)
        if len(x) != len(y):
            raise ToolError("x和y的长度必须相同", code=1002)

    def _linear_interpolate(
        self, x: List[Union[int, float]], y: List[Union[int, float]], x_new: List[Union[int, float]]
    ) -> Dict[str, Any]:
        """
        执行线性插值计算。

        根据给定的 x_new 点，利用 x/y 中的相邻点计算对应的 y 值。
        对于超出 x 范围的值，使用边界值进行填充（截断式插值）。

        Args:
            x: 原始 X 坐标列表。
            y: 原始 Y 坐标列表。
            x_new: 目标插值 X 坐标列表。

        Returns:
            包含插值结果、方法及查询点的字典。
        """
        if not x_new:
            return {"interpolated": [], "method": "linear", "x_new": []}

        result: List[Union[int, float]] = []
        for xi in x_new:
            if xi <= x[0]:
                result.append(y[0])
            elif xi >= x[-1]:
                result.append(y[-1])
            else:
                for i in range(len(x) - 1):
                    if x[i] <= xi <= x[i + 1]:
                        t: float = (xi - x[i]) / (x[i + 1] - x[i])
                        result.append(y[i] + t * (y[i + 1] - y[i]))
                        break
        return {"interpolated": result, "method": "linear", "x_new": x_new}

    def _cubic_interpolate(
        self, x: List[Union[int, float]], y: List[Union[int, float]]
    ) -> Dict[str, Any]:
        """
        执行三次插值（占位实现）。

        当前版本返回元信息，保留扩展接口。实际应用中可替换为 SciPy 或其他库实现。

        Args:
            x: 原始 X 坐标列表。
            y: 原始 Y 坐标列表。

        Returns:
            包含方法标识和数据长度的字典。
        """
        return {
            "method": "cubic",
            "x": x,
            "y": y,
            "smoothness": 0.5,
            "interpolated_points": len(x),
        }

    def _nearest_interpolate(
        self, x: List[Union[int, float]], y: List[Union[int, float]], x_new: List[Union[int, float]]
    ) -> Dict[str, Any]:
        """
        执行最近邻插值。

        为每个 x_new 点寻找距离最近的 x 值，并返回对应的 y 值。

        Args:
            x: 原始 X 坐标列表。
            y: 原始 Y 坐标列表。
            x_new: 目标插值 X 坐标列表。

        Returns:
            包含最近邻结果及查询点的字典。
        """
        if not x_new:
            return {"interpolated": [], "method": "nearest", "x_new": []}

        result: List[Union[int, float]] = []
        for xi in x_new:
            min_index: int = min(range(len(x)), key=lambda i: abs(x[i] - xi))
            result.append(y[min_index])
        return {"interpolated": result, "method": "nearest", "x_new": x_new}

    def _extrapolate(
        self, x: List[Union[int, float]], y: List[Union[int, float]]
    ) -> Dict[str, Any]:
        """
        执行线性外推。

        基于最后两个点计算斜率，并向前外推固定步长（10个单位）。

        Args:
            x: 原始 X 坐标列表。
            y: 原始 Y 坐标列表。

        Returns:
            包含外推值及方法的字典。
        """
        if len(x) < 2:
            val: Union[int, float] = y[0] if y else 0
            return {"extrapolated": val, "method": "constant", "value": val}
        slope: float = (y[-1] - y[-2]) / (x[-1] - x[-2])
        extrapolated_value: float = y[-1] + slope * 10
        return {"extrapolated": extrapolated_value, "method": "linear", "value": extrapolated_value}

    def _fill_missing(self, y: List[Union[int, float, None]]) -> Dict[str, Any]:
        """
        填充缺失值（前向填充策略）。

        将列表中的 None 值用其前一个非 None 值替代。若首个元素为 None，则计数但不填充（或保持 None，视具体需求，此处仅计数）。

        Args:
            y: 包含潜在缺失值（None）的数值列表。

        Returns:
            包含填充后列表及填充数量的字典。
        """
        filled: List[Union[int, float, None]] = y[:]
        missing_count: int = 0
        for i in range(1, len(filled)):
            if filled[i] is None:
                filled[i] = filled[i - 1]
                missing_count += 1
        if filled and filled[0] is None:
            missing_count += 1
        return {"filled": filled, "missing_filled": missing_count}

    def _smooth(self, y: List[Union[int, float]]) -> Dict[str, Any]:
        """
        执行移动平均平滑。

        使用固定窗口大小（3）对序列进行平滑处理。

        Args:
            y: 待平滑的数值列表。

        Returns:
            包含平滑后列表及窗口参数的字典。
        """
        if not y:
            return {"smoothed": [], "window": 3, "method": "moving_average"}
        
        window_size: int = 3
        half_window: int = window_size // 2
        smoothed: List[float] = []
        for i in range(len(y)):
            start_idx: int = max(0, i - half_window)
            end_idx: int = min(len(y), i + half_window + 1)
            window_values: List[Union[int, float]] = y[start_idx:end_idx]
            smoothed.append(sum(window_values) / len(window_values))
        return {"smoothed": smoothed, "window": window_size, "method": "moving_average"}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """
        执行插值操作的主入口。

        根据 action 参数分发到具体的插值算法实现。

        Args:
            **kwargs: 包含 action、x、y、x_new 等键值的字典。

        Returns:
            插值计算结果字典。

        Raises:
            ToolError: 当输入无效或操作未知时抛出。
        """
        action: str = str(kwargs.get("action", ""))
        x: List[Union[int, float, None]] = kwargs.get("x", [])
        y: List[Union[int, float, None]] = kwargs.get("y", [])
        x_new: List[Union[int, float]] = kwargs.get("x_new", [])

        if action not in self._VALID_ACTIONS:
            raise ToolError(f"未知操作: {action}", code=1002)

        # 对于需要 x/y 对应关系的操作进行基础校验
        if action in ("linear", "cubic", "nearest", "extrapolate"):
            self._validate_sequences(x, y)

        if action == "linear":
            return self._linear_interpolate(x, y, x_new)
        if action == "cubic":
            return self._cubic_interpolate(x, y)
        if action == "nearest":
            return self._nearest_interpolate(x, y, x_new)
        if action == "extrapolate":
            return self._extrapolate(x, y)
        if action == "fill_missing":
            return self._fill_missing(y)
        if action == "smooth":
            return self._smooth(y)
            
        # 理论上不会到达这里，因为前面有 action 校验
        raise ToolError(f"未知操作: {action}", code=1002)
