"""
数据清洗工具。

支持去重、填充缺失值、移除离群点、归一化、修剪和全面清洗。
"""

from __future__ import annotations

import hashlib
import json
import statistics
from typing import Any, Dict, List, Set, Union

from src.ximu.agents.tools.base import BaseTool, ToolError


# 性能优化：去重集合中存 blake2b 短摘要(16字节=32hex)，而非完整 JSON 字符串。
# 万条 dict 去重时，seen 内存占用从 ~MB 级字符串降到 ~KB 级；
# blake2b SIMD 硬件加速比直接存字符串做哈希表查找快，且避免长字符串比较。
def _dedup_key(item: Any) -> str:
    """生成去重键：dict/list 用 blake2b 短摘要，标量直接用 repr。"""
    if isinstance(item, (dict, list)):
        # separators 去掉空白，序列化更快更短
        payload = json.dumps(item, sort_keys=True, ensure_ascii=False,
                             separators=(",", ":")).encode("utf-8")
        return hashlib.blake2b(payload, digest_size=16).hexdigest()
    return str(item)


class DataCleanerTool(BaseTool):
    """数据清洗工具，提供多种数据预处理操作。"""

    name: str = "data_cleaner"
    description: str = "数据清洗工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化工具。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """注册参数定义。"""
        self.add_parameter(
            "action", str, required=True,
            choices=["deduplicate", "fill_missing", "remove_outliers", "normalize", "trim", "clean_all"],
            description="操作类型"
        )
        self.add_parameter("data", list, required=True, description="数据列表")
        self.add_parameter(
            "strategy", str, required=False, default="mean",
            choices=["mean", "median", "mode", "zero", "drop"],
            description="填充策略"
        )
        self.add_parameter("threshold", float, required=False, default=3.0, description="离群点阈值")

    def _deduplicate(self, data: List[Any]) -> Dict[str, Any]:
        """去重操作，移除完全相同的数据项。"""
        seen: Set[str] = set()
        result: List[Any] = []
        for item in data:
            key = _dedup_key(item)
            if key not in seen:
                seen.add(key)
                result.append(item)
        return {
            "original": len(data),
            "cleaned": len(result),
            "removed": len(data) - len(result),
            "data": result
        }

    def _fill_missing(self, data: List[Any], strategy: str) -> Dict[str, Any]:
        """填充缺失值（None或空字符串）。"""
        numeric_values: List[Union[int, float]] = [x for x in data if isinstance(x, (int, float))]
        if strategy == "drop":
            result = [x for x in data if x is not None and x != ""]
            return {"filled": 0, "removed": len(data) - len(result), "data": result}
        fill_value: Union[int, float, str] = 0
        if numeric_values:
            if strategy == "mean":
                fill_value = statistics.mean(numeric_values)
            elif strategy == "median":
                fill_value = statistics.median(numeric_values)
            elif strategy == "zero":
                fill_value = 0
            else:
                fill_value = 0
        result: List[Any] = [fill_value if (x is None or x == "") else x for x in data]
        filled_count: int = sum(1 for x in data if x is None or x == "")
        return {"filled": filled_count, "data": result}

    def _remove_outliers(self, data: List[Any], threshold: float) -> Dict[str, Any]:
        """移除离群点，基于标准差阈值。"""
        numeric: List[Union[int, float]] = [x for x in data if isinstance(x, (int, float))]
        if len(numeric) < 3:
            return {"data": data, "removed": 0}
        mean: float = statistics.mean(numeric)
        stdev: float = statistics.stdev(numeric)
        if stdev == 0:
            return {"original": len(data), "cleaned": len(data), "removed": 0, "data": data}
        result: List[Any] = [
            x for x in data
            if not isinstance(x, (int, float)) or abs(x - mean) <= threshold * stdev
        ]
        return {
            "original": len(data),
            "cleaned": len(result),
            "removed": len(data) - len(result),
            "data": result
        }

    def _normalize(self, data: List[Any]) -> Dict[str, Any]:
        """归一化操作，将数值映射到[0, 1]区间。"""
        numeric: List[Union[int, float]] = [x for x in data if isinstance(x, (int, float))]
        if not numeric:
            return {"data": data}
        mn: Union[int, float] = min(numeric)
        mx: Union[int, float] = max(numeric)
        rng: Union[int, float] = mx - mn if mx != mn else 1
        result: List[Any] = [
            round((x - mn) / rng, 4) if isinstance(x, (int, float)) else x
            for x in data
        ]
        return {"data": result, "min": mn, "max": mx}

    def _trim(self, data: List[Any]) -> Dict[str, Any]:
        """修剪字符串首尾空格。"""
        result: List[Any] = [x.strip() if isinstance(x, str) else x for x in data]
        return {"data": result}

    def _clean_all(self, data: List[Any], strategy: str) -> Dict[str, Any]:
        """执行全面清洗：去重+填充缺失值。"""
        result: List[Any] = data
        steps: List[str] = []
        dedup_result = self._deduplicate(result)
        result = dedup_result["data"]
        steps.append(f"deduplicate: removed {dedup_result['removed']}")
        fill_result = self._fill_missing(result, strategy)
        result = fill_result["data"]
        steps.append(f"fill_missing: filled {fill_result['filled']}")
        return {"data": result, "steps": steps}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行清洗操作。"""
        action: str = kwargs.get("action", "")
        data: List[Any] = kwargs.get("data", [])
        strategy: str = kwargs.get("strategy", "mean")
        threshold: float = kwargs.get("threshold", 3.0)
        if not data:
            raise ToolError("数据为空", code=1002)
        handlers: Dict[str, Any] = {
            "deduplicate": lambda d: self._deduplicate(d),
            "fill_missing": lambda d: self._fill_missing(d, strategy),
            "remove_outliers": lambda d: self._remove_outliers(d, threshold),
            "normalize": lambda d: self._normalize(d),
            "trim": lambda d: self._trim(d),
            "clean_all": lambda d: self._clean_all(d, strategy),
        }
        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler(data)
