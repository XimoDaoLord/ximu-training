import csv
import html
import io
import json
import logging
from typing import Any, Dict, List, Optional, Tuple, Union
from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataFormatterTool(BaseTool):
    """数据格式化工具，支持表格、CSV、JSON、Markdown、HTML、TSV格式输出。"""

    name: str = "data_formatter"
    description: str = "数据格式化工具，支持表格、CSV、JSON、Markdown、HTML、TSV格式输出"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    _SUPPORTED_FORMATS: Tuple[str, ...] = ("table", "csv", "json", "markdown", "html", "tsv")
    _CSV_DELIMITER: str = ","
    _TSV_DELIMITER: str = "\t"

    def __init__(self) -> None:
        """初始化工具实例。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数。"""
        self.add_parameter("data", list, required=True, description="要格式化的数据，可以是列表或字典列表")
        self.add_parameter("format", str, required=False, default="table", choices=list(self._SUPPORTED_FORMATS), description="输出格式")
        self.add_parameter("headers", list, required=False, default=[], description="表头列表")
        self.add_parameter("indent", int, required=False, default=2, description="JSON输出的缩进空格数")

    def _normalize_headers(self, data: List[Any], headers: List[str]) -> List[str]:
        """标准化表头，从字典数据中自动推导缺失表头。
        
        Args:
            data: 原始数据。
            headers: 提供的表头。
            
        Returns:
            标准化后的表头列表。
        """
        if headers:
            return list(headers)
        if data and isinstance(data[0], dict):
            return list(data[0].keys())
        if data and isinstance(data[0], (list, tuple)):
            return [f"col_{i}" for i in range(len(data[0]))]
        return []

    def _extract_row_values(self, row: Any, headers: List[str]) -> List[str]:
        """提取单行数据的字符串值列表。
        
        Args:
            row: 单行数据。
            headers: 表头列表。
            
        Returns:
            字符串值列表。
        """
        if isinstance(row, dict):
            return [str(row.get(h, "")) for h in headers]
        if isinstance(row, (list, tuple)):
            return [str(val) for val in row]
        return [str(row)]

    def _calculate_column_widths(self, all_rows: List[List[str]]) -> List[int]:
        """计算每列的最大宽度。
        
        Args:
            all_rows: 包含所有行的二维列表。
            
        Returns:
            每列的宽度列表。
        """
        if not all_rows:
            return []
        num_cols = len(all_rows[0])
        return [max(len(str(row[i])) for row in all_rows) for i in range(num_cols)]

    def _format_json(self, data: List[Any], indent: int) -> Dict[str, Any]:
        """格式化为JSON字符串。
        
        Args:
            data: 原始数据。
            indent: 缩进空格数。
            
        Returns:
            包含格式化结果的字典。
        """
        json_str: str = json.dumps(data, ensure_ascii=False, indent=indent, default=str)
        return {"formatted": json_str, "format": "json"}

    def _format_delimited(self, data: List[Any], headers: List[str], delimiter: str, fmt: str) -> Dict[str, Any]:
        """格式化为分隔符文本（CSV/TSV）。
        
        Args:
            data: 原始数据。
            headers: 表头列表。
            delimiter: 分隔符。
            fmt: 格式类型。
            
        Returns:
            包含格式化结果的字典。
        """
        lines: List[str] = []
        if headers:
            lines.append(delimiter.join(str(h) for h in headers))
        for row in data:
            row_values: List[str] = self._extract_row_values(row, headers)
            lines.append(delimiter.join(row_values))
        return {"formatted": "\n".join(lines), "format": fmt, "rows": len(data)}

    def _format_markdown(self, data: List[Any], headers: List[str]) -> Dict[str, Any]:
        """格式化为Markdown表格。
        
        Args:
            data: 原始数据。
            headers: 表头列表。
            
        Returns:
            包含格式化结果的字典。
        """
        lines: List[str] = []
        if headers:
            lines.append("| " + " | ".join(str(h) for h in headers) + " |")
            lines.append("| " + " | ".join(["---"] * len(headers)) + " |")
        for row in data:
            row_values: List[str] = self._extract_row_values(row, headers)
            lines.append("| " + " | ".join(row_values) + " |")
        return {"formatted": "\n".join(lines), "format": "markdown", "rows": len(data)}

    def _format_html(self, data: List[Any], headers: List[str]) -> Dict[str, Any]:
        """格式化为HTML表格。
        
        Args:
            data: 原始数据。
            headers: 表头列表。
            
        Returns:
            包含格式化结果的字典。
        """
        parts: List[str] = ["<table>"]
        if headers:
            parts.append("<thead><tr>")
            parts.append("".join(f"<th>{html.escape(str(h))}</th>" for h in headers))
            parts.append("</tr></thead>")
        parts.append("<tbody>")
        for row in data:
            row_values: List[str] = self._extract_row_values(row, headers)
            cells: str = "".join(f"<td>{html.escape(v)}</td>" for v in row_values)
            parts.append(f"<tr>{cells}</tr>")
        parts.append("</tbody>")
        parts.append("</table>")
        return {"formatted": "".join(parts), "format": "html", "rows": len(data)}

    def _format_table(self, data: List[Any], headers: List[str]) -> Dict[str, Any]:
        """格式化为对齐文本表格。
        
        Args:
            data: 原始数据。
            headers: 表头列表。
            
        Returns:
            包含格式化结果的字典。
        """
        if not headers:
            return {"formatted": "", "format": "table"}
        
        all_rows: List[List[str]] = [list(headers)]
        for row in data:
            all_rows.append(self._extract_row_values(row, headers))
        
        col_widths: List[int] = self._calculate_column_widths(all_rows)
        lines: List[str] = []
        lines.append(" | ".join(str(h).ljust(col_widths[i]) for i, h in enumerate(headers)))
        lines.append("-+-".join("-" * w for w in col_widths))
        for row in all_rows[1:]:
            lines.append(" | ".join(val.ljust(col_widths[i]) for i, val in enumerate(row)))
        
        return {"formatted": "\n".join(lines), "format": "table", "rows": len(data)}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行数据格式化。
        
        Args:
            **kwargs: 包含data, format, headers, indent等参数。
            
        Returns:
            包含格式化结果的字典。
            
        Raises:
            ToolError: 当数据为空或格式不支持时抛出。
        """
        data: List[Any] = kwargs.get("data", [])
        fmt: str = kwargs.get("format", "table")
        headers: List[str] = kwargs.get("headers", [])
        indent: int = kwargs.get("indent", 2)

        if not data:
            raise ToolError("数据为空", code=1002)

        if fmt not in self._SUPPORTED_FORMATS:
            raise ToolError(f"不支持的格式: {fmt}", code=1002)

        headers = self._normalize_headers(data, headers)

        try:
            if fmt == "json":
                return self._format_json(data, indent)
            elif fmt == "csv":
                return self._format_delimited(data, headers, self._CSV_DELIMITER, fmt)
            elif fmt == "tsv":
                return self._format_delimited(data, headers, self._TSV_DELIMITER, fmt)
            elif fmt == "markdown":
                return self._format_markdown(data, headers)
            elif fmt == "html":
                return self._format_html(data, headers)
            elif fmt == "table":
                return self._format_table(data, headers)
            else:
                raise ToolError(f"不支持的格式: {fmt}", code=1002)
        except (IndexError, TypeError, ValueError) as e:
            raise ToolError(f"数据格式错误: {str(e)}", code=1003) from e