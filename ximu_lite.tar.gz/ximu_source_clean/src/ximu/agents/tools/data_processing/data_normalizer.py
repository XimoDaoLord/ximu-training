"""数据归一化工具，支持Min-Max、Z-score、L1/L2范数等多种归一化方法。

通过提取数值提取和归一化方法，提高代码复用性。
"""

from __future__ import annotations

import math
import statistics
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError


class DataNormalizerTool(BaseTool):
    """数据归一化工具类，提供数值标准化处理能力。
    
    支持多种归一化方法，核心逻辑通过统一方法分发。
    """

    name: str = "data_normalizer"
    description: str = "数据归一化工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化工具实例。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """配置工具参数。"""
        self.add_parameter("data", list, required=True, description="待归一化的数据列表")
        self.add_parameter(
            "method", str, required=False, default="minmax",
            choices=["minmax", "zscore", "decimal", "log", "l1", "l2", "maxabs"],
            description="归一化方法"
        )
        self.add_parameter("field", str, required=False, default="", description="指定数据字段名")
        self.add_parameter("feature_range", list, required=False, default=[0, 1], description="特征缩放范围")

    def _extract_numeric_values(self, data: List[Any], field: str) -> List[Union[int, float]]:
        """从数据中提取数值列表。

        Args:
            data: 数据列表，元素为数值或字典。
            field: 当数据为字典时提取的字段名。

        Returns:
            提取的数值列表。
        """
        if field and data and all(isinstance(x, dict) for x in data):
            return [x.get(field, 0) for x in data]
        return [x for x in data if isinstance(x, (int, float))]

    def _normalize_minmax(self, values: List[Union[int, float]], feature_range: List[float]) -> List[float]:
        """执行Min-Max归一化。

        Args:
            values: 数值列表。
            feature_range: 目标范围，如[0, 1]。

        Returns:
            归一化后的值列表。
        """
        min_val, max_val = min(values), max(values)
        range_val = max_val - min_val if max_val != min_val else 1.0
        low, high = feature_range[0], feature_range[1]
        return [round(low + (x - min_val) / range_val * (high - low), 6) for x in values]

    def _normalize_zscore(self, values: List[Union[int, float]]) -> List[float]:
        """执行Z-score标准归一化。

        Args:
            values: 数值列表。

        Returns:
            归一化后的值列表。
        """
        mean = statistics.mean(values)
        std = statistics.stdev(values) if len(values) > 1 else 1.0
        if std == 0:
            return [0.0] * len(values)
        return [round((x - mean) / std, 6) for x in values]

    def _normalize_decimal(self, values: List[Union[int, float]]) -> List[float]:
        """执行小数量化归一化。

        Args:
            values: 数值列表。

        Returns:
            归一化后的值列表。
        """
        max_abs = max(abs(x) for x in values)
        if max_abs == 0:
            return [0.0] * len(values)
        int_part = int(max_abs)
        scale = 10 ** max(1, len(str(int_part)))
        return [round(x / scale, 6) for x in values]

    def _normalize_log(self, values: List[Union[int, float]]) -> List[float]:
        """执行对数归一化。

        Args:
            values: 数值列表。

        Returns:
            归一化后的值列表。
        """
        return [round(math.log1p(abs(x)), 6) for x in values]

    def _normalize_l1(self, values: List[Union[int, float]]) -> List[float]:
        """执行L1范数归一化。

        Args:
            values: 数值列表。

        Returns:
            归一化后的值列表。
        """
        total = sum(abs(x) for x in values)
        if total == 0:
            return [0.0] * len(values)
        return [round(x / total, 6) for x in values]

    def _normalize_l2(self, values: List[Union[int, float]]) -> List[float]:
        """执行L2范数归一化。

        Args:
            values: 数值列表。

        Returns:
            归一化后的值列表。
        """
        total = math.sqrt(sum(x * x for x in values))
        if total == 0:
            return [0.0] * len(values)
        return [round(x / total, 6) for x in values]

    def _normalize_maxabs(self, values: List[Union[int, float]]) -> List[float]:
        """执行最大绝对值归一化。

        Args:
            values: 数值列表。

        Returns:
            归一化后的值列表。
        """
        max_abs = max(abs(x) for x in values)
        if max_abs == 0:
            return [0.0] * len(values)
        return [round(x / max_abs, 6) for x in values]

    def _apply_normalization(self, values: List[Union[int, float]], method: str, feature_range: Optional[List[float]] = None) -> List[float]:
        """根据指定方法执行归一化。

        Args:
            values: 数值列表。
            method: 归一化方法名称。
            feature_range: 特征范围，仅Min-Max方法使用。

        Returns:
            归一化后的值列表。

        Raises:
            ToolError: 当方法不受支持时抛出。
        """
        feature_range = feature_range if feature_range is not None else [0, 1]
        dispatch: Dict[str, Any] = {
            "minmax": lambda: self._normalize_minmax(values, feature_range),
            "zscore": lambda: self._normalize_zscore(values),
            "decimal": lambda: self._normalize_decimal(values),
            "log": lambda: self._normalize_log(values),
            "l1": lambda: self._normalize_l1(values),
            "l2": lambda: self._normalize_l2(values),
            "maxabs": lambda: self._normalize_maxabs(values),
        }
        if method not in dispatch:
            raise ToolError(f"不支持的归一化方法: {method}", code=1002)
        return dispatch[method]()

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行数据归一化操作。

        Args:
            **kwargs: 包含data, method, field, feature_range等参数。

        Returns:
            归一化结果字典。

        Raises:
            ToolError: 当无数值数据或方法不支持时抛出。
        """
        data: List[Any] = kwargs.get("data", [])
        method: str = kwargs.get("method", "minmax")
        field: str = kwargs.get("field", "")
        feature_range: List[float] = kwargs.get("feature_range", [0, 1])

        values = self._extract_numeric_values(data, field)
        if not values:
            raise ToolError("数据中无数值可供归一化", code=1002)

        normalized = self._apply_normalization(values, method, feature_range)

        if field and data and all(isinstance(x, dict) for x in data):
            result: List[Dict[str, Any]] = []
            for i, item in enumerate(data):
                new_item = dict(item)
                new_item[f"{field}_normalized"] = normalized[i] if i < len(normalized) else None
                result.append(new_item)
            return {"normalized": result, "method": method}

        return {"normalized": normalized, "method": method, "original": values}