"""
数据统计工具，支持描述统计、频率统计、分布分析。
"""

import time
import statistics
import logging
from typing import Any, Dict, List, Optional, Union
from datetime import datetime, timezone

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")

class DataStatisticsTool(BaseTool):
    """数据统计工具，支持描述统计、频率统计、分布分析。"""

    name: str = "data_statistics"
    description: str = "数据统计工具，支持描述统计、频率统计、分布分析"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """设置工具参数。"""
        self.add_parameter("data", list, required=True, description="数据")
        self.add_parameter("action", str, required=False, default="describe", 
                         choices=["describe", "frequency", "distribution", "correlation", "percentile", "quartile"], 
                         description="操作")
        self.add_parameter("field", str, required=False, default="", description="字段")
        self.add_parameter("bins", int, required=False, default=10, description="分箱数")
        self.add_parameter("data2", list, required=False, default=[], description="第二组数据")

    def _extract_values(self, data: List[Any], field: str) -> List[Union[int, float]]:
        """从数据中提取数值。"""
        if field and all(isinstance(x, dict) for x in data):
            values = [x.get(field) for x in data if isinstance(x.get(field), (int, float))]
        else:
            values = [x for x in data if isinstance(x, (int, float))]
        return values

    def _describe(self, values: List[Union[int, float]]) -> Dict[str, Any]:
        """描述统计。"""
        if not values:
            raise ToolError("无数值数据", code=1002)
        
        return {
            "count": len(values),
            "mean": round(statistics.mean(values), 4),
            "median": statistics.median(values),
            "mode": statistics.mode(values) if len(set(values)) < len(values) else None,
            "std": round(statistics.stdev(values), 4) if len(values) > 1 else 0,
            "variance": round(statistics.variance(values), 4) if len(values) > 1 else 0,
            "min": min(values),
            "max": max(values),
            "range": max(values) - min(values),
            "skewness": round(self._skewness(values), 4),
            "kurtosis": round(self._kurtosis(values), 4),
        }

    def _frequency(self, data: List[Any], field: str) -> Dict[str, Any]:
        """频率统计。"""
        if field and all(isinstance(x, dict) for x in data):
            items = [x.get(field) for x in data]
        else:
            items = data
        
        freq: Dict[str, int] = {}
        for item in items:
            key = str(item)
            freq[key] = freq.get(key, 0) + 1
        
        return {"frequency": dict(sorted(freq.items(), key=lambda x: x[1], reverse=True)), "unique": len(freq)}

    def _distribution(self, values: List[Union[int, float]], bins: int) -> Dict[str, Any]:
        """分布分析。"""
        if not values:
            raise ToolError("无数值数据", code=1002)
        
        mn, mx = min(values), max(values)
        bin_width = (mx - mn) / bins if bins > 0 else 1
        dist = [0] * bins
        for v in values:
            idx = min(int((v - mn) / bin_width), bins - 1)
            dist[idx] += 1
        
        return {
            "bins": bins,
            "bin_width": round(bin_width, 4),
            "min": mn,
            "max": mx,
            "distribution": [
                {"bin": i, "range": [round(mn + i * bin_width, 4), round(mn + (i + 1) * bin_width, 4)], "count": dist[i]}
                for i in range(bins)
            ],
        }

    def _correlation(self, values: List[Union[int, float]], data2: List[Union[int, float]]) -> Dict[str, Any]:
        """相关性分析。"""
        if not data2 or len(data2) != len(values):
            raise ToolError("需要等长data2", code=1002)
        
        n = len(values)
        mean1, mean2 = statistics.mean(values), statistics.mean(data2)
        cov = sum((values[i] - mean1) * (data2[i] - mean2) for i in range(n)) / n
        std1, std2 = statistics.stdev(values), statistics.stdev(data2)
        corr = cov / (std1 * std2) if std1 and std2 else 0
        
        return {"correlation": round(corr, 4), "covariance": round(cov, 4), "n": n}

    def _percentile(self, values: List[Union[int, float]]) -> Dict[str, Any]:
        """百分位数分析。"""
        if not values:
            raise ToolError("无数值数据", code=1002)
        
        sorted_v = sorted(values)
        percentiles: Dict[str, Union[int, float]] = {}
        for p in [10, 25, 50, 75, 90, 95, 99]:
            idx = int(len(sorted_v) * p / 100)
            percentiles[str(p)] = sorted_v[min(idx, len(sorted_v) - 1)]
        
        return {"percentiles": percentiles}

    def _quartile(self, values: List[Union[int, float]]) -> Dict[str, Union[int, float]]:
        """四分位数分析。"""
        if not values:
            raise ToolError("无数值数据", code=1002)
        
        sorted_v = sorted(values)
        q2 = statistics.median(sorted_v)
        q1 = statistics.median([x for x in sorted_v if x <= q2])
        q3 = statistics.median([x for x in sorted_v if x >= q2])
        
        return {"Q1": q1, "Q2": q2, "Q3": q3, "IQR": q3 - q1, "min": min(values), "max": max(values)}

    def _skewness(self, values: List[Union[int, float]]) -> float:
        """计算偏度。"""
        n = len(values)
        if n < 3:
            return 0
        mean = statistics.mean(values)
        std = statistics.stdev(values)
        if std == 0:
            return 0
        return (n / ((n - 1) * (n - 2))) * sum(((x - mean) / std) ** 3 for x in values)

    def _kurtosis(self, values: List[Union[int, float]]) -> float:
        """计算峰度。"""
        n = len(values)
        if n < 4:
            return 0
        mean = statistics.mean(values)
        std = statistics.stdev(values)
        if std == 0:
            return 0
        return (
            (n * (n + 1) / ((n - 1) * (n - 2) * (n - 3))) * sum(((x - mean) / std) ** 4 for x in values)
            - (3 * (n - 1) ** 2 / ((n - 2) * (n - 3)))
        )

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行数据统计操作。"""
        data: List[Any] = kwargs.get("data", [])
        action: str = kwargs.get("action", "describe")
        field: str = kwargs.get("field", "")
        bins: int = kwargs.get("bins", 10)
        data2: List[Union[int, float]] = kwargs.get("data2", [])
        
        # 使用策略模式替代 if-elif 链
        handlers: Dict[str, Any] = {
            "describe": lambda: self._describe(self._extract_values(data, field)),
            "frequency": lambda: self._frequency(data, field),
            "distribution": lambda: self._distribution(self._extract_values(data, field), bins),
            "correlation": lambda: self._correlation(self._extract_values(data, field), data2),
            "percentile": lambda: self._percentile(self._extract_values(data, field)),
            "quartile": lambda: self._quartile(self._extract_values(data, field)),
        }
        
        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        
        return handler()

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具的主入口。"""
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1
        
        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(validated), 1002, start)
            
            result: Dict[str, Any] = self.execute(**validated)
            elapsed = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(True, elapsed)
            return self._success_result(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _success_result(self, result: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """构建成功响应字典。"""
        return {
            "success": True,
            "data": result,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _err(
        self,
        msg: str,
        code: int,
        start: float,
        details: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """构建错误响应字典。"""
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, ok: bool, elapsed: float) -> None:
        """追加执行历史，保持最多 100 条记录。"""
        self._history.append(
            {"ts": datetime.now(timezone.utc).isoformat(), "ok": ok, "t": elapsed}
        )
        if len(self._history) > 100:
            self._history.pop(0)

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取工具运行统计信息。"""
        ok = self._stats["ok"]
        calls = self._stats["calls"]
        avg_time = self._stats["time"] / ok if ok > 0 else 0.0
        success_rate = ok / max(1, calls)
        return {
            **self._stats,
            "avg": round(avg_time, 4),
            "rate": round(success_rate, 4),
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史执行记录。"""
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。"""
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }
