"""数据编码工具，支持Base64、URL、Hex、Unicode编码与解码。"""

import base64
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union
from urllib.parse import quote, unquote

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataEncoderTool(BaseTool):
    """数据编码工具，支持多种常用编码/解码方式。"""

    name: str = "data_encoder"
    description: str = "数据编码工具，支持Base64、URL、Hex、Unicode编码"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    _VALID_ACTIONS: tuple = (
        "base64_encode",
        "base64_decode",
        "url_encode",
        "url_decode",
        "hex_encode",
        "hex_decode",
        "unicode_encode",
        "unicode_decode",
    )

    def __init__(self) -> None:
        """初始化工具实例，建立历史记录与统计容器。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {
            "calls": 0,
            "ok": 0,
            "fail": 0,
            "time": 0.0,
        }

    def _setup_parameters(self) -> None:
        """配置工具输入参数。"""
        self.add_parameter("data", str, required=True, description="待编码或解码的数据")
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=list(self._VALID_ACTIONS),
            description="编码/解码操作类型",
        )

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行单条编码或解码操作。

        Args:
            **kwargs: 包含 data 和 action 参数的字典。

        Returns:
            包含编码/解码结果及 method 字段的字典。

        Raises:
            ToolError: 当 action 无效或解码失败时抛出。
        """
        data: str = str(kwargs.get("data", ""))
        action: str = str(kwargs.get("action", ""))

        # 使用模块级辅助函数以减少重复代码和状态管理问题
        dispatch: Dict[str, Any] = {
            "base64_encode": lambda: self._base64_encode(data),
            "base64_decode": lambda: self._base64_decode(data),
            "url_encode": lambda: {"encoded": quote(data, safe=""), "method": "url"},
            "url_decode": lambda: {"decoded": unquote(data), "method": "url"},
            "hex_encode": lambda: {"encoded": data.encode("utf-8").hex(), "method": "hex"},
            "hex_decode": lambda: self._hex_decode(data),
            "unicode_encode": lambda: {"encoded": data.encode("unicode_escape").decode("ascii"), "method": "unicode"},
            "unicode_decode": lambda: self._unicode_decode(data),
        }

        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
            
        return handler()

    @staticmethod
    def _base64_encode(data: str) -> Dict[str, str]:
        """对字符串进行 Base64 编码。
        
        Args:
            data: 输入字符串。
            
        Returns:
            包含编码结果的字典。
        """
        encoded: str = base64.b64encode(data.encode("utf-8")).decode("ascii")
        return {"encoded": encoded, "method": "base64"}

    @staticmethod
    def _base64_decode(data: str) -> Dict[str, str]:
        """对 Base64 字符串进行解码。
        
        Args:
            data: Base64 字符串。
            
        Returns:
            包含解码结果的字典。
            
        Raises:
            ToolError: 解码失败时抛出。
        """
        try:
            decoded: str = base64.b64decode(data, validate=True).decode("utf-8", errors="replace")
            return {"decoded": decoded, "method": "base64"}
        except Exception as e:
            raise ToolError(f"Base64解码失败: {e}", code=1008) from e

    @staticmethod
    def _hex_decode(data: str) -> Dict[str, str]:
        """对 Hex 字符串进行解码。
        
        Args:
            data: Hex 字符串。
            
        Returns:
            包含解码结果的字典。
            
        Raises:
            ToolError: 解码失败时抛出。
        """
        try:
            decoded: str = bytes.fromhex(data).decode("utf-8", errors="replace")
            return {"decoded": decoded, "method": "hex"}
        except Exception as e:
            raise ToolError(f"Hex解码失败: {e}", code=1008) from e

    @staticmethod
    def _unicode_decode(data: str) -> Dict[str, str]:
        """对 Unicode 转义字符串进行解码。
        
        Args:
            data: Unicode 转义字符串。
            
        Returns:
            包含解码结果的字典。
            
        Raises:
            ToolError: 解码失败时抛出。
        """
        try:
            # 假设输入是ASCII安全的转义序列
            decoded: str = data.encode("utf-8").decode("unicode_escape")
            return {"decoded": decoded, "method": "unicode"}
        except Exception as e:
            raise ToolError(f"Unicode解码失败: {e}", code=1008) from e

    def encode_multiple(self, data: str, methods: List[str]) -> str:
        """依次使用多种方法对数据进行链式编码。
        
        Args:
            data: 输入数据。
            methods: 编码方法名称列表。
            
        Returns:
            链式编码后的结果字符串。
        """
        result: str = data
        for method in methods:
            # 内部调用 execute 逻辑
            try:
                inner_result: Dict[str, Any] = self.execute(data=result, action=f"{method}_encode")
                result = inner_result.get("encoded", result)
            except ToolError:
                break
        return result

    def auto_detect_encode(self, data: str) -> Dict[str, bool]:
        """尝试对各编码格式进行解码，判断数据可能的编码类型。
        
        Args:
            data: 待检测的字符串。
            
        Returns:
            各编码格式是否可成功解码的布尔字典。
        """
        results: Dict[str, bool] = {}
        # 注意：这里为了逻辑清晰，直接调用静态方法判断，避免依赖 run 的状态管理
        for method in ["base64", "url", "hex", "unicode"]:
            try:
                if method == "base64":
                    base64.b64decode(data, validate=True)
                elif method == "hex":
                    bytes.fromhex(data)
                elif method == "url":
                    unquote(data)
                elif method == "unicode":
                    data.encode("utf-8").decode("unicode_escape")
                
                results[method] = True
            except Exception:
                results[method] = False
        
        return results

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具的主入口，包含统一的状态追踪与错误处理。
        
        Args:
            params: 可选的参数字典。
            
        Returns:
            包含执行状态和结果的字典。
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(validated), 1002, start)
            
            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(True, elapsed)
            return self._success_result(result, elapsed)
        
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _success_result(self, result: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """构建成功响应字典。
        
        Args:
            result: 内部执行结果。
            elapsed: 执行耗时。
            
        Returns:
            标准化的成功响应。
        """
        return {
            "success": True,
            "data": result,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _err(
        self,
        msg: str,
        code: int,
        start: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """构建错误响应字典。
        
        Args:
            msg: 错误信息。
            code: 错误代码。
            start: 开始时间戳。
            details: 额外细节。
            
        Returns:
            标准化的错误响应。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, ok: bool, elapsed: float) -> None:
        """追加执行历史，保持最多 100 条记录。
        
        Args:
            ok: 是否成功。
            elapsed: 耗时。
        """
        self._history.append(
            {"ts": datetime.now(timezone.utc).isoformat(), "ok": ok, "t": elapsed}
        )
        if len(self._history) > 100:
            self._history.pop(0)

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取工具运行统计信息。
        
        Returns:
            统计字典。
        """
        ok: int = self._stats["ok"]
        calls: int = self._stats["calls"]
        avg_time: float = self._stats["time"] / ok if ok > 0 else 0.0
        success_rate: float = ok / max(1, calls)
        
        return {
            **self._stats,
            "avg": round(avg_time, 4),
            "rate": round(success_rate, 4),
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史执行记录。
        
        Args:
            limit: 返回记录条数限制。
            
        Returns:
            历史记录列表。
        """
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。
        
        Returns:
            描述符字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }

    def __repr__(self) -> str:
        """返回工具的可读表示。"""
        return f"<{self.__class__.__name__} v{self.version}>"
