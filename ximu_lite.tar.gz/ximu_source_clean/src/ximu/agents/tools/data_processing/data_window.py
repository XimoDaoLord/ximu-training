"""数据窗口工具。

提供滚动（rolling）、扩展（expanding）、移位（shift）、
重采样（resample）、填充（fill）和滞后（lag）操作。
"""

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataWindowTool(BaseTool):
    """数据窗口工具，提供滚动、扩展、移位、重采样、填充和滞后操作。"""

    name: str = "data_window"
    description: str = "数据窗口工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "analytics"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化数据窗口工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {
            "calls": 0, "ok": 0, "fail": 0, "time": 0.0,
        }

    def _setup_parameters(self) -> None:
        """注册工具参数。"""
        self.add_parameter(
            "action", str, required=True,
            choices=["rolling", "expanding", "shift", "resample", "fill", "lag"],
            description="操作类型",
        )
        self.add_parameter("data", list, required=True, description="数据列表")
        self.add_parameter("window_size", int, required=False, default=3, description="窗口大小")

    # ── 业务操作 ───────────────────────────────────────────────────────

    def _rolling_window(self, data: List[float], window_size: int) -> Dict[str, Any]:
        """计算滚动窗口均值。"""
        rolling_means: List[float] = []
        for i in range(len(data)):
            start: int = max(0, i - window_size + 1)
            window = data[start: i + 1]
            rolling_means.append(round(sum(window) / len(window), 4))
        return {"rolling_mean": rolling_means, "window_size": window_size, "data": data}

    def _expanding_window(self, data: List[float]) -> Dict[str, Any]:
        """计算扩展窗口均值。"""
        expanding_means: List[float] = [
            round(sum(data[: i + 1]) / (i + 1), 4)
            for i in range(len(data))
        ]
        return {"expanding_mean": expanding_means, "data": data}

    def _shift(self, data: List[Any], periods: int) -> Dict[str, Any]:
        """数据移位操作。"""
        if periods > 0:
            shifted: List[Any] = [None] * periods + data[:-periods]
        elif periods < 0:
            shifted = data[abs(periods):] + [None] * abs(periods)
        else:
            shifted = data[:]
        return {"shifted": shifted, "periods": periods, "data": data}

    def _resample(self, data: List[Any]) -> Dict[str, Any]:
        """数据重采样操作（每隔一个元素取一个）。"""
        resampled: List[Any] = data[::2]
        return {
            "resampled": resampled,
            "rule": "2S",
            "original_count": len(data),
            "resampled_count": len(resampled),
        }

    def _fill_missing(self, data: List[Any]) -> Dict[str, Any]:
        """使用前向填充（ffill）处理缺失值。"""
        filled: List[Any] = []
        last_valid: Any = 0
        for value in data:
            if value is not None:
                last_valid = value
                filled.append(value)
            else:
                filled.append(last_valid)
        return {"filled": filled, "method": "ffill", "data": data}

    def _lag(self, data: List[Any], periods: int) -> Dict[str, Any]:
        """数据滞后操作（与 shift 相同语义）。"""
        if periods > 0:
            lagged: List[Any] = [None] * periods + data[:-periods]
        elif periods < 0:
            lagged = data[abs(periods):] + [None] * abs(periods)
        else:
            lagged = data[:]
        return {"lagged": lagged, "periods": periods, "data": data}

    # ── 执行入口 ───────────────────────────────────────────────────────

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """根据 action 分发并执行对应的数据窗口操作。"""
        action: str = kwargs.get("action", "")
        data: List[Any] = kwargs.get("data", [])
        window_size: int = kwargs.get("window_size", 3)
        if not data:
            raise ToolError("需要data", code=1002)
        handlers: Dict[str, Any] = {
            "rolling":  lambda: self._rolling_window(data, window_size),
            "expanding": lambda: self._expanding_window(data),
            "shift":    lambda: self._shift(data, window_size),
            "resample": lambda: self._resample(data),
            "fill":     lambda: self._fill_missing(data),
            "lag":      lambda: self._lag(data, window_size),
        }
        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    # ── run / _err 公共骨架 ───────────────────────────────────────────

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具，包含参数校验、错误处理和统计记录。"""
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1
        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(v), 1002, start)
            result: Dict[str, Any] = self.execute(**v)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(True, elapsed)
            return self._ok_resp(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _err(self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构造错误响应字典。"""
        return {
            "success": False, "data": None, "error": msg,
            "error_code": code, "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name, "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _ok_resp(self, data: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """构造成功响应字典。"""
        return {
            "success": True, "data": data, "error": None,
            "execution_time": elapsed, "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, ok: bool, elapsed: float) -> None:
        """追加历史记录，超出 100 条时淘汰最旧的一条。"""
        self._history.append({
            "ts": datetime.now(timezone.utc).isoformat(),
            "ok": ok, "t": elapsed,
        })
        if len(self._history) > 100:
            self._history.pop(0)

    # ── 统计与描述 ─────────────────────────────────────────────────────

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取工具调用统计信息。"""
        ok: int = self._stats["ok"]
        total: int = self._stats["calls"]
        avg: float = self._stats["time"] / ok if ok > 0 else 0.0
        rate: float = round(ok / max(1, total), 4)
        return {**self._stats, "avg": round(avg, 4), "rate": rate}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的操作历史记录。"""
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具的完整描述符。"""
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }

    def __repr__(self) -> str:
        """返回工具的可读表示字符串。"""
        return f"<{type(self).__name__} name={self.name} v{self.version}>"