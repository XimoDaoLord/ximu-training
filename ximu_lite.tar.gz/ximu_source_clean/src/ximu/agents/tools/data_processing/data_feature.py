"""数据特征工程工具模块，提供基础特征变换方法。"""

from typing import Any, Dict, List, Tuple, Union
from src.ximu.agents.tools.base import BaseTool, ToolError


class DataFeatureTool(BaseTool):
    """数据特征工程工具类，提供特征编码、缩放、归一化、二值化及多项式特征生成等操作。"""

    name: str = "data_feature"
    description: str = "数据特征工程工具"
    version: str = "2.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "analytics"]
    author: str = "汐沫AI"
    PRECISION: int = 4

    VALID_ACTIONS: Tuple[str, ...] = (
        "encode",
        "scale",
        "normalize",
        "binarize",
        "polynomial",
        "select",
    )

    def __init__(self) -> None:
        """初始化数据特征工具实例并注册参数。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """注册特征工程工具参数。"""
        self.add_parameter(
            "action", str, required=True, choices=list(self.VALID_ACTIONS), description="操作类型"
        )
        self.add_parameter("data", list, required=True, description="输入数据列表")
        self.add_parameter("method", str, required=False, default="", description="辅助参数")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行指定的特征工程操作。

        Args:
            **kwargs: 包含action, data, method的参数映射。

        Returns:
            处理结果及元信息字典。

        Raises:
            ToolError: 当数据为空、类型不匹配或操作未知时抛出。
        """
        action: str = str(kwargs.get("action", ""))
        data: List[Any] = kwargs.get("data", [])
        method_param: Any = kwargs.get("method", "")
        if not data:
            raise ToolError("data不能为空", code=1002)

        handlers: Dict[str, Any] = {
            "encode": lambda: self._encode(data),
            "scale": lambda: self._scale(data),
            "normalize": lambda: self._normalize(data),
            "binarize": lambda: self._binarize(data, method_param),
            "polynomial": lambda: self._polynomial(data),
            "select": lambda: self._select_features(data),
        }

        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _check_numeric(self, data: List[Any], action: str) -> None:
        """校验数据是否全为数值类型。

        Args:
            data: 待检查数据列表。
            action: 用于错误提示的操作名。

        Raises:
            ToolError: 包含非数值类型时抛出。
        """
        if not all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in data):
            raise ToolError(f"操作 {action} 需要纯数值数据", code=1002)

    def _encode(self, data: List[Any]) -> Dict[str, Any]:
        """执行标签编码，将唯一值映射为整数索引。

        Args:
            data: 待编码原始数据。

        Returns:
            编码结果及映射表大小。
        """
        unique_values: List[Any] = sorted(set(data), key=str)
        mapping: Dict[Any, int] = {v: i for i, v in enumerate(unique_values)}
        encoded_data: List[int] = [mapping[x] for x in data]
        return {"encoded": encoded_data, "mapping_size": len(mapping), "method": "label_encoding"}

    def _scale(self, data: List[float]) -> Dict[str, Any]:
        """执行标准缩放 (Z-Score)。

        Args:
            data: 待缩放数值数据。

        Returns:
            缩放结果及均值、标准差。

        Raises:
            ToolError: 当数据非数值时抛出。
        """
        self._check_numeric(data, "scale")
        n: int = len(data)
        mean: float = sum(data) / n
        variance: float = sum((x - mean) ** 2 for x in data) / n
        std: float = variance ** 0.5 if variance > 0 else 1.0
        scaled: List[float] = [round((x - mean) / std, self.PRECISION) for x in data]
        return {
            "scaled": scaled,
            "mean": round(mean, self.PRECISION),
            "std_dev": round(std, self.PRECISION),
            "method": "z_score",
        }

    def _normalize(self, data: List[float]) -> Dict[str, Any]:
        """执行Min-Max归一化。

        Args:
            data: 待归一化数值数据。

        Returns:
            归一化结果及min/max值。

        Raises:
            ToolError: 当数据非数值时抛出。
        """
        self._check_numeric(data, "normalize")
        min_val: float = min(data)
        max_val: float = max(data)
        range_val: float = max_val - min_val
        normalized: List[float] = [
            round((x - min_val) / range_val, self.PRECISION) if range_val != 0 else 0.0 for x in data
        ]
        return {"normalized": normalized, "min_val": min_val, "max_val": max_val, "method": "min_max"}

    def _binarize(self, data: List[Any], threshold: Any) -> Dict[str, Any]:
        """执行阈值二值化，将数据映射为0/1。

        Args:
            data: 待二值化数据。
            threshold: 二值化阈值。

        Returns:
            二值化结果及阈值。

        Raises:
            ToolError: 当threshold非数值时抛出。
        """
        self._check_numeric(data, "binarize")
        if not isinstance(threshold, (int, float)) or isinstance(threshold, bool):
            raise ToolError("threshold必须为数值", code=1002)
        binarized: List[int] = [1 if x > threshold else 0 for x in data]
        return {"binarized": binarized, "threshold": threshold, "method": "threshold_binarize"}

    def _polynomial(self, data: List[float]) -> Dict[str, Any]:
        """生成多项式特征 (x^0, x^1, x^2)。

        Args:
            data: 待生成多项式特征的数值数据。

        Returns:
            多项式特征矩阵及特征维数。

        Raises:
            ToolError: 当数据非数值时抛出。
        """
        self._check_numeric(data, "polynomial")
        features: List[List[float]] = [
            [round(x ** d, self.PRECISION) for d in range(3)] for x in data
        ]
        return {"polynomial_features": features, "degree": 2, "features_per_sample": 3}

    def _select_features(self, data: List[Any]) -> Dict[str, Any]:
        """执行基于方差阈值的特征选择模拟。

        Args:
            data: 待选择特征的数据。

        Returns:
            模拟特征选择结果。
        """
        return {
            "selected_indices": [0, 1, 2],
            "removed_indices": [3, 4],
            "method": "variance_threshold",
            "threshold_used": 0.05,
        }

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符及统计信息映射。

        Returns:
            工具描述字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }
