"""
数据验证工具模块。

提供基于规则的数据验证功能，支持类型检查、范围约束、长度限制、
正则模式匹配及枚举值验证。适用于数据清洗前的质量校验。
"""

import re
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.agents.tools.base import BaseTool, ToolError


class DataValidatorTool(BaseTool):
    """
    数据验证工具，支持类型检查、范围验证、模式匹配、规则引擎。

    该工具允许用户定义一套验证规则，并检查输入数据是否符合这些规则。
    支持多种数据结构和验证策略，内置正则编译缓存以提升性能。
    """

    name: str = "data_validator"
    description: str = "数据验证工具，支持类型检查、范围验证、模式匹配、规则引擎"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    _TYPE_MAP: Dict[str, Union[type, Tuple[type, ...]]] = {
        "string": str,
        "integer": int,
        "number": (int, float),
        "boolean": bool,
        "array": list,
        "object": dict,
    }

    # 性能优化：动态正则编译缓存
    _pattern_cache: Dict[str, re.Pattern] = {}
    _MAX_PATTERN_CACHE: int = 128

    def __init__(self) -> None:
        """
        初始化数据验证工具。

        注册参数并初始化内部状态。
        """
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """
        设置工具参数。

        定义 data, rules, action 参数。
        """
        self.add_parameter("data", Any, required=True, description="待验证数据")
        self.add_parameter("rules", dict, required=True, description="验证规则")
        self.add_parameter(
            "action", str, required=False, default="validate", choices=["validate", "schema", "check_types"], description="操作类型"
        )

    def _validate_input(self, data: Any, rules: Dict[str, Any]) -> None:
        """
        验证输入参数的有效性。

        Args:
            data: 待验证数据。
            rules: 验证规则字典。

        Raises:
            ToolError: 当 data 为 None 或 rules 不是字典时抛出。
        """
        if data is None:
            raise ToolError("data 参数不能为 None", code=1001)
        if not isinstance(rules, dict):
            raise ToolError("rules 参数必须是字典类型", code=1001)

    def _check_type(self, value: Any, rule: Dict[str, Any]) -> bool:
        """
        检查值是否符合规则指定的类型。

        Args:
            value: 待检查的值。
            rule: 包含 'type' 键的规则字典。

        Returns:
            类型匹配返回 True，否则返回 False。
        """
        if "type" not in rule:
            return True
        expected_type = self._TYPE_MAP.get(rule["type"])
        if expected_type and not isinstance(value, expected_type):
            return False
        return True

    def _check_range(self, value: Any, rule: Dict[str, Any]) -> List[str]:
        """
        检查数值是否在指定范围内。

        Args:
            value: 数值。
            rule: 包含 'min', 'max' 键的规则。

        Returns:
            错误信息列表，若无错误则为空列表。
        """
        errors: List[str] = []
        # 注意：bool 是 int 的子类，需排除
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            return errors
        if "min" in rule and value < rule["min"]:
            errors.append(f"小于最小值 {rule['min']}")
        if "max" in rule and value > rule["max"]:
            errors.append(f"大于最大值 {rule['max']}")
        return errors

    def _check_length(self, value: Any, rule: Dict[str, Any]) -> List[str]:
        """
        检查序列长度是否满足约束。

        Args:
            value: 可测量长度的对象（如 list, str）。
            rule: 包含 'min_length', 'max_length' 键的规则。

        Returns:
            错误信息列表。
        """
        errors: List[str] = []
        if not hasattr(value, "__len__"):
            return errors
        if "min_length" in rule and len(value) < rule["min_length"]:
            errors.append("长度不足")
        if "max_length" in rule and len(value) > rule["max_length"]:
            errors.append("长度超出")
        return errors

    def _check_pattern(self, value: Any, rule: Dict[str, Any]) -> List[str]:
        """
        检查字符串是否匹配正则表达式模式。

        使用模块级缓存避免重复编译正则表达式。

        Args:
            value: 字符串值。
            rule: 包含 'pattern' 键的规则。

        Returns:
            错误信息列表。
        """
        errors: List[str] = []
        if "pattern" not in rule or not isinstance(value, str):
            return errors
        
        pattern_str = rule["pattern"]
        try:
            compiled = self._pattern_cache.get(pattern_str)
            if compiled is None:
                compiled = re.compile(pattern_str)
                if len(self._pattern_cache) >= self._MAX_PATTERN_CACHE:
                    keys = list(self._pattern_cache.keys())[: self._MAX_PATTERN_CACHE // 2]
                    for k in keys:
                        del self._pattern_cache[k]
                self._pattern_cache[pattern_str] = compiled
            
            if not compiled.match(value):
                errors.append("格式不匹配")
        except re.error as e:
            errors.append(f"无效的正则表达式: {e}")
        
        return errors

    def _check_enum(self, value: Any, rule: Dict[str, Any]) -> List[str]:
        """
        检查值是否在允许的枚举列表中。

        Args:
            value: 待检查值。
            rule: 包含 'enum' 键的规则。

        Returns:
            错误信息列表。
        """
        errors: List[str] = []
        if "enum" in rule and value not in rule["enum"]:
            errors.append("不在允许值范围内")
        return errors

    def _validate_data(self, data: Any, rules: Dict[str, Any]) -> List[Dict[str, str]]:
        """
        验证数据是否符合给定的规则。

        Args:
            data: 待验证的数据对象（通常为 dict）。
            rules: 验证规则字典，键为字段名，值为规则字典。

        Returns:
            包含错误详情（字段及错误描述）的列表。
        """
        errors: List[Dict[str, str]] = []
        for field, rule in rules.items():
            if not isinstance(rule, dict):
                errors.append({"field": field, "error": "规则定义必须是字典类型"})
                continue

            value: Any = data.get(field) if isinstance(data, dict) else None

            if rule.get("required") and value is None:
                errors.append({"field": field, "error": "必填字段缺失"})
                continue

            if value is None:
                continue

            if not self._check_type(value, rule):
                errors.append({"field": field, "error": f"类型错误，期望 {rule['type']}"})
                continue

            for error_msg in self._check_range(value, rule):
                errors.append({"field": field, "error": error_msg})
            for error_msg in self._check_length(value, rule):
                errors.append({"field": field, "error": error_msg})
            for error_msg in self._check_pattern(value, rule):
                errors.append({"field": field, "error": error_msg})
            for error_msg in self._check_enum(value, rule):
                errors.append({"field": field, "error": error_msg})

        return errors

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """
        执行数据验证操作的主入口。

        Args:
            **kwargs: 包含 data, rules, action 等键值的字典。

        Returns:
            验证结果或模式信息字典。

        Raises:
            ToolError: 当操作未知时抛出。
        """
        data: Any = kwargs.get("data")
        rules: Dict[str, Any] = kwargs.get("rules", {})
        action: str = kwargs.get("action", "validate")

        if action == "validate":
            self._validate_input(data, rules)
            errors = self._validate_data(data, rules)
            return {"valid": len(errors) == 0, "errors": errors, "error_count": len(errors)}

        if action == "schema":
            self._validate_input(data, rules)
            return {"schema": rules, "fields": list(rules.keys())}

        if action == "check_types":
            if isinstance(data, dict):
                return {"types": {k: type(v).__name__ for k, v in data.items()}}
            return {"type": type(data).__name__}

        raise ToolError(f"未知操作: {action}", code=1002)
