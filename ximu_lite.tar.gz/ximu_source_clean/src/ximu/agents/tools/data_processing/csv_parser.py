"""
CSV解析器，支持读取、写入、转换、统计等操作。
"""
from __future__ import annotations

import csv
import io
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError


class CsvParserTool(BaseTool):
    """解析和处理 CSV 数据的工具，支持多种操作模式。"""

    name: str = "csv_parser"
    description: str = "CSV解析器"
    version: str = "2.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化 CSV 解析器工具。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """注册参数定义。"""
        self.add_parameter(
            "action", str, required=True,
            choices=["parse", "to_json", "to_dict", "headers", "rows", "columns", "stats"],
            description="操作类型"
        )
        self.add_parameter("data", str, required=True, description="CSV内容")
        self.add_parameter("delimiter", str, required=False, default=",", description="分隔符")
        self.add_parameter("has_header", bool, required=False, default=True, description="是否有表头")
        self.add_parameter("column", str, required=False, default="", description="列名")

    def _parse_csv(self, data: str, delimiter: str) -> List[List[str]]:
        """解析CSV数据为行列表。

        Args:
            data: CSV字符串
            delimiter: 分隔符

        Returns:
            行列表

        Raises:
            ToolError: 当解析失败时抛出
        """
        try:
            reader = csv.reader(io.StringIO(data), delimiter=delimiter)
            return list(reader)
        except Exception as exc:
            raise ToolError(f"CSV解析失败: {exc}", code=1008) from exc

    def _action_parse(self, rows: List[List[str]], has_header: bool) -> Dict[str, Any]:
        """执行parse操作，返回基本统计信息。"""
        return {
            "rows": len(rows),
            "columns": len(rows[0]) if rows else 0,
            "data": rows[:100],
        }

    def _action_to_json(self, rows: List[List[str]], has_header: bool) -> Dict[str, Any]:
        """执行to_json操作，将CSV转换为JSON数组。"""
        if has_header:
            headers = rows[0]
            result = [dict(zip(headers, r)) for r in rows[1:] if len(r) == len(headers)]
        else:
            result = [{"col_" + str(i): v for i, v in enumerate(r)} for r in rows]
        return {"json": result, "count": len(result)}

    def _action_to_dict(self, rows: List[List[str]], has_header: bool) -> Dict[str, Any]:
        """执行to_dict操作，将CSV转换为字典结构。"""
        if has_header:
            headers = rows[0]
            records = [dict(zip(headers, r)) for r in rows[1:] if len(r) == len(headers)]
            return {"headers": headers, "records": records}
        return {"records": rows}

    def _action_headers(self, rows: List[List[str]], has_header: bool) -> Dict[str, Any]:
        """执行headers操作，返回表头列表。"""
        if has_header:
            return {"headers": rows[0]}
        return {"headers": ["col_" + str(i) for i in range(len(rows[0]))]}

    def _action_rows(self, rows: List[List[str]], has_header: bool) -> Dict[str, Any]:
        """执行rows操作，返回数据行列表。"""
        data_rows = rows[1:] if has_header else rows
        return {"rows": data_rows, "count": len(data_rows)}

    def _action_columns(self, rows: List[List[str]], has_header: bool) -> Dict[str, Any]:
        """执行columns操作，按列组织数据。"""
        if not has_header:
            raise ToolError("columns操作需要表头", code=1002)
        headers = rows[0]
        cols = {
            h: [r[i] for r in rows[1:] if i < len(r)]
            for i, h in enumerate(headers)
        }
        return {"columns": cols}

    def _parse_numeric(self, values: List[str]) -> List[float]:
        """将字符串列表解析为数字列表。"""
        result: List[float] = []
        for v in values:
            try:
                result.append(float(v))
            except ValueError:
                continue
        return result

    def _action_stats(self, rows: List[List[str]], has_header: bool) -> Dict[str, Any]:
        """执行stats操作，返回列统计信息。"""
        if not has_header:
            raise ToolError("stats操作需要表头", code=1002)

        headers = rows[0]
        stats: Dict[str, Any] = {
            "row_count": len(rows) - 1,
            "column_count": len(headers),
            "columns": {}
        }

        for i, h in enumerate(headers):
            col_data = [r[i] for r in rows[1:] if i < len(r)]
            numeric = self._parse_numeric(col_data)
            stats["columns"][h] = {
                "count": len(col_data),
                "unique": len(set(col_data)),
                "numeric_count": len(numeric),
                "min": min(numeric) if numeric else None,
                "max": max(numeric) if numeric else None,
                "avg": round(sum(numeric) / len(numeric), 2) if numeric else None,
            }
        return stats

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行 CSV 解析操作。

        Args:
            **kwargs: 包含 action, data, delimiter, has_header, column 等参数。

        Returns:
            根据操作类型返回对应的结果字典。

        Raises:
            ToolError: 当 CSV 数据为空或操作无效时抛出。
        """
        action: str = kwargs.get("action", "")
        data: str = kwargs.get("data", "")
        delimiter: str = kwargs.get("delimiter", ",")
        has_header: bool = kwargs.get("has_header", True)

        if not data:
            raise ToolError("CSV数据为空", code=1008)

        rows = self._parse_csv(data, delimiter)
        if not rows:
            raise ToolError("CSV数据为空", code=1008)

        handlers = {
            "parse": lambda: self._action_parse(rows, has_header),
            "to_json": lambda: self._action_to_json(rows, has_header),
            "to_dict": lambda: self._action_to_dict(rows, has_header),
            "headers": lambda: self._action_headers(rows, has_header),
            "rows": lambda: self._action_rows(rows, has_header),
            "columns": lambda: self._action_columns(rows, has_header),
            "stats": lambda: self._action_stats(rows, has_header),
        }

        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()
