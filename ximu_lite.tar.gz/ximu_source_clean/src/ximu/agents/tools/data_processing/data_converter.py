"""
数据格式转换工具模块。

支持在 JSON, CSV, XML, YAML, TOML 及 Python Dict 字符串之间进行双向转换。
该工具适用于数据清洗、格式标准化及跨系统数据交换场景。
"""

from __future__ import annotations

import ast
import csv
import io
import json
import logging
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataConverterTool(BaseTool):
    """
    数据格式转换工具，支持 JSON/CSV/XML/YAML/TOML 互转。

    该工具封装了多种序列化与反序列化处理器，允许用户指定源格式和目标格式，
    自动完成数据结构的转换。对于缺失的第三方库（如 yaml, toml），将抛出明确的错误。
    """

    name: str = "data_converter"
    description: str = "数据格式转换工具，支持JSON/CSV/XML/YAML/TOML互转"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """
        初始化 DataConverterTool 实例。

        注册参数定义并准备内部处理逻辑。
        """
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """
        配置工具参数字段。

        定义 data, from_format, to_format 及 delimiter 参数。
        """
        self.add_parameter("data", str, required=True, description="输入数据")
        self.add_parameter(
            "from_format",
            str,
            required=True,
            choices=["json", "csv", "xml", "yaml", "toml", "dict"],
            description="源格式",
        )
        self.add_parameter(
            "to_format",
            str,
            required=True,
            choices=["json", "csv", "xml", "yaml", "toml", "dict"],
            description="目标格式",
        )
        self.add_parameter("delimiter", str, required=False, default=",", description="CSV分隔符")

    def _parse_json(self, data: str) -> Any:
        """
        解析 JSON 字符串为 Python 对象。

        Args:
            data: JSON 字符串。

        Returns:
            解析后的 Python 对象（dict/list/str/int等）。

        Raises:
            ToolError: 当 JSON 格式无效时抛出。
        """
        try:
            return json.loads(data)
        except json.JSONDecodeError as e:
            raise ToolError(f"JSON解析错误: {e}", code=1003)

    def _parse_csv(self, data: str, delimiter: str) -> Any:
        """
        解析 CSV 字符串为字典列表。

        Args:
            data: CSV 字符串。
            delimiter: 分隔符。

        Returns:
            字典列表，每个字典代表一行，键为第一行定义的列名。
        """
        reader = csv.reader(io.StringIO(data), delimiter=delimiter)
        rows = list(reader)
        if not rows:
            return []
        return [dict(zip(rows[0], row)) for row in rows[1:]]

    def _parse_xml(self, data: str) -> Any:
        """
        解析 XML 字符串为嵌套字典。

        Args:
            data: XML 字符串。

        Returns:
            表示 XML 结构的字典。
        """
        root = ET.fromstring(data)

        def parse_xml(node: ET.Element) -> Any:
            if len(node) == 0:
                return node.text or ""
            return {child.tag: parse_xml(child) for child in node}

        return parse_xml(root)

    def _parse_dict(self, data: str) -> Any:
        """
        解析 Python 字典字面量字符串。

        使用 ast.literal_eval 确保安全性，防止执行恶意代码。

        Args:
            data: 字典字符串表示。

        Returns:
            解析后的 Python 对象。
        """
        return ast.literal_eval(data)

    def _parse_yaml(self, data: str) -> Any:
        """
        解析 YAML 字符串。

        依赖 PyYAML 库。若未安装则抛出异常。

        Args:
            data: YAML 字符串。

        Returns:
            解析后的 Python 对象。
        """
        try:
            import yaml
            return yaml.safe_load(data)
        except ImportError:
            raise ToolError("YAML模块未安装", code=1004)

    def _parse_toml(self, data: str) -> Any:
        """
        解析 TOML 字符串。

        依赖 tomllib 或 toml 库。若未安装则抛出异常。

        Args:
            data: TOML 字符串。

        Returns:
            解析后的 Python 对象。
        """
        try:
            import tomllib
            return tomllib.loads(data)
        except ImportError:
            raise ToolError("TOML模块未安装", code=1004)

    def _serialize_json(self, obj: Any) -> str:
        """
        序列化对象为 JSON 字符串。

        Args:
            obj: 待序列化对象。

        Returns:
            JSON 字符串。
        """
        return json.dumps(obj, ensure_ascii=False)

    def _serialize_csv(self, obj: Any, delimiter: str) -> str:
        """
        序列化对象为 CSV 字符串。

        仅支持字典列表或单个字典。其他类型将转换为字符串表示。

        Args:
            obj: 待序列化对象。
            delimiter: 分隔符。

        Returns:
            CSV 字符串。
        """
        if isinstance(obj, list) and obj and isinstance(obj[0], dict):
            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=list(obj[0].keys()), delimiter=delimiter)
            writer.writeheader()
            writer.writerows(obj)
            return output.getvalue()
        elif isinstance(obj, dict):
            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=list(obj.keys()), delimiter=delimiter)
            writer.writeheader()
            writer.writerow(obj)
            return output.getvalue()
        else:
            return str(obj)

    def _serialize_xml(self, obj: Any) -> str:
        """
        序列化对象为 XML 字符串。

        Args:
            obj: 待序列化对象（通常为 dict）。

        Returns:
            XML 字符串。
        """
        def serialize_xml_rec(obj: Any, root_tag: str = "root") -> str:
            root = ET.Element(root_tag)

            def _add(child: ET.Element, key: Optional[str], value: Any) -> None:
                if isinstance(value, dict):
                    new_elem = ET.SubElement(child, key or "item")
                    _add(new_elem, None, value)
                elif isinstance(value, list):
                    new_elem = ET.SubElement(child, key or "item")
                    for item in value:
                        if isinstance(item, dict):
                            _add(new_elem, None, item)
                        else:
                            ET.SubElement(new_elem, "item").text = str(item)
                else:
                    ET.SubElement(child, key or "item").text = str(value)

            if isinstance(obj, dict):
                _add(root, None, obj)
            return ET.tostring(root, encoding="unicode")

        return serialize_xml_rec(obj)

    def _serialize_dict(self, obj: Any) -> str:
        """
        序列化对象为字典字符串表示。

        Args:
            obj: 待序列化对象。

        Returns:
            字典的字符串表示。
        """
        return str(obj)

    def _serialize_yaml(self, obj: Any) -> str:
        """
        序列化对象为 YAML 字符串。

        Args:
            obj: 待序列化对象。

        Returns:
            YAML 字符串。
        """
        try:
            import yaml
            return yaml.dump(obj, allow_unicode=True)
        except ImportError:
            raise ToolError("YAML模块未安装", code=1004)

    def _serialize_toml(self, obj: Any) -> str:
        """
        序列化对象为 TOML 字符串。

        Args:
            obj: 待序列化对象。

        Returns:
            TOML 字符串。
        """
        try:
            import tomli_w
            return tomli_w.dumps(obj)
        except ImportError:
            raise ToolError("TOML模块未安装", code=1004)

    def _get_parse_handler(self, fmt: str) -> Optional[callable]:
        """
        获取指定格式的解析处理器。

        Args:
            fmt: 格式标识。

        Returns:
            对应的解析函数或 None。
        """
        handlers = {
            "json": self._parse_json,
            "csv": self._parse_csv,
            "xml": self._parse_xml,
            "dict": self._parse_dict,
            "yaml": self._parse_yaml,
            "toml": self._parse_toml,
        }
        return handlers.get(fmt)

    def _get_serialize_handler(self, fmt: str) -> Optional[callable]:
        """
        获取指定格式的序列化处理器。

        Args:
            fmt: 格式标识。

        Returns:
            对应的序列化函数或 None。
        """
        handlers = {
            "json": self._serialize_json,
            "csv": self._serialize_csv,
            "xml": self._serialize_xml,
            "dict": self._serialize_dict,
            "yaml": self._serialize_yaml,
            "toml": self._serialize_toml,
        }
        return handlers.get(fmt)

    def _parse(self, data: str, fmt: str, delimiter: str) -> Any:
        """
        将字符串数据从指定格式解析为 Python 对象。

        Args:
            data: 输入字符串。
            fmt: 源格式。
            delimiter: CSV 分隔符（若适用）。

        Returns:
            解析后的 Python 对象。

        Raises:
            ToolError: 当格式不支持时抛出。
        """
        handler = self._get_parse_handler(fmt)
        if handler:
            if fmt == "csv":
                return handler(data, delimiter)
            return handler(data)
        raise ToolError(f"不支持的源格式: {fmt}", code=1002)

    def _serialize(self, obj: Any, fmt: str, delimiter: str) -> str:
        """
        将 Python 对象序列化为指定格式的字符串。

        Args:
            obj: 输入对象。
            fmt: 目标格式。
            delimiter: CSV 分隔符（若适用）。

        Returns:
            序列化后的字符串。

        Raises:
            ToolError: 当格式不支持时抛出。
        """
        handler = self._get_serialize_handler(fmt)
        if handler:
            if fmt == "csv":
                return handler(obj, delimiter)
            return handler(obj)
        raise ToolError(f"不支持的目标格式: {fmt}", code=1002)

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """
        执行数据格式转换的主入口。

        Args:
            **kwargs: 包含 data, from_format, to_format, delimiter 等键值的字典。

        Returns:
            包含转换结果及元信息的字典。

        Raises:
            ToolError: 当输入为空或格式无效时抛出。
        """
        data: str = str(kwargs.get("data", ""))
        from_format: str = str(kwargs.get("from_format", ""))
        to_format: str = str(kwargs.get("to_format", ""))
        delimiter: str = str(kwargs.get("delimiter", ","))

        if not data:
            raise ToolError("输入数据不能为空", code=1001)
        if not from_format:
            raise ToolError("源格式不能为空", code=1001)
        if not to_format:
            raise ToolError("目标格式不能为空", code=1001)

        obj: Any = self._parse(data, from_format, delimiter)
        result: str = self._serialize(obj, to_format, delimiter)

        return {"from": from_format, "to": to_format, "result": result, "original_size": len(data)}
