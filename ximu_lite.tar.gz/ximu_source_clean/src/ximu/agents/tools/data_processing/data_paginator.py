"""数据分页工具模块，支持页码、游标及偏移分页操作。"""

import logging
from typing import Any, Dict, List, Optional, Callable

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataPaginatorTool(BaseTool):
    """数据分页工具类，支持多种分页策略及分页信息获取。"""

    name: str = "data_paginator"
    description: str = "数据分页工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化DataPaginatorTool实例及参数。"""
        super().__init__()
        self._handlers: Dict[str, Callable[[List[Any], Dict[str, Any]], Dict[str, Any]]] = {
            "page": self._page_paging,
            "cursor": self._cursor_paging,
            "offset": self._offset_paging,
            "info": self._get_info,
        }
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """注册分页工具参数及约束。"""
        self.add_parameter("data", list, required=True, description="输入数据")
        self.add_parameter(
            "action", str, required=False, default="page", choices=list(self._handlers.keys()), description="操作"
        )
        self.add_parameter("page", int, required=False, default=1, description="页码")
        self.add_parameter("page_size", int, required=False, default=10, description="每页大小")
        self.add_parameter("cursor", str, required=False, default="", description="游标")
        self.add_parameter("offset", int, required=False, default=0, description="偏移量")
        self.add_parameter("limit", int, required=False, default=10, description="限制数")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行指定的分页操作。

        Args:
            **kwargs: 包含data、action及其他分页参数的映射。

        Returns:
            分页结果字典。

        Raises:
            ToolError: 操作无效时抛出。
        """
        data: List[Any] = kwargs.get("data", [])
        action: str = str(kwargs.get("action", "page"))
        handler: Optional[Callable[..., Dict[str, Any]]] = self._handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler(data, kwargs)

    def _page_paging(self, data: List[Any], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """执行页码分页策略。

        Args:
            data: 待分页列表。
            kwargs: 包含page及page_size参数。

        Returns:
            分页结果元数据字典。

        Raises:
            ToolError: page_size或page无效时抛出。
        """
        page: int = int(kwargs.get("page", 1))
        page_size: int = int(kwargs.get("page_size", 10))
        if page_size <= 0:
            raise ToolError("page_size 必须大于 0", code=1003)
        if page < 1:
            raise ToolError("page 必须大于等于 1", code=1004)
        total_pages: int = (len(data) + page_size - 1) // page_size if page_size > 0 else 0
        safe_page: int = max(1, min(page, total_pages)) if total_pages > 0 else 1
        start: int = (safe_page - 1) * page_size
        end: int = start + page_size
        return {
            "items": data[start:end],
            "page": safe_page,
            "page_size": page_size,
            "total": len(data),
            "total_pages": total_pages,
            "has_next": safe_page < total_pages,
            "has_prev": safe_page > 1,
        }

    def _cursor_paging(self, data: List[Any], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """执行游标分页策略。

        Args:
            data: 待分页列表。
            kwargs: 包含cursor及page_size参数。

        Returns:
            游标分页结果字典。
        """
        cursor: str = str(kwargs.get("cursor", ""))
        page_size: int = int(kwargs.get("page_size", 10))
        start_idx: int = 0
        if cursor:
            try:
                start_idx = max(0, int(cursor))
            except (ValueError, TypeError):
                start_idx = 0
        end_idx: int = start_idx + page_size
        items: List[Any] = data[start_idx:end_idx]
        next_cursor: Optional[str] = str(end_idx) if end_idx < len(data) else None
        return {"items": items, "next_cursor": next_cursor, "has_more": end_idx < len(data)}

    def _offset_paging(self, data: List[Any], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """执行偏移分页策略。

        Args:
            data: 待分页列表。
            kwargs: 包含offset及limit参数。

        Returns:
            偏移分页结果字典。

        Raises:
            ToolError: offset或limit无效时抛出。
        """
        offset: int = int(kwargs.get("offset", 0))
        limit: int = int(kwargs.get("limit", 10))
        if offset < 0:
            raise ToolError("offset 必须大于等于 0", code=1005)
        if limit <= 0:
            raise ToolError("limit 必须大于 0", code=1006)
        end_idx: int = offset + limit
        return {
            "items": data[offset:end_idx],
            "offset": offset,
            "limit": limit,
            "total": len(data),
            "has_more": end_idx < len(data),
        }

    def _get_info(self, data: List[Any], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """获取当前数据集的分页信息。

        Args:
            data: 数据列表。
            kwargs: 包含page_size参数。

        Returns:
            分页信息字典。
        """
        page_size: int = int(kwargs.get("page_size", 10))
        total_pages: int = (len(data) + page_size - 1) // page_size if page_size > 0 else 0
        return {"total": len(data), "page_size": page_size, "total_pages": total_pages}

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符及统计信息。

        Returns:
            工具描述映射。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }
