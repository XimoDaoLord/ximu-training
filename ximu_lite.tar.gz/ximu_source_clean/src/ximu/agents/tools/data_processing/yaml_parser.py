"""YAML解析器，支持解析、转换、验证与键路径提取。"""

import json
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class YamlParserTool(BaseTool):
    """YAML解析器工具，支持解析、JSON互转、验证和键路径提取。"""

    name: str = "yaml_parser"
    description: str = "YAML解析器，支持解析、转换、验证"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    _VALID_ACTIONS: tuple = ("parse", "to_json", "to_yaml", "validate", "keys")

    def __init__(self) -> None:
        """初始化工具实例，建立历史记录与统计容器。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, float] = {"calls": 0.0, "ok": 0.0, "fail": 0.0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """设置工具参数定义。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=list(self._VALID_ACTIONS),
            description="YAML操作类型",
        )
        self.add_parameter("data", str, required=True, description="YAML 内容")
        self.add_parameter("json_data", str, required=False, default="", description="JSON 内容（to_yaml 时使用）")

    @staticmethod
    def _import_yaml() -> Any:
        """懒加载 yaml 模块，未安装时抛出 ToolError。"""
        try:
            import yaml
            return yaml
        except ImportError as e:
            raise ToolError("PyYAML 未安装", code=1010) from e

    @staticmethod
    def _all_keys(obj: Any, prefix: str = "") -> List[str]:
        """递归提取嵌套字典中的所有点分键路径。"""
        keys: List[str] = []
        if isinstance(obj, dict):
            for key, value in obj.items():
                full_key = f"{prefix}.{key}" if prefix else str(key)
                keys.append(full_key)
                keys.extend(YamlParserTool._all_keys(value, full_key))
        return keys

    def _parse(self, data: str, yaml_mod: Any) -> Dict[str, Any]:
        """解析 YAML 字符串并返回结构。"""
        try:
            obj = yaml_mod.safe_load(data)
            return {"parsed": obj, "type": type(obj).__name__}
        except yaml_mod.YAMLError as e:
            raise ToolError(f"YAML解析失败: {e}", code=1008) from e

    def _to_json(self, data: str, yaml_mod: Any) -> Dict[str, str]:
        """将 YAML 字符串转换为 JSON 字符串。"""
        try:
            obj = yaml_mod.safe_load(data)
            return {"json": json.dumps(obj, ensure_ascii=False, indent=2)}
        except yaml_mod.YAMLError as e:
            raise ToolError(f"YAML解析失败: {e}", code=1008) from e

    def _to_yaml(self, json_data: str) -> Dict[str, str]:
        """将 JSON 字符串转换为 YAML 字符串。"""
        yaml_mod = self._import_yaml()
        if not json_data:
            raise ToolError("需要 json_data", code=1002)
        try:
            obj = json.loads(json_data)
            return {"yaml": yaml_mod.dump(obj, allow_unicode=True, default_flow_style=False)}
        except json.JSONDecodeError as e:
            raise ToolError(f"JSON解析失败: {e}", code=1009) from e

    def _validate(self, data: str, yaml_mod: Any) -> Dict[str, Any]:
        """校验 YAML 字符串格式是否合法。"""
        try:
            yaml_mod.safe_load(data)
            return {"valid": True}
        except yaml_mod.YAMLError as e:
            return {"valid": False, "error": str(e)}

    def _keys(self, data: str, yaml_mod: Any) -> Dict[str, Any]:
        """提取 YAML 中的顶层键与所有嵌套键路径。"""
        try:
            obj = yaml_mod.safe_load(data)
        except yaml_mod.YAMLError as e:
            raise ToolError(f"YAML解析失败: {e}", code=1008) from e
        
        if isinstance(obj, dict):
            return {
                "keys": list(obj.keys()),
                "nested_keys": self._all_keys(obj),
            }
        return {"keys": [], "type": type(obj).__name__}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """根据 action 分发到对应 YAML 处理逻辑。

        Args:
            **kwargs: 包含 action、data、json_data 等参数。

        Returns:
            操作结果字典。

        Raises:
            ToolError: 当 action 无效或解析失败时抛出。
        """
        action: str = kwargs.get("action", "")
        data: str = kwargs.get("data", "")
        json_data: str = kwargs.get("json_data", "")
        
        yaml_mod = self._import_yaml()

        # 使用策略模式替代 lambda 字典
        handlers: Dict[str, Any] = {
            "parse": lambda: self._parse(data, yaml_mod),
            "to_json": lambda: self._to_json(data, yaml_mod),
            "to_yaml": lambda: self._to_yaml(json_data),
            "validate": lambda: self._validate(data, yaml_mod),
            "keys": lambda: self._keys(data, yaml_mod),
        }
        
        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        
        return handler()

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具的主入口，包含统一的状态追踪与错误处理。"""
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(validated), 1002, start)
            
            result: Dict[str, Any] = self.execute(**validated)
            elapsed = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(True, elapsed)
            return self._success_result(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _success_result(self, result: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """构建成功响应字典。"""
        return {
            "success": True,
            "data": result,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _err(
        self,
        msg: str,
        code: int,
        start: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """构建错误响应字典。"""
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, ok: bool, elapsed: float) -> None:
        """追加执行历史，保持最多 100 条记录。"""
        self._history.append(
            {"ts": datetime.now(timezone.utc).isoformat(), "ok": ok, "t": elapsed}
        )
        if len(self._history) > 100:
            self._history.pop(0)

    def get_stats(self) -> Dict[str, Any]:
        """获取工具运行统计信息。"""
        ok = self._stats["ok"]
        calls = self._stats["calls"]
        avg_time = self._stats["time"] / ok if ok > 0 else 0.0
        success_rate = ok / max(1, calls)
        return {
            **self._stats,
            "avg": round(avg_time, 4),
            "rate": round(success_rate, 4),
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史执行记录。"""
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。"""
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }

    def __repr__(self) -> str:
        """返回工具的可读表示。"""
        return f"<{self.__class__.__name__} {self.name} v{self.version}>"
