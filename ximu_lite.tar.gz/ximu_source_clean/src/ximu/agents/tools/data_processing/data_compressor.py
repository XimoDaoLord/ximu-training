from __future__ import annotations

import bz2
import gzip
import io
import logging
import lzma
import time
import zlib
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Union
from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataCompressorTool(BaseTool):
    """数据压缩工具，支持zlib、gzip、bz2、lzma压缩。"""

    name: str = "data_compressor"
    description: str = "数据压缩工具，支持zlib、gzip、bz2、lzma压缩"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    _SUPPORTED_ALGORITHMS: Tuple[str, ...] = ("zlib", "gzip", "bz2", "lzma")
    _VALID_ACTIONS: Tuple[str, ...] = ("compress", "decompress", "info")
    _MIN_LEVEL: int = 1
    _MAX_LEVEL: int = 9

    def __init__(self) -> None:
        """初始化DataCompressorTool实例。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数定义。"""
        self.add_parameter("data", str, required=True, description="数据")
        self.add_parameter("algorithm", str, required=False, default="zlib", choices=list(self._SUPPORTED_ALGORITHMS), description="算法")
        self.add_parameter("level", int, required=False, default=6, min_value=self._MIN_LEVEL, max_value=self._MAX_LEVEL, description="压缩级别")
        self.add_parameter("action", str, required=False, default="compress", choices=list(self._VALID_ACTIONS), description="操作类型")

    def _validate_parameters(self, algorithm: str, level: int, action: str) -> None:
        """验证参数有效性。
        
        Args:
            algorithm: 压缩算法。
            level: 压缩级别。
            action: 操作类型。
            
        Raises:
            ToolError: 当参数无效时抛出。
        """
        if algorithm not in self._SUPPORTED_ALGORITHMS:
            raise ToolError(f"不支持的算法: {algorithm}", code=1002)
        if not isinstance(level, int) or level < self._MIN_LEVEL or level > self._MAX_LEVEL:
            raise ToolError(f"压缩级别无效: {level}，必须在{self._MIN_LEVEL}-{self._MAX_LEVEL}之间", code=1002)
        if action not in self._VALID_ACTIONS:
            raise ToolError(f"未知操作: {action}", code=1002)

    def _convert_to_bytes(self, data: Any) -> bytes:
        """将数据转换为字节串。
        
        Args:
            data: 输入数据（str或bytes）。
            
        Returns:
            字节串。
            
        Raises:
            ToolError: 当数据类型无效时抛出。
        """
        if isinstance(data, str):
            return data.encode("utf-8")
        elif isinstance(data, bytes):
            return data
        else:
            raise ToolError(f"无效的数据类型: {type(data)}，支持 str 或 bytes", code=1002)

    def _compress_with_algorithm(self, data: bytes, algorithm: str, level: int) -> bytes:
        """使用指定算法压缩数据。
        
        Args:
            data: 待压缩数据。
            algorithm: 压缩算法。
            level: 压缩级别。
            
        Returns:
            压缩后的字节串。
        """
        if algorithm == "zlib":
            return zlib.compress(data, level)
        elif algorithm == "gzip":
            buf: io.BytesIO = io.BytesIO()
            with gzip.GzipFile(fileobj=buf, mode="wb", compresslevel=level) as gz_file:
                gz_file.write(data)
            return buf.getvalue()
        elif algorithm == "bz2":
            return bz2.compress(data, level)
        elif algorithm == "lzma":
            return lzma.compress(data)
        else:
            raise ToolError(f"不支持的算法: {algorithm}", code=1002)

    def _decompress_with_algorithm(self, data: bytes, algorithm: str) -> bytes:
        """使用指定算法解压数据。
        
        Args:
            data: 待解压数据。
            algorithm: 解压算法。
            
        Returns:
            解压后的字节串。
            
        Raises:
            ToolError: 当解压失败时抛出。
        """
        try:
            if algorithm == "zlib":
                return zlib.decompress(data)
            elif algorithm == "gzip":
                return gzip.decompress(data)
            elif algorithm == "bz2":
                return bz2.decompress(data)
            elif algorithm == "lzma":
                return lzma.decompress(data)
            else:
                raise ToolError(f"不支持的算法: {algorithm}", code=1002)
        except ToolError:
            raise
        except Exception as e:
            raise ToolError(f"解压失败: {str(e)}", code=1005) from e

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行压缩、解压或信息查询操作。
        
        Args:
            **kwargs: 包含data, algorithm, level, action等参数。
            
        Returns:
            包含操作结果的字典。
            
        Raises:
            ToolError: 当参数无效或操作失败时抛出。
        """
        data: Any = kwargs.get("data", "")
        algorithm: str = kwargs.get("algorithm", "zlib")
        level: int = kwargs.get("level", 6)
        action: str = kwargs.get("action", "compress")

        self._validate_parameters(algorithm, level, action)

        if action == "compress":
            return self._do_compress(data, algorithm, level)
        elif action == "decompress":
            return self._do_decompress(data, algorithm)
        else:  # info
            return self._get_info(data, algorithm, level)

    def _do_compress(self, data: Any, algorithm: str, level: int) -> Dict[str, Any]:
        """执行压缩操作。
        
        Args:
            data: 待压缩数据。
            algorithm: 压缩算法。
            level: 压缩级别。
            
        Returns:
            包含压缩结果的字典。
        """
        raw: bytes = self._convert_to_bytes(data)
        compressed: bytes = self._compress_with_algorithm(raw, algorithm, level)
        ratio: float = round(len(compressed) / len(raw) * 100, 2) if raw else 0.0
        
        return {
            "algorithm": algorithm,
            "original_size": len(raw),
            "compressed_size": len(compressed),
            "ratio": ratio,
            "data": compressed.hex()
        }

    def _do_decompress(self, data: Any, algorithm: str) -> Dict[str, Any]:
        """执行解压操作。
        
        Args:
            data: 待解压数据（hex字符串或bytes）。
            algorithm: 解压算法。
            
        Returns:
            包含解压结果的字典。
        """
        if isinstance(data, str):
            try:
                compressed_bytes: bytes = bytes.fromhex(data)
            except ValueError as e:
                raise ToolError(f"无效的十六进制数据: {e}", code=1008) from e
        elif isinstance(data, bytes):
            compressed_bytes = data
        else:
            raise ToolError(f"无效的数据类型: {type(data)}，支持 str (hex) 或 bytes", code=1002)
            
        decompressed: bytes = self._decompress_with_algorithm(compressed_bytes, algorithm)
        return {
            "algorithm": algorithm,
            "decompressed_size": len(decompressed),
            "data": decompressed.decode("utf-8", errors="replace")
        }

    def _get_info(self, data: Any, algorithm: str, level: int) -> Dict[str, Any]:
        """获取压缩信息。
        
        Args:
            data: 数据。
            algorithm: 算法。
            level: 级别。
            
        Returns:
            包含信息结果的字典。
        """
        data_size: int = 0
        if data:
            try:
                raw = self._convert_to_bytes(data)
                data_size = len(raw)
            except ToolError:
                data_size = 0
                
        return {
            "algorithm": algorithm,
            "level": level,
            "data_size": data_size
        }