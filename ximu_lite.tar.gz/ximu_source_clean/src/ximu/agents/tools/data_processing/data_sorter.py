"""数据排序工具模块

提供数据排序算法的实现。
"""
from typing import List


def quick_sort(arr: List[int]) -> List[int]:
    """快速排序算法

    使用快速排序算法对整数列表进行排序。

    Args:
        arr: 待排序的整数列表

    Returns:
        排序后的整数列表
    """
    if len(arr) <= 1:
        return arr
    pivot: int = arr[len(arr) // 2]
    left: List[int] = [x for x in arr if x < pivot]
    middle: List[int] = [x for x in arr if x == pivot]
    right: List[int] = [x for x in arr if x > pivot]
    return quick_sort(left) + middle + quick_sort(right)