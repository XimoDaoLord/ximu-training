from __future__ import annotations

import hashlib
import logging
import random
from typing import Any, Dict, List, Tuple, Union
from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool.data_anonymizer")


class DataAnonymizerTool(BaseTool):
    """数据匿名化工具，提供多种数据脱敏、泛化、扰动、加密和假名化功能。"""

    name: str = "data_anonymizer"
    description: str = "数据匿名化工具，支持脱敏、泛化、扰动、加密匿名"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    _VALID_ACTIONS: Tuple[str, ...] = ("mask", "generalize", "perturb", "encrypt", "pseudonymize")
    _HASH_TRUNCATE_LENGTH: int = 16
    _MD5_TRUNCATE_LENGTH: int = 8

    def __init__(self) -> None:
        """初始化工具。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """定义参数。"""
        self.add_parameter("data", List, required=True, description="待匿名化的数据列表")
        self.add_parameter(
            "action", str, required=False, default="mask",
            choices=list(self._VALID_ACTIONS), description="匿名化操作类型"
        )
        self.add_parameter("fields", List, required=False, default=[], description="需要匿名化的字段名称列表")
        self.add_parameter("mask_char", str, required=False, default="*", description="用于掩码的替代字符")
        self.add_parameter("epsilon", float, required=False, default=1.0, description="差分隐私扰动操作的epsilon参数")

    def _validate_input(self, data: List[Any], action: str) -> None:
        """验证输入数据的有效性。

        Args:
            data: 待处理的数据。
            action: 操作类型。

        Raises:
            ToolError: 当输入无效时抛出。
        """
        if not isinstance(data, list):
            raise ToolError("数据必须为列表类型", code=1003)
        if action not in self._VALID_ACTIONS:
            raise ToolError(f"未知操作: {action}", code=1002)

    def _transform_item(self, item: Any, fields: List[str], transform_func: Any) -> Any:
        """对单个数据项应用转换函数。

        Args:
            item: 单个数据项。
            fields: 需要转换的字段列表。
            transform_func: 转换函数，接收值并返回转换后的值。

        Returns:
            转换后的数据项。
        """
        if isinstance(item, dict):
            new_item = dict(item)
            for field in fields:
                if field in new_item:
                    new_item[field] = transform_func(new_item[field])
            return new_item
        return item

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行匿名化操作。

        Args:
            **kwargs: 包含data, action, fields, mask_char, epsilon等参数。

        Returns:
            包含匿名化结果的字典。

        Raises:
            ToolError: 当参数无效时抛出。
        """
        data: List[Any] = kwargs.get("data", [])
        action: str = kwargs.get("action", "mask")
        fields: List[str] = kwargs.get("fields", [])
        mask_char: str = kwargs.get("mask_char", "*")
        epsilon: float = kwargs.get("epsilon", 1.0)

        self._validate_input(data, action)

        if action == "mask":
            return self._apply_mask(data, fields, mask_char)
        if action == "generalize":
            return self._apply_generalize(data, fields)
        if action == "perturb":
            return self._apply_perturb(data, fields, epsilon)
        if action == "encrypt":
            return self._apply_encrypt(data, fields)
        if action == "pseudonymize":
            return self._apply_pseudonymize(data, fields)
        raise ToolError(f"未知操作: {action}", code=1002)

    def _apply_mask(self, data: List[Any], fields: List[str], mask_char: str) -> Dict[str, Any]:
        """应用掩码匿名化。

        Args:
            data: 原始数据列表。
            fields: 需要掩码的字段。
            mask_char: 掩码字符。

        Returns:
            包含匿名化结果的字典。
        """

        def mask_value(val: Any) -> Any:
            if not isinstance(val, str):
                return val
            if len(val) > 2:
                return val[0] + mask_char * (len(val) - 2) + val[-1]
            return mask_char * len(val)

        result = [self._transform_item(item, fields, mask_value) for item in data]
        return {"anonymized": result, "method": "mask", "fields": fields}

    def _apply_generalize(self, data: List[Any], fields: List[str]) -> Dict[str, Any]:
        """应用泛化匿名化。

        Args:
            data: 原始数据列表。
            fields: 需要泛化的字段。

        Returns:
            包含匿名化结果的字典。
        """

        def generalize_value(val: Any) -> Any:
            if isinstance(val, (int, float)):
                return int(val // 10) * 10
            return val

        result = [self._transform_item(item, fields, generalize_value) for item in data]
        return {"anonymized": result, "method": "generalize"}

    def _apply_perturb(self, data: List[Any], fields: List[str], epsilon: float) -> Dict[str, Any]:
        """应用差分隐私扰动。

        Args:
            data: 原始数据列表。
            fields: 需要扰动的字段。
            epsilon: 差分隐私参数。

        Returns:
            包含匿名化结果的字典。

        Raises:
            ToolError: 当epsilon无效时抛出。
        """
        if epsilon <= 0:
            raise ToolError("epsilon参数必须大于0", code=1003)

        def perturb_value(val: Any) -> Any:
            if isinstance(val, (int, float)):
                scale: float = 1.0 / epsilon
                noise: float = random.gauss(0, scale)
                return round(val + noise, 2)
            return val

        result = [self._transform_item(item, fields, perturb_value) for item in data]
        return {"anonymized": result, "method": "perturb", "epsilon": epsilon}

    def _apply_encrypt(self, data: List[Any], fields: List[str]) -> Dict[str, Any]:
        """应用哈希加密匿名化。

        Args:
            data: 原始数据列表。
            fields: 需要加密的字段。

        Returns:
            包含匿名化结果的字典。
        """

        def encrypt_value(val: Any) -> Any:
            val_str: str = str(val)
            hash_obj = hashlib.sha256(val_str.encode("utf-8"), usedforsecurity=False)
            return hash_obj.hexdigest()[: self._HASH_TRUNCATE_LENGTH]

        result = [self._transform_item(item, fields, encrypt_value) for item in data]
        return {"anonymized": result, "method": "encrypt"}

    def _apply_pseudonymize(self, data: List[Any], fields: List[str]) -> Dict[str, Any]:
        """应用假名化匿名化。

        Args:
            data: 原始数据列表。
            fields: 需要假名化的字段。

        Returns:
            包含匿名化结果的字典。
        """
        mapping: Dict[str, str] = {}

        def pseudonymize_value(val: Any) -> Any:
            val_str: str = str(val)
            if val_str not in mapping:
                hash_obj = hashlib.md5(val_str.encode(), usedforsecurity=False)
                mapping[val_str] = "PSEUDO_" + hash_obj.hexdigest()[: self._MD5_TRUNCATE_LENGTH].upper()
            return mapping[val_str]

        result = [self._transform_item(item, fields, pseudonymize_value) for item in data]
        return {"anonymized": result, "method": "pseudonymize", "mapping_size": len(mapping)}
