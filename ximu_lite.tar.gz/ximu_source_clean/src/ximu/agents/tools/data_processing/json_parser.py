"""JSON解析器，支持解析、格式化、验证、路径查询、扁平化和深度合并操作。"""

import json
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class JsonParserTool(BaseTool):
    """JSON解析工具，提供解析、格式化、验证、查询、扁平化和合并功能。"""

    name: str = "json_parser"
    description: str = "JSON解析器，支持解析、格式化、验证、路径查询"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化 JsonParserTool 实例。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """配置工具参数。"""
        self.add_parameter(
            "action", str, required=True,
            choices=["parse", "format", "validate", "query", "flatten", "merge"],
            description="操作类型"
        )
        self.add_parameter("data", str, required=True, description="JSON字符串")
        self.add_parameter("path", str, required=False, default="", description="JSON路径")
        self.add_parameter("indent", int, required=False, default=2, description="缩进")
        self.add_parameter("merge_data", str, required=False, default="", description="合并数据")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行指定的 JSON 操作。"""
        action: str = kwargs.get("action", "")
        data: str = kwargs.get("data", "")
        indent: int = kwargs.get("indent", 2)
        obj: Any = self._parse_json_data(data)

        dispatch: Dict[str, Any] = {
            "parse": lambda: self._parse(obj),
            "format": lambda: self._format(obj, data, indent),
            "validate": lambda: self._validate(obj),
            "query": lambda: self._query(obj, kwargs.get("path", "")),
            "flatten": lambda: self._flatten(obj),
            "merge": lambda: self._merge(obj, kwargs.get("merge_data", "")),
        }

        if action not in dispatch:
            raise ToolError(f"未知操作: {action}", code=1002)
        return dispatch[action]()

    def _parse_json_data(self, data: str) -> Any:
        """将JSON字符串解析为Python对象。"""
        if not isinstance(data, str):
            return data
        try:
            return json.loads(data)
        except json.JSONDecodeError as e:
            raise ToolError(f"JSON解析失败: {e}", code=1008) from e

    def _parse(self, obj: Any) -> Dict[str, Any]:
        """解析JSON数据并返回基本信息。"""
        keys: Optional[List[str]] = list(obj.keys()) if isinstance(obj, dict) else None
        return {"parsed": obj, "type": type(obj).__name__, "keys": keys}

    def _format(self, obj: Any, original_data: str, indent: int) -> Dict[str, Any]:
        """格式化JSON数据。"""
        formatted: str = json.dumps(obj, indent=indent, ensure_ascii=False)
        original_size: int = len(original_data)
        return {"formatted": formatted, "original_size": original_size}

    def _validate(self, obj: Any) -> Dict[str, Any]:
        """验证JSON数据的有效性。"""
        return {"valid": True, "type": type(obj).__name__}

    def _query(self, obj: Any, path: str) -> Dict[str, Any]:
        """查询JSON路径。"""
        if not path:
            raise ToolError("需要path参数", code=1002)
        result: Any = self._json_path(obj, path)
        return {"path": path, "result": result, "found": result is not None}

    def _json_path(self, obj: Any, path: str) -> Any:
        """按点分路径查询嵌套对象。"""
        if not path:
            return obj
        parts: List[str] = path.split(".")
        current: Any = obj
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
        return current

    def _flatten(self, obj: Any) -> Dict[str, Any]:
        """扁平化JSON对象。"""
        flattened: Dict[str, Any] = self._flatten_obj(obj)
        return {"flattened": flattened, "count": len(flattened)}

    def _flatten_obj(self, obj: Any, prefix: str = "") -> Dict[str, Any]:
        """递归扁平化嵌套字典。"""
        result: Dict[str, Any] = {}
        if not isinstance(obj, dict):
            return result
        for key, value in obj.items():
            new_key: str = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict):
                result.update(self._flatten_obj(value, new_key))
            else:
                result[new_key] = value
        return result

    def _merge(self, obj: Any, merge_data: str) -> Dict[str, Any]:
        """深度合并两个JSON对象。"""
        if not merge_data:
            raise ToolError("需要merge_data", code=1002)
        try:
            other: Any = json.loads(merge_data)
        except json.JSONDecodeError as e:
            raise ToolError(f"merge_data JSON解析失败: {e}", code=1008) from e
        merged: Any = self._deep_merge(obj, other)
        return {"merged": merged}

    def _deep_merge(self, base: Any, override: Any) -> Any:
        """递归深度合并两个对象。"""
        if isinstance(base, dict) and isinstance(override, dict):
            merged = dict(base)
            for key, value in override.items():
                merged[key] = self._deep_merge(merged.get(key), value)
            return merged
        return override
