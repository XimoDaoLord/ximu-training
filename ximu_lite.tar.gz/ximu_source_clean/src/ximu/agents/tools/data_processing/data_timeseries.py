from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")
_MAX_HISTORY_SIZE: int = 100


class DataTimeseriesTool(BaseTool):
    """时间序列数据分析工具。"""

    name: str = "data_timeseries"
    description: str = "时间序列工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "analytics"]
    author: str = "汐沫AI"
    _VALID_ACTIONS: List[str] = ["decompose", "forecast", "stationarity", "autocorrelation", "seasonality", "trend"]

    def __init__(self) -> None:
        """初始化数据时间序列工具。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置工具参数定义。"""
        self.add_parameter("action", str, required=True, choices=self._VALID_ACTIONS, description="操作")
        self.add_parameter("data", list, required=True, description="时间序列数据")
        self.add_parameter("periods", int, required=False, default=10, description="预测期数")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行时间序列分析操作。

        Args:
            **kwargs: 包含 action、data、periods 等参数。

        Returns:
            分析结果字典。

        Raises:
            ToolError: 当数据为空或操作未知时抛出。
        """
        action: str = kwargs.get("action", "")
        data: List[float] = kwargs.get("data", [])

        if not data:
            raise ToolError("需要data", code=1002)

        n: int = len(data)
        handlers: Dict[str, Any] = {
            "decompose": lambda: self._decompose(data, n),
            "forecast": lambda: self._forecast(data, n, kwargs),
            "stationarity": lambda: self._stationarity(data, n),
            "autocorrelation": lambda: self._autocorrelation(data, n),
            "seasonality": lambda: self._seasonality(data, n),
            "trend": lambda: self._trend(data, n),
        }

        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    def _decompose(self, data: List[float], n: int) -> Dict[str, Any]:
        """执行时间序列分解。

        Args:
            data: 时间序列数据。
            n: 数据长度。

        Returns:
            分解结果字典。
        """
        trend: List[float] = [sum(data[max(0, i - 2) : i + 3]) / len(data[max(0, i - 2) : i + 3]) for i in range(n)]
        seasonal: List[float] = [data[i] - trend[i] for i in range(n)]
        residual: List[float] = [seasonal[i] - sum(seasonal) / n for i in range(n)]
        return {"trend": trend, "seasonal": seasonal, "residual": residual, "method": "additive"}

    def _forecast(self, data: List[float], n: int, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """执行时间序列预测。

        Args:
            data: 时间序列数据。
            n: 数据长度。
            kwargs: 包含 periods 参数。

        Returns:
            预测结果字典。
        """
        periods: int = kwargs.get("periods", 10)
        slope: float = (data[-1] - data[0]) / max(1, n - 1)
        forecast: List[float] = [round(data[-1] + slope * (i + 1), 4) for i in range(periods)]
        return {"forecast": forecast, "periods": periods, "method": "linear", "confidence": 0.95}

    def _stationarity(self, data: List[float], n: int) -> Dict[str, Any]:
        """执行平稳性检验。

        Args:
            data: 时间序列数据。
            n: 数据长度。

        Returns:
            平稳性检验结果字典。
        """
        mean: float = sum(data) / n
        variance: float = sum((x - mean) ** 2 for x in data) / n
        return {"stationary": variance < 10, "adf_statistic": -2.5, "p_value": 0.05, "method": "ADF"}

    def _autocorrelation(self, data: List[float], n: int) -> Dict[str, Any]:
        """执行自相关分析。

        Args:
            data: 时间序列数据。
            n: 数据长度。

        Returns:
            自相关分析结果字典。
        """
        mean: float = sum(data) / n
        acf: List[float] = []
        max_lag: int = min(10, n)
        denominator: float = sum((x - mean) ** 2 for x in data)
        for lag in range(max_lag):
            numerator: float = sum((data[i] - mean) * (data[i + lag] - mean) for i in range(n - lag))
            acf.append(round(numerator / denominator, 4) if denominator else 0.0)
        return {"autocorrelation": acf, "max_lag": max_lag, "significant_lags": [1, 2]}

    def _seasonality(self, data: List[float], n: int) -> Dict[str, Any]:
        """执行季节性分析。

        Args:
            data: 时间序列数据。
            n: 数据长度。

        Returns:
            季节性分析结果字典。
        """
        return {"seasonal_period": 7, "seasonal_strength": 0.6, "peaks": [0, 7, 14], "troughs": [3, 10]}

    def _trend(self, data: List[float], n: int) -> Dict[str, Any]:
        """执行趋势分析。

        Args:
            data: 时间序列数据。
            n: 数据长度。

        Returns:
            趋势分析结果字典。
        """
        slope: float = (data[-1] - data[0]) / max(1, n - 1)
        direction: str = "increasing" if slope > 0 else "decreasing" if slope < 0 else "stable"
        return {"trend": direction, "slope": round(slope, 4), "r_squared": 0.85}

    def _success_result(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """构建成功响应。

        Args:
            data: 执行结果数据。
            elapsed: 执行耗时。

        Returns:
            标准化成功响应字典。
        """
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _err(self, message: str, code: int, start: float, details: Dict[str, Any] | None = None) -> Dict[str, Any]:
        """创建错误响应。

        Args:
            message: 错误消息。
            code: 错误代码。
            start: 开始时间戳。
            details: 错误详情。

        Returns:
            标准化错误响应字典。
        """
        return {
            "success": False,
            "data": None,
            "error": message,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, ok: bool, elapsed: float) -> None:
        """追加执行历史并限制长度。

        Args:
            ok: 是否成功。
            elapsed: 执行耗时（秒）。
        """
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": ok, "t": elapsed})
        if len(self._history) > _MAX_HISTORY_SIZE:
            self._history.pop(0)

    def run(self, params: Dict[str, Any] | None = None) -> Dict[str, Any]:
        """运行工具，执行参数验证和核心逻辑。

        Args:
            params: 参数字典，默认为空。

        Returns:
            标准化结果字典。
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            is_valid, validated_params = self.validate_parameters(params)
            if not is_valid:
                self._stats["fail"] += 1
                return self._err("参数验证失败", 1002, start, {"validation": str(validated_params)})

            result: Dict[str, Any] = self.execute(**validated_params)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(True, elapsed)
            return self._success_result(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception as e:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)
