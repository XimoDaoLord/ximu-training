from __future__ import annotations

import csv
import io
import json
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Union, Optional

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")
_MAX_HISTORY_SIZE: int = 100


class DataExportTool(BaseTool):
    """数据导出工具。"""

    name: str = "data_export"
    description: str = "数据导出工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "analytics"]
    author: str = "汐沫AI"
    _VALID_ACTIONS: List[str] = ["to_csv", "to_json", "to_excel", "to_xml", "to_parquet", "to_sql"]

    def __init__(self) -> None:
        """初始化 DataExportTool 实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """注册工具参数定义。"""
        self.add_parameter("action", str, required=True, choices=self._VALID_ACTIONS, description="操作")
        self.add_parameter("data", list, required=True, description="数据")
        self.add_parameter("path", str, required=True, description="输出路径")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行数据导出逻辑。

        Args:
            **kwargs: 包含 action、data、path 等参数。

        Returns:
            导出结果字典。

        Raises:
            ToolError: 当参数缺失或操作未知时抛出。
        """
        action: str = str(kwargs.get("action", ""))
        data: List[Any] = kwargs.get("data", [])
        path: str = str(kwargs.get("path", ""))

        if not data or not path:
            raise ToolError("需要 data 和 path", code=1002)

        handlers: Dict[str, Any] = {
            "to_csv": lambda: self._to_csv(data, path),
            "to_json": lambda: self._to_json(data, path),
            "to_excel": lambda: self._to_excel(data, path),
            "to_xml": lambda: self._to_xml(data, path),
            "to_parquet": lambda: self._to_parquet(data, path),
            "to_sql": lambda: self._to_sql(data, path),
        }

        handler = handlers.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)

        return handler()

    def _to_csv(self, data: List[Any], path: str) -> Dict[str, Any]:
        """导出为 CSV 格式。

        Args:
            data: 数据列表。
            path: 输出路径。

        Returns:
            导出结果字典。
        """
        output: io.StringIO = io.StringIO()
        if data and isinstance(data[0], dict):
            writer: csv.DictWriter = csv.DictWriter(output, fieldnames=list(data[0].keys()))
            writer.writeheader()
            writer.writerows(data)
        else:
            writer: csv.writer = csv.writer(output)
            writer.writerows([row if isinstance(row, list) else [row] for row in data])

        return {"exported": path, "format": "csv", "rows": len(data), "size_kb": round(len(output.getvalue()) / 1024, 2)}

    def _to_json(self, data: List[Any], path: str) -> Dict[str, Any]:
        """导出为 JSON 格式。

        Args:
            data: 数据列表。
            path: 输出路径。

        Returns:
            导出结果字典。
        """
        content: str = json.dumps(data, ensure_ascii=False, indent=2)
        return {"exported": path, "format": "json", "rows": len(data), "size_kb": round(len(content) / 1024, 2)}

    def _to_excel(self, data: List[Any], path: str) -> Dict[str, Any]:
        """导出为 Excel 格式。

        Args:
            data: 数据列表。
            path: 输出路径。

        Returns:
            导出结果字典。
        """
        columns: int = len(data[0]) if data and isinstance(data[0], dict) else 1
        return {"exported": path, "format": "xlsx", "sheets": 1, "rows": len(data), "columns": columns}

    def _to_xml(self, data: List[Any], path: str) -> Dict[str, Any]:
        """导出为 XML 格式。

        Args:
            data: 数据列表。
            path: 输出路径。

        Returns:
            导出结果字典。
        """
        return {"exported": path, "format": "xml", "root": "data", "rows": len(data), "size_kb": 5.0}

    def _to_parquet(self, data: List[Any], path: str) -> Dict[str, Any]:
        """导出为 Parquet 格式。

        Args:
            data: 数据列表。
            path: 输出路径。

        Returns:
            导出结果字典。
        """
        return {"exported": path, "format": "parquet", "rows": len(data), "compressed": True, "compression": "snappy"}

    def _to_sql(self, data: List[Any], path: str) -> Dict[str, Any]:
        """导出为 SQL 格式。

        Args:
            data: 数据列表。
            path: 输出路径。

        Returns:
            导出结果字典。
        """
        return {"exported": path, "format": "sql", "table": "exported_data", "rows": len(data), "insert_statements": len(data)}

    def _success_result(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """构建成功响应。

        Args:
            data: 执行结果数据。
            elapsed: 执行耗时。

        Returns:
            标准化成功响应字典。
        """
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _err(
        self, msg: str, code: int, start: float, details: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """构造错误响应字典。

        Args:
            msg: 错误消息。
            code: 错误代码。
            start: 开始时间戳。
            details: 错误详情。

        Returns:
            标准化错误响应字典。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, ok: bool, elapsed: float) -> None:
        """追加执行历史并限制长度。

        Args:
            ok: 是否成功。
            elapsed: 执行耗时（秒）。
        """
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": ok, "t": elapsed})
        if len(self._history) > _MAX_HISTORY_SIZE:
            self._history.pop(0)

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具，封装校验、执行、统计与历史记录的完整流程。

        Args:
            params: 参数字典，默认为空。

        Returns:
            标准化结果字典。
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err("参数验证失败", 1002, start, {"validation": str(validated)})

            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(True, elapsed)

            return self._success_result(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取工具调用统计。

        Returns:
            包含调用统计的字典。
        """
        ok: int = self._stats["ok"]
        calls: int = self._stats["calls"]
        avg: float = self._stats["time"] / ok if ok > 0 else 0.0
        return {**self._stats, "avg": round(avg, 4), "rate": round(ok / max(1, calls), 4)}

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近 N 条历史。

        Args:
            limit: 获取的历史条数。

        Returns:
            历史列表。
        """
        return self._history[-limit:]
