"""数据透视工具模块，提供多种数据变换操作。"""

import logging
from typing import Any, Dict, List, Optional, Union, Callable, Tuple

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataPivotTool(BaseTool):
    """数据透视工具类，支持pivot、melt、crosstab、groupby、aggregate及unpivot操作。"""

    name: str = "data_pivot"
    description: str = "数据透视工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "analytics"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化DataPivotTool实例，注册参数及操作调度。"""
        super().__init__()
        self._actions: Dict[str, Callable[..., Dict[str, Any]]] = {
            "pivot": self._execute_pivot,
            "melt": self._execute_melt,
            "crosstab": self._execute_crosstab,
            "groupby": self._execute_groupby,
            "aggregate": self._execute_aggregate,
            "unpivot": self._execute_unpivot,
        }
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """配置工具参数定义及约束。"""
        self.add_parameter("action", str, required=True, choices=list(self._actions.keys()), description="操作类型")
        self.add_parameter("data", list, required=True, description="输入数据列表")
        self.add_parameter("index", str, required=False, default="", description="索引列名")
        self.add_parameter("columns", str, required=False, default="", description="透视列名")
        self.add_parameter("values", str, required=False, default="", description="值列名")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行指定的数据操作。

        Args:
            **kwargs: 包含action及相关参数的映射。

        Returns:
            操作结果字典。

        Raises:
            ToolError: 当数据为空或操作未知时抛出。
        """
        action: str = str(kwargs.get("action", ""))
        data: List[Any] = kwargs.get("data", [])
        if not data:
            raise ToolError("需要提供非空数据", code=1002)

        handler: Optional[Callable[..., Dict[str, Any]]] = self._actions.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)

        index: str = str(kwargs.get("index", ""))
        columns: str = str(kwargs.get("columns", ""))
        values: str = str(kwargs.get("values", ""))
        return handler(data, index, columns, values)

    def _execute_pivot(self, data: List[Any], index: str, columns: str, values: str) -> Dict[str, Any]:
        """执行数据透视操作。

        Args:
            data: 输入数据列表。
            index: 索引列名。
            columns: 透视列名。
            values: 值列名。

        Returns:
            透视结果元数据字典。
        """
        return {"pivoted": True, "index": index, "columns": columns, "values": values, "shape": [len(data), 12]}

    def _execute_melt(self, data: List[Any], index: str, columns: str, values: str) -> Dict[str, Any]:
        """执行数据熔解操作。

        Args:
            data: 输入数据列表。
            index: ID 变量名。
            columns: 参数（保留兼容性）。
            values: 参数（保留兼容性）。

        Returns:
            熔解结果字典。
        """
        return {"melted": True, "id_vars": [index], "value_vars": ["col1", "col2"], "rows": len(data) * 2}

    def _execute_crosstab(self, data: List[Any], index: str, columns: str, values: str) -> Dict[str, Any]:
        """执行交叉表生成操作。

        Args:
            data: 输入数据列表。
            index: 参数（保留兼容性）。
            columns: 参数（保留兼容性）。
            values: 参数（保留兼容性）。

        Returns:
            交叉表结果字典。
        """
        return {"crosstab": True, "rows": len(data), "cols": 4, "margins": True, "normalized": False}

    def _execute_groupby(self, data: List[Any], index: str, columns: str, values: str) -> Dict[str, Any]:
        """执行分组聚合操作。

        Args:
            data: 输入数据列表。
            index: 分组键列名。
            columns: 参数（保留兼容性）。
            values: 参数（保留兼容性）。

        Returns:
            分组结果字典。
        """
        groups: Dict[Any, int] = {}
        for row in data:
            if isinstance(row, dict):
                key: Any = row.get(index, "unknown")
                groups[key] = groups.get(key, 0) + 1
        return {"groups": groups, "group_count": len(groups)}

    def _execute_aggregate(self, data: List[Any], index: str, columns: str, values: str) -> Dict[str, Any]:
        """执行聚合操作。

        Args:
            data: 输入数据列表。
            index: 分组列名。
            columns: 参数（保留兼容性）。
            values: 参数（保留兼容性）。

        Returns:
            聚合结果字典。
        """
        return {
            "aggregated": True,
            "functions": ["sum", "mean", "count"],
            "group_by": index,
            "result_count": len(data),
        }

    def _execute_unpivot(self, data: List[Any], index: str, columns: str, values: str) -> Dict[str, Any]:
        """执行逆透视操作。

        Args:
            data: 输入数据列表。
            index: 参数（保留兼容性）。
            columns: 参数（保留兼容性）。
            values: 参数（保留兼容性）。

        Returns:
            逆透视结果字典。
        """
        return {
            "unpivoted": True,
            "original_columns": 5,
            "melted_rows": len(data) * 4,
            "variable_col": "variable",
            "value_col": "value",
        }

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符及统计映射。

        Returns:
            工具描述字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }
