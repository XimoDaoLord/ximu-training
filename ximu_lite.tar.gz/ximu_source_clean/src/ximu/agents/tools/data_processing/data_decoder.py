"""数据解码工具，支持多种编码格式的智能解码。"""

import base64
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union
from urllib.parse import unquote

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataDecoderTool(BaseTool):
    """数据解码工具，支持 Base64、URL、Hex、Unicode、二进制、摩尔斯码的自动与手动解码。"""

    name: str = "data_decoder"
    description: str = "数据解码工具，支持多种编码格式的智能解码"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化工具实例。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """配置工具输入参数。"""
        self.add_parameter("data", str, required=True, description="待解码的编码数据字符串")
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=["base64", "url", "hex", "unicode", "auto", "morse", "binary"],
            description="解码方式：手动指定或 auto 自动检测",
        )

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行数据解码操作。"""
        data = kwargs.get("data", "")
        action = kwargs.get("action", "")

        dispatch: Dict[str, Any] = {
            "base64": lambda: self._decode_base64(data),
            "url": lambda: {"decoded": unquote(data), "method": "url"},
            "hex": lambda: self._decode_hex(data),
            "unicode": lambda: self._decode_unicode(data),
            "binary": lambda: self._decode_binary(data),
            "morse": lambda: self._decode_morse(data),
            "auto": lambda: self._decode_auto(data),
        }

        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        return handler()

    @staticmethod
    def _decode_base64(data: str) -> Dict[str, str]:
        """Base64 解码。"""
        try:
            decoded = base64.b64decode(data).decode("utf-8", errors="replace")
            return {"decoded": decoded, "method": "base64"}
        except Exception as e:
            raise ToolError(f"base64 解码失败: {e}", code=1008) from e

    @staticmethod
    def _decode_hex(data: str) -> Dict[str, str]:
        """Hex 字符串解码。"""
        try:
            decoded = bytes.fromhex(data).decode("utf-8", errors="replace")
            return {"decoded": decoded, "method": "hex"}
        except Exception as e:
            raise ToolError(f"hex 解码失败: {e}", code=1008) from e

    @staticmethod
    def _decode_unicode(data: str) -> Dict[str, str]:
        """Unicode 转义序列解码。"""
        try:
            decoded = data.encode().decode("unicode_escape")
            return {"decoded": decoded, "method": "unicode"}
        except Exception as e:
            raise ToolError(f"unicode 解码失败: {e}", code=1008) from e

    @staticmethod
    def _decode_binary(data: str) -> Dict[str, str]:
        """二进制位串解码。"""
        try:
            bits = data.replace(" ", "")
            if not bits or len(bits) % 8 != 0:
                raise ValueError("二进制长度不是 8 的倍数")
            chars = [chr(int(bits[i:i+8], 2)) for i in range(0, len(bits), 8)]
            decoded = "".join(chars)
            return {"decoded": decoded, "method": "binary"}
        except Exception as e:
            raise ToolError(f"binary 解码失败: {e}", code=1008) from e

    @staticmethod
    def _decode_morse(data: str) -> Dict[str, str]:
        """摩尔斯电码解码。"""
        morse_map: Dict[str, str] = {
            ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E",
            "..-.": "F", "--.": "G", "....": "H", "..": "I", ".---": "J",
            "-.-": "K", ".-..": "L", "--": "M", "-.": "N", "---": "O",
            ".--.": "P", "--.-": "Q", ".-.": "R", "...": "S", "-": "T",
            "..-": "U", "...-": "V", ".--": "W", "-..-": "X", "-.--": "Y",
            "--..": "Z", "-----": "0", ".----": "1", "..---": "2",
            "...--": "3", "....-": "4", ".....": "5", "-....": "6",
            "--...": "7", "---..": "8", "----.": "9",
        }
        words = data.split(" / ")
        decoded_words = [
            "".join(morse_map.get(c, "?") for c in word.split())
            for word in words
        ]
        return {"decoded": " ".join(decoded_words), "method": "morse"}

    def _decode_auto(self, data: str) -> Dict[str, Any]:
        """自动检测并解码编码格式。"""
        for method in ["base64", "hex", "url", "unicode"]:
            try:
                r = self.run({"data": data, "action": method})
                if r.get("success"):
                    return {
                        "decoded": r["data"]["decoded"],
                        "method": method,
                        "auto_detected": True,
                    }
            except ToolError:
                continue
        raise ToolError("无法自动识别编码格式", code=1008)

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具的主入口。"""
        params = params or {}
        start = time.monotonic()  # type: ignore[name-defined]
        self._stats["calls"] += 1

        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._build_error(str(v), 1002, start)
            result = self.execute(**v)
            elapsed = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed, True)
            return self._build_success(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._build_error(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("数据解码工具内部错误", exc_info=True)
            return self._build_error("工具内部错误", 1006, start)

    def _build_success(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """构建成功响应字典。"""
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _build_error(
        self,
        msg: Any,
        code: int,
        start: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """构建错误响应字典。"""
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, elapsed: float, success: bool) -> None:
        """追加调用历史并裁剪至最近100条。"""
        self._history.append({
            "ts": datetime.now(timezone.utc).isoformat(),
            "ok": success,
            "t": elapsed,
        })
        if len(self._history) > 100:
            self._history.pop(0)