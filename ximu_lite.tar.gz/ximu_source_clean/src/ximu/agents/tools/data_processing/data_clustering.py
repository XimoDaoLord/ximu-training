"""数据聚类工具模块。

提供 k-means、层次聚类、DBSCAN 等聚类操作及聚类评估功能。
"""
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataClusteringTool(BaseTool):
    """数据聚类工具。

    支持 kmeans/hierarchical/dbscan/evaluate/silhouette/elbow 操作，
    所有数值结果均为模拟值，用于演示管道行为。
    """

    name: str = "data_clustering"
    description: str = "数据聚类工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "analytics"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化数据聚类工具。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """注册工具参数。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=["kmeans", "hierarchical", "dbscan", "evaluate", "silhouette", "elbow"],
            description="操作类型",
        )
        self.add_parameter("data", list, required=True, description="数据点列表")
        self.add_parameter("k", int, required=False, default=3, description="簇数（kmeans/elbow/silhouette 使用）")

    @staticmethod
    def _generate_kmeans_result(data: List[Any], k: int) -> Dict[str, Any]:
        """生成模拟 k-means 聚类结果。

        Args:
            data: 数据点列表。
            k: 簇数。

        Returns:
            包含 labels/centroids/k/iterations/inertia 的字典。
        """
        n = len(data)
        labels = [i % k for i in range(n)]
        centroids = data[:k] if n >= k else data
        return {"labels": labels, "centroids": centroids, "k": k, "iterations": 10, "inertia": 150.5}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行聚类或评估操作。

        Args:
            **kwargs: 包含 action/data/k 的参数字典。

        Returns:
            操作结果字典。

        Raises:
            ToolError: action 无效或 data 为空时抛出。
        """
        action = kwargs.get("action", "")
        data = kwargs.get("data", [])
        k = int(kwargs.get("k", 3))

        if not data:
            raise ToolError("需要 data 参数且不能为空", code=1002)

        if action == "kmeans":
            return self._generate_kmeans_result(data, k)
        if action == "hierarchical":
            return {"linkage": "ward", "dendrogram": "available", "clusters": k, "method": "agglomerative"}
        if action == "dbscan":
            return {"eps": 0.5, "min_samples": 5, "clusters": 3, "noise_points": 2, "labels": [0, 0, 1, -1]}
        if action == "evaluate":
            return {"silhouette_score": 0.65, "davies_bouldin": 0.8, "calinski_harabasz": 150, "k": k}
        if action == "silhouette":
            scores = [0.6, 0.7, 0.5]
            return {"silhouette_scores": scores, "avg_score": sum(scores) / len(scores), "k": k, "best_k": 3}
        if action == "elbow":
            inertias = [500, 300, 150, 120, 110]
            return {"k_values": list(range(1, len(inertias) + 1)), "inertias": inertias, "elbow_point": 3, "recommended_k": 3}
        raise ToolError(f"未知操作: {action}", code=1002)

    def _append_history(self, elapsed: float, ok: bool) -> None:
        """追加执行历史，保持最多 100 条记录。

        Args:
            elapsed: 本次执行耗时。
            ok: 是否成功。
        """
        self._history.append({"ts": datetime.now(timezone.utc).isoformat(), "ok": ok, "t": elapsed})
        if len(self._history) > 100:
            self._history.pop(0)

    def _build_success(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """构建成功响应字典。

        Args:
            data: 执行结果。
            elapsed: 执行耗时（秒）。

        Returns:
            成功响应字典。
        """
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _build_error(
        self,
        msg: Any,
        code: int,
        start: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """构建错误响应字典。

        Args:
            msg: 错误信息。
            code: 错误码。
            start: 计时起点。
            details: 附加详情。

        Returns:
            错误响应字典。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """执行工具调用。

        Args:
            params: 参数字典，默认为空字典。

        Returns:
            包含 success、data、error、execution_time 等字段的响应字典。
        """
        params = params or {}
        start = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._build_error(v, 1002, start)
            result = self.execute(**v)
            elapsed = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed, True)
            return self._build_success(result, elapsed)
        except ToolError as e:
            self._stats["fail"] += 1
            return self._build_error(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("数据聚类工具内部错误", exc_info=True)
            return self._build_error("工具内部错误", 1006, start)

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取统计信息。

        Returns:
            包含 calls、ok、fail、time、avg、rate 的字典。
        """
        ok = self._stats["ok"]
        calls = self._stats["calls"]
        avg = self._stats["time"] / ok if ok > 0 else 0.0
        return {
            **self._stats,
            "avg": round(avg, 4),
            "rate": round(ok / max(1, calls), 4),
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史记录。

        Args:
            limit: 返回的最大记录数，默认为 10。

        Returns:
            最近 limit 条历史记录列表。
        """
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。

        Returns:
            包含工具名称、描述、版本、参数及统计信息的字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }

    def validate_input(self, params: Dict[str, Any]) -> tuple[bool, str]:
        """验证输入参数。

        Args:
            params: 待验证的参数字典。

        Returns:
            元组 (是否有效, 错误消息)。
        """
        ok, r = self.validate_parameters(params)
        return ok, "" if ok else r

    def __repr__(self) -> str:
        """返回工具的可读表示。"""
        return f"<DataClusteringTool name={self.name} v{self.version}>"

    def kmeans(self, data: List[Any], k: int = 3) -> Dict[str, Any]:
        """快捷调用 k-means 聚类。

        Args:
            data: 数据点列表。
            k: 簇数，默认为 3。

        Returns:
            包含 success、data 等字段的响应字典。
        """
        return self.run({"action": "kmeans", "data": data, "k": k})
