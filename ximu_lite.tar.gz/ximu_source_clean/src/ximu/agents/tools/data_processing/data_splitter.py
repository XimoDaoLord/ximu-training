"""数据分割工具。"""

import random
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

class DataSplitterTool(BaseTool):
    """数据分割工具类。"""
    name: str = "data_splitter"
    description: str = "数据分割工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化。"""
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """配置参数。"""
        self.add_parameter("data", list, required=True, description="待分割的数据列表")
        self.add_parameter("action", str, required=False, default="split", choices=["split", "chunk", "stratified", "kfold"], description="分割操作类型")
        self.add_parameter("ratio", float, required=False, default=0.8, description="训练集比例")
        self.add_parameter("chunk_size", int, required=False, default=10, description="分块大小")
        self.add_parameter("k", int, required=False, default=5, description="K折交叉验证的K值")
        self.add_parameter("seed", int, required=False, default=42, description="随机种子")

    def _validate_ratio(self, ratio: float) -> None:
        """校验比例参数有效性。"""
        if not 0 < ratio < 1:
            raise ToolError("比例必须介于0和1之间", code=1005)

    def _validate_data(self, data: List[Any]) -> None:
        """校验数据非空。"""
        if not data:
            raise ToolError("数据列表不能为空", code=1004)

    def _random_split(self, data: List[Any], ratio: float, seed: int) -> Dict[str, Any]:
        """执行随机分割。"""
        self._validate_ratio(ratio)
        self._validate_data(data)
        random.seed(seed)
        shuffled = data[:]
        random.shuffle(shuffled)
        split_index = int(len(shuffled) * ratio)
        train_set = shuffled[:split_index]
        test_set = shuffled[split_index:]
        return {"train": train_set, "test": test_set, "train_size": len(train_set), "test_size": len(test_set)}

    def _chunk_data(self, data: List[Any], chunk_size: int) -> Dict[str, Any]:
        """将数据分块。"""
        self._validate_data(data)
        if chunk_size <= 0:
            raise ToolError("分块大小必须为正整数", code=1006)
        chunks = [data[i:i + chunk_size] for i in range(0, len(data), chunk_size)]
        return {"chunks": chunks, "chunk_count": len(chunks)}

    def _stratified_split(self, data: List[Any], ratio: float, seed: int) -> Dict[str, Any]:
        """执行分层分割。"""
        self._validate_ratio(ratio)
        self._validate_data(data)
        random.seed(seed)
        groups: Dict[Any, List[Any]] = {}
        for item in data:
            label = item.get("label") if isinstance(item, dict) else None
            groups.setdefault(label, []).append(item)
        train_set: List[Any] = []
        test_set: List[Any] = []
        for label, group_items in groups.items():
            random.shuffle(group_items)
            split_index = int(len(group_items) * ratio)
            train_set.extend(group_items[:split_index])
            test_set.extend(group_items[split_index:])
        return {"train": train_set, "test": test_set, "stratified": True}

    def _kfold_cv(self, data: List[Any], k: int, seed: int) -> Dict[str, Any]:
        """执行K折交叉验证。"""
        self._validate_data(data)
        if k <= 0:
            raise ToolError("K值必须为正整数", code=1007)
        if k > len(data):
            raise ToolError("K值不能大于数据总量", code=1008)
        random.seed(seed)
        shuffled = data[:]
        random.shuffle(shuffled)
        fold_size = len(shuffled) // k
        folds: List[Dict[str, Any]] = []
        for i in range(k):
            start = i * fold_size
            end = start + fold_size if i < k - 1 else len(shuffled)
            fold_data = shuffled[start:end]
            train_data = shuffled[:start] + shuffled[end:]
            folds.append({"fold": i + 1, "train": train_data, "validation": fold_data, "train_size": len(train_data), "val_size": len(fold_data)})
        return {"folds": folds, "k": k, "total": len(data)}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行数据分割操作。"""
        data: List[Any] = kwargs.get("data", [])
        if not isinstance(data, list):
            raise ToolError("数据必须是列表类型", code=1003)
        action: str = kwargs.get("action", "split")
        ratio: float = float(kwargs.get("ratio", 0.8))
        chunk_size: int = int(kwargs.get("chunk_size", 10))
        k: int = int(kwargs.get("k", 5))
        seed: int = int(kwargs.get("seed", 42))
        dispatch = {
            "split": lambda: self._random_split(data, ratio, seed),
            "chunk": lambda: self._chunk_data(data, chunk_size),
            "stratified": lambda: self._stratified_split(data, ratio, seed),
            "kfold": lambda: self._kfold_cv(data, k, seed)
        }
        if action not in dispatch:
            raise ToolError(f"未知操作: {action}", code=1002)
        return dispatch[action]()