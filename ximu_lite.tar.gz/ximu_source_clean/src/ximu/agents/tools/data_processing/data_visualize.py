"""数据可视化工具，支持 plot、bar、scatter、histogram、pie、heatmap、line 等图表渲染。"""

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataVisualizeTool(BaseTool):
    """数据可视化工具，提供多种图表类型的占位渲染结果。"""

    name: str = "data_visualize"
    description: str = "数据可视化工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "analytics"]
    author: str = "汐沫AI"

    _VALID_ACTIONS: tuple = ("plot", "bar", "scatter", "histogram", "pie", "heatmap", "line")

    def __init__(self) -> None:
        """初始化工具实例，建立历史记录与统计容器。"""
        super().__init__()
        self._history: List[Dict[str, Any]] = []
        self._stats: Dict[str, Union[int, float]] = {
            "calls": 0,
            "ok": 0,
            "fail": 0,
            "time": 0.0,
        }

    def _setup_parameters(self) -> None:
        """定义工具参数配置。"""
        self.add_parameter(
            "action",
            str,
            required=True,
            choices=list(self._VALID_ACTIONS),
            description="图表类型",
        )
        self.add_parameter("data", list, required=True, description="数据列表")
        self.add_parameter("labels", list, required=False, default=[], description="标签列表")
        self.add_parameter("title", str, required=False, default="", description="图表标题")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """根据 action 分发到对应图表绘制方法。
        
        Args:
            **kwargs: 包含 action、data、labels、title 等参数。
            
        Returns:
            图表配置字典。
            
        Raises:
            ToolError: 当 data 为空或 action 无效时抛出。
        """
        action: str = str(kwargs.get("action", ""))
        data: List[Union[int, float]] = kwargs.get("data", [])
        
        if not data:
            raise ToolError("需要 data", code=1002)

        dispatch: Dict[str, Any] = {
            "plot": lambda: self._plot_line(data, kwargs),
            "line": lambda: self._plot_line(data, kwargs),
            "bar": lambda: self._plot_bar(data, kwargs),
            "scatter": lambda: self._plot_scatter(data, kwargs),
            "histogram": lambda: self._plot_histogram(data, kwargs),
            "pie": lambda: self._plot_pie(data, kwargs),
            "heatmap": lambda: self._plot_heatmap(data, kwargs),
        }
        
        handler = dispatch.get(action)
        if handler is None:
            raise ToolError(f"未知操作: {action}", code=1002)
        
        return handler()

    @staticmethod
    def _plot_line(data: List[Union[int, float]], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """折线图配置。
        
        Args:
            data: 数据点序列。
            kwargs: 包含标签和标题的参数。
            
        Returns:
            折线图配置字典。
        """
        return {
            "chart_type": "line",
            "data": data,
            "labels": kwargs.get("labels", []),
            "title": kwargs.get("title") or "Line Plot",
            "rendered": True,
        }

    @staticmethod
    def _plot_bar(data: List[Union[int, float]], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """柱状图配置。
        
        Args:
            data: 数值序列。
            kwargs: 包含标签的参数。
            
        Returns:
            柱状图配置字典。
        """
        max_val: float = max(data) if data else 0
        return {
            "chart_type": "bar",
            "data": data,
            "labels": kwargs.get("labels", []),
            "categories": len(data),
            "max": max_val,
        }

    @staticmethod
    def _plot_scatter(data: List[Union[int, float]], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """散点图配置。
        
        Args:
            data: 数据点。
            kwargs: 输入参数。
            
        Returns:
            散点图配置字典。
        """
        return {
            "chart_type": "scatter",
            "points": len(data),
            "x_range": [0, 100],
            "y_range": [0, 100],
            "correlation": 0.65, # 模拟值
        }

    @staticmethod
    def _plot_histogram(data: List[Union[int, float]], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """直方图配置。
        
        Args:
            data: 数值序列。
            kwargs: 输入参数。
            
        Returns:
            直方图配置字典。
        """
        bins: int = 10
        # 简单的固定区间分布计算 (0-99)
        distribution: List[int] = []
        for i in range(0, 100, 10):
            count = sum(1 for x in data if i <= x < i + 10)
            distribution.append(count)
            
        mean_val: float = round(sum(data) / len(data), 4) if data else 0
        
        return {
            "chart_type": "histogram",
            "bins": bins,
            "distribution": distribution,
            "mean": mean_val,
        }

    @staticmethod
    def _plot_pie(data: List[Union[int, float]], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """饼图配置。
        
        Args:
            data: 数值序列。
            kwargs: 包含标签的参数。
            
        Returns:
            饼图配置字典。
        """
        total: float = sum(data)
        percentages: List[float] = []
        if total > 0:
            percentages = [round(d / total * 100, 1) for d in data]
            
        return {
            "chart_type": "pie",
            "data": data,
            "percentages": percentages,
            "labels": kwargs.get("labels", []),
        }

    @staticmethod
    def _plot_heatmap(data: List[Union[int, float]], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """热力图配置。
        
        Args:
            data: 数据。
            kwargs: 输入参数。
            
        Returns:
            热力图配置字典。
        """
        return {
            "chart_type": "heatmap",
            "rows": 5, # 默认网格大小
            "cols": 5,
            "color_scale": "viridis",
            "data_range": [0, 1],
        }

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具的主入口，包含统一的状态追踪与错误处理。
        
        Args:
            params: 可选的参数字典。
            
        Returns:
            包含执行状态和结果的字典。
        """
        params = params or {}
        start: float = time.monotonic()
        self._stats["calls"] += 1

        try:
            ok, validated = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._err(str(validated), 1002, start)
            
            result: Dict[str, Any] = self.execute(**validated)
            elapsed: float = round(time.monotonic() - start, 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(True, elapsed)
            return self._success_result(result, elapsed)
        
        except ToolError as e:
            self._stats["fail"] += 1
            return self._err(e.message, e.code, start, e.details)
        except Exception:
            self._stats["fail"] += 1
            logger.error("工具内部错误", exc_info=True)
            return self._err("工具内部错误", 1006, start)

    def _success_result(self, result: Dict[str, Any], elapsed: float) -> Dict[str, Any]:
        """构建成功响应字典。
        
        Args:
            result: 内部执行结果。
            elapsed: 执行耗时。
            
        Returns:
            标准化的成功响应。
        """
        return {
            "success": True,
            "data": result,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _err(
        self,
        msg: str,
        code: int,
        start: float,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """构建错误响应字典。
        
        Args:
            msg: 错误信息。
            code: 错误代码。
            start: 开始时间戳。
            details: 额外细节。
            
        Returns:
            标准化的错误响应。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round(time.monotonic() - start, 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, ok: bool, elapsed: float) -> None:
        """追加执行历史，保持最多 100 条记录。
        
        Args:
            ok: 是否成功。
            elapsed: 耗时。
        """
        self._history.append(
            {"ts": datetime.now(timezone.utc).isoformat(), "ok": ok, "t": elapsed}
        )
        if len(self._history) > 100:
            self._history.pop(0)

    def get_stats(self) -> Dict[str, Union[int, float]]:
        """获取工具运行统计信息。
        
        Returns:
            统计字典。
        """
        ok: int = self._stats["ok"]
        calls: int = self._stats["calls"]
        avg_time: float = self._stats["time"] / ok if ok > 0 else 0.0
        success_rate: float = ok / max(1, calls)
        
        return {
            **self._stats,
            "avg": round(avg_time, 4),
            "rate": round(success_rate, 4),
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近的历史执行记录。
        
        Args:
            limit: 返回记录条数限制。
            
        Returns:
            历史记录列表。
        """
        return self._history[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。
        
        Returns:
            描述符字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }

    def __repr__(self) -> str:
        """返回工具的可读表示。"""
        return f"<{self.__class__.__name__} v{self.version}>"
