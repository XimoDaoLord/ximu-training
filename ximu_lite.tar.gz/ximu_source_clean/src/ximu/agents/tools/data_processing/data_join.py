"""数据合并工具模块。支持内/左/右/外连接、拼接与合并操作。"""

import logging
from collections import deque
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataJoinTool(BaseTool):
    """数据合并工具类。

    支持 inner/left/right/outer 连接、concat 拼接与 merge 合并，
    适用于字典列表型结构化数据，模拟数据管道中的关系型操作。
    """

    name: str = "data_join"
    description: str = "数据合并工具"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "analytics"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """初始化数据合并工具实例。"""
        super().__init__()
        self._history: deque[Dict[str, Any]] = deque(maxlen=100)
        self._stats: Dict[str, Any] = {"calls": 0, "ok": 0, "fail": 0, "time": 0.0}

    def _setup_parameters(self) -> None:
        """注册工具参数定义。"""
        self.add_parameter(
            "action", str, required=True,
            choices=["inner", "left", "right", "outer", "concat", "merge"],
            description="操作类型",
        )
        self.add_parameter("left_data", list, required=True, description="左数据集（列表）")
        self.add_parameter("right_data", list, required=True, description="右数据集（列表）")
        self.add_parameter("on", str, required=False, default="id", description="连接键字段名")

    @staticmethod
    def _to_map(items: List[Any], key: str) -> Dict[Any, Dict[str, Any]]:
        """将列表转为以 key 为索引的字典映射。

        Args:
            items: 数据项列表。
            key: 用于索引的键名。

        Returns:
            {key_value: item, ...} 字典。
        """
        return {item[key]: item for item in items if isinstance(item, dict) and key in item}

    def _execute_join(self, left_data: List[Any], right_data: List[Any], key: str, join_type: str) -> Dict[str, Any]:
        """执行关系型连接操作。

        Args:
            left_data: 左数据集。
            right_data: 右数据集。
            key: 连接键字段名。
            join_type: 连接类型（inner/left/right/outer）。

        Returns:
            包含连接结果、类型、行数及键的字典。
        """
        right_map = self._to_map(right_data, key)
        if join_type == "inner":
            result = [
                {**left_item, **right_map.get(left_item.get(key), {})}
                for left_item in left_data
                if isinstance(left_item, dict) and left_item.get(key) in right_map
            ]
        elif join_type == "left":
            result = [
                {**left_item, **right_map.get(left_item.get(key), {})}
                for left_item in left_data
                if isinstance(left_item, dict)
            ]
        elif join_type == "right":
            left_map = self._to_map(left_data, key)
            result = [
                {**right_item, **left_map.get(right_item.get(key), {})}
                for right_item in right_data
                if isinstance(right_item, dict)
            ]
        else:  # outer
            left_keys = {item.get(key) for item in left_data if isinstance(item, dict)}
            right_keys = {item.get(key) for item in right_data if isinstance(item, dict)}
            return {
                "joined_count": len(left_keys | right_keys),
                "type": "outer",
                "key": key,
            }
        return {"joined": result, "type": join_type, "rows": len(result), "key": key}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行数据连接操作。

        Args:
            **kwargs: 包含 action/left_data/right_data/on 的参数字典。

        Returns:
            操作结果字典。

        Raises:
            ToolError: 参数缺失或操作未知时抛出。
        """
        action: str = kwargs.get("action", "")
        left_data: List[Any] = kwargs.get("left_data", [])
        right_data: List[Any] = kwargs.get("right_data", [])
        on_key: str = kwargs.get("on", "id")

        if not left_data or not right_data:
            raise ToolError("需要 left_data 与 right_data", code=1002)

        if action in ("inner", "left", "right", "outer"):
            return self._execute_join(left_data, right_data, on_key, action)
        if action == "concat":
            result = left_data + right_data
            return {"concatenated": result, "type": "concat", "rows": len(result), "axis": 0}
        if action == "merge":
            return {
                "merged": True,
                "type": "inner",
                "left_rows": len(left_data),
                "right_rows": len(right_data),
                "result_rows": min(len(left_data), len(right_data)),
            }
        raise ToolError(f"未知操作: {action}", code=1002)

    def run(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """运行工具的主入口。

        Args:
            params: 参数字典，可选。

        Returns:
            包含 success/data/error/execution_time 的结构化响应。
        """
        params = params or {}
        start: datetime = datetime.now(timezone.utc)
        self._stats["calls"] += 1

        try:
            ok, v = self.validate_parameters(params)
            if not ok:
                self._stats["fail"] += 1
                return self._build_error(str(v), 1002, start)
            result = self.execute(**v)
            elapsed: float = round((datetime.now(timezone.utc) - start).total_seconds(), 4)
            self._stats["ok"] += 1
            self._stats["time"] += elapsed
            self._append_history(elapsed, True)
            return self._build_success(result, elapsed)
        except ToolError as err:
            self._stats["fail"] += 1
            return self._build_error(err.message, err.code, start, err.details)
        except Exception as exc:  # pylint: disable=broad-except
            self._stats["fail"] += 1
            logger.exception("数据合并工具内部错误")
            return self._build_error("工具内部错误", 1006, start)

    def _build_success(self, data: Any, elapsed: float) -> Dict[str, Any]:
        """构建成功响应字典。

        Args:
            data: 执行结果。
            elapsed: 执行耗时（秒）。

        Returns:
            成功响应字典。
        """
        return {
            "success": True,
            "data": data,
            "error": None,
            "execution_time": elapsed,
            "tool": self.name,
            "version": self.version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _build_error(self, msg: Any, code: int, start: datetime, details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """构建错误响应字典。

        Args:
            msg: 错误信息。
            code: 错误码。
            start: 计时起点。
            details: 附加详情。

        Returns:
            错误响应字典。
        """
        return {
            "success": False,
            "data": None,
            "error": msg,
            "error_code": code,
            "error_details": details or {},
            "execution_time": round((datetime.now(timezone.utc) - start).total_seconds(), 4),
            "tool": self.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def _append_history(self, elapsed: float, ok: bool) -> None:
        """追加执行历史，保持最多 100 条记录。

        Args:
            elapsed: 本次执行耗时。
            ok: 是否成功。
        """
        self._history.append({
            "ts": datetime.now(timezone.utc).isoformat(),
            "ok": ok,
            "t": elapsed,
        })

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息。

        Returns:
            包含 calls/ok/fail/time/avg/rate 的字典。
        """
        ok: int = self._stats["ok"]
        calls: int = self._stats["calls"]
        avg: float = self._stats["time"] / ok if ok > 0 else 0.0
        return {
            **self._stats,
            "avg": round(avg, 4),
            "rate": round(ok / max(1, calls), 4),
        }

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取最近执行历史。

        Args:
            limit: 返回记录上限，默认10。

        Returns:
            历史记录列表。
        """
        return list(self._history)[-limit:]

    def get_descriptor(self) -> Dict[str, Any]:
        """获取工具描述符。

        Returns:
            工具描述符字典。
        """
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "tags": self.tags,
            "parameters": [p.to_dict() for p in self.parameters],
            "stats": self.get_stats(),
        }
