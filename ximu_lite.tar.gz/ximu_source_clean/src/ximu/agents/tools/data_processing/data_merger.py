"""
数据合并工具模块。

提供多种数据集合并策略，包括简单拼接、键值合并、SQL 风格连接、
集合并集及交集操作。所有操作均基于内存数据结构实现，适用于中小规模数据。
"""

import json
import logging
from typing import Any, Dict, List, Optional, Union

from src.ximu.agents.tools.base import BaseTool, ToolError

logger = logging.getLogger("ximu.tool")


class DataMergerTool(BaseTool):
    """
    数据合并工具，支持连接、合并、拼接、并集、交集数据集。

    该工具允许用户通过指定不同的 action 参数，灵活地对两个列表型
    数据集执行结构化的合并操作。
    """

    name: str = "data_merger"
    description: str = "数据合并工具，支持连接、合并、拼接、并集、交集数据集"
    version: str = "1.0.0"
    category: str = "data_processing"
    tags: List[str] = ["data", "processing", "transform"]
    author: str = "汐沫AI"

    def __init__(self) -> None:
        """
        初始化 DataMergerTool 实例。

        注册工具参数并准备内部状态。
        """
        super().__init__()
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """
        配置工具接受的外部参数。

        定义 action、data1、data2、key 及 join_type 参数。
        """
        self.add_parameter(
            "action", str, required=True, choices=["concat", "merge", "join", "union", "intersection"], description="操作类型"
        )
        self.add_parameter("data1", list, required=True, description="数据集1")
        self.add_parameter("data2", list, required=True, description="数据集2")
        self.add_parameter("key", str, required=False, default="", description="连接键")
        self.add_parameter(
            "join_type", str, required=False, default="inner", choices=["inner", "left", "right", "outer"], description="连接类型"
        )

    def _hash_item(self, item: Any) -> str:
        """
        生成项目哈希字符串。

        优先使用 JSON 序列化以保证顺序无关性，若失败则回退到字符串表示。

        Args:
            item: 任意可哈希或可序列化对象。

        Returns:
            用于去重或比较的哈希字符串。
        """
        try:
            return json.dumps(item, sort_keys=True)
        except (TypeError, ValueError):
            return str(item)

    def _build_dict_map(self, data: List[Any], key: str) -> Dict[Any, Dict[str, Any]]:
        """
        构建基于指定键的字典映射。

        遍历列表，仅处理字典类型元素，以 key 对应的值为键构建映射表。

        Args:
            data: 输入的列表数据。
            key: 用于映射的字典键名。

        Returns:
            键值映射字典。
        """
        result: Dict[Any, Dict[str, Any]] = {}
        for item in data:
            if isinstance(item, dict) and key in item:
                result[item[key]] = item
        return result

    def _validate_inputs(self, data1: Any, data2: Any) -> None:
        """
        验证输入数据的基础类型。

        确保两个输入参数均为列表类型。

        Args:
            data1: 第一个数据集。
            data2: 第二个数据集。

        Raises:
            ToolError: 当输入不是列表时抛出。
        """
        if not isinstance(data1, list):
            raise ToolError("data1 必须是列表类型", code=1002)
        if not isinstance(data2, list):
            raise ToolError("data2 必须是列表类型", code=1002)

    def _perform_concat(self, data1: List[Any], data2: List[Any]) -> Dict[str, Any]:
        """
        执行拼接操作。

        将两个列表简单相加。

        Args:
            data1: 列表1。
            data2: 列表2。

        Returns:
            包含合并结果及计数的字典。
        """
        merged = data1 + data2
        return {"merged": merged, "count": len(merged)}

    def _perform_merge(self, data1: List[Any], data2: List[Any], key: str) -> Dict[str, Any]:
        """
        执行基于键的合并操作。

        遍历 data1，尝试从 data2 中查找匹配键并更新当前项。

        Args:
            data1: 主数据集列表。
            data2: 从数据集列表。
            key: 连接键名。

        Returns:
            包含合并结果及计数的字典。

        Raises:
            ToolError: 当 key 为空时抛出。
        """
        if not key:
            raise ToolError("merge 操作需要指定 key", code=1002)
        map2 = self._build_dict_map(data2, key)
        result: List[Dict[str, Any]] = []
        for item in data1:
            if isinstance(item, dict):
                merged_item = dict(item)
                other = map2.get(item.get(key))
                if other:
                    merged_item.update(other)
                result.append(merged_item)
        return {"merged": result, "count": len(result)}

    def _perform_join(self, data1: List[Any], data2: List[Any], key: str, join_type: str) -> Dict[str, Any]:
        """
        执行 SQL 风格连接操作。

        支持 inner, left, right, outer 四种连接类型。

        Args:
            data1: 左表数据。
            data2: 右表数据。
            key: 连接键。
            join_type: 连接类型。

        Returns:
            包含连接结果、计数及类型的字典。

        Raises:
            ToolError: 当 key 为空时抛出。
        """
        if not key:
            raise ToolError("join 操作需要指定 key", code=1002)
        map1 = self._build_dict_map(data1, key)
        map2 = self._build_dict_map(data2, key)
        keys1 = set(map1.keys())
        keys2 = set(map2.keys())

        if join_type == "inner":
            join_keys = keys1 & keys2
        elif join_type == "left":
            join_keys = keys1
        elif join_type == "right":
            join_keys = keys2
        else:
            join_keys = keys1 | keys2

        result: List[Dict[str, Any]] = []
        for k in join_keys:
            merged: Dict[str, Any] = {}
            if k in map1:
                merged.update(map1[k])
            if k in map2:
                merged.update(map2[k])
            result.append(merged)
        return {"joined": result, "count": len(result), "join_type": join_type}

    def _perform_union(self, data1: List[Any], data2: List[Any]) -> Dict[str, Any]:
        """
        执行并集操作（去重）。

        合并两个列表并移除重复项，基于哈希值去重。

        Args:
            data1: 列表1。
            data2: 列表2。

        Returns:
            包含并集结果及计数的字典。
        """
        seen: set = set()
        result: List[Any] = []
        for item in data1 + data2:
            h = self._hash_item(item)
            if h not in seen:
                seen.add(h)
                result.append(item)
        return {"union": result, "count": len(result)}

    def _perform_intersection(self, data1: List[Any], data2: List[Any]) -> Dict[str, Any]:
        """
        执行交集操作。

        返回同时存在于两个列表中的元素。

        Args:
            data1: 列表1。
            data2: 列表2。

        Returns:
            包含交集结果及计数的字典。
        """
        set1 = {self._hash_item(x) for x in data1}
        set2 = {self._hash_item(x) for x in data2}
        common = set1 & set2
        result: List[Any] = []
        for s in common:
            try:
                result.append(json.loads(s))
            except json.JSONDecodeError:
                result.append(s)
        return {"intersection": result, "count": len(result)}

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """
        执行数据合并操作的主入口。

        根据 action 参数分发到具体的合并逻辑。

        Args:
            **kwargs: 包含 action、data1、data2、key、join_type 等键值的字典。

        Returns:
            合并结果字典。

        Raises:
            ToolError: 当操作未知或输入无效时抛出。
        """
        data1: List[Any] = kwargs.get("data1", [])
        data2: List[Any] = kwargs.get("data2", [])
        action: str = kwargs.get("action", "")
        key: str = kwargs.get("key", "")
        join_type: str = kwargs.get("join_type", "inner")

        self._validate_inputs(data1, data2)

        if action == "concat":
            return self._perform_concat(data1, data2)
        elif action == "merge":
            return self._perform_merge(data1, data2, key)
        elif action == "join":
            return self._perform_join(data1, data2, key, join_type)
        elif action == "union":
            return self._perform_union(data1, data2)
        elif action == "intersection":
            return self._perform_intersection(data1, data2)
        else:
            raise ToolError(f"未知操作: {action}", code=1002)
