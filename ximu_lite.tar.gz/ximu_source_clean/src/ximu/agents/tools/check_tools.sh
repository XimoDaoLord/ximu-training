#!/usr/bin/env bash
# 汐沫AI - 实用工具检查脚本
# 参数化路径、统一输出风格、增强错误边界

set -uo pipefail

# 路径与变量初始化
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
XIMU_BASE_DIR="${XIMU_BASE_DIR:-$(dirname "$(dirname "$(dirname "$SCRIPT_DIR")")")}"
BASE_DIR="$XIMU_BASE_DIR"

# 输出成功信息
# 参数: $1=标签, $2=详情（可选）
_emit_ok() {
    local label="$1"
    local detail="${2:-}"
    if [[ -n "$detail" ]]; then
        echo "  ✅ $label: $detail"
    else
        echo "  ✅ $label"
    fi
}

# 输出警告信息
# 参数: $1=标签, $2=提示（可选）
_emit_warn() {
    local label="$1"
    local hint="${2:-}"
    if [[ -n "$hint" ]]; then
        echo "  ⚠️ $label: $hint"
    else
        echo "  ⚠️ $label: 未配置"
    fi
}

# 输出失败信息
# 参数: $1=标签, $2=修复提示（可选）
_emit_fail() {
    local label="$1"
    local hint="${2:-}"
    echo "  ❌ $label"
    if [[ -n "$hint" ]]; then
        echo "     修复: $hint"
    fi
}

# 检查命令是否存在
# 参数: $1=命令名称
# 返回: 0=存在，1=不存在
_check_command() {
    local cmd="$1"
    command -v "$cmd" &> /dev/null
}

# 获取命令版本信息
# 参数: $1=工具名称
# 返回: 版本字符串
_get_version() {
    local tool="$1"
    "$tool" --version 2>/dev/null | head -1 || echo '已安装'
}

# 检查搜索工具
check_search_tool() {
    echo ""
    echo "🔍 [搜索工具]"
    if _check_command "open-websearch"; then
        local version
        version="$(open-websearch --version 2>/dev/null || echo '未知版本')"
        _emit_ok "open-websearch" "$version"
    else
        _emit_warn "open-websearch" "未安装"
        echo "     安装: pip install open-websearch"
    fi
}

# 检查浏览器自动化工具
check_browser_automation() {
    echo ""
    echo "🌐 [浏览器自动化]"
    local automation_path="$BASE_DIR/skills/browser-automation/dist/index.js"
    if [[ -f "$automation_path" ]]; then
        _emit_ok "browser-automation" "已构建"
    else
        _emit_warn "browser-automation" "未构建"
        echo "     构建: cd skills/browser-automation && npm install && npm run build"
    fi
}

# 检查自定义MCP服务器
check_custom_mcp() {
    echo ""
    echo "⚙️ [自定义MCP服务器]"
    local pid_file="$BASE_DIR/logs/mcp_server.pid"
    local pid=""
    if [[ -f "$pid_file" ]]; then
        pid="$(cat "$pid_file" 2>/dev/null || echo "")"
        if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
            _emit_ok "custom-mcp" "运行中 (PID: $pid)"
        else
            _emit_fail "custom-mcp" "bash skills/custom-mcp-server/start_mcp.sh"
        fi
    else
        _emit_fail "custom-mcp" "bash skills/custom-mcp-server/start_mcp.sh"
    fi
}

# 检查文件系统MCP
check_filesystem_mcp() {
    echo ""
    echo "📁 [文件系统MCP]"
    if [[ -d "$BASE_DIR" ]]; then
        _emit_ok "filesystem" "$BASE_DIR"
    else
        _emit_fail "filesystem" "路径不存在"
        echo "     期望路径: $BASE_DIR"
    fi
}

# 检查备用工具
check_fallback_tools() {
    echo ""
    echo "🔧 [备用工具]"
    local tool version
    for tool in "curl" "jq" "sqlite3"; do
        if _check_command "$tool"; then
            version="$("$tool" --version 2>/dev/null | head -1 || echo '已安装')"
            _emit_ok "$tool" "$version"
        else
            _emit_warn "$tool" "未安装"
        fi
    done
}

# 显示MCP配置
show_mcp_config() {
    echo ""
    echo "📋 [MCP配置]"
    local config_file="$BASE_DIR/mcp_config.json"
    if [[ -f "$config_file" ]]; then
        head -30 "$config_file"
        echo "  ..."
    else
        _emit_warn "MCP配置" "文件不存在"
        echo "     期望: $config_file"
    fi
}

# 执行所有检查
main_check() {
    echo "=========================================="
    echo "  汐沫AI - 实用工具检查"
    echo "=========================================="

    check_search_tool
    check_browser_automation
    check_custom_mcp
    check_filesystem_mcp
    check_fallback_tools
    show_mcp_config

    echo ""
    echo "=========================================="
    echo "  工具检查完成！"
    echo "=========================================="
}

main_check