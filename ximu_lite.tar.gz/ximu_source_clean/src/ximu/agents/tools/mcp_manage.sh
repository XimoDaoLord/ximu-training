#!/usr/bin/env bash
# 汐沫AI - MCP管理工具（启动/停止/重启）
# 支持环境变量配置，增强路径解析、PID文件校验

set -euo pipefail

# 路径解析，支持环境变量覆盖
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
XIMU_BASE_DIR="${XIMU_BASE_DIR:-$(dirname "$(dirname "$(dirname "$SCRIPT_DIR")")")}"
MCP_DIR="$XIMU_BASE_DIR"
PID_FILE="${MCP_PID_FILE:-$MCP_DIR/logs/mcp_server.pid}"
LOG_FILE="${MCP_LOG_FILE:-$MCP_DIR/logs/mcp_server.log}"
MCP_SERVER_DIR="${MCP_SERVER_DIR:-$MCP_DIR/skills/custom-mcp-server}"
MCP_SERVER_SCRIPT="$MCP_SERVER_DIR/mcp_server.py"
PYTHON_BIN="${PYTHON_BIN:-python3}"

# 显示用法信息
usage() {
    echo "用法: $0 {start|stop|restart|status|help}"
    echo ""
    echo "命令:"
    echo "  start    - 启动MCP服务器"
    echo "  stop     - 停止MCP服务器"
    echo "  restart  - 重启MCP服务器"
    echo "  status   - 查看MCP状态"
    echo "  help     - 显示帮助"
}

# 校验脚本环境，确保必要文件和命令存在
_validate_environment() {
    if [[ ! -f "$MCP_SERVER_SCRIPT" ]]; then
        echo "❌ 错误: 找不到MCP服务器脚本: $MCP_SERVER_SCRIPT" >&2
        return 1
    fi

    if ! command -v "$PYTHON_BIN" &>/dev/null; then
        echo "❌ 错误: 未找到 $PYTHON_BIN，请检查Python环境" >&2
        return 1
    fi

    mkdir -p "$(dirname "$PID_FILE")" "$(dirname "$LOG_FILE")" "$MCP_SERVER_DIR"
}

# 获取当前运行中的MCP PID，若有效则输出并返回0，否则返回1
_get_running_pid() {
    local old_pid
    if [[ ! -f "$PID_FILE" ]]; then
        return 1
    fi
    old_pid="$(cat "$PID_FILE" 2>/dev/null || echo "")"
    if [[ -n "$old_pid" ]] && kill -0 "$old_pid" 2>/dev/null; then
        echo "$old_pid"
        return 0
    fi
    return 1
}

# 启动MCP服务器
start_mcp() {
    echo "启动自定义MCP服务器..."
    _validate_environment

    local running_pid
    if running_pid="$("$_get_running_pid" 2>/dev/null || true)"; then
        if [[ -n "$running_pid" ]]; then
            echo "⚠️ MCP服务器已在运行 (PID: $running_pid)"
            return 0
        fi
    fi

    # 清理可能残留的无效PID文件
    [[ -f "$PID_FILE" ]] && rm -f "$PID_FILE"

    # 启动服务
    (
        cd "$MCP_SERVER_DIR"
        nohup "$PYTHON_BIN" "$(basename "$MCP_SERVER_SCRIPT")" >> "$LOG_FILE" 2>&1 &
        echo $! > "$PID_FILE"
    )

    local new_pid
    new_pid="$(cat "$PID_FILE" 2>/dev/null || echo "")"

    # 等待启动确认
    sleep 2

    if [[ -n "$new_pid" ]] && kill -0 "$new_pid" 2>/dev/null; then
        echo "✅ MCP服务器已启动 (PID: $new_pid)"
        echo "📝 日志: $LOG_FILE"
    else
        echo "❌ 启动失败，查看日志: $LOG_FILE" >&2
        [[ -f "$PID_FILE" ]] && rm -f "$PID_FILE"
        return 1
    fi
}

# 停止MCP服务器，先尝试优雅停止，超时则强制终止
stop_mcp() {
    echo "停止MCP服务器..."

    local running_pid
    running_pid="$("$_get_running_pid" 2>/dev/null || true)"
    if [[ -n "$running_pid" ]]; then
        kill "$running_pid" 2>/dev/null || true
        sleep 1
        if kill -0 "$running_pid" 2>/dev/null; then
            echo "⚠️ 正常停止超时，执行强制终止"
            kill -9 "$running_pid" 2>/dev/null || true
        fi
        echo "✅ MCP服务器已停止 (PID: $running_pid)"
    else
        echo "⚠️ MCP服务器未运行或PID文件无效"
    fi

    [[ -f "$PID_FILE" ]] && rm -f "$PID_FILE"
}

# 重启MCP服务器
restart_mcp() {
    echo "重启MCP服务器..."
    stop_mcp
    sleep 1
    start_mcp
}

# 显示MCP状态，优先使用外部状态脚本，降级为本地检查
show_status() {
    local status_script="$MCP_DIR/tools/mcp_status.sh"
    if [[ -f "$status_script" ]]; then
        bash "$status_script"
    else
        echo "⚠️ 状态脚本不存在: $status_script"
        local running_pid
        running_pid="$("$_get_running_pid" 2>/dev/null || true)"
        if [[ -n "$running_pid" ]]; then
            echo "✅ MCP服务器运行中 (PID: $running_pid)"
        else
            echo "❌ MCP服务器未运行"
        fi
    fi
}

# 主入口
main() {
    local command="${1:-status}"
    case "$command" in
        start) start_mcp ;;
        stop) stop_mcp ;;
        restart) restart_mcp ;;
        status) show_status ;;
        help) usage ;;
        *)
            echo "未知命令: $command" >&2
            usage >&2
            exit 1
            ;;
    esac
}

main "$@"