"""
向量嵌入生成工具。提供文本到向量的转换能力，支持缓存机制。
v2.0：使用真实云端向量模型（智谱+agnes多模型轮询），不再用MD5哈希伪向量。
v2.1：密钥改为从环境变量读取，消除明文硬编码。
"""
import json
import os
import ssl
import struct
import urllib.request
from collections import OrderedDict
from typing import Any, Dict, List, Optional
from dataclasses import dataclass

from src.ximu.agents.tools.base import BaseTool, ToolError

# 性能优化：numpy加速向量归一化；struct.pack紧凑序列化2048维向量（Jina v5）。
try:  # pragma: no cover - 运行环境探测
    import numpy as _np
    _HAS_NUMPY: bool = True
except Exception:  # pragma: no cover
    _np = None  # type: ignore
    _HAS_NUMPY = False

# 性能优化：预计算 byte(0..255) -> [-1,1] 浮点映射表，避免2048次重复除法。
_BYTE_TO_FLOAT: List[float] = [(b / 255.0) * 2.0 - 1.0 for b in range(256)]


@dataclass
class EmbeddingModelConfig:
    """嵌入模型配置。"""
    name: str
    api_key: str
    base_url: str
    model: str
    dim: int
    priority: int = 1


# 多向量模型配置（智谱高维优先，自动轮询，失败切换）
# 密钥从环境变量读取，避免明文硬编码；未设置时返回空串，运行时降级跳过该模型。
EMBEDDING_MODELS: List[EmbeddingModelConfig] = [
    EmbeddingModelConfig(
        name="zhipu-embedding-3",
        api_key=os.environ.get("ZHIPU_API_KEY", ""),
        base_url="https://open.bigmodel.cn/api/paas/v4/embeddings",
        model="embedding-3",
        dim=2048,
        priority=1
    ),
    EmbeddingModelConfig(
        name="zhipu-embedding-2",
        api_key=os.environ.get("ZHIPU_API_KEY", ""),
        base_url="https://open.bigmodel.cn/api/paas/v4/embeddings",
        model="embedding-2",
        dim=1024,
        priority=2
    ),
    EmbeddingModelConfig(
        name="agnes-embedding",
        api_key=os.environ.get("AGNES_API_KEY", ""),
        base_url="https://apihub.agnes-ai.com/v1/embeddings",
        model="text-embedding-ada-002",
        dim=1536,
        priority=3
    ),
    EmbeddingModelConfig(
        name="agnes-backup-embedding",
        api_key=os.environ.get("AGNES_BACKUP_API_KEY", ""),
        base_url="https://apihub.agnes-ai.com/v1/embeddings",
        model="text-embedding-ada-002",
        dim=1536,
        priority=4
    ),
]

# 统一输出维度：高维2048维
TARGET_DIM: int = 2048

# SSL上下文（不走代理）
_SSL_CONTEXT: ssl.SSLContext = ssl.create_default_context()
_OPENER: urllib.request.OpenerDirector = urllib.request.build_opener(
    urllib.request.ProxyHandler({}),
    urllib.request.HTTPSHandler(context=_SSL_CONTEXT)
)


def _normalize_vector(vec: List[float], target_dim: int = TARGET_DIM) -> List[float]:
    """统一向量维度：pad或truncate到target_dim。

    Args:
        vec: 输入向量。
        target_dim: 目标维度。

    Returns:
        标准化后的向量。
    """
    if len(vec) == target_dim:
        return vec
    if len(vec) > target_dim:
        return vec[:target_dim]
    return vec + [0.0] * (target_dim - len(vec))


def l2_normalize(vec: List[float]) -> List[float]:
    """L2归一化向量（预计算，后续余弦相似度只需点积，避免重复开方）。

    性能优化：numpy可用时单次BLAS算范数；否则纯Python。零向量返回原向量。
    """
    if not vec:
        return vec
    if _HAS_NUMPY:
        try:
            v = _np.asarray(vec, dtype=_np.float32)
            n = float(_np.linalg.norm(v))
            return (v / n).tolist() if n > 0 else list(vec)
        except Exception:
            pass
    norm = sum(x * x for x in vec) ** 0.5
    return [x / norm for x in vec] if norm > 0 else list(vec)


def serialize_vector(vec: List[float]) -> bytes:
    """用struct.pack紧凑序列化float32向量（比JSON小~4倍，速度更快）。

    用于Jina v5 2048维向量存储：2048*4=8KB，JSON约30KB+。
    """
    return struct.pack(f"<{len(vec)}f", *vec)


def deserialize_vector(data: bytes) -> List[float]:
    """反序列化struct.pack得到的float32向量。

    Args:
        data: 二进制数据。

    Returns:
        反序列化后的向量。
    """
    n = len(data) // 4
    return list(struct.unpack(f"<{n}f", data))


class _EmbeddingAPIClient:
    """嵌入API客户端，支持多模型轮询。"""

    def __init__(self, models: List[EmbeddingModelConfig], max_failures: int = 5) -> None:
        """初始化客户端。

        Args:
            models: 模型配置列表。
            max_failures: 最大失败次数。
        """
        self._models: List[EmbeddingModelConfig] = sorted(
            models, key=lambda m: m.priority
        )
        self._failed_counts: Dict[str, int] = {m.name: 0 for m in models}
        self._max_failures: int = max_failures

    def _call_single_model(self, text: str, model_cfg: EmbeddingModelConfig) -> Optional[List[float]]:
        """调用单个模型获取嵌入。

        Args:
            text: 输入文本。
            model_cfg: 模型配置。

        Returns:
            嵌入向量或None。
        """
        try:
            body = json.dumps({"model": model_cfg.model, "input": text[:8000]}).encode("utf-8")
            req = urllib.request.Request(
                model_cfg.base_url,
                data=body,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {model_cfg.api_key}"
                }
            )
            with _OPENER.open(req, timeout=20) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                vec = data["data"][0]["embedding"]
                return _normalize_vector(vec, TARGET_DIM)
        except Exception:
            self._failed_counts[model_cfg.name] = self._failed_counts.get(model_cfg.name, 0) + 1
            return None

    def get_embedding(self, text: str) -> Optional[List[float]]:
        """获取嵌入向量，自动切换模型。

        Args:
            text: 输入文本。

        Returns:
            嵌入向量或None。
        """
        for model_cfg in self._models:
            if not model_cfg.api_key:
                continue
            if self._failed_counts.get(model_cfg.name, 0) >= self._max_failures:
                continue
            
            vec = self._call_single_model(text, model_cfg)
            if vec is not None:
                self._failed_counts[model_cfg.name] = 0
                return vec
        
        return None


class EmbeddingGeneratorTool(BaseTool):
    """向量嵌入生成工具，提供文本到向量的转换能力。
    v2.0：使用真实云端向量模型（智谱+agnes多模型轮询），1024维。
    """

    name: str = "embedding_generator"
    description: str = "向量嵌入生成工具（真实云端模型，多模型轮询，1024维）"
    version: str = "2.0.0"
    category: str = "ai_tools"
    tags: List[str] = ["ai", "ml", "embedding"]
    author: str = "汐沫AI"

    def __init__(self, max_cache_size: int = 4096) -> None:
        """初始化工具。

        Args:
            max_cache_size: 最大缓存大小。
        """
        super().__init__()
        self._embed_cache: OrderedDict[str, List[float]] = OrderedDict()
        self._embed_cache_max: int = max_cache_size
        self._api_client: _EmbeddingAPIClient = _EmbeddingAPIClient(EMBEDDING_MODELS)
        self._setup_parameters()

    def _setup_parameters(self) -> None:
        """设置参数。"""
        self.add_parameter("text", str, required=True, description="文本")
        self.add_parameter("model", str, required=False, default="", description="模型")
        self.add_parameter("dimensions", int, required=False, default=TARGET_DIM, description="维度")

    def execute(self, **kwargs: Any) -> Dict[str, Any]:
        """执行嵌入生成。

        Args:
            **kwargs: 包含 text, model, dimensions 等参数

        Returns:
            包含嵌入向量的字典

        Raises:
            ToolError: 当文本为空或嵌入生成失败时抛出
        """
        text: str = kwargs.get("text", "")
        if not isinstance(text, str) or not text.strip():
            raise ToolError("文本为空", code=1002)

        cache_key: str = text
        cached: Optional[List[float]] = self._embed_cache.get(cache_key)
        if cached is not None:
            self._embed_cache.move_to_end(cache_key)
            return {"embedding": list(cached), "dimensions": len(cached), "cached": True}

        embedding: Optional[List[float]] = self._generate_embedding(text)
        if embedding is None:
            raise ToolError("嵌入生成失败", code=1006)

        self._embed_cache[cache_key] = embedding
        if len(self._embed_cache) > self._embed_cache_max:
            self._embed_cache.popitem(last=False)

        return {"embedding": embedding, "dimensions": len(embedding), "cached": False}

    def _generate_embedding(self, text: str) -> Optional[List[float]]:
        """生成嵌入向量。
        v2.0：优先调用真实云端API（多模型轮询），全部失败才降级。

        Args:
            text: 输入文本。

        Returns:
            嵌入向量或None。
        """
        return self._api_client.get_embedding(text)
