"""统一SSRF防护工具模块。

所有接受用户URL的网络工具在发起请求前必须调用assert_safe_url()，
拦截环回/私网/链路本地/组播/未指定地址，防止SSRF攻击内网服务。
"""

from __future__ import annotations

import ipaddress
from typing import Tuple
from urllib.parse import urlparse

_BLOCKED_HOSTNAMES: frozenset[str] = frozenset({
    "localhost",
    "localhost.localdomain",
})


def is_blocked_host(host: str) -> bool:
    """判断host是否为应被拦截的内网/环回地址。

    检查规则：
    - 空host视为不安全
    - 显式localhost变体视为不安全
    - 字面IP（v4/v6）按ipaddress模块判定私网/环回/链路本地/组播/未指定/保留地址
    - 域名不在此处拦截（DNS rebinding由调用方在受控环境下处理）

    Args:
        host: 待检查的主机名或IP地址

    Returns:
        是否应被拦截
    """
    if not host:
        return True

    host = host.strip().lower().rstrip(".")

    if host in _BLOCKED_HOSTNAMES:
        return True

    if host.startswith("[") and host.endswith("]"):
        host = host[1:-1]

    try:
        ip: ipaddress._BaseAddress = ipaddress.ip_address(host)
    except ValueError:
        return False

    return bool(
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_multicast
        or ip.is_unspecified
        or getattr(ip, "is_reserved", False)
    )


def parse_safe_url(url: str) -> Tuple[bool, str]:
    """解析并校验URL安全性。

    Args:
        url: 待检查的URL字符串

    Returns:
        (是否安全, 原因说明)元组。若安全，原因说明为主机名。
    """
    if not isinstance(url, str) or not url:
        return False, "empty url"

    parsed = urlparse(url)
    scheme: str = (parsed.scheme or "").lower()

    if scheme not in ("http", "https", "ws", "wss"):
        return False, "scheme not allowed: " + scheme

    host: str = (parsed.hostname or "").lower()

    if is_blocked_host(host):
        return False, "blocked host: " + host

    return True, host


class SSRFBlocked(RuntimeError):
    """URL命中SSRF黑名单时抛出的异常。

    调用方可捕获此异常并转换为各自的业务错误。
    """

    def __init__(self, reason: str, code: int = 1004) -> None:
        """初始化SSRFBlocked异常。

        Args:
            reason: 拦截原因
            code: 业务错误码，默认1004
        """
        super().__init__("url blocked: " + reason)
        self.code: int = code
        self.reason: str = reason
        self.message: str = "url blocked: " + reason


def assert_safe_url(url: str, code: int = 1004) -> None:
    """在发起请求前断言URL安全，不安全则抛出SSRFBlocked。

    Args:
        url: 待检查的URL
        code: 业务错误码，默认1004

    Raises:
        SSRFBlocked: 当URL不合法或主机被拦截时抛出
    """
    ok: bool
    reason: str
    ok, reason = parse_safe_url(url)
    if not ok:
        raise SSRFBlocked(reason, code=code)


def assert_safe_host(host: str, code: int = 1004) -> None:
    """对host:port或纯host形式的目标做SSRF校验。

    适用于gRPC/MQTT/SMTP/ping/port_scan/ssl_check/traceroute等非URL形式的工具。

    Args:
        host: 主机名或host:port格式的目标地址
        code: 业务错误码，默认1004

    Raises:
        SSRFBlocked: 当host为空或命中黑名单时抛出
    """
    if not isinstance(host, str) or not host:
        raise SSRFBlocked("empty host", code=code)

    raw: str = host.strip()

    if raw.startswith("["):
        host_part: str = raw.split("]")[0].lstrip("[")
    elif ":" in raw:
        host_part = raw.rsplit(":", 1)[0]
    else:
        host_part = raw

    if is_blocked_host(host_part):
        raise SSRFBlocked("blocked host: " + host_part, code=code)


__all__: list[str] = ["is_blocked_host", "parse_safe_url", "assert_safe_url", "assert_safe_host"]
