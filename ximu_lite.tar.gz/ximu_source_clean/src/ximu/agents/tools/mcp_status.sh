#!/usr/bin/env bash
# 汐沫AI - MCP状态检查工具
# 复用路径变量、统一输出风格、增强日志截取可配置性

set -uo pipefail

# 路径与变量初始化
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
XIMU_BASE_DIR="${XIMU_BASE_DIR:-$(dirname "$(dirname "$(dirname "$SCRIPT_DIR")")")}"
BASE_DIR="$XIMU_BASE_DIR"
LOG_TAIL_LINES="${MCP_LOG_TAIL_LINES:-5}"

# 获取MCP服务PID
# 返回: 成功时输出PID并返回0，失败返回1
_get_mcp_pid() {
    local pid_file="$BASE_DIR/logs/mcp_server.pid"
    local pid=""
    if [[ -f "$pid_file" ]]; then
        pid="$(cat "$pid_file" 2>/dev/null || echo "")"
        if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
            echo "$pid"
            return 0
        fi
    fi
    return 1
}

# 检查custom-mcp服务器状态
check_custom_mcp_status() {
    echo ""
    echo "📊 [1/4] custom-mcp 服务器:"
    local pid=""
    if pid="$("$_get_mcp_pid" 2>/dev/null || true)"; then
        if [[ -n "$pid" ]]; then
            echo "  ✅ 运行中 (PID: $pid)"
            return 0
        fi
    fi
    if [[ -f "$BASE_DIR/logs/mcp_server.pid" ]]; then
        echo "  ❌ 未运行 (PID文件存在但进程不存在)"
    else
        echo "  ⚠️ 未启动 (无PID文件)"
    fi
}

# 检查open-websearch状态
check_open_websearch_status() {
    echo ""
    echo "🔍 [2/4] open-websearch:"
    if command -v open-websearch &> /dev/null; then
        local version
        version="$(open-websearch --version 2>/dev/null || echo '未知')"
        echo "  ✅ 已安装 (版本: $version)"
    else
        echo "  ⚠️ 未安装"
        echo "     安装: pip install open-websearch"
    fi
}

# 检查browser-automation状态
check_browser_automation_status() {
    echo ""
    echo "🌐 [3/4] browser-automation:"
    local automation_path="$BASE_DIR/skills/browser-automation/dist/index.js"
    if [[ -f "$automation_path" ]]; then
        echo "  ✅ 已构建"
    else
        echo "  ⚠️ 未构建"
        echo "     构建: cd skills/browser-automation && npm install && npm run build"
    fi
}

# 检查filesystem MCP状态
check_filesystem_mcp_status() {
    echo ""
    echo "📁 [4/4] filesystem MCP:"
    if [[ -d "$BASE_DIR" ]]; then
        echo "  ✅ 已配置 (路径: $BASE_DIR)"
    else
        echo "  ❌ 路径不存在 (期望: $BASE_DIR)"
    fi
}

# 显示当前运行的MCP进程
show_mcp_processes() {
    echo ""
    echo "🔄 [当前运行的MCP进程]:"
    local processes
    processes="$(ps aux | grep -E "mcp_server|browser-automation" | grep -v grep || true)"
    if [[ -n "$processes" ]]; then
        echo "$processes"
    else
        echo "  无相关进程"
    fi
}

# 显示最近日志
show_recent_logs() {
    echo ""
    echo "📝 [最近日志 (最近${LOG_TAIL_LINES}行)]:"
    local log_file="$BASE_DIR/logs/mcp_server.log"
    if [[ -f "$log_file" ]]; then
        tail -"$LOG_TAIL_LINES" "$log_file" 2>/dev/null || echo "  (日志读取失败)"
    else
        echo "  无日志文件"
    fi
}

# 执行所有状态检查
main_status() {
    echo "=========================================="
    echo "  汐沫AI - MCP服务器状态"
    echo "=========================================="

    check_custom_mcp_status
    check_open_websearch_status
    check_browser_automation_status
    check_filesystem_mcp_status
    show_mcp_processes
    show_recent_logs

    echo ""
    echo "=========================================="
    echo "  状态检查完成！"
    echo "=========================================="
}

main_status