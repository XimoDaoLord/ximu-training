from __future__ import annotations

from typing import Any, Dict, Optional


class CallCostController:
    """调用成本控制器，用于估算、检查和记录 LLM 调用的花费，支持预算控制。"""

    DEFAULT_PRICE: Dict[str, tuple] = {
        "gpt-4o": (0.0025, 0.01),
        "gpt-4o-mini": (0.00015, 0.0006),
        "deepseek-chat": (0.00027, 0.0011),
        "local": (0.0, 0.0),
    }

    def __init__(self, budget_usd: Optional[float] = None) -> None:
        """初始化成本控制器，设置初始价格和预算。"""
        self.price: Dict[str, tuple] = dict(self.DEFAULT_PRICE)
        self.budget_usd: Optional[float] = budget_usd
        self.spent_usd: float = 0.0
        self.calls: int = 0
        self.total_prompt_tokens: int = 0
        self.total_completion_tokens: int = 0
        self._by_personality: Dict[str, Dict[str, float]] = {}

    def set_price(self, model: str, in_per_1k: float, out_per_1k: float) -> None:
        """设置指定模型的输入和输出单价（每1k token）。"""
        self.price[model] = (float(in_per_1k), float(out_per_1k))

    def _price_for(self, model: str) -> tuple:
        """获取模型价格，如果本地未设置则尝试从定价服务获取。"""
        if model in self.price:
            return self.price[model]
        try:
            from src.ximu.core.pricing import get_model_price
            p = get_model_price(model)
            return (float(p.get("in_per_1k", 0.0)), float(p.get("out_per_1k", 0.0)))
        except ImportError:
            return (0.0, 0.0)

    def estimate(self, prompt_tokens: int, completion_tokens: int, model: str) -> float:
        """根据 token 数量和模型估算调用成本。"""
        pin, pout = self._price_for(model)
        return (max(0, prompt_tokens) / 1000.0 * pin + max(0, completion_tokens) / 1000.0 * pout)

    def can_afford(self, est_cost: float) -> bool:
        """检查当前预算是否足以支付估算成本。"""
        if self.budget_usd is None:
            return True
        return self.spent_usd + est_cost <= self.budget_usd + 1e-12

    @property
    def remaining(self) -> Optional[float]:
        """获取剩余预算，无预算限制时返回 None。"""
        return None if self.budget_usd is None else max(0.0, self.budget_usd - self.spent_usd)

    def record(self, usage: Dict[str, int], model: str, personality_id: str = "") -> Dict[str, Any]:
        """记录一次 LLM 调用的成本，更新统计信息并返回记录结果。"""
        def _int(v: Any) -> int:
            try:
                return max(0, int(v))
            except (TypeError, ValueError):
                return 0

        pt = _int(usage.get("prompt_tokens", 0))
        ct = _int(usage.get("completion_tokens", 0))
        cost = self.estimate(pt, ct, model)
        if not self.can_afford(cost):
            return {"allowed": False, "cost": cost, "spent": self.spent_usd, "budget": self.budget_usd}

        self.spent_usd = round(self.spent_usd + cost, 9)
        self.calls += 1
        self.total_prompt_tokens += pt
        self.total_completion_tokens += ct
        if personality_id:
            acc = self._by_personality.setdefault(
                personality_id,
                {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0, "cost_usd": 0.0},
            )
            acc["calls"] += 1
            acc["prompt_tokens"] += pt
            acc["completion_tokens"] += ct
            acc["cost_usd"] = round(acc["cost_usd"] + cost, 9)

        return {
            "allowed": True,
            "cost": cost,
            "spent": self.spent_usd,
            "calls": self.calls,
            "remaining": self.remaining,
            "personality_id": personality_id or None,
        }

    def summary(self) -> Dict[str, Any]:
        """获取成本统计摘要，包括总调用次数、花费、token 用量及按人格分类的数据。"""
        return {
            "calls": self.calls,
            "spent_usd": self.spent_usd,
            "budget_usd": self.budget_usd,
            "remaining": self.remaining,
            "prompt_tokens": self.total_prompt_tokens,
            "completion_tokens": self.total_completion_tokens,
            "by_personality": dict(self._by_personality),
        }
