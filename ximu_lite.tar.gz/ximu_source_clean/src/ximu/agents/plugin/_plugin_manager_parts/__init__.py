"""插件管理器模块拆分包。

提供用于加载插件管理器相关子模块公开符号的工具函数。
"""
import importlib
import logging
from typing import Any, Dict


def load_part_symbols(part_name: str, module_path: str = "_plugin_manager_parts") -> Dict[str, Any]:
    """加载并聚合特定拆分模块中的公开符号。

    Args:
        part_name: 要加载的子模块名称。
        module_path: 默认拆分包路径，默认为 '_plugin_manager_parts'。

    Returns:
        以符号名为键、符号值为值的字典；若加载失败则返回空字典。
    """
    logger = logging.getLogger(__name__)
    symbols: Dict[str, Any] = {}
    
    try:
        module = importlib.import_module(f".{module_path}.{part_name}")
        for symbol_name in dir(module):
            if not symbol_name.startswith("_"):
                symbols[symbol_name] = getattr(module, symbol_name)
    except ImportError as exc:
        logger.warning("无法加载 %s.%s: %s", module_path, part_name, exc)
    
    return symbols
