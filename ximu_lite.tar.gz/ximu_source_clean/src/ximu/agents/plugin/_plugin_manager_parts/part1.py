"""插件管理器核心模块 (Part 1)。

提供插件的注册、启用/禁用、配置管理、更新、回滚及事件监听功能。
"""
from __future__ import annotations

import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("src.ximu.agents.plugin._plugin_manager_parts.part1")


class PluginManagerState(Enum):
    """插件管理器状态枚举。"""

    RUNNING = "running"
    STOPPED = "stopped"
    MAINTENANCE = "maintenance"
    ERROR = "error"


@dataclass
class PluginConfig:
    """插件配置数据类。"""

    enabled: bool = True
    auto_update: bool = False
    config: Dict[str, Any] = field(default_factory=dict)
    priority: int = 0
    load_on_startup: bool = True


@dataclass
class UpdateInfo:
    """插件更新信息数据类。"""

    plugin_id: str
    current_version: str
    latest_version: str
    changelog: str = ""
    release_notes: str = ""
    breaking_changes: bool = False
    download_url: str = ""
    size_bytes: int = 0
    published_at: float = 0.0


class PluginManager:
    """插件管理器。

    负责插件生命周期管理、配置持久化、更新及回滚。
    """

    def __init__(self, plugin_dir: str = "plugins", config_dir: str = "plugin_configs") -> None:
        """初始化插件管理器。

        Args:
            plugin_dir: 插件文件存储目录。
            config_dir: 配置文件存储目录。
        """
        self._plugin_dir = plugin_dir
        self._config_dir = config_dir
        self._plugins: Dict[str, Dict[str, Any]] = {}
        self._configs: Dict[str, PluginConfig] = {}
        self._state = PluginManagerState.STOPPED
        self._update_history: List[Dict[str, Any]] = []
        self._rollback_points: Dict[str, Dict[str, Any]] = {}
        self._listeners: Dict[str, List[Callable[..., None]]] = {}
        self._manager_id = str(uuid.uuid4())
        self._started_at: Optional[float] = None

    async def start(self) -> None:
        """启动插件管理器。

        设置状态为 RUNNING 并创建配置目录。
        """
        self._state = PluginManagerState.RUNNING
        self._started_at = time.monotonic()
        os.makedirs(self._config_dir, exist_ok=True)
        logger.info("Plugin manager started, id=%s", self._manager_id)

    async def stop(self) -> None:
        """停止插件管理器。

        设置状态为 STOPPED。
        """
        self._state = PluginManagerState.STOPPED
        logger.info("Plugin manager stopped")

    def register(self, plugin_id: str, metadata: Dict[str, Any]) -> None:
        """注册插件。

        Args:
            plugin_id: 插件唯一标识。
            metadata: 插件元数据字典。
        """
        self._plugins[plugin_id] = metadata
        if plugin_id not in self._configs:
            self._configs[plugin_id] = PluginConfig()

    def enable(self, plugin_id: str) -> bool:
        """启用插件。

        Args:
            plugin_id: 插件 ID。

        Returns:
            是否成功启用。
        """
        if plugin_id not in self._configs:
            return False
        self._configs[plugin_id].enabled = True
        self._notify("enable", plugin_id)
        return True

    def disable(self, plugin_id: str) -> bool:
        """禁用插件。

        Args:
            plugin_id: 插件 ID。

        Returns:
            是否成功禁用。
        """
        if plugin_id not in self._configs:
            return False
        self._configs[plugin_id].enabled = False
        self._notify("disable", plugin_id)
        return True

    def is_enabled(self, plugin_id: str) -> bool:
        """检查插件是否启用。

        Args:
            plugin_id: 插件 ID。

        Returns:
            启用状态。
        """
        return self._configs.get(plugin_id, PluginConfig()).enabled

    def get_config(self, plugin_id: str) -> Optional[PluginConfig]:
        """获取插件配置。

        Args:
            plugin_id: 插件 ID。

        Returns:
            PluginConfig 实例或 None。
        """
        return self._configs.get(plugin_id)

    def set_config(self, plugin_id: str, config: Dict[str, Any]) -> None:
        """设置插件配置并持久化。

        Args:
            plugin_id: 插件 ID。
            config: 配置字典。
        """
        if plugin_id not in self._configs:
            self._configs[plugin_id] = PluginConfig()
        self._configs[plugin_id].config.update(config)
        self._save_config(plugin_id)

    def _save_config(self, plugin_id: str) -> None:
        """保存配置到 JSON 文件。

        Args:
            plugin_id: 插件 ID。

        Raises:
            IOError: 写入配置文件失败时抛出。
        """
        path = os.path.join(self._config_dir, f"{plugin_id}.json")
        cfg = self._configs.get(plugin_id, PluginConfig())
        payload = {
            "enabled": cfg.enabled,
            "auto_update": cfg.auto_update,
            "config": cfg.config,
            "priority": cfg.priority,
            "load_on_startup": cfg.load_on_startup,
        }
        try:
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2)
        except OSError as exc:
            logger.error("Failed to save config for %s: %s", plugin_id, exc)
            raise

    def _load_config(self, plugin_id: str) -> None:
        """从 JSON 文件加载配置。

        Args:
            plugin_id: 插件 ID。
        """
        path = os.path.join(self._config_dir, f"{plugin_id}.json")
        if not os.path.exists(path):
            return
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            self._configs[plugin_id] = PluginConfig(**data)
        except (OSError, json.JSONDecodeError, TypeError) as exc:
            logger.warning("Failed to load config for %s: %s", plugin_id, exc)
            self._configs[plugin_id] = PluginConfig()

    async def update(self, plugin_id: str, new_version: str) -> bool:
        """更新插件版本。

        Args:
            plugin_id: 插件 ID。
            new_version: 新版本号。

        Returns:
            是否成功。
        """
        if plugin_id not in self._plugins:
            return False
        old_version = self._plugins[plugin_id].get("version", "unknown")
        self._create_rollback_point(plugin_id, old_version)
        self._plugins[plugin_id]["version"] = new_version
        self._update_history.append({
            "plugin_id": plugin_id,
            "from": old_version,
            "to": new_version,
            "time": time.time(),
        })
        self._notify("update", plugin_id)
        return True

    def _create_rollback_point(self, plugin_id: str, version: str) -> None:
        """创建回滚点。

        Args:
            plugin_id: 插件 ID。
            version: 当前版本号。
        """
        current_cfg = self._configs.get(plugin_id, PluginConfig())
        self._rollback_points[plugin_id] = {
            "version": version,
            "config": dict(current_cfg.config),
            "time": time.time(),
        }

    def rollback(self, plugin_id: str) -> bool:
        """回滚插件到上一个版本。

        Args:
            plugin_id: 插件 ID。

        Returns:
            是否成功回滚。
        """
        point = self._rollback_points.get(plugin_id)
        if point is None:
            return False
        self._plugins[plugin_id]["version"] = point["version"]
        if plugin_id in self._configs:
            self._configs[plugin_id].config = point["config"]
            self._save_config(plugin_id)
        self._notify("rollback", plugin_id)
        return True

    def check_for_updates(self) -> List[UpdateInfo]:
        """检查所有插件的可用更新。

        Returns:
            UpdateInfo 列表。
        """
        updates: List[UpdateInfo] = []
        for pid, meta in self._plugins.items():
            current = meta.get("version", "1.0.0")
            latest = self._fetch_latest_version(pid, current)
            if latest and latest != current:
                updates.append(
                    UpdateInfo(
                        plugin_id=pid,
                        current_version=current,
                        latest_version=latest,
                    )
                )
        return updates

    def _fetch_latest_version(self, plugin_id: str, current: str) -> Optional[str]:
        """查询插件最新版本号（占位实现，实际应调用远程 API）。

        Args:
            plugin_id: 插件 ID。
            current: 当前版本号。

        Returns:
            最新版本号或 None。
        """
        return None

    def list_plugins(self) -> List[str]:
        """列出所有已注册插件 ID。

        Returns:
            插件 ID 列表。
        """
        return list(self._plugins.keys())

    def get_plugin(self, plugin_id: str) -> Optional[Dict[str, Any]]:
        """获取插件元数据。

        Args:
            plugin_id: 插件 ID。

        Returns:
            插件元数据字典或 None。
        """
        return self._plugins.get(plugin_id)

    def remove_plugin(self, plugin_id: str) -> bool:
        """移除插件及其配置。

        Args:
            plugin_id: 插件 ID。

        Returns:
            是否成功移除。
        """
        if plugin_id not in self._plugins:
            return False
        self._plugins.pop(plugin_id, None)
        self._configs.pop(plugin_id, None)
        self._rollback_points.pop(plugin_id, None)
        self._notify("remove", plugin_id)
        return True

    def on(self, event: str, callback: Callable[..., None]) -> None:
        """注册事件监听器。

        Args:
            event: 事件名称。
            callback: 回调函数。
        """
        self._listeners.setdefault(event, []).append(callback)

    def _notify(self, event: str, *args: Any, **kwargs: Any) -> None:
        """通知所有监听指定事件的处理函数。

        Args:
            event: 事件名称。
            *args: 位置参数。
            **kwargs: 关键字参数。
        """
        for cb in self._listeners.get(event, []):
            try:
                cb(*args, **kwargs)
            except Exception as exc:
                logger.warning("Event listener error for %s: %s", event, exc)

    def get_state(self) -> PluginManagerState:
        """获取当前管理器状态。

        Returns:
            当前状态枚举值。
        """
        return self._state

    def get_update_history(self) -> List[Dict[str, Any]]:
        """获取更新历史记录。

        Returns:
            更新历史列表。
        """
        return list(self._update_history)
