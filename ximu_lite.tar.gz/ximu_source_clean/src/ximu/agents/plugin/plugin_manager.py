from __future__ import annotations

import importlib
import logging
import warnings
from typing import Any, Dict, List

logger: logging.Logger = logging.getLogger(__name__)


def _load_module_parts(package_name: str, part_names: List[str]) -> Dict[str, Any]:
    """从模块部分加载并聚合公开符号。

    遍历指定的部分模块列表，导入每个模块并将其公开属性
    （非下划线开头）收集到字典中返回。

    Args:
        package_name: 部分模块的包路径前缀。
        part_names: 需要导入的部分模块名称列表。

    Returns:
        键为符号名、值为对应对象的字典。
    """
    symbols: Dict[str, Any] = {}
    for part_name in part_names:
        module_path = f".{package_name}.{part_name}"
        try:
            module = importlib.import_module(module_path, package=__package__)
            for symbol_name in dir(module):
                if not symbol_name.startswith("_"):
                    symbols[symbol_name] = getattr(module, symbol_name)
        except Exception as exc:
            logger.warning("Failed to load %s: %s", module_path, exc)
    return symbols


def _reexport_all() -> None:
    """执行全部部分模块的重导出并触发弃用警告。

    遍历所有部分模块，依次调用重导出函数，并抛出弃用警告提示
    用户迁移到独立的部分模块导入方式。
    """
    _parts: List[str] = ["part1", "part2"]
    symbols: Dict[str, Any] = _load_module_parts("_plugin_manager_parts", _parts)
    globals().update(symbols)

    warnings.warn(
        "plugin_manager has been split, import from specific part",
        DeprecationWarning,
        stacklevel=2
    )


_reexport_all()
