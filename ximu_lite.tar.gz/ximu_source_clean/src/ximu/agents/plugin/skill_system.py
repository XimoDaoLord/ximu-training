"""扩展方向8: 技能系统模块，支持技能定义、注册、分组与执行。"""
from typing import Any, Dict, List, Optional, Callable, Union
from dataclasses import dataclass, field
from enum import Enum
import asyncio
import time


class SkillStatus(Enum):
    """技能状态枚举"""

    DISABLED = "disabled"
    ENABLED = "enabled"
    ACTIVE = "active"
    ERROR = "error"


@dataclass
class SkillParam:
    """技能参数定义，支持类型校验与默认值"""

    name: str
    type: str = "string"
    required: bool = True
    default: Any = None
    description: str = ""

    def __post_init__(self) -> None:
        """参数校验，确保名称非空且类型合法"""
        if not self.name or not isinstance(self.name, str):
            raise ValueError("SkillParam name must be a non-empty string")
        valid_types = ("string", "int", "float", "bool", "list", "dict", "any")
        if self.type not in valid_types:
            raise ValueError(f"Invalid type '{self.type}', supported: {valid_types}")


@dataclass
class SkillResult:
    """技能执行结果，包含成功标志、数据与错误信息"""

    success: bool
    data: Any = None
    error: str = ""
    execution_time: float = 0.0

    def __post_init__(self) -> None:
        """结果一致性校验"""
        if self.success and self.error:
            raise ValueError("Cannot have both success=True and non-empty error")
        if not self.success and not self.error:
            raise ValueError("Failed result must include error message")


@dataclass
class Skill:
    """技能单元，封装名称、参数、状态与处理器"""

    name: str
    description: str = ""
    version: str = "1.0.0"
    params: List[SkillParam] = field(default_factory=list)
    status: SkillStatus = SkillStatus.ENABLED
    _handler: Optional[Callable] = field(default=None, repr=False)
    _metadata: Dict[str, Any] = field(default_factory=dict, repr=False)

    def __post_init__(self) -> None:
        """初始化校验，确保名称非空"""
        if not self.name or not isinstance(self.name, str):
            raise ValueError("Skill name must be a non-empty string")
        if not self.version:
            self.version = "1.0.0"

    def set_handler(self, handler: Callable) -> None:
        """设置处理器

        Args:
            handler: 同步或异步可调用对象

        Raises:
            TypeError: 若handler不可调用
        """
        if not callable(handler):
            raise TypeError("Handler must be callable")
        self._handler = handler

    async def execute(self, **kwargs: Any) -> SkillResult:
        """执行技能

        Args:
            **kwargs: 传入参数

        Returns:
            执行结果
        """
        start = time.monotonic()
        try:
            if self._handler is None:
                raise ValueError(f"Handler not set for skill: {self.name}")
            result = self._handler(**kwargs)
            if asyncio.iscoroutine(result):
                result = await result
            self.status = SkillStatus.ACTIVE
            return SkillResult(
                success=True, data=result, execution_time=time.monotonic() - start
            )
        except Exception as e:
            self.status = SkillStatus.ERROR
            return SkillResult(
                success=False,
                error=f"{type(e).__name__}: {str(e)}",
                execution_time=time.monotonic() - start,
            )


class SkillRegistry:
    """技能注册表，支持注册、注销、分组与批量执行"""

    def __init__(self) -> None:
        """初始化注册表"""
        self._skills: Dict[str, Skill] = {}
        self._groups: Dict[str, List[str]] = {}
        self._cache: List[Dict[str, Any]] = []
        self._dirty: bool = True

    def register(self, skill: Skill) -> None:
        """注册技能

        Args:
            skill: Skill实例

        Raises:
            TypeError: 若传入非Skill实例
        """
        if not isinstance(skill, Skill):
            raise TypeError("Expected Skill instance")
        self._skills[skill.name] = skill
        self._dirty = True

    def unregister(self, name: str) -> bool:
        """注销技能

        Args:
            name: 技能名称

        Returns:
            是否成功注销
        """
        if name in self._skills:
            del self._skills[name]
            self._dirty = True
            return True
        return False

    def get(self, name: str) -> Optional[Skill]:
        """获取技能

        Args:
            name: 技能名称

        Returns:
            Skill实例或None
        """
        return self._skills.get(name)

    def list_skills(self, group: Optional[str] = None) -> List[Dict[str, Any]]:
        """列出技能

        Args:
            group: 可选分组名

        Returns:
            技能字典列表
        """
        if group is None and not self._dirty:
            return list(self._cache)
        skills = list(self._skills.values())
        if group is not None:
            members = set(self._groups.get(group, []))
            skills = [s for s in skills if s.name in members]
        result = [
            {
                "name": s.name,
                "description": s.description,
                "version": s.version,
                "status": s.status.value,
                "params": [p.__dict__ for p in s.params],
            }
            for s in skills
        ]
        if group is None:
            self._cache = result
            self._dirty = False
        return result

    def group(self, group_name: str, *skill_names: str) -> None:
        """创建分组

        Args:
            group_name: 组名
            *skill_names: 成员技能名称
        """
        self._groups[group_name] = list(skill_names)
        self._dirty = True

    async def execute_group(self, group_name: str, **kwargs: Any) -> List[SkillResult]:
        """顺序执行分组内所有技能

        Args:
            group_name: 组名
            **kwargs: 传递给每个技能的参数

        Returns:
            结果列表，缺失技能跳过
        """
        results: List[SkillResult] = []
        for name in self._groups.get(group_name, []):
            skill = self._skills.get(name)
            if skill is not None:
                results.append(await skill.execute(**kwargs))
        return results
