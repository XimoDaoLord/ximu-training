"""
数据库操作模块
提供用户认证相关的数据库操作接口
"""

import logging
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Optional, Generator, Any

from sqlalchemy import create_engine, Column, Integer, String, DateTime, Boolean, Text, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, Session
from sqlalchemy.exc import SQLAlchemyError

from auth_schema import User, RefreshToken, LoginAttempt, PasswordReset, UserRole, TokenType

# 版本号
__version__ = "0.5"

logger = logging.getLogger(__name__)

# 确保默认使用UTC时区
def _utc_now() -> datetime:
    """返回当前UTC时间"""
    return datetime.now(timezone.utc)

Base = declarative_base()


class UserModel(Base):
    """用户表模型"""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    salt = Column(String(64), nullable=False)
    role = Column(String(20), nullable=False, default=UserRole.USER.value)
    is_active = Column(Boolean, nullable=False, default=True)
    is_verified = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime, nullable=False, default=_utc_now)
    updated_at = Column(DateTime, nullable=False, default=_utc_now, onupdate=_utc_now)
    last_login = Column(DateTime, nullable=True)
    failed_login_attempts = Column(Integer, nullable=False, default=0)
    locked_until = Column(DateTime, nullable=True)
    
    # 关系
    refresh_tokens = relationship("RefreshTokenModel", back_populates="user")
    login_attempts = relationship("LoginAttemptModel", back_populates="user")
    password_resets = relationship("PasswordResetModel", back_populates="user")


class RefreshTokenModel(Base):
    """刷新令牌表模型"""
    __tablename__ = 'refresh_tokens'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    token_hash = Column(String(64), nullable=False, unique=True)
    token_type = Column(String(20), nullable=False, default=TokenType.REFRESH.value)
    expires_at = Column(DateTime, nullable=False)
    is_revoked = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime, nullable=False, default=_utc_now)
    used_at = Column(DateTime, nullable=True)
    
    # 关系
    user = relationship("UserModel", back_populates="refresh_tokens")


class LoginAttemptModel(Base):
    """登录尝试记录表模型"""
    __tablename__ = 'login_attempts'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    username = Column(String(50), nullable=False)
    ip_address = Column(String(45), nullable=False)  # IPv6地址最长45字符
    user_agent = Column(Text, nullable=True)
    success = Column(Boolean, nullable=False)
    created_at = Column(DateTime, nullable=False, default=_utc_now)
    
    # 关系
    user = relationship("UserModel", back_populates="login_attempts")


class PasswordResetModel(Base):
    """密码重置表模型"""
    __tablename__ = 'password_resets'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    token_hash = Column(String(64), nullable=False, unique=True)
    expires_at = Column(DateTime, nullable=False)
    is_used = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime, nullable=False, default=_utc_now)
    
    # 关系
    user = relationship("UserModel", back_populates="password_resets")


class DatabaseManager:
    """数据库管理器，负责连接池和会话管理"""
    
    def __init__(self, database_url: str) -> None:
        """初始化数据库管理器
        
        Args:
            database_url: 数据库连接字符串
        """
        self.database_url = database_url
        self.engine = create_engine(
            database_url,
            pool_pre_ping=True,  # 自动断开失效连接
            pool_recycle=3600,   # 1小时回收连接
            echo=False,          # 生产环境关闭SQL日志
            pool_size=20,        # 默认连接池大小
            max_overflow=10      # 最大溢出连接数
        )
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
        
        # 创建表
        self._create_tables()
        
    def _create_tables(self) -> None:
        """创建数据库表"""
        try:
            Base.metadata.create_all(bind=self.engine)
            logger.info("Database tables created successfully")
        except SQLAlchemyError as e:
            logger.error(f"Failed to create database tables: {e}")
            raise

    @contextmanager
    def get_session(self) -> Generator[Session, None, None]:
        """获取数据库会话上下文管理器
        
        Yields:
            Session: SQLAlchemy会话对象
        """
        session = self.SessionLocal()
        try:
            yield session
        finally:
            session.close()

    def close_session(self, session: Session) -> None:
        """关闭数据库会话
        
        Args:
            session: 需要关闭的会话对象
        """
        try:
            session.close()
        except SQLAlchemyError as e:
            logger.error(f"Failed to close database session: {e}")


class UserRepository:
    """用户数据访问层"""
    
    def __init__(self, db_manager: DatabaseManager) -> None:
        """初始化用户仓库
        
        Args:
            db_manager: 数据库管理器实例
        """
        self.db_manager = db_manager
        
    def _query_user(self, filter_func: callable) -> Optional[UserModel]:
        """内部方法：执行用户查询
        
        Args:
            filter_func: 过滤函数，接收UserModel类作为参数
            
        Returns:
            用户模型或None
        """
        with self.db_manager.get_session() as session:
            return session.query(UserModel).filter(
                UserModel.is_active == True
            ).filter(filter_func).first()

    def get_user_by_username(self, username: str) -> Optional[User]:
        """根据用户名查找用户
        
        Args:
            username: 用户名
            
        Returns:
            用户领域对象或None
        """
        user_model = self._query_user(lambda u: u.username == username)
        if user_model:
            return self._model_to_domain(user_model)
        return None

    def get_user_by_email(self, email: str) -> Optional[User]:
        """根据邮箱查找用户
        
        Args:
            email: 邮箱地址
            
        Returns:
            用户领域对象或None
        """
        user_model = self._query_user(lambda u: u.email == email)
        if user_model:
            return self._model_to_domain(user_model)
        return None

    def get_user_by_id(self, user_id: int) -> Optional[User]:
        """根据ID查找用户
        
        Args:
            user_id: 用户ID
            
        Returns:
            用户领域对象或None
        """
        user_model = self._query_user(lambda u: u.id == user_id)
        if user_model:
            return self._model_to_domain(user_model)
        return None

    def create_user(self, username: str, email: str, password_hash: str, 
                   salt: str, role: UserRole = UserRole.USER) -> User:
        """创建新用户
        
        Args:
            username: 用户名
            email: 邮箱地址
            password_hash: 密码哈希值
            salt: 盐值
            role: 用户角色
            
        Returns:
            创建的用户领域对象
            
        Raises:
            SQLAlchemyError: 数据库操作失败时抛出
        """
        with self.db_manager.get_session() as session:
            try:
                user_model = UserModel(
                    username=username,
                    email=email,
                    password_hash=password_hash,
                    salt=salt,
                    role=role.value,
                    is_active=True,
                    is_verified=False,
                    created_at=_utc_now(),
                    updated_at=_utc_now()
                )
                
                session.add(user_model)
                session.commit()
                session.refresh(user_model)
                
                logger.info(f"User {username} created successfully")
                return self._model_to_domain(user_model)
            except SQLAlchemyError as e:
                session.rollback()
                logger.error(f"Failed to create user {username}: {e}")
                raise

    def update_user(self, user_id: int, **kwargs) -> Optional[User]:
        """更新用户信息
        
        Args:
            user_id: 用户ID
            **kwargs: 要更新的字段和值
            
        Returns:
            更新后的用户领域对象或None
        """
        allowed_fields = {
            'username', 'email', 'password_hash', 'salt', 'role',
            'is_active', 'is_verified', 'last_login',
            'failed_login_attempts', 'locked_until'
        }
        
        with self.db_manager.get_session() as session:
            try:
                user_model = session.query(UserModel).filter(UserModel.id == user_id).first()
                
                if not user_model:
                    logger.warning(f"User {user_id} not found for update")
                    return None
                
                # 更新允许的字段
                for key, value in kwargs.items():
                    if key in allowed_fields and hasattr(user_model, key):
                        setattr(user_model, key, value)
                    
                user_model.updated_at = _utc_now()
                session.commit()
                session.refresh(user_model)
                
                logger.info(f"User {user_id} updated successfully")
                return self._model_to_domain(user_model)
            except SQLAlchemyError as e:
                session.rollback()
                logger.error(f"Failed to update user {user_id}: {e}")
                raise

    def _model_to_domain(self, user_model: UserModel) -> User:
        """将数据库模型转换为领域对象
        
        Args:
            user_model: 用户数据库模型
            
        Returns:
            用户领域对象
        """
        return User(
            id=user_model.id,
            username=user_model.username,
            email=user_model.email,
            password_hash=user_model.password_hash,
            salt=user_model.salt,
            role=UserRole(user_model.role),
            is_active=user_model.is_active,
            is_verified=user_model.is_verified,
            created_at=user_model.created_at,
            updated_at=user_model.updated_at,
            last_login=user_model.last_login,
            failed_login_attempts=user_model.failed_login_attempts,
            locked_until=user_model.locked_until
        )


class RefreshTokenRepository:
    """刷新令牌数据访问层"""
    
    def __init__(self, db_manager: DatabaseManager) -> None:
        """初始化刷新令牌仓库
        
        Args:
            db_manager: 数据库管理器实例
        """
        self.db_manager = db_manager
    
    def create_refresh_token(self, user_id: int, token_hash: str, 
                           expires_at: datetime) -> RefreshToken:
        """创建刷新令牌
        
        Args:
            user_id: 用户ID
            token_hash: 令牌哈希值
            expires_at: 过期时间
            
        Returns:
            创建的刷新令牌领域对象
            
        Raises:
            SQLAlchemyError: 数据库操作失败时抛出
        """
        with self.db_manager.get_session() as session:
            try:
                token_model = RefreshTokenModel(
                    user_id=user_id,
                    token_hash=token_hash,
                    token_type=TokenType.REFRESH.value,
                    expires_at=expires_at,
                    is_revoked=False,
                    created_at=_utc_now()
                )
                
                session.add(token_model)
                session.commit()
                session.refresh(token_model)
                
                logger.info(f"Refresh token created for user {user_id}")
                return self._model_to_domain(token_model)
            except SQLAlchemyError as e:
                session.rollback()
                logger.error(f"Failed to create refresh token for user {user_id}: {e}")
                raise
    
    def revoke_refresh_token(self, token_hash: str) -> bool:
        """撤销刷新令牌
        
        Args:
            token_hash: 令牌哈希值
            
        Returns:
            撤销成功返回True，令牌不存在返回False
        """
        with self.db_manager.get_session() as session:
            try:
                token_model = session.query(RefreshTokenModel).filter(
                    RefreshTokenModel.token_hash == token_hash
                ).first()
                
                if token_model:
                    token_model.is_revoked = True
                    session.commit()
                    logger.info(f"Refresh token revoked: {token_hash[:16]}...")
                    return True
                else:
                    logger.warning(f"Refresh token not found for revocation: {token_hash[:16]}...")
                    return False
            except SQLAlchemyError as e:
                session.rollback()
                logger.error(f"Failed to revoke refresh token {token_hash[:16]}...: {e}")
                raise
