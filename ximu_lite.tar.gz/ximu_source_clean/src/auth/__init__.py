"""汐沫AI认证系统模块。

提供完整的用户认证功能：登录、注册、Token管理、安全防护。
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .login_api import create_login_routes, LoginService
    from .database import DatabaseManager, UserRepository, RefreshTokenRepository
    from auth_schema import (
        User,
        RefreshToken,
        LoginAttempt,
        PasswordReset,
        AuthConfig,
        AuthResponse,
        AuthError,
        UserRole,
        TokenType,
    )
    from auth_utils import (
        PasswordHasher,
        TokenManager,
        SecurityUtils,
        RateLimiter,
    )

__version__: str = "1.0.0"
__author__: str = "汐沫AI开发团队"

__all__: List[str] = [
    # 核心类
    "LoginService",
    "DatabaseManager",
    "UserRepository",
    "RefreshTokenRepository",
    # 数据模型
    "User",
    "RefreshToken",
    "LoginAttempt",
    "PasswordReset",
    # 配置和响应
    "AuthConfig",
    "AuthResponse",
    "AuthError",
    # 枚举
    "UserRole",
    "TokenType",
    # 工具类
    "PasswordHasher",
    "TokenManager",
    "SecurityUtils",
    "RateLimiter",
    # 路由创建函数
    "create_login_routes",
]
