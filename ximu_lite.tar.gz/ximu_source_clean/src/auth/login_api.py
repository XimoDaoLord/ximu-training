"""
登录API实现
包含完整的登录流程：凭证校验、用户查询、登录态管理、安全防护
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple
from flask import request, jsonify
from auth_schema import (
    User,
    RefreshToken,
    LoginAttempt,
    AuthConfig,
    AuthResponse,
    AuthError,
    UserRole,
    TokenType,
)
from auth_utils import (
    PasswordHasher,
    TokenManager,
    SecurityUtils,
    RateLimiter,
)

logger = logging.getLogger(__name__)

class LoginService:
    """
    登录服务类
    """

    def __init__(self, db_session):
        """
        初始化登录服务类

        Args:
            db_session: 数据库会话
        """
        self.db = db_session
        self.token_manager = TokenManager()
        self.rate_limiter = RateLimiter(
            max_attempts=AuthConfig.MAX_LOGIN_ATTEMPTS,
            time_window=AuthConfig.ACCOUNT_LOCK_MINUTES * 60,
        )

    def login(
        self,
        username: str,
        password: str,
        ip_address: str,
        user_agent: str,
    ) -> Tuple[Dict, int]:
        """
        用户登录

        Args:
            username: 用户名
            password: 密码
            ip_address: IP地址
            user_agent: 用户代理

        Returns:
            Tuple[response_dict, status_code]
        """
        try:
            # 输入验证和清理
            username = SecurityUtils.sanitize_input(username)
            password = SecurityUtils.sanitize_input(password)

            if not SecurityUtils.validate_input_length(
                username, 3, 50, "username"
            ):
                return AuthError.invalid_credentials(), 400

            if not SecurityUtils.validate_input_length(
                password, 8, 128, "password"
            ):
                return AuthError.invalid_credentials(), 400

            # 频率限制检查
            if not self.rate_limiter.is_allowed(f"login:{ip_address}"):
                return AuthError.rate_limit_exceeded(), 429

            # 查找用户
            user = self._get_user_by_username(username)

            if not user:
                # 记录失败的登录尝试
                self._record_login_attempt(
                    None, username, ip_address, user_agent, False
                )
                return AuthError.invalid_credentials(), 401

            # 检查账户状态
            if not user.is_active:
                return AuthError.invalid_credentials(), 401

            # 检查账户锁定状态
            if SecurityUtils.is_account_locked(user):
                return AuthError.account_locked(), 423

            # 验证密码
            if not PasswordHasher.verify_password(
                password, user.password_hash, user.salt
            ):
                # 更新失败登录次数
                self._update_failed_login_attempts(user)
                self._record_login_attempt(
                    user.id, username, ip_address, user_agent, False
                )
                return AuthError.invalid_credentials(), 401

            # 登录成功处理
            return self._handle_successful_login(user, ip_address, user_agent)

        except Exception as e:
            logger.error(f"Login error for user {username}: {str(e)}")
            return {
                "success": False,
                "error": "INTERNAL_ERROR",
                "message": "Internal server error",
                "status": 500,
            }, 500

    def _get_user_by_username(self, username: str) -> Optional[User]:
        """
        根据用户名查找用户

        Args:
            username: 用户名

        Returns:
            Optional[User]
        """
        try:
            # 模拟数据库查询
            # user = self.db.query(User).filter(User.username == username).first()
            # return user
            return None  # 临时返回None，实际项目中需要实现真实的查询
        except Exception as e:
            logger.error(f"Database error while fetching user {username}: {str(e)}")
            return None

    def _record_login_attempt(
        self,
        user_id: Optional[int],
        username: str,
        ip_address: str,
        user_agent: str,
        success: bool,
    ):
        """
        记录登录尝试

        Args:
            user_id: 用户ID
            username: 用户名
            ip_address: IP地址
            user_agent: 用户代理
            success: 是否登录成功
        """
        try:
            login_attempt = LoginAttempt(
                id=0,  # 数据库会自动生成ID
                user_id=user_id,
                username=username,
                ip_address=ip_address,
                user_agent=user_agent,
                success=success,
                created_at=datetime.utcnow(),
            )
            # 这里应该是实际的数据库插入操作
            # self.db.add(login_attempt)
            # self.db.commit()
        except Exception as e:
            logger.error(f"Failed to record login attempt: {str(e)}")

    def _update_failed_login_attempts(self, user: User):
        """
        更新失败登录次数

        Args:
            user: 用户
        """
        try:
            user.failed_login_attempts += 1
            # 检查是否需要锁定账户
            if user.failed_login_attempts >= AuthConfig.MAX_LOGIN_ATTEMPTS:
                user.locked_until = datetime.utcnow() + timedelta(
                    minutes=AuthConfig.ACCOUNT_LOCK_MINUTES
                )
            # 这里应该是实际的数据库更新操作
            # self.db.commit()
        except Exception as e:
            logger.error(f"Failed to update failed login attempts: {str(e)}")

    def _handle_successful_login(
        self, user: User, ip_address: str, user_agent: str
    ) -> Tuple[Dict, int]:
        """
        处理成功的登录

        Args:
            user: 用户
            ip_address: IP地址
            user_agent: 用户代理

        Returns:
            Tuple[response_dict, status_code]
        """
        try:
            # 重置失败登录次数
            user.failed_login_attempts = 0
            user.locked_until = None
            user.last_login = datetime.utcnow()

            # 生成Token
            access_token = self.token_manager.create_access_token(user.id)
            refresh_token = self.token_manager.create_refresh_token(
                user.id, SecurityUtils.generate_token_hash(refresh_token)
            )

            # 记录成功的登录尝试
            self._record_login_attempt(
                user.id, user.username, ip_address, user_agent, True
            )

            # 这里应该是实际的数据库更新操作
            # self.db.commit()

            logger.info(f"User {user.username} logged in successfully from {ip_address}")
            return AuthResponse.login_success(user, access_token, refresh_token), 200

        except Exception as e:
            logger.error(f"Failed to handle successful login for user {user.username}: {str(e)}")
            return {
                "success": False,
                "error": "INTERNAL_ERROR",
                "message": "Failed to generate authentication tokens",
                "status": 500,
            }, 500

def create_login_routes(app, db_session):
    """
    创建登录路由

    Args:
        app: Flask应用
        db_session: 数据库会话
    """
    login_service = LoginService(db_session)

    @app.route("/api/auth/login", methods=["POST"])
    def login():
        """
        登录接口
        """
        try:
            # 获取请求数据
            data = request.get_json()

            if not data:
                return jsonify(
                    {
                        "success": False,
                        "error": "INVALID_REQUEST",
                        "message": "Request body is required",
                        "status": 400,
                    }
                ), 400

            # 验证必需字段
            required_fields = ["username", "password"]
            missing_fields = [
                field for field in required_fields if field not in data
            ]

            if missing_fields:
                return jsonify(
                    {
                        "success": False,
                        "error": "MISSING_FIELDS",
                        "message": f"Missing required fields: {', '.join(missing_fields)}",
                        "status": 400,
                    }
                ), 400

            # 获取客户端信息
            username = data.get("username")
            password = data.get("password")
            ip_address = request.remote_addr
            user_agent = request.headers.get("User-Agent", "")

            # 执行登录
            response, status_code = login_service.login(username, password, ip_address, user_agent)
            return jsonify(response), status_code

        except Exception as e:
            logger.error(f"Login route error: {str(e)}")
            return jsonify(
                {
                    "success": False,
                    "error": "INTERNAL_ERROR",
                    "message": "Internal server error",
                    "status": 500,
                }
            ), 500

    @app.route("/api/auth/refresh", methods=["POST"])
    def refresh_token():
        """
        刷新Token接口
        """
        try:
            # 获取请求数据
            data = request.get_json()

            if not data or "refresh_token" not in data:
                return jsonify(
                    {
                        "success": False,
                        "error": "MISSING_TOKEN",
                        "message": "Refresh token is required",
                        "status": 400,
                    }
                ), 400

            # 验证刷新令牌
            refresh_token = data.get("refresh_token")
            try:
                # 验证刷新令牌
                payload = login_service.token_manager.verify_token(
                    refresh_token, TokenType.REFRESH
                )
                user_id = int(payload.get("sub"))

                # 这里应该验证refresh_token是否在数据库中存在且未被撤销
                # refresh_token_db = login_service.db.query(RefreshToken).filter(
                #     RefreshToken.user_id == user_id,
                #     RefreshToken.token_hash == payload.get("hash"),
                #     RefreshToken.is_revoked == False,
                # ).first()

                # if not refresh_token_db:
                #     return AuthError.invalid_token(), 401

                # 生成新的访问令牌
                new_access_token = login_service.token_manager.create_access_token(user_id)
                return jsonify(AuthResponse.token_refresh_success(new_access_token)), 200

            except Exception as e:
                logger.error(f"Token refresh error: {str(e)}")
                return AuthError.invalid_token(), 401

        except Exception as e:
            logger.error(f"Refresh token route error: {str(e)}")
            return jsonify(
                {
                    "success": False,
                    "error": "INTERNAL_ERROR",
                    "message": "Internal server error",
                    "status": 500,
                }
            ), 500

        return app
