"""基础问候模块。

用于测试的最小化示例。
"""


def hello_world() -> None:
    """向标准输出打印 'hello world'。"""
    print("hello world")


if __name__ == "__main__":
    hello_world()
