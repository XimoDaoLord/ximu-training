"""
汐沫AI - 核心包。

提供配置管理基础功能。
"""

import json
import logging
from typing import Dict, Optional

logger: logging.Logger = logging.getLogger(__name__)


class ConfigManager:
    """管理配置文件的单例类。"""
    _instance: Optional["ConfigManager"] = None

    def __init__(self, config_path: str) -> None:
        """初始化配置管理器。

        Args:
            config_path: 配置文件路径。
        """
        self.config_path: str = config_path
        self.config: Optional[Dict[str, object]] = self._load_config()

    def _load_config(self) -> Optional[Dict[str, object]]:
        """从指定路径加载JSON配置。

        Returns:
            配置字典，若加载失败则返回None。
        """
        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                raise ValueError("配置文件根节点必须为字典类型")
            return data
        except (FileNotFoundError, json.JSONDecodeError, ValueError) as e:
            logger.error("配置文件加载失败: %s", e)
            return None

    def get_db_config(self) -> Optional[Dict[str, object]]:
        """获取数据库配置子树。

        Returns:
            数据库配置字典，若不存在或格式错误则返回None。
        """
        if self.config is None:
            return None
        db_config = self.config.get("database")
        return db_config if isinstance(db_config, dict) else None

    @staticmethod
    def validate_config(config: Dict[str, object]) -> bool:
        """验证配置字典是否包含所有必需字段。

        Args:
            config: 待验证的配置字典。

        Returns:
            若所有必需字段存在且非空则返回True，否则False。
        """
        required_keys: list[str] = ["host", "port", "user"]
        return all(config.get(key) is not None for key in required_keys)