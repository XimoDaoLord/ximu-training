# -*- coding: utf-8 -*-
"""数据模型聚合模块。

统一管理所有数据模型类的导入，提供便捷访问接口。
当前为占位实现，待具体模型类完成后补充导入。
"""
from __future__ import annotations


# 按需导入具体模型模块
# from .user import User


class Model:
    """数据模型基类占位，用于统一类型标识。

    后续可扩展字段校验、序列化等公共逻辑。
    """

    pass


__all__: list[str] = ["Model"]