# -*- coding: utf-8 -*-
"""排序算法模块。

提供基于快速排序算法的实现，包含完整的类型注解和文档说明，
适用于数据处理任务中的列表排序需求。
"""
from __future__ import annotations

from typing import Any, Callable, List, TypeVar

T = TypeVar("T")


def quick_sort(arr: List[T], key: Callable[[T], Any] | None = None) -> List[T]:
    """使用快速排序算法对列表进行排序。

    基于分治策略实现，返回一个新的已排序列表。
    支持自定义排序键函数。

    Args:
        arr: 待排序的列表。
        key: 可选的排序键函数，用于自定义排序顺序。

    Returns:
        排序后的新列表，原列表不被修改。
    """
    if len(arr) <= 1:
        return arr[:]

    pivot: T = arr[len(arr) // 2]
    key_func: Callable[[T], Any] = key if key is not None else (lambda x: x)

    left: List[T] = [x for x in arr if key_func(x) < key_func(pivot)]
    middle: List[T] = [x for x in arr if key_func(x) == key_func(pivot)]
    right: List[T] = [x for x in arr if key_func(x) > key_func(pivot)]

    return quick_sort(left, key) + middle + quick_sort(right, key)


def sort_by_key(arr: List[T], key_func: Callable[[T], Any]) -> List[T]:
    """使用自定义键函数对列表进行排序。

    是对quick_sort的便捷封装，用于简化按特定键排序的调用。

    Args:
        arr: 待排序的列表。
        key_func: 用于确定排序顺序的键函数。

    Returns:
        按指定键排序后的新列表。
    """
    return quick_sort(arr, key=key_func)
