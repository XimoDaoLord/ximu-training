"""
汐沫AI - 基础问候模块。

提供简单的用户交互入口功能。
"""


def greet(message: str = "hello") -> None:
    """向用户输出问候信息。

    Args:
        message: 自定义问候语，默认为"hello"。
    """
    print(message)
