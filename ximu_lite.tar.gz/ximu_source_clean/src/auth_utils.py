from __future__ import annotations

import importlib.util
import logging
import os
from typing import Any, Optional, Type

import bcrypt

logger: logging.Logger = logging.getLogger(__name__)

try:
    from models import User
except ImportError:
    User = None


def hash_password(password: str) -> bytes:
    """使用 bcrypt 对密码进行加盐哈希。"""
    if not password:
        raise ValueError("密码不能为空")
    salt: bytes = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode("utf-8"), salt)


def verify_password(hashed_password: bytes, user_password: str) -> bool:
    """校验明文密码与存储的哈希是否匹配。"""
    if not hashed_password or not user_password:
        raise ValueError("密码参数不能为空")
    return bcrypt.checkpw(user_password.encode("utf-8"), hashed_password)


def get_user_by_username(username: str) -> Optional[Any]:
    """根据用户名获取用户对象。"""
    if User is None:
        logger.warning("User 模型不可用，无法执行用户查询")
        return None
    return User.query.filter_by(username=username).first()  # type: ignore[union-attr]


def authenticate_user(username: str, password: str) -> Optional[Any]:
    """执行用户认证，支持新用户自动注册。"""
    if not username or not password:
        raise ValueError("用户名和密码不能为空")

    if User is None:
        logger.error("User 模型不可用，无法完成认证")
        return None

    user: Optional[Any] = get_user_by_username(username)
    if user is not None and verify_password(user.password_hash, password):  # type: ignore[union-attr]
        return user

    hashed_password: bytes = hash_password(password)
    new_user: Any = User(username=username, password_hash=hashed_password)  # type: ignore[call-arg]
    new_user.save()
    logger.info("新用户注册: %s", username)
    return new_user


def _load_root_auth_utils() -> None:
    """从根目录加载认证工具扩展类。"""
    root_path: str = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "auth_utils.py",
    )

    if not os.path.exists(root_path):
        logger.debug("根目录 auth_utils.py 不存在，跳过扩展加载")
        return

    spec: Optional[Any] = importlib.util.spec_from_file_location("_root_auth_utils", root_path)
    if spec is None or spec.loader is None:
        logger.warning("无法解析根 auth_utils 模块规范")
        return

    module: Any = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except Exception as exc:
        logger.warning("加载根 auth_utils 失败: %s", exc)
        return

    class_map: dict[str, Any] = {
        "PasswordHasher": getattr(module, "PasswordHasher", None),
        "TokenManager": getattr(module, "TokenManager", None),
        "SecurityUtils": getattr(module, "SecurityUtils", None),
        "RateLimiter": getattr(module, "RateLimiter", None),
    }
    globals().update({k: v for k, v in class_map.items() if v is not None})
    logger.debug("兼容层加载完成")


_load_root_auth_utils()