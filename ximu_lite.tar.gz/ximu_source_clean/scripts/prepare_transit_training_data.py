#!/usr/bin/env python3
"""中转三合一模型训练数据预处理脚本（知识蒸馏版）。

从 data/training_data/train_*.jsonl 读取原始数据，
生成三类训练样本并用BGE-m3预计算向量蒸馏目标：

  分类任务:  "分类: " + input  ->  task_type        (seq2seq CE损失)
  提纯任务:  "提纯: " + input  ->  output           (seq2seq CE损失)
  向量任务:  "向量: " + input  ->  BGE(output)向量  (MSE蒸馏损失)

输出:
  data/transit_training/train.jsonl
  data/transit_training/val.jsonl
每行字段: input_text, target_text, task, vector_target(仅向量任务, list[float]1024)
"""
import json
import glob
import os
import random
import sys

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW_DATA_DIR = os.path.join(PROJECT_ROOT, "data", "training_data")
OUTPUT_DIR = os.path.join(PROJECT_ROOT, "data", "transit_training")
BGE_PATH = os.path.join(PROJECT_ROOT, "data", "用户数据", "本地模型", "bge-m3")

PREFIX_CLASSIFY = "分类: "
PREFIX_PURIFY = "提纯: "
PREFIX_VECTOR = "向量: "

SEED = 42
VAL_RATIO = 0.1
MAX_INPUT_CHARS = 1024
MAX_OUTPUT_CHARS = 512
VECTOR_DIM = 1024
BGE_BATCH = 32  # BGE编码批大小(防内存溢出)

# 向量库(干净数据BGE向量)与干净数据文本路径
VEC_LIB_DIR = os.path.join(PROJECT_ROOT, "data", "vectors", "core")
CLEAN_TEXT_DIR = os.path.join(PROJECT_ROOT, "data", "用户数据", "干净数据")


def load_raw_samples():
    """读取所有 train_*.jsonl，返回原始样本列表。"""
    pattern = os.path.join(RAW_DATA_DIR, "train_*.jsonl")
    files = sorted(glob.glob(pattern))
    if not files:
        print(f"[ERROR] 未找到训练数据: {pattern}", file=sys.stderr)
        sys.exit(1)
    samples = []
    for fp in files:
        with open(fp, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not all(k in obj for k in ("task_type", "input", "output")):
                    continue
                samples.append(obj)
    print(f"[INFO] 读取 {len(files)} 个文件, 共 {len(samples)} 条有效样本")
    return samples


def truncate(text, max_chars):
    if not text:
        return ""
    return text


def encode_vectors_with_bge(texts):
    """用BGE-m3批量编码文本为1024维归一化向量。

    返回 list[list[float]]，与texts等长。
    """
    import torch
    from sentence_transformers import SentenceTransformer

    print(f"[INFO] 加载BGE-m3: {BGE_PATH}")
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = SentenceTransformer(BGE_PATH, device=device)
    print(f"[INFO] BGE-m3 已加载, 设备={device}, 编码 {len(texts)} 条...")

    vectors = model.encode(
        texts,
        batch_size=BGE_BATCH,
        show_progress_bar=True,
        normalize_embeddings=True,  # L2归一化, 余弦相似度内积即可
        convert_to_numpy=True,
    )
    # numpy -> list[list[float]]，便于JSON序列化
    result = vectors.tolist()
    print(f"[INFO] BGE编码完成, 向量维度={len(result[0])}")
    # 释放显存/内存
    del model
    if device == "cuda":
        torch.cuda.empty_cache()
    return result


def build_samples(raw, bge_vectors):
    """将原始样本+BGE向量转换为三类训练样本。

    bge_vectors[i] 对应 raw[i] 的 output 文本向量(1024维)。
    返回 list[dict]: {input_text, target_text, task, vector_target}
    """
    samples = []
    for obj, vec in zip(raw, bge_vectors):
        task_type = obj["task_type"].strip()
        inp = truncate(obj["input"].strip(), MAX_INPUT_CHARS)
        out = truncate(obj["output"].strip(), MAX_OUTPUT_CHARS)
        if not inp or not out or not task_type:
            continue
        # 1) 分类: 输出task_type
        samples.append({
            "input_text": PREFIX_CLASSIFY + inp,
            "target_text": task_type,
            "task": "classify",
            "vector_target": None,
        })
        # 2) 提纯: 输出提纯文本
        samples.append({
            "input_text": PREFIX_PURIFY + inp,
            "target_text": out,
            "task": "purify",
            "vector_target": None,
        })
        # 3) 向量: 目标是BGE编码的向量(MSE蒸馏)
        samples.append({
            "input_text": PREFIX_VECTOR + inp,
            "target_text": out,  # 保留文本仅作参考/评估,训练时用vector_target
            "task": "vector",
            "vector_target": vec,
        })
    print(f"[INFO] 生成 {len(samples)} 条训练样本 (原始 {len(raw)} 条)")
    return samples


def load_vector_library_pairs():
    """从向量库+干净数据文本恢复(文本, BGE向量)对, 用于扩展蒸馏。

    返回 list[dict]: {input_text, target_text, task="vector", vector_target}
    仅含alive向量, 通过task_id整数关联。
    """
    import numpy as np

    npy_path = os.path.join(VEC_LIB_DIR, "clean_data.vectors.npy")
    json_path = os.path.join(VEC_LIB_DIR, "clean_data.json")
    alive_path = os.path.join(VEC_LIB_DIR, "clean_data.alive.npy")
    if not (os.path.exists(npy_path) and os.path.exists(json_path)):
        print("[WARN] 向量库不存在, 跳过向量库扩展蒸馏")
        return []

    vectors = np.load(npy_path)
    meta = json.load(open(json_path, "r", encoding="utf-8"))
    alive = np.load(alive_path) if os.path.exists(alive_path) else \
        np.ones(len(vectors), dtype=bool)

    # task_id整数 -> row_idx (仅alive)
    tid2row = {}
    for vid, row_idx in meta.get("id2vid", {}).items():
        parts = vid.split("_")
        try:
            n = int(parts[1])
            if alive[row_idx]:
                tid2row[n] = row_idx
        except (IndexError, ValueError):
            continue

    # 加载干净数据文本, join出(文本,向量)对
    pairs = []
    seen_tid = set()
    clean_files = sorted(glob.glob(os.path.join(CLEAN_TEXT_DIR, "clean_*.jsonl")))
    for fp in clean_files:
        with open(fp, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                tid = rec.get("task_id", "")
                try:
                    n = int(tid.split("_")[1])
                except (IndexError, ValueError):
                    continue
                if n not in tid2row or n in seen_tid:
                    continue
                seen_tid.add(n)
                vec = vectors[tid2row[n]].tolist()
                inp = truncate(str(rec.get("input", "")).strip(), MAX_INPUT_CHARS)
                out = truncate(str(rec.get("output", "")).strip(), MAX_OUTPUT_CHARS)
                if not inp or not out:
                    continue
                pairs.append({
                    "input_text": PREFIX_VECTOR + inp,
                    "target_text": out,
                    "task": "vector",
                    "vector_target": vec,
                })
    print(f"[INFO] 向量库扩展蒸馏对: {len(pairs)} 条 "
          f"(向量库alive {len(tid2row)}, 干净文件{len(clean_files)})")
    return pairs


def split_and_save(samples):
    """按9:1划分并保存为jsonl。"""
    rng = random.Random(SEED)
    rng.shuffle(samples)
    n_val = max(1, int(len(samples) * VAL_RATIO))
    val, train = samples[:n_val], samples[n_val:]

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    train_path = os.path.join(OUTPUT_DIR, "train.jsonl")
    val_path = os.path.join(OUTPUT_DIR, "val.jsonl")

    def write_jsonl(lst, path):
        with open(path, "w", encoding="utf-8") as f:
            for s in lst:
                f.write(json.dumps(s, ensure_ascii=False) + "\n")

    write_jsonl(train, train_path)
    write_jsonl(val, val_path)

    def count_by_task(lst):
        c = {}
        for s in lst:
            c[s["task"]] = c.get(s["task"], 0) + 1
        return c

    print(f"[INFO] 训练集: {len(train)} 条 -> {train_path}")
    print(f"[INFO] 验证集: {len(val)} 条 -> {val_path}")
    print(f"[INFO] 训练集分布: {count_by_task(train)}")
    print(f"[INFO] 验证集分布: {count_by_task(val)}")


def decode_existing_vectors(raw):
    """从训练数据的vector_b64字段直接解码已有BGE向量，避免重复编码。"""
    import base64
    import numpy as np
    vectors = []
    skipped = 0
    for obj in raw:
        vb = obj.get("vector_b64", "")
        if vb and len(vb) > 10:
            try:
                vec = np.frombuffer(base64.b64decode(vb), dtype=np.float32)
                if len(vec) == 1024:
                    vectors.append(vec.tolist())
                    continue
            except Exception:
                pass
        # 无有效向量时用零向量占位（训练时MSE损失会忽略）
        vectors.append([0.0] * 1024)
        skipped += 1
    print(f"[INFO] 从训练数据解码已有向量: {len(vectors)-skipped}条有效, {skipped}条缺失")
    return vectors


def main():
    print("=" * 60)
    print("中转三合一模型 - 训练数据预处理 (知识蒸馏版)")
    print("=" * 60)
    raw = load_raw_samples()
    # 优先使用训练数据中已有的vector_b64（BGE-m3已编码），避免重复编码
    bge_vecs = decode_existing_vectors(raw)
    samples = build_samples(raw, bge_vecs)
    # 追加向量库(干净数据BGE向量)扩展蒸馏对
    vec_lib_pairs = load_vector_library_pairs()
    samples.extend(vec_lib_pairs)
    print(f"[INFO] 合并后总样本: {len(samples)}")
    split_and_save(samples)
    print("[DONE] 数据预处理完成")


if __name__ == "__main__":
    main()
