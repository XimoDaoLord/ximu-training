#!/usr/bin/env python3
"""中转三合一模型(mT5-large) LoRA微调 + 向量知识蒸馏训练脚本。

底座: mT5-large (d_model=1024, encoder-decoder)
方法: LoRA微调(q/v/wo/wi) + 新增向量投影头(1024->1024)
任务: 多任务联合训练
  - 分类: seq2seq交叉熵 (输出task_type)
  - 提纯: seq2seq交叉熵 (输出提纯文本)
  - 向量: MSE蒸馏 (encoder输出 -> 投影头 -> L2归一化 -> 对齐BGE-m3向量)

支持CPU/GPU。训练后保存adapter + 合并完整模型。

用法:
  python scripts/train_transit_mt5.py
  python scripts/train_transit_mt5.py --epochs 5
"""
import os
import sys
import argparse
import json

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_MODEL_PATH = os.path.join(
    PROJECT_ROOT, "data", "用户数据", "本地模型", "mt5-base"
)
DEFAULT_DATA_DIR = os.path.join(PROJECT_ROOT, "data", "transit_training")
DEFAULT_OUTPUT_DIR = os.path.join(PROJECT_ROOT, "models", "transit_mt5_base")
VECTOR_DIM = 1024
VEC_LIB_PATH = os.path.join(
    PROJECT_ROOT, "data", "vectors", "core", "clean_data.vectors.npy"
)


class VectorIndex:
    """轻量向量库索引: 加载BGE向量, 支持top-k余弦检索。

    用于训练时的检索增强: 对向量任务样本, 召回top-k相似向量
    作为额外对比目标(拉近语义相近知识)。
    """

    def __init__(self, npy_path=VEC_LIB_PATH, top_k=3):
        import numpy as np
        self.top_k = top_k
        if not os.path.exists(npy_path):
            print(f"[WARN] 向量库不存在: {npy_path}, 检索增强关闭")
            self.vectors = None
            return
        vecs = np.load(npy_path).astype("float32")
        # L2归一化(余弦=内积)
        norms = np.linalg.norm(vecs, axis=1, keepdims=True) + 1e-9
        self.vectors = vecs / norms
        print(f"[INFO] 向量库索引已加载: {self.vectors.shape}, top_k={top_k}")

    def to_torch(self, device):
        """把向量搬到指定设备的torch张量, 供训练时批量检索。"""
        import torch
        if self.vectors is None:
            return
        self.vectors_torch = torch.from_numpy(self.vectors).to(device)

    def search(self, query_vec):
        """query_vec: numpy[1024] -> 返回top_k个相似向量numpy[k,1024]。"""
        import numpy as np
        if self.vectors is None:
            return None
        q = np.asarray(query_vec, dtype="float32")
        q = q / (np.linalg.norm(q) + 1e-9)
        sims = self.vectors @ q  # [N]
        top = np.argsort(-sims)[: self.top_k]
        return self.vectors[top]


def parse_args():
    p = argparse.ArgumentParser(description="mT5中转三合一 LoRA+蒸馏训练")
    p.add_argument("--model_path", default=DEFAULT_MODEL_PATH)
    p.add_argument("--data_dir", default=DEFAULT_DATA_DIR)
    p.add_argument("--output_dir", default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--batch_size", type=int, default=1)
    p.add_argument("--learning_rate", type=float, default=1e-4)
    p.add_argument("--epochs", type=int, default=3)
    p.add_argument("--max_steps", type=int, default=80,
                   help="最大训练步数(与epochs取小者优先)，-1表示不限制")
    p.add_argument("--early_stop_patience", type=int, default=3,
                   help="早停耐心值(评估次数)，连续N次eval_loss不下降则停止")
    p.add_argument("--eval_steps", type=int, default=20,
                   help="每多少步评估一次")
    p.add_argument("--save_steps", type=int, default=10,
                   help="每多少步保存一次检查点")
    p.add_argument("--save_total_limit", type=int, default=5,
                   help="保留最近N个检查点")
    p.add_argument("--resume_from_checkpoint", type=str, default=None,
                   help="从指定检查点恢复训练，不传则自动找最新")
    p.add_argument("--max_length", type=int, default=192,
                   help="最大序列长度(降低可加速,代码任务192够用)")
    p.add_argument("--lora_r", type=int, default=16)
    p.add_argument("--lora_alpha", type=int, default=32)
    p.add_argument("--lora_dropout", type=float, default=0.05)
    p.add_argument("--weight_decay", type=float, default=0.01)
    p.add_argument("--warmup_ratio", type=float, default=0.05)
    p.add_argument("--vector_loss_weight", type=float, default=1.0,
                   help="向量MSE损失权重")
    p.add_argument("--grad_accum", type=int, default=4,
                   help="梯度累积步数(有效batch=batch_size*grad_accum)")
    p.add_argument("--no_contrastive", action="store_true",
                   help="禁用对比损失(跳过13058向量矩阵乘,大幅加速)")
    p.add_argument("--no_merge", action="store_true")
    p.add_argument("--bfloat16", action="store_true",
                   help="CPU上用bfloat16加载模型(省内存但可能不稳定)")
    return p.parse_args()


def load_jsonl(path):
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                data.append(json.loads(line))
    return data


def _decode_vector_b64(vb64):
    """将base64编码的float32向量解码为1024维list。失败返回零向量。"""
    import base64
    import numpy as np
    if not vb64:
        return [0.0] * VECTOR_DIM
    try:
        raw = base64.b64decode(vb64)
        vec = np.frombuffer(raw, dtype="float32")
        if vec.shape[0] != VECTOR_DIM:
            print(f"[WARN] 向量维度{vec.shape[0]}≠{VECTOR_DIM}, 用零向量")
            return [0.0] * VECTOR_DIM
        return vec.tolist()
    except Exception as e:
        print(f"[WARN] 向量解码失败: {e}, 用零向量")
        return [0.0] * VECTOR_DIM


def _preprocess_raw(raw_list):
    """将实际数据字段映射为训练脚本期望的字段。

    实际列: task_type, purpose, input, output, text, vector_b64, ...
    期望列: input_text, target_text, task, vector_target
    """
    out = []
    n_vec_ok = 0
    for d in raw_list:
        input_text = d.get("input") or d.get("text") or ""
        target_text = d.get("output") or d.get("text") or ""
        # 所有样本均有vector_b64, 统一作为vector任务(同时学seq2seq+向量蒸馏)
        task = "vector"
        vt = _decode_vector_b64(d.get("vector_b64"))
        if any(abs(x) > 1e-8 for x in vt):
            n_vec_ok += 1
        out.append({
            "input_text": input_text,
            "target_text": target_text,
            "task": task,
            "vector_target": vt,
        })
    print(f"[INFO] 预处理: {len(out)}条, 有效向量: {n_vec_ok}")
    return out


def build_dataset(data_dir, tokenizer, max_length):
    """构建HF Dataset，对input/target编码，保留task和vector_target。"""
    from datasets import Dataset

    train_raw = _preprocess_raw(load_jsonl(os.path.join(data_dir, "train.jsonl")))
    val_raw = _preprocess_raw(load_jsonl(os.path.join(data_dir, "val.jsonl")))
    print(f"[INFO] 训练: {len(train_raw)}, 验证: {len(val_raw)}")

    def tokenize_fn(batch):
        enc = tokenizer(batch["input_text"], max_length=max_length,
                        truncation=True, padding="max_length")
        labels = tokenizer(batch["target_text"], max_length=max_length,
                           truncation=True, padding="max_length")
        enc["labels"] = [
            [t if t != tokenizer.pad_token_id else -100 for t in seq]
            for seq in labels["input_ids"]
        ]
        # task标签: 0=classify,1=purify,2=vector
        task_map = {"classify": 0, "purify": 1, "vector": 2}
        enc["task_id"] = [task_map[t] for t in batch["task"]]
        # vector_target: None或1024维list -> 统一为1024维float list
        vt = []
        for v in batch["vector_target"]:
            if v is None:
                vt.append([0.0] * VECTOR_DIM)
            else:
                vt.append(v)
        enc["vector_target"] = vt
        return enc

    train_ds = Dataset.from_list(train_raw)
    val_ds = Dataset.from_list(val_raw)
    train_ds = train_ds.map(tokenize_fn, batched=True, batch_size=100,
                            remove_columns=["input_text", "target_text", "task", "vector_target"])
    val_ds = val_ds.map(tokenize_fn, batched=True, batch_size=100,
                        remove_columns=["input_text", "target_text", "task", "vector_target"])
    return train_ds, val_ds


def custom_collator(features):
    """自定义collator: pad input_ids/labels, 保留task_id和vector_target为tensor。"""
    import torch
    batch = {}
    # pad input_ids and attention_mask
    max_len = max(len(f["input_ids"]) for f in features)
    input_ids, attn_masks, labels = [], [], []
    for f in features:
        ids = f["input_ids"]
        pad_len = max_len - len(ids)
        input_ids.append(ids + [0] * pad_len)
        attn_masks.append(f.get("attention_mask", [1]*len(ids)) + [0] * pad_len)
        lab = f["labels"]
        labels.append(lab + [-100] * (max_len - len(lab)))
    batch["input_ids"] = torch.tensor(input_ids, dtype=torch.long)
    batch["attention_mask"] = torch.tensor(attn_masks, dtype=torch.long)
    batch["labels"] = torch.tensor(labels, dtype=torch.long)
    batch["task_id"] = torch.tensor([f["task_id"] for f in features], dtype=torch.long)
    batch["vector_target"] = torch.tensor([f["vector_target"] for f in features], dtype=torch.float)
    return batch


def mean_pool(last_hidden, attention_mask):
    """对encoder输出做masked mean pooling。"""
    import torch
    mask = attention_mask.unsqueeze(-1).float()
    summed = (last_hidden * mask).sum(dim=1)
    counts = mask.sum(dim=1).clamp(min=1e-9)
    return summed / counts


def make_custom_trainer_class(vector_loss_weight, contrastive_weight=0.1,
                              contrastive_enabled=True):
    """返回自定义Seq2SeqTrainer子类。

    loss = lm_loss(seq2seq) + vector_loss_weight * mse(向量蒸馏)
           + contrastive_weight * 对比损失(拉近检索到的相似知识向量)
    """
    import torch
    import torch.nn.functional as F
    from transformers import Seq2SeqTrainer

    class TransitTrainer(Seq2SeqTrainer):
        """多任务训练器: seq2seq CE + 向量MSE蒸馏 + 检索对比。"""

        def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
            task_id = inputs.pop("task_id")
            vector_target = inputs.pop("vector_target")
            input_ids = inputs["input_ids"]
            attention_mask = inputs["attention_mask"]
            labels = inputs["labels"]

            outputs = model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                labels=labels,
            )
            lm_loss = outputs.loss

            enc_out = outputs.encoder_last_hidden_state
            pooled = mean_pool(enc_out, attention_mask)
            base = model.module if hasattr(model, "module") else model
            proj = F.normalize(base.projection_head(pooled), p=2, dim=-1).float()

            vec_mask = (task_id == 2).float()
            n_vec = vec_mask.sum().clamp(min=1e-9)
            mse = F.mse_loss(proj, vector_target.float(), reduction="none")
            mse = mse.mean(dim=-1)
            vec_loss = (mse * vec_mask).sum() / n_vec

            total_loss = lm_loss + vector_loss_weight * vec_loss

            # 对比损失: 仅在启用时计算(13058向量矩阵乘较耗时)
            if contrastive_enabled and contrastive_weight > 0:
                contrast_loss = torch.tensor(0.0, device=proj.device)
                idx = getattr(self, "vec_index", None)
                if idx is not None and idx.vectors is not None:
                    with torch.no_grad():
                        sims = idx.vectors_torch @ proj.T  # [N, B]
                        topk = sims.topk(min(3, sims.shape[0]), dim=0).values
                    contrast_loss = (1.0 - topk.mean())
                total_loss = total_loss + contrastive_weight * contrast_loss

            if return_outputs:
                return total_loss, outputs
            return total_loss

    return TransitTrainer


def main():
    args = parse_args()
    train_path = os.path.join(args.data_dir, "train.jsonl")
    if not os.path.exists(train_path):
        print(f"[ERROR] 训练数据不存在: {train_path}", file=sys.stderr)
        print("请先运行: python scripts/prepare_transit_training_data.py",
              file=sys.stderr)
        sys.exit(1)

    import torch
    import torch.nn as nn
    from transformers import (
        T5ForConditionalGeneration, T5Tokenizer,
        Seq2SeqTrainingArguments, DataCollatorForSeq2Seq,
    )
    from peft import LoraConfig, get_peft_model, TaskType

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"[INFO] 设备: {device}")
    if device == "cpu":
        n_cores = os.cpu_count() or 4
        torch.set_num_threads(n_cores)
        print(f"[INFO] CPU线程数: {n_cores} (torch.set_num_threads)")
    contrastive_enabled = not args.no_contrastive
    print(f"[INFO] 对比损失: {'启用' if contrastive_enabled else '禁用(加速)'}")

    tokenizer = T5Tokenizer.from_pretrained(args.model_path)
    # CPU默认float32(已验证可跑)，--bfloat16可省内存但可能不稳定；GPU用float16
    model_dtype = torch.bfloat16 if args.bfloat16 else (torch.float32 if device == "cpu" else torch.float16)
    model = T5ForConditionalGeneration.from_pretrained(
        args.model_path,
        torch_dtype=model_dtype,
    )
    print(f"[INFO] 模型加载精度: {model_dtype}")

    # 向量投影头: encoder pool (d_model) -> Linear(d_model, 1024)
    d_model = model.config.d_model
    model.projection_head = nn.Linear(d_model, VECTOR_DIM)
    print(f"[INFO] 已挂载向量投影头: Linear({d_model},{VECTOR_DIM})")

    # LoRA配置
    lora_config = LoraConfig(
        task_type=TaskType.SEQ_2_SEQ_LM,
        r=args.lora_r,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        target_modules=["q", "v", "wo", "wi_0", "wi_1"],
        modules_to_save=["projection_head"],
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()
    # 梯度检查点(bf16下内存够用,先禁用加速;OOM时再启用)
    model.config.use_cache = False
    model.enable_input_require_grads()
    # model.gradient_checkpointing_enable()
    print("[INFO] 梯度检查点: 禁用(bf16加速模式)")

    train_ds, val_ds = build_dataset(args.data_dir, tokenizer, args.max_length)

    # 确保输出目录存在
    os.makedirs(args.output_dir, exist_ok=True)

    # max_steps优先: 设定后覆盖epochs(num_epochs保持默认，max_steps自动优先生效)
    if args.max_steps and args.max_steps > 0:
        num_epochs = args.epochs
        max_steps = args.max_steps
        eval_strategy = "steps"
        save_strategy = "steps"
        eval_steps = args.eval_steps
        save_steps = args.save_steps
        print(f"[INFO] max_steps模式: {max_steps}步, 每{eval_steps}步评估, 每{save_steps}步保存检查点")
    else:
        num_epochs = args.epochs
        max_steps = -1
        eval_strategy = "epoch"
        save_strategy = "steps"
        eval_steps = None
        save_steps = args.save_steps

    training_args = Seq2SeqTrainingArguments(
        output_dir=args.output_dir,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        num_train_epochs=num_epochs,
        max_steps=max_steps,
        weight_decay=args.weight_decay,
        warmup_steps=min(50, max(5, max_steps // 10 if max_steps > 0 else 50)),
        logging_steps=10,
        eval_strategy=eval_strategy,
        eval_steps=eval_steps,
        save_strategy=save_strategy,
        save_steps=save_steps,
        save_total_limit=args.save_total_limit,
        predict_with_generate=False,
        generation_max_length=128,
        fp16=(device == "cuda"),
        gradient_accumulation_steps=args.grad_accum,
        gradient_checkpointing=False,
        dataloader_num_workers=0,
        load_best_model_at_end=(save_steps is not None and eval_steps is not None and save_steps % eval_steps == 0),
        metric_for_best_model="eval_loss",
        greater_is_better=False,
        report_to=[],
        remove_unused_columns=False,
        optim="adamw_torch",
    )

    data_collator = custom_collator

    TransitTrainer = make_custom_trainer_class(
        args.vector_loss_weight, contrastive_weight=0.1,
        contrastive_enabled=contrastive_enabled,
    )

    # 早停回调
    from transformers import EarlyStoppingCallback
    callbacks = [EarlyStoppingCallback(early_stopping_patience=args.early_stop_patience)]
    print(f"[INFO] 早停耐心值: {args.early_stop_patience}次评估不下降则停止")
    print(f"[INFO] 检查点策略: 每{save_steps}步保存, 保留最近{args.save_total_limit}个")
    _load_best = (save_steps is not None and eval_steps is not None and save_steps % eval_steps == 0)
    print(f"[INFO] load_best_model_at_end: {_load_best}" + ("" if _load_best else " (save_steps非eval_steps整数倍，已关闭)"))

    trainer = TransitTrainer(
        model=model,
        args=training_args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        data_collator=data_collator,
        callbacks=callbacks,
    )

    # 挂载向量库索引(仅对比损失启用时加载,否则跳过省内存和时间)
    if contrastive_enabled:
        vec_index = VectorIndex()
        vec_index.to_torch(device)
        trainer.vec_index = vec_index
    else:
        print("[INFO] 对比损失已禁用, 跳过向量库加载")

    # 自动寻找最新检查点用于resume
    resume_path = args.resume_from_checkpoint
    if resume_path is None:
        import glob as _glob
        ckpts = sorted(_glob.glob(os.path.join(args.output_dir, "checkpoint-*")),
                       key=lambda p: int(os.path.basename(p).split("-")[-1]))
        if ckpts:
            resume_path = ckpts[-1]
            print(f"[INFO] 自动发现最新检查点: {resume_path}")
    if resume_path and os.path.exists(resume_path):
        print(f"[INFO] 从检查点恢复训练: {resume_path}")
    else:
        print("[INFO] 从头开始训练(无检查点)")

    print("[INFO] 开始训练...")
    trainer.train(resume_from_checkpoint=resume_path)
    print("[INFO] 训练完成")

    adapter_dir = os.path.join(args.output_dir, "lora_adapter")
    model.save_pretrained(adapter_dir)
    tokenizer.save_pretrained(adapter_dir)
    print(f"[INFO] LoRA adapter保存: {adapter_dir}")

    if not args.no_merge:
        print("[INFO] 合并LoRA权重...")
        merged = model.merge_and_unload()
        merged_dir = os.path.join(args.output_dir, "merged")
        merged.save_pretrained(merged_dir)
        tokenizer.save_pretrained(merged_dir)
        # 投影头单独保存(merge_and_unload不会自动保存modules_to_save)
        import torch
        torch.save(
            model.projection_head.state_dict(),
            os.path.join(merged_dir, "projection_head.pt"),
        )
        print(f"[INFO] 合并模型+投影头保存: {merged_dir}")

    # 训练完成后自动跑严格评估
    print("[INFO] 训练完成, 开始自动评估质量门禁...")
    import subprocess
    eval_script = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "eval_transit.py"
    )
    merged_dir = os.path.join(args.output_dir, "merged")
    eval_cmd = [
        sys.executable, eval_script,
        "--model_dir", merged_dir if os.path.exists(merged_dir) else args.output_dir,
    ]
    print(f"[INFO] 执行: {' '.join(eval_cmd)}")
    ret = subprocess.run(eval_cmd, cwd=PROJECT_ROOT)
    if ret.returncode == 0:
        print("[PASS] 质量门禁通过, 可用于自举迭代")
    else:
        print("[WARN] 质量门禁未通过, 请勿上线; 请继续训练或调参")
    print("[DONE] 全部完成")


if __name__ == "__main__":
    main()
